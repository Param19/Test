package com.scb.channels.common.service.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.BatchAccBalService;
import com.scb.channels.common.vo.BatchAccBalVO;

public class BatchAccBalServiceTest {

private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchAccBal() {
		
		BatchAccBalService batchAccBalService = (BatchAccBalService)context.getBean("batchAccBalService");
		BatchAccBalVO batchAccBalVO = batchAccBalService.getBatchAccountBalance("1234", "000005509");
		assertNull(batchAccBalVO);
	}

}
