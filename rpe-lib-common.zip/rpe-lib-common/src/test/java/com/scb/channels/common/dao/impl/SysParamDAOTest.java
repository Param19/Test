package com.scb.channels.common.dao.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.common.dao.SysParamDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.SysParamVO;

public class SysParamDAOTest {

	ApplicationContext context = null;
	static SysParamVO  sysParamVO = null;

	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		if(sysParamVO==null){
		sysParamVO = new SysParamVO();
		sysParamVO.setCategory("DEFAULT_CURRENCY_CODE");
		sysParamVO.setSysCd("PRODUCT");
		sysParamVO.setValue("UGX");
		sysParamVO.setDtCreated(DateUtils.getCurrentDate());
		sysParamVO.setDtUpd(DateUtils.getCurrentDate());
		sysParamVO.setCreatedBy("SYSTEM");
		sysParamVO.setUpdBy("SYSTEM");
		}
		
	}

	
	@Test
	public void testInsert() {		
		SysParamDAO sysParamDAO =context.getBean("sysParamDAO",SysParamDAO.class);
		//sysParamDAO.insert(sysParamVO);
	}
	
	@Test
	public void testGet() {
		
		SysParamDAO sysParamDAO=  context.getBean("sysParamDAO",SysParamDAO.class);
		  //assertEquals("success",2,sysParamDAO.get(sysParamVO)==null?0:sysParamDAO.get(sysParamVO).getId());
		  sysParamDAO.get(sysParamVO);
	}
	
	@Test
	public void testUpdate() {
		
		sysParamVO.setValue("OTH1");
		sysParamVO.setUpdBy("SYS");
		sysParamVO.setDtUpd(DateUtils.getCurrentDate());
		sysParamVO.setCategory("CURRENCY_CODE");
		SysParamDAO sysParamDAO=  context.getBean("sysParamDAO",SysParamDAO.class);
		sysParamDAO.update(sysParamVO);
	}
	
	@Test
	public void testDelete() {
		
		SysParamDAO sysParamDAO=  context.getBean("sysParamDAO",SysParamDAO.class);
		sysParamDAO.delete(sysParamVO);
	}

}
