package com.scb.channels.common.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;

public class DataBeanTest {
	private ApplicationContext context = null;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}
	@Test
	public void testLoadVariables() {
		System.out.println("before bean loading");
		DataBean bean = (DataBean) context.getBean("dataBean");
		bean.init();
		//System.out.println(list.size());
	}

}
