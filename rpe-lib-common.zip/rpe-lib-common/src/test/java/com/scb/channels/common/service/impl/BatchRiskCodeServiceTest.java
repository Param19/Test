package com.scb.channels.common.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.BatchRiskCodeService;
import com.scb.channels.common.vo.BatchRiskCodeVO;

public class BatchRiskCodeServiceTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchRiskCodeTxnWithEmptyObj() {
		BatchRiskCodeService batchRiskCodeService = (BatchRiskCodeService)context.getBean("batchRiskCodeService");
		BatchRiskCodeVO batchFxRateVO = new BatchRiskCodeVO();
		List<BatchRiskCodeVO> batchRiskCodeList = batchRiskCodeService.getBatchRiskCode(batchFxRateVO);
		assertFalse(!CollectionUtils.isEmpty(batchRiskCodeList));
	}
	

	@Test
	public void testListBatchRiskCodeWithNullObj() {
		BatchRiskCodeService batchRiskCodeService = (BatchRiskCodeService)context.getBean("batchRiskCodeService");
		List<BatchRiskCodeVO> batchRiskCodeList = batchRiskCodeService.getBatchRiskCode(null);
		assertFalse(!CollectionUtils.isEmpty(batchRiskCodeList));
	}
	
	
	@Test
	public void testListBatchRiskCode() {
		
		BatchRiskCodeService batchRiskCodeService = (BatchRiskCodeService)context.getBean("batchRiskCodeService");
		BatchRiskCodeVO batchFxRateVO = new BatchRiskCodeVO();
		batchFxRateVO.setId(1);
		List<BatchRiskCodeVO> batchRiskCodeList = batchRiskCodeService.getBatchRiskCode(batchFxRateVO);
		assertFalse(!CollectionUtils.isEmpty(batchRiskCodeList));
	}
	
	

}
