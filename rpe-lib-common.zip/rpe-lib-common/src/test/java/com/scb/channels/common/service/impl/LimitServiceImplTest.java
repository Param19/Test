package com.scb.channels.common.service.impl;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.LimitService;

public class LimitServiceImplTest {
	
	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void testIsLimitAvailable() {
		LimitService limitService = (LimitService)context.getBean("limitService");
		UserVO user=new UserVO();
		user.setCustomerId("21886118");
		user.setChannelId("ATM");
		user.setCountry("KE");
		user.setResident("N");
		user.setSalary("N");
		user.setStaff("N");
		user.setSegmentCode("01");
		
		AccountVO srcAccountVO= new AccountVO();
		srcAccountVO.setAccountNumber("876543");
		srcAccountVO.setCurrency("KES");
		srcAccountVO.setAmount(new BigDecimal(100));
		
		AccountVO destAccountVO= new AccountVO();
		destAccountVO.setAccountNumber("12354");
		destAccountVO.setCurrency("KES");
		//destAccountVO.setAmount(new BigDecimal(100));
		destAccountVO.setCtryCD("KE");
		
		ClientVO clientVO=new ClientVO();
		clientVO.setClientId("ADC");
		clientVO.setChannel("ADC");
		
		TransactionInfoVO trnfrTxnBO=new TransactionInfoVO();
		trnfrTxnBO.setClientVO(clientVO);
		trnfrTxnBO.setUserVO(user);
		trnfrTxnBO.setTxnId("NGN8767678898956");
		//trnfrTxnBO.setUser(user);
		trnfrTxnBO.setSrcAccountVO(srcAccountVO);
		trnfrTxnBO.setDestAccountVO(destAccountVO);
		trnfrTxnBO.setTransferAmt(100);		
		trnfrTxnBO.setTxnStatusCd("SUCC");
		trnfrTxnBO.setDtCreated(new Date());
		trnfrTxnBO.setCreatedBy("adcuser");
		trnfrTxnBO.setDtUpd(new Date());
		trnfrTxnBO.setUpdBy("adcuser");
		trnfrTxnBO.setVersion(9);
		trnfrTxnBO.setTransferCurrencyCd("KES");
		trnfrTxnBO.setId(24);
		
		limitService.isLimitAvailable(trnfrTxnBO);
	}

}
