package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.util.CollectionUtils;

import com.scb.channels.common.dao.BatchAccRelDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchAccRelVO;

public class BatchAccRelDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchAccBalWithNull() {
		BatchAccRelDAO batchAccBalDao = (BatchAccRelDAO)context.getBean("batchAccRelDAO");
		List<BatchAccRelVO> batchList = batchAccBalDao.getBatchAccountRel(null);
		assertFalse(!CollectionUtils.isEmpty(batchList));
	}
	
	@Test
	public void testListBatchAccBalWithEmptyObj() {
		BatchAccRelDAO batchAccBalDao = (BatchAccRelDAO)context.getBean("batchAccRelDAO");
		BatchAccRelVO batchAccRelVO = new BatchAccRelVO();
		List<BatchAccRelVO> batchList = batchAccBalDao.getBatchAccountRel(batchAccRelVO);
		assertFalse(!CollectionUtils.isEmpty(batchList));
	}
	
	@Test
	public void testListBatchAccBal() {
		BatchAccRelDAO batchAccBalDao = (BatchAccRelDAO)context.getBean("batchAccRelDAO");
		BatchAccRelVO batchAccRelVO = new BatchAccRelVO();
		batchAccRelVO.setCustGroupId("000011453");
		List<BatchAccRelVO> batchList = batchAccBalDao.getBatchAccountRel(batchAccRelVO);
		assertTrue(CollectionUtils.isEmpty(batchList));
	}

}
