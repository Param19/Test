package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.BatchAccBalDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchAccBalVO;

public class BatchAccBalDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testDaoObjIsNotNull() {
		BatchAccBalDAO batchAccBalDao = (BatchAccBalDAO)context.getBean("batchAccBalDAO");
		assertNotNull(batchAccBalDao);
	}

	@Test
	public void testListEmptyOnNullParams() {
		BatchAccBalDAO batchAccBalDao = (BatchAccBalDAO)context.getBean("batchAccBalDAO");
		BatchAccBalVO batchAccBalVO = batchAccBalDao.getBatchAccountBalance(null, null);
		assertNull(batchAccBalVO);

	}
	
	@Test
	public void testListEmptyOnInvalidCustId() {
		BatchAccBalDAO batchAccBalDao = (BatchAccBalDAO)context.getBean("batchAccBalDAO");
		BatchAccBalVO batchAccBalVO = batchAccBalDao.getBatchAccountBalance("12", "123303");
		assertNull(batchAccBalVO);

	}
	
	@Test
	public void testListEmptyOnInvalidId() {
		BatchAccBalDAO batchAccBalDao = (BatchAccBalDAO)context.getBean("batchAccBalDAO");
		BatchAccBalVO batchAccBalVO = batchAccBalDao.getBatchAccountBalance("11002201", "000002002");
		assertNull(batchAccBalVO);
	}
	
	@Test
	public void testListBatchAccBal() {
		BatchAccBalDAO batchAccBalDao = (BatchAccBalDAO)context.getBean("batchAccBalDAO");
		BatchAccBalVO batchAccBalVO = batchAccBalDao.getBatchAccountBalance("2850709573001", "000005509");
		assertNull(batchAccBalVO);
	}
	
	

}
