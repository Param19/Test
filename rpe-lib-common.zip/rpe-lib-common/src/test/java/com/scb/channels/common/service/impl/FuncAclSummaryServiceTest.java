package com.scb.channels.common.service.impl;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.FuncAclSummaryService;

public class FuncAclSummaryServiceTest {
	
	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Ignore
	@Test
	public void testIsLimitAvailable() {
		FuncAclSummaryService funcAclSummaryService = context.getBean("funcAclSummaryService",FuncAclSummaryService.class);
			
		funcAclSummaryService.checkProductFilter("OED-SRC-SG", "514", "514", "KES", "0", null);
	}

}
