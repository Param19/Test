/**
 * 
 */
package com.scb.channels.common.dao.impl;

import static org.junit.Assert.assertFalse;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.LimitDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.LimitCriteriaVO;
import com.scb.channels.common.vo.OverallLimitVO;
import com.scb.channels.common.vo.TransactionLimitVO;

/**
 * @author 1411807
 *
 */
public class LimitDaoTest {
	
	private ApplicationContext context = null;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	/**
	 * Test method for {@link com.scb.channels.transaction.transfer.dao.impl.LimitDAOImpl#getOverallLimits(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	//@Test
	public void testGetOverallLimits() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<OverallLimitVO> list =  dao.getOverallLimits("000002002", "KE", "ADC");
		assertFalse(CollectionUtils.isEmpty(list));
		System.out.println(list.size());
	}

	@Test
	public void testGetOverallLimitsListEmptyOnInvalidCustId() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<OverallLimitVO> list =  dao.getOverallLimits("234556", "KE", "DUB");
		assertFalse(!CollectionUtils.isEmpty(list));
	}
	
	@Test
	public void testGetOverallLimitsListEmptyOnInvalidCOuntry() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<OverallLimitVO> list =  dao.getOverallLimits("12345", "UK", "DUB");
		assertFalse(!CollectionUtils.isEmpty(list));
	}  
	
	@Test
	public void testGetOverallLimitsListEmptyOnInvalidChannelID() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<OverallLimitVO> list =  dao.getOverallLimits("12345", "KE", "ADC1");
		assertFalse(!CollectionUtils.isEmpty(list));
	}

	@Test
	public void testGetOverallLimitsListEmptyOnNullParameters() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<OverallLimitVO> list =  dao.getOverallLimits(null,null,null);
		assertFalse(!CollectionUtils.isEmpty(list));
	}

	/**
	 * Test method for {@link com.scb.channels.transaction.transfer.dao.impl.LimitDAOImpl#getTransactionLimits(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	
	
	//@Test
	public void testGetTransactionLimits() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits("000002002", "KE", "ADC", "IFT", "KES", "KES");
		assertFalse(CollectionUtils.isEmpty(list));
		
	}
	
	
	@Test
	public void testGetTransactionLimitsFXCurr() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits("21886118", "KE", "ADC", "IFT", "KES", "USD");
		assertFalse(!CollectionUtils.isEmpty(list));
		
	} 

	
	@Test
	public void testGetTransactionLimitsListEmptyNullParameter() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits(null,null,null, null,null,null);
		assertFalse(!CollectionUtils.isEmpty(list));
		
	}
	
			
	@Test
	public void testGetTransactionLimitsListEmptyInvalidChannel() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits("000000001", "KE", "IBNK11", "IFT", "KES", "KES");
		assertFalse(!CollectionUtils.isEmpty(list));
		System.out.println(list.size());
	}

	@Test
	public void testGetTransactionLimitsListEmptyInvalidTxnType() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits("000000001", "KE", "ADC", "IBFT", "KES", "USD");
		assertFalse(!CollectionUtils.isEmpty(list));
		System.out.println(list.size());
	}
	
	@Test
	public void testGetTransactionLimitsListEmptyInvalidSrcCurr() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits("000000001", "KE", "ADC", "IFT", "USD", "USD");
		assertFalse(!CollectionUtils.isEmpty(list));
		System.out.println(list.size());
	}
	
	@Test
	public void testGetTransactionLimitsListEmptyInvalidDestCurr() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		List<TransactionLimitVO> list =  dao.getTransactionLimits("218861181", "KE", "ADC", "IBFT", "KES", "GBR");
		assertFalse(!CollectionUtils.isEmpty(list));
		System.out.println(list.size());
	}	
	
	/**
	 * Test method for {@link com.scb.channels.transaction.transfer.dao.impl.LimitDAOImpl#getTransactionLimits(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	//@Test
	public void testGetCustomerLimits() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		Map<String, Map<String, Double>>  map =  dao.getCustomerLimits("21886118", "ADC", "001", "IFT");
		assertFalse(map.isEmpty());
		System.out.println(map.size());
		for (Entry<String, Map<String, Double>> entry : map.entrySet()) {
			System.out.println(entry.getKey());
			Map<String, Double> mapD = entry.getValue();
			for (Entry<String, Double> entry1 : mapD.entrySet()) {
				System.out.println(entry1.getKey());
				System.out.println(entry1.getValue());
			}
		}
	} 
	
	@Test
	public void testGetCriteria() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "N", "N", "N");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
		
	}
	
	
	@Test
	public void testGetCriteriaResident() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "Y", "N", "N");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
	} 
	
	@Test
	public void testGetCriteriaStaff() { 
		LimitDAO dao = (LimitDAO) context.getBean("limitDao"); 
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "N", "N", "N");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
	}
	
	
	@Test
	public void testGetCriteriaSalary() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "N", "N", "Y");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
	}
	
	
	@Test
	public void testGetCriteriaResidentSalary() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "Y", "N", "Y");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
	}
	
	@Test
	public void testGetCriteriaResidentStaffSalary() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "Y", "Y", "Y");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
	} 
 @Test
	public void testGetCriteriaStaffSalary() {
		LimitDAO dao = (LimitDAO) context.getBean("limitDao");
		LimitCriteriaVO limitCriteriaVO = dao.getCriteria("KE", "01", "N", "Y", "Y");
		assertFalse(limitCriteriaVO==null);
		System.out.println(limitCriteriaVO.getLimitSegmentCode() + "_" + limitCriteriaVO.getLimitSegmentName());
	}
}
