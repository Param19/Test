package com.scb.channels.common.dao.impl;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.AuthViewDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.AuthViewVO;

public class AuthViewDAOTest {

	private ApplicationContext context = null;
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}
	@Test
	public void testGet() {
		AuthViewDAO authViewDAO =  context.getBean("authViewDAO",AuthViewDAO.class);
		AuthViewVO authViewVO=  authViewDAO.get("12345678","1234","KE","ADC","EN");		
		Assert.assertNotNull(authViewVO);
	}

}
