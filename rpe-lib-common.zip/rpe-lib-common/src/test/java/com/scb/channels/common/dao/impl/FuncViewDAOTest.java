package com.scb.channels.common.dao.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.FuncViewDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.FuncViewVO;

public class FuncViewDAOTest {

	private ApplicationContext context=null;
	static  FuncViewVO funcViewVO = null;
	
	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		if(funcViewVO==null){
		   funcViewVO = new FuncViewVO();
		   funcViewVO.setFuncCd("LOGIN_CD");
		   funcViewVO.setStatusCd("A");
		
		}
	}

	@Test
	public void testGet() {
		
		FuncViewDAO funcViewDAO=  context.getBean("funcViewDAO",FuncViewDAO.class);
		  //assertEquals("success",127,referenceDAO.get(referenceVO)==null?0:referenceDAO.get(referenceVO).getId());
		//assertEquals("EN",funcViewDAO.get(funcViewVO)==null?"EN":funcViewDAO.get(funcViewVO).getLangCd());
	}
}
