package com.scb.channels.common.dao.impl;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.CustomerProfileVO;
import com.scb.channels.common.dao.CustomerProfileDAO;
import com.scb.channels.common.helper.TestHelper;

public class CustomerProfileDAOImplTest {
	
	private ApplicationContext context = null;
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void testGetCustomerProfile() {
		CustomerProfileDAO customerProfileDAO =  context.getBean("customerProfileDAO", CustomerProfileDAO.class);
		CustomerProfileVO customerProfileVO =  customerProfileDAO.getCustomerProfile("987654321");
		assertNotNull(customerProfileVO);
	}

	@Test
	public void testGetCustomerProfileForRelationship() {
		CustomerProfileDAO customerProfileDAO =  context.getBean("customerProfileDAO", CustomerProfileDAO.class);
		CustomerProfileVO customerProfileVO =  customerProfileDAO.getCustomerProfile("987654321");
		assertNotNull(customerProfileVO);
	}

}
