package com.scb.channels.common.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.BatchFxRateService;
import com.scb.channels.common.vo.BatchFxRateVO;

public class BatchFxRateServiceTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}

	@Test
	public void testListBatchFxRateWithEmptyObj() {
		BatchFxRateService batchFxRateService = (BatchFxRateService)context.getBean("batchFxRateService");
		BatchFxRateVO batchFxRateVO = new BatchFxRateVO();
		List<BatchFxRateVO> batchCardBalList = batchFxRateService.getBatchFxRate(batchFxRateVO);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	

	@Test
	public void testListBatchFxRateWithNullObj() {
		BatchFxRateService batchFxRateService = (BatchFxRateService)context.getBean("batchFxRateService");
		List<BatchFxRateVO> batchCardBalList = batchFxRateService.getBatchFxRate(null);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	
	@Test
	public void testListBatchFxRate() {
		
		BatchFxRateService batchFxRateService = (BatchFxRateService)context.getBean("batchFxRateService");
		BatchFxRateVO batchFxRateVO = new BatchFxRateVO();
		batchFxRateVO.setId(1);
		List<BatchFxRateVO> batchCardBalList = batchFxRateService.getBatchFxRate(batchFxRateVO);
		assertTrue(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	

}
