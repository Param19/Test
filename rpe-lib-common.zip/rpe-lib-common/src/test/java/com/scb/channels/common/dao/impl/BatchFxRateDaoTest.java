package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import com.scb.channels.common.dao.BatchFxRateDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchFxRateVO;

public class BatchFxRateDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchFxRateWithEmptyObj() {
		BatchFxRateDAO batchCardTxnDAO = (BatchFxRateDAO)context.getBean("batchFxRateDAO");
		BatchFxRateVO batchFxRateVO = new BatchFxRateVO();
		List<BatchFxRateVO> batchCardBalList = batchCardTxnDAO.getBatchFxRate(batchFxRateVO);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	

	@Test
	public void testListBatchFxRateWithNullObj() {
		BatchFxRateDAO batchCardTxnDAO = (BatchFxRateDAO)context.getBean("batchFxRateDAO");
		List<BatchFxRateVO> batchCardBalList = batchCardTxnDAO.getBatchFxRate(null);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	
	@Test
	public void testListBatchFxRate() {
		BatchFxRateDAO batchCardTxnDAO = (BatchFxRateDAO)context.getBean("batchFxRateDAO");
		BatchFxRateVO batchFxRateVO = new BatchFxRateVO();
		batchFxRateVO.setId(1);
		List<BatchFxRateVO> batchCardBalList = batchCardTxnDAO.getBatchFxRate(batchFxRateVO);
		assertTrue(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	

}
