package com.scb.channels.common.dao.impl;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.common.dao.ReferenceDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.ReferenceVO;

public class ReferenceDAOTest {

	private ApplicationContext context=null;
	static  ReferenceVO referenceVO = null;
	
	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		if(referenceVO==null){
		referenceVO = new ReferenceVO();
		referenceVO.setCreatedBy("SYSTEM");
		referenceVO.setChannelId("NG");
		referenceVO.setDescription("CURRENCY OTH");
		referenceVO.setCreatedTimeStamp(new Date());
		referenceVO.setUdpatedTimeStamp(new Date());
		//referenceVO.setIsDefault(isDefault);
		//referenceVO.setIsDisplay(isDisplay);
		referenceVO.setRefCode("OTH");
		referenceVO.setSeqNo(1);
		//referenceVO.setStatusCd(statusCd);
		referenceVO.setType("SCB_ACCOUNT_CURRENCY");
		referenceVO.setUpdatedBy("SYSTEM");
		referenceVO.setRefValue("CURRENCY OTH");
		}
	}

	

	@Test
	public void testInsert() {
		ReferenceDAO referenceDAO=  context.getBean("referenceDAO",ReferenceDAO.class);
		referenceDAO.insert(referenceVO);
	}
	
	@Test
	public void testGet() {		
		ReferenceDAO referenceDAO=  context.getBean("referenceDAO",ReferenceDAO.class);
		  //assertEquals("success",127,referenceDAO.get(referenceVO)==null?0:referenceDAO.get(referenceVO).getId());
		 referenceDAO.get(referenceVO);
	}
	
	@Test
	public void testUpdate() {
		
		referenceVO.setRefCode("OTH1");
		referenceVO.setUpdatedBy("SYS");
		referenceVO.setUdpatedTimeStamp(DateUtils.getCurrentDate());
		referenceVO.setStatusCode("NA");
		ReferenceDAO referenceDAO=  context.getBean("referenceDAO",ReferenceDAO.class);
		referenceDAO.update(referenceVO);
	}
	
	@Test
	public void testDelete() {
		
		ReferenceDAO referenceDAO=  context.getBean("referenceDAO",ReferenceDAO.class);
		referenceDAO.delete(referenceVO);
	}

	
	
}
