package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import com.scb.channels.common.dao.BatchCardTxnDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchCardTxnVO;

public class BatchCardTxnDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchCardTxnWithEmptyObj() {
		BatchCardTxnDAO batchCardTxnDAO = (BatchCardTxnDAO)context.getBean("batchCardTxnDAO");
		BatchCardTxnVO batchCardTxnVO = new BatchCardTxnVO();
		List<BatchCardTxnVO> batchCardBalList = batchCardTxnDAO.getBatchCardTxn(batchCardTxnVO);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	

	@Test
	public void testListBatchCardTxnWithNullObj() {
		BatchCardTxnDAO batchCardTxnDAO = (BatchCardTxnDAO)context.getBean("batchCardTxnDAO");
		List<BatchCardTxnVO> batchCardBalList = batchCardTxnDAO.getBatchCardTxn(null);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	
	//@Test
	public void testListBatchCardTxn() {
		BatchCardTxnDAO batchCardTxnDAO = (BatchCardTxnDAO)context.getBean("batchCardTxnDAO");
		BatchCardTxnVO batchCardTxnVO = new BatchCardTxnVO();
		batchCardTxnVO.setId(1);
		List<BatchCardTxnVO> batchCardBalList = batchCardTxnDAO.getBatchCardTxn(batchCardTxnVO);
		assertTrue(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	

}
