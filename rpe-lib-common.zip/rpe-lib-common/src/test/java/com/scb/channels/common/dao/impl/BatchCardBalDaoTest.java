package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.BatchCardBalDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchCardBalVO;

public class BatchCardBalDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchCardBalWithEmptyObj() {
		BatchCardBalDAO batchAccTxnDAO = (BatchCardBalDAO)context.getBean("batchCardBalDAO");
		BatchCardBalVO batchCardBalVO = new BatchCardBalVO();
		List<BatchCardBalVO> BatchCardBalList = batchAccTxnDAO.getBatchCardBal(batchCardBalVO);
		assertFalse(!CollectionUtils.isEmpty(BatchCardBalList));
	}
	

	@Test
	public void testListBatchCardBalWithNullObj() {
		BatchCardBalDAO batchAccTxnDAO = (BatchCardBalDAO)context.getBean("batchCardBalDAO");
		List<BatchCardBalVO> BatchCardBalList = batchAccTxnDAO.getBatchCardBal(null);
		assertFalse(!CollectionUtils.isEmpty(BatchCardBalList));
	}
	
	
	@Test
	public void testListBatchCardBal() {
		BatchCardBalDAO batchAccTxnDAO = (BatchCardBalDAO)context.getBean("batchCardBalDAO");
		BatchCardBalVO batchCardBalVO = new BatchCardBalVO();
		batchCardBalVO.setId(1);
		List<BatchCardBalVO> BatchCardBalList = batchAccTxnDAO.getBatchCardBal(batchCardBalVO);
		assertTrue(!CollectionUtils.isEmpty(BatchCardBalList));
	}
	
	

}
