package com.scb.channels.common.dao.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.BillerValidationDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.ReferenceVO;

public class BillerValidationDAOTest {

	private ApplicationContext context=null;
	static  ReferenceVO referenceVO = null;
	
	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		
	}

	


	
	@Test
	public void testGet() {		
		BillerValidationDAO billerValidationDAO=  context.getBean("billerValidationDAO",BillerValidationDAO.class);
		  //assertEquals("success",127,referenceDAO.get(referenceVO)==null?0:referenceDAO.get(referenceVO).getId());
		
		billerValidationDAO.getByctryCdAndBillerCd("KE", "1010");
		billerValidationDAO.get("requestVO.billerPayDetailsVO.consumerNo","KE","1010");
	}
	
	

	
	
}
