package com.scb.channels.common.dao.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.FuncAclSummaryDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.FuncAclSummaryVO;

public class FuncAclSummaryDAOTest {

	private ApplicationContext context=null;
	static  FuncAclSummaryVO funcAclSummaryVO = null;
	
	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		if(funcAclSummaryVO==null){
		funcAclSummaryVO = new FuncAclSummaryVO();
		funcAclSummaryVO.setFuncCode("FUNC_FT_OWN_DR_NG");
		
		
		}
	}

	

	
	
	@Test
	public void testGet() {		
		FuncAclSummaryDAO funcAclSummaryDAO=  context.getBean("funcAclSummaryDAO",FuncAclSummaryDAO.class);
		 
		funcAclSummaryDAO.get();
	}
	
	

	
	
}
