package com.scb.channels.common.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.util.List;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.common.dao.ChannelCommonDAO;
import com.scb.channels.base.exception.DAOException;
import com.scb.channels.common.vo.ChannelMaskPolicyVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.helper.TestHelper;


public class ChannelCommonDAOImplTest {

	private static final Logger logger = LoggerFactory.getLogger(ChannelCommonDAOImplTest.class);
	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	//@Test
	public void getAllMaskPolicyTest() throws DAOException {
		ChannelCommonDAO channelCommonDAO = (ChannelCommonDAO) context.getBean("channelCommonDAO");
		
		String typeCode="Logger";
		List<ChannelMaskPolicyVO> channelPolicyList = channelCommonDAO.getAllMaskPolicy(typeCode);
		logger.info(":::::getAllMaskPolicyTest() begins::::");
		logger.info("channelPolicyList.size():==="+ channelPolicyList.size());
		assertNotNull(channelPolicyList);
		logger.info(":::::getAllMaskPolicyTest() ends::::");
	}
	
	//@Test
	public void getChannelMaskPolicyTest() throws DAOException {
		ChannelCommonDAO channelCommonDAO = (ChannelCommonDAO) context.getBean("channelCommonDAO");
		ClientVO clientVO= new ClientVO();
		clientVO.setChannel("KIOSK");
		clientVO.setCountry("NG");
		
		String categoryCode="payments";
		String typeCode="email";
		logger.info(":::::getChannelMaskPolicyTest() begins::::");
		List<ChannelMaskPolicyVO> channelPolicyList = channelCommonDAO.getChannelMaskPolicy(typeCode,categoryCode,clientVO);
		logger.info("channelPolicyList.size():==="+ channelPolicyList.size());
		assertNotNull(channelPolicyList);
		logger.info(":::::getChannelMaskPolicyTest() ends::::");
	}
	
	
	@Test
	public void getChannelMaskPolicyForFieldTest() throws DAOException {
		ChannelCommonDAO channelCommonDAO = (ChannelCommonDAO) context.getBean("channelCommonDAO");
		ClientVO clientVO= new ClientVO();
		clientVO.setChannel("KIOSK");
		clientVO.setCountry("KE");
		
		String categoryCode="payments";
		String typeCode="email";
		String fieldName="accountNumber";
		ChannelMaskPolicyVO channelMaskPolicyVO = channelCommonDAO.getChannelMaskPolicyForField(typeCode, categoryCode, clientVO, fieldName);
		logger.info(":::::getChannelMaskPolicyForFieldTest() begins::::");
		/*logger.info("channelMaskPolicyVO.getPattern():==="+ channelMaskPolicyVO.getPattern() );
		assertNotNull(channelMaskPolicyVO);
		logger.info(":::::getChannelMaskPolicyForFieldTest() ends::::");*/
	}

}
