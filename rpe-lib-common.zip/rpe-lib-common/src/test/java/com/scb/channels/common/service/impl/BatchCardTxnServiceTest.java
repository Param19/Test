package com.scb.channels.common.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.BatchCardTxnService;
import com.scb.channels.common.vo.BatchCardTxnVO;

public class BatchCardTxnServiceTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	//@Test
	public void testListBatchCardTxnWithEmptyObj() {
		BatchCardTxnService batchCardTxnService = (BatchCardTxnService)context.getBean("batchCardTxnService");
		BatchCardTxnVO batchCardTxnVO = new BatchCardTxnVO();
		List<BatchCardTxnVO> batchCardBalList = batchCardTxnService.getBatchCardTxn(batchCardTxnVO);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	

	//@Test
	public void testListBatchCardTxnWithNullObj() {
		BatchCardTxnService batchCardTxnService = (BatchCardTxnService)context.getBean("batchCardTxnService");
		List<BatchCardTxnVO> batchCardBalList = batchCardTxnService.getBatchCardTxn(null);
		assertFalse(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	
	//@Test
	public void testListBatchCardTxn() {
		BatchCardTxnService batchCardTxnService = (BatchCardTxnService)context.getBean("batchCardTxnService");
		BatchCardTxnVO batchCardTxnVO = new BatchCardTxnVO();
		batchCardTxnVO.setId(1);
		List<BatchCardTxnVO> batchCardBalList = batchCardTxnService.getBatchCardTxn(batchCardTxnVO);
		assertTrue(!CollectionUtils.isEmpty(batchCardBalList));
	}
	
	

}
