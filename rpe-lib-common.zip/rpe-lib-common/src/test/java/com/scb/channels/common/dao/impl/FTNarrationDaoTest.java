/**
 * 
 */
package com.scb.channels.common.dao.impl;

import static org.junit.Assert.assertFalse;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.FTNarrationDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.FTNarrationVO;

/**
 * @author 1464143
 *
 */
public class FTNarrationDaoTest {
	
	private ApplicationContext context = null;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	/**
	 * Test method for {@link com.scb.channels.transaction.transfer.dao.impl.LimitDAOImpl#getOverallLimits(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void getAllNarration() {
		
		FTNarrationDAO dao =  context.getBean("fTNarrationDAO",FTNarrationDAO.class);
		List<FTNarrationVO> list =  dao.get("ADC", "KE");
		assertFalse(CollectionUtils.isEmpty(list));
		System.out.println(list.size());
	}

	
}
