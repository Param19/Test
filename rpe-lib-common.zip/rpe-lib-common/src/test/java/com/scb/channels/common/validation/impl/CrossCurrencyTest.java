package com.scb.channels.common.validation.impl;


import org.apache.commons.validator.ValidatorException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.TransferRequestVO;
import com.scb.channels.common.helper.TestHelper;


public class CrossCurrencyTest {
	private ApplicationContext context = null;

	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
	}

	@After
	public void tearDown() throws Exception {
	}
	
	
	@Test
	public void checkCrossCurrency() throws ValidatorException{
		PayloadDTO payloadDTO = getTransferPayload();
		CrossCurrencyValidator crossCurrencyValidator = (CrossCurrencyValidator)context.getBean("xCurrencyValidator");
		crossCurrencyValidator.setBean(payloadDTO);
		crossCurrencyValidator.validate();
	}
	
	private PayloadDTO getTransferPayload() {
		
		TransferRequestVO transferRequestVO = new TransferRequestVO();
		ClientVO clientVO = new ClientVO();
		clientVO.setChannel("ADC");
		clientVO.setCountry("KE"); 
		transferRequestVO.setClientVO(clientVO);
		
		TransactionInfoVO transationInfoVO = new TransactionInfoVO();
		transationInfoVO.setSrcAccountVO(new AccountVO());
		transationInfoVO.getSrcAccountVO().setCurrency("KES");
		
		transationInfoVO.setDestAccountVO(new AccountVO());
		transationInfoVO.getDestAccountVO().setCurrency("KES");
		transferRequestVO.setTransactionInfoVO(transationInfoVO);
		
		PayloadDTO payloadDTO = new PayloadDTO();
		payloadDTO.setRequestVO(transferRequestVO);
		
		return payloadDTO;
	}
	

}
