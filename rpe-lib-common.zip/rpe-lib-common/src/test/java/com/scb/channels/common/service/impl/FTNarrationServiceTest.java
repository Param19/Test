package com.scb.channels.common.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.FTNarrationService;
import com.scb.channels.common.vo.FTNarrationVO;

public class FTNarrationServiceTest {

private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchAccBal() {
		
		FTNarrationService fTNarrationService = context.getBean("fTNarrationService",FTNarrationService.class);
		Map<String, FTNarrationVO> ftnarrationMap = fTNarrationService.getCacheFTNarration("ADC", "KE", "IFT");
		assertNotNull(ftnarrationMap);
	}

}
