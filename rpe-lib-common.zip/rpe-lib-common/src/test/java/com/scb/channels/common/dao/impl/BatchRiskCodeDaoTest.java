package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.BatchRiskCodeDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchRiskCodeVO;

public class BatchRiskCodeDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchRiskCodeTxnWithEmptyObj() {
		BatchRiskCodeDAO batchRiskCodeDAO = (BatchRiskCodeDAO)context.getBean("batchRiskCodeDAO");
		BatchRiskCodeVO batchFxRateVO = new BatchRiskCodeVO();
		List<BatchRiskCodeVO> batchRiskCodeList = batchRiskCodeDAO.getBatchRiskCode(batchFxRateVO);
		assertFalse(!CollectionUtils.isEmpty(batchRiskCodeList));
	}
	

	@Test
	public void testListBatchRiskCodeWithNullObj() {
		BatchRiskCodeDAO batchRiskCodeDAO = (BatchRiskCodeDAO)context.getBean("batchRiskCodeDAO");
		List<BatchRiskCodeVO> batchRiskCodeList = batchRiskCodeDAO.getBatchRiskCode(null);
		assertFalse(!CollectionUtils.isEmpty(batchRiskCodeList));
	}
	
	
	@Test
	public void testListBatchRiskCode() {
		BatchRiskCodeDAO batchRiskCodeDAO = (BatchRiskCodeDAO)context.getBean("batchRiskCodeDAO");
		BatchRiskCodeVO batchFxRateVO = new BatchRiskCodeVO();
		batchFxRateVO.setId(1);
		List<BatchRiskCodeVO> batchRiskCodeList = batchRiskCodeDAO.getBatchRiskCode(batchFxRateVO);
		assertTrue(CollectionUtils.isEmpty(batchRiskCodeList));
	}
	
	

}
