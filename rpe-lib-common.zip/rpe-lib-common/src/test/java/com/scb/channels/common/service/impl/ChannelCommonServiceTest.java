package com.scb.channels.common.service.impl;


import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.exception.MaskException;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.ChannelCommonService;
import com.scb.channels.common.vo.ChannelMaskPolicyVO;

public class ChannelCommonServiceTest{
	private static final Logger logger = LoggerFactory.getLogger(ChannelCommonServiceTest.class);
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}

	@Test
	public void getChannelMaskPolicyTest() throws MaskException {
		ChannelCommonService channelCommonService = (ChannelCommonService)context.getBean("channelCommonService");
		ClientVO clientVO= new ClientVO();
		clientVO.setChannel("KIOSK");
		clientVO.setCountry("NG");
		
		String categoryCode="payments";
		String typeCode="email";
		logger.info(":::::getChannelMaskPolicyTest() begins::::");
		List<ChannelMaskPolicyVO> channelPolicyList = channelCommonService.getChannelMaskPolicy(typeCode,categoryCode,clientVO);
		logger.info("channelPolicyList.size():==="+ channelPolicyList.size());
		assertNotNull(channelPolicyList);
		logger.info(":::::getChannelMaskPolicyTest() ends::::");
	}
	
	@Test
	public void getAllMaskPolicyTest() throws MaskException {
		ChannelCommonService channelCommonService = (ChannelCommonService)context.getBean("channelCommonService");
		String typeCode="Logger";
		List<ChannelMaskPolicyVO> channelPolicyList = channelCommonService.getAllMaskPolicy(typeCode);
		logger.info(":::::getAllMaskPolicyTest() begins::::");
		logger.info("channelPolicyList.size():==="+ channelPolicyList.size());
		assertNotNull(channelPolicyList);
		logger.info(":::::getAllMaskPolicyTest() ends::::");
	}
	
	//@Test
	public void getChannelMaskPolicyForFieldTest() throws MaskException {
		ChannelCommonService channelCommonService = (ChannelCommonService)context.getBean("channelCommonService");
		ClientVO clientVO= new ClientVO();
		clientVO.setChannel("KIOSK");
		clientVO.setCountry("NG");
		
		String categoryCode="payments";
		String typeCode="email";
		String fieldName="accountNumber";
		ChannelMaskPolicyVO channelMaskPolicyVO = channelCommonService.getChannelMaskPolicyForField(typeCode, categoryCode, clientVO, fieldName);
		logger.info(":::::getChannelMaskPolicyForFieldTest() begins::::");
		/*logger.info("channelMaskPolicyVO.getPattern():==="+ channelMaskPolicyVO.getPattern() );
		assertNotNull(channelMaskPolicyVO);
		logger.info(":::::getChannelMaskPolicyForFieldTest() ends::::");*/
	}
	
}