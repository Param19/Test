package com.scb.channels.common.dao.impl;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.common.dao.LoginSessionDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.LoginSessionVO;

public class LoginSessionDAOTest {

	private ApplicationContext context=null;
	static  LoginSessionVO loginSessionVO = null;
	
	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		if(loginSessionVO==null){
		loginSessionVO = new LoginSessionVO();
		loginSessionVO.setChannel("ADC");
		loginSessionVO.setCtryCd("KE");
		loginSessionVO.setSessionId("jfksdjfkdsjf");
		loginSessionVO.setDtUpd(DateUtils.getCurrentDate());
		loginSessionVO.setDtCreated(DateUtils.getCurrentDate());		
		loginSessionVO.setEnvironment("ADC");
		loginSessionVO.setUserId("12e4311111");
		loginSessionVO.setSystemType("mobile");
		}
	}

	
	@Ignore
	@Test
	public void testInsert() {
		LoginSessionDAO loginSessionDAO=  context.getBean("loginSessionDAO",LoginSessionDAO.class);
		loginSessionDAO.save(loginSessionVO);
	}
	
	
	@Ignore
	@Test 
	public void testDelete() {
		
		LoginSessionDAO loginSessionDAO=  context.getBean("loginSessionDAO",LoginSessionDAO.class);
		loginSessionDAO.delete(loginSessionVO);
	}

	@Ignore
	@
	Test
	public void testSearch(){
		LoginSessionDAO loginSessionDAO=  context.getBean("loginSessionDAO",LoginSessionDAO.class);
		LoginSessionVO loginSessionVO = loginSessionDAO.search("12e43", "KE", "ADC", "jfksdjfkdsjf");
		if (loginSessionVO != null) {
			long timeDiff = new Date().getMinutes() -loginSessionVO.getDtCreated().getMinutes();
			assertTrue(timeDiff<30);
		}
	}
}
