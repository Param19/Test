package com.scb.channels.common.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.BatchAccTxnService;
import com.scb.channels.common.vo.BatchAccTxnVO;

public class BatchAccTxnServiceTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	@Ignore
	@Test
	public void testListBatchAccTxnWithEmptyObj() {
		BatchAccTxnService batchAccTxnDAO = (BatchAccTxnService)context.getBean("batchAccTxnService");
		BatchAccTxnVO batchAccTxnVO = new BatchAccTxnVO();
		List<BatchAccTxnVO> batchAccTxnlist = batchAccTxnDAO.getBatchAccountTxn("00011711721");
		assertFalse(!CollectionUtils.isEmpty(batchAccTxnlist));
	}
	

	@Test
	public void testListBatchAccTxnWithNullObj() {
		BatchAccTxnService batchAccTxnDAO = (BatchAccTxnService)context.getBean("batchAccTxnService");
		List<BatchAccTxnVO> batchAccTxnlist = batchAccTxnDAO.getBatchAccountTxn(null);
		assertFalse(!CollectionUtils.isEmpty(batchAccTxnlist));
	}
	
	
	@Test
	public void testListBatchAccTxn() {
		BatchAccTxnService batchAccTxnDAO = (BatchAccTxnService)context.getBean("batchAccTxnService");
		BatchAccTxnVO batchAccTxnVO = new BatchAccTxnVO();
		batchAccTxnVO.setId(1);
		List<BatchAccTxnVO> batchAccTxnlist = batchAccTxnDAO.getBatchAccountTxn("0001171172");
		assertTrue(CollectionUtils.isEmpty(batchAccTxnlist));
	}
	
	

}
