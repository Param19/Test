package com.scb.channels.common.dao.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.dao.BatchAccTxnDAO;
import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.vo.BatchAccTxnVO;

public class BatchAccTxnDaoTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	//@Test
	public void testListBatchAccTxnWithEmptyObj() {
		BatchAccTxnDAO batchAccTxnDAO = (BatchAccTxnDAO)context.getBean("batchAccTxnDAO");
		
		List<BatchAccTxnVO> batchAccTxnlist = batchAccTxnDAO.getBatchAccountTxn("000117117223");
		assertFalse(!CollectionUtils.isEmpty(batchAccTxnlist));
	}
	

	//@Test
	public void testListBatchAccTxnWithNullObj() {
		BatchAccTxnDAO batchAccTxnDAO = (BatchAccTxnDAO)context.getBean("batchAccTxnDAO");
		List<BatchAccTxnVO> batchAccTxnlist = batchAccTxnDAO.getBatchAccountTxn(null);
		assertFalse(!CollectionUtils.isEmpty(batchAccTxnlist));
	}
	
	
	//@Test
	public void testListBatchAccTxn() {
		BatchAccTxnDAO batchAccTxnDAO = (BatchAccTxnDAO)context.getBean("batchAccTxnDAO");
		
		List<BatchAccTxnVO> batchAccTxnlist = batchAccTxnDAO.getBatchAccountTxn("0001171172");
		assertTrue(!CollectionUtils.isEmpty(batchAccTxnlist));
	}
	
	

}
