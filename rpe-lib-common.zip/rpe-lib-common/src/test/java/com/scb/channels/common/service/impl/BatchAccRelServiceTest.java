package com.scb.channels.common.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.util.CollectionUtils;

import com.scb.channels.common.helper.TestHelper;
import com.scb.channels.common.service.BatchAccRelService;
import com.scb.channels.common.vo.BatchAccRelVO;

public class BatchAccRelServiceTest {
	
	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
		assertNotNull(context);
	}
	
	@Test
	public void testListBatchAccBalWithNull() {
		BatchAccRelService batchAccRelService = (BatchAccRelService)context.getBean("batchAccRelService");
		List<BatchAccRelVO> batchList = batchAccRelService.getBatchAccountRel(null);
		assertFalse(!CollectionUtils.isEmpty(batchList));
	}
	
	@Test
	public void testListBatchAccBalWithEmptyObj() {
		BatchAccRelService batchAccRelService = (BatchAccRelService)context.getBean("batchAccRelService");
		BatchAccRelVO batchAccRelVO = new BatchAccRelVO();
		List<BatchAccRelVO> batchList = batchAccRelService.getBatchAccountRel(batchAccRelVO);
		assertFalse(!CollectionUtils.isEmpty(batchList));
	}
	
	@Test
	public void testListBatchAccBal() {
		BatchAccRelService batchAccRelService = (BatchAccRelService)context.getBean("batchAccRelService");
		BatchAccRelVO batchAccRelVO = new BatchAccRelVO();
		batchAccRelVO.setCustGroupId("000011453");
		List<BatchAccRelVO> batchList = batchAccRelService.getBatchAccountRel(batchAccRelVO);
		assertTrue(CollectionUtils.isEmpty(batchList));
	}

}
