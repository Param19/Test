package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.FTNarrationVO;

/**
 * The Interface FTNarrationDAO.
 */
public interface FTNarrationDAO {
 
	/**
	 * Gets the.
	 * @param bankViewVO the bank view vo
	 *
	 * @return the fT narration vo
	 */
	List<FTNarrationVO> get(String channel,String cntryCd);
}
