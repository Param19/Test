/**
 * 
 */
package com.scb.channels.common.dao.impl;

import java.util.List;


import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.vo.CustomerProfileVO;
import com.scb.channels.common.dao.CustomerProfileDAO;

/**
 * The Class CustomerProfileDAOImpl.
 *
 * @author 1411807
 */
public class CustomerProfileDAOImpl extends HibernateDaoSupport implements
		CustomerProfileDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustomerProfileDAO#getCustomerProfile(java.lang.String)
	 */
	
	public CustomerProfileVO getCustomerProfile(String username) {
		org.hibernate.Criteria criteria = getSession().createCriteria(CustomerProfileVO.class);
		criteria.add(Restrictions.eq("userId", username));
		List<CustomerProfileVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustomerProfileDAO#getCustomerProfileForRelationship(java.lang.String)
	 */
	
	public CustomerProfileVO getCustomerProfileForRelationship(String relno) {
		org.hibernate.Criteria criteria = getSession().createCriteria(CustomerProfileVO.class);
		criteria.add(Restrictions.eq("custId", relno));
		List<CustomerProfileVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustomerProfileDAO#getCustomerProfile(java.lang.String, java.lang.String, java.lang.String)
	 */
	public CustomerProfileVO getCustomerProfile(String CountryCode,
			String MobileNumber, String RelNum) {
		org.hibernate.Criteria criteria = getSession().createCriteria(CustomerProfileVO.class);
		criteria.add(Restrictions.eq("userId", MobileNumber));
		criteria.add(Restrictions.eq("custId", RelNum));
		List<CustomerProfileVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}

}
