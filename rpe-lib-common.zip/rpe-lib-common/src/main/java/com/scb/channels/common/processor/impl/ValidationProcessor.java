package com.scb.channels.common.processor.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.validation.MultiFieldValidator;
import com.scb.channels.common.validation.Validator;

/**
 * The Class ValidationProcessor.
 */
public class ValidationProcessor extends AbstractProcessor {

	/** The validator list. */
	private List<Validator> validatorList;
	
	/** The multi field validator list. */
	private List<MultiFieldValidator> multiFieldValidatorList;
	
	/** The bean. */
	private PayloadDTO bean;
	
	
	/**
	 * Perform validation;.
	 *
	 * @throws ValidatorException the validator exception
	 */
	private void performValidation() throws ValidatorException {
		if (CollectionUtils.isNotEmpty(validatorList)) {
			for (Validator v: validatorList) {
				v.setBean(bean);
				v.validate();
			}
		}
	}
	
	/**
	 * Perform multi-field validation;.
	 *
	 * @throws ValidatorException the validator exception
	 */
	private void performMultiFieldValidation() throws ValidatorException {
		if (CollectionUtils.isNotEmpty(multiFieldValidatorList)) {
			for (MultiFieldValidator v: multiFieldValidatorList) {
				v.setBean(bean);
				v.validate();
			}
		}
	}
	



	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) {
		try {
			this.bean=bean;
			performMultiFieldValidation();
			performValidation();
		} catch (ValidatorException e) {
			if (bean.getResponseVO() == null) {
				bean = CommonHelper.getResponseInstance(bean);
			}
			bean.getResponseVO().setStatus(ExceptionMessages._125.getCode());
			bean.getResponseVO().setStatusDesc(e.getMessage());
			bean.getResponseVO().setClientVO(bean.getRequestVO().getClientVO());
			bean.getResponseVO().setMessageVO(bean.getRequestVO().getMessageVO());
			bean.getResponseVO().setServiceVO(bean.getRequestVO().getServiceVO());
			bean.getResponseVO().setUser(bean.getRequestVO().getUser());
		}
		return bean; 
	}

	/**
	 * Gets the validator list.
	 *
	 * @return the validatorList
	 */
	public List<Validator> getValidatorList() {
		return validatorList;
	}

	/**
	 * Sets the validator list.
	 *
	 * @param validatorList the validatorList to set
	 */
	public void setValidatorList(List<Validator> validatorList) {
		this.validatorList = validatorList;
	}

	/**
	 * Gets the multi field validator list.
	 *
	 * @return the multiFieldValidatorList
	 */
	public List<MultiFieldValidator> getMultiFieldValidatorList() {
		return multiFieldValidatorList;
	}

	/**
	 * Sets the multi field validator list.
	 *
	 * @param multiFieldValidatorList the multiFieldValidatorList to set
	 */
	public void setMultiFieldValidatorList(
			List<MultiFieldValidator> multiFieldValidatorList) {
		this.multiFieldValidatorList = multiFieldValidatorList;
	}

	/**
	 * /**.
	 *
	 * @return the bean
	 */
	public PayloadDTO getBean() {
		return bean;
	}

	/**
	 * Sets the bean.
	 *
	 * @param bean the bean to set
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;
	}
	
	
}
