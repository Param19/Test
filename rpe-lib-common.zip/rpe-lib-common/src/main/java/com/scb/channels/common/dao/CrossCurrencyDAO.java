package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.CrossCurrencyVO;

/**
 * The Interface CrossCurrencyDAO.
 */
public interface CrossCurrencyDAO {

	/**
	 * Gets the cross currency list.
	 *
	 * @param channelCD the channel cd
	 * @param countyrCD the countyr cd
	 * @param statusCD the status cd
	 * @return the cross currency list
	 */
	List<CrossCurrencyVO> getCrossCurrencyList(String channelCD,String countyrCD,String statusCD);
	
	
	/**
	 * Gets the cross currency list.
	 *
	 * @param countyrCD the countyr cd
	 * @param statusCD the status cd
	 * @return the cross currency list
	 */
	List<CrossCurrencyVO> getCrossCurrencyList(String countyrCD,String statusCD);
		
}
