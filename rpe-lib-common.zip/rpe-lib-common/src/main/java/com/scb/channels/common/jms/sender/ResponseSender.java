package com.scb.channels.common.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Class ResponseSender.
 */
public class ResponseSender {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseSender.class);
	
    /** The jms template. */
    private JmsTemplate jmsTemplate;
   
    /**
     * Send.
     *
     * @param payloadDTO the payload dto
     * @param msgId the msg id
     */
    public void send( final PayloadDTO payloadDTO,final String msgId){
    	jmsTemplate.send(jmsTemplate.getDefaultDestination(), new MessageCreator() {
			
			public Message createMessage(Session session) throws JMSException {
				ObjectMessage  objectMessage= session.createObjectMessage();
				objectMessage.setObject(payloadDTO);	
				objectMessage.setJMSCorrelationID(msgId);
				return objectMessage;
			}
		});
    	LOGGER.info("Message sent {}", new Object[]{msgId});
    }

	/**
	 * Sets the jms template.
	 *
	 * @param jmsTemplate the new jms template
	 */
	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}
}
