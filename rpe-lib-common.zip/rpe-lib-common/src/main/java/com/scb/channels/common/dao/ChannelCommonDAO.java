/**
 * 
 */
package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.ChannelMaskPolicyVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.exception.DAOException;


/**
 * The Interface ChannelMasknDAO.
 *
 * @author 1382158
 */
public interface ChannelCommonDAO {
	
	/**
	 * Gets the channel mask policy.
	 *
	 * @param typeCode the type code
	 * @param categoryCode the category code
	 * @param clientVO the client vo
	 * @return the channel mask policy
	 * @throws DAOException the dAO exception
	 */
	public List<ChannelMaskPolicyVO> getChannelMaskPolicy (String typeCode,String categoryCode,ClientVO clientVO) throws DAOException;
	
	 /**
 	 * Gets the channel mask policy for field.
 	 *
 	 * @param typeCode the type code
 	 * @param categoryCode the category code
 	 * @param clientVO the client vo
 	 * @param fieldName the field name
 	 * @return the channel mask policy for field
 	 * @throws DAOException the dAO exception
 	 */
 	public ChannelMaskPolicyVO getChannelMaskPolicyForField(String typeCode, String categoryCode, ClientVO clientVO, String fieldName) throws DAOException;
	
	/**
	 * Gets the all mask policy.
	 *
	 * @param typeCode the type code
	 * @return the all mask policy
	 * @throws DAOException the dAO exception
	 */
	public List<ChannelMaskPolicyVO> getAllMaskPolicy (String typeCode) throws DAOException;
	
	
}
