package com.scb.channels.common.service.impl;

import java.util.List;

import com.scb.channels.common.dao.BatchAccTxnDAO;
import com.scb.channels.common.service.BatchAccTxnService;
import com.scb.channels.common.vo.BatchAccTxnVO;

/**
 * The Class BatchAccTxnServiceImpl.
 */
public class BatchAccTxnServiceImpl implements BatchAccTxnService {
	
	/** The batch acc txn dao. */
	private BatchAccTxnDAO batchAccTxnDAO;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchAccTxnService#getBatchAccountTxn(com.scb.channels.common.vo.BatchAccTxnVO)
	 */
	public List<BatchAccTxnVO> getBatchAccountTxn(String accNo) {
		return batchAccTxnDAO.getBatchAccountTxn(accNo);
	}
	

	/**
	 * Gets the batch acc txn dao.
	 *
	 * @return the batch acc txn dao
	 */
	public BatchAccTxnDAO getBatchAccTxnDAO() {
		return batchAccTxnDAO;
	}

	/**
	 * Sets the batch acc txn dao.
	 *
	 * @param batchAccTxnDAO the new batch acc txn dao
	 */
	public void setBatchAccTxnDAO(BatchAccTxnDAO batchAccTxnDAO) {
		this.batchAccTxnDAO = batchAccTxnDAO;
	}

}
