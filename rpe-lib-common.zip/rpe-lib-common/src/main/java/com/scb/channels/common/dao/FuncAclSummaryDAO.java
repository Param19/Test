package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.FuncAclSummaryVO;

/**
 * The Interface ReferenceDAO.
 */
public interface FuncAclSummaryDAO {
 
	

	/**
	 * Gets the FuncAclSummaryVO.
	 *
	 * @return the funcAclSummary vo
	 */
	List<FuncAclSummaryVO> get();
	
	
}
