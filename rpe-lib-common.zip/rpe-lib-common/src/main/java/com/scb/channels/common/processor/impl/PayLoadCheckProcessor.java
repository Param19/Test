/**
 * 
 */
package com.scb.channels.common.processor.impl;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class PayLoadCheckProcessor.
 *
 * @author 1411807
 */
public class PayLoadCheckProcessor extends AbstractProcessor  {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */


	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		BaseVO responseVO = null;
		if (bean == null || bean.getRequestVO() == null) {
			PayloadDTO beanNew = new PayloadDTO();
			responseVO = new BaseVO();
			responseVO.setStatusDesc(ExceptionMessages._100.getMessage());
			responseVO.setStatus(ExceptionMessages._100.getCode());
			beanNew.setResponseVO(responseVO);
			return beanNew;
		} 
		return bean;
	}
	
	

}
