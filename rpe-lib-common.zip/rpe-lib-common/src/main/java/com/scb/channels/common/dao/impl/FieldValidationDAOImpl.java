package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.dao.FieldValidationDAO;
import com.scb.channels.common.vo.FieldValidationVO;



/**
 * The Class FieldValidationDAOImpl.
 */
public class FieldValidationDAOImpl extends HibernateDaoSupport implements FieldValidationDAO {

	
	public List<FieldValidationVO> getfieldValidationList(String module, String status, String baseObject, ClientVO clientVO) throws DAOException {
		
		
		Criteria criteria = getSession().createCriteria(FieldValidationVO.class)
				.add(Restrictions.eq("countryCode",clientVO.getCountry()))
				.add(Restrictions.eq("channelId",clientVO.getChannel())) 
				.add(Restrictions.eq("module", module))
				.add(Restrictions.eq("baseObject", baseObject))
				.add(Restrictions.eq("status", status));
                
        return criteria.list();

		
	}

	
}
