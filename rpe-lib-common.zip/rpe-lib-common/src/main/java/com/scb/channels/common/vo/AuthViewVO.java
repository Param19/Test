/*
 * 
 */
package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class AuthViewVO.
 */
public class AuthViewVO implements Serializable {

	
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7593878379039284114L;
	
	/** The id. */
	private Integer id; 
	
	/** The levels. */
	private Integer levels;
	
	/** The login invalid count. */
	private Integer loginInvalidCount;
	
	/** The login success count. */
	private Integer loginSuccessCount; 
	
	/** The version. */
	private Integer version;
	
	/** The u role. */
	private Integer uRole;
	
	/** The is rereg. */
	private Character isRereg;
	
	/** The is letter gen. */
	private Character isLetterGen;
	
	/** The is act. */
	private Character isAct;
	
	/** The is email gen. */
	private Character isEmailGen;
	
	/** The oeprating account currency. */
	private Character oepratingAccountCurrency;
	
	/** The is email alert enabled. */
	private Character isEmailAlertEnabled;
	
	/** The is service enabled. */
	private Character isServiceEnabled;
	
	/** The is handset lost. */
	private Character isHandsetLost;	
	
	/** The ctry cd. */
	private String ctryCd;   
	
	/** The user id. */
	private String userId;   
	
	/** The user pswd. */
	private String userPswd;  
	
	/** The name. */
	private String name;     
	
	/** The system type. */
	private String systemType;
	
	/** The status cd. */
	private String statusCd; 	
	
	/** The created by. */
	private String createdBy;	    
	
	/** The upd by. */
	private String updBy; 
	
	/** The is logged in. */
	private String isLoggedIn;   
	
	/** The cust group id. */
	private String custGroupId;   
	
	/** The cust id type. */
	private String custIdType;  
	
	/** The cust id. */
	private String custId;     
	
	/** The cust name1. */
	private String custName1;
	
	/** The cust name2. */
	private String custName2; 	
	
	/** The nickname. */
	private String nickname;	    
	
	/** The email. */
	private String email; 
	
	/** The mobil phone. */
	private String mobilPhone;   
	
	/** The arm cd. */
	private String armCd;   
	
	/** The reg by. */
	private String regBy;  
	
	/** The cust access key. */
	private String custAccessKey;     
	
	/** The reg mode. */
	private String regMode;
	
	/** The actv type. */
	private String actvType; 	
	
	/** The notif type. */
	private String notifType;	    
	
	/** The migrate flag. */
	private String migrateFlag; 
	
	/** The operating account no. */
	private String operatingAccountNo;   
	
	/** The email generation type. */
	private String emailGenerationType;   
	
	/** The mobile operator code. */
	private String mobileOperatorCode;  
	
	/** The role cd. */
	private String roleCd;     
	
	/** The r name. */
	private String rName;
	
	/** The u func. */
	private String uFunc; 	
	
	/** The func cd. */
	private String funcCd;	    
	
	/** The name. */
	private String fName; 
	
	/** The type. */
	private String type;  
	
	/** The is secure. */
	private String isSecure;     
	
	/** The paren func cd. */
	private String parenFuncCd;
	
	/** The new window. */
	private String newWindow; 	
	
	/** The lang cd. */
	private String langCd;
	
	/** The dt first login. */
	private Date dtFirstLogin;
	
	/** The dt last login. */
	private Date dtLastLogin;
	
	/** The dt last pswd chg. */
	private Date dtLastPswdChg;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The dt reg. */
	private Date dtReg;
	
	/** The dt act. */
	private Date dtAct;
	
	/** The dt serv start. */
	private Date dtServStart;
	
	/** The dt serv end. */
	private Date dtServEnd;
	
	/** The dt suspend start. */
	private Date dtSuspendStart;
	
	/** The dt suspend end. */
	private Date dtSuspendEnd;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The dt pin mailer exp. */
	private Date dtPinMailerExp;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the levels.
	 *
	 * @return the levels
	 */
	public Integer getLevels() {
		return levels;
	}
	
	/**
	 * Sets the levels.
	 *
	 * @param levels the new levels
	 */
	public void setLevels(Integer levels) {
		this.levels = levels;
	}
	
	/**
	 * Gets the login invalid count.
	 *
	 * @return the login invalid count
	 */
	public Integer getLoginInvalidCount() {
		return loginInvalidCount;
	}
	
	/**
	 * Sets the login invalid count.
	 *
	 * @param loginInvalidCount the new login invalid count
	 */
	public void setLoginInvalidCount(Integer loginInvalidCount) {
		this.loginInvalidCount = loginInvalidCount;
	}
	
	/**
	 * Gets the login success count.
	 *
	 * @return the login success count
	 */
	public Integer getLoginSuccessCount() {
		return loginSuccessCount;
	}
	
	/**
	 * Sets the login success count.
	 *
	 * @param loginSuccessCount the new login success count
	 */
	public void setLoginSuccessCount(Integer loginSuccessCount) {
		this.loginSuccessCount = loginSuccessCount;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the u role.
	 *
	 * @return the u role
	 */
	public Integer getuRole() {
		return uRole;
	}
	
	/**
	 * Sets the u role.
	 *
	 * @param uRole the new u role
	 */
	public void setuRole(Integer uRole) {
		this.uRole = uRole;
	}
	
	/**
	 * Gets the checks if is rereg.
	 *
	 * @return the checks if is rereg
	 */
	public Character getIsRereg() {
		return isRereg;
	}
	
	/**
	 * Sets the checks if is rereg.
	 *
	 * @param isRereg the new checks if is rereg
	 */
	public void setIsRereg(Character isRereg) {
		this.isRereg = isRereg;
	}
	
	/**
	 * Gets the checks if is letter gen.
	 *
	 * @return the checks if is letter gen
	 */
	public Character getIsLetterGen() {
		return isLetterGen;
	}
	
	/**
	 * Sets the checks if is letter gen.
	 *
	 * @param isLetterGen the new checks if is letter gen
	 */
	public void setIsLetterGen(Character isLetterGen) {
		this.isLetterGen = isLetterGen;
	}
	
	/**
	 * Gets the checks if is act.
	 *
	 * @return the checks if is act
	 */
	public Character getIsAct() {
		return isAct;
	}
	
	/**
	 * Sets the checks if is act.
	 *
	 * @param isAct the new checks if is act
	 */
	public void setIsAct(Character isAct) {
		this.isAct = isAct;
	}
	
	/**
	 * Gets the checks if is email gen.
	 *
	 * @return the checks if is email gen
	 */
	public Character getIsEmailGen() {
		return isEmailGen;
	}
	
	/**
	 * Sets the checks if is email gen.
	 *
	 * @param isEmailGen the new checks if is email gen
	 */
	public void setIsEmailGen(Character isEmailGen) {
		this.isEmailGen = isEmailGen;
	}
	
	/**
	 * Gets the oeprating account currency.
	 *
	 * @return the oeprating account currency
	 */
	public Character getOepratingAccountCurrency() {
		return oepratingAccountCurrency;
	}
	
	/**
	 * Sets the oeprating account currency.
	 *
	 * @param oepratingAccountCurrency the new oeprating account currency
	 */
	public void setOepratingAccountCurrency(Character oepratingAccountCurrency) {
		this.oepratingAccountCurrency = oepratingAccountCurrency;
	}
	
	/**
	 * Gets the checks if is email alert enabled.
	 *
	 * @return the checks if is email alert enabled
	 */
	public Character getIsEmailAlertEnabled() {
		return isEmailAlertEnabled;
	}
	
	/**
	 * Sets the checks if is email alert enabled.
	 *
	 * @param isEmailAlertEnabled the new checks if is email alert enabled
	 */
	public void setIsEmailAlertEnabled(Character isEmailAlertEnabled) {
		this.isEmailAlertEnabled = isEmailAlertEnabled;
	}
	
	/**
	 * Gets the checks if is service enabled.
	 *
	 * @return the checks if is service enabled
	 */
	public Character getIsServiceEnabled() {
		return isServiceEnabled;
	}
	
	/**
	 * Sets the checks if is service enabled.
	 *
	 * @param isServiceEnabled the new checks if is service enabled
	 */
	public void setIsServiceEnabled(Character isServiceEnabled) {
		this.isServiceEnabled = isServiceEnabled;
	}
	
	/**
	 * Gets the checks if is handset lost.
	 *
	 * @return the checks if is handset lost
	 */
	public Character getIsHandsetLost() {
		return isHandsetLost;
	}
	
	/**
	 * Sets the checks if is handset lost.
	 *
	 * @param isHandsetLost the new checks if is handset lost
	 */
	public void setIsHandsetLost(Character isHandsetLost) {
		this.isHandsetLost = isHandsetLost;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the user pswd.
	 *
	 * @return the user pswd
	 */
	public String getUserPswd() {
		return userPswd;
	}
	
	/**
	 * Sets the user pswd.
	 *
	 * @param userPswd the new user pswd
	 */
	public void setUserPswd(String userPswd) {
		this.userPswd = userPswd;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the system type.
	 *
	 * @return the system type
	 */
	public String getSystemType() {
		return systemType;
	}
	
	/**
	 * Sets the system type.
	 *
	 * @param systemType the new system type
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the checks if is logged in.
	 *
	 * @return the checks if is logged in
	 */
	public String getIsLoggedIn() {
		return isLoggedIn;
	}
	
	/**
	 * Sets the checks if is logged in.
	 *
	 * @param isLoggedIn the new checks if is logged in
	 */
	public void setIsLoggedIn(String isLoggedIn) {
		this.isLoggedIn = isLoggedIn;
	}
	
	/**
	 * Gets the cust group id.
	 *
	 * @return the cust group id
	 */
	public String getCustGroupId() {
		return custGroupId;
	}
	
	/**
	 * Sets the cust group id.
	 *
	 * @param custGroupId the new cust group id
	 */
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	
	/**
	 * Gets the cust id type.
	 *
	 * @return the cust id type
	 */
	public String getCustIdType() {
		return custIdType;
	}
	
	/**
	 * Sets the cust id type.
	 *
	 * @param custIdType the new cust id type
	 */
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public String getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	/**
	 * Gets the cust name1.
	 *
	 * @return the cust name1
	 */
	public String getCustName1() {
		return custName1;
	}
	
	/**
	 * Sets the cust name1.
	 *
	 * @param custName1 the new cust name1
	 */
	public void setCustName1(String custName1) {
		this.custName1 = custName1;
	}
	
	/**
	 * Gets the cust name2.
	 *
	 * @return the cust name2
	 */
	public String getCustName2() {
		return custName2;
	}
	
	/**
	 * Sets the cust name2.
	 *
	 * @param custName2 the new cust name2
	 */
	public void setCustName2(String custName2) {
		this.custName2 = custName2;
	}
	
	/**
	 * Gets the nickname.
	 *
	 * @return the nickname
	 */
	public String getNickname() {
		return nickname;
	}
	
	/**
	 * Sets the nickname.
	 *
	 * @param nickname the new nickname
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Gets the mobil phone.
	 *
	 * @return the mobil phone
	 */
	public String getMobilPhone() {
		return mobilPhone;
	}
	
	/**
	 * Sets the mobil phone.
	 *
	 * @param mobilPhone the new mobil phone
	 */
	public void setMobilPhone(String mobilPhone) {
		this.mobilPhone = mobilPhone;
	}
	
	/**
	 * Gets the arm cd.
	 *
	 * @return the arm cd
	 */
	public String getArmCd() {
		return armCd;
	}
	
	/**
	 * Sets the arm cd.
	 *
	 * @param armCd the new arm cd
	 */
	public void setArmCd(String armCd) {
		this.armCd = armCd;
	}
	
	/**
	 * Gets the reg by.
	 *
	 * @return the reg by
	 */
	public String getRegBy() {
		return regBy;
	}
	
	/**
	 * Sets the reg by.
	 *
	 * @param regBy the new reg by
	 */
	public void setRegBy(String regBy) {
		this.regBy = regBy;
	}
	
	/**
	 * Gets the cust access key.
	 *
	 * @return the cust access key
	 */
	public String getCustAccessKey() {
		return custAccessKey;
	}
	
	/**
	 * Sets the cust access key.
	 *
	 * @param custAccessKey the new cust access key
	 */
	public void setCustAccessKey(String custAccessKey) {
		this.custAccessKey = custAccessKey;
	}
	
	/**
	 * Gets the reg mode.
	 *
	 * @return the reg mode
	 */
	public String getRegMode() {
		return regMode;
	}
	
	/**
	 * Sets the reg mode.
	 *
	 * @param regMode the new reg mode
	 */
	public void setRegMode(String regMode) {
		this.regMode = regMode;
	}
	
	/**
	 * Gets the actv type.
	 *
	 * @return the actv type
	 */
	public String getActvType() {
		return actvType;
	}
	
	/**
	 * Sets the actv type.
	 *
	 * @param actvType the new actv type
	 */
	public void setActvType(String actvType) {
		this.actvType = actvType;
	}
	
	/**
	 * Gets the notif type.
	 *
	 * @return the notif type
	 */
	public String getNotifType() {
		return notifType;
	}
	
	/**
	 * Sets the notif type.
	 *
	 * @param notifType the new notif type
	 */
	public void setNotifType(String notifType) {
		this.notifType = notifType;
	}
	
	/**
	 * Gets the migrate flag.
	 *
	 * @return the migrate flag
	 */
	public String getMigrateFlag() {
		return migrateFlag;
	}
	
	/**
	 * Sets the migrate flag.
	 *
	 * @param migrateFlag the new migrate flag
	 */
	public void setMigrateFlag(String migrateFlag) {
		this.migrateFlag = migrateFlag;
	}
	
	/**
	 * Gets the operating account no.
	 *
	 * @return the operating account no
	 */
	public String getOperatingAccountNo() {
		return operatingAccountNo;
	}
	
	/**
	 * Sets the operating account no.
	 *
	 * @param operatingAccountNo the new operating account no
	 */
	public void setOperatingAccountNo(String operatingAccountNo) {
		this.operatingAccountNo = operatingAccountNo;
	}
	
	/**
	 * Gets the email generation type.
	 *
	 * @return the email generation type
	 */
	public String getEmailGenerationType() {
		return emailGenerationType;
	}
	
	/**
	 * Sets the email generation type.
	 *
	 * @param emailGenerationType the new email generation type
	 */
	public void setEmailGenerationType(String emailGenerationType) {
		this.emailGenerationType = emailGenerationType;
	}
	
	/**
	 * Gets the mobile operator code.
	 *
	 * @return the mobile operator code
	 */
	public String getMobileOperatorCode() {
		return mobileOperatorCode;
	}
	
	/**
	 * Sets the mobile operator code.
	 *
	 * @param mobileOperatorCode the new mobile operator code
	 */
	public void setMobileOperatorCode(String mobileOperatorCode) {
		this.mobileOperatorCode = mobileOperatorCode;
	}
	
	/**
	 * Gets the role cd.
	 *
	 * @return the role cd
	 */
	public String getRoleCd() {
		return roleCd;
	}
	
	/**
	 * Sets the role cd.
	 *
	 * @param roleCd the new role cd
	 */
	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}
	
	/**
	 * Gets the r name.
	 *
	 * @return the r name
	 */
	public String getrName() {
		return rName;
	}
	
	/**
	 * Sets the r name.
	 *
	 * @param rName the new r name
	 */
	public void setrName(String rName) {
		this.rName = rName;
	}
	
	/**
	 * Gets the u func.
	 *
	 * @return the u func
	 */
	public String getuFunc() {
		return uFunc;
	}
	
	/**
	 * Sets the u func.
	 *
	 * @param uFunc the new u func
	 */
	public void setuFunc(String uFunc) {
		this.uFunc = uFunc;
	}
	
	/**
	 * Gets the func cd.
	 *
	 * @return the func cd
	 */
	public String getFuncCd() {
		return funcCd;
	}
	
	/**
	 * Sets the func cd.
	 *
	 * @param funcCd the new func cd
	 */
	public void setFuncCd(String funcCd) {
		this.funcCd = funcCd;
	}
	
	/**
	 * Gets the f name.
	 *
	 * @return the f name
	 */
	public String getfName() {
		return fName;
	}
	
	/**
	 * Sets the f name.
	 *
	 * @param fName the new f name
	 */
	public void setfName(String fName) {
		this.fName = fName;
	}
	
	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * Gets the checks if is secure.
	 *
	 * @return the checks if is secure
	 */
	public String getIsSecure() {
		return isSecure;
	}
	
	/**
	 * Sets the checks if is secure.
	 *
	 * @param isSecure the new checks if is secure
	 */
	public void setIsSecure(String isSecure) {
		this.isSecure = isSecure;
	}
	
	/**
	 * Gets the paren func cd.
	 *
	 * @return the paren func cd
	 */
	public String getParenFuncCd() {
		return parenFuncCd;
	}
	
	/**
	 * Sets the paren func cd.
	 *
	 * @param parenFuncCd the new paren func cd
	 */
	public void setParenFuncCd(String parenFuncCd) {
		this.parenFuncCd = parenFuncCd;
	}
	
	/**
	 * Gets the new window.
	 *
	 * @return the new window
	 */
	public String getNewWindow() {
		return newWindow;
	}
	
	/**
	 * Sets the new window.
	 *
	 * @param newWindow the new new window
	 */
	public void setNewWindow(String newWindow) {
		this.newWindow = newWindow;
	}
	
	/**
	 * Gets the lang cd.
	 *
	 * @return the lang cd
	 */
	public String getLangCd() {
		return langCd;
	}
	
	/**
	 * Sets the lang cd.
	 *
	 * @param langCd the new lang cd
	 */
	public void setLangCd(String langCd) {
		this.langCd = langCd;
	}
	
	/**
	 * Gets the dt first login.
	 *
	 * @return the dt first login
	 */
	public Date getDtFirstLogin() {
		return dtFirstLogin;
	}
	
	/**
	 * Sets the dt first login.
	 *
	 * @param dtFirstLogin the new dt first login
	 */
	public void setDtFirstLogin(Date dtFirstLogin) {
		this.dtFirstLogin = dtFirstLogin;
	}
	
	/**
	 * Gets the dt last login.
	 *
	 * @return the dt last login
	 */
	public Date getDtLastLogin() {
		return dtLastLogin;
	}
	
	/**
	 * Sets the dt last login.
	 *
	 * @param dtLastLogin the new dt last login
	 */
	public void setDtLastLogin(Date dtLastLogin) {
		this.dtLastLogin = dtLastLogin;
	}
	
	/**
	 * Gets the dt last pswd chg.
	 *
	 * @return the dt last pswd chg
	 */
	public Date getDtLastPswdChg() {
		return dtLastPswdChg;
	}
	
	/**
	 * Sets the dt last pswd chg.
	 *
	 * @param dtLastPswdChg the new dt last pswd chg
	 */
	public void setDtLastPswdChg(Date dtLastPswdChg) {
		this.dtLastPswdChg = dtLastPswdChg;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the dt reg.
	 *
	 * @return the dt reg
	 */
	public Date getDtReg() {
		return dtReg;
	}
	
	/**
	 * Sets the dt reg.
	 *
	 * @param dtReg the new dt reg
	 */
	public void setDtReg(Date dtReg) {
		this.dtReg = dtReg;
	}
	
	/**
	 * Gets the dt act.
	 *
	 * @return the dt act
	 */
	public Date getDtAct() {
		return dtAct;
	}
	
	/**
	 * Sets the dt act.
	 *
	 * @param dtAct the new dt act
	 */
	public void setDtAct(Date dtAct) {
		this.dtAct = dtAct;
	}
	
	/**
	 * Gets the dt serv start.
	 *
	 * @return the dt serv start
	 */
	public Date getDtServStart() {
		return dtServStart;
	}
	
	/**
	 * Sets the dt serv start.
	 *
	 * @param dtServStart the new dt serv start
	 */
	public void setDtServStart(Date dtServStart) {
		this.dtServStart = dtServStart;
	}
	
	/**
	 * Gets the dt serv end.
	 *
	 * @return the dt serv end
	 */
	public Date getDtServEnd() {
		return dtServEnd;
	}
	
	/**
	 * Sets the dt serv end.
	 *
	 * @param dtServEnd the new dt serv end
	 */
	public void setDtServEnd(Date dtServEnd) {
		this.dtServEnd = dtServEnd;
	}
	
	/**
	 * Gets the dt suspend start.
	 *
	 * @return the dt suspend start
	 */
	public Date getDtSuspendStart() {
		return dtSuspendStart;
	}
	
	/**
	 * Sets the dt suspend start.
	 *
	 * @param dtSuspendStart the new dt suspend start
	 */
	public void setDtSuspendStart(Date dtSuspendStart) {
		this.dtSuspendStart = dtSuspendStart;
	}
	
	/**
	 * Gets the dt suspend end.
	 *
	 * @return the dt suspend end
	 */
	public Date getDtSuspendEnd() {
		return dtSuspendEnd;
	}
	
	/**
	 * Sets the dt suspend end.
	 *
	 * @param dtSuspendEnd the new dt suspend end
	 */
	public void setDtSuspendEnd(Date dtSuspendEnd) {
		this.dtSuspendEnd = dtSuspendEnd;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the dt pin mailer exp.
	 *
	 * @return the dt pin mailer exp
	 */
	public Date getDtPinMailerExp() {
		return dtPinMailerExp;
	}
	
	/**
	 * Sets the dt pin mailer exp.
	 *
	 * @param dtPinMailerExp the new dt pin mailer exp
	 */
	public void setDtPinMailerExp(Date dtPinMailerExp) {
		this.dtPinMailerExp = dtPinMailerExp;
	}
	
	
	
	
	


}
