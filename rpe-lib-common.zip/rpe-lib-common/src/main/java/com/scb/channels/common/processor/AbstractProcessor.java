/**
 * 
 */
package com.scb.channels.common.processor;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.filters.PostFilter;
import com.scb.channels.common.filters.PreFilter;

/**
 * The Class AbstractProcessor.
 *
 * @author 1411807
 */
public abstract class AbstractProcessor implements Processor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractProcessor.class);
	
	/** The pre filter. */
	private List<PreFilter> preFilter;
	
	/** The post filter. */
	private List<PostFilter> postFilter;
	
	/**
	 * Do tasks.
	 *
	 * @param bean the bean
	 * @return the payload dto
	 * @throws BusinessException the business exception
	 */
	protected abstract PayloadDTO doTasks(PayloadDTO bean) throws BusinessException;
	
	/**
	 * Do pre filter.
	 * 
	 * @param bean
	 *            the bean
	 * @throws FilterException
	 *             the filter exception
	 * @see com.scb.channels.common.processor.Processor#doPreFilter(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void doPreFilter(PayloadDTO bean) throws FilterException {
		if (CollectionUtils.isNotEmpty(preFilter)) {
			for (PreFilter filter: preFilter) {
				filter.filter(bean);
			}
		}
		
	}

	/**
	 * Do post filter.
	 * 
	 * @param bean
	 *            the bean
	 * @throws FilterException
	 *             the filter exception
	 * @see com.scb.channels.common.processor.Processor#doPostFilter(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void doPostFilter(PayloadDTO bean) throws FilterException {
		if (CollectionUtils.isNotEmpty(postFilter)) {
			for (PostFilter filter: postFilter) {
				filter.filter(bean);
			}
		}
		
	}
	
	
	/**
	 * Process.
	 * 
	 * @param bean
	 *            the bean
	 * @return the payload dto
	 * @throws FilterException
	 *             the filter exception
	 * @throws BusinessException
	 *             the business exception
	 * @see com.scb.channels.common.processor.Processor#process(com.scb.channels.common.vo.PayloadDTO)
	 */
	public PayloadDTO process(PayloadDTO bean) throws FilterException {
		try {
			doPreFilter(bean);
			PayloadDTO resultBean = doTasks(bean);
			doPostFilter(resultBean);
			return resultBean;
		} catch(FilterException e) {
			LOGGER.error(e.getMessage());
			throw e;
		}
		catch (Exception e) {
			LOGGER.error(e.getMessage());
			//throw new BusinessException(e, bean);
		}
		return bean; 
	}
	
	/**
	 * Gets the default host empty response.
	 * 
	 * @return the default host empty response
	 */
	public PayloadDTO getDefaultHostEmptyResponse() {
		PayloadDTO newBean = new PayloadDTO();
		BaseVO responseVO = new BaseVO();
		responseVO.setStatusDesc(ExceptionMessages._107.getMessage());
		responseVO.setStatus(ExceptionMessages._107.getCode());
		newBean.setResponseVO(responseVO);
		return newBean;
	}

	/**
	 * Sets the pre filter.
	 *
	 * @param preFilter the preFilter to set
	 */
	public void setPreFilter(List<PreFilter> preFilter) {
		this.preFilter = preFilter;
	}

	/**
	 * Sets the post filter.
	 *
	 * @param postFilter the postFilter to set
	 */
	public void setPostFilter(List<PostFilter> postFilter) {
		this.postFilter = postFilter;
	}

}
