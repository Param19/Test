/**
 * 
 */
package com.scb.channels.common.dao;

import java.util.List;
import java.util.Map;

import com.scb.channels.common.vo.LimitCriteriaVO;
import com.scb.channels.common.vo.OverallLimitVO;
import com.scb.channels.common.vo.TransactionLimitVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface LimitDAO.
 *
 * @author 1411807
 */
public interface LimitDAO {
	
	/**
	 * Gets the overall limits.
	 *
	 * @param custId the cust id
	 * @param country the country
	 * @param channelId the channel id
	 * @return the overall limits
	 */
	List<OverallLimitVO> getOverallLimits(String custId, String country, String channelId);

	/**
	 * Gets the transaction limits.
	 *
	 * @param custId the cust id
	 * @param country the country
	 * @param channelId the channel id
	 * @param txnType the txn type
	 * @param srcCUR the src cur
	 * @param destCUR the dest cur
	 * @return the transaction limits
	 */
	List<TransactionLimitVO> getTransactionLimits(String custId, String country, String channelId, String txnType, String srcCUR, String destCUR);
	
	/**
	 * Gets the customer limits.
	 *
	 * @param custId the cust id
	 * @param channelId the channel id
	 * @param limitSegmentCode the limit segment code
	 * @param txnType the txn type
	 * @return the customer limits
	 */
	Map<String, Map<String, Double>>  getCustomerLimits(String custId, String channelId, String limitSegmentCode, String txnType);
	
	/**
	 * Gets the country limits.
	 *
	 * @param custId the cust id
	 * @param channelId the channel id
	 * @param limitSegmentCode the limit segment code
	 * @param txnType the txn type
	 * @return the customer limits
	 */
	Map<String, Map<String, Double>>  getCountryLimits(String channelId, String limitSegmentCode, String txnType);
	
	Map<String, Map<String, Double>>  getMaximumLimits(String channelId, String limitSegmentCode);
	
	
	/**
	 * Gets the criteria.
	 *
	 * @param cntryId the cntry id
	 * @param retailSegmentCode the retail segment code
	 * @param resident the resident
	 * @param staffFlag the staff flag
	 * @param salaryAC the salary ac
	 * @return the criteria
	 */
	LimitCriteriaVO getCriteria(String cntryId, String retailSegmentCode, String resident, String staffFlag, String salaryAC);
	
	
}
