package com.scb.channels.common.processor.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.SessionService;
import com.scb.channels.common.vo.ReferenceVO;

public class SessionCheckProcessor extends AbstractProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(SessionCheckProcessor.class);
	
	private SessionService sessionService;
	
	private ReferenceService referenceService;
	
	private Boolean enableSessionValidation = true;
	
	public void init() {
		try {
			ReferenceVO referenceVO = new ReferenceVO();
			referenceVO.setRefCode(CommonConstants.SESSION_VALIDATION);
			ReferenceVO referenceVONew = referenceService.getReference(referenceVO);
			if (referenceVONew != null) {
				enableSessionValidation = Boolean.valueOf(StringUtils.defaultIfEmpty(referenceVONew.getRefValue(), CommonConstants.TRUE));
			}
		} catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		UserVO user = bean.getRequestVO().getUser();
		ClientVO clientVO = bean.getRequestVO().getClientVO();
		if (enableSessionValidation) {
			if (!sessionService.isValidSession(user.getUserId(), user.getCountry(), 
					clientVO.getChannel(), clientVO.getScbSessionId())) {
				bean = CommonHelper.getResponseInstance(bean);
				bean.getResponseVO().setStatus(ExceptionMessages._111.getCode());
				bean.getResponseVO().setStatusDesc(ExceptionMessages._111.getMessage());
			}
		}
		return bean;
	}


	/**
	 * @param sessionService the sessionService to set
	 */
	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}


	/**
	 * @param referenceService the referenceService to set
	 */
	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	
}
