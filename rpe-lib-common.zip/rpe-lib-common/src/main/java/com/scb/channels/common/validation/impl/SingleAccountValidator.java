/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.validation.MultiFieldValidator;

/**
 * The Class SingleAccountValidator.
 *
 * @author 1464143 This class used to check the validation for Account Number
 */
public class SingleAccountValidator implements MultiFieldValidator {

	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private List<String> property;
	
	/** The min length. */
	private int minLength = CommonConstants.SIX;
	
	/** The max length. */
	private int maxLength = CommonConstants.TEN;
	
	/** The min amount. */
	private Double minAmount = 1.0;
	

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		
		this.property = property;
	}

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		String fromAcc = null;
		boolean fromAccFlag = false;
		Double amount = null;
		try {
			fromAcc = (String) PropertyUtils.getProperty(bean, property.get(0));
			amount = (Double)PropertyUtils.getProperty(bean, property.get(1));
		} catch (Exception e) {

			throw new ValidatorException(
					"Invalid Account or Amount field present");
		}

		fromAccFlag = StringUtils.isBlank(fromAcc)|| StringUtils.isEmpty(fromAcc)|| !StringUtils.isNumeric(fromAcc)	
							|| checkAccountLength(fromAcc, minLength, maxLength) ;

		if (fromAccFlag) {
			throw new ValidatorException("Account number validation fails..");
		}
		checkMinAccount(amount);
	}

	/**
	 * Check account length.
	 *
	 * @param accNmbr the acc nmbr
	 * @param minLength the min length
	 * @param maxLength the max length
	 * @return true, if successful
	 */
	public boolean checkAccountLength(String accNmbr, Integer minLength, Integer maxLength) {
		boolean accFlag = false;
		if (accNmbr.length() < minLength || accNmbr.length() > maxLength){
			accFlag = true;
		}
		return accFlag;
	}

	/**
	 * Check same account.
	 *
	 * @param fromAccNmbr the from acc nmbr
	 * @param toAccNmbr the to acc nmbr
	 * @return true, if successful
	 */
	public boolean checkSameAccount(String fromAccNmbr, String toAccNmbr) {
		boolean accFlag = false;
		if (fromAccNmbr.equalsIgnoreCase(toAccNmbr)){
			accFlag = true;
		}
		return accFlag;
	}

	/**
	 * Check min account.
	 *
	 * @param amount the amount
	 * @throws ValidatorException the validator exception
	 */
	public void checkMinAccount(Double amount) throws ValidatorException {
		if (amount < minAmount){
			throw new ValidatorException("Amount is less than min amount allowed : " + minAmount);
		}
	}
	
	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean =  bean;
		
	}

	/**
	 * Sets the max length.
	 *
	 * @param maxLength the maxLength to set
	 */
	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	/**
	 * Sets the min length.
	 *
	 * @param minLength the minLength to set
	 */
	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}

	/**
	 * @param minAmount the minAmount to set
	 */
	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}
	
}
