package com.scb.channels.common.vo;

import java.io.Serializable;

/**
 * The Class BankViewVO.
 */
public class BankViewVO implements Serializable {

	
	
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8221846066210631727L;

	/** The id. */
	private Integer id; 
	
	/** The bank cd. */
	private String bankCd;   
	
	/** The bank name. */
	private String bankName;   
	
	/** The ctry cd. */
	private String ctryCd;  
	
	/** The status cd. */
	private String statusCd;     
	
	/** The bank ctry cd. */
	private String bankCtryCd;
	
	/** The bank branch cd. */
	private String bankBranchCd; 	
	
	/** The bank branch. */
	private String bankBranch;	    
	
	/** The routing cd. */
	private String routingCd; 
	
	/** The routing type. */
	private String routingType;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the bank cd.
	 *
	 * @return the bank cd
	 */
	public String getBankCd() {
		return bankCd;
	}
	
	/**
	 * Sets the bank cd.
	 *
	 * @param bankCd the new bank cd
	 */
	public void setBankCd(String bankCd) {
		this.bankCd = bankCd;
	}
	
	/**
	 * Gets the bank name.
	 *
	 * @return the bank name
	 */
	public String getBankName() {
		return bankName;
	}
	
	/**
	 * Sets the bank name.
	 *
	 * @param bankName the new bank name
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the bank ctry cd.
	 *
	 * @return the bank ctry cd
	 */
	public String getBankCtryCd() {
		return bankCtryCd;
	}
	
	/**
	 * Sets the bank ctry cd.
	 *
	 * @param bankCtryCd the new bank ctry cd
	 */
	public void setBankCtryCd(String bankCtryCd) {
		this.bankCtryCd = bankCtryCd;
	}
	
	/**
	 * Gets the bank branch cd.
	 *
	 * @return the bank branch cd
	 */
	public String getBankBranchCd() {
		return bankBranchCd;
	}
	
	/**
	 * Sets the bank branch cd.
	 *
	 * @param bankBranchCd the new bank branch cd
	 */
	public void setBankBranchCd(String bankBranchCd) {
		this.bankBranchCd = bankBranchCd;
	}
	
	/**
	 * Gets the bank branch.
	 *
	 * @return the bank branch
	 */
	public String getBankBranch() {
		return bankBranch;
	}
	
	/**
	 * Sets the bank branch.
	 *
	 * @param bankBranch the new bank branch
	 */
	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}
	
	/**
	 * Gets the routing cd.
	 *
	 * @return the routing cd
	 */
	public String getRoutingCd() {
		return routingCd;
	}
	
	/**
	 * Sets the routing cd.
	 *
	 * @param routingCd the new routing cd
	 */
	public void setRoutingCd(String routingCd) {
		this.routingCd = routingCd;
	}
	
	/**
	 * Gets the routing type.
	 *
	 * @return the routing type
	 */
	public String getRoutingType() {
		return routingType;
	}
	
	/**
	 * Sets the routing type.
	 *
	 * @param routingType the new routing type
	 */
	public void setRoutingType(String routingType) {
		this.routingType = routingType;
	}   
	
	
	

}
