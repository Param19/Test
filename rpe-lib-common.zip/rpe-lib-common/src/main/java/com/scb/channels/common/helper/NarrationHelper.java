package com.scb.channels.common.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientInfoVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardTransactionInfoVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.SenderInfoVO;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class NarrationHelper.
 */
public class NarrationHelper {
	
	/** The Constant CLOSE_SQUARE. */
	public static final String CLOSE_SQUARE = "]";

	/** The Constant OPEN_SQUARE. */
	private static final String OPEN_SQUARE = "[";

	/** The Constant CLOSE_CURL. */
	private static final String CLOSE_CURL = "}";

	/** The Constant OPEN_CURL. */
	private static final String OPEN_CURL = "{";

	/** The Constant RSP_BPD_PD. */
	public static final String RSP_BPD_PD = "rsp.bpd.pd";

	/** The Constant RSP_BPD_TXN. */
	public static final String RSP_BPD_TXN = "rsp.bpd.txn";

	/** The Constant RSP_BPD. */
	public static final String RSP_BPD = "rsp.bpd";

	/** The Constant RQ_BPD_PD. */
	public static final String RQ_BPD_PD = "rq.bpd.pd";

	/** The Constant RQ_BPD_TXN. */
	public static final String RQ_BPD_TXN = "rq.bpd.txn";

	/** The Constant RQ_BPD. */
	public static final String RQ_BPD = "rq.bpd";

	/** The Constant RESPONSE_VO_BILLER_PAY_DETAILS_VO_PAYMENT_DETAILS_VO. */
	public static final String RESPONSE_VO_BILLER_PAY_DETAILS_VO_PAYMENT_DETAILS_VO = "responseVO.billerPayDetailsVO.paymentDetailsVO";

	/** The Constant RESPONSE_VO_BILLER_PAY_DETAILS_VO_TRANSACTION_INFO_VO. */
	public static final String RESPONSE_VO_BILLER_PAY_DETAILS_VO_TRANSACTION_INFO_VO = "responseVO.billerPayDetailsVO.transactionInfoVO";

	/** The Constant RESPONSE_VO_BILLER_PAY_DETAILS_VO. */
	public static final String RESPONSE_VO_BILLER_PAY_DETAILS_VO = "responseVO.billerPayDetailsVO";

	/** The Constant REQUEST_VO_BILLER_PAY_DETAILS_VO_PAYMENT_DETAILS_VO. */
	public static final String REQUEST_VO_BILLER_PAY_DETAILS_VO_PAYMENT_DETAILS_VO = "requestVO.billerPayDetailsVO.paymentDetailsVO";

	/** The Constant REQUEST_VO_BILLER_PAY_DETAILS_VO_TRANSACTION_INFO_VO. */
	public static final String REQUEST_VO_BILLER_PAY_DETAILS_VO_TRANSACTION_INFO_VO = "requestVO.billerPayDetailsVO.transactionInfoVO";

	/** The Constant REQUEST_VO_BILLER_PAY_DETAILS_VO. */
	public static final String REQUEST_VO_BILLER_PAY_DETAILS_VO = "requestVO.billerPayDetailsVO";

	public static final String CREDIT_NARRATION_IBS_UTIL = "IBS UTIL-";

	public static final String CREDIT_NARRATION_BILLPAYMENT = "BILLPAYMENT-";
	
	public static final String DEBIT_NARRATION_IBKG = "IBKG ";
	
	public static final String DEBIT_NARRATION_PAY_TO = "PAY TO ";
	
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(NarrationHelper.class);
	
	/** The Constant shortCodeMap. */
	public static final Map<String, String> shortCodeMap = new HashMap<String, String>();
	
	static {
		shortCodeMap.put(RQ_BPD, REQUEST_VO_BILLER_PAY_DETAILS_VO);
		shortCodeMap.put(RQ_BPD_TXN, REQUEST_VO_BILLER_PAY_DETAILS_VO_TRANSACTION_INFO_VO);
		shortCodeMap.put(RQ_BPD_PD, REQUEST_VO_BILLER_PAY_DETAILS_VO_PAYMENT_DETAILS_VO);
		shortCodeMap.put(RSP_BPD, RESPONSE_VO_BILLER_PAY_DETAILS_VO);
		shortCodeMap.put(RSP_BPD_TXN, RESPONSE_VO_BILLER_PAY_DETAILS_VO_TRANSACTION_INFO_VO);
		shortCodeMap.put(RSP_BPD_PD, RESPONSE_VO_BILLER_PAY_DETAILS_VO_PAYMENT_DETAILS_VO);
	}

	/**
	 * Replce text.
	 *
	 * @param pattern the pattern
	 * @param bean the bean
	 * @return the string
	 * @throws BusinessException the business exception
	 */
	public static String replceText(String pattern, BillerPayDetailsVO bean) throws BusinessException{		
		if (pattern != null) {
			try {
				while(pattern.indexOf(OPEN_CURL)!=-1){
					
					String replaceKey=pattern.substring(pattern.indexOf(OPEN_CURL)+1,pattern.indexOf(CLOSE_CURL));
					String orginalReplaceKey = new String(replaceKey);
					if (replaceKey.contains(OPEN_SQUARE)) {
						String shortCode = replaceKey.substring(replaceKey.indexOf(OPEN_SQUARE)+1,replaceKey.indexOf(CLOSE_SQUARE));
						replaceKey=	shortCodeMap.get(shortCode)+ replaceKey.substring(replaceKey.indexOf(CLOSE_SQUARE)+1);
					}
					String replaceValue=CommonConstants.SPACE;
					try {
						replaceValue = (String) PropertyUtils.getProperty(bean,replaceKey);
					} catch (Exception e) {				
						LOGGER.debug(e.getCause().toString());
						throw new BusinessException(e.getCause().toString());
					} 
					pattern=pattern.replace(OPEN_CURL+orginalReplaceKey+CLOSE_CURL, StringUtils.defaultIfEmpty(replaceValue, CommonConstants.SPACE));
					
				}
				return pattern;
			} finally {
				return pattern;
			}
		} else {
			return pattern;
		}
	}
	
	public static String replceText(String pattern, Object bean) throws BusinessException{		
		if (pattern != null) {
			try {
				while(pattern.indexOf(OPEN_CURL)!=-1){
					LOGGER.info(pattern+" ::::Entered");
					String replaceKey=pattern.substring(pattern.indexOf(OPEN_CURL)+1,pattern.indexOf(CLOSE_CURL));
					String orginalReplaceKey = new String(replaceKey);
					LOGGER.info("Replace Key::::: "+replaceKey);
					LOGGER.info("orginalReplaceKey Key::::: "+orginalReplaceKey);
					if (replaceKey.contains(OPEN_SQUARE)) {
						LOGGER.info("Replace Key::::: "+replaceKey);
						String shortCode = replaceKey.substring(replaceKey.indexOf(OPEN_SQUARE)+1,replaceKey.indexOf(CLOSE_SQUARE));
						replaceKey=	shortCodeMap.get(shortCode)+ replaceKey.substring(replaceKey.indexOf(CLOSE_SQUARE)+1);
					}
					String replaceValue=CommonConstants.SPACE;
					try {
						LOGGER.info("Replace Valuse :::"+replaceValue);
						replaceValue = (String) PropertyUtils.getProperty(bean,replaceKey);
						LOGGER.info("Replace Valuse :::"+replaceValue);
					} catch (Exception e) {				
						LOGGER.info("Replace Valuse Exception:::"+e);
						LOGGER.info(e.getCause().toString());
						throw new BusinessException(e.getCause().toString());
					} 
					pattern=pattern.replace(OPEN_CURL+orginalReplaceKey+CLOSE_CURL, StringUtils.defaultIfEmpty(replaceValue, CommonConstants.SPACE));
					
				}
				return pattern;
			} finally {
				return pattern;
			}
		} else {
			return pattern;
		}
	}
	public static BillerPayDetailsVO populateNarration(BillerPayDetailsVO billerPayDetails,NarrationVO narration) {
		
		try{
			LOGGER.info("populating narrations for :::: " + billerPayDetails.getPayRef());
			
			NarrationVO cnarrationVO1 = new NarrationVO();
			NarrationVO cnarrationVO2 = new NarrationVO();
			NarrationVO cnarrationVO3 = new NarrationVO();
			NarrationVO cnarrationVO4 = new NarrationVO();
			NarrationVO cnarrationVO5 = new NarrationVO();
			NarrationVO cnarrationVO6 = new NarrationVO();
			
			LOGGER.debug("populating credit narrations ::::: " + billerPayDetails.getPayRef());
			cnarrationVO1.setNarration(replceText(narration.getCreditNarration1(),billerPayDetails));
			cnarrationVO2.setNarration(replceText(narration.getCreditNarration2(),billerPayDetails));
			cnarrationVO3.setNarration(replceText(narration.getCreditNarration3(),billerPayDetails));
			cnarrationVO4.setNarration(replceText(narration.getCreditNarration4(),billerPayDetails));
			cnarrationVO5.setNarration(replceText(narration.getCreditNarration5(),billerPayDetails));
			cnarrationVO6.setNarration(replceText(narration.getCreditNarration6(),billerPayDetails));
			
			List<NarrationVO> creditNarration =new ArrayList<NarrationVO>();
			creditNarration.add(cnarrationVO1);
			creditNarration.add(cnarrationVO2);
			creditNarration.add(cnarrationVO3);
			creditNarration.add(cnarrationVO4);
			creditNarration.add(cnarrationVO5);
			creditNarration.add(cnarrationVO6);
			
			NarrationVO dnarrationVO1 = new NarrationVO();
			NarrationVO dnarrationVO2 = new NarrationVO();
			NarrationVO dnarrationVO3 = new NarrationVO();
			NarrationVO dnarrationVO4 = new NarrationVO();
			NarrationVO dnarrationVO5 = new NarrationVO();
			NarrationVO dnarrationVO6 = new NarrationVO();
			
			LOGGER.debug("populating debit narrations ::::: " + billerPayDetails.getPayRef());
			dnarrationVO1.setNarration(replceText(narration.getDebitNarration1(),billerPayDetails));
			dnarrationVO2.setNarration(replceText(narration.getDebitNarration2(),billerPayDetails));
			dnarrationVO3.setNarration(replceText(narration.getDebitNarration3(),billerPayDetails));
			dnarrationVO4.setNarration(replceText(narration.getDebitNarration4(),billerPayDetails));
			dnarrationVO5.setNarration(replceText(narration.getDebitNarration5(),billerPayDetails));
			dnarrationVO6.setNarration(replceText(narration.getDebitNarration6(),billerPayDetails));
			//dnarrationVO6.setNarration(billerPayDetails.getBillerCd());
		
			List<NarrationVO> debitNarration =new ArrayList<NarrationVO>();
			debitNarration.add(dnarrationVO1);
			debitNarration.add(dnarrationVO2);
			debitNarration.add(dnarrationVO3);
			debitNarration.add(dnarrationVO4);
			debitNarration.add(dnarrationVO5);
			debitNarration.add(dnarrationVO6);
		
			billerPayDetails.getTransactionInfoVO().setCreditNarration(creditNarration);
			billerPayDetails.getTransactionInfoVO().setDebitNarration(debitNarration);
			
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e.getCause());
		}
		
		return billerPayDetails;
	}

public static InwardPaymentRequestVO populateNarration(InwardPaymentRequestVO inwardPaymentRequestVO,NarrationVO narration) {
	
	try{
		LOGGER.info("populating narrations for :::: " + inwardPaymentRequestVO+" Narration::: "+narration);
		
		NarrationVO cnarrationVO1 = new NarrationVO();
		NarrationVO cnarrationVO2 = new NarrationVO();
		NarrationVO cnarrationVO3 = new NarrationVO();
		NarrationVO cnarrationVO4 = new NarrationVO();
		NarrationVO cnarrationVO5 = new NarrationVO();
		NarrationVO cnarrationVO6 = new NarrationVO();
		
		LOGGER.debug("populating credit narrations ::::: " + inwardPaymentRequestVO+" Narration::: "+narration);
		cnarrationVO1.setNarration(replceText(narration.getCreditNarration1(),inwardPaymentRequestVO));
		cnarrationVO2.setNarration(replceText(narration.getCreditNarration2(),inwardPaymentRequestVO));
		cnarrationVO3.setNarration(replceText(narration.getCreditNarration3(),inwardPaymentRequestVO));
		cnarrationVO4.setNarration(replceText(narration.getCreditNarration4(),inwardPaymentRequestVO));
		cnarrationVO5.setNarration(replceText(narration.getCreditNarration5(),inwardPaymentRequestVO));
		cnarrationVO6.setNarration(replceText(narration.getCreditNarration6(),inwardPaymentRequestVO));
		
		List<NarrationVO> creditNarration =new ArrayList<NarrationVO>();
		creditNarration.add(cnarrationVO1);
		creditNarration.add(cnarrationVO2);
		creditNarration.add(cnarrationVO3);
		creditNarration.add(cnarrationVO4);
		creditNarration.add(cnarrationVO5);
		creditNarration.add(cnarrationVO6);
		
		LOGGER.debug("populating credit narrations ::::: " + inwardPaymentRequestVO+" Narration::: "+creditNarration);
		
		NarrationVO dnarrationVO1 = new NarrationVO();
		NarrationVO dnarrationVO2 = new NarrationVO();
		NarrationVO dnarrationVO3 = new NarrationVO();
		NarrationVO dnarrationVO4 = new NarrationVO();
		NarrationVO dnarrationVO5 = new NarrationVO();
		NarrationVO dnarrationVO6 = new NarrationVO();
		
		
		dnarrationVO1.setNarration(replceText(narration.getDebitNarration1(),inwardPaymentRequestVO));
		dnarrationVO2.setNarration(replceText(narration.getDebitNarration2(),inwardPaymentRequestVO));
		dnarrationVO3.setNarration(replceText(narration.getDebitNarration3(),inwardPaymentRequestVO));
		dnarrationVO4.setNarration(replceText(narration.getDebitNarration4(),inwardPaymentRequestVO));
		dnarrationVO5.setNarration(replceText(narration.getDebitNarration5(),inwardPaymentRequestVO));
		dnarrationVO6.setNarration(replceText(narration.getDebitNarration6(),inwardPaymentRequestVO));
		
		List<NarrationVO> debitNarration =new ArrayList<NarrationVO>();
		debitNarration.add(dnarrationVO1);
		debitNarration.add(dnarrationVO2);
		debitNarration.add(dnarrationVO3);
		debitNarration.add(dnarrationVO4);
		debitNarration.add(dnarrationVO5);
		debitNarration.add(dnarrationVO6);
		
		LOGGER.debug("populating debit narrations ::::: " + inwardPaymentRequestVO+" Narration::: "+debitNarration);

		inwardPaymentRequestVO.setDebitNarrationVOs(debitNarration);
		inwardPaymentRequestVO.setCreditNarrationVOs(creditNarration);
	} catch(Exception e) {
		LOGGER.error(e.getMessage(), e.getCause());
	}
	
	return inwardPaymentRequestVO;
}

//CR1477 Orange Money Changes Starts, 20Feb18, Vijayan A
/** The Constant CLOSE_SQUARE. */
public static final String CLOSE_BRACKET = ")";

/** The Constant OPEN_SQUARE. */
private static final String OPEN_BRACKET = "(";


public static String replceText(String pattern, Object bean, boolean formatRequired) throws BusinessException{		
	if (pattern != null) {
		try {
			String objectType = null;
			String format = null;
			while(pattern.indexOf(OPEN_CURL)!=-1){
				LOGGER.info(pattern+" ::::Entered");
				String replaceKey=pattern.substring(pattern.indexOf(OPEN_CURL)+1,pattern.indexOf(CLOSE_CURL));
				String orginalReplaceKey = new String(replaceKey);
				LOGGER.info("Replace Key::::: "+replaceKey +":: orginalReplaceKey Key ::::: "+orginalReplaceKey);
				//LOGGER.info("orginalReplaceKey Key::::: "+orginalReplaceKey);
				if (formatRequired && replaceKey.contains(OPEN_BRACKET)) {
					//LOGGER.info("Replace Key::::: "+replaceKey);
					String shortCode = replaceKey.substring(replaceKey.indexOf(OPEN_BRACKET)+1,replaceKey.indexOf(CLOSE_BRACKET));
					if(shortCode.contains(CommonConstants.COMMA)) {
						String [] splitData = shortCode.split(CommonConstants.COMMA);
								objectType = splitData[0];
								format = splitData[1];
					}	
					replaceKey= replaceKey.substring(0, replaceKey.indexOf(OPEN_BRACKET));
				}
				Object replaceValue=null;
				try {
					LOGGER.info("Replace Value :::"+replaceValue);
					replaceValue = PropertyUtils.getProperty(bean,replaceKey);
					
					if(objectType != null && objectType.equalsIgnoreCase(Date.class.getSimpleName())) {
												
						Date date = (Date) replaceValue;
						replaceValue = DateUtils.getDateString(date, format);							
					}
					if(objectType != null && objectType.equalsIgnoreCase(Timestamp.class.getSimpleName())) {
						
						Timestamp date = (Timestamp) replaceValue;
						replaceValue = DateUtils.getDateString(date, format);							
					}
					if(objectType != null && objectType.equalsIgnoreCase(Calendar.class.getSimpleName())) {
						
						Calendar date = (Calendar) replaceValue;
						replaceValue = DateUtils.getDateString(date.getTime(), format);							
					}
					LOGGER.info("Replace Value :::"+replaceValue);
				} catch (Exception e) {				
					//LOGGER.info("Exception while performing replace text:::",e);
					LOGGER.error("Exception while performing replace text:::",e);
					throw new BusinessException(e.getCause().toString());
				} 
				pattern=pattern.replace(OPEN_CURL+orginalReplaceKey+CLOSE_CURL, StringUtils.defaultIfEmpty(replaceValue.toString(), CommonConstants.SPACE));
				
			}
			return pattern;
		} catch(Exception e) {
			LOGGER.error("Exception occurred while formatting replace text:::",e);
		}
	} 
	return pattern;
}
//CR1477 Orange Money Changes Ends, 20Feb18, Vijayan A

}
