/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.validation.MultiFieldValidator;

/**
 * The Class AccountValidator.
 *
 * @author 1464143 This class used to check the validation for Account Number
 */
public class AccountValidator implements MultiFieldValidator {

	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private List<String> property;
	
	/** The min length. */
	private int minLength = CommonConstants.SIX;
	
	/** The max length. */
	private int maxLength = CommonConstants.THIRTEEN;
	
	/** The min amount. */
	private Double minAmount = 1.0;
	

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		
		this.property = property;
	}

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		String fromAcc = null;
		String toAcc = null;
		Double amount = null;
		try {
			fromAcc = (String) PropertyUtils.getProperty(bean, property.get(0));
			toAcc = (String) PropertyUtils.getProperty(bean, property.get(1));
			amount = (Double)PropertyUtils.getProperty(bean, property.get(2));
		} catch (Exception e) {
			throw new ValidatorException(
					"Invalid Account or Amount field present");
		}
		if (checkSourceAccount(fromAcc, toAcc) || checkDestAccount(toAcc)) {
			throw new ValidatorException("Account number validation fails..");
		}
		checkMinAccount(amount);

	}

	/**
	 * Check dest account.
	 *
	 * @param toAcc the to acc
	 * @return true, if successful
	 * @throws ValidatorException ValidatorException
	 */
	private boolean checkDestAccount(String toAcc) throws ValidatorException {
		boolean accFlag = StringUtils.isBlank(toAcc) || StringUtils.isEmpty(toAcc)
				      || !StringUtils.isNumeric(toAcc);
		checkAccountLength(toAcc, minLength, maxLength);
		return accFlag;
	}

	/**
	 * Check source account.
	 *
	 * @param fromAcc the from acc
	 * @param toAcc the to acc
	 * @return true, if successful
	 * @throws ValidatorException  ValidatorException
	 */
	private boolean checkSourceAccount(String fromAcc, String toAcc) throws ValidatorException {
		boolean accFlag = StringUtils.isBlank(fromAcc)|| StringUtils.isEmpty(fromAcc)
				|| !StringUtils.isNumeric(fromAcc);
		checkAccountLength(fromAcc, minLength, maxLength);
		checkSameAccount(fromAcc, toAcc);
		return accFlag;
	}

	/**
	 * Check account length.
	 *
	 * @param accNmbr the acc nmbr
	 * @param minLength the min length
	 * @param maxLength the max length
	 * @return true, if successful
	 * @throws ValidatorException ValidatorException
	 */
	public void checkAccountLength(String accNmbr, Integer minLength, Integer maxLength) throws ValidatorException {
		if (accNmbr.length() < minLength || accNmbr.length() > maxLength){
			throw new ValidatorException("Account number validation fails..");
		}
	}

	/**
	 * Check same account.
	 * 
	 * @param fromAccNmbr
	 *            the from acc nmbr
	 * @param toAccNmbr
	 *            the to acc nmbr
	 * @return true, if successful
	 * @throws ValidatorException
	 *             the validator exception
	 */
	public void checkSameAccount(String fromAccNmbr, String toAccNmbr) throws ValidatorException {
		if (fromAccNmbr.equalsIgnoreCase(toAccNmbr)){
			throw new ValidatorException("Account number validation fails..");
		}
	}

	
	/**
	 * Check min account.
	 *
	 * @param amount the amount
	 * @throws ValidatorException the validator exception
	 */
	public void checkMinAccount(Double amount) throws ValidatorException {
		if (amount < minAmount){
			throw new ValidatorException("Amount is less than min amount allowed : " + minAmount);
		}
	}

	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean =  bean;
		
	}

	/**
	 * Sets the max length.
	 *
	 * @param maxLength the maxLength to set
	 */
	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	/**
	 * Sets the min length.
	 *
	 * @param minLength the minLength to set
	 */
	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}

	/**
	 * Sets the min amount.
	 *
	 * @param minAmount the minAmount to set
	 */
	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}
	
}
