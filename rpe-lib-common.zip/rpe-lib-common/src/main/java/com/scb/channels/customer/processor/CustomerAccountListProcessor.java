package com.scb.channels.customer.processor;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.AccountListRequestVO;
import com.scb.channels.base.vo.AccountListResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.customer.service.CustomerAccountListService;

/**
 * The Class CustomerAccountListProcessor.
 */
public class CustomerAccountListProcessor extends AbstractProcessor {
	
	/** The customer account list service. */
	CustomerAccountListService customerAccountListService;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.base.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		
		AccountListRequestVO accountListRequestVO = null;
		AccountListResponseVO  accountListResponseVO = null;
		accountListRequestVO =(AccountListRequestVO)bean.getRequestVO();
		accountListResponseVO = customerAccountListService
				.getCustomerAccountList(accountListRequestVO.getUser(), 
						accountListRequestVO.getClientVO(), accountListRequestVO.getMessageVO(), 
						accountListRequestVO.getServiceVO().getServiceTxnType());
		try {
			if (accountListResponseVO == null) {
				accountListResponseVO = new AccountListResponseVO();
				accountListResponseVO.setStatusDesc(ExceptionMessages._106.getMessage());
				accountListResponseVO.setStatus(ExceptionMessages._106.getCode());
			}
			else if(accountListResponseVO.getAccountListDetails()!=null){
				accountListResponseVO.setStatus(Messages._000.getCode());
				accountListResponseVO.setStatusDesc(Messages._000.getMessage());
				accountListResponseVO.setUser(accountListRequestVO.getUser());
				accountListResponseVO.setClientVO(accountListRequestVO.getClientVO());
				accountListResponseVO.setMessageVO(accountListRequestVO.getMessageVO());
				accountListResponseVO.setStatusCd("na,00");
				
			}
			else{
				accountListResponseVO.setStatus(ExceptionMessages._104.getCode());
				accountListResponseVO.setStatusDesc(ExceptionMessages._104.getMessage()); 	
			}
	   } 
		catch (Exception e) {
			if (accountListResponseVO == null) {
				accountListResponseVO = new AccountListResponseVO();
			}
			accountListResponseVO.setStatus(ExceptionMessages._105.getCode());
			accountListResponseVO.setStatusDesc(e.getMessage());
		}
		finally{
			bean.setResponseVO(accountListResponseVO);
		}
		return bean;
	}

	/**
	 * Sets the customer account list service.
	 *
	 * @param customerAccountListService the new customer account list service
	 */
	public void setCustomerAccountListService(
			CustomerAccountListService customerAccountListService) {
		this.customerAccountListService = customerAccountListService;
	}


}
