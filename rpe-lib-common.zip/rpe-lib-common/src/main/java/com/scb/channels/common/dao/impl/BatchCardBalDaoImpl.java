package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchCardBalDAO;
import com.scb.channels.common.vo.BatchCardBalVO;


/**
 * The Class BatchCardBalDaoImpl.
 */
public class BatchCardBalDaoImpl extends HibernateDaoSupport implements BatchCardBalDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchCardBalDAO#getBatchCardBal(com.scb.channels.common.vo.BatchCardBalVO)
	 */
	public List<BatchCardBalVO> getBatchCardBal(BatchCardBalVO batchCardBalVO) {
		Criteria criteria = getSession().createCriteria(BatchCardBalVO.class);
		if(batchCardBalVO!=null && batchCardBalVO.getId()!=null){
			criteria.add(Restrictions.eq(HibernateHelper.ID, batchCardBalVO.getId()));
			List<BatchCardBalVO> list = criteria.list();
			return list;
		}else{
			return null;
		}
	}
	
}
