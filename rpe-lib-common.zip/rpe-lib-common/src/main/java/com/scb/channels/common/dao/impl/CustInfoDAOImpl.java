package com.scb.channels.common.dao.impl;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.vo.CustInfoVO;
import com.scb.channels.base.vo.CustomerDetailsVO;
import com.scb.channels.common.dao.CustInfoDAO;

/**
 * The Class CustInfoDAOImpl.
 */
public class CustInfoDAOImpl extends HibernateDaoSupport implements CustInfoDAO {
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustInfoDAO#save(com.scb.channels.base.vo.CustInfoVO)
	 */
	public void save(CustInfoVO custinfovo) {
		getSession().save(custinfovo);
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustInfoDAO#update(com.scb.channels.base.vo.CustInfoVO)
	 */
	public void update(CustInfoVO custinfovo) {
		getSession().saveOrUpdate(custinfovo);

	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustInfoDAO#getCustomerInfo(java.lang.String, java.lang.String)
	 */
	public CustInfoVO getCustomerInfo(String CountryCode ,String MobileNumber){
		Criteria criteria = getSession().createCriteria(CustInfoVO.class);
		criteria.add(Restrictions.eq("mobilePhone", MobileNumber));
		criteria.add(Restrictions.eq("ctryCd", CountryCode));
		List<CustInfoVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustInfoDAO#getCustomerInfoForRelationship(java.lang.String)
	 */
	public CustInfoVO getCustomerInfoForRelationship(String relno){
		Criteria criteria = getSession().createCriteria(CustInfoVO.class);
		criteria.add(Restrictions.eq("relno", relno));
		List<CustInfoVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}
	
	 
		/**
		 * public void update(ReferenceVO referenceVO) {
		 * Query query = getSession().createQuery("update ReferenceVO set refCd =:refCd, statusCd =:statusCd,dtUpd=:dtUpd ,updBy=:updBy where id=:id ");
		 * query.setParameter(HibernateHelper.REF_CD, referenceVO.getRefCd());
		 * query.setParameter(HibernateHelper.STA_CD, referenceVO.getStatusCd());
		 * query.setParameter(HibernateHelper.DATE_UPDATE, DateUtils.getCurrentDate());
		 * query.setParameter(HibernateHelper.UPDATE_BY, referenceVO.getUpdBy());
		 * query.setParameter(HibernateHelper.ID, referenceVO.getId());
		 * query.executeUpdate();
		 * 
		 * }
		 *
		 * @param CustInfo the cust info
		 */

	public void updateOprAccount(CustInfoVO CustInfo) {
		Query query = getSession().createQuery("update CustInfoVO set OPERATING_ACCOUNT_NO =:OPERATING_ACCOUNT_NO where CUST_ID=:CUST_ID");
		query.setParameter("OPERATING_ACCOUNT_NO", CustInfo.getOperatingAccountNo());
		query.setParameter("CUST_ID",CustInfo.getCustId() );
		query.executeUpdate();   	
		//getSession().update(CustInfo);
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.CustInfoDAO#updateDefaultAccount(com.scb.channels.base.vo.CustInfoVO)
	 */
	public void updateDefaultAccount(CustInfoVO CustInfo) {
		Query query = getSession().createQuery("update CustInfoVO set defaultAccountNo =:defaultAccountNo where custId=:custId");
		query.setParameter("defaultAccountNo", CustInfo.getOperatingAccountNo());
		query.setParameter("custId",CustInfo.getCustId() );
		query.executeUpdate();   	
		//getSession().update(CustInfo);
	}
	
	/**
	 * update Customer Detail.
	 *
	 * @param customerDetailsVO the customer details vo
	 */
	public void updateCustDetail(CustomerDetailsVO customerDetailsVO) {
		Query query = getSession().createQuery(getQueryString(customerDetailsVO).toString());
		getQueryParameter(customerDetailsVO, query);
		query.executeUpdate();   	
	}

	/**
	 * Gets the query parameter.
	 *
	 * @param customerDetailsVO the customer details vo
	 * @param query the query
	 * @return the query parameter
	 */
	private void getQueryParameter(CustomerDetailsVO customerDetailsVO,
			Query query) {
		query.setParameter("CUST_NAME1", customerDetailsVO.getCustName1());
		query.setParameter("CUST_NAME2", customerDetailsVO.getCustName2());
		if(customerDetailsVO.getEmail()!=null){
			query.setParameter("EMAIL", customerDetailsVO.getEmail());
		}
		if(customerDetailsVO.getSegmentCd()!=null){ 
			query.setParameter("SEGMENT_CD", customerDetailsVO.getSegmentCd());
		}
		if(customerDetailsVO.getMobile()!=null){
			query.setParameter("MOBILE_PHONE", customerDetailsVO.getMobile());
		}
		query.setParameter("CTRY_CD", customerDetailsVO.getCtryCd());
		query.setParameter("CUST_ID",customerDetailsVO.getCustId());
	}

	/**
	 * Gets the query string.
	 *
	 * @param customerDetailsVO the customer details vo
	 * @return the query string
	 */
	private StringBuilder getQueryString(CustomerDetailsVO customerDetailsVO) {
		StringBuilder queryString = new StringBuilder();
		queryString.append("update CustInfoVO set CUST_NAME1 =:CUST_NAME1, CUST_NAME2 =:CUST_NAME2 ");
		if(customerDetailsVO.getEmail()!=null){
			queryString.append(",EMAIL =:EMAIL ");
		}
		if(customerDetailsVO.getSegmentCd()!=null){
			queryString.append(",SEGMENT_CD =:SEGMENT_CD ");
		}
		if(customerDetailsVO.getMobile()!=null){
			queryString.append(",MOBILE_PHONE =:MOBILE_PHONE ");
		}
		queryString.append(",CTRY_CD =:CTRY_CD  where CUST_ID=:CUST_ID");
		return queryString;
	}

}


