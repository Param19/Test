package com.scb.channels.common.dao;

import com.scb.channels.common.vo.BankViewVO;

/**
 * The Interface BankViewDAO.
 */
public interface BankViewDAO {
 
	/**
	 * Gets the.
	 *
	 * @param bankViewVO the bank view vo
	 * @return the bank view vo
	 */
	BankViewVO get(BankViewVO bankViewVO);
}
