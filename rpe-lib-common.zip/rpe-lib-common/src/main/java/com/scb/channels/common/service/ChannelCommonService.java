package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.base.exception.MaskException;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.vo.ChannelMaskPolicyVO;


/**
 * @author 1382158
 *
 */
public interface ChannelCommonService {


	public List<ChannelMaskPolicyVO> getChannelMaskPolicy (String typeCode,String categoryCode,ClientVO clientVO) throws MaskException;
	
	public List<ChannelMaskPolicyVO> getAllMaskPolicy(String typeCode) throws MaskException;
	
	public ChannelMaskPolicyVO getChannelMaskPolicyForField(String typeCode, String categoryCode, ClientVO clientVO, String fieldName) throws MaskException;



}
