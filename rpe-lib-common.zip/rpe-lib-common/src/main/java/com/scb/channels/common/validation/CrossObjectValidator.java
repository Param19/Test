package com.scb.channels.common.validation;

import java.util.List;
import java.util.Map;

import org.apache.commons.validator.ValidatorException;

/**
 * The Interface CrossObjectValidator.
 */
public interface CrossObjectValidator {
	
	/**
	 * Validate.
	 *
	 * @throws ValidatorException the validator exception
	 */
	void validate() throws ValidatorException;
	
	/**
	 * Sets the bean.
	 *
	 * @param bean the bean
	 */
	void setBean(Map<String, Object> bean);
	
	/**
	 * Sets the property.
	 *
	 * @param map the map
	 */
	void setProperty(Map<String, List<String>> map);
}
