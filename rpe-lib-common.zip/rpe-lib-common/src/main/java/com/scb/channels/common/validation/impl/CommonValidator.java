/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.validation.MultiFieldValidator;

/**
 * The Class NumericValidator.
 *
 * @author 1464143
 */
public class CommonValidator implements MultiFieldValidator {
	
	/** The property. */
	private List<String> property;
	
	/** The bean. */
	private PayloadDTO bean;	
	
	
	

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidator.class);
	

	/**
	 * Validate.
	 *b
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
	
	
		
		for (String key: property) {
			String value=null;
			try {
				 value = (String) PropertyUtils.getProperty(bean, key);				
				
			} catch (Exception e) {
				LOGGER.error(key, e.getMessage());
				throw new ValidatorException(e.getMessage());
			} 
			//boolean numericValue=StringUtils.isNumeric( value) && StringUtils.isNotEmpty(value)&& StringUtils.isNotBlank(value) && checkLengthField(value,Integer.valueOf(billerValidationVO.getBillerField()));
			if(!checkValidation(value)){
				throw new ValidatorException("The chequebook number is not valid.");
			}
			
			
			
		}

	}
	
	
	/**
	 * Check runtime fields length.
	 *
	 * @param accNmbr the acc nmbr
	 * @param minLength the min length
	 * @param maxLength the max length
	 * @return true, if successful
	 */
	public boolean checkValidation(String value) {
		String regPattern="\\d{6}";
		Pattern pattern=Pattern.compile(regPattern);		
		boolean accFlag=pattern.matcher(value).matches();		
		/*if ( value.length() > billerValidationVO.getLenMaxValidation() || value.length()<billerValidationVO.getLenMinValidation()){
			accFlag = false;
		}*/
		return accFlag;
	}

	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;
	}

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		this.property = property;
	}


  

}

	
	
	

