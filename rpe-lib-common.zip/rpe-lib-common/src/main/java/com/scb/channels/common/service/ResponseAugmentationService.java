package com.scb.channels.common.service;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Interface ResponseAugmentationService.
 */
public interface ResponseAugmentationService<K> {
	
	/**
	 * Process response.
	 *
	 * @param obj the obj
	 */
	void processResponse(Object obj);
	
	/**
	 * Process response.
	 *
	 * @param obj the obj
	 */
	PayloadDTO handleResponse(K obj);

}
