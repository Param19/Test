package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.BatchCardTxnVO;

/**
 * The Interface BatchCardTxnDAO.
 */
public interface BatchCardTxnDAO {
	
	/**
	 * Gets the batch card txn.
	 *
	 * @param batchCardTxnVO the batch card txn vo
	 * @return the batch card txn
	 */
	List<BatchCardTxnVO> getBatchCardTxn(BatchCardTxnVO batchCardTxnVO);

}
