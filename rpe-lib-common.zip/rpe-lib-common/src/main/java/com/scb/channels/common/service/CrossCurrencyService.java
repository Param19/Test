package com.scb.channels.common.service;

/**
 * The Interface CrossCurrencyService.
 */
public interface CrossCurrencyService {
	
 /**
  * Cross currency check.
  *
  * @param channelType the channel type
  * @param countryCode the country code
  * @param srcCurrency the src currency
  * @param destinationCurrency the destination currency
  * @return true, if successful
  */
 boolean crossCurrencyCheck(String channelType,String countryCode,String srcCurrency,String destinationCurrency);  
	

}
