package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.ActiveLoginSessionVO;
import com.scb.channels.common.vo.LoginSessionVO;

/**
 * The Interface LoginSessionDAO.
 */
public interface LoginSessionDAO {
 
	/**
	 * Save.
	 *
	 * @param loginSessionVO the login session vo
	 */
	void save(LoginSessionVO loginSessionVO);
	
	/**
	 * Delete.
	 *
	 * @param loginSessionVO the login session vo
	 */
	void delete(LoginSessionVO loginSessionVO);
	
	/**
	 * Delete active session.
	 *
	 * @param loginSessionVO the login session vo
	 */
	void deleteActiveSession(ActiveLoginSessionVO loginSessionVO);
	
	/**
	 * Search.
	 *
	 * @param userId the user id
	 * @param country the country
	 * @param channel the channel
	 * @param sessionId the session id
	 * @return the login session vo
	 */
	LoginSessionVO search(String userId,String country, String channel, String sessionId);
	
	/**
	 * Search by user id.
	 *
	 * @param userId the user id
	 * @param country the country
	 * @param channel the channel
	 * @return the list of LoginSessionVO
	 */
	List<LoginSessionVO> searchByUserId(String userId,String country, String channel);

	
	/**
	 * Gets the all session.
	 *
	 * @param country the country
	 * @param channel the channel
	 * @return the all session
	 */
	List<LoginSessionVO> getAllSession(String country, String channel);
	
	

	/**
	 * Search.
	 *
	 * @param userId the user id
	 * @param country the country
	 * @param channel the channel
	 * @param sessionId the session id
	 * @return the login session vo
	 */
	ActiveLoginSessionVO searchActiveSession(String userId,String country, String channel, String sessionId);
	
	/**
	 * Search by user id.
	 *
	 * @param userId the user id
	 * @param country the country
	 * @param channel the channel
	 * @return the list of LoginSessionVO
	 */
	List<ActiveLoginSessionVO> searchActiveSessionByUserId(String userId,String country, String channel);

	
	/**
	 * Gets the all session.
	 *
	 * @param country the country
	 * @param channel the channel
	 * @return the all session
	 */
	List<ActiveLoginSessionVO> getAllActiveSession(String country, String channel);
}
