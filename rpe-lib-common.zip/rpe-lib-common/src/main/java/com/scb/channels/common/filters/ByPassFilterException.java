/**
 * 
 */
package com.scb.channels.common.filters;

/**
 * The Class ByPassFilterException.
 *
 * @author 1411807
 */
public class ByPassFilterException extends FilterException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8603698711647846007L;

	/**
	 * Instantiates a new by pass filter exception.
	 *
	 * @param arg0 the arg0
	 */
	public ByPassFilterException(Throwable arg0) {
		super(arg0);
	}
	
	/**
	 * Instantiates a new by pass filter exception.
	 *
	 * @param message the message
	 */
	public ByPassFilterException(String message) {
	    super(message);
	}

}
