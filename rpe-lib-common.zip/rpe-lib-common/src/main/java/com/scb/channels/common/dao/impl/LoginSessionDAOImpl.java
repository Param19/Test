package com.scb.channels.common.dao.impl;

import java.util.List;

import org.apache.cxf.common.util.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.LoginSessionDAO;
import com.scb.channels.common.vo.ActiveLoginSessionVO;
import com.scb.channels.common.vo.LoginSessionVO;

/**
 * The Class LoginSessionDAOImpl.
 */
public class LoginSessionDAOImpl extends HibernateDaoSupport implements
		LoginSessionDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#save(com.scb.channels.common.vo.LoginSessionVO)
	 */
	public void save(LoginSessionVO loginSessionVO) {
		getSession().save(loginSessionVO);

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#delete(com.scb.channels.common.vo.LoginSessionVO)
	 */
	public void delete(LoginSessionVO loginSessionVO) {
		getSession().delete(loginSessionVO);

	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#delete(com.scb.channels.common.vo.LoginSessionVO)
	 */
	public void deleteActiveSession(ActiveLoginSessionVO loginSessionVO) {
		/*getSession().delete(loginSessionVO);*/
		String sqlQuery="delete from security.LOGIN_SESSION where user_id= :userId";
		Query query= getSession().createSQLQuery(sqlQuery);
		query.setParameter("userId", loginSessionVO.getUserId());
		query.executeUpdate();
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#search(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public LoginSessionVO search(String userId, String country, String channel,
			String sessionId) {
		Criteria criteria=getSession().createCriteria(LoginSessionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.USER_ID, userId));
		criteria.add(Restrictions.eq(HibernateHelper.CTRYCD, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL, channel));	
		if (!StringUtils.isEmpty(sessionId)) {
			criteria.add(Restrictions.eq("sessionId", sessionId));	
		}
		List<LoginSessionVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#searchByUserId(java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<LoginSessionVO> searchByUserId(String userId, String country, String channel) {
		Criteria criteria=getSession().createCriteria(LoginSessionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.USER_ID, userId));
		criteria.add(Restrictions.eq(HibernateHelper.CTRYCD, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL, channel));	
		return criteria.list();
	}	

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#getAllSession(java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<LoginSessionVO> getAllSession(String country, String channel) {
		Criteria criteria=getSession().createCriteria(LoginSessionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CTRYCD, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL, channel));	
		return criteria.list();
	}	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#searchActiveSession(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public ActiveLoginSessionVO searchActiveSession(String userId, String country, String channel,
			String sessionId) {
		Criteria criteria=getSession().createCriteria(ActiveLoginSessionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.USER_ID, userId));
		criteria.add(Restrictions.eq(HibernateHelper.CTRYCD, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL, channel));	
		if (!StringUtils.isEmpty(sessionId)) {
			criteria.add(Restrictions.eq("sessionId", sessionId));	
		}
		List<ActiveLoginSessionVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#searchByUserId(java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<ActiveLoginSessionVO> searchActiveSessionByUserId(String userId, String country, String channel) {
		Criteria criteria=getSession().createCriteria(ActiveLoginSessionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.USER_ID, userId));
		criteria.add(Restrictions.eq(HibernateHelper.CTRYCD, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL, channel));	
		return criteria.list();
	}	

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LoginSessionDAO#getAllSession(java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<ActiveLoginSessionVO> getAllActiveSession(String country, String channel) {
		Criteria criteria=getSession().createCriteria(ActiveLoginSessionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CTRYCD, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL, channel));	
		return criteria.list();
	}	
}
