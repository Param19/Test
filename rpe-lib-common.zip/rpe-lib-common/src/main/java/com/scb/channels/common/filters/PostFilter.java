/**
 * 
 */
package com.scb.channels.common.filters;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Interface PostFilter.
 *
 * @author 1411807
 */
public interface PostFilter {

	/**
	 * Filter.
	 *
	 * @param bean the bean
	 * @throws FilterException the filter exception
	 */
	void filter(PayloadDTO bean) throws FilterException;
	
	/**
	 * Sets the filter condition.
	 *
	 * @param condition the new filter condition
	 */
	void setFilterCondition(FilterCondition condition);
	
}
