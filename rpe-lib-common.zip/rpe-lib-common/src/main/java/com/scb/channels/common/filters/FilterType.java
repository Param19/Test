/**
 * 
 */
package com.scb.channels.common.filters;

/**
 * The Enum FilterType.
 * 
 * @author 1411807
 */
public enum FilterType {

	CHECK_AND_PASS, CHECK_AND_REJECT
}
