/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.dao.BillerValidationDAO;
import com.scb.channels.common.validation.MultiFieldValidator;
import com.scb.channels.common.vo.BillerValidationVO;

/**
 * The Class NumericValidator.
 *
 * @author 1464143
 */
public class NumericValidator implements MultiFieldValidator {
	
	/** The property. */
	private List<String> property;
	
	/** The bean. */
	private PayloadDTO bean;
	
	
	
	private BillerValidationDAO billerValidationDAO;
	

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(NumericValidator.class);
	

	/**
	 * Validate.
	 *b
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		//BillerValidationVO billerValidationVO =null;
		 BillerPayRequestVO requestVO =( (BillerPayRequestVO)bean.getRequestVO());
		List<BillerValidationVO> billerValidationList=billerValidationDAO.getByctryCdAndBillerCd(requestVO.getUser().getCountry(), requestVO.getBillerPayDetailsVO().getBillerCd());
		for (BillerValidationVO billerValidationVO: billerValidationList) {
			String value=null;
			try {
				 value = (String) PropertyUtils.getProperty(bean, billerValidationVO.getBillerField());				
				
			} catch (Exception e) {
				LOGGER.error(billerValidationVO.getBillerField(), e.getMessage());
				throw new ValidatorException(e.getMessage());
			} 
			//boolean numericValue=StringUtils.isNumeric( value) && StringUtils.isNotEmpty(value)&& StringUtils.isNotBlank(value) && checkLengthField(value,Integer.valueOf(billerValidationVO.getBillerField()));
			if(!checkValidation(billerValidationVO,value)){
				throw new ValidatorException(billerValidationVO.getValMessage());
			}
		}

	}
	
	
	/**
	 * Check runtime fields length.
	 *
	 * @param accNmbr the acc nmbr
	 * @param minLength the min length
	 * @param maxLength the max length
	 * @return true, if successful
	 */
	public boolean checkValidation(BillerValidationVO billerValidationVO,String value) {
		// /d{1,8}
		Pattern pattern=Pattern.compile(billerValidationVO.getRegExp());		
		boolean accFlag=pattern.matcher(value).matches();		
		/*if ( value.length() > billerValidationVO.getLenMaxValidation() || value.length()<billerValidationVO.getLenMinValidation()){
			accFlag = false;
		}*/
		return accFlag;
	}

	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;
	}

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		this.property = property;
	}


	public void setBillerValidationDAO(BillerValidationDAO billerValidationDAO) {
		this.billerValidationDAO = billerValidationDAO;
	}
	


}

	
	
	

