package com.scb.channels.common.service.impl;

import java.util.List;

import com.scb.channels.common.dao.BatchCardBalDAO;
import com.scb.channels.common.service.BatchCardBalService;
import com.scb.channels.common.vo.BatchCardBalVO;

/**
 * The Class BatchCardBalServiceImpl.
 */
public class BatchCardBalServiceImpl implements BatchCardBalService {
	
	/** The batch card bal dao. */
	private BatchCardBalDAO batchCardBalDAO;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchCardBalService#getBatchCardBal(com.scb.channels.common.vo.BatchCardBalVO)
	 */
	public List<BatchCardBalVO> getBatchCardBal(BatchCardBalVO batchCardBalVO) {
		return batchCardBalDAO.getBatchCardBal(batchCardBalVO);
	}

	
	/**
	 * Gets the batch card bal dao.
	 *
	 * @return the batch card bal dao
	 */
	public BatchCardBalDAO getBatchCardBalDAO() {
		return batchCardBalDAO;
	}

	/**
	 * Sets the batch card bal dao.
	 *
	 * @param batchCardBalDAO the new batch card bal dao
	 */
	public void setBatchCardBalDAO(BatchCardBalDAO batchCardBalDAO) {
		this.batchCardBalDAO = batchCardBalDAO;
	}

}
