package com.scb.channels.jms.listener;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.common.service.ResponseAugmentationService;
import com.scb.channels.common.transformers.Transformer;



/**
 * The listener interface for receiving channel events.
 * The class that is interested in processing a channel
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addChannelListener<code> method. When
 * the channel event occurs, that object's appropriate
 * method is invoked.
 *
 * @see ChannelEvent
 */
public class ChannelListener<K> implements MessageListener{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelListener.class);
	
	
	/** The transformer. */
	private Transformer<K, String> transformer;
	
	/** The augmentation service. */
	private ResponseAugmentationService<K> augmentationService;
	
	

	/**
	 * On message.
	 * 
	 * @param msg
	 *            the msg
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	public void onMessage(Message msg) {
		if (msg instanceof TextMessage) {
			try {
				LOGGER.debug(msg.toString());
				TextMessage tmsg = (TextMessage) msg;
				augmentationService.processResponse(transformer.transform(tmsg.getText()));
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
	}


	/**
	 * Sets the transformer.
	 *
	 * @param transform the transform
	 */
	public void setTransformer(Transformer<K, String> transform) {
		this.transformer = transform;
	}


	/**
	 * Sets the augmentation service.
	 *
	 * @param augmentationService the augmentationService to set
	 */
	public void setAugmentationService(
			ResponseAugmentationService<K> augmentationService) {
		this.augmentationService = augmentationService;
	}

	

}
