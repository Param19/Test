package com.scb.channels.common.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.EncryptionUtils;
import com.scb.channels.common.dao.VariableDAO;
import com.scb.channels.common.vo.VariablesVO;

public class DataBean {
	/*
	 * Java Beans for retrieving all the data and put into the hashmap
	 * 
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DataBean.class);
	public  Map<String,String> map= new HashMap<String,String>(0);
	public VariableDAO variableDAO;
	
	
	
	/*
	 * @author 1460693 Srikanth
	 * 
	 * writing the data in
	 */
	public void init(){		
		
		List<VariablesVO> variable=variableDAO.getSystemVaribale();
		try{
			if(variable!=null){

				LOGGER.debug("SYS PARAMS exists in DB");
				for(VariablesVO var: variable){
					
					LOGGER.debug("Vaibale Name -   "+var.getVariableName()+"  -- "+"Vaibale value -   "+var.getVariableValue() + "encFlag --" +  var.getEncryption());
					if(var.getVariableName()!=null && var.getVariableValue()!=null){
						
						String varkey="";
						String key=var.getVariableName();
						String value=var.getVariableValue();
						String country=var.getCountryCode();
						String Channel=var.getChannelCode();
						String encFlag = var.getEncryption();
						
								
						if(StringUtils.isNotEmpty(encFlag) && encFlag.equals(CommonConstants.YES)) {
							if (value.length()>5 && value.substring(0, 5).compareToIgnoreCase(CommonConstants.encryptPrefix) == 0) {
								value = EncryptionUtils.decrypt(key, value.substring(5));
								
							} else {
								try {
									String encValue = EncryptionUtils.encrypt(key, value);
									var.setVariableValue(CommonConstants.encryptPrefix + encValue);
									variableDAO.update(var); 
								} catch(Exception e) {
									LOGGER.error("DataBean - updating encryption exception  ",e);
								}								
							}
						}
						
						 if(StringUtils.isNotEmpty(country)){
							 varkey=varkey+country;
						 }
						 if(StringUtils.isNotEmpty(Channel)){
							 varkey=varkey+Channel;
						 }
						 varkey=varkey+key;
						 map.put(varkey, value);
						 LOGGER.info("map values [" + varkey +"]--[" + map.get(varkey));
					}else{
						LOGGER.debug("variable is empty");
					}
					
				}
				
			}else{
				LOGGER.debug("No SYS PARAMS exists in DB");
			}
			
			
			
		}catch(Exception e){
			LOGGER.debug("Exception while retriving the variable names");
		}
		
		
	}
	
	
	public Map<String, String> getMap() {
		return map;
	}
	public void setMap(Map<String, String> map) {
		this.map = map;
	}
	public VariableDAO getVariableDAO() {
		return variableDAO;
	}
	public void setVariableDAO(VariableDAO variableDAO) {
		this.variableDAO = variableDAO;
	}

}
