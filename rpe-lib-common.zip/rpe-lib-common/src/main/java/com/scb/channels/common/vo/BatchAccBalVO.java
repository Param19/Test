package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class BatchAccBalVO.
 */
public class BatchAccBalVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6793506178215488924L;
	
	/** The id. */
	private Integer  id;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The acct no. */
	private String acctNo;
	
	/** The prod cd. */
	private String prodCd;
	
	/** The sub prod cd. */
	private String subProdCd;
	
	/** The currency cd. */
	private String currencyCd;
	
	/** The current bal. */
	private Double currentBal;
	
	/** The current bal local. */
	private Double currentBalLocal;
	
	/** The aval bal. */
	private Double avalBal;
	
	/** The aval local bal. */
	private Double avalLocalBal;
	
	/** The uncleared chq bal. */
	private Double unclearedChqBal;
	
	/** The inter acct no. */
	private String interAcctNo;
	
	/** The money trnfr ind. */
	private String moneyTrnfrInd;
	
	/** The short name. */
	private String shortName;
	
	/** The principal amt. */
	private Double principalAmt;
	
	/** The term. */
	private String term;
	
	/** The term cd. */
	private String termCd;
	
	/** The int rate. */
	private Double intRate;
	
	/** The int maturity. */
	private Double intMaturity;
	
	/** The issue date. */
	private Date issueDate;
	
	/** The maturity date. */
	private Date maturityDate;
	
	/** The roll over type. */
	private String rollOverType;
	
	/** The roll over inst cd. */
	private String rollOverInstCd;
	
	/** The cheque book flag. */
	private String chequeBookFlag;
	
	/** The relationship cd. */
	private String relationshipCd;
	
	/** The final mature dt. */
	private Date finalMatureDt;
	
	/** The principal disposal cd. */
	private String principalDisposalCd;
	
	/** The last txn dt. */
	private Date lastTxnDt;
	
	/** The notes. */
	private String notes;
	
	/** The deal dt. */
	private Date dealDt;
	
	/** The deal branch. */
	private String dealBranch;
	
	/** The int pay due dt. */
	private Date intPayDueDt;
	
	/** The limit lien amt. */
	private Double limitLienAmt;
	
	/** The minimum repayment. */
	private Double minimumRepayment;
	
	/** The total effect limit. */
	private Double totalEffectLimit;
	
	/** The cleared balance. */
	private Double clearedBalance;
	
	/** The mas cd. */
	private String masCd;
	
	/** The od class. */
	private String odClass;
	
	/** The interest disposal cd. */
	private String interestDisposalCd;
	
	/** The date created. */
	private Date dateCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The date upd. */
	private Date dateUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private Integer version;
	
	/** The sadiq flag. */
	private String sadiqFlag;
	
	/** The cust id. */
	private String custId;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}
	
	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	/**
	 * Gets the prod cd.
	 *
	 * @return the prod cd
	 */
	public String getProdCd() {
		return prodCd;
	}
	
	/**
	 * Sets the prod cd.
	 *
	 * @param prodCd the new prod cd
	 */
	public void setProdCd(String prodCd) {
		this.prodCd = prodCd;
	}
	
	/**
	 * Gets the sub prod cd.
	 *
	 * @return the sub prod cd
	 */
	public String getSubProdCd() {
		return subProdCd;
	}
	
	/**
	 * Sets the sub prod cd.
	 *
	 * @param subProdCd the new sub prod cd
	 */
	public void setSubProdCd(String subProdCd) {
		this.subProdCd = subProdCd;
	}
	
	/**
	 * Gets the currency cd.
	 *
	 * @return the currency cd
	 */
	public String getCurrencyCd() {
		return currencyCd;
	}
	
	/**
	 * Sets the currency cd.
	 *
	 * @param currencyCd the new currency cd
	 */
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	
	/**
	 * Gets the current bal.
	 *
	 * @return the current bal
	 */
	public Double getCurrentBal() {
		return currentBal;
	}
	
	/**
	 * Sets the current bal.
	 *
	 * @param currentBal the new current bal
	 */
	public void setCurrentBal(Double currentBal) {
		this.currentBal = currentBal;
	}
	
	/**
	 * Gets the current bal local.
	 *
	 * @return the current bal local
	 */
	public Double getCurrentBalLocal() {
		return currentBalLocal;
	}
	
	/**
	 * Sets the current bal local.
	 *
	 * @param currentBalLocal the new current bal local
	 */
	public void setCurrentBalLocal(Double currentBalLocal) {
		this.currentBalLocal = currentBalLocal;
	}
	
	/**
	 * Gets the aval bal.
	 *
	 * @return the aval bal
	 */
	public Double getAvalBal() {
		return avalBal;
	}
	
	/**
	 * Sets the aval bal.
	 *
	 * @param avalBal the new aval bal
	 */
	public void setAvalBal(Double avalBal) {
		this.avalBal = avalBal;
	}
	
	/**
	 * Gets the aval local bal.
	 *
	 * @return the aval local bal
	 */
	public Double getAvalLocalBal() {
		return avalLocalBal;
	}
	
	/**
	 * Sets the aval local bal.
	 *
	 * @param avalLocalBal the new aval local bal
	 */
	public void setAvalLocalBal(Double avalLocalBal) {
		this.avalLocalBal = avalLocalBal;
	}
	
	/**
	 * Gets the uncleared chq bal.
	 *
	 * @return the uncleared chq bal
	 */
	public Double getUnclearedChqBal() {
		return unclearedChqBal;
	}
	
	/**
	 * Sets the uncleared chq bal.
	 *
	 * @param unclearedChqBal the new uncleared chq bal
	 */
	public void setUnclearedChqBal(Double unclearedChqBal) {
		this.unclearedChqBal = unclearedChqBal;
	}
	
	/**
	 * Gets the inter acct no.
	 *
	 * @return the inter acct no
	 */
	public String getInterAcctNo() {
		return interAcctNo;
	}
	
	/**
	 * Sets the inter acct no.
	 *
	 * @param interAcctNo the new inter acct no
	 */
	public void setInterAcctNo(String interAcctNo) {
		this.interAcctNo = interAcctNo;
	}
	
	/**
	 * Gets the money trnfr ind.
	 *
	 * @return the money trnfr ind
	 */
	public String getMoneyTrnfrInd() {
		return moneyTrnfrInd;
	}
	
	/**
	 * Sets the money trnfr ind.
	 *
	 * @param moneyTrnfrInd the new money trnfr ind
	 */
	public void setMoneyTrnfrInd(String moneyTrnfrInd) {
		this.moneyTrnfrInd = moneyTrnfrInd;
	}
	
	/**
	 * Gets the short name.
	 *
	 * @return the short name
	 */
	public String getShortName() {
		return shortName;
	}
	
	/**
	 * Sets the short name.
	 *
	 * @param shortName the new short name
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	
	/**
	 * Gets the principal amt.
	 *
	 * @return the principal amt
	 */
	public Double getPrincipalAmt() {
		return principalAmt;
	}
	
	/**
	 * Sets the principal amt.
	 *
	 * @param principalAmt the new principal amt
	 */
	public void setPrincipalAmt(Double principalAmt) {
		this.principalAmt = principalAmt;
	}
	
	/**
	 * Gets the term.
	 *
	 * @return the term
	 */
	public String getTerm() {
		return term;
	}
	
	/**
	 * Sets the term.
	 *
	 * @param term the new term
	 */
	public void setTerm(String term) {
		this.term = term;
	}
	
	/**
	 * Gets the term cd.
	 *
	 * @return the term cd
	 */
	public String getTermCd() {
		return termCd;
	}
	
	/**
	 * Sets the term cd.
	 *
	 * @param termCd the new term cd
	 */
	public void setTermCd(String termCd) {
		this.termCd = termCd;
	}
	
	/**
	 * Gets the int rate.
	 *
	 * @return the int rate
	 */
	public Double getIntRate() {
		return intRate;
	}
	
	/**
	 * Sets the int rate.
	 *
	 * @param intRate the new int rate
	 */
	public void setIntRate(Double intRate) {
		this.intRate = intRate;
	}
	
	/**
	 * Gets the int maturity.
	 *
	 * @return the int maturity
	 */
	public Double getIntMaturity() {
		return intMaturity;
	}
	
	/**
	 * Sets the int maturity.
	 *
	 * @param intMaturity the new int maturity
	 */
	public void setIntMaturity(Double intMaturity) {
		this.intMaturity = intMaturity;
	}
	
	/**
	 * Gets the issue date.
	 *
	 * @return the issue date
	 */
	public Date getIssueDate() {
		return issueDate;
	}
	
	/**
	 * Sets the issue date.
	 *
	 * @param issueDate the new issue date
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	
	/**
	 * Gets the maturity date.
	 *
	 * @return the maturity date
	 */
	public Date getMaturityDate() {
		return maturityDate;
	}
	
	/**
	 * Sets the maturity date.
	 *
	 * @param maturityDate the new maturity date
	 */
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}
	
	/**
	 * Gets the roll over type.
	 *
	 * @return the roll over type
	 */
	public String getRollOverType() {
		return rollOverType;
	}
	
	/**
	 * Sets the roll over type.
	 *
	 * @param rollOverType the new roll over type
	 */
	public void setRollOverType(String rollOverType) {
		this.rollOverType = rollOverType;
	}
	
	/**
	 * Gets the roll over inst cd.
	 *
	 * @return the roll over inst cd
	 */
	public String getRollOverInstCd() {
		return rollOverInstCd;
	}
	
	/**
	 * Sets the roll over inst cd.
	 *
	 * @param rollOverInstCd the new roll over inst cd
	 */
	public void setRollOverInstCd(String rollOverInstCd) {
		this.rollOverInstCd = rollOverInstCd;
	}
	
	/**
	 * Gets the cheque book flag.
	 *
	 * @return the cheque book flag
	 */
	public String getChequeBookFlag() {
		return chequeBookFlag;
	}
	
	/**
	 * Sets the cheque book flag.
	 *
	 * @param chequeBookFlag the new cheque book flag
	 */
	public void setChequeBookFlag(String chequeBookFlag) {
		this.chequeBookFlag = chequeBookFlag;
	}
	
	/**
	 * Gets the relationship cd.
	 *
	 * @return the relationship cd
	 */
	public String getRelationshipCd() {
		return relationshipCd;
	}
	
	/**
	 * Sets the relationship cd.
	 *
	 * @param relationshipCd the new relationship cd
	 */
	public void setRelationshipCd(String relationshipCd) {
		this.relationshipCd = relationshipCd;
	}
	
	/**
	 * Gets the final mature dt.
	 *
	 * @return the final mature dt
	 */
	public Date getFinalMatureDt() {
		return finalMatureDt;
	}
	
	/**
	 * Sets the final mature dt.
	 *
	 * @param finalMatureDt the new final mature dt
	 */
	public void setFinalMatureDt(Date finalMatureDt) {
		this.finalMatureDt = finalMatureDt;
	}
	
	/**
	 * Gets the principal disposal cd.
	 *
	 * @return the principal disposal cd
	 */
	public String getPrincipalDisposalCd() {
		return principalDisposalCd;
	}
	
	/**
	 * Sets the principal disposal cd.
	 *
	 * @param principalDisposalCd the new principal disposal cd
	 */
	public void setPrincipalDisposalCd(String principalDisposalCd) {
		this.principalDisposalCd = principalDisposalCd;
	}
	
	/**
	 * Gets the last txn dt.
	 *
	 * @return the last txn dt
	 */
	public Date getLastTxnDt() {
		return lastTxnDt;
	}
	
	/**
	 * Sets the last txn dt.
	 *
	 * @param lastTxnDt the new last txn dt
	 */
	public void setLastTxnDt(Date lastTxnDt) {
		this.lastTxnDt = lastTxnDt;
	}
	
	/**
	 * Gets the notes.
	 *
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}
	
	/**
	 * Sets the notes.
	 *
	 * @param notes the new notes
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	/**
	 * Gets the deal dt.
	 *
	 * @return the deal dt
	 */
	public Date getDealDt() {
		return dealDt;
	}
	
	/**
	 * Sets the deal dt.
	 *
	 * @param dealDt the new deal dt
	 */
	public void setDealDt(Date dealDt) {
		this.dealDt = dealDt;
	}
	
	/**
	 * Gets the deal branch.
	 *
	 * @return the deal branch
	 */
	public String getDealBranch() {
		return dealBranch;
	}
	
	/**
	 * Sets the deal branch.
	 *
	 * @param dealBranch the new deal branch
	 */
	public void setDealBranch(String dealBranch) {
		this.dealBranch = dealBranch;
	}
	
	/**
	 * Gets the int pay due dt.
	 *
	 * @return the int pay due dt
	 */
	public Date getIntPayDueDt() {
		return intPayDueDt;
	}
	
	/**
	 * Sets the int pay due dt.
	 *
	 * @param intPayDueDt the new int pay due dt
	 */
	public void setIntPayDueDt(Date intPayDueDt) {
		this.intPayDueDt = intPayDueDt;
	}
	
	/**
	 * Gets the limit lien amt.
	 *
	 * @return the limit lien amt
	 */
	public Double getLimitLienAmt() {
		return limitLienAmt;
	}
	
	/**
	 * Sets the limit lien amt.
	 *
	 * @param limitLienAmt the new limit lien amt
	 */
	public void setLimitLienAmt(Double limitLienAmt) {
		this.limitLienAmt = limitLienAmt;
	}
	
	/**
	 * Gets the minimum repayment.
	 *
	 * @return the minimum repayment
	 */
	public Double getMinimumRepayment() {
		return minimumRepayment;
	}
	
	/**
	 * Sets the minimum repayment.
	 *
	 * @param minimumRepayment the new minimum repayment
	 */
	public void setMinimumRepayment(Double minimumRepayment) {
		this.minimumRepayment = minimumRepayment;
	}
	
	/**
	 * Gets the total effect limit.
	 *
	 * @return the total effect limit
	 */
	public Double getTotalEffectLimit() {
		return totalEffectLimit;
	}
	
	/**
	 * Sets the total effect limit.
	 *
	 * @param totalEffectLimit the new total effect limit
	 */
	public void setTotalEffectLimit(Double totalEffectLimit) {
		this.totalEffectLimit = totalEffectLimit;
	}
	
	/**
	 * Gets the cleared balance.
	 *
	 * @return the cleared balance
	 */
	public Double getClearedBalance() {
		return clearedBalance;
	}
	
	/**
	 * Sets the cleared balance.
	 *
	 * @param clearedBalance the new cleared balance
	 */
	public void setClearedBalance(Double clearedBalance) {
		this.clearedBalance = clearedBalance;
	}
	
	/**
	 * Gets the mas cd.
	 *
	 * @return the mas cd
	 */
	public String getMasCd() {
		return masCd;
	}
	
	/**
	 * Sets the mas cd.
	 *
	 * @param masCd the new mas cd
	 */
	public void setMasCd(String masCd) {
		this.masCd = masCd;
	}
	
	/**
	 * Gets the od class.
	 *
	 * @return the od class
	 */
	public String getOdClass() {
		return odClass;
	}
	
	/**
	 * Sets the od class.
	 *
	 * @param odClass the new od class
	 */
	public void setOdClass(String odClass) {
		this.odClass = odClass;
	}
	
	/**
	 * Gets the interest disposal cd.
	 *
	 * @return the interest disposal cd
	 */
	public String getInterestDisposalCd() {
		return interestDisposalCd;
	}
	
	/**
	 * Sets the interest disposal cd.
	 *
	 * @param interestDisposalCd the new interest disposal cd
	 */
	public void setInterestDisposalCd(String interestDisposalCd) {
		this.interestDisposalCd = interestDisposalCd;
	}
	
	/**
	 * Gets the date created.
	 *
	 * @return the date created
	 */
	public Date getDateCreated() {
		return dateCreated;
	}
	
	/**
	 * Sets the date created.
	 *
	 * @param dateCreated the new date created
	 */
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the date upd.
	 *
	 * @return the date upd
	 */
	public Date getDateUpd() {
		return dateUpd;
	}
	
	/**
	 * Sets the date upd.
	 *
	 * @param dateUpd the new date upd
	 */
	public void setDateUpd(Date dateUpd) {
		this.dateUpd = dateUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the sadiq flag.
	 *
	 * @return the sadiq flag
	 */
	public String getSadiqFlag() {
		return sadiqFlag;
	}
	
	/**
	 * Sets the sadiq flag.
	 *
	 * @param sadiqFlag the new sadiq flag
	 */
	public void setSadiqFlag(String sadiqFlag) {
		this.sadiqFlag = sadiqFlag;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public String getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	
	
	
}
