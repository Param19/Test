package com.scb.channels.common.dao;

import com.scb.channels.common.vo.BatchAccBalVO;

/**
 * The Interface BatchAccBalDAO.
 */
public interface BatchAccBalDAO {
	
	/**
	 * Gets the Batch Account Balance.
	 *
	 * @param id the id
	 * @param custId the cust id
	 * @return the BatchAccBalVO
	 */
	BatchAccBalVO getBatchAccountBalance(String accNo,String custId);

}
