/**
 * 
 */
package com.scb.channels.common.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.common.service.ChannelCommonService;
import com.scb.channels.common.vo.ChannelMaskPolicyVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.dao.ChannelCommonDAO;
import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.exception.MaskException;


/**
 * The Interface MessageTransformerService.
 *
 * @author 1382158
 */
public class ChannelCommonServiceImpl implements ChannelCommonService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelCommonServiceImpl.class);
	
	private ChannelCommonDAO channelCommonDAO;

	public List<ChannelMaskPolicyVO> getChannelMaskPolicy(String typeCode,String categoryCode,
			ClientVO clientVO) throws MaskException {
		// TODO Auto-generated method stub
		List<ChannelMaskPolicyVO> channelMaskPolicyList=null;
		//Caching Logic needs to be implemented
		try {
			 channelMaskPolicyList=channelCommonDAO.getChannelMaskPolicy(typeCode,categoryCode, clientVO);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception occurred ::: ",e);
		}
		return channelMaskPolicyList;
	}
	
	 public ChannelMaskPolicyVO getChannelMaskPolicyForField(String typeCode, String categoryCode, ClientVO clientVO, String fieldName) throws MaskException{
		 ChannelMaskPolicyVO channelMaskPolicy=null;
		 
		 try {
			 channelMaskPolicy=channelCommonDAO.getChannelMaskPolicyForField(typeCode, categoryCode, clientVO, fieldName);
			} catch (DAOException e) {
				// TODO Auto-generated catch block
				LOGGER.error("Exception occurred ::: ",e);
			}
			return channelMaskPolicy;
	 }
	
	public List<ChannelMaskPolicyVO> getAllMaskPolicy(String typeCode) throws MaskException{
		// TODO Auto-generated method stub
				List<ChannelMaskPolicyVO> channelMaskPolicyList=null;
				//Caching Logic needs to be implemented
				try {
					channelMaskPolicyList=channelCommonDAO.getAllMaskPolicy(typeCode);
				} catch (DAOException e) {
					// TODO Auto-generated catch block
					LOGGER.error("Exception occurred ::: ",e);
				}
				return channelMaskPolicyList;
	}
	
	

	public ChannelCommonDAO getchannelCommonDAO() {
		return channelCommonDAO;
	}

	public void setchannelCommonDAO(ChannelCommonDAO channelCommonDAO) {
		this.channelCommonDAO = channelCommonDAO;
	}

	
	
	}
