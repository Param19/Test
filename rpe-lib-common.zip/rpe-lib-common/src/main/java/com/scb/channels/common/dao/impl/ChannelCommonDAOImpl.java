package com.scb.channels.common.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.dao.ChannelCommonDAO;
import com.scb.channels.common.vo.ChannelMaskPolicyVO;



/**
 * The Class ChannelBaseDAOImpl.
 */
public class ChannelCommonDAOImpl extends HibernateDaoSupport implements ChannelCommonDAO {

	
	public List<ChannelMaskPolicyVO> getChannelMaskPolicy(String typeCode,String categoryCode, ClientVO clientVO) throws DAOException {
		// TODO Auto-generated method stub
		
		Criteria criteria = getSession().createCriteria(ChannelMaskPolicyVO.class)
                .add(Restrictions.eq("channelId", clientVO.getChannel()))
                .add(Restrictions.eq("country",clientVO.getCountry()))
                .add(Restrictions.eq("categoryCode", categoryCode))
                .add(Restrictions.eq("typeCode", typeCode))	;
//               
        return criteria.list();

		
	}

	 public ChannelMaskPolicyVO getChannelMaskPolicyForField(String typeCode, String categoryCode, ClientVO clientVO, String fieldName){
		 
		 Criteria criteria = getSession().createCriteria(ChannelMaskPolicyVO.class)
	                .add(Restrictions.eq("channelId", clientVO.getChannel()))
	                .add(Restrictions.eq("country",clientVO.getCountry()))
	                .add(Restrictions.eq("categoryCode", categoryCode))
	                .add(Restrictions.eq("typeCode", typeCode))
	                .add(Restrictions.eq("fieldName",fieldName));
		 
		 List<ChannelMaskPolicyVO> list= criteria.list();
			if (CollectionUtils.isEmpty(list)) {
				return null;
			} else {
				return list.get(0);
			}
//	               
	        
	 }
	
	public List<ChannelMaskPolicyVO> getAllMaskPolicy(String typeCode)
			throws DAOException {
		// TODO Auto-generated method stub
		Criteria criteria = getSession().createCriteria(ChannelMaskPolicyVO.class)
                .add(Restrictions.eq("typeCode", typeCode))	;
//               
        return criteria.list();
	}
	
	
}
