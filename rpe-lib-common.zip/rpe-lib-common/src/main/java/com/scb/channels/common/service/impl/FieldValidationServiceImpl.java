/**
 * 
 */
package com.scb.channels.common.service.impl;

import java.util.List;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.exception.MaskException;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.dao.FieldValidationDAO;
import com.scb.channels.common.service.FieldValidationService;
import com.scb.channels.common.vo.FieldValidationVO;



public class FieldValidationServiceImpl implements FieldValidationService {

	private FieldValidationDAO fieldValidationDAO;	

	/**
	 * EH cachemanager service
	 */
	private CacheManager cacheManager;

	private static final Logger LOGGER = LoggerFactory.getLogger(FieldValidationServiceImpl.class);

	public List<FieldValidationVO> getfieldValidationList(String module, String status, String baseObject, ClientVO clientVO) throws MaskException {		
		List<FieldValidationVO> fieldValidationList=null;
		try {

			if(cacheManager.getCache(CommonConstants.FIELD_VALIDATION).get(CommonConstants.FIELD_VALIDATION+clientVO.getCountry()+baseObject)==null){
				LOGGER.debug("Calling DB due to no field validation list Available on  cache  ");
				fieldValidationList=fieldValidationDAO.getfieldValidationList(module,status, baseObject, clientVO);

				if(fieldValidationList !=null && fieldValidationList.size()>0){
					LOGGER.debug("getting  the field validation list into DB");
					cacheManager.getCache(CommonConstants.FIELD_VALIDATION).put(new Element(CommonConstants.FIELD_VALIDATION+clientVO.getCountry()+baseObject , fieldValidationList));
				}else{
					LOGGER.debug("No field validation list AVAILABLE in DB as well");
				}

			}else{
				LOGGER.debug("field validation list AVAILABLE in Cache");
				fieldValidationList =(List<FieldValidationVO>)cacheManager.getCache(CommonConstants.FIELD_VALIDATION).get(CommonConstants.FIELD_VALIDATION+clientVO.getCountry()+baseObject).getValue();
			}

		} catch (DAOException e) {			
			e.printStackTrace();
		}
		return fieldValidationList;
	}	

	public FieldValidationDAO getFieldValidationDAO() {
		return fieldValidationDAO;
	}

	public void setFieldValidationDAO(FieldValidationDAO fieldValidationDAO) {
		this.fieldValidationDAO = fieldValidationDAO;
	}

	public CacheManager getCacheManager() {
		return cacheManager;
	}

	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}
}
