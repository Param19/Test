package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.CrossCurrencyDAO;
import com.scb.channels.common.vo.CrossCurrencyVO;

/**
 * The Class CrossCurrencyDAOImpl.
 */
public class CrossCurrencyDAOImpl extends HibernateDaoSupport implements CrossCurrencyDAO {

	/**
	 * Gets the cross currency list.
	 * 
	 * @param channelCD
	 *            the channel cd
	 * @param countyrCD
	 *            the countyr cd
	 * @param statusCD
	 *            the status cd
	 * @return the cross currency list
	 * @see com.scb.channels.common.dao.CrossCurrencyDAO#getCrossCurrencyList(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public List<CrossCurrencyVO> getCrossCurrencyList(String channelCD,String countyrCD,String statusCD) {
		Criteria criteria = getSession().createCriteria(CrossCurrencyVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, channelCD));
		criteria.add(Restrictions.eq(HibernateHelper.CTRY_CD, countyrCD));
		criteria.add(Restrictions.eq(HibernateHelper.IS_ALLOWED, "Y"));
		criteria.add(Restrictions.eq(HibernateHelper.STATUS_CD, statusCD));
		return criteria.list();
	}
	
	/**
	 * Gets the cross currency list.
	 * 
	 * @param channelCD
	 *            the channel cd
	 * @param countyrCD
	 *            the countyr cd
	 * @param statusCD
	 *            the status cd
	 * @return the cross currency list
	 * @see com.scb.channels.common.dao.CrossCurrencyDAO#getCrossCurrencyList(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public List<CrossCurrencyVO> getCrossCurrencyList(String countyrCD,String statusCD) {
		Criteria criteria = getSession().createCriteria(CrossCurrencyVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CTRY_CD, countyrCD));
		criteria.add(Restrictions.eq(HibernateHelper.IS_ALLOWED, "Y"));
		criteria.add(Restrictions.eq(HibernateHelper.STATUS_CD, statusCD));
		return criteria.list();
	}

	
}
