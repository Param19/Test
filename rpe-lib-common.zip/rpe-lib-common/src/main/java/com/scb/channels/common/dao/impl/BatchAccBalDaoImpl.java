package com.scb.channels.common.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchAccBalDAO;
import com.scb.channels.common.vo.BatchAccBalVO;

/**
 * The Class BatchAccBalDaoImpl.
 */
public class BatchAccBalDaoImpl extends HibernateDaoSupport implements BatchAccBalDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchAccBalDAO#getBatchAccountBalance(java.lang.String, java.lang.String)
	 */
	public BatchAccBalVO getBatchAccountBalance(String accNo,String custId) {
		Criteria criteria = getSession().createCriteria(BatchAccBalVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.ACC_NUM, accNo));
		List<BatchAccBalVO> list= criteria.list();
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list.get(0);
		}
	}
	
}
