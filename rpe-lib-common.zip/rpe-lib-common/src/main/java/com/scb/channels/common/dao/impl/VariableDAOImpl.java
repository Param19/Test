package com.scb.channels.common.dao.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.common.dao.VariableDAO;
import com.scb.channels.common.vo.VariablesVO;


/*
 * 
 * Retrives all the VO's
 * 
 */

public class VariableDAOImpl extends HibernateDaoSupport  implements VariableDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(VariableDAOImpl.class);
	/* 
	 * @return the List of VariablesVO  beans/ row by every VO.
	 */
	public List<VariablesVO> getSystemVaribale() {
		List<VariablesVO> variable=null;
		Session session = null;
		Criteria condition = null;
		try {
	    session = getHibernateTemplate().getSessionFactory().openSession();
	    condition=session.createCriteria(VariablesVO.class);
		
		condition.add(Restrictions.eq("status", CommonConstants.ACTIVE));
		variable=condition.list();
		}catch (Exception exception){
			 LOGGER.info("Exception occurred duirng getSystemVaribale ::: " + exception);
		}
		 finally {
			 if(session!=null&& session.isOpen()){
				 LOGGER.info("Session ExplicitttttttttD Close : getSystemVaribale::Variable DAO  ::: " );
				 session.close();
			 }
		 }
		return variable ;
	}

	@Override
	public VariablesVO getValuefromkey(String CountryCode,String channelId,String key) {
		VariablesVO variable=null;
		List variableList=null;
		Session session = null;
		Criteria condition = null;
		try {
			  session = getHibernateTemplate().getSessionFactory().openSession();
				 condition=session.createCriteria(VariablesVO.class);
		condition.add(Restrictions.eq("variableName", key));
		if(StringUtils.isNotBlank(CountryCode)){
			condition.add(Restrictions.eq("countryCode", CountryCode));
		}
		if(StringUtils.isNotBlank(channelId)){
			condition.add(Restrictions.eq("channelCode", channelId));
		}
		
		variableList=condition.list();
		if(variableList.size()>0){
			variable =(VariablesVO) condition.list().get(0);
		}
		}catch (Exception exception){
			LOGGER.info("Exception occurred duirng getValuefromkey ::: " + exception);
		}
		 finally {
			 if(session!=null&& session.isOpen()){
				 LOGGER.info("Session ExplicitttttttttE Close : getValuefromkey::Variable DAO  ::: " );
				 session.close();
			 }
		 }
		return variable;
	}
	
	@Override
	public List<VariablesVO> getValuesPerkey(String CountryCode,String channelId,String key) {
		// TODO Auto-generated method stub
		Criteria condition=getHibernateTemplate().getSessionFactory().openSession().createCriteria(VariablesVO.class);
		condition.add(Restrictions.eq("variableName", key));
		return  condition.list();
	}

	@Override
	public void update(VariablesVO variablesVO) {
		getHibernateTemplate().update(variablesVO);
	}

}
