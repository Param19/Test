package com.scb.channels.common.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * The Class BatchAccRelVO.
 */
public class BatchAccRelVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8431012975587703332L;
	
	/** The id. */
	private Integer id;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The cust group id. */
	private String custGroupId;
	
	/** The prod cd. */
	private String prodCd;
	
	/** The acct no. */
	private String acctNo;
	
	/** The currency cd. */
	private String currencyCd;
	
	/** The acct rel cd. */
	private String acctRelCd;
	
	/** The acct status cd. */
	private String acctStatusCd;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private BigDecimal version;
	
	/** The acct date close. */
	private Date acctDateClose;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the acct date close.
	 *
	 * @return the acct date close
	 */
	public Date getAcctDateClose() {
		return acctDateClose;
	}
	
	/**
	 * Sets the acct date close.
	 *
	 * @param acctDateClose the new acct date close
	 */
	public void setAcctDateClose(Date acctDateClose) {
		this.acctDateClose = acctDateClose;
	}

	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the cust group id.
	 *
	 * @return the cust group id
	 */
	public String getCustGroupId() {
		return custGroupId;
	}
	
	/**
	 * Sets the cust group id.
	 *
	 * @param custGroupId the new cust group id
	 */
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	
	/**
	 * Gets the prod cd.
	 *
	 * @return the prod cd
	 */
	public String getProdCd() {
		return prodCd;
	}
	
	/**
	 * Sets the prod cd.
	 *
	 * @param prodCd the new prod cd
	 */
	public void setProdCd(String prodCd) {
		this.prodCd = prodCd;
	}
	
	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}
	
	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	/**
	 * Gets the currency cd.
	 *
	 * @return the currency cd
	 */
	public String getCurrencyCd() {
		return currencyCd;
	}
	
	/**
	 * Sets the currency cd.
	 *
	 * @param currencyCd the new currency cd
	 */
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	
	/**
	 * Gets the acct rel cd.
	 *
	 * @return the acct rel cd
	 */
	public String getAcctRelCd() {
		return acctRelCd;
	}
	
	/**
	 * Sets the acct rel cd.
	 *
	 * @param acctRelCd the new acct rel cd
	 */
	public void setAcctRelCd(String acctRelCd) {
		this.acctRelCd = acctRelCd;
	}
	
	/**
	 * Gets the acct status cd.
	 *
	 * @return the acct status cd
	 */
	public String getAcctStatusCd() {
		return acctStatusCd;
	}
	
	/**
	 * Sets the acct status cd.
	 *
	 * @param acctStatusCd the new acct status cd
	 */
	public void setAcctStatusCd(String acctStatusCd) {
		this.acctStatusCd = acctStatusCd;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public BigDecimal getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(BigDecimal version) {
		this.version = version;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}


	
}
