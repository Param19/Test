package com.scb.channels.common.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.exception.MaskException;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonMaskEncoder;
import com.scb.channels.base.helper.Masker;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.service.ChannelCommonService;
import com.scb.channels.common.vo.ChannelMaskPolicyVO;


/**
 * The class ChannelMaskHelper.
 *
 * @author 1382158
 */
public class ChannelMaskHelper {
	
	public static final String ASTERIK = "*";

	public static final String NUMERIC_REGEX = "[^0-9]+";

	/** The channel common service. */
	private ChannelCommonService channelCommonService;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelMaskHelper.class);
	
	/**
	 * content - String to masked
	 * contentName - Property Name, exp. accountnumber
	 * typeCode - OTP,Logger,Notification
	 * clientVO - channelInfo
	 *
	 * @param content the content
	 * @param maskLength the mask length
	 * @param startPoint the start point
	 * @param endPoint the end point
	 * @param pattern the pattern
	 * @return the string
	 */
   
	public String maskString(String content,int maskLength,int startPoint, int endPoint,String pattern ){	
		if(pattern.equals(CommonConstants.MASK_EXCEPT_RIGHT)){
			content=maskExceptRightOperation(content,maskLength);
		} else if(pattern.equals(CommonConstants.MASK_EXCEPT_LEFT)){
			content=maskExceptLeftOperation(content,maskLength);
		} else if(pattern.equals(CommonConstants.MASK_MIDDLE)){
			content= maskMiddleOperation(content,startPoint,endPoint);
		} else if(pattern.equals(CommonConstants.MASK_ALL)){
			content=maskAllOperation(content);
		}
		return content;		
	}
	
	/**
	 * content - ValueObject to masked
	 * typeCode - OTP,Logger,Notification
	 * clientVO - channelInfo.
	 *
	 * @param content the content
	 * @param typeCode the type code
	 * @param categoryCode the category code
	 * @param clientVO the client vo
	 * @return the object
	 */

/*	public Object maskObject(Object content,String typeCode,String categoryCode,ClientVO clientVO ){
		List<ChannelMaskPolicyVO> channelPolicyList= null;
		try {
			channelPolicyList=channelCommonService.getChannelMaskPolicy(typeCode,categoryCode, clientVO);
		} catch (MaskException e) {
			LOGGER.error(e.getMessage(), e.getCause());
		}
		return content;
	}*/
	
	/**
	 * parameters - key,value pair to masked
	 * typeCode - OTP,Logger,Notification
	 * clientVO - channelInfo.
	 *
	 * @param parameters the parameters
	 * @param typeCode the type code
	 * @param categoryCode the category code
	 * @param clientVO the client vo
	 * @return the map
	 */
	
	public Map<String, String> maskMap(Map<String, String> parameters,String typeCode,String categoryCode,ClientVO clientVO ){
		List<ChannelMaskPolicyVO> channelPolicyList= null;
		int startPoint=0;
		int endPoint=0;
		int maskLength=0;
		List<String> keyOrder= new ArrayList<String>();
		Map<String,String> result= new HashMap<String,String>();
		for (Map.Entry<String,String> entry : parameters.entrySet()) {
			keyOrder.add((String)entry.getKey());
		}
		
		try {
			
			LOGGER.info("typeCode, categoryCode, clientVO.country: {} {} {}", new Object[]{typeCode, categoryCode, clientVO.getCountry()});
			channelPolicyList=channelCommonService.getChannelMaskPolicy(typeCode,categoryCode,clientVO);
			
			List<ChannelMaskPolicyVO> channelPolicyFilterList=new ArrayList<ChannelMaskPolicyVO>();
			
			for(ChannelMaskPolicyVO channelMaskPolicyVO: channelPolicyList){
				for (Map.Entry<String,String> entry : parameters.entrySet()) {
					if(channelMaskPolicyVO.getFieldName().equals(entry.getKey())){
						channelPolicyFilterList.add(channelMaskPolicyVO);
					}
				}
			}
			
			for(ChannelMaskPolicyVO channelMaskPolicyVO:channelPolicyFilterList){
				if(channelPolicyFilterList.contains(channelMaskPolicyVO)) {
					String patternWithLength= channelMaskPolicyVO.getPattern();
					if(getMaskRange(patternWithLength).size()==2){
						startPoint= Integer.parseInt(getMaskRange(patternWithLength).get(0));
						endPoint= Integer.parseInt(getMaskRange(patternWithLength).get(1));
						maskLength=endPoint-startPoint+1;
					} else {
						startPoint=0;
						endPoint=0;
						maskLength=Integer.parseInt(getMaskRange(patternWithLength).get(0));
					}
					String pattern=getPattern(patternWithLength);
					parameters.put(channelMaskPolicyVO.getFieldName(), maskString(parameters.get(channelMaskPolicyVO.getFieldName()),maskLength,startPoint, endPoint,pattern ));
				}
			}
			
		} catch (MaskException e) {
			LOGGER.error(e.getMessage(), e.getCause());
		}
		
		for(int i=0;i<keyOrder.size();i++){
			result.put(keyOrder.get(i),parameters.get(keyOrder.get(i)));
		}
		return result;
	}
	
	/**
	 * Gets the pattern.
	 *
	 * @param patternWithLength the pattern with length
	 * @return the pattern
	 */
	public String getPattern(String patternWithLength) {
		return patternWithLength.substring(0, 2);
	}

	/**
	 * Gets the logger mask policy.
	 *
	 * @return the logger mask policy
	 */
	public List<ChannelMaskPolicyVO> getLoggerMaskPolicy() {
		List<ChannelMaskPolicyVO> channelMaskPolicyList=null;
		String typeCode="Logger";
		//Caching Logic needs to be implemented
		try {
			channelMaskPolicyList=	channelCommonService.getAllMaskPolicy(typeCode);
		} catch (MaskException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception occurred ::: ",e);
		}
		return channelMaskPolicyList;
	}
	
	/**
	 * Inits the.
	 */
	public void init() {
		List<ChannelMaskPolicyVO> channelMaskPolicyList = getLoggerMaskPolicy();
		for (ChannelMaskPolicyVO channelMaskPolicyVO : channelMaskPolicyList) {
			channelMaskPolicyVO.getCountry();
			channelMaskPolicyVO.getCategoryCode();
			String key = channelMaskPolicyVO.getCountry() + CommonConstants.HYPHEN + channelMaskPolicyVO.getCategoryCode();
			if (CommonMaskEncoder.maskerMaster.containsKey(key)) {
				List<Masker> maskerMasterList = CommonMaskEncoder.maskerMaster.get(key);
				Masker m = new Masker(channelMaskPolicyVO.getFieldName(), channelMaskPolicyVO.getGroupCode() , channelMaskPolicyVO.getPattern());
				maskerMasterList.add(m);
			} else {
				List<Masker> value = new ArrayList<Masker>();
				Masker m = new Masker(channelMaskPolicyVO.getFieldName(), channelMaskPolicyVO.getGroupCode() , channelMaskPolicyVO.getPattern());
				value.add(m);
				CommonMaskEncoder.maskerMaster.put(key, value);
			}
		}
		CommonMaskEncoder.reloadMaskDetails();
	}
	
	/**
	 * Mask all operation.
	 *
	 * @param content the content
	 * @return the string
	 */
	public String maskAllOperation(String content){
		StringBuilder result= new StringBuilder(CommonConstants.EMPTY);
		for (int i=0; i<content.length();i++){
			result.append(ASTERIK);
		}
		return result.toString();
	}
	
	/**
	 * Mask except right operation.
	 *
	 * @param content the content
	 * @param maskLength the mask length
	 * @return the string
	 */
	public String maskExceptRightOperation(String content, int maskLength){
		
		String noMaskPart=content.substring((content.length()-maskLength), content.length());
		StringBuilder result= new StringBuilder(CommonConstants.EMPTY);
		for (int i=0; i<content.length()-maskLength;i++){
			result.append(ASTERIK);
		}
		result.append(noMaskPart);
		return result.toString();
	}
	
	/**
	 * Mask except left operation.
	 *
	 * @param content the content
	 * @param maskLength the mask length
	 * @return the string
	 */
	public String maskExceptLeftOperation(String content, int maskLength){
		
		String noMaskPart=content.substring(0,maskLength);
		StringBuilder result= new StringBuilder(noMaskPart);
		for (int i=0; i<content.length()-maskLength;i++){
			result.append(ASTERIK);
		}
		return result.toString();
	}
	
	
	/**
	 * Mask middle operation.
	 *
	 * @param content the content
	 * @param startPoint the start point
	 * @param endPoint the end point
	 * @return the string
	 */
	public String maskMiddleOperation(String content, int startPoint, int endPoint){
		
		String noMaskPart1=content.substring(0,startPoint-1);
		String noMaskPart2=content.substring(endPoint,content.length());
		StringBuilder result= new StringBuilder(noMaskPart1);
		for (int i=0; i<endPoint-startPoint+1;i++){
			result.append(ASTERIK);
		}
		result.append(noMaskPart2);
		return result.toString();
	}
	
	/**
	 * Gets the mask range.
	 *
	 * @param pattern the pattern
	 * @return the mask range
	 */
	public List<String> getMaskRange(String pattern){
		pattern = pattern.replaceAll(NUMERIC_REGEX, CommonConstants.SPACE);
		return (Arrays.asList(pattern.trim().split(CommonConstants.SPACE)));
	}

	/**
	 * Gets the channel common service.
	 *
	 * @return the channel common service
	 */
	public ChannelCommonService getchannelCommonService() {
		return channelCommonService;
	}

	/**
	 * Sets the channel common service.
	 *
	 * @param channelCommonService the new channel common service
	 */
	public void setchannelCommonService(ChannelCommonService channelCommonService) {
		this.channelCommonService = channelCommonService;
	}

	
	

}
