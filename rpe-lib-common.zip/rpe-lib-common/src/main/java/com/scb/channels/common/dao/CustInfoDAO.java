package com.scb.channels.common.dao;
import com.scb.channels.base.vo.CustInfoVO;
import com.scb.channels.base.vo.CustomerDetailsVO;

/**
 * The Interface CustInfoDAO.
 */
public interface CustInfoDAO {
	
	/**
	 * Save.
	 *
	 * @param custinfovo the custinfovo
	 */
	void save(CustInfoVO custinfovo);
	
	/**
	 * Update.
	 *
	 * @param custinfovo the custinfovo
	 */
	void update(CustInfoVO custinfovo);
	
	/**
	 * Gets the customer info.
	 *
	 * @param CountryCode the country code
	 * @param MobileNumber the mobile number
	 * @return the customer Info
	 */
	CustInfoVO getCustomerInfo(String CountryCode ,String MobileNumber);
	
	/**
	 * Gets the customer information.
	 *
	 * @param relno the relno
	 * @return the customer Info for relationship
	 */
	CustInfoVO getCustomerInfoForRelationship(String relno);
	
	/**
	 * Update opr account.
	 *
	 * @param custInfo the cust info
	 */
	void updateOprAccount(CustInfoVO custInfo);	
	
	/**
	 * Update default account.
	 *
	 * @param custInfo the cust info
	 */
	void updateDefaultAccount(CustInfoVO custInfo);	
	
	/**
	 * update Customer Detail.
	 *
	 * @param customerDetailsVO the customer details vo
	 */
	void updateCustDetail(CustomerDetailsVO customerDetailsVO);
}
