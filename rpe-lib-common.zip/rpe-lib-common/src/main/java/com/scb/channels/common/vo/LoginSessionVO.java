package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class LoginSessionVO.
 */
public class LoginSessionVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3572392323602035904L;
	
	/** The id. */
	private Integer id;
	
	/** The user id. */
	private String userId;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The system type. */
	private String systemType;
	
	/** The session id. */
	private String sessionId;
	
	/** The channel. */
	private String channel;
	
	/** The environment. */
	private String environment;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The dt upd. */
	private Date dtUpd;
	
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the system type.
	 *
	 * @return the system type
	 */
	public String getSystemType() {
		return systemType;
	}
	
	/**
	 * Sets the system type.
	 *
	 * @param systemType the new system type
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	/**
	 * Gets the session id.
	 *
	 * @return the session id
	 */
	public String getSessionId() {
		return sessionId;
	}
	
	/**
	 * Sets the session id.
	 *
	 * @param sessionId the new session id
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the new channel
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	
	/**
	 * Sets the environment.
	 *
	 * @param environment the new environment
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
    
	
	
}
