package com.scb.channels.common.filters.impl;

import com.scb.channels.common.filters.FilterCondition;
import com.scb.channels.common.filters.FilterOperation;
import com.scb.channels.common.filters.FilterType;

/**
 * The Class FailTransactionFilterCondition.
 */
public class FailTransactionFilterCondition implements FilterCondition {
	
	/** The property. */
	private String property;
	
	/** The value. */
	private String value;

	/**
	 * Gets the filter type.
	 *
	 * @return the filter type
	 */
	public FilterType getFilterType() {
		return FilterType.CHECK_AND_PASS;
	}

	/**
	 * Gets the operation.
	 *
	 * @return the operation
	 */
	public FilterOperation getOperation() {
		return FilterOperation.LIST_NOTCONTAINS;
	}

	/**
	 * Gets the property.
	 *
	 * @return the property
	 */
	public String getProperty() {
		return this.property;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * Sets the property.
	 *
	 * @param property the property to set
	 */
	public void setProperty(String property) {
		this.property = property;
	}

	/**
	 * Sets the value.
	 *
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

}
