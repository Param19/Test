/**
 * 
 */
package com.scb.channels.common.service;

import java.util.List;
import java.util.Map;

import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.common.vo.ReferenceVO;

/**
 * The Interface ReferenceService.
 */
public interface ReferenceService {

	/**
	 * Save reference.
	 *
	 * @param referenceVO the reference vo
	 */
	void saveReference(ReferenceVO referenceVO);

	/**
	 * Update reference.
	 *
	 * @param referenceVO the reference vo
	 */
	void updateReference(ReferenceVO referenceVO);

	/**
	 * Delete reference.
	 *
	 * @param referenceVO the reference vo
	 */
	void deleteReference(ReferenceVO referenceVO);

	/**
	 * Gets the reference.
	 *
	 * @param referenceVO the reference vo
	 * @return the reference
	 */
	ReferenceVO getReference(ReferenceVO referenceVO);
	
	/**
	 * Gets the reference list.
	 *
	 * @param referenceVO the reference vo
	 * @return the reference list
	 */
	 Map<String, String> getReferenceMap(ReferenceVO referenceVO);
	 /**
 	 * Gets the currency.
 	 *
 	 * @param country the country
 	 * @return the currency
 	 */
 	List<ISOCODESVO> getCurrency(String country);
 	
 	/**
 	 * Gets the precision currency.
 	 *
 	 * @param country the currencyCode
 	 * @return the precision currency
 	 */
 	List<ISOCODESVO> getPrecisionCurrency(String currencyCode);
 	
 	/**
 	 * Get customized Message
 	 * @param country
 	 * @param channel
 	 * @param component
 	 * @param module
 	 * @return
 	 */
 	public Map<String, ApplicationMessageVO> getCustomizedMessages(String country,String channel,String component, String module);

}
