/**
 * 
 */
package com.scb.channels.common.service;

import com.scb.channels.base.vo.TransactionInfoVO;

/**
 * The Interface LimitService.
 *
 * @author 1411807
 */
public interface LimitService {
	
	/**
	 * Checks if is limit available.
	 *
	 * @param info the info
	 * @return true, if is limit available
	 */
	boolean isLimitAvailable(TransactionInfoVO info);

}
