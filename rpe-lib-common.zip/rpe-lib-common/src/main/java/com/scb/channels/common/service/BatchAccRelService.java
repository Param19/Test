package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.common.vo.BatchAccRelVO;

/**
 * The Interface BatchAccRelService.
 */
public interface BatchAccRelService {
	
	/**
	 * Gets the batch account rel.
	 *
	 * @param batchAccRelVO the batch acc rel vo
	 * @return the batch account rel
	 */
	List<BatchAccRelVO> getBatchAccountRel(BatchAccRelVO batchAccRelVO);

}
