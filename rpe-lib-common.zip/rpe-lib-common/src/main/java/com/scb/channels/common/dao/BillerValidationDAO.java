package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.BillerValidationVO;

public interface BillerValidationDAO {
	
	 BillerValidationVO get( String billerField,String ctryCd,String billerCd);
	 
	 List<BillerValidationVO> getByctryCdAndBillerCd (String ctryCd,String billerCd);
}
