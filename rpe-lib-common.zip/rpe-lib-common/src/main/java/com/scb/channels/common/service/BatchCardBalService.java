package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.common.vo.BatchCardBalVO;

/**
 * The Interface BatchCardBalService.
 */
public interface BatchCardBalService {
	
	/**
	 * Gets the batch card bal.
	 *
	 * @param batchCardBalVO the batch card bal vo
	 * @return the batch card bal
	 */
	List<BatchCardBalVO> getBatchCardBal(BatchCardBalVO batchCardBalVO);

}
