/**
 * 
 */
package com.scb.channels.common.filters;

/**
 * The Interface FilterCondition.
 *
 * @author 1411807
 */
public interface FilterCondition {

	/**
	 * Gets the property.
	 *
	 * @return the property
	 */
	String getProperty();
	
	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	String getValue();
	
	/**
	 * Gets the operation.
	 *
	 * @return the operation
	 */
	FilterOperation getOperation();
	
	/**
	 * Gets the filter type.
	 *
	 * @return the filter type
	 */
	FilterType getFilterType();
}
