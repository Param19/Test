package com.scb.channels.common.ws.interceptor;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.cxf.common.util.Base64Utility;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

/**
 * The Class HttpHeaderInterceptor.
 */
public class HttpHeaderInterceptor extends AbstractPhaseInterceptor<Message> {

/** The Constant AUTHORIZATION. */
public static final String AUTHORIZATION = "Authorization";

/** The Constant BASIC. */
public static final String BASIC = "Basic ";

/** The usern name. */
private String usernName;

/** The password. */
private String password;



/**
 * Instantiates a new http header interceptor.
 */
public HttpHeaderInterceptor() {
    super(Phase.POST_PROTOCOL);
}

/* (non-Javadoc)
 * @see org.apache.cxf.interceptor.Interceptor#handleMessage(org.apache.cxf.message.Message)
 */
public void handleMessage(Message message) throws Fault {
    Map<String, List> headers = (Map<String, List>) message.get(Message.PROTOCOL_HEADERS);
    try {
        String value = BASIC + Base64Utility.encode((usernName+":"+password).getBytes());
        headers.put(AUTHORIZATION, Collections.singletonList(value));
        
    } catch (Exception ce) {
        throw new Fault(ce);
    }
}

/**
 * Gets the usern name.
 *
 * @return the usern name
 */
public String getUsernName() {
	return usernName;
}

/**
 * Sets the usern name.
 *
 * @param usernName the new usern name
 */
public void setUsernName(String usernName) {
	this.usernName = usernName;
}

/**
 * Gets the password.
 *
 * @return the password
 */
public String getPassword() {
	return password;
}

/**
 * Sets the password.
 *
 * @param password the new password
 */
public void setPassword(String password) {
	this.password = password;
}


}
