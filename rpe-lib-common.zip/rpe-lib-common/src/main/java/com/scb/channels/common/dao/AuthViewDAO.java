package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.AuthViewVO;

/**
 * The Interface AuthViewDAO.
 */
public interface AuthViewDAO {
 
	/**
	 * Gets the.
	 *
	 * @param userId the user id
	 * @param userPswd the user pswd
	 * @param ctryCd the ctry cd
	 * @param systemType the system type
	 * @param langCd the lang cd
	 * @return the auth view vo
	 */
	AuthViewVO get(String userId ,String userPswd,String ctryCd,String systemType,String langCd);
	
	/**
	 * Gets the all.
	 *
	 * @param userId the user id
	 * @param userPswd the user pswd
	 * @param ctryCd the ctry cd
	 * @param systemType the system type
	 * @param langCd the lang cd
	 * @param functionName the function name
	 * @return the all
	 */
	List<AuthViewVO> getAll(String userId ,String userPswd,String ctryCd,String systemType,String langCd, String functionName);
}
