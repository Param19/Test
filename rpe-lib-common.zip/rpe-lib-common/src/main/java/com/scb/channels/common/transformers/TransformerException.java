package com.scb.channels.common.transformers;

/**
 * The Class TransformerException.
 */
public class TransformerException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 958904050619605001L;
	
	/**
	 * Instantiates a new transformer exception.
	 *
	 * @param e the e
	 */
	public TransformerException(Throwable e) {
		super(e);
	}
	
	
	/**
	 * Instantiates a new transformer exception.
	 * 
	 * @param message
	 *            the message
	 * @param e
	 *            the e
	 */
	public TransformerException(String message, Throwable e) {
		super(message, e);
	}
}
