package com.scb.channels.common.validation.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.validation.Validator;


/**
 * The Class CurrencyValidator.
 */
public class CurrencyValidator implements Validator {
	
	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private String property;
	
	/** The currency list. */
	private List<String> currencyList = new ArrayList<String>();
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CurrencyValidator.class);

	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.Validator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;

	}

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.Validator#validate()
	 */
	public void validate() throws ValidatorException {
		try {
			String currencyField = (String) PropertyUtils.getProperty(bean,	property);
			if (!currencyList.contains(currencyField)) {
				
				throw new ValidatorException(
						"Not expected currency..."+currencyField);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new ValidatorException("Property Conversion error...");
		}

	}

	/**
	 * Gets the bean.
	 *
	 * @return the bean
	 */
	public PayloadDTO getBean() {
		return bean;
	}

	/**
	 * Gets the property.
	 *
	 * @return the property
	 */
	public String getProperty() {
		return property;
	}

	/**
	 * Sets the property.
	 *
	 * @param property the property to set
	 */
	public void setProperty(String property) {
		this.property = property;
		Properties entries=null;
		try {
			entries = org.springframework.core.io.support.PropertiesLoaderUtils.loadAllProperties("channel-DEV.properties");
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		if (entries != null) {
			String currList=(String) entries.get("currList");
			currencyList=Arrays.asList(currList.split(","));
		}
	}

}
