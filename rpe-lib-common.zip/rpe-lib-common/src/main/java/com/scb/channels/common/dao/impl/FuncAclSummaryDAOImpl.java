package com.scb.channels.common.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.common.dao.FuncAclSummaryDAO;
import com.scb.channels.common.vo.FuncAclSummaryVO;

public class FuncAclSummaryDAOImpl extends HibernateDaoSupport implements
		FuncAclSummaryDAO {

	public List<FuncAclSummaryVO> get() {		
		
		return  getSession().createCriteria(FuncAclSummaryVO.class).list();
		
	}

}
