package com.scb.channels.common.service;


/**
 * The Interface LoginSessionService.
 */
public interface SessionService {

	/**
	 * Checks if is valid session.
	 *
	 * @param userId the user id
	 * @param country the country
	 * @param channel the channel
	 * @param sessionId the session id
	 * @return true, if is valid session
	 */
	boolean isValidSession(String userId,String country, String channel, String sessionId);
	
	
	/**
	 * Clear old session.
	 *
	 * @param country the country
	 * @param channel the channel
	 */
	void clearOldSession(String country, String channel);
}
