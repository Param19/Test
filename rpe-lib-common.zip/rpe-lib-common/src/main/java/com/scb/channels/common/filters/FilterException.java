/**
 * 
 */
package com.scb.channels.common.filters;

/**
 * The Class FilterException.
 *
 * @author 1411807
 */
public class FilterException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6808804367533511079L;

    /**
     * Instantiates a new filter exception.
     *
     * @param arg0 the arg0
     */
    public FilterException(Throwable arg0) {
    	super(arg0);
	}
    
    /**
     * Instantiates a new filter exception.
     *
     * @param message the message
     */
    public FilterException(String message) {
    	super(message);
	}
	
}
