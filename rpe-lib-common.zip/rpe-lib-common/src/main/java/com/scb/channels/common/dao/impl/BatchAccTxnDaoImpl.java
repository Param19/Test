package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchAccTxnDAO;
import com.scb.channels.common.vo.BatchAccTxnVO;


/**
 * The Class BatchAccTxnDaoImpl.
 */
public class BatchAccTxnDaoImpl extends HibernateDaoSupport implements BatchAccTxnDAO {
	private int maxResults;
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchAccTxnDAO#getBatchAccountTxn(com.scb.channels.common.vo.BatchAccTxnVO)
	 */ 
	public List<BatchAccTxnVO> getBatchAccountTxn(String accNo) {
		Criteria criteria = getSession().createCriteria(BatchAccTxnVO.class);		
			criteria.add(Restrictions.eq(HibernateHelper.ACCT_NO, accNo));
			criteria.setMaxResults(maxResults);
			List<BatchAccTxnVO> list = criteria.list();
			return list;
	
		}
	public void setMaxResults(int maxResults) {
		this.maxResults = maxResults;
	}
	
	
}
