/**
 * 
 */
package com.scb.channels.common.processor.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ApplicationContext;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransferRequestVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class ContextInitializationProcessor.
 *
 * @author 1411807
 */
public class ContextInitializationProcessor extends AbstractProcessor  {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ContextInitializationProcessor.class);
	
	private boolean generateReqCode = true;
	

	/**
	 * Do tasks.
	 * 
	 * @param bean
	 *            the bean
	 * @return the payload dto
	 * @throws BusinessException
	 *             the business exception
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.debug("Inside Context initializer-----");
		BaseVO requestVO = bean.getRequestVO();
		LOGGER.debug("Inside Context initializer   requestVO  -- "+requestVO);
		UserVO user = requestVO.getUser();
		ClientVO clientVO = requestVO.getClientVO();
		ServiceVO serviceVO = requestVO.getServiceVO();
		if (user != null && clientVO!=null && serviceVO!=null && requestVO.getMessageVO()!=null) {
			try{
				LOGGER.debug("Inside Context initializer  user clientVO serviceVO -- "+user+clientVO+serviceVO);
				ApplicationContext.initializeContext(user,clientVO,serviceVO);
				if (requestVO.getMessageVO().getRequestCode() == null) {
					if (generateReqCode) {
						requestVO.getMessageVO().setRequestCode(ReferenceNumberGenerator.generateReferenceNumber(user.getCountry(), 
								serviceVO.getServiceName(), user.getChannelId()));
						LOGGER.debug("Request Code generated {}" , new Object[] {requestVO.getMessageVO().getRequestCode()});
					}
					setTransactionId(requestVO);
					setJVMDetail(requestVO);
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				throw new BusinessException(e.getMessage(), e.getCause(), bean);
			}
		} else {
			return getDefaultHostEmptyResponse();
		}
		LOGGER.debug("Completed Context initializer");
		return bean;
	}


	/**
	 * Sets the transaction id.
	 * 
	 * @param requestVO
	 *            the new transaction id
	 */
	private void setTransactionId(BaseVO requestVO) {
		if (requestVO instanceof TransferRequestVO && ((TransferRequestVO)requestVO).getTransactionInfoVO() != null) {
			((TransferRequestVO)requestVO).getTransactionInfoVO().setTxnId(requestVO.getMessageVO().getRequestCode());
		} else if (requestVO instanceof BillerPayRequestVO 
				&& ((BillerPayRequestVO)requestVO).getBillerPayDetailsVO() != null
				&& ((BillerPayRequestVO)requestVO).getBillerPayDetailsVO().getTransactionInfoVO() != null) {
			((BillerPayRequestVO)requestVO).getBillerPayDetailsVO()
				.getTransactionInfoVO().setTxnId(requestVO.getMessageVO().getRequestCode());
		}
	}


	/**
	 * @param generateReqCode the generateReqCode to set
	 */
	public void setGenerateReqCode(boolean generateReqCode) {
		this.generateReqCode = generateReqCode;
	}


	private void setJVMDetail(BaseVO requestVO){
		if(requestVO instanceof QRPaymentRequestVO && ((QRPaymentRequestVO)requestVO).getQrPaymentDetailVO() != null){
			((QRPaymentRequestVO)requestVO).getQrPaymentDetailVO().setJvmName(CommonHelper.getJVMName());
		}
	}
	
	
	

}
