package com.scb.channels.common.dao;

import java.util.List;
import com.scb.channels.common.vo.BatchRiskCodeVO;

/**
 * The Interface BatchRiskCodeDAO.
 */
public interface BatchRiskCodeDAO {
	
	/**
	 * Gets the batch risk code.
	 *
	 * @param batchRiskCodeVO the batch risk code vo
	 * @return the batch risk code
	 */
	List<BatchRiskCodeVO> getBatchRiskCode(BatchRiskCodeVO batchRiskCodeVO);

}
