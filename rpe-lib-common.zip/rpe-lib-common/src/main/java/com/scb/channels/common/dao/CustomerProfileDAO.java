package com.scb.channels.common.dao;

import com.scb.channels.base.vo.CustomerProfileVO;

/**
 * The Interface CustomerProfileDAO.
 */
public interface CustomerProfileDAO {

	/**
	 * Gets the customer profile.
	 *
	 * @param username the username
	 * @return the customer profile
	 */
	CustomerProfileVO getCustomerProfile(String username);
	
	/**
	 * Gets the customer profile for relationship.
	 *
	 * @param relno the relno
	 * @return the customer profile for relationship
	 */
	CustomerProfileVO getCustomerProfileForRelationship(String relno);
	

	/**
	 * Gets the Customer Profile
	 * @param CountryCode
	 * @param MobileNumber
	 * @param RelNum
	 * @return
	 */
	public CustomerProfileVO getCustomerProfile(String CountryCode,
			String MobileNumber, String RelNum);
}
