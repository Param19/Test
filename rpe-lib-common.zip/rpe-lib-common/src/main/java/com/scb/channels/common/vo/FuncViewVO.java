package com.scb.channels.common.vo;

import java.io.Serializable;

/**
 * The Class FuncViewVO.
 */
public class FuncViewVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2301120159923245611L;

	/** The u func. */
	private Integer uFunc; 
	
	/** The lang cd. */
	private String langCd;   
	
	/** The name. */
	private String name;   
	
	/** The func cd. */
	private String funcCd;  
	
	/** The status cd. */
	private String statusCd;     
	
	/** The type. */
	private String type;
	
	/**
	 * Gets the u func.
	 *
	 * @return the u func
	 */
	public Integer getuFunc() {
		return uFunc;
	}
	
	/**
	 * Sets the u func.
	 *
	 * @param uFunc the new u func
	 */
	public void setuFunc(Integer uFunc) {
		this.uFunc = uFunc;
	}
	
	/**
	 * Gets the lang cd.
	 *
	 * @return the lang cd
	 */
	public String getLangCd() {
		return langCd;
	}
	
	/**
	 * Sets the lang cd.
	 *
	 * @param langCd the new lang cd
	 */
	public void setLangCd(String langCd) {
		this.langCd = langCd;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the func cd.
	 *
	 * @return the func cd
	 */
	public String getFuncCd() {
		return funcCd;
	}
	
	/**
	 * Sets the func cd.
	 *
	 * @param funcCd the new func cd
	 */
	public void setFuncCd(String funcCd) {
		this.funcCd = funcCd;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	
	

}
