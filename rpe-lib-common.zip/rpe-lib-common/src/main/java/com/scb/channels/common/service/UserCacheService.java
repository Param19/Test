/*
 * 
 */
package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.base.vo.AccountDetailsVO;
import com.scb.channels.base.vo.BeneficiaryVO;
import com.scb.channels.base.vo.BillerDetailsVO;
import com.scb.channels.base.vo.CASAVO;
import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Interface UserCacheService.
 */
public interface UserCacheService {

	/**
	 * Adds the account list.
	 *
	 * @param payload the payload
	 */
	void addAccountList(PayloadDTO payload);
	
	/**
	 * Adds the beneficiary.
	 *
	 * @param payload the payload
	 */
	void addBeneficiary(PayloadDTO payload);
	
	/**
	 * Adds the biller.
	 *
	 * @param payload the payload
	 */
	void addBiller(PayloadDTO payload);
	
	/**
	 * Adds the cust info.
	 *
	 * @param payload the payload
	 */
	void addCustInfo(PayloadDTO payload);
	
	/**
	 * Gets the account.
	 *
	 * @param payload the payload
	 * @param accountNumber the account number
	 * @return the account
	 */
	CASAVO getAccount(PayloadDTO payload, String accountNumber);
	
	
	/**
	 * Adds the beneficiary account.
	 *
	 * @param payload the payload
	 * @param accountDetailsVO the account details vo
	 */
	void addBeneficiaryAccount(PayloadDTO payload, CASAVO cASAVO);
	
	/**
	 * Gets the account list.
	 *
	 * @param payload the payload
	 * @return the account list
	 */
	List<AccountDetailsVO> getAccountList(PayloadDTO payload);
	
	/**
	 * Gets the beneficiary list.
	 *
	 * @param payload the payload
	 * @return the beneficiary list
	 */
	List<BeneficiaryVO> getBeneficiaryList(PayloadDTO payload);
	
	/**
	 * Gets the biller list.
	 *
	 * @param payload the payload
	 * @return the biller list
	 */
	List<BillerDetailsVO> getBillerList(PayloadDTO payload);
	
	/**
	 * Clear cust info.
	 *
	 * @param payload the payload
	 */
	void clearCustInfo(PayloadDTO payload);
}
