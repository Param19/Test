/**
 * 
 */
package com.scb.channels.common.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.common.dao.ReferenceDAO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.vo.ReferenceVO;

/**
 * The Class ReferenceServiceImpl.
 *
 * @author 1411807
 */
public class ReferenceServiceImpl implements ReferenceService {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceServiceImpl.class);

	private ReferenceDAO referenceDAO;
	
	/** The cache manager. */
	private CacheManager cacheManager;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.ReferenceService#saveReference(com.scb.channels.common.vo.ReferenceVO)
	 */
	public void saveReference(ReferenceVO referenceVO) {
		referenceDAO.insert(referenceVO);
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.ReferenceService#updateReference(com.scb.channels.common.vo.ReferenceVO)
	 */
	public void updateReference(ReferenceVO referenceVO) {
		referenceDAO.update(referenceVO);
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.ReferenceService#deleteReference(com.scb.channels.common.vo.ReferenceVO)
	 */
	public void deleteReference(ReferenceVO referenceVO) {
		referenceDAO.update(referenceVO);
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.ReferenceService#getReference(com.scb.channels.common.vo.ReferenceVO)
	 */
	public ReferenceVO getReference(ReferenceVO referenceVO) {
		ReferenceVO refVO = null;
		if(cacheManager.getCache(CommonConstants.MY_CACHE).get(referenceVO.getCountryCode() + referenceVO.getChannelId() + referenceVO.getType()) == null){
			refVO = referenceDAO.get(referenceVO);
			cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(referenceVO.getCountryCode() + referenceVO.getChannelId() + referenceVO.getType() , refVO));
		} else {
			refVO = (ReferenceVO) cacheManager.getCache(CommonConstants.MY_CACHE).get(referenceVO.getCountryCode() + referenceVO.getChannelId() + referenceVO.getType()).getValue();
		}
		return refVO;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.ReferenceService#getReference(com.scb.channels.common.vo.ReferenceVO)
	 */
	//Insert corresponding records into reference Table
	public Map<String, String> getReferenceMap(ReferenceVO referenceVO) {
	LOGGER.info("Entered Reference ServiceImpl Class..");
		List<ReferenceVO>  list =null;
		Map<String, String> referenceMap = new HashMap<String, String>();
		
		String searchKey = referenceVO.getCountryCode() + referenceVO.getChannelId() + 
				(referenceVO.getAggregator() != null ? referenceVO.getAggregator() : CommonConstants.EMPTY) + 
				(referenceVO.getVersion()!= null ? referenceVO.getVersion() : CommonConstants.EMPTY)  + 
				(referenceVO.getType() != null ? referenceVO.getType() : CommonConstants.EMPTY);
		
		if(cacheManager.getCache(CommonConstants.MY_CACHE).get(searchKey) == null){
			list = referenceDAO.getList(referenceVO);
			
			for(ReferenceVO reference : list){
				referenceMap.put(reference.getRefCode(), reference.getRefValue());
			}		
			if(referenceMap.size() != 0) {
				cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(searchKey , referenceMap));
				LOGGER.info("Loading getReferenceMap Values..");
			}
		} else {
			referenceMap = (Map<String, String>) cacheManager.getCache(CommonConstants.MY_CACHE).get(searchKey).getValue();
			LOGGER.info("retreiving it from Cache..");
		}
		return referenceMap;
	} 
	public List<ISOCODESVO> getCurrency(String country){
	
		List<ISOCODESVO> isocodesvos = null;
		LOGGER.debug("Fetching Currency and country LIST   {} ", new Object[] {country});
		if(cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(country+CommonConstants.ISO_LIST)==null){
			
			LOGGER.debug("Calling DB due to no Currency data Available on  ISO_LIST cache  ");
			isocodesvos = referenceDAO.getIsoCodesVo(country);
			
			if(isocodesvos != null && isocodesvos.size()>0){
				 LOGGER.debug("setting  the Currency and country Configuration into ISO_LIST CACHE");
				cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).put(new Element(country+CommonConstants.ISO_LIST , isocodesvos));
			} else {
				 LOGGER.debug("No Data in DB as well");
			}
			
		}else{
			LOGGER.debug("Narration Configuration AVAILABLE in Cache");
			isocodesvos  =(List<ISOCODESVO>)cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(country+CommonConstants.ISO_LIST).getValue();
		}
		
		return isocodesvos;
	}

	public List<ISOCODESVO> getPrecisionCurrency(String currencyCode){
		
		List<ISOCODESVO> isocodesvos = null;
		LOGGER.debug("Fetching ISO Currency,Country,Precision   {} ", new Object[] {currencyCode});
		if(cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(currencyCode+CommonConstants.ISO_LIST_CURR_PRECISION)==null){
			
			LOGGER.debug("Calling DB due no data Available on  ISO_LIST_CURR_PRECISION cache  ");
			isocodesvos = referenceDAO.getPrecisionIsoCodesVo(currencyCode);
			
			if(isocodesvos != null && isocodesvos.size()>0){
				 LOGGER.debug("setting  the ISO Currency,Country,Precision Configuration into ISO_LIST_CURR_PRECISION CACHE");
				cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).put(new Element(currencyCode+CommonConstants.ISO_LIST_CURR_PRECISION , isocodesvos));
			} else {
				 LOGGER.debug("No Data in DB as well");
			}
			
		}else{
			LOGGER.debug("Narration Configuration AVAILABLE in Cache");
			isocodesvos  =(List<ISOCODESVO>)cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(currencyCode+CommonConstants.ISO_LIST_CURR_PRECISION).getValue();
		}
		
		return isocodesvos;
	}
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.ReferenceService#getCustomizedMessages(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public Map<String,ApplicationMessageVO> getCustomizedMessages(String country,String channel,String component, String module)
	{
        Map<String, ApplicationMessageVO> mapFromDB = null;
        LOGGER.debug("Fetching getCustomizedMessages   {} ", new Object[] {country});
        if(cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(country+channel+component+module+CommonConstants.APPLICATION_MESSAGE)==null){
               
               LOGGER.debug("Fetch the messages from DB -- DB Call Start channel "+channel);
               
               mapFromDB=referenceDAO.getApplicationMessages(country,channel,component,module);
                 
                 if(mapFromDB != null && mapFromDB.size() > 0){
                       LOGGER.debug("Got Messages from DB and put it into CACHE" );
                       cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).put(new Element(country+channel+component+module+CommonConstants.APPLICATION_MESSAGE , mapFromDB));
                 }else{
                       LOGGER.debug("Customized Message not  AVAILABLE in DB");
                 }
        }else{
               LOGGER.debug("Customized Application Messages  AVAILABLE in Cache");
               mapFromDB =( Map<String, ApplicationMessageVO>)cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(country+channel+component+module+CommonConstants.APPLICATION_MESSAGE).getValue();
        }
        
        return mapFromDB;
        
 }


	/**
	 * @return the referenceDAO
	 */
	public ReferenceDAO getReferenceDAO() {
		return referenceDAO;
	}

	/**
	 * @param referenceDAO the referenceDAO to set
	 */
	public void setReferenceDAO(ReferenceDAO referenceDAO) {
		this.referenceDAO = referenceDAO;
	}

	/**
	 * @return the cacheManager
	 */
	public CacheManager getCacheManager() {
		return cacheManager;
	}

	/**
	 * @param cacheManager the cacheManager to set
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

}
