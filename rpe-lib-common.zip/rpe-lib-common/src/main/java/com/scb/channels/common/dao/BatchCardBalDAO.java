package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.BatchCardBalVO;

/**
 * The Interface BatchCardBalDAO.
 */
public interface BatchCardBalDAO {
	
	/**
	 * Gets the batch card bal.
	 *
	 * @param batchCardBalVO the batch card bal vo
	 * @return the batch card bal
	 */
	List<BatchCardBalVO> getBatchCardBal(BatchCardBalVO batchCardBalVO);

}
