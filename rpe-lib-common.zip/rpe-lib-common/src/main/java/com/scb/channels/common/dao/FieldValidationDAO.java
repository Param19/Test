/**
 * 
 */
package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.FieldValidationVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.exception.DAOException;


/**
 * The Interface FieldValidationDAO.
 * 
 */
public interface FieldValidationDAO {
	
	/**
	 * Gets the filed validation list based on country, channel and module.
	 *
	 * @param module the module
	 * @param status the status
	 * @param clientVO the client vo
	 * @return the filed validation
	 * @throws DAOException the dAO exception
	 */
	public List<FieldValidationVO> getfieldValidationList (String module, String status, String baseObject, ClientVO clientVO) throws DAOException;
	
}
