package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.VariablesVO;

/**
 * The Interface VariableDAO.
 */
public interface VariableDAO {
	
	
	/**
	 * Gets the all SysParaments.
	 *
	 *  
	 * @param with out passing parameter we aree trying fecth the all the sys parameters
	 * @return the List of VariablesVO  beans/ row by every VO.
	 */
	public List<VariablesVO> getSystemVaribale();
	
	
	/**
	 * @param key name 
	 * @return VariablesVO
	 */
	/**
	 * @param CountryCode
	 * @param channelId
	 * @param key
	 * @return VariablesVO
	 */
	public VariablesVO getValuefromkey(String CountryCode,String channelId,String key);
	
	
	/**
	 * @param CountryCode
	 * @param channelId
	 * @param key
	 * @return List<VariablesVO> 
	 */
	public List<VariablesVO> getValuesPerkey(String CountryCode,String channelId,String key);


	/**
	 * @param CountryCode
	 * @param channelId
	 * @param key
	 * @return List<VariablesVO> 
	 */
	public void update(VariablesVO variablesVO);

}
