package com.scb.channels.common.dao.impl;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.SysParamDAO;
import com.scb.channels.common.vo.SysParamVO;

/**
 * The Class SysParamDAOImpl.
 */
public class SysParamDAOImpl extends HibernateDaoSupport implements SysParamDAO {
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.SysParamDAO#insert(com.scb.channels.common.vo.SysParamVO)
	 */
	public void insert(SysParamVO sysParamVO) {
		getHibernateTemplate().save(sysParamVO);
		

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.SysParamDAO#update(com.scb.channels.common.vo.SysParamVO)
	 */
	public void update(SysParamVO sysParamVO) {
		Query query = getSession().createQuery("update SysParamVO set category =:category, value =:value,dtUpd=:dtUpd ,updBy=:updBy where id=:id ");
		query.setParameter(HibernateHelper.CATEGORY, sysParamVO.getCategory());
		query.setParameter(HibernateHelper.VALUE, sysParamVO.getValue());
		query.setParameter(HibernateHelper.DATE_UPDATE, DateUtils.getCurrentDate());
		query.setParameter(HibernateHelper.UPDATE_BY, sysParamVO.getUpdBy());
		query.setParameter(HibernateHelper.ID, sysParamVO.getId());
		query.executeUpdate();   	

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.SysParamDAO#delete(com.scb.channels.common.vo.SysParamVO)
	 */
	public void delete(SysParamVO sysParamVO) {		
		getSession().delete(sysParamVO);

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.SysParamDAO#get(com.scb.channels.common.vo.SysParamVO)
	 */
	public SysParamVO get(SysParamVO sysParamVO) {
		org.hibernate.Criteria criteria =  getSession().createCriteria(SysParamVO.class);
		if(sysParamVO.getId()!=null){
			criteria.add(Restrictions.eq(HibernateHelper.ID, sysParamVO.getId()));	
		}else{
			criteria.add(Restrictions.eq(HibernateHelper.VALUE, sysParamVO.getValue()));
			criteria.add(Restrictions.eq(HibernateHelper.CATEGORY, sysParamVO.getCategory()));
		}
			
		
		List<SysParamVO> list = criteria.list();
		return list.size()==0?null: list.get(0);
	}

}
