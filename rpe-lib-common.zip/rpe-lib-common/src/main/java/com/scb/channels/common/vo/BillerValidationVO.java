package com.scb.channels.common.vo;

import java.io.Serializable;

public class BillerValidationVO implements Serializable {

	/**
	 * 1464143
	 */
	private static final long serialVersionUID = -790740105326889421L;
	private int id;
	private String billerField;
	private int lenMinValidation;
	private int lenMaxValidation;
	private String ctryCd;
	private String regExp;
	private String billerCdFK;
	private String valMessage;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBillerField() {
		return billerField;
	}

	public void setBillerField(String billerField) {
		this.billerField = billerField;
	}

	public int getLenMinValidation() {
		return lenMinValidation;
	}

	public void setLenMinValidation(int lenMinValidation) {
		this.lenMinValidation = lenMinValidation;
	}

	public int getLenMaxValidation() {
		return lenMaxValidation;
	}

	public void setLenMaxValidation(int lenMaxValidation) {
		this.lenMaxValidation = lenMaxValidation;
	}

	public String getCtryCd() {
		return ctryCd;
	}

	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	public String getRegExp() {
		return regExp;
	}

	public void setRegExp(String regExp) {
		this.regExp = regExp;
	}

	public String getBillerCdFK() {
		return billerCdFK;
	}

	public void setBillerCdFK(String billerCdFK) {
		this.billerCdFK = billerCdFK;
	}

	public String getValMessage() {
		return valMessage;
	}

	public void setValMessage(String valMessage) {
		this.valMessage = valMessage;
	}
	

}
