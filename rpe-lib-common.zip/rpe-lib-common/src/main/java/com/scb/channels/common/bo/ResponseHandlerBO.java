package com.scb.channels.common.bo;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Interface ResponseHandlerBO.
 */
public interface ResponseHandlerBO {
	
	/**
	 * Update transaction details.
	 *
	 * @param payloadDTO the payload dto
	 */
	void updateTransactionDetails(PayloadDTO payloadDTO);

}
