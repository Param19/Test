package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.BatchAccTxnVO;

/**
 * The Interface BatchAccTxnDAO.
 */
public interface BatchAccTxnDAO {
	
	/**
	 * Gets the batch account txn.
	 *
	 * @param accNo the batch acc txn vo
	 * @return the batch account txn
	 */
	List<BatchAccTxnVO> getBatchAccountTxn(String accNo);

}
