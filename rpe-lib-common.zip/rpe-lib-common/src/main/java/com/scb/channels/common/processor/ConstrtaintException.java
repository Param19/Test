package com.scb.channels.common.processor;

/**
 * The Class ConstrtaintException.
 *
 * @author 1493439
 */
public class ConstrtaintException extends BusinessException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5586790816906264393L;
	
	public ConstrtaintException(String message) {
		super(message);
	}
	
}
