package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class ReferenceVO.
 */
public class ReferenceVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5635724357488609886L;
	
	/** The id. */
	private Integer id; 
	
	/** The version. */
	private Integer version;
	
	/** The seq no. */
	private Integer seqNo; 
	
	/** The is default. */
	private Character isDefault;
	
	/** The is display. */
	private Character isDisplay;
	
	/** The ctry cd. */
	private String countryCode;   
	
	/** The is channel Id. */
	private String channelId;
	
	/** The type. */
	private String type;   
	
	/** The aggregator name. */
	private String aggregator;   
	
	/** The api Version. */
	private String apiVersion;   
	
	/** The ref cd. */
	private String refCode;  
	
	/** The value. */
	private String refValue;     
	
	/** The descr. */
	private String description;
	

	/** The status cd. */
	private String statusCode; 	
	
	/** The created by. */
	private String createdBy;	 
	
	/** The upd by. */
	private String updatedBy;  
	
	/** The dt created. */
	private Date createdTimeStamp;
	
	/** The dt upd. */
	private Date udpatedTimeStamp;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public Character getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Character isDefault) {
		this.isDefault = isDefault;
	}

	public Character getIsDisplay() {
		return isDisplay;
	}

	public void setIsDisplay(Character isDisplay) {
		this.isDisplay = isDisplay;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRefCode() {
		return refCode;
	}

	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}

	public String getRefValue() {
		return refValue;
	}

	public void setRefValue(String refValue) {
		this.refValue = refValue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Date createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public Date getUdpatedTimeStamp() {
		return udpatedTimeStamp;
	}

	public void setUdpatedTimeStamp(Date udpatedTimeStamp) {
		this.udpatedTimeStamp = udpatedTimeStamp;
	}
	
	public String getAggregator() {
		return aggregator;
	}

	public void setAggregator(String aggregator) {
		this.aggregator = aggregator;
	}

	public String getApiVersion() {
		return apiVersion;
	}

	public void setApiVersion(String apiVersion) {
		this.apiVersion = apiVersion;
	}


	@Override
	public String toString() {
		return "ReferenceVO [id=" + id + ", version=" + version + ", seqNo="
				+ seqNo + ", isDefault=" + isDefault + ", isDisplay="
				+ isDisplay + ", countryCode=" + countryCode + ", channelId="
				+ channelId + ", type=" + type + ", refCode=" + refCode
				+ ", refValue=" + refValue + ", description=" + description
				+ ", statusCode=" + statusCode + ", createdBy=" + createdBy
				+ ", updatedBy=" + updatedBy + ", createdTimeStamp="
				+ createdTimeStamp + ", udpatedTimeStamp=" + udpatedTimeStamp
				+ "]";
	}

}
