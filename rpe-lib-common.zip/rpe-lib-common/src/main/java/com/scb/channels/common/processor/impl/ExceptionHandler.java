package com.scb.channels.common.processor.impl;

import org.apache.camel.CamelException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.exception.DeviceNotSupported;
import com.scb.channels.common.processor.BusinessException;

public class ExceptionHandler implements Processor {

	public static final String JMS_CORRELATION_ID = "JMSCorrelationID";
	public static final String ERROR_CAUGHT = "ERROR_CAUGHT";
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ExceptionHandler.class);

	public void process(Exchange exchange) throws CamelException {
		LOGGER.info("Exception handling from {}", exchange.getFromRouteId());
		LOGGER.info("Sendmail failed, resetting exchange with original error");
		LOGGER.error("Error ", exchange.getProperty(Exchange.EXCEPTION_CAUGHT));
		Exception ex = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
		if (ex != null) {
			exchange.setProperty(Exchange.EXCEPTION_CAUGHT, ex);
			PayloadDTO beanNew = exchange.getIn().getBody(PayloadDTO.class);
			if (ex instanceof BusinessException) {
				if (beanNew == null) {
					beanNew = ((BusinessException)ex).getBean();
					if (beanNew == null) {
						beanNew = CommonHelper.getResponseInstance(beanNew);
						beanNew.getResponseVO().setStatus(ExceptionMessages._105.getCode());
						beanNew.getResponseVO().setStatusDesc(ExceptionMessages._105.getMessage());
					}
				}
			} else if (ex instanceof DeviceNotSupported) {
				beanNew = CommonHelper.getResponseInstance(beanNew);
				beanNew.getResponseVO().setStatus(ExceptionMessages._116.getErrorCode());
				beanNew.getResponseVO().setStatusDesc(ExceptionMessages._116.getMessage());
			} else {
				beanNew = CommonHelper.getResponseInstance(beanNew);
				beanNew.getResponseVO().setStatus(ExceptionMessages._105.getCode());
				beanNew.getResponseVO().setStatusDesc(ExceptionMessages._105.getMessage());
			}
			if (beanNew != null && beanNew.getRequestVO() != null && beanNew.getRequestVO().getMessageVO()!=null) {
				exchange.getOut().setHeader(JMS_CORRELATION_ID, beanNew.getRequestVO().getMessageVO().getReqID());
			}
			exchange.getOut().setBody(beanNew);
		}
	}

	
}
