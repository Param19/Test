package com.scb.channels.common.dao.impl;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchAccRelDAO;
import com.scb.channels.common.vo.BatchAccRelVO;


/**
 * The Class BatchAccRelDaoImpl.
 */
public class BatchAccRelDaoImpl extends HibernateDaoSupport implements BatchAccRelDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchAccRelDAO#getBatchAccountRel(com.scb.channels.common.vo.BatchAccRelVO)
	 */
	public List<BatchAccRelVO> getBatchAccountRel(BatchAccRelVO batchAccRelVO) {
		Criteria criteria = getSession().createCriteria(BatchAccRelVO.class);
		if(batchAccRelVO!=null && batchAccRelVO.getCustGroupId()!=null){
			criteria.add(Restrictions.eq(HibernateHelper.CUST_GRP_ID, batchAccRelVO.getCustGroupId()));
			List<BatchAccRelVO> list = criteria.list();
			return list;
		}else{
			return null;
		}
	}
	
}
