package com.scb.channels.common.dao.impl;



import java.util.List;

import org.apache.cxf.common.util.StringUtils;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.common.dao.AuthViewDAO;
import com.scb.channels.common.vo.AuthViewVO;

/**
 * The Class AuthViewDAOImpl.
 */
public class AuthViewDAOImpl extends HibernateDaoSupport implements AuthViewDAO {
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.AuthViewDAO#get(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public AuthViewVO get(String userId ,String userPswd,String ctryCd,String systemType,String langCd) {
		org.hibernate.Criteria criteria = getSession().createCriteria(AuthViewVO.class);
		
			criteria.add(Restrictions.eq("userId", userId));
			criteria.add(Restrictions.eq("userPswd", userPswd));
			criteria.add(Restrictions.eq("ctryCd", ctryCd));
			criteria.add(Restrictions.eq("systemType",systemType ));
			criteria.add(Restrictions.eq("langCd",langCd ));
			List<AuthViewVO> list = criteria.list();
			return list.size() == 0 ? null : list.get(0);
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.AuthViewDAO#getAll(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<AuthViewVO> getAll(String userId ,String userPswd,String ctryCd,String systemType,String langCd, String functionName) {
		org.hibernate.Criteria criteria = getSession().createCriteria(AuthViewVO.class);
			criteria.add(Restrictions.eq("userId", userId));
			criteria.add(Restrictions.eq("userPswd", userPswd));
			criteria.add(Restrictions.eq("ctryCd", ctryCd));
			criteria.add(Restrictions.eq("systemType",systemType ));
			criteria.add(Restrictions.eq("langCd",langCd ));
			if (!StringUtils.isEmpty(functionName)) {
				criteria.add(Restrictions.eq("fName",functionName ));
			}
			return criteria.list();
	}

	

}
