package com.scb.channels.common.dao;

import com.scb.channels.common.vo.SysParamVO;

/**
 * The Interface SysParamDAO.
 */
public interface SysParamDAO {
 
	/**
	 * Insert.
	 *
	 * @param sysParamVO the sys param vo
	 */
	void insert(SysParamVO sysParamVO);

	/**
	 * Update.
	 *
	 * @param sysParamVO the sys param vo
	 */
	void update(SysParamVO sysParamVO);

	/**
	 * Delete.
	 *
	 * @param sysParamVO the sys param vo
	 */
	void delete(SysParamVO sysParamVO);

	/**
	 * Gets the.
	 *
	 * @param sysParamVO the sys param vo
	 * @return the sys param vo
	 */
	SysParamVO get(SysParamVO sysParamVO);
}
