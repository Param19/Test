/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.validation.MultiFieldValidator;
import com.scb.channels.common.vo.ReferenceVO;

/**
 * The Class AccountValidator.
 *
 * @author 1464143 This class used to check the validation for Account Number
 */
public class RegisterCustomerPostValidator implements MultiFieldValidator {

	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private List<String> property;
	
	/** The reference service. */
	private ReferenceService referenceService;
	
	
	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		List listAccountDetailsVOs = null;
		String defaultAccount = null;
		boolean isValidated = false;
		try {
			defaultAccount = (String) PropertyUtils.getProperty(bean, property.get(0));
			if (defaultAccount == null) {
				throw new ValidatorException("Default Account is null");
			}
			listAccountDetailsVOs =(List) PropertyUtils.getProperty(bean, property.get(1));
			if (listAccountDetailsVOs != null){
				for(Object obj :listAccountDetailsVOs ){
					String accountNumber = (String)PropertyUtils.getProperty(obj, property.get(2));
					if (accountNumber!= null && defaultAccount.equals(accountNumber.trim())) {
						String opsIns = (String)PropertyUtils.getProperty(obj, property.get(3));
						String currencyCode = (String)PropertyUtils.getProperty(obj, property.get(4));
						if (checkOperatingInstructions(opsIns.trim())) {
							throw new ValidatorException("Operating Instruction not allowed for registration.");
						}
						if (checkForAllowedCurrencyCodes(currencyCode.trim())) {
							throw new ValidatorException("Currency code not allowed for registration.");
						}
						isValidated = true;
					}
				}
			}
			if (!isValidated) {
				throw new ValidatorException("Default account is not valid account/not associated with customer");
			}
		} catch (ValidatorException e) {
			throw e;
		} catch (Exception e) {
			throw new ValidatorException(
					"Invalid Account Details field present");
		}		
	}

	

	
	public boolean checkOperatingInstructions(String strOperIns) throws ValidatorException {
		
	String operInsCd = null;
	ReferenceVO referenceVO = new ReferenceVO();
	referenceVO.setType(CommonConstants.TYPE_ADC_BO_MASTER);
	referenceVO.setRefCode(CommonConstants.REFCD_ALLOWED_OPERATING_INSTRUCTION);
	referenceVO = referenceService.getReference(referenceVO);
	operInsCd=referenceVO.getRefValue();
	String[] operatingInstructionsArray = operInsCd.split(",");
	List<String> operatingInstructionList = Arrays.asList(operatingInstructionsArray);

	if (operatingInstructionList.contains(strOperIns))
	{
		return false;
	}else{
		return true;
	}
	}
	
	public boolean checkForAllowedCurrencyCodes(String strCurCode) throws ValidatorException {
		
	String currencyCd = null;
	ReferenceVO referenceVO = new ReferenceVO();
	referenceVO.setType(CommonConstants.TYPE_ADC_BO_MASTER);
	referenceVO.setRefCode(CommonConstants.REFCD_ALLOWED_CURRENCY_CODES);
	referenceVO = referenceService.getReference(referenceVO);
	currencyCd=referenceVO.getRefValue();
	String[] currencyCdArray = currencyCd.split(",");
	List<String> currencyCdList = Arrays.asList(currencyCdArray);

	if (currencyCdList.contains(strCurCode))
	{
		return false;
	}else{
		return true;
	}
	}
	
	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		
		this.property = property;
	}
	
	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean =  bean;
		
	}

	
	/**
	 * @param referenceService the referenceService to set
	 */
	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	

	
}
