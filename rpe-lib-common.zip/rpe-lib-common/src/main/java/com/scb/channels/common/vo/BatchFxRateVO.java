package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class BatchFxRateVO.
 */
public class BatchFxRateVO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8600068983746695591L;
	
	/** The id. */
	private Integer id;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The ccy cd. */
	private String ccyCd;
	
	/** The ccy nm. */
	private String ccyNm;
	
	/** The multiply divide flag. */
	private String multiplyDivideFlag;
	
	/** The fx buy rate. */
	private Double fxBuyRate;
	
	/** The fx selling rate. */
	private Double fxSellingRate;
	
	/** The mid rate. */
	private Double midRate;
	
	/** The base ccy. */
	private String baseCcy;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private Integer version;
	
	/** The ctr buy rate. */
	private Double ctrBuyRate;
	
	/** The ctr sell rate. */
	private Double ctrSellRate;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the ccy cd.
	 *
	 * @return the ccy cd
	 */
	public String getCcyCd() {
		return ccyCd;
	}
	
	/**
	 * Sets the ccy cd.
	 *
	 * @param ccyCd the new ccy cd
	 */
	public void setCcyCd(String ccyCd) {
		this.ccyCd = ccyCd;
	}
	
	/**
	 * Gets the ccy nm.
	 *
	 * @return the ccy nm
	 */
	public String getCcyNm() {
		return ccyNm;
	}
	
	/**
	 * Sets the ccy nm.
	 *
	 * @param ccyNm the new ccy nm
	 */
	public void setCcyNm(String ccyNm) {
		this.ccyNm = ccyNm;
	}
	
	/**
	 * Gets the multiply divide flag.
	 *
	 * @return the multiply divide flag
	 */
	public String getMultiplyDivideFlag() {
		return multiplyDivideFlag;
	}
	
	/**
	 * Sets the multiply divide flag.
	 *
	 * @param multiplyDivideFlag the new multiply divide flag
	 */
	public void setMultiplyDivideFlag(String multiplyDivideFlag) {
		this.multiplyDivideFlag = multiplyDivideFlag;
	}
	
	/**
	 * Gets the fx buy rate.
	 *
	 * @return the fx buy rate
	 */
	public Double getFxBuyRate() {
		return fxBuyRate;
	}
	
	/**
	 * Sets the fx buy rate.
	 *
	 * @param fxBuyRate the new fx buy rate
	 */
	public void setFxBuyRate(Double fxBuyRate) {
		this.fxBuyRate = fxBuyRate;
	}
	
	/**
	 * Gets the fx selling rate.
	 *
	 * @return the fx selling rate
	 */
	public Double getFxSellingRate() {
		return fxSellingRate;
	}
	
	/**
	 * Sets the fx selling rate.
	 *
	 * @param fxSellingRate the new fx selling rate
	 */
	public void setFxSellingRate(Double fxSellingRate) {
		this.fxSellingRate = fxSellingRate;
	}
	
	/**
	 * Gets the mid rate.
	 *
	 * @return the mid rate
	 */
	public Double getMidRate() {
		return midRate;
	}
	
	/**
	 * Sets the mid rate.
	 *
	 * @param midRate the new mid rate
	 */
	public void setMidRate(Double midRate) {
		this.midRate = midRate;
	}
	
	/**
	 * Gets the base ccy.
	 *
	 * @return the base ccy
	 */
	public String getBaseCcy() {
		return baseCcy;
	}
	
	/**
	 * Sets the base ccy.
	 *
	 * @param baseCcy the new base ccy
	 */
	public void setBaseCcy(String baseCcy) {
		this.baseCcy = baseCcy;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the ctr buy rate.
	 *
	 * @return the ctr buy rate
	 */
	public Double getCtrBuyRate() {
		return ctrBuyRate;
	}
	
	/**
	 * Sets the ctr buy rate.
	 *
	 * @param ctrBuyRate the new ctr buy rate
	 */
	public void setCtrBuyRate(Double ctrBuyRate) {
		this.ctrBuyRate = ctrBuyRate;
	}
	
	/**
	 * Gets the ctr sell rate.
	 *
	 * @return the ctr sell rate
	 */
	public Double getCtrSellRate() {
		return ctrSellRate;
	}
	
	/**
	 * Sets the ctr sell rate.
	 *
	 * @param ctrSellRate the new ctr sell rate
	 */
	public void setCtrSellRate(Double ctrSellRate) {
		this.ctrSellRate = ctrSellRate;
	}

	

}
