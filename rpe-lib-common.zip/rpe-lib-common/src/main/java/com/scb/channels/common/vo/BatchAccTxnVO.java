package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * The Class BatchAccTxnVO.
 */
public class BatchAccTxnVO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5971273081240322422L;
	
	/** The id. */
	private Integer id;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The acct no. */
	private String acctNo;
	
	/** The currency cd. */
	private String currencyCd;
	
	/** The post date. */
	private Date postDate;
	
	/** The eff date. */
	private Date effDate;
	
	/** The cheque no. */
	private String chequeNo;
	
	/** The txn amt. */
	private Double txnAmt;
	
	/** The txn type. */
	private String txnType;
	
	/** The running bal. */
	private Double runningBal;
	
	/** The txn desc. */
	private String txnDesc;
	
	/** The exg rate. */
	private Double exgRate;
	
	/** The txn currency. */
	private String txnCurrency;
	
	/** The seq no. */
	private Integer seqNo;
	
	/** The txn time. */
	private Date txnTime;
	
	/** The to acct. */
	private String toAcct;
	
	/** The from acct. */
	private String fromAcct;
	
	/** The float amt. */
	private Double floatAmt;
	
	/** The float days. */
	private Integer floatDays;
	
	/** The extract code. */
	private String extractCode;
	
	/** The dt created. */
	private Calendar dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private Integer version;
	
	/** The product code. */
	private String productCode;
	
	/** The record type. */
	private String recordType;
	
	/** The batch no. */
	private String batchNo;
	
	/** The branch cd. */
	private String branchCd;
	
	/** The channel id. */
	private String channelId;
	
	/** The m narration1. */
	private String mNarration1;
	
	/** The m narration2. */
	private String mNarration2;
	
	/** The m narration3. */
	private String mNarration3;
	
	/** The m narration4. */
	private String mNarration4;
	
	/** The approver seqno. */
	private String approverSeqno;
	
	/** The txn code. */
	private String txnCode;
	
	/** The narration1. */
	private String narration1;
	
	/** The narration2. */
	private String narration2;
	
	/** The narration3. */
	private String narration3;
	
	/** The narration4. */
	private String narration4;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the acct no.
	 *
	 * @return the acct no
	 */
	public String getAcctNo() {
		return acctNo;
	}
	
	/**
	 * Sets the acct no.
	 *
	 * @param acctNo the new acct no
	 */
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	/**
	 * Gets the currency cd.
	 *
	 * @return the currency cd
	 */
	public String getCurrencyCd() {
		return currencyCd;
	}
	
	/**
	 * Sets the currency cd.
	 *
	 * @param currencyCd the new currency cd
	 */
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	
	/**
	 * Gets the post date.
	 *
	 * @return the post date
	 */
	public Date getPostDate() {
		return postDate;
	}
	
	/**
	 * Sets the post date.
	 *
	 * @param postDate the new post date
	 */
	public void setPostDate(Date postDate) {
		this.postDate = postDate;
	}
	
	/**
	 * Gets the eff date.
	 *
	 * @return the eff date
	 */
	public Date getEffDate() {
		return effDate;
	}
	
	/**
	 * Sets the eff date.
	 *
	 * @param effDate the new eff date
	 */
	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}
	
	/**
	 * Gets the cheque no.
	 *
	 * @return the cheque no
	 */
	public String getChequeNo() {
		return chequeNo;
	}
	
	/**
	 * Sets the cheque no.
	 *
	 * @param chequeNo the new cheque no
	 */
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	
	/**
	 * Gets the txn amt.
	 *
	 * @return the txn amt
	 */
	public Double getTxnAmt() {
		return txnAmt;
	}
	
	/**
	 * Sets the txn amt.
	 *
	 * @param txnAmt the new txn amt
	 */
	public void setTxnAmt(Double txnAmt) {
		this.txnAmt = txnAmt;
	}
	
	/**
	 * Gets the txn type.
	 *
	 * @return the txn type
	 */
	public String getTxnType() {
		return txnType;
	}
	
	/**
	 * Sets the txn type.
	 *
	 * @param txnType the new txn type
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	
	/**
	 * Gets the running bal.
	 *
	 * @return the running bal
	 */
	public Double getRunningBal() {
		return runningBal;
	}
	
	/**
	 * Sets the running bal.
	 *
	 * @param runningBal the new running bal
	 */
	public void setRunningBal(Double runningBal) {
		this.runningBal = runningBal;
	}
	
	/**
	 * Gets the txn desc.
	 *
	 * @return the txn desc
	 */
	public String getTxnDesc() {
		return txnDesc;
	}
	
	/**
	 * Sets the txn desc.
	 *
	 * @param txnDesc the new txn desc
	 */
	public void setTxnDesc(String txnDesc) {
		this.txnDesc = txnDesc;
	}
	
	/**
	 * Gets the exg rate.
	 *
	 * @return the exg rate
	 */
	public Double getExgRate() {
		return exgRate;
	}
	
	/**
	 * Sets the exg rate.
	 *
	 * @param exgRate the new exg rate
	 */
	public void setExgRate(Double exgRate) {
		this.exgRate = exgRate;
	}
	
	/**
	 * Gets the txn currency.
	 *
	 * @return the txn currency
	 */
	public String getTxnCurrency() {
		return txnCurrency;
	}
	
	/**
	 * Sets the txn currency.
	 *
	 * @param txnCurrency the new txn currency
	 */
	public void setTxnCurrency(String txnCurrency) {
		this.txnCurrency = txnCurrency;
	}
	
	/**
	 * Gets the seq no.
	 *
	 * @return the seq no
	 */
	public Integer getSeqNo() {
		return seqNo;
	}
	
	/**
	 * Sets the seq no.
	 *
	 * @param seqNo the new seq no
	 */
	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}
	
	/**
	 * Gets the txn time.
	 *
	 * @return the txn time
	 */
	public Date getTxnTime() {
		return txnTime;
	}
	
	/**
	 * Sets the txn time.
	 *
	 * @param txnTime the new txn time
	 */
	public void setTxnTime(Date txnTime) {
		this.txnTime = txnTime;
	}
	
	/**
	 * Gets the to acct.
	 *
	 * @return the to acct
	 */
	public String getToAcct() {
		return toAcct;
	}
	
	/**
	 * Sets the to acct.
	 *
	 * @param toAcct the new to acct
	 */
	public void setToAcct(String toAcct) {
		this.toAcct = toAcct;
	}
	
	/**
	 * Gets the from acct.
	 *
	 * @return the from acct
	 */
	public String getFromAcct() {
		return fromAcct;
	}
	
	/**
	 * Sets the from acct.
	 *
	 * @param fromAcct the new from acct
	 */
	public void setFromAcct(String fromAcct) {
		this.fromAcct = fromAcct;
	}
	
	/**
	 * Gets the float amt.
	 *
	 * @return the float amt
	 */
	public Double getFloatAmt() {
		return floatAmt;
	}
	
	/**
	 * Sets the float amt.
	 *
	 * @param floatAmt the new float amt
	 */
	public void setFloatAmt(Double floatAmt) {
		this.floatAmt = floatAmt;
	}
	
	/**
	 * Gets the float days.
	 *
	 * @return the float days
	 */
	public Integer getFloatDays() {
		return floatDays;
	}
	
	/**
	 * Sets the float days.
	 *
	 * @param floatDays the new float days
	 */
	public void setFloatDays(Integer floatDays) {
		this.floatDays = floatDays;
	}
	
	/**
	 * Gets the extract code.
	 *
	 * @return the extract code
	 */
	public String getExtractCode() {
		return extractCode;
	}
	
	/**
	 * Sets the extract code.
	 *
	 * @param extractCode the new extract code
	 */
	public void setExtractCode(String extractCode) {
		this.extractCode = extractCode;
	}
	
	
	
	public Calendar getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Calendar dtCreated) {
		this.dtCreated = dtCreated;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the product code.
	 *
	 * @return the product code
	 */
	public String getProductCode() {
		return productCode;
	}
	
	/**
	 * Sets the product code.
	 *
	 * @param productCode the new product code
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	/**
	 * Gets the record type.
	 *
	 * @return the record type
	 */
	public String getRecordType() {
		return recordType;
	}
	
	/**
	 * Sets the record type.
	 *
	 * @param recordType the new record type
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	
	/**
	 * Gets the batch no.
	 *
	 * @return the batch no
	 */
	public String getBatchNo() {
		return batchNo;
	}
	
	/**
	 * Sets the batch no.
	 *
	 * @param batchNo the new batch no
	 */
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	
	/**
	 * Gets the branch cd.
	 *
	 * @return the branch cd
	 */
	public String getBranchCd() {
		return branchCd;
	}
	
	/**
	 * Sets the branch cd.
	 *
	 * @param branchCd the new branch cd
	 */
	public void setBranchCd(String branchCd) {
		this.branchCd = branchCd;
	}
	
	/**
	 * Gets the channel id.
	 *
	 * @return the channel id
	 */
	public String getChannelId() {
		return channelId;
	}
	
	/**
	 * Sets the channel id.
	 *
	 * @param channelId the new channel id
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	/**
	 * Gets the m narration1.
	 *
	 * @return the m narration1
	 */
	public String getmNarration1() {
		return mNarration1;
	}
	
	/**
	 * Sets the m narration1.
	 *
	 * @param mNarration1 the new m narration1
	 */
	public void setmNarration1(String mNarration1) {
		this.mNarration1 = mNarration1;
	}
	
	/**
	 * Gets the m narration2.
	 *
	 * @return the m narration2
	 */
	public String getmNarration2() {
		return mNarration2;
	}
	
	/**
	 * Sets the m narration2.
	 *
	 * @param mNarration2 the new m narration2
	 */
	public void setmNarration2(String mNarration2) {
		this.mNarration2 = mNarration2;
	}
	
	/**
	 * Gets the m narration3.
	 *
	 * @return the m narration3
	 */
	public String getmNarration3() {
		return mNarration3;
	}
	
	/**
	 * Sets the m narration3.
	 *
	 * @param mNarration3 the new m narration3
	 */
	public void setmNarration3(String mNarration3) {
		this.mNarration3 = mNarration3;
	}
	
	/**
	 * Gets the m narration4.
	 *
	 * @return the m narration4
	 */
	public String getmNarration4() {
		return mNarration4;
	}
	
	/**
	 * Sets the m narration4.
	 *
	 * @param mNarration4 the new m narration4
	 */
	public void setmNarration4(String mNarration4) {
		this.mNarration4 = mNarration4;
	}
	
	/**
	 * Gets the approver seqno.
	 *
	 * @return the approver seqno
	 */
	public String getApproverSeqno() {
		return approverSeqno;
	}
	
	/**
	 * Sets the approver seqno.
	 *
	 * @param approverSeqno the new approver seqno
	 */
	public void setApproverSeqno(String approverSeqno) {
		this.approverSeqno = approverSeqno;
	}
	
	/**
	 * Gets the txn code.
	 *
	 * @return the txn code
	 */
	public String getTxnCode() {
		return txnCode;
	}
	
	/**
	 * Sets the txn code.
	 *
	 * @param txnCode the new txn code
	 */
	public void setTxnCode(String txnCode) {
		this.txnCode = txnCode;
	}
	
	/**
	 * Gets the narration1.
	 *
	 * @return the narration1
	 */
	public String getNarration1() {
		return narration1;
	}
	
	/**
	 * Sets the narration1.
	 *
	 * @param narration1 the new narration1
	 */
	public void setNarration1(String narration1) {
		this.narration1 = narration1;
	}
	
	/**
	 * Gets the narration2.
	 *
	 * @return the narration2
	 */
	public String getNarration2() {
		return narration2;
	}
	
	/**
	 * Sets the narration2.
	 *
	 * @param narration2 the new narration2
	 */
	public void setNarration2(String narration2) {
		this.narration2 = narration2;
	}
	
	/**
	 * Gets the narration3.
	 *
	 * @return the narration3
	 */
	public String getNarration3() {
		return narration3;
	}
	
	/**
	 * Sets the narration3.
	 *
	 * @param narration3 the new narration3
	 */
	public void setNarration3(String narration3) {
		this.narration3 = narration3;
	}
	
	/**
	 * Gets the narration4.
	 *
	 * @return the narration4
	 */
	public String getNarration4() {
		return narration4;
	}
	
	/**
	 * Sets the narration4.
	 *
	 * @param narration4 the new narration4
	 */
	public void setNarration4(String narration4) {
		this.narration4 = narration4;
	}
	
	
}
