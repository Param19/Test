package com.scb.channels.common.filters.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.scb.channels.common.filters.ByPassFilterException;
import com.scb.channels.common.filters.FilterCondition;
import com.scb.channels.common.filters.RejectFilterException;
/**
 * Abstract class PreFilter
 * @author 1411807
 *
 */
public abstract class AbstractPreFilter {

	/**
	 * Instantiates a new abstract pre filter.
	 */
	public AbstractPreFilter() {
		super();
	}
	/** The filter condition. */
	private FilterCondition filterCondition;
	
	/**
	 * List not contains check.
	 *
	 * @param value the value
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void listNotContainsCheck(String value)
			throws ByPassFilterException, RejectFilterException {
				String[] arry = filterCondition.getValue().split(",");
				List<String>list = new ArrayList<String>();
				CollectionUtils.addAll(list, arry);
				if (list.contains(value)){
					manageException();
				}
			}

	/**
	 * Manage exception.
	 * 
	 * @throws ByPassFilterException
	 *             the by pass filter exception
	 * @throws RejectFilterException
	 *             the reject filter exception
	 */
	public abstract void manageException() throws ByPassFilterException, RejectFilterException ;

	/**
	 * List contains check.
	 *
	 * @param value the value
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void listContainsCheck(String value) throws ByPassFilterException,
			RejectFilterException {
				String[] arry = filterCondition.getValue().split(",");
				List<String> list = new ArrayList<String>();
				CollectionUtils.addAll(list, arry);
				if (!list.contains(value)){
					manageException();
				}
			}

	/**
	 * Not contains check.
	 *
	 * @param value the value
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void notContainsCheck(String value) throws ByPassFilterException,
			RejectFilterException {
				if (!filterCondition.getValue().contains(value)) {
					manageException();
				}
			}

	/**
	 * Contains check.
	 *
	 * @param value the value
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void containsCheck(String value) throws ByPassFilterException,
			RejectFilterException {
				if (filterCondition.getValue().contains(value)) {
					manageException();
				}
			}

	/**
	 * Not equals check.
	 *
	 * @param value the value
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void notEqualsCheck(String value) throws ByPassFilterException,
			RejectFilterException {
				if (!filterCondition.getValue().equalsIgnoreCase(value)) {
					manageException();
				}
			}

	/**
	 * Equals check.
	 *
	 * @param value the value
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void equalsCheck(String value) throws ByPassFilterException,
			RejectFilterException {
				if (filterCondition.getValue().equalsIgnoreCase(value)) {
					manageException();
				}
			}

	/**
	 * Sets the filter condition.
	 * 
	 * @param condition
	 *            the new filter condition
	 */
	public void setFilterCondition(FilterCondition condition) {
		this.filterCondition=condition;

	}

	/**
	 * Gets the filter condition.
	 * 
	 * @return the filterCondition
	 */
	public FilterCondition getFilterCondition() {
		return filterCondition;
	}
}