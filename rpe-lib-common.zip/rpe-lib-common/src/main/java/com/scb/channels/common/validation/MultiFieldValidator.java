/**
 * 
 */
package com.scb.channels.common.validation;

import java.util.List;

import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Interface MultiFieldValidator.
 *
 * @author 1411807
 */
public interface MultiFieldValidator {

	/**
	 * Validate.
	 *
	 * @throws ValidatorException the validator exception
	 */
	void validate() throws ValidatorException;
	
	/**
	 * Sets the bean.
	 *
	 * @param bean the new bean
	 */
	void setBean(PayloadDTO bean);
	
	/**
	 * Sets the property.
	 *
	 * @param property the new property
	 */
	void setProperty(List<String> property);
}
