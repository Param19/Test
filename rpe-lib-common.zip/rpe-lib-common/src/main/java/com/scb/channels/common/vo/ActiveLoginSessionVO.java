/**
 * 
 */
package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class ActiveLoginSessionVO.
 *
 * @author 1411807
 */
public class ActiveLoginSessionVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3918822012786213944L;
	
	/** The id. */
	private Integer id;
	
	/** The user id. */
	private String userId;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The system type. */
	private String systemType;
	
	/** The session id. */
	private String sessionId;
	
	/** The channel. */
	private String channel;
	
	/** The environment. */
	private String environment;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The service dt audit. */
	private Date serviceDtAudit;
	
	/** The txn dt audit. */
	private Date txnDtAudit;

	/**
	 * Gets the service dt audit.
	 *
	 * @return the serviceDtAudit
	 */
	public Date getServiceDtAudit() {
		return serviceDtAudit;
	}

	/**
	 * Sets the service dt audit.
	 *
	 * @param serviceDtAudit the serviceDtAudit to set
	 */
	public void setServiceDtAudit(Date serviceDtAudit) {
		this.serviceDtAudit = serviceDtAudit;
	}

	/**
	 * Gets the txn dt audit.
	 *
	 * @return the txnDtAudit
	 */
	public Date getTxnDtAudit() {
		return txnDtAudit;
	}

	/**
	 * Sets the txn dt audit.
	 *
	 * @param txnDtAudit the txnDtAudit to set
	 */
	public void setTxnDtAudit(Date txnDtAudit) {
		this.txnDtAudit = txnDtAudit;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}

	/**
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	/**
	 * @return the systemType
	 */
	public String getSystemType() {
		return systemType;
	}

	/**
	 * @param systemType the systemType to set
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	/**
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the dtCreated
	 */
	public Date getDtCreated() {
		return dtCreated;
	}

	/**
	 * @param dtCreated the dtCreated to set
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	/**
	 * @return the dtUpd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}

	/**
	 * @param dtUpd the dtUpd to set
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}

}
