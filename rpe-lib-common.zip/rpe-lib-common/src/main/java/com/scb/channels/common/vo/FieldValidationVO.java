package com.scb.channels.common.vo;

/**
 * The Class FieldValidationVO.
 */
public class FieldValidationVO {

	/** The id. */
	private int id;
	
	/** The countryCode. */
	private String countryCode;
	
	/** The channelId. */
	private String channelId;
	
	/** The module. */
	private String module;
	
	/** The baseObject. */
	private String baseObject;
	
	/** The fieldName. */
	private String fieldName;
	
	/** The errorCode. */
	private String errorCode;
	
	/** The errorMsg. */
	private String errorMsg;
	
	/** The status. */
	private String status;
	
	/** The defaultValue. */
	private String defaultValue;
	
	/** The defaultErrorCode. */
	private String defaultErrorCode;
	
	/** The defaultErrorMsg. */
	private String defaultErrorMsg;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getBaseObject() {
		return baseObject;
	}

	public void setBaseObject(String baseObject) {
		this.baseObject = baseObject;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getDefaultErrorCode() {
		return defaultErrorCode;
	}

	public void setDefaultErrorCode(String defaultErrorCode) {
		this.defaultErrorCode = defaultErrorCode;
	}

	public String getDefaultErrorMsg() {
		return defaultErrorMsg;
	}

	public void setDefaultErrorMsg(String defaultErrorMsg) {
		this.defaultErrorMsg = defaultErrorMsg;
	}

	@Override
	public String toString() {
		return "FieldValidationVO [id=" + id + ", countryCode="
				+ countryCode + ", id=" + channelId + ", module="
				+ module + ", baseObject=" + baseObject + ", fieldName="
				+ fieldName + ", errorCode=" + errorCode + ", errorMsg="
				+ errorMsg + ", status=" + status + ", defaultValue="
				+ defaultValue + ", defaultErrorCode=" + defaultErrorCode
				+ ", defaultErrorMsg=" + defaultErrorMsg + "]";
	}
	
}
