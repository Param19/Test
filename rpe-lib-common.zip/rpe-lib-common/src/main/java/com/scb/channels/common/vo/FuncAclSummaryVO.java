package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

public class FuncAclSummaryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3349654234186532429L;
		
	private Integer id;
	private Integer version;
	
	private String funcCode;
	private String accCode;
	private String opsIns;
	private String currCode;
	private String blockCode;
	private String accStat;
	private String createdBy;
	private String updBy;


	private Character isCr;
	private Character isDr;
	private Character accDisplayable;
	
	private Date dtCreated;
	private Date dtUpd;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getFuncCode() {
		return funcCode;
	}
	public void setFuncCode(String funcCode) {
		this.funcCode = funcCode;
	}
	public String getAccCode() {
		return accCode;
	}
	public void setAccCode(String accCode) {
		this.accCode = accCode;
	}
	public String getOpsIns() {
		return opsIns;
	}
	public void setOpsIns(String opsIns) {
		this.opsIns = opsIns;
	}
	public String getCurrCode() {
		return currCode;
	}
	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}
	public String getBlockCode() {
		return blockCode;
	}
	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}
	public String getAccStat() {
		return accStat;
	}
	public void setAccStat(String accStat) {
		this.accStat = accStat;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdBy() {
		return updBy;
	}
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	public Character getIsCr() {
		return isCr;
	}
	public void setIsCr(Character isCr) {
		this.isCr = isCr;
	}
	public Character getIsDr() {
		return isDr;
	}
	public void setIsDr(Character isDr) {
		this.isDr = isDr;
	}
	public Character getAccDisplayable() {
		return accDisplayable;
	}
	public void setAccDisplayable(Character accDisplayable) {
		this.accDisplayable = accDisplayable;
	}
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	public Date getDtUpd() {
		return dtUpd;
	}
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	
}
