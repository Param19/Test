/**
 * 
 */
package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class CustomerPreferenceNotificationVO.
 *
 * @author 1382158
 */
public class ChannelMaskPolicyVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8913311719186158464L;
	
	/** The id. */
	private int id;
	
	private Integer groupCode;
	
	private String uuid;
	
	/** The channel Id. */
	private String channelId;
	
	/** The country code. */
	private String country;
	
	/** The category code. */
	private String categoryCode;
	
	/** The type code. */
	private String typeCode;
	
	private String fieldName;
	
	private String pattern;
	
	/** The status code. */
	private char statusCode;
	
	/** The date created. */
	private Date dateCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The date updated. */
	private Date dateUpdated;
	
	/** The updated by. */
	private String userId;
	
	private int version;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public char getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(char statusCode) {
		this.statusCode = statusCode;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * @return the groupCode
	 */
	public Integer getGroupCode() {
		return groupCode;
	}

	/**
	 * @param groupCode the groupCode to set
	 */
	public void setGroupCode(Integer groupCode) {
		this.groupCode = groupCode;
	}
	
	
	
}
