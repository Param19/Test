package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchCardTxnDAO;
import com.scb.channels.common.vo.BatchCardTxnVO;


/**
 * The Class BatchCardTxnDaoImpl.
 */
public class BatchCardTxnDaoImpl extends HibernateDaoSupport implements BatchCardTxnDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchCardTxnDAO#getBatchCardTxn(com.scb.channels.common.vo.BatchCardTxnVO)
	 */
	public List<BatchCardTxnVO> getBatchCardTxn(BatchCardTxnVO batchCardTxnVO) {
		Criteria criteria = getSession().createCriteria(BatchCardTxnVO.class);
		if(batchCardTxnVO!=null && batchCardTxnVO.getId()!=null){
			criteria.add(Restrictions.eq(HibernateHelper.ID, batchCardTxnVO.getId()));
			List<BatchCardTxnVO> list = criteria.list();
			return list;
		}else{
			return null;
		}
	}
	
}
