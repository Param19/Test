/**
 * 
 */
package com.scb.channels.common.processor;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.filters.FilterException;

/**
 * The Interface Processor.
 *
 * @author 1411807
 */
public interface Processor {
	
	/**
	 * Process.
	 *
	 * @param bean the bean
	 * @return the payload dto
	 * @throws BusinessException the business exception
	 * @throws FilterException the filter exception
	 */
	PayloadDTO process(PayloadDTO bean) throws BusinessException, FilterException;
	
	/**
	 * Do pre filter.
	 *
	 * @param bean the bean
	 * @throws FilterException the filter exception
	 */
	void doPreFilter(PayloadDTO bean) throws FilterException;
	
	/**
	 * Do post filter.
	 *
	 * @param bean the bean
	 * @throws FilterException the filter exception
	 */
	void doPostFilter(PayloadDTO bean) throws FilterException;
	
}
