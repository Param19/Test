package com.scb.channels.common.transformers;

/**
 * The Interface Transformer.
 *
 * @param <K> the key type
 * @param <V> the value type
 */
public interface Transformer<K,V> {

	/**
	 * Transform.
	 *
	 * @param v the v
	 * @return the k
	 * @throws TransformerException the transformer exception
	 */
	K transform(V v) throws TransformerException;
}
