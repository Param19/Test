package com.scb.channels.common.service;

import java.util.Map;

import com.scb.channels.common.vo.FTNarrationVO;

public interface FTNarrationService {
	Map<String,FTNarrationVO> getCacheFTNarration(String channel,String cntryCd,String  narrationType);
}
