package com.scb.channels.common.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.common.dao.FTNarrationDAO;
import com.scb.channels.common.service.FTNarrationService;
import com.scb.channels.common.vo.FTNarrationVO;

/**
 * The Class FTNarrationServiceImpl.
 */
public class FTNarrationServiceImpl implements FTNarrationService{
	
	/** The t narration dao. */
	private FTNarrationDAO fTNarrationDAO;
	/** The cache manager. */
	private CacheManager cacheManager;
	
	/** The ft narration map. */
	private Map<String ,FTNarrationVO> ftNarrationMap = new HashMap<String, FTNarrationVO>();
	

	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.FTNarrationService#getCacheFTNarration(java.lang.String, java.lang.String, java.lang.String)
	 */
	public Map<String,FTNarrationVO> getCacheFTNarration(String channel,String cntryCd,String  narrationType) {
		List<FTNarrationVO> narrationVOList=null; 
		if(cacheManager.getCache(CommonConstants.MY_CACHE).get(CommonConstants.FTNARRATION_MAP) == null){
			narrationVOList=fTNarrationDAO.get(channel,cntryCd);
		for(FTNarrationVO narrationVO :narrationVOList ){
			ftNarrationMap.put(narrationVO.getChannel()+CommonConstants.UNDERSCORE+narrationVO.getCcountryCode()
						+CommonConstants.UNDERSCORE+narrationVO.getVtrntype()+CommonConstants.UNDERSCORE+narrationVO.getVtrndesc(), narrationVO);
		}			
			cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.FTNARRATION_MAP, ftNarrationMap));
		}else {
			ftNarrationMap=  (Map<String, FTNarrationVO>) cacheManager.getCache(CommonConstants.MY_CACHE).get(CommonConstants.FTNARRATION_MAP).getValue();
		}
		 return ftNarrationMap;
	}
	

	/**
	 * Sets the f t narration dao.
	 *
	 * @param fTNarrationDAO the new f t narration dao
	 */
	public void setfTNarrationDAO(FTNarrationDAO fTNarrationDAO) {
		this.fTNarrationDAO = fTNarrationDAO;
	}



	/**
	 * Sets the cache manager.
	 *
	 * @param cacheManager the new cache manager
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}
	

	
}
