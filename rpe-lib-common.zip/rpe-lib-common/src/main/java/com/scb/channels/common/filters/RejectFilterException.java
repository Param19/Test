/**
 * 
 */
package com.scb.channels.common.filters;

/**
 * The Class RejectFilterException.
 *
 * @author 1411807
 */
public class RejectFilterException extends FilterException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8603698711647846007L;

	/**
	 * Instantiates a new reject filter exception.
	 *
	 * @param arg0 the arg0
	 */
	public RejectFilterException(Throwable arg0) {
		super(arg0);
	}
	
	/**
	 * Instantiates a new reject filter exception.
	 *
	 * @param message the message
	 */
	public RejectFilterException(String message) {
	    super(message);
	}
}
