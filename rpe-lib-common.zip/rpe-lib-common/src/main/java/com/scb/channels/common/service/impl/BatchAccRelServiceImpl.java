package com.scb.channels.common.service.impl;

import java.util.List;

import com.scb.channels.common.dao.BatchAccRelDAO;
import com.scb.channels.common.service.BatchAccRelService;
import com.scb.channels.common.vo.BatchAccRelVO;

/**
 * The Class BatchAccRelServiceImpl.
 */
public class BatchAccRelServiceImpl implements BatchAccRelService{
	
	/** The batch acc rel dao. */
	private BatchAccRelDAO batchAccRelDAO;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchAccRelService#getBatchAccountRel(com.scb.channels.common.vo.BatchAccRelVO)
	 */
	public List<BatchAccRelVO> getBatchAccountRel(BatchAccRelVO batchAccRelVO) {
		return batchAccRelDAO.getBatchAccountRel(batchAccRelVO);
	}

	/**
	 * Gets the batch acc rel dao.
	 *
	 * @return the batch acc rel dao
	 */
	public BatchAccRelDAO getBatchAccRelDAO() {
		return batchAccRelDAO;
	}

	/**
	 * Sets the batch acc rel dao.
	 *
	 * @param batchAccRelDAO the new batch acc rel dao
	 */
	public void setBatchAccRelDAO(BatchAccRelDAO batchAccRelDAO) {
		this.batchAccRelDAO = batchAccRelDAO;
	}

}
