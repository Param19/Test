package com.scb.channels.common.dao;

import java.util.List;
import java.util.Map;

import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.common.vo.ReferenceVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface ReferenceDAO.
 */
public interface ReferenceDAO {
  
	/**
	 * Insert.
	 *
	 * @param referenceVO the reference vo
	 */
	void insert(ReferenceVO referenceVO);

	/**
	 * Update.
	 *
	 * @param referenceVO the reference vo
	 */
	void update(ReferenceVO referenceVO);

	/**
	 * Delete.
	 *
	 * @param referenceVO the reference vo
	 */
	void delete(ReferenceVO referenceVO);

	/**
	 * Gets the ReferenceVO.
	 *
	 * @param referenceVO the reference vo
	 * @return the reference vo
	 */
	ReferenceVO get(ReferenceVO referenceVO);
	
	/**
	 * Gets the list.
	 *
	 * @param referenceVO the reference vo
	 * @return the list
	 */
	List<ReferenceVO> getList(ReferenceVO referenceVO);
	/**
	 * Gets the iso codes vo.
	 *
	 * @param countryCode the country code
	 * @return the iso codes vo
	 */
	List<ISOCODESVO> getIsoCodesVo(String countryCode);
	/**
	 * Gets the iso codes vo based on currency code.
	 *
	 * @param currencyCode the currency code
	 * @return the iso codes vo
	 */
	List<ISOCODESVO> getPrecisionIsoCodesVo(String currencyCode);
	
	/**
	 * Get Application Messages
	 * @param country
	 * @param channel
	 * @param component
	 * @param module
	 * @return
	 */
	public Map<String, ApplicationMessageVO> getApplicationMessages(String country,String channel,String component, String module);
}
