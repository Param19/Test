/**
 * 
 */
package com.scb.channels.common.filters.impl;



import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.filters.ByPassFilterException;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.filters.FilterType;
import com.scb.channels.common.filters.PreFilter;
import com.scb.channels.common.filters.RejectFilterException;

/**
 * The Class CheckFilter.
 *
 * @author 1411807
 */
public class CheckFilter extends AbstractPreFilter implements PreFilter {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CheckFilter.class);
	
	

	/**
	 * Filter.
	 * 
	 * @param bean
	 *            the bean
	 * @throws FilterException
	 *             the filter exception
	 * @see com.scb.channels.common.filters.PreFilter#filter(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void filter(PayloadDTO bean) throws FilterException {
		try {
			String value = (String) PropertyUtils.getProperty(bean, getFilterCondition().getProperty());
			
			switch (getFilterCondition().getOperation()) {
			case NOT_EQUALS:
				equalsCheck(value);
				break;
			case EQUALS:
				notEqualsCheck(value);
				break;
			case NOT_CONTAINS:
				containsCheck(value);
				break;
			case CONTAINS:
				notContainsCheck(value);
				break;
			case LIST_CONTAINS:
				listContainsCheck(value);
				break;
			case LIST_NOTCONTAINS:
				listNotContainsCheck(value);	
				break;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new FilterException(e);
		} 

	}


	/**
	 * Manage exception.
	 *
	 * @throws ByPassFilterException the by pass filter exception
	 * @throws RejectFilterException the reject filter exception
	 */
	public void manageException() throws ByPassFilterException,
			RejectFilterException {
		if (getFilterCondition().getFilterType().equals(FilterType.CHECK_AND_PASS)) {
			   throw new ByPassFilterException(CommonConstants.CONDITION_NOT_MET);
		   } else {
			   throw new RejectFilterException(CommonConstants.CONDITION_NOT_MET);
		   }
	}


	

}
