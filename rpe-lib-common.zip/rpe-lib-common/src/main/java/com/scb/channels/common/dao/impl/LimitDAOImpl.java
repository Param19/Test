/**
 * 
 */
package com.scb.channels.common.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.LimitDAO;
import com.scb.channels.common.vo.LimitCriteriaVO;
import com.scb.channels.common.vo.LimitDefinitionVO;
import com.scb.channels.common.vo.OverallLimitVO;
import com.scb.channels.common.vo.TransactionLimitVO;

/**
 * The Class LimitDAOImpl.
 *
 * @author 1411807
 */
public class LimitDAOImpl extends HibernateDaoSupport implements LimitDAO {


	/**
	 * Gets the overall limits.
	 * 
	 * @param custId
	 *            the cust id
	 * @param country
	 *            the country
	 * @param channelId
	 *            the channel id
	 * @return the overall limits
	 * @see com.scb.channels.transaction.transfer.dao.LimitDAO#getOverallLimits(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public List<OverallLimitVO> getOverallLimits(String custId, String country,
			String channelId) {
		
		Criteria criteria = getSession().createCriteria(OverallLimitVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CUST_ID, custId));
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, channelId));
		return criteria.list();
	}

	
	/**
	 * Gets the transaction limits.
	 * 
	 * @param custId
	 *            the cust id
	 * @param country
	 *            the country
	 * @param channelId
	 *            the channel id
	 * @param txnType
	 *            the txn type
	 * @param srcCUR
	 *            the src cur
	 * @param destCUR
	 *            the dest cur
	 * @return the transaction limits
	 * @see com.scb.channels.transaction.transfer.dao.LimitDAO#getTransactionLimits(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public List<TransactionLimitVO> getTransactionLimits(String custId,
			String country, String channelId, String txnType, String srcCUR,
			String destCUR) {
		Criteria criteria = getSession().createCriteria(TransactionLimitVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CUST_ID, custId));
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY, country));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, channelId));
		criteria.add(Restrictions.eq(HibernateHelper.TXN_TYPE_CD, txnType));
		if (!(CommonConstants.ALL.equalsIgnoreCase(srcCUR) || CommonConstants.ALL.equalsIgnoreCase(destCUR))) {
			criteria.add(Restrictions.eq(HibernateHelper.SRC_CURRENCY, srcCUR));
			criteria.add(Restrictions.eq(HibernateHelper.DEST_CURRENCY, destCUR));
		}
		return criteria.list();
	}

	
	/**
	 * Gets the customer limits.
	 *
	 * @param custId the cust id
	 * @param channelId the channel id
	 * @param limitSegmentCode the limit segment code
	 * @param txnType the txn type
	 * @return the customer limits
	 * @see com.scb.channels.transaction.transfer.dao.LimitDAO#getCustomerLimits(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public Map<String, Map<String, Double>>  getCustomerLimits(String custId, String channelId, String limitSegmentCode, String txnType) {
		
		Criteria criteria = getSession().createCriteria(LimitDefinitionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CUST_ID, custId));
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, channelId));
		criteria.add(Restrictions.eq(HibernateHelper.LIMIT_SEG_CODE, limitSegmentCode));
		criteria.add(Restrictions.in(HibernateHelper.TXN_TYPE_CD, new Object[]{txnType, HibernateHelper.NA}));
		List <LimitDefinitionVO> list=criteria.list();
		Map<String, Map<String, Double>> map = new HashMap<String, Map<String, Double>>();
		Map<String, Double> limitMap = null;
		for (LimitDefinitionVO limit: list) {
			String limitType = limit.getLimitType();
			if (map.containsKey(limitType)) {
				limitMap = map.get(limitType);
				limitMap.put(limit.getSrcCurrency()+CommonConstants.HYPHEN+limit.getDestCurrency(), limit.getAmount());
				map.put(limitType, limitMap);
			} else {
				limitMap = new HashMap<String, Double>();
				limitMap.put(limit.getSrcCurrency()+CommonConstants.HYPHEN+limit.getDestCurrency(), limit.getAmount());
				map.put(limitType, limitMap);
			}
		}
		return map;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LimitDAO#getCountryLimits(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public Map<String, Map<String, Double>>  getCountryLimits(String channelId, String limitSegmentCode, String txnType) {
		
		Criteria criteria = getSession().createCriteria(LimitDefinitionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, channelId));
		criteria.add(Restrictions.eq(HibernateHelper.LIMIT_SEG_CODE, limitSegmentCode));
		criteria.add(Restrictions.in(HibernateHelper.TXN_TYPE_CD, new Object[]{txnType, HibernateHelper.NA}));
		List <LimitDefinitionVO> list=criteria.list();
		Map<String, Map<String, Double>> map = new HashMap<String, Map<String, Double>>();
		Map<String, Double> limitMap = null;
		for (LimitDefinitionVO limit: list) {
			String limitType = limit.getLimitType();
			if (map.containsKey(limitType)) {
				limitMap = map.get(limitType);
				limitMap.put(limit.getSrcCurrency()+CommonConstants.HYPHEN+limit.getDestCurrency(), limit.getAmount());
				map.put(limitType, limitMap);
			} else {
				limitMap = new HashMap<String, Double>();
				limitMap.put(limit.getSrcCurrency()+CommonConstants.HYPHEN+limit.getDestCurrency(), limit.getAmount());
				map.put(limitType, limitMap);
			}
		}
		return map;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.LimitDAO#getMaximumLimits(java.lang.String, java.lang.String)
	 */
	public Map<String, Map<String, Double>>  getMaximumLimits(String channelId, String limitSegmentCode) {
		Criteria criteria = getSession().createCriteria(LimitDefinitionVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, channelId));
		criteria.add(Restrictions.eq(HibernateHelper.LIMIT_SEG_CODE, limitSegmentCode));
		criteria.add(Restrictions.in(HibernateHelper.LMT_TYP_CODE, new Object[]{HibernateHelper.MDTL}));
		List <LimitDefinitionVO> list=criteria.list();
		Map<String, Map<String, Double>> map = new HashMap<String, Map<String, Double>>();
		Map<String, Double> limitMap = null;
		for (LimitDefinitionVO limit: list) {
			String limitType = limit.getLimitType();
			if (map.containsKey(limitType)) {
				limitMap = map.get(limitType);
				limitMap.put(limit.getSrcCurrency()+CommonConstants.HYPHEN+limit.getDestCurrency(), limit.getAmount());
				map.put(limitType, limitMap);
			} else {
				limitMap = new HashMap<String, Double>();
				limitMap.put(limit.getSrcCurrency()+CommonConstants.HYPHEN+limit.getDestCurrency(), limit.getAmount());
				map.put(limitType, limitMap);
			}
		}
		return map;
	}

	/**
	 * Gets the criteria.
	 *
	 * @param cntryId the cntry id
	 * @param retailSegmentCode the retail segment code
	 * @param resident the resident
	 * @param staffFlag the staff flag
	 * @param salaryAC the salary ac
	 * @return the criteria
	 * @see com.scb.channels.transaction.transfer.dao.LimitDAO#getCriteria(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public LimitCriteriaVO getCriteria(String cntryId,
			String retailSegmentCode,  String resident, String staffFlag, String salaryAC) {
		Criteria criteria = getSession().createCriteria(LimitCriteriaVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.CTRY_CD, cntryId));
		criteria.add(Restrictions.eq(HibernateHelper.RETAIL_SEG_NO, retailSegmentCode));
		criteria.add(Restrictions.eq(HibernateHelper.SEGMENT_CRITERIA_TYPE, resident+staffFlag+salaryAC));
		List<LimitCriteriaVO> list = criteria.list();
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list.get(0);
		}
		
	}



}
