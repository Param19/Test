package com.scb.channels.common.dao;

import java.util.List;

import com.scb.channels.common.vo.BatchAccRelVO;

/**
 * The Interface BatchAccRelDAO.
 */
public interface BatchAccRelDAO {
	
	/**
	 * Gets the batch account rel.
	 *
	 * @param batchAccRelVO the batch acc rel vo
	 * @return the batch account rel
	 */
	List<BatchAccRelVO> getBatchAccountRel(BatchAccRelVO batchAccRelVO);

}
