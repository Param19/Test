package com.scb.channels.common.service.impl;

import com.scb.channels.common.dao.BatchAccBalDAO;
import com.scb.channels.common.service.BatchAccBalService;
import com.scb.channels.common.vo.BatchAccBalVO;

/**
 * The Class BatchAccBalServiceImpl.
 */
public class BatchAccBalServiceImpl implements BatchAccBalService {
	
	/** The batch acc bal dao. */
	private BatchAccBalDAO batchAccBalDAO;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchAccBalService#getBatchAccountBalance(java.lang.String, java.lang.String)
	 */
	public BatchAccBalVO getBatchAccountBalance(String accNo, String custId) {
		return batchAccBalDAO.getBatchAccountBalance(accNo, custId);
	}

	
	/**
	 * Gets the batch acc bal dao.
	 *
	 * @return the batch acc bal dao
	 */
	public BatchAccBalDAO getBatchAccBalDAO() {
		return batchAccBalDAO;
	}

	/**
	 * Sets the batch acc bal dao.
	 *
	 * @param batchAccBalDAO the new batch acc bal dao
	 */
	public void setBatchAccBalDAO(BatchAccBalDAO batchAccBalDAO) {
		this.batchAccBalDAO = batchAccBalDAO;
	}

}
