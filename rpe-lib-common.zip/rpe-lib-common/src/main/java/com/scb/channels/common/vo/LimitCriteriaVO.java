/**
 * 
 */
package com.scb.channels.common.vo;

import java.io.Serializable;

/**
 * The Class LimitCriteriaVO.
 *
 * @author 1411807
 */
public class LimitCriteriaVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8152966248971064720L;
	
	/** The segment criteria type. */
	private String segmentCriteriaType;
	
	/** The segment criteria value. */
	private String segmentCriteriaValue;
	
	/** The limit segment code. */
	private String limitSegmentCode;
	
	/** The limit segment name. */
	private String limitSegmentName;
	
	/** The segment code. */
	private String segmentCode;
	
	/** The retail seg code. */
	private String retailSegCode;
	
	/** The field name. */
	private String fieldName;
	
	/** The ctry code. */
	private String ctryCode;
	
	/** The segment priority. */
	private Integer segmentPriority;

	/**
	 * Gets the segment criteria type.
	 *
	 * @return the segmentCriteriaType
	 */
	public String getSegmentCriteriaType() {
		return segmentCriteriaType;
	}

	/**
	 * Sets the segment criteria type.
	 *
	 * @param segmentCriteriaType the segmentCriteriaType to set
	 */
	public void setSegmentCriteriaType(String segmentCriteriaType) {
		this.segmentCriteriaType = segmentCriteriaType;
	}

	/**
	 * Gets the segment criteria value.
	 *
	 * @return the segmentCriteriaValue
	 */
	public String getSegmentCriteriaValue() {
		return segmentCriteriaValue;
	}

	/**
	 * Sets the segment criteria value.
	 *
	 * @param segmentCriteriaValue the segmentCriteriaValue to set
	 */
	public void setSegmentCriteriaValue(String segmentCriteriaValue) {
		this.segmentCriteriaValue = segmentCriteriaValue;
	}

	/**
	 * Gets the limit segment code.
	 *
	 * @return the limitSegmentCode
	 */
	public String getLimitSegmentCode() {
		return limitSegmentCode;
	}

	/**
	 * Sets the limit segment code.
	 *
	 * @param limitSegmentCode the limitSegmentCode to set
	 */
	public void setLimitSegmentCode(String limitSegmentCode) {
		this.limitSegmentCode = limitSegmentCode;
	}

	/**
	 * Gets the field name.
	 *
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * Sets the field name.
	 *
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * Gets the limit segment name.
	 *
	 * @return the limitSegmentName
	 */
	public String getLimitSegmentName() {
		return limitSegmentName;
	}

	/**
	 * Sets the limit segment name.
	 *
	 * @param limitSegmentName the limitSegmentName to set
	 */
	public void setLimitSegmentName(String limitSegmentName) {
		this.limitSegmentName = limitSegmentName;
	}

	/**
	 * Gets the segment code.
	 *
	 * @return the segmentCode
	 */
	public String getSegmentCode() {
		return segmentCode;
	}

	/**
	 * Sets the segment code.
	 *
	 * @param segmentCode the segmentCode to set
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	/**
	 * Gets the retail seg code.
	 *
	 * @return the retailSegCode
	 */
	public String getRetailSegCode() {
		return retailSegCode;
	}

	/**
	 * Sets the retail seg code.
	 *
	 * @param retailSegCode the retailSegCode to set
	 */
	public void setRetailSegCode(String retailSegCode) {
		this.retailSegCode = retailSegCode;
	}

	/**
	 * Gets the ctry code.
	 *
	 * @return the ctryCode
	 */
	public String getCtryCode() {
		return ctryCode;
	}

	/**
	 * Sets the ctry code.
	 *
	 * @param ctryCode the ctryCode to set
	 */
	public void setCtryCode(String ctryCode) {
		this.ctryCode = ctryCode;
	}

	/**
	 * Gets the segment priority.
	 *
	 * @return the segmentPriority
	 */
	public Integer getSegmentPriority() {
		return segmentPriority;
	}

	/**
	 * Sets the segment priority.
	 *
	 * @param segmentPriority the segmentPriority to set
	 */
	public void setSegmentPriority(Integer segmentPriority) {
		this.segmentPriority = segmentPriority;
	}


}
