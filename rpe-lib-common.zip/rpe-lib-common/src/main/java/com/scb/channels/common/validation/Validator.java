/**
 * 
 */
package com.scb.channels.common.validation;

import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Interface Validator.
 *
 * @author 1411807
 */
public interface Validator {
	
	/**
	 * Validate.
	 *
	 * @throws ValidatorException the validator exception
	 */
	void validate() throws ValidatorException;
	
	/**
	 * Sets the bean.
	 *
	 * @param bean the new bean
	 */
	void setBean(PayloadDTO bean);
	
	/**
	 * Sets the property.
	 *
	 * @param property the new property
	 */
	void setProperty(String property);
}
