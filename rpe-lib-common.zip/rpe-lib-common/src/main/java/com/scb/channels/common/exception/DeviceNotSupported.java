package com.scb.channels.common.exception;

public class DeviceNotSupported extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4486715121444751432L;

	public DeviceNotSupported() {
	}
	
	public DeviceNotSupported(String deviceID) {
		super(deviceID);
	}
}
