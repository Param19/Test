package com.scb.channels.common.service.impl;

import java.util.List;

import com.scb.channels.common.dao.BatchCardTxnDAO;
import com.scb.channels.common.service.BatchCardTxnService;
import com.scb.channels.common.vo.BatchCardTxnVO;

/**
 * The Class BatchCardTxnServiceImpl.
 */
public class BatchCardTxnServiceImpl implements BatchCardTxnService {
	
	/** The batch card txn dao. */
	private BatchCardTxnDAO batchCardTxnDAO;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchCardTxnService#getBatchCardTxn(com.scb.channels.common.vo.BatchCardTxnVO)
	 */
	public List<BatchCardTxnVO> getBatchCardTxn(BatchCardTxnVO batchCardTxnVO) {
		return batchCardTxnDAO.getBatchCardTxn(batchCardTxnVO);
	}

	
	/**
	 * Gets the batch card txn dao.
	 *
	 * @return the batch card txn dao
	 */
	public BatchCardTxnDAO getBatchCardTxnDAO() {
		return batchCardTxnDAO;
	}

	/**
	 * Sets the batch card txn dao.
	 *
	 * @param batchCardTxnDAO the new batch card txn dao
	 */
	public void setBatchCardTxnDAO(BatchCardTxnDAO batchCardTxnDAO) {
		this.batchCardTxnDAO = batchCardTxnDAO;
	}

}
