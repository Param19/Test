package com.scb.channels.common.service;

import com.scb.channels.common.vo.BatchAccBalVO;

/**
 * The Interface BatchAccBalService.
 */
public interface BatchAccBalService {
	
	/**
	 * Gets the Batch Account Balance.
	 *
	 * @param id the id
	 * @param custId the cust id
	 * @return the BatchAccBalVO
	 */
	BatchAccBalVO getBatchAccountBalance(String accNo,String custId);

}
