/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.validation.MultiFieldValidator;
import com.scb.channels.common.vo.ReferenceVO;

/**
 * The Class AccountValidator.
 *
 * @author 1464143 This class used to check the validation for Account Number
 */
public class RegisterCustomerPreValidator implements MultiFieldValidator {

	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private List<String> property;
	
	/** The reference service. */
	private ReferenceService referenceService;
	
	
	

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		
		this.property = property;
	}
	
	

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		Object obj = null;
		try {
			obj = (Object) PropertyUtils.getProperty(bean, property.get(0));
			if(obj==null)
			{
				throw new ValidatorException("Invalid Customer Details field present");
				
			}else{					
					String segmentCd = (String)PropertyUtils.getProperty(obj, property.get(1));
					if (checkForAllowedSegmentCodes(segmentCd)) {
						throw new ValidatorException("Segment cod not allowed for registration.");
					}
					
					
				}					
		} catch (Exception e) {
			throw new ValidatorException(
					"Invalid Customer Details field present");
		}		
	

	}

	
	
	
	
	
	public boolean checkForAllowedSegmentCodes(String strSegCode) throws ValidatorException {
		
	String segmentCd = null;
	ReferenceVO referenceVO = new ReferenceVO();
	referenceVO.setType(CommonConstants.TYPE_ADC_BO_MASTER);
	referenceVO.setRefCode(CommonConstants.REFCD_ALLOWED_SEGMENTS);
	referenceVO = referenceService.getReference(referenceVO);
	segmentCd=referenceVO.getRefValue();
	String[] segmentCdArray = segmentCd.split(",");
	List<String> segmentCdList = Arrays.asList(segmentCdArray);

	if (segmentCdList.contains(strSegCode))
	{
		return false;
	}else{
		return true;
	}
	}
	


	


	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean =  bean;
		
	}





	/**
	 * @param referenceService the referenceService to set
	 */
	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}



	


	
}
