package com.scb.channels.common.vo;

import java.io.Serializable;

/**
 * The Class FTNarrationVO.
 */
public class FTNarrationVO implements Serializable {


	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 925746638084142533L;
	
	/** The ccountry code. */
	private String ccountryCode; 		
	
	/** The vtrntype. */
	private String vtrntype;     		
	
	/** The vcrnarration1. */
	private String vcrnarration1 ;
	
	/** The vcrnarration2. */
	private String vcrnarration2 ;		
	
	/** The vcrnarration3. */
	private String vcrnarration3 ;		
	
	/** The vcrnarration4. */
	private String vcrnarration4 ;	
	
	/** The vcrnarration5. */
	private String vcrnarration5 ;
	/** The vcrnarration6. */
	private String vcrnarration6 ;
	
	public String getVcrnarration5() {
		return vcrnarration5;
	}

	public void setVcrnarration5(String vcrnarration5) {
		this.vcrnarration5 = vcrnarration5;
	}

	public String getVcrnarration6() {
		return vcrnarration6;
	}

	public void setVcrnarration6(String vcrnarration6) {
		this.vcrnarration6 = vcrnarration6;
	}

	public String getVdrnarration5() {
		return vdrnarration5;
	}

	public void setVdrnarration5(String vdrnarration5) {
		this.vdrnarration5 = vdrnarration5;
	}

	public String getVdrnarration6() {
		return vdrnarration6;
	}

	public void setVdrnarration6(String vdrnarration6) {
		this.vdrnarration6 = vdrnarration6;
	}

	/** The vdrnarration1. */
	private String vdrnarration1 ;		
	
	/** The vdrnarration2. */
	private String vdrnarration2 ;		
	
	/** The vdrnarration3. */
	private String vdrnarration3 ;		
	
	/** The vdrnarration4. */
	private String vdrnarration4 ;
	/** The vdrnarration5. */
	private String vdrnarration5 ;	
	/** The vdrnarration6. */
	private String vdrnarration6 ;	
	
	/** The vtrndesc. */
	private String vtrndesc ;    		
	
	/** The reversal not required. */
	private String reversalNotRequired;	
	
	/** The lang. */
	private String lang ;		  	
	
	/** The channel. */
	private String channel;
	
	/**
	 * Gets the ccountry code.
	 *
	 * @return the ccountry code
	 */
	public String getCcountryCode() {
		return ccountryCode;
	}
	
	/**
	 * Sets the ccountry code.
	 *
	 * @param ccountryCode the new ccountry code
	 */
	public void setCcountryCode(String ccountryCode) {
		this.ccountryCode = ccountryCode;
	}
	
	/**
	 * Gets the vtrntype.
	 *
	 * @return the vtrntype
	 */
	public String getVtrntype() {
		return vtrntype;
	}
	
	/**
	 * Sets the vtrntype.
	 *
	 * @param vtrntype the new vtrntype
	 */
	public void setVtrntype(String vtrntype) {
		this.vtrntype = vtrntype;
	}
	
	/**
	 * Gets the vcrnarration1.
	 *
	 * @return the vcrnarration1
	 */
	public String getVcrnarration1() {
		return vcrnarration1;
	}
	
	/**
	 * Sets the vcrnarration1.
	 *
	 * @param vcrnarration1 the new vcrnarration1
	 */
	public void setVcrnarration1(String vcrnarration1) {
		this.vcrnarration1 = vcrnarration1;
	}
	
	/**
	 * Gets the vcrnarration2.
	 *
	 * @return the vcrnarration2
	 */
	public String getVcrnarration2() {
		return vcrnarration2;
	}
	
	/**
	 * Sets the vcrnarration2.
	 *
	 * @param vcrnarration2 the new vcrnarration2
	 */
	public void setVcrnarration2(String vcrnarration2) {
		this.vcrnarration2 = vcrnarration2;
	}
	
	/**
	 * Gets the vcrnarration3.
	 *
	 * @return the vcrnarration3
	 */
	public String getVcrnarration3() {
		return vcrnarration3;
	}
	
	/**
	 * Sets the vcrnarration3.
	 *
	 * @param vcrnarration3 the new vcrnarration3
	 */
	public void setVcrnarration3(String vcrnarration3) {
		this.vcrnarration3 = vcrnarration3;
	}
	
	/**
	 * Gets the vcrnarration4.
	 *
	 * @return the vcrnarration4
	 */
	public String getVcrnarration4() {
		return vcrnarration4;
	}
	
	/**
	 * Sets the vcrnarration4.
	 *
	 * @param vcrnarration4 the new vcrnarration4
	 */
	public void setVcrnarration4(String vcrnarration4) {
		this.vcrnarration4 = vcrnarration4;
	}
	
	/**
	 * Gets the vdrnarration1.
	 *
	 * @return the vdrnarration1
	 */
	public String getVdrnarration1() {
		return vdrnarration1;
	}
	
	/**
	 * Sets the vdrnarration1.
	 *
	 * @param vdrnarration1 the new vdrnarration1
	 */
	public void setVdrnarration1(String vdrnarration1) {
		this.vdrnarration1 = vdrnarration1;
	}
	
	/**
	 * Gets the vdrnarration2.
	 *
	 * @return the vdrnarration2
	 */
	public String getVdrnarration2() {
		return vdrnarration2;
	}
	
	/**
	 * Sets the vdrnarration2.
	 *
	 * @param vdrnarration2 the new vdrnarration2
	 */
	public void setVdrnarration2(String vdrnarration2) {
		this.vdrnarration2 = vdrnarration2;
	}
	
	/**
	 * Gets the vdrnarration3.
	 *
	 * @return the vdrnarration3
	 */
	public String getVdrnarration3() {
		return vdrnarration3;
	}
	
	/**
	 * Sets the vdrnarration3.
	 *
	 * @param vdrnarration3 the new vdrnarration3
	 */
	public void setVdrnarration3(String vdrnarration3) {
		this.vdrnarration3 = vdrnarration3;
	}
	
	/**
	 * Gets the vdrnarration4.
	 *
	 * @return the vdrnarration4
	 */
	public String getVdrnarration4() {
		return vdrnarration4;
	}
	
	/**
	 * Sets the vdrnarration4.
	 *
	 * @param vdrnarration4 the new vdrnarration4
	 */
	public void setVdrnarration4(String vdrnarration4) {
		this.vdrnarration4 = vdrnarration4;
	}
	
	/**
	 * Gets the vtrndesc.
	 *
	 * @return the vtrndesc
	 */
	public String getVtrndesc() {
		return vtrndesc;
	}
	
	/**
	 * Sets the vtrndesc.
	 *
	 * @param vtrndesc the new vtrndesc
	 */
	public void setVtrndesc(String vtrndesc) {
		this.vtrndesc = vtrndesc;
	}
	
	/**
	 * Gets the reversal not required.
	 *
	 * @return the reversal not required
	 */
	public String getReversalNotRequired() {
		return reversalNotRequired;
	}
	
	/**
	 * Sets the reversal not required.
	 *
	 * @param reversalNotRequired the new reversal not required
	 */
	public void setReversalNotRequired(String reversalNotRequired) {
		this.reversalNotRequired = reversalNotRequired;
	}
	
	/**
	 * Gets the lang.
	 *
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}
	
	/**
	 * Sets the lang.
	 *
	 * @param lang the new lang
	 */
	public void setLang(String lang) {
		this.lang = lang;
	}
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the new channel
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	
	
}
