package com.scb.channels.common.jms.receiver;

import org.springframework.jms.core.JmsTemplate;

import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.common.transformers.Transformer;

public interface Receiver<K> {

	/**
	 * Receive message.
	 *
	 * @param requestId the request id
	 * @return the biller pay response vo
	 */
	public abstract BaseVO receiveMessage(String requestId);

	/**
	 * Sets the jms template.
	 *
	 * @param jmsTemplate the jmsTemplate to set
	 */
	public abstract void setJmsTemplate(JmsTemplate jmsTemplate);

	/**
	 * Sets the transformer.
	 *
	 * @param transformer the transformer to set
	 */
	public abstract void setTransformer(
			Transformer<K, String> transformer);

}