package com.scb.channels.common.dao.impl;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.common.dao.ReferenceDAO;
import com.scb.channels.common.vo.ReferenceVO;

/**
 * The Class ReferenceDAOImpl.
 */
public class ReferenceDAOImpl extends HibernateDaoSupport implements ReferenceDAO {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(ReferenceDAOImpl.class);
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.ReferenceDAO#insert(com.scb.channels.common.vo.ReferenceVO)
	 */
	public void insert(ReferenceVO referenceVO) {
		getHibernateTemplate().save(referenceVO);
		

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.ReferenceDAO#update(com.scb.channels.common.vo.ReferenceVO)
	 */
	public void update(ReferenceVO referenceVO) {
		Query query = getSession().createQuery("update ReferenceVO set refCd =:refCd, statusCd =:statusCd,dtUpd=:dtUpd ,updBy=:updBy where id=:id ");
		query.setParameter(HibernateHelper.REF_CD, referenceVO.getRefCode());
		//query.setParameter(HibernateHelper.STATUS_CODE, referenceVO.getStatusCode());
		query.setParameter(HibernateHelper.DATE_UPDATE, DateUtils.getCurrentDate());
		query.setParameter(HibernateHelper.UPDATE_BY, referenceVO.getUpdatedBy());
		query.setParameter(HibernateHelper.ID, referenceVO.getId());
		query.executeUpdate();   	

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.ReferenceDAO#delete(com.scb.channels.common.vo.ReferenceVO)
	 */
	public void delete(ReferenceVO referenceVO) {
		/*String sqlQuery="delete from ReferenceVO where id= :id";
		Query query= getSession().createQuery(sqlQuery);
		query.setParameter(HibernateHelper.ID, referenceVO.getId());
		query.executeUpdate();*/
		getSession().delete(referenceVO);

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.ReferenceDAO#get(com.scb.channels.common.vo.ReferenceVO)
	 */
	public ReferenceVO get(ReferenceVO referenceVO) { 
		org.hibernate.Criteria criteria =  getSession().createCriteria(ReferenceVO.class);
		if (referenceVO.getId() != null) {
			criteria.add(Restrictions.eq(HibernateHelper.ID, referenceVO.getId()));
		}
		if (referenceVO.getCountryCode() != null) {
			criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, referenceVO.getCountryCode()));
		}
		if (referenceVO.getChannelId() != null) {
			criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, referenceVO.getCountryCode()));
		}
		if (referenceVO.getType() != null) {
			criteria.add(Restrictions.eq(HibernateHelper.TYPE, referenceVO.getType()));
		}
		if (referenceVO.getRefCode() != null) {
			criteria.add(Restrictions.eq(HibernateHelper.REF_CD, referenceVO.getRefCode()));
		}
		
		//criteria.add(Restrictions.eq(HibernateHelper.STATUS_CODE, referenceVO.getStatusCode()));
	
		LOGGER.info("ReferenceDAOImpl, criteria () {}-{}-{}-{}",new Object[] {criteria});
		List<ReferenceVO> list = criteria.list();
		
		return list.size()==0? null : list.get(0);
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.ReferenceDAO#get(com.scb.channels.common.vo.ReferenceVO)
	 */
	public List<ReferenceVO> getList(ReferenceVO referenceVO) {
		
		LOGGER.info("ReferenceDAOImpl, getList: Start {}-{}-{}-{}",new Object[] {referenceVO});
		Session session = null;
		List<ReferenceVO> list = null;
		
		try {
			session = getHibernateTemplate().getSessionFactory().openSession();
			
			Criteria criteria = session.createCriteria(ReferenceVO.class);
			
			if (referenceVO.getCountryCode() != null) {
				criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, referenceVO.getCountryCode()));
			}
			if (referenceVO.getChannelId() != null) {
				criteria.add(Restrictions.eq(HibernateHelper.CHANNEL_ID, referenceVO.getChannelId()));
			}
			if (referenceVO.getType() != null) {
				criteria.add(Restrictions.eq(HibernateHelper.TYPE, referenceVO.getType()));
			}
			
			if (referenceVO.getAggregator() != null) {
				criteria.add(Restrictions.eq(HibernateHelper.AGGREGATOR, referenceVO.getAggregator()));
			}
			
			if (referenceVO.getApiVersion() != null) {
				criteria.add(Restrictions.eq(HibernateHelper.API_Version, referenceVO.getApiVersion()));
			}
			
			criteria.add(Restrictions.eq(HibernateHelper.STATUS_CODE, CommonConstants.ACTIVE));
			
			LOGGER.info("ReferenceDAOImpl, criteria () {}",new Object[] {criteria});
		
			list = criteria.list();

		} catch (Exception exp) {
			LOGGER.error("ReferenceDAOImpl, getList Exception ()", exp);
		} finally {
			if(session != null && session.isOpen()) {
				session.close();
				LOGGER.info("ReferenceDAOImpl, getList, closing session");
			}
		}
		LOGGER.info("ReferenceDAOImpl, list () {}-{}-{}-{}",new Object[] {list});
		return list;
	}
	public List<ISOCODESVO> getIsoCodesVo(String countryCode)
    {
          ISOCODESVO dbIsoCodes = null;
          Session session = null;
          List<ISOCODESVO> listIsocodesvos =null;
          try{
                 LOGGER.info("Fetching ISO Codes for following country::::"+countryCode);
                 session = getHibernateTemplate().getSessionFactory().openSession();
                 Criteria criteria = session.createCriteria(ISOCODESVO.class);
                 criteria.add(Restrictions.eq("countrycode", countryCode));
                 listIsocodesvos = criteria.list();
                /* if(object != null) {
                        dbIsoCodes = (ISOCODESVO) object;
                        LOGGER.info("Obtained persistent object ::: " + countryCode);
                 } else {
                        LOGGER.info("No data in the DB for ::: " + countryCode);
                 }*/
          }catch(Exception e)
          {
                 LOGGER.error("Exception occurred duirng fetching IsoCodes::: ", e);
          } finally {
                 if(session != null) {
                        LOGGER.info("QRPaymentDAOImpl :IsoCodes, closing Session ");
                        session.close();
                 }
          }
          return listIsocodesvos;
    }
	
	public List<ISOCODESVO> getPrecisionIsoCodesVo(String currencyCode){
         
          Session session = null;
          List<ISOCODESVO> listIsocodesvos =null;
          try{
                 LOGGER.info("Fetching ISO Codes for following country::::"+currencyCode);
                 session = getHibernateTemplate().getSessionFactory().openSession();
                 Criteria criteria = session.createCriteria(ISOCODESVO.class);
                 /*ProjectionList projectionsList = Projections.projectionList();*/
                 Disjunction orCondition = Restrictions.disjunction();
                 
                 /*projectionsList.add(Projections.property("countrycode").as("countrycode"));
                 projectionsList.add(Projections.property("currency_precision").as("currency_precision"));      
                 projectionsList.add(Projections.property("currencycode_numeric").as("currencycode_numeric"));
                 criteria.setProjection(projectionsList);
                 criteria.setResultTransformer(Transformers.aliasToBean(ISOCODESVO.class));*/
                 
                 orCondition.add(Restrictions.eq("countrycode",currencyCode));
                 orCondition.add(Restrictions.eq("currencycode_char",currencyCode));                 
                 if(StringUtils.isNumeric(currencyCode)){
                	 orCondition.add(Restrictions.eq("currencycode_numeric",Integer.parseInt(currencyCode)));
                 }                 
                 criteria.add(orCondition);                 
                 listIsocodesvos = criteria.list();               
          }catch(Exception e){
                 LOGGER.error("Exception occurred duirng fetching IsoCodes::: ", e);
          } finally {
                 if(session != null) {
                        LOGGER.info("QRPaymentDAOImpl :IsoCodes, closing Session ");
                        session.close();
                 }
          }
         
          return listIsocodesvos;
    }
	
	/**
	 * Get Application Messages
	 * @param country
	 * @param channel
	 * @param component
	 * @param module
	 * @return
	 */
	public Map<String,ApplicationMessageVO> getApplicationMessages(String country,String channel,String component, String module){
        LOGGER.info("BillerManagementDAOImpl -- getApplicationMessages -- ::: " + country+"----channel --- > "+channel);
        Session session=null;
        List<ApplicationMessageVO> persistentObjectList = null;
        
        Map<String,ApplicationMessageVO> dbMapObject = new HashMap<String, ApplicationMessageVO>();
        
        try{
               session = getHibernateTemplate().getSessionFactory().openSession();

               Criteria criteria = session
                            .createCriteria(ApplicationMessageVO.class);
               criteria.add(Restrictions.eq("countryCode", country));
               criteria.add(Restrictions.eq("channel", channel));
               criteria.add(Restrictions.eq(CommonConstants.COMPONENT_NAME, component));  
               criteria.add(Restrictions.eq(CommonConstants.MODULE_NAME, module));
               
               persistentObjectList = criteria.list();
               
               for (ApplicationMessageVO appMsg: persistentObjectList) {
                     dbMapObject.put(appMsg.getCompErrorCode(), appMsg);
               }
               
        } catch (Exception exception) {
               LOGGER.error("Exception occurred while getApplicationMessages :::: ", exception);
               //exception.printStackTrace();
        } finally {
               if(session != null && session.isOpen()) {
                     LOGGER.info("closing the session in getApplicationMessages");
                     session.close();
               }
        }
        LOGGER.info("BillerManagementDAOImpl -- getApplicationMessages -- End ::: ");
        return dbMapObject;
 }


}
