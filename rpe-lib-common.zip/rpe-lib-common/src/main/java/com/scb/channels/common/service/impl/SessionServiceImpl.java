package com.scb.channels.common.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.common.dao.LoginSessionDAO;
import com.scb.channels.common.service.SessionService;
import com.scb.channels.common.vo.ActiveLoginSessionVO;

/**
 * The Class SessionServiceImpl.
 */
public class SessionServiceImpl implements SessionService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SessionServiceImpl.class);

	/** The login session dao. */
	private LoginSessionDAO loginSessionDAO;
	
	/** The session timeout. */
	private Map<String, String> sessionTimeout;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.SessionService#isValidSession(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public boolean isValidSession(String userId, String country,
			String channel, String sessionId) {
		ActiveLoginSessionVO loginSessionVO = loginSessionDAO.searchActiveSession(userId, country, channel, sessionId);
		if (null != loginSessionVO) {
			int timeDiff = 0;
			if (loginSessionVO.getTxnDtAudit() != null) {
				timeDiff = new Date().getMinutes() -loginSessionVO.getTxnDtAudit().getMinutes();
			} else if (loginSessionVO.getServiceDtAudit() != null) {
				timeDiff = new Date().getMinutes() -loginSessionVO.getServiceDtAudit().getMinutes();
			} else {
				timeDiff = new Date().getMinutes() -loginSessionVO.getDtCreated().getMinutes();
			}
			int defaultTimeout=Integer.parseInt(sessionTimeout.get(CommonConstants.ADC_TIMEOUT));
			if(timeDiff > defaultTimeout){
				loginSessionDAO.deleteActiveSession(loginSessionVO);
				return false;
			}
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.SessionService#clearOldSession(java.lang.String, java.lang.String)
	 */
	public void clearOldSession(String country, String channel) {
		List<ActiveLoginSessionVO> list = loginSessionDAO.getAllActiveSession(country, channel);
		
		for (ActiveLoginSessionVO loginSessionVO : list) {
			if (null != loginSessionVO) {
				int timeDiff = 0;
				if (loginSessionVO.getTxnDtAudit() != null) {
					timeDiff = new Date().getMinutes() -loginSessionVO.getTxnDtAudit().getMinutes();
				} else if (loginSessionVO.getServiceDtAudit() != null) {
					timeDiff = new Date().getMinutes() -loginSessionVO.getServiceDtAudit().getMinutes();
				} else {
					timeDiff = new Date().getMinutes() -loginSessionVO.getDtCreated().getMinutes();
				}
				int defaultTimeout = Integer.parseInt(sessionTimeout.get(CommonConstants.ADC_TIMEOUT));
				if(timeDiff > defaultTimeout){
					loginSessionDAO.deleteActiveSession(loginSessionVO);
					LOGGER.info("Cleared the old session Id {}", loginSessionVO.getSessionId());
				}
			}
		}
	}
	
	/**
	 * Gets the login session dao.
	 *
	 * @return the loginSessionDAO
	 */
	public LoginSessionDAO getLoginSessionDAO() {
		return loginSessionDAO;
	}

	/**
	 * Sets the login session dao.
	 *
	 * @param loginSessionDAO the loginSessionDAO to set
	 */
	public void setLoginSessionDAO(LoginSessionDAO loginSessionDAO) {
		this.loginSessionDAO = loginSessionDAO;
	}

	/**
	 * Sets the session timeout.
	 *
	 * @param sessionTimeout the sessionTimeout to set
	 */
	public void setSessionTimeout(Map<String, String> sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

}
