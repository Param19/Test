package com.scb.channels.common.service.impl;

import java.util.List;

import com.scb.channels.common.dao.BatchRiskCodeDAO;
import com.scb.channels.common.service.BatchRiskCodeService;
import com.scb.channels.common.vo.BatchRiskCodeVO;

/**
 * The Class BatchRiskCodeServiceImpl.
 */
public class BatchRiskCodeServiceImpl implements BatchRiskCodeService {

	/** The batch risk code dao. */
	private BatchRiskCodeDAO batchRiskCodeDAO;
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchRiskCodeService#getBatchRiskCode(com.scb.channels.common.vo.BatchRiskCodeVO)
	 */
	public List<BatchRiskCodeVO> getBatchRiskCode(BatchRiskCodeVO batchRiskCodeVO) {
		return batchRiskCodeDAO.getBatchRiskCode(batchRiskCodeVO);
	}


	/**
	 * Gets the batch risk code dao.
	 *
	 * @return the batch risk code dao
	 */
	public BatchRiskCodeDAO getBatchRiskCodeDAO() {
		return batchRiskCodeDAO;
	}


	/**
	 * Sets the batch risk code dao.
	 *
	 * @param batchRiskCodeDAO the new batch risk code dao
	 */
	public void setBatchRiskCodeDAO(BatchRiskCodeDAO batchRiskCodeDAO) {
		this.batchRiskCodeDAO = batchRiskCodeDAO;
	}

}
