package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class BatchCardTxnVO.
 */
public class BatchCardTxnVO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8600068983746695591L;
	
	/** The id. */
	private Integer id;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The card no. */
	private String cardNo;
	
	/** The eff date. */
	private Date effDate;
	
	/** The txn date. */
	private Date txnDate;
	
	/** The txn desc. */
	private String txnDesc;
	
	/** The txn curr. */
	private String txnCurr;
	
	/** The txn type. */
	private String txnType;
	
	/** The ori txn amt. */
	private Double oriTxnAmt;
	
	/** The local txn amt. */
	private Double localTxnAmt;
	
	/** The stmt code. */
	private String stmtCode;
	
	/** The stmt date. */
	private Date stmtDate;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private Integer version;
	
	/** The stmt period. */
	private String stmtPeriod;
	
	/** The txn ccy card holder. */
	private String txnCcyCardHolder;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the card no.
	 *
	 * @return the card no
	 */
	public String getCardNo() {
		return cardNo;
	}
	
	/**
	 * Sets the card no.
	 *
	 * @param cardNo the new card no
	 */
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	
	/**
	 * Gets the eff date.
	 *
	 * @return the eff date
	 */
	public Date getEffDate() {
		return effDate;
	}
	
	/**
	 * Sets the eff date.
	 *
	 * @param effDate the new eff date
	 */
	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}
	
	/**
	 * Gets the txn date.
	 *
	 * @return the txn date
	 */
	public Date getTxnDate() {
		return txnDate;
	}
	
	/**
	 * Sets the txn date.
	 *
	 * @param txnDate the new txn date
	 */
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
	
	/**
	 * Gets the txn desc.
	 *
	 * @return the txn desc
	 */
	public String getTxnDesc() {
		return txnDesc;
	}
	
	/**
	 * Sets the txn desc.
	 *
	 * @param txnDesc the new txn desc
	 */
	public void setTxnDesc(String txnDesc) {
		this.txnDesc = txnDesc;
	}
	
	/**
	 * Gets the txn curr.
	 *
	 * @return the txn curr
	 */
	public String getTxnCurr() {
		return txnCurr;
	}
	
	/**
	 * Sets the txn curr.
	 *
	 * @param txnCurr the new txn curr
	 */
	public void setTxnCurr(String txnCurr) {
		this.txnCurr = txnCurr;
	}
	
	/**
	 * Gets the txn type.
	 *
	 * @return the txn type
	 */
	public String getTxnType() {
		return txnType;
	}
	
	/**
	 * Sets the txn type.
	 *
	 * @param txnType the new txn type
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	
	/**
	 * Gets the ori txn amt.
	 *
	 * @return the ori txn amt
	 */
	public Double getOriTxnAmt() {
		return oriTxnAmt;
	}
	
	/**
	 * Sets the ori txn amt.
	 *
	 * @param oriTxnAmt the new ori txn amt
	 */
	public void setOriTxnAmt(Double oriTxnAmt) {
		this.oriTxnAmt = oriTxnAmt;
	}
	
	/**
	 * Gets the local txn amt.
	 *
	 * @return the local txn amt
	 */
	public Double getLocalTxnAmt() {
		return localTxnAmt;
	}
	
	/**
	 * Sets the local txn amt.
	 *
	 * @param localTxnAmt the new local txn amt
	 */
	public void setLocalTxnAmt(Double localTxnAmt) {
		this.localTxnAmt = localTxnAmt;
	}
	
	/**
	 * Gets the stmt code.
	 *
	 * @return the stmt code
	 */
	public String getStmtCode() {
		return stmtCode;
	}
	
	/**
	 * Sets the stmt code.
	 *
	 * @param stmtCode the new stmt code
	 */
	public void setStmtCode(String stmtCode) {
		this.stmtCode = stmtCode;
	}
	
	/**
	 * Gets the stmt date.
	 *
	 * @return the stmt date
	 */
	public Date getStmtDate() {
		return stmtDate;
	}
	
	/**
	 * Sets the stmt date.
	 *
	 * @param stmtDate the new stmt date
	 */
	public void setStmtDate(Date stmtDate) {
		this.stmtDate = stmtDate;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the stmt period.
	 *
	 * @return the stmt period
	 */
	public String getStmtPeriod() {
		return stmtPeriod;
	}
	
	/**
	 * Sets the stmt period.
	 *
	 * @param stmtPeriod the new stmt period
	 */
	public void setStmtPeriod(String stmtPeriod) {
		this.stmtPeriod = stmtPeriod;
	}
	
	/**
	 * Gets the txn ccy card holder.
	 *
	 * @return the txn ccy card holder
	 */
	public String getTxnCcyCardHolder() {
		return txnCcyCardHolder;
	}
	
	/**
	 * Sets the txn ccy card holder.
	 *
	 * @param txnCcyCardHolder the new txn ccy card holder
	 */
	public void setTxnCcyCardHolder(String txnCcyCardHolder) {
		this.txnCcyCardHolder = txnCcyCardHolder;
	}
	
	


}
