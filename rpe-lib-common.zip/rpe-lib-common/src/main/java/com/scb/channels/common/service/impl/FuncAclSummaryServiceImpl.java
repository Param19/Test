package com.scb.channels.common.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.common.dao.FuncAclSummaryDAO;
import com.scb.channels.common.service.FuncAclSummaryService;
import com.scb.channels.common.vo.FuncAclSummaryVO;

/**
 * The Class FuncAclSummaryServiceImpl.
 */
public class FuncAclSummaryServiceImpl implements FuncAclSummaryService {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(FuncAclSummaryServiceImpl.class);
	
	/** The func acl summary dao. */
	private FuncAclSummaryDAO funcAclSummaryDAO;
	
	/** The cache manager. */
	private CacheManager cacheManager;
	
	
	/** The acc code map. */
	private Map<String,List<String>> accCodeMap = new HashMap<String,List<String>>();
	
	/** The acc code flag map. */
	private Map<String,String> accCodeFlagMap = new HashMap<String ,String>();
	
	/** The ops ins map. */
	private Map<String,List<String>> opsInsMap = new HashMap<String,List<String>>();
	
	/** The ops ins flag map. */
	private Map<String,String> opsInsFlagMap = new HashMap<String ,String>();
	
	/** The curr code map. */
	private Map<String,List<String>> currCodeMap = new HashMap<String,List<String>>();
	
	/** The curr code flag map. */
	private Map<String,String>  currCodeFlagMap = new HashMap<String ,String>();
	
	/** The account status map. */
	private Map<String,List<String>> accountStatusMap = new HashMap<String,List<String>>();
	
	/** The acc status flag map. */
	private Map<String,String>  accStatusFlagMap = new HashMap<String ,String>();
	
	/** The account status map. */
	private Map<String,List<String>> blockCodeMap = new HashMap<String,List<String>>();
	
	/** The acc status flag map. */
	private Map<String,String>  blockCodeFlagMap = new HashMap<String ,String>();
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.FuncAclSummaryService#checkProductFilter(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public boolean checkProductFilter(String funcCode, String prdCode, String opsIns, 
			String currCode ,String accountStatus, List<String> blockCodeList) {
		boolean accCodeFlag = true;
		boolean opsInsFlag = true;
		boolean currCodeFlag = true;
		boolean accountStatusFlag = true;
		boolean blockCodeFlag = true;
		populateValues();
		if (CommonConstants.WHITELIST.equalsIgnoreCase(accCodeFlagMap.get(funcCode))) {
			if (!accCodeMap.get(funcCode).contains(CommonConstants.ALL_ASTERIK)) {
				accCodeFlag = accCodeMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
						accCodeMap.get(funcCode).contains(prdCode) ;
				LOGGER.info("White list product filtering for function code, product code, accCodeFlag {} {} {}", 
						new Object[] {funcCode, prdCode, accCodeFlag});
			} 
		} else {
			accCodeFlag = !(accCodeMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
					accCodeMap.get(funcCode).contains(prdCode)) ;
			LOGGER.info("Block list product filtering for function code, product code, accCodeFlag {} {} {}", 
					new Object[] {funcCode, prdCode, accCodeFlag});
		}
		
		if (CommonConstants.WHITELIST.equalsIgnoreCase(opsInsFlagMap.get(funcCode))) {
			if (!opsInsMap.get(funcCode).contains(CommonConstants.ALL_ASTERIK)) {
				opsInsFlag = opsInsMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
						opsInsMap.get(funcCode).contains(opsIns) ;
				LOGGER.info("White list product filtering for function code, ops ins, opsInsFlag {} {} {}", 
						new Object[] {funcCode, opsIns, opsInsFlag});
			}
		} else {
			opsInsFlag = !(opsInsMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
					opsInsMap.get(funcCode).contains(opsIns)) ;
			LOGGER.info("Block list product filtering for function code, ops ins, opsInsFlag {} {} {}", 
					new Object[] {funcCode, opsIns, opsInsFlag});
		}

		if (CommonConstants.WHITELIST.equalsIgnoreCase(currCodeFlagMap.get(funcCode))) {
			if (!currCodeMap.get(funcCode).contains(CommonConstants.ALL_ASTERIK)) {
				currCodeFlag = currCodeMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
						currCodeMap.get(funcCode).contains(currCode) ;
				LOGGER.info("White list product filtering for function code, curr code, currCodeFlag {} {} {}", 
						new Object[] {funcCode, currCode, currCodeFlag});
			}
		} else {
			currCodeFlag = !(currCodeMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
					currCodeMap.get(funcCode).contains(currCode)) ;
			LOGGER.info("Block list product filtering for function code, curr code, currCodeFlag {} {} {}", 
					new Object[] {funcCode, currCode, currCodeFlag});
		}
		if (CommonConstants.WHITELIST.equalsIgnoreCase(accStatusFlagMap.get(funcCode))) {
			if (!accountStatusMap.get(funcCode).contains(CommonConstants.ALL_ASTERIK)) {
				accountStatusFlag = accountStatusMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
						accountStatusMap.get(funcCode).contains(accountStatus) ;
				LOGGER.info("White list product filtering for function code, acc status, accountStatusFlag {} {} {}", 
						new Object[] {funcCode, accountStatus, accountStatusFlag});
			}
		} else {
			accountStatusFlag = !(accountStatusMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
					accountStatusMap.get(funcCode).contains(accountStatus)) ;
			LOGGER.info("Block list product filtering for function code, acc status, accountStatusFlag {} {} {}", 
					new Object[] {funcCode, accountStatus, accountStatusFlag});
		}
		/*if (CommonConstants.WHITELIST.equalsIgnoreCase(blockCodeFlagMap.get(funcCode))) {
			if (!blockCodeMap.get(funcCode).contains(CommonConstants.ALL_ASTERIK)) {
				if (blockCodeList != null) {
					for (String blockCode : blockCodeList) {
						blockCodeFlag = blockCodeFlag && (blockCodeMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
								blockCodeMap.get(funcCode).contains(blockCode)) ;
						LOGGER.info("White list product filtering for function code, acc status, blockCodeFlagMap {} {} {}", 
								new Object[] {funcCode, accountStatus, accountStatusFlag});
					}
				}
			}
		} else {
			if (blockCodeList != null) {
				for (String blockCode : blockCodeList) {
					blockCodeFlag = blockCodeFlag && (!(blockCodeMap.get(funcCode).contains(CommonConstants.PIPE_REGEX) || 
							blockCodeMap.get(funcCode).contains(blockCode)) );
					LOGGER.info("Block list product filtering for function code, blockCode status, blockCodeFlagMap {} {} {}", 
							new Object[] {funcCode, accountStatus, accountStatusFlag});
				}
			}
		}*/
		return accCodeFlag && opsInsFlag && currCodeFlag && accountStatusFlag && blockCodeFlag;
	}

	/**
	 * Populate values.
	 */
	private void populateValues() {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		if(cache.get(CommonConstants.ACC_CODE_MAP) == null 
				|| cache.get(CommonConstants.OPS_INS_MAP)==null
				|| cache.get(CommonConstants.CURR_CODE_MAP)==null 
				|| cache.get(CommonConstants.ACCOUNT_STATUS_MAP)==null 
				|| cache.get(CommonConstants.BLOCK_CODE_MAP)==null){			
			cacheProductFilter();
		}else {
			accCodeMap=(Map<String, List<String>>) cache.get(CommonConstants.ACC_CODE_MAP).getValue();
			accCodeFlagMap=(Map<String, String>) cache.get(CommonConstants.ACC_CODE_FLAG_MAP).getValue();	
			
			opsInsMap=(Map<String, List<String>>) cache.get(CommonConstants.OPS_INS_MAP).getValue();
			opsInsFlagMap=(Map<String, String>) cache.get(CommonConstants.OPS_INS_FLAG_MAP).getValue();	
			
			currCodeMap=(Map<String, List<String>>) cache.get(CommonConstants.CURR_CODE_MAP).getValue();
			currCodeFlagMap=(Map<String, String>) cache.get(CommonConstants.CURR_CODE_FLAG_MAP).getValue();	
			
			accountStatusMap=(Map<String, List<String>>) cache.get(CommonConstants.ACCOUNT_STATUS_MAP).getValue();
			accStatusFlagMap=(Map<String, String>) cache.get(CommonConstants.ACC_STATUS_FLAG_MAP).getValue();	
			
			blockCodeMap=(Map<String, List<String>>) cache.get(CommonConstants.BLOCK_CODE_MAP).getValue();
			blockCodeFlagMap=(Map<String, String>) cache.get(CommonConstants.BLOCK_CODE_FLAG_MAP).getValue();	
		}
	}

	/**
	 * Cache product filter.
	 */
	private void cacheProductFilter() {
		List<FuncAclSummaryVO> listFuncAclSummaryVO = funcAclSummaryDAO.get();		
		for(FuncAclSummaryVO funAclSummaryVO:listFuncAclSummaryVO){
			String[] accCodeArr = funAclSummaryVO.getAccCode().split(CommonConstants.COLON);
			String[] opsInsArr = funAclSummaryVO.getOpsIns().split(CommonConstants.COLON);
			String[] currCodeArr = funAclSummaryVO.getCurrCode().split(CommonConstants.COLON);
			String[] accStatusArr = funAclSummaryVO.getAccStat().split(CommonConstants.COLON);
			String[] blockCodeArr = funAclSummaryVO.getBlockCode().split(CommonConstants.COLON);
			
			accCodeFlagMap.put(funAclSummaryVO.getFuncCode(), 
					accCodeArr[0].equals(CommonConstants.WHITELIST)?CommonConstants.WHITELIST:CommonConstants.BLOCKLIST);	
			opsInsFlagMap.put(funAclSummaryVO.getFuncCode(), 
					opsInsArr[0].equals(CommonConstants.WHITELIST)?CommonConstants.WHITELIST:CommonConstants.BLOCKLIST);
			currCodeFlagMap.put(funAclSummaryVO.getFuncCode(), 
					currCodeArr[0].equals(CommonConstants.WHITELIST)?CommonConstants.WHITELIST:CommonConstants.BLOCKLIST);
			accStatusFlagMap.put(funAclSummaryVO.getFuncCode(), 
					accStatusArr[0].equals(CommonConstants.WHITELIST)?CommonConstants.WHITELIST:CommonConstants.BLOCKLIST);
			blockCodeFlagMap.put(funAclSummaryVO.getFuncCode(), 
					blockCodeArr[0].equals(CommonConstants.WHITELIST)?CommonConstants.WHITELIST:CommonConstants.BLOCKLIST);
			
			accCodeMap.put(funAclSummaryVO.getFuncCode(),Arrays.asList(accCodeArr[1].split(CommonConstants.PIPE_REGEX)));	
			opsInsMap.put(funAclSummaryVO.getFuncCode(), Arrays.asList(opsInsArr[1].split(CommonConstants.PIPE_REGEX)));
			currCodeMap.put(funAclSummaryVO.getFuncCode(), Arrays.asList(currCodeArr[1].split(CommonConstants.PIPE_REGEX)));
			accountStatusMap.put(funAclSummaryVO.getFuncCode(), Arrays.asList(accStatusArr[1].split(CommonConstants.PIPE_REGEX)));
			blockCodeMap.put(funAclSummaryVO.getFuncCode(), Arrays.asList(blockCodeArr[1].split(CommonConstants.PIPE_REGEX)));
		}
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.ACC_CODE_MAP, accCodeMap));
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.ACC_CODE_FLAG_MAP, accCodeFlagMap));
		
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.OPS_INS_MAP, opsInsMap));
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.OPS_INS_FLAG_MAP, opsInsFlagMap));
		
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.CURR_CODE_MAP, currCodeMap));
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.CURR_CODE_FLAG_MAP, currCodeFlagMap));
		
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.ACCOUNT_STATUS_MAP, accountStatusMap));
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.ACC_STATUS_FLAG_MAP, accStatusFlagMap));
		
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.BLOCK_CODE_MAP, blockCodeMap));
		cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.BLOCK_CODE_FLAG_MAP, blockCodeMap));
	}

	/**
	 * Sets the func acl summary dao.
	 *
	 * @param funcAclSummaryDAO the new func acl summary dao
	 */
	public void setFuncAclSummaryDAO(FuncAclSummaryDAO funcAclSummaryDAO) {
		this.funcAclSummaryDAO = funcAclSummaryDAO;
	}

	/**
	 * Sets the cache manager.
	 *
	 * @param cacheManager the new cache manager
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}
    
	
}
