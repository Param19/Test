package com.scb.channels.common.service.impl;

import java.util.List;

import com.scb.channels.common.service.BatchFxRateService;
import com.scb.channels.common.vo.BatchFxRateVO;
import com.scb.channels.common.dao.BatchFxRateDAO;

/**
 * The Class BatchFxRateServiceImpl.
 */
public class BatchFxRateServiceImpl implements BatchFxRateService {
	
	/** The Batch fx rate dao. */
	private BatchFxRateDAO BatchFxRateDAO;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.BatchFxRateService#getBatchFxRate(com.scb.channels.common.vo.BatchFxRateVO)
	 */
	public List<BatchFxRateVO> getBatchFxRate(BatchFxRateVO batchFxRateVO) {
		return BatchFxRateDAO.getBatchFxRate(batchFxRateVO);
	}

	
	/**
	 * Gets the batch fx rate dao.
	 *
	 * @return the batch fx rate dao
	 */
	public BatchFxRateDAO getBatchFxRateDAO() {
		return BatchFxRateDAO;
	}

	/**
	 * Sets the batch fx rate dao.
	 *
	 * @param batchFxRateDAO the new batch fx rate dao
	 */
	public void setBatchFxRateDAO(BatchFxRateDAO batchFxRateDAO) {
		BatchFxRateDAO = batchFxRateDAO;
	}

}
