package com.scb.channels.common.vo;

import java.io.Serializable;

/**
 * The Class CrossCurrencyVO.
 */
public class CrossCurrencyVO implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4557325339184573448L;
	
	/** The channel id. */
	private String channelId;
	
	/** The ctry code. */
	private String ctryCode;
	
	/** The src currency. */
	private String srcCurrency;
	
	/** The txn curr cd. */
	private String txnCurrCD;
	
	/** The dest currency. */
	private String destCurrency;
	
	/** The is allowed. */
	private String isAllowed;
	
	/** The status cd. */
	private String statusCD;
	
	/** The id. */
	private int id;
	
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	

	/**
	 * Gets the ctry code.
	 *
	 * @return the ctryCode
	 */
	public String getCtryCode() {
		return ctryCode;
	}
	
	/**
	 * Sets the ctry code.
	 *
	 * @param ctryCode the ctryCode to set
	 */
	public void setCtryCode(String ctryCode) {
		this.ctryCode = ctryCode;
	}
	
	/**
	 * Gets the txn curr cd.
	 *
	 * @return the txnCurrCD
	 */
	public String getTxnCurrCD() {
		return txnCurrCD;
	}
	
	/**
	 * Sets the txn curr cd.
	 *
	 * @param txnCurrCD the txnCurrCD to set
	 */
	public void setTxnCurrCD(String txnCurrCD) {
		this.txnCurrCD = txnCurrCD;
	}
	
	/**
	 * Gets the checks if is allowed.
	 *
	 * @return the isAllowed
	 */
	public String getIsAllowed() {
		return isAllowed;
	}
	
	/**
	 * Sets the checks if is allowed.
	 *
	 * @param isAllowed the isAllowed to set
	 */
	public void setIsAllowed(String isAllowed) {
		this.isAllowed = isAllowed;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the statusCD
	 */
	public String getStatusCD() {
		return statusCD;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCD the statusCD to set
	 */
	public void setStatusCD(String statusCD) {
		this.statusCD = statusCD;
	}
	
	/**
	 * Gets the channel id.
	 *
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}
	
	/**
	 * Sets the channel id.
	 *
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	/**
	 * Gets the src currency.
	 *
	 * @return the srcCurrency
	 */
	public String getSrcCurrency() {
		return srcCurrency;
	}
	
	/**
	 * Sets the src currency.
	 *
	 * @param srcCurrency the srcCurrency to set
	 */
	public void setSrcCurrency(String srcCurrency) {
		this.srcCurrency = srcCurrency;
	}
	
	/**
	 * Gets the dest currency.
	 *
	 * @return the destCurrency
	 */
	public String getDestCurrency() {
		return destCurrency;
	}
	
	/**
	 * Sets the dest currency.
	 *
	 * @param destCurrency the destCurrency to set
	 */
	public void setDestCurrency(String destCurrency) {
		this.destCurrency = destCurrency;
	}
	
	

}
