package com.scb.channels.common.dao.impl;



import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BankViewDAO;
import com.scb.channels.common.vo.BankViewVO;

/**
 * The Class BankViewDAOImpl.
 */
public class BankViewDAOImpl extends HibernateDaoSupport implements BankViewDAO {
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BankViewDAO#get(com.scb.channels.common.vo.BankViewVO)
	 */
	public BankViewVO get(BankViewVO bankViewVO) {
		org.hibernate.Criteria criteria = getSession().createCriteria(BankViewVO.class);
		if (bankViewVO.getId() != null) {
			criteria.add(Restrictions.eq(HibernateHelper.ID, bankViewVO.getId()));
		} else {
			criteria.add(Restrictions.eq("bankCd", bankViewVO.getBankCd()));
			criteria.add(Restrictions.eq("ctryCd", bankViewVO.getCtryCd()));
		}
		List<BankViewVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}

	

}
