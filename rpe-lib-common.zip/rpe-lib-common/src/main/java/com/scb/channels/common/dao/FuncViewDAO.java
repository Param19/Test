package com.scb.channels.common.dao;

import com.scb.channels.common.vo.FuncViewVO;

/**
 * The Interface FuncViewDAO.
 */
public interface FuncViewDAO {
 
	/**
	 * Gets the.
	 *
	 * @param funcViewVO the func view vo
	 * @return the func view vo
	 */
	FuncViewVO get(FuncViewVO funcViewVO);
}
