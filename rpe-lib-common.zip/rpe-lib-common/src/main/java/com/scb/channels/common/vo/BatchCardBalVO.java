package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class BatchCardBalVO.
 */
public class BatchCardBalVO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5971273081240322422L;
	
	/** The id. */
	private Integer id;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The cust grp id. */
	private String custGrpId;
	
	/** The currency cd. */
	private String currencyCd;
	
	/** The money master ind. */
	private String moneyMasterInd;
	
	/** The primarycard no. */
	private String primarycardNo;
	
	/** The supp card no. */
	private String suppCardNo;
	
	/** The card type. */
	private String cardType;
	
	/** The holder type. */
	private String holderType;
	
	/** The card holder name. */
	private String cardHolderName;
	
	/** The statement bal. */
	private Double statementBal;
	
	/** The unbilled charges. */
	private Double unbilledCharges;
	
	/** The unbilled payments. */
	private Double unbilledPayments;
	
	/** The outstanding bal. */
	private Double outstandingBal;
	
	/** The avail credit limit. */
	private Double availCreditLimit;
	
	/** The avail cash limit. */
	private Double availCashLimit;
	
	/** The min amt due. */
	private Double minAmtDue;
	
	/** The card expiry date. */
	private String cardExpiryDate;
	
	/** The statement date. */
	private Date statementDate;
	
	/** The payment due date. */
	private Date paymentDueDate;
	
	/** The combined card limit. */
	private Double combinedCardLimit;
	
	/** The supp card limit. */
	private Double suppCardLimit;
	
	/** The card status. */
	private String cardStatus;
	
	/** The sadiq flag. */
	private String sadiqFlag;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The card lvl credit limit. */
	private Double cardLvlCreditLimit;
	
	/** The version. */
	private Integer version;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the cust grp id.
	 *
	 * @return the cust grp id
	 */
	public String getCustGrpId() {
		return custGrpId;
	}
	
	/**
	 * Sets the cust grp id.
	 *
	 * @param custGrpId the new cust grp id
	 */
	public void setCustGrpId(String custGrpId) {
		this.custGrpId = custGrpId;
	}
	
	/**
	 * Gets the currency cd.
	 *
	 * @return the currency cd
	 */
	public String getCurrencyCd() {
		return currencyCd;
	}
	
	/**
	 * Sets the currency cd.
	 *
	 * @param currencyCd the new currency cd
	 */
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	
	/**
	 * Gets the money master ind.
	 *
	 * @return the money master ind
	 */
	public String getMoneyMasterInd() {
		return moneyMasterInd;
	}
	
	/**
	 * Sets the money master ind.
	 *
	 * @param moneyMasterInd the new money master ind
	 */
	public void setMoneyMasterInd(String moneyMasterInd) {
		this.moneyMasterInd = moneyMasterInd;
	}
	
	/**
	 * Gets the primarycard no.
	 *
	 * @return the primarycard no
	 */
	public String getPrimarycardNo() {
		return primarycardNo;
	}
	
	/**
	 * Sets the primarycard no.
	 *
	 * @param primarycardNo the new primarycard no
	 */
	public void setPrimarycardNo(String primarycardNo) {
		this.primarycardNo = primarycardNo;
	}
	
	/**
	 * Gets the supp card no.
	 *
	 * @return the supp card no
	 */
	public String getSuppCardNo() {
		return suppCardNo;
	}
	
	/**
	 * Sets the supp card no.
	 *
	 * @param suppCardNo the new supp card no
	 */
	public void setSuppCardNo(String suppCardNo) {
		this.suppCardNo = suppCardNo;
	}
	
	/**
	 * Gets the card type.
	 *
	 * @return the card type
	 */
	public String getCardType() {
		return cardType;
	}
	
	/**
	 * Sets the card type.
	 *
	 * @param cardType the new card type
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	
	/**
	 * Gets the holder type.
	 *
	 * @return the holder type
	 */
	public String getHolderType() {
		return holderType;
	}
	
	/**
	 * Sets the holder type.
	 *
	 * @param holderType the new holder type
	 */
	public void setHolderType(String holderType) {
		this.holderType = holderType;
	}
	
	/**
	 * Gets the card holder name.
	 *
	 * @return the card holder name
	 */
	public String getCardHolderName() {
		return cardHolderName;
	}
	
	/**
	 * Sets the card holder name.
	 *
	 * @param cardHolderName the new card holder name
	 */
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	
	/**
	 * Gets the statement bal.
	 *
	 * @return the statement bal
	 */
	public Double getStatementBal() {
		return statementBal;
	}
	
	/**
	 * Sets the statement bal.
	 *
	 * @param statementBal the new statement bal
	 */
	public void setStatementBal(Double statementBal) {
		this.statementBal = statementBal;
	}
	
	/**
	 * Gets the unbilled charges.
	 *
	 * @return the unbilled charges
	 */
	public Double getUnbilledCharges() {
		return unbilledCharges;
	}
	
	/**
	 * Sets the unbilled charges.
	 *
	 * @param unbilledCharges the new unbilled charges
	 */
	public void setUnbilledCharges(Double unbilledCharges) {
		this.unbilledCharges = unbilledCharges;
	}
	
	/**
	 * Gets the unbilled payments.
	 *
	 * @return the unbilled payments
	 */
	public Double getUnbilledPayments() {
		return unbilledPayments;
	}
	
	/**
	 * Sets the unbilled payments.
	 *
	 * @param unbilledPayments the new unbilled payments
	 */
	public void setUnbilledPayments(Double unbilledPayments) {
		this.unbilledPayments = unbilledPayments;
	}
	
	/**
	 * Gets the outstanding bal.
	 *
	 * @return the outstanding bal
	 */
	public Double getOutstandingBal() {
		return outstandingBal;
	}
	
	/**
	 * Sets the outstanding bal.
	 *
	 * @param outstandingBal the new outstanding bal
	 */
	public void setOutstandingBal(Double outstandingBal) {
		this.outstandingBal = outstandingBal;
	}
	
	/**
	 * Gets the avail credit limit.
	 *
	 * @return the avail credit limit
	 */
	public Double getAvailCreditLimit() {
		return availCreditLimit;
	}
	
	/**
	 * Sets the avail credit limit.
	 *
	 * @param availCreditLimit the new avail credit limit
	 */
	public void setAvailCreditLimit(Double availCreditLimit) {
		this.availCreditLimit = availCreditLimit;
	}
	
	/**
	 * Gets the avail cash limit.
	 *
	 * @return the avail cash limit
	 */
	public Double getAvailCashLimit() {
		return availCashLimit;
	}
	
	/**
	 * Sets the avail cash limit.
	 *
	 * @param availCashLimit the new avail cash limit
	 */
	public void setAvailCashLimit(Double availCashLimit) {
		this.availCashLimit = availCashLimit;
	}
	
	/**
	 * Gets the min amt due.
	 *
	 * @return the min amt due
	 */
	public Double getMinAmtDue() {
		return minAmtDue;
	}
	
	/**
	 * Sets the min amt due.
	 *
	 * @param minAmtDue the new min amt due
	 */
	public void setMinAmtDue(Double minAmtDue) {
		this.minAmtDue = minAmtDue;
	}
	
	/**
	 * Gets the card expiry date.
	 *
	 * @return the card expiry date
	 */
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}
	
	/**
	 * Sets the card expiry date.
	 *
	 * @param cardExpiryDate the new card expiry date
	 */
	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	
	/**
	 * Gets the statement date.
	 *
	 * @return the statement date
	 */
	public Date getStatementDate() {
		return statementDate;
	}
	
	/**
	 * Sets the statement date.
	 *
	 * @param statementDate the new statement date
	 */
	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}
	
	/**
	 * Gets the payment due date.
	 *
	 * @return the payment due date
	 */
	public Date getPaymentDueDate() {
		return paymentDueDate;
	}
	
	/**
	 * Sets the payment due date.
	 *
	 * @param paymentDueDate the new payment due date
	 */
	public void setPaymentDueDate(Date paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	
	/**
	 * Gets the combined card limit.
	 *
	 * @return the combined card limit
	 */
	public Double getCombinedCardLimit() {
		return combinedCardLimit;
	}
	
	/**
	 * Sets the combined card limit.
	 *
	 * @param combinedCardLimit the new combined card limit
	 */
	public void setCombinedCardLimit(Double combinedCardLimit) {
		this.combinedCardLimit = combinedCardLimit;
	}
	
	/**
	 * Gets the supp card limit.
	 *
	 * @return the supp card limit
	 */
	public Double getSuppCardLimit() {
		return suppCardLimit;
	}
	
	/**
	 * Sets the supp card limit.
	 *
	 * @param suppCardLimit the new supp card limit
	 */
	public void setSuppCardLimit(Double suppCardLimit) {
		this.suppCardLimit = suppCardLimit;
	}
	
	/**
	 * Gets the card status.
	 *
	 * @return the card status
	 */
	public String getCardStatus() {
		return cardStatus;
	}
	
	/**
	 * Sets the card status.
	 *
	 * @param cardStatus the new card status
	 */
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	
	/**
	 * Gets the sadiq flag.
	 *
	 * @return the sadiq flag
	 */
	public String getSadiqFlag() {
		return sadiqFlag;
	}
	
	/**
	 * Sets the sadiq flag.
	 *
	 * @param sadiqFlag the new sadiq flag
	 */
	public void setSadiqFlag(String sadiqFlag) {
		this.sadiqFlag = sadiqFlag;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the card lvl credit limit.
	 *
	 * @return the card lvl credit limit
	 */
	public Double getCardLvlCreditLimit() {
		return cardLvlCreditLimit;
	}
	
	/**
	 * Sets the card lvl credit limit.
	 *
	 * @param cardLvlCreditLimit the new card lvl credit limit
	 */
	public void setCardLvlCreditLimit(Double cardLvlCreditLimit) {
		this.cardLvlCreditLimit = cardLvlCreditLimit;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	
	
}
