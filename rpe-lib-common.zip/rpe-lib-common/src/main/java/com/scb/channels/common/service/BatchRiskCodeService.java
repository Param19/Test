package com.scb.channels.common.service;

import java.util.List;
import com.scb.channels.common.vo.BatchRiskCodeVO;

/**
 * The Interface BatchRiskCodeService.
 */
public interface BatchRiskCodeService {
	
	/**
	 * Gets the batch risk code.
	 *
	 * @param batchRiskCodeVO the batch risk code vo
	 * @return the batch risk code
	 */
	List<BatchRiskCodeVO> getBatchRiskCode(BatchRiskCodeVO batchRiskCodeVO);

}
