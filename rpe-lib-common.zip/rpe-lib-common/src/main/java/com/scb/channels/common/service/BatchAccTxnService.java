package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.common.vo.BatchAccTxnVO;

/**
 * The Interface BatchAccTxnService.
 */
public interface BatchAccTxnService {
	
	/**
	 * Gets the batch account txn.
	 *
	 * @param accNo the batch acc txn vo
	 * @return the batch account txn
	 */
	List<BatchAccTxnVO> getBatchAccountTxn(String accNo);

}
