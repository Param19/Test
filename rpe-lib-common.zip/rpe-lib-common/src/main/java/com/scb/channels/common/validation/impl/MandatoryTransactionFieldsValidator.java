/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.validator.ValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.validation.MultiFieldValidator;

/**
 * The Class MandatoryTransactionFieldsValidator.
 *
 * @author 1411807
 */
public class MandatoryTransactionFieldsValidator implements MultiFieldValidator {
	
	/** The property. */
	private List<String> property;
	
	/** The bean. */
	private PayloadDTO bean;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MandatoryTransactionFieldsValidator.class);

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		for (String field: property) {
			try {
				Object value = PropertyUtils.getProperty(bean, field);
				Validate.notNull(value);
				if(value.equals("")){
					throw new ValidatorException("The "+ field +" is null" );
				}
			} catch (Exception e) {
				LOGGER.error(field, e.getMessage());
				throw new ValidatorException(e.getMessage());
			} 
		}

	}

	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;
	}

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		this.property = property;
	}

}
