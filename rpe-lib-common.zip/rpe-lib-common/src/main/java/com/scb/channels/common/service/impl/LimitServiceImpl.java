/**
 * 
 */
package com.scb.channels.common.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.FXRateInfoVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.dao.LimitDAO;
import com.scb.channels.common.service.LimitService;
import com.scb.channels.common.vo.LimitCriteriaVO;
import com.scb.channels.common.vo.TransactionLimitVO;

/**
 * The Class LimitServiceImpl.
 *
 * @author 1411807
 */
public class LimitServiceImpl implements LimitService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LimitServiceImpl.class);
	
	/** The limit dao. */
	private LimitDAO limitDao;
	


	/**
	 * Checks if is limit available.
	 * 
	 * @param info
	 *            the info
	 * @return true, if is limit available
	 * @see com.scb.channels.common.service.LimitService#isLimitAvailable(com.scb.channels.common.vo.TransactionInfoVO)
	 */
	public boolean isLimitAvailable(TransactionInfoVO info) {
		UserVO userVO = info.getUserVO();
		LOGGER.info("Limit Check started {}", new Object[]{userVO.getCustomerId()} );
		ClientVO clientVO = info.getClientVO();
		
		findLimitSegment(userVO);
		LOGGER.info("Limit Check Segment completed {}", new Object[]{userVO.getCustomerId()});
		
		String srcCurrency = info.getSrcAccountVO().getCurrency();
		String destCUR = (info.getDestAccountVO()==null || info.getDestAccountVO().getCurrency()==null)?srcCurrency:info.getDestAccountVO().getCurrency();
		
		List<TransactionLimitVO> limitTxnList = limitDao.getTransactionLimits(userVO.getCustomerId(), 
				userVO.getCountry(), clientVO.getChannel(), info.getTxnTypeCd(), 
				srcCurrency, destCUR);
		
		LOGGER.info("Limit Txn List fetch completed {} {}", new Object[]{userVO.getCustomerId(), limitTxnList.size()});
		String key = null;
		//If Customer txn limit present below block will execute
		if (!limitTxnList.isEmpty()) {
			for (TransactionLimitVO txnLimitVO : limitTxnList) {
				key = txnLimitVO.getSrcCurrency() + CommonConstants.HYPHEN + txnLimitVO.getDestCurrency();
				
				Map<String, Map<String, Double>> limitMap = limitDao.getCustomerLimits(userVO.getCustomerId(),
						clientVO.getChannel(), userVO.getLimitSegmentCode(), info.getTxnTypeCd());
				
				// if customer defined limit is empty then country level limit will be applicable
				if (limitMap.isEmpty()) {
					limitMap = limitDao.getCountryLimits(clientVO.getChannel(), userVO.getLimitSegmentCode(), info.getTxnTypeCd());
				}
				//Limit check for per transaction type
				if (!checkLimit(limitMap, ((info.getTxnAmount()* getExchangeRate(info))), key, CommonConstants.PER_TXN_LIMIT_ORDER_LIST)){
					LOGGER.info("Limit check failed for customer {} {} ", new Object[]{userVO.getCustomerId(), key});
					if (limitMap.get(CommonConstants.PTL) != null && limitMap.get(CommonConstants.PTL).get(key) != null) {
						info.setHostRespDesc(ExceptionMessages._131.getMessage() + limitMap.get(CommonConstants.PTL).get(key));
					} else {
						info.setHostRespDesc(ExceptionMessages._133.getMessage());
					}
					return false;
				}
				//Limit check for transaction type
				if (!checkLimit(limitMap, (txnLimitVO.getAmount()+(info.getTxnAmount()* getExchangeRate(info))), key, CommonConstants.LIMIT_ORDER_LIST)){
					LOGGER.info("Limit check failed for customer {} {} ", new Object[]{userVO.getCustomerId(), key});
					info.setHostRespDesc(ExceptionMessages._132.getMessage());
					return false;
				}
				//Maximum Daily limit check
				Map<String, Map<String, Double>> maxLimitMap = limitDao.getMaximumLimits(
						clientVO.getChannel(), userVO.getLimitSegmentCode());
				if (!checkLimit(maxLimitMap, (txnLimitVO.getAmount()+(info.getTxnAmount()* getExchangeRate(info))), key, CommonConstants.MAX_LIMIT_ORDER_LIST)){
					LOGGER.info("Limit Master failed for customer {} {} ", new Object[]{userVO.getCustomerId(), key});
					info.setHostRespDesc(ExceptionMessages._132.getMessage());
					return false;
				}
			}
			return true;
		} else { //If Customer txn limit not present below block will execute
			
			key = srcCurrency + CommonConstants.HYPHEN + destCUR;
			
			Map<String, Map<String, Double>> limitMap = limitDao.getCustomerLimits(userVO.getCustomerId(),
					clientVO.getChannel(), userVO.getLimitSegmentCode(), info.getTxnTypeCd());
			
			
			// if customer defined limit is empty then country level limit will be applicable
			if (limitMap.isEmpty()) {
				limitMap = limitDao.getCountryLimits(clientVO.getChannel(), userVO.getLimitSegmentCode(), info.getTxnTypeCd());
			}
			//Limit check for per transaction type
			if (!checkLimit(limitMap, ((info.getTxnAmount()* getExchangeRate(info))), key, CommonConstants.PER_TXN_LIMIT_ORDER_LIST)){
				LOGGER.info("Limit check failed for customer {} {} ", new Object[]{userVO.getCustomerId(), key});
				if (limitMap.get(CommonConstants.PTL) != null && limitMap.get(CommonConstants.PTL).get(key) != null) {
					info.setHostRespDesc(ExceptionMessages._131.getMessage() + limitMap.get(CommonConstants.PTL).get(key));
				} else {
					info.setHostRespDesc(ExceptionMessages._133.getMessage());
				}
				return false;
			}
			//Limit check for transaction type
			if (!checkLimit(limitMap, (info.getTxnAmount()* getExchangeRate(info)), key, CommonConstants.LIMIT_ORDER_LIST)){
				LOGGER.info("Limit check failed for customer {} {} ", new Object[]{userVO.getCustomerId(), key});
				info.setHostRespDesc(ExceptionMessages._132.getMessage());
				return false;
			}
			//Maximum Daily limit check
			Map<String, Map<String, Double>> maxLimitMap = limitDao.getMaximumLimits(
					clientVO.getChannel(), userVO.getLimitSegmentCode());
			if (!checkLimit(maxLimitMap, (info.getTxnAmount()* getExchangeRate(info)), key, CommonConstants.MAX_LIMIT_ORDER_LIST)){
				LOGGER.info("Limit Master failed for customer {} {} ", new Object[]{userVO.getCustomerId(), key});
				info.setHostRespDesc(ExceptionMessages._132.getMessage());
				return false;
			}
			return true;
		}
	}

	/**
	 * Find limit segment.
	 * 
	 * @param userVO
	 *            the user vo
	 */
	private void findLimitSegment(UserVO userVO) {
		LimitCriteriaVO criteriaVO = limitDao.getCriteria(userVO.getCountry(), userVO.getSegmentCode(), 
				StringUtils.defaultString(userVO.getResident(), CommonConstants.N) , 
				StringUtils.defaultString(userVO.getStaff(), CommonConstants.N) , 
				StringUtils.defaultString(userVO.getSalary(), CommonConstants.N));
		userVO.setLimitSegmentCode(criteriaVO.getLimitSegmentCode());
	}
	
	/**
	 * Gets the exchange rate.
	 *
	 * @param info the info
	 * @return the exchange rate
	 */
	private double getExchangeRate(TransactionInfoVO info){
		if (info == null || info.getfXRateInfoVO() == null ) {
			return 1;
		} else {
			FXRateInfoVO fXRateInfoVO = info.getfXRateInfoVO();
			if (fXRateInfoVO.getCustDealRate() != null ){
				return fXRateInfoVO.getCustDealRate();
			} else if (fXRateInfoVO.getCostRate() > 0){
				return fXRateInfoVO.getCostRate();
			} else if (fXRateInfoVO.getExchgRate() > 0){
				return fXRateInfoVO.getExchgRate();
			} else {
				return 1;
			}
		}
	}

	/**
	 * Check limit.
	 *
	 * @param limitMap the limit map
	 * @param amount the amount
	 * @param key the key
	 * @return true, if successful
	 */
	private boolean checkLimit(Map<String, Map<String, Double>> limitMap, double amount, String key, String[] limitArray) {
		double limitAmout = 0;
		for (String limitType : limitArray) {
			Map<String, Double> amountMap = limitMap.get(limitType);
			if(amountMap!=null){
				if (amountMap.containsKey(key)) {
					limitAmout = limitMap.get(limitType).get(key).doubleValue();
				} else if (amountMap.containsKey(CommonConstants.ALL_KEY)){
					limitAmout = limitMap.get(limitType).get(CommonConstants.ALL_KEY).doubleValue();
				}
				if (amount > limitAmout) {
					 return false;
				}
			}
		}
		return true;
	}
	
	

	/**
	 * Sets the limit dao.
	 *
	 * @param limitDao the limitDao to set
	 */
	public void setLimitDao(LimitDAO limitDao) {
		this.limitDao = limitDao;
	}

}
