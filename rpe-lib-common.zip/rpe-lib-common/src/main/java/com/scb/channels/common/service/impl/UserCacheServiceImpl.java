/**
 * 
 */
package com.scb.channels.common.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.collections.CollectionUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.AccountDetailsVO;
import com.scb.channels.base.vo.AccountListDetailsVO;
import com.scb.channels.base.vo.AccountListResponseVO;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.BeneficiaryResponseVO;
import com.scb.channels.base.vo.BeneficiaryVO;
import com.scb.channels.base.vo.BillerDetailsVO;
import com.scb.channels.base.vo.BillerListResponseVO;
import com.scb.channels.base.vo.CASAVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.service.UserCacheService;
import com.scb.channels.customer.service.CustomerAccountListService;

/**
 * The Class UserCacheServiceImpl.
 *
 * @author 1411807
 */
public class UserCacheServiceImpl implements UserCacheService {
	
	/** The cache manager. */
	private CacheManager cacheManager;
	
	/** The customer account list service. */
	private CustomerAccountListService customerAccountListService;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#addAccountList(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public void addAccountList(PayloadDTO payload) {
		if(payload != null && payload.getRequestVO() !=null 
				&& payload.getResponseVO() !=null 
				&& payload.getResponseVO() instanceof AccountListResponseVO
				&& payload.getRequestVO().getUser()!=null){
			AccountListResponseVO accListResponseVO = (AccountListResponseVO) payload.getResponseVO();
			AccountListDetailsVO accountListDetails = accListResponseVO.getAccountListDetails();
			if (accountListDetails!=null && CollectionUtils.isNotEmpty(accountListDetails.getAccountDetails())) {
				cacheManager.getCache(CommonConstants.MY_CACHE)
					.put(new Element(payload.getRequestVO().getUser().getUserId()+ CommonConstants.ACCOUNT_LIST, 
							accountListDetails.getAccountDetails()));
			}
		}

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#addBeneficiary(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public void addBeneficiary(PayloadDTO payload) {
		if(payload != null && payload.getRequestVO() !=null 
				&& payload.getResponseVO() !=null 
				&& payload.getResponseVO() instanceof BeneficiaryResponseVO
				&& payload.getRequestVO().getUser()!=null){
			BeneficiaryResponseVO beneficiaryResponseVO = (BeneficiaryResponseVO) payload.getResponseVO();
			List<BeneficiaryVO> list = beneficiaryResponseVO.getBeneficiaryList();
			if (list!=null && CollectionUtils.isNotEmpty(list)) {
				cacheManager.getCache(CommonConstants.MY_CACHE)
					.put(new Element(payload.getRequestVO().getUser().getUserId()+ CommonConstants.BENE_LIST, 
							list));
			}
		}

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#addBiller(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public void addBiller(PayloadDTO payload) {
		if(payload != null && payload.getRequestVO() !=null 
				&& payload.getResponseVO() !=null 
				&& payload.getResponseVO() instanceof BillerListResponseVO
				&& payload.getRequestVO().getUser()!=null){
			BillerListResponseVO billerListResponseVO = (BillerListResponseVO) payload.getResponseVO();
			List<BillerDetailsVO> list = billerListResponseVO.getBillerList();
			if (list!=null && CollectionUtils.isNotEmpty(list)) {
				cacheManager.getCache(CommonConstants.MY_CACHE)
					.put(new Element(payload.getRequestVO().getUser().getUserId()+ CommonConstants.BILLER_LIST, 
							list));
			}
		}

	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#getAccount(com.scb.channels.base.vo.PayloadDTO, java.lang.String)
	 */
	@Override
	public CASAVO getAccount(PayloadDTO payload, String accountNumber) {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		BaseVO requestVO = payload.getRequestVO();
		String userId = requestVO.getUser().getUserId();
		if (cache!=null
				&& cache.get(userId+ CommonConstants.BENE_ACCOUNT)!=null){
			List<CASAVO> list = (List<CASAVO>) cache.get(userId+ CommonConstants.BENE_ACCOUNT).getValue();
			for (CASAVO cASAVO : list) {
				if(cASAVO.getAccountNumber().equals(accountNumber)) {
					return cASAVO;
				}
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#getAccountList(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public List<AccountDetailsVO> getAccountList(PayloadDTO payload) {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		BaseVO requestVO = payload.getRequestVO();
		String userId = requestVO.getUser().getUserId();
		if (cache!=null
				&& cache.get(userId+ CommonConstants.ACCOUNT_LIST)!=null){
			return (List<AccountDetailsVO>) cache.get(userId+ CommonConstants.ACCOUNT_LIST).getValue();
		} else {
			AccountListResponseVO responseVO = customerAccountListService
					.getCustomerAccountList(requestVO.getUser(), requestVO.getClientVO(), 
							requestVO.getMessageVO(), requestVO.getServiceVO().getServiceTxnType());
			if (responseVO != null && responseVO.getAccountListDetails()!=null) {
				List<AccountDetailsVO> list =(List<AccountDetailsVO>) responseVO.getAccountListDetails().getAccountDetails();
				/*if (CollectionUtils.isNotEmpty(list)) {
					cache.put(new Element(requestVO.getUser().getUserId()+ CommonConstants.ACCOUNT_LIST, 
							list));
				}*/
				return list;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#addBeneficiaryAccount(com.scb.channels.base.vo.PayloadDTO, com.scb.channels.base.vo.AccountDetailsVO)
	 */
	public void addBeneficiaryAccount(PayloadDTO payload,
			CASAVO cASAVO) {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		BaseVO requestVO = payload.getRequestVO();
		String userId = requestVO.getUser().getUserId();
		if (cache!=null
				&& cache.get(userId+ CommonConstants.BENE_ACCOUNT)!=null){
			List<CASAVO> list = (List<CASAVO>)cache.get(userId+ CommonConstants.BENE_ACCOUNT).getValue();
			list.add(cASAVO);
			cache.put(new Element(payload.getRequestVO().getUser().getUserId()+ CommonConstants.BENE_ACCOUNT, 
					list));
		} else {
			List<CASAVO> list = new ArrayList<CASAVO>();	
			list.add(cASAVO);
			cache.put(new Element(payload.getRequestVO().getUser().getUserId()+ CommonConstants.BENE_ACCOUNT, 
					list));
		}
		
	}

	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#getBeneficiaryList(com.scb.channels.base.vo.PayloadDTO)
	 */
	public List<BeneficiaryVO> getBeneficiaryList(PayloadDTO payload) {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		BaseVO requestVO = payload.getRequestVO();
		String userId = requestVO.getUser().getUserId();
		if (cache!=null
				&& cache.get(userId+ CommonConstants.BENE_LIST)!=null){
			return (List<BeneficiaryVO>) cache.get(userId+ CommonConstants.BENE_LIST).getValue();
		} 
		return null;
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#getBillerList(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public List<BillerDetailsVO> getBillerList(PayloadDTO payload) {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		BaseVO requestVO = payload.getRequestVO();
		String userId = requestVO.getUser().getUserId();
		if (cache!=null
				&& cache.get(userId+ CommonConstants.BILLER)!=null){
			return (List<BillerDetailsVO>) cache.get(userId+ CommonConstants.BILLER).getValue();
		} 
		return null;
	}

	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#addCustInfo(com.scb.channels.base.vo.PayloadDTO)
	 */
	public void addCustInfo(PayloadDTO payload) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.service.UserCacheService#clearCustInfo(com.scb.channels.base.vo.PayloadDTO)
	 */
	public void clearCustInfo(PayloadDTO payload) {
		Cache cache = cacheManager.getCache(CommonConstants.MY_CACHE);
		BaseVO requestVO = payload.getRequestVO();
		String userId = requestVO.getUser().getUserId();
		if (cache!=null){
			cache.remove(userId+ CommonConstants.BILLER);
			cache.remove(userId+ CommonConstants.BENE_LIST);
			cache.remove(userId+ CommonConstants.BENE_ACCOUNT);
			cache.remove(userId+ CommonConstants.ACCOUNT_LIST);
		} 
		
	}
	
	/**
	 * Sets the cache manager.
	 *
	 * @param cacheManager the cacheManager to set
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}


	/**
	 * Sets the customer account list service.
	 *
	 * @param customerAccountListService the customerAccountListService to set
	 */
	public void setCustomerAccountListService(
			CustomerAccountListService customerAccountListService) {
		this.customerAccountListService = customerAccountListService;
	}

	

	



}
