package com.scb.channels.customer.service;

import com.scb.channels.base.vo.AccountListResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.UserVO;

public interface CustomerAccountListService {
	
	/**
	 *  Interface AccountListResponseVO
	 *  @param relNumber
	 */
	AccountListResponseVO getCustomerAccountList(UserVO userVO, 
			ClientVO clientVO, MessageVO messageVO, String operationType);

}
