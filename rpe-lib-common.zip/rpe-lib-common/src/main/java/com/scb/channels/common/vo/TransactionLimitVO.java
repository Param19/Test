/**
 * 
 */
package com.scb.channels.common.vo;

import java.io.Serializable;

/**
 * The Class TransactionLimitVO.
 *
 * @author 1411807
 */
public class TransactionLimitVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8152966248971064720L;
	
	/** The cust id. */
	private String custId;
	
	/** The channel id. */
	private String channelId;
	
	/** The txn type cd. */
	private String txnTypeCd;
	
	/** The country. */
	private String country;
	
	/** The src currency. */
	private String srcCurrency;
	
	/** The dest currency. */
	private String destCurrency;
	
	/** The amount. */
	private double amount;

	/**
	 * Gets the cust id.
	 *
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}

	/**
	 * Sets the cust id.
	 *
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}

	/**
	 * Gets the channel id.
	 *
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * Sets the channel id.
	 *
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * Gets the txn type cd.
	 *
	 * @return the txnTypeCd
	 */
	public String getTxnTypeCd() {
		return txnTypeCd;
	}

	/**
	 * Sets the txn type cd.
	 *
	 * @param txnTypeCd the txnTypeCd to set
	 */
	public void setTxnTypeCd(String txnTypeCd) {
		this.txnTypeCd = txnTypeCd;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * Gets the src currency.
	 *
	 * @return the srcCurrency
	 */
	public String getSrcCurrency() {
		return srcCurrency;
	}

	/**
	 * Sets the src currency.
	 *
	 * @param srcCurrency the srcCurrency to set
	 */
	public void setSrcCurrency(String srcCurrency) {
		this.srcCurrency = srcCurrency;
	}

	/**
	 * Gets the dest currency.
	 *
	 * @return the destCurrency
	 */
	public String getDestCurrency() {
		return destCurrency;
	}

	/**
	 * Sets the dest currency.
	 *
	 * @param destCurrency the destCurrency to set
	 */
	public void setDestCurrency(String destCurrency) {
		this.destCurrency = destCurrency;
	}

}
