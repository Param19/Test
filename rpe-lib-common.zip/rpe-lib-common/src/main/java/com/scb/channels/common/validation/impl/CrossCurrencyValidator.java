package com.scb.channels.common.validation.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.service.CrossCurrencyService;
import com.scb.channels.common.validation.MultiFieldValidator;

/**
 * The Class CrossCurrencyValidator.
 */
public class CrossCurrencyValidator implements MultiFieldValidator {
	
	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private List<String> property;
	
	/** The cross currency service. */
	private CrossCurrencyService crossCurrencyService;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CrossCurrencyValidator.class);

	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty( List<String> property) {
		this.property=property;
	}

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		LOGGER.info("Entered CrossCurrencyValidator class..");
		try {
			String channelID=(String) PropertyUtils.getProperty(bean, property.get(0));
			String countryCode=(String) PropertyUtils.getProperty(bean, property.get(1));
			String srcCurrency=(String) PropertyUtils.getProperty(bean, property.get(2));
			String destinationCurrency=(String) PropertyUtils.getProperty(bean, property.get(CommonConstants.THREE));
			LOGGER.info("Request details : {}, {}, {}, {}", new Object[]{channelID,countryCode, srcCurrency, destinationCurrency});
			
			boolean isValidCurrency;
			isValidCurrency=crossCurrencyService.crossCurrencyCheck(channelID, countryCode, srcCurrency, 
						                                                destinationCurrency);
			LOGGER.info("isValidCurrency :: "+isValidCurrency);
			
			if (!isValidCurrency) {
				throw new ValidatorException(
						"from and to currency is different....");
			}
		} catch (IllegalAccessException e) {
			LOGGER.error(e.getMessage());
		} catch (InvocationTargetException e) {
			LOGGER.error(e.getMessage());
		} catch (NoSuchMethodException e) {
			LOGGER.error(e.getMessage());
		}
		
	}
	
	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean= bean;
		
	}

	/**
	 * Gets the bean.
	 *
	 * @return the bean
	 */
	public PayloadDTO getBean() {
		return bean;
	}

	/**
	 * Gets the property.
	 *
	 * @return the property
	 */
	public  List<String> getProperty() {
		return property;
	}

	/**
	 * Gets the cross currency service.
	 *
	 * @return the crossCurrencyService
	 */
	public CrossCurrencyService getCrossCurrencyService() {
		return crossCurrencyService;
	}

	/**
	 * Sets the cross currency service.
	 *
	 * @param crossCurrencyService the crossCurrencyService to set
	 */
	public void setCrossCurrencyService(CrossCurrencyService crossCurrencyService) {
		this.crossCurrencyService = crossCurrencyService;
	}


}
