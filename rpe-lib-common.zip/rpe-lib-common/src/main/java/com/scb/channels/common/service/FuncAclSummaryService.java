/*
 * 
 */
package com.scb.channels.common.service;

import java.util.List;

/**
 * The Interface FuncAclSummaryService.
 */
public interface FuncAclSummaryService {
	
	/**
	 * Check product filter.
	 *
	 * @param funcCode the func code
	 * @param prdCode the prd code
	 * @param opsIns the ops ins
	 * @param currCode the curr code
	 * @param accountStatus the account status
	 * @return true, if successful
	 */
	public boolean checkProductFilter(String funcCode, String prdCode, String opsIns, 
			String currCode ,String accountStatus, List<String> blockCode) ;

}
