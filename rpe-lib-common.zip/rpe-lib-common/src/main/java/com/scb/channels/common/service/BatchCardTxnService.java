package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.common.vo.BatchCardTxnVO;

/**
 * The Interface BatchCardTxnService.
 */
public interface BatchCardTxnService {
	
	/**
	 * Gets the batch card txn.
	 *
	 * @param batchCardTxnVO the batch card txn vo
	 * @return the batch card txn
	 */
	List<BatchCardTxnVO> getBatchCardTxn(BatchCardTxnVO batchCardTxnVO);

}
