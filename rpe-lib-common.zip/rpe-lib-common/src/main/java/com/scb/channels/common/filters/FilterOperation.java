package com.scb.channels.common.filters;

/**
 * The Enum FilterOperation.
 */
public enum FilterOperation {

	EQUALS, NOT_EQUALS, CONTAINS, NOT_CONTAINS, LIST_CONTAINS, LIST_NOTCONTAINS
}
