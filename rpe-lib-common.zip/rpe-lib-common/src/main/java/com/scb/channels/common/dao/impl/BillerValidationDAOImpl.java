package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.common.dao.BillerValidationDAO;
import com.scb.channels.common.vo.BillerValidationVO;

public class BillerValidationDAOImpl extends HibernateDaoSupport implements
		BillerValidationDAO {

	
	public BillerValidationVO get(String billerField, String ctryCd,
			String billerCd) {
		
		org.hibernate.Criteria criteria =  getSession().createCriteria(BillerValidationVO.class);		
			criteria.add(Restrictions.eq("billerField", billerField));		
		    criteria.add(Restrictions.eq("ctryCd",ctryCd));
		    criteria.add(Restrictions.eq("billerCdFK",billerCd));
		return (BillerValidationVO) criteria.uniqueResult();
	}


	public List<BillerValidationVO> getByctryCdAndBillerCd(String ctryCd,
			String billerCd) {
		org.hibernate.Criteria criteria =  getSession().createCriteria(BillerValidationVO.class);						
	    criteria.add(Restrictions.eq("ctryCd",ctryCd));
	    criteria.add(Restrictions.eq("billerCdFK",billerCd));
	return  criteria.list();
	}

}
