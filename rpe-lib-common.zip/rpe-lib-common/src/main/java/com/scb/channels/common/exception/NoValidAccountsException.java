/**
 * 
 */
package com.scb.channels.common.exception;

import com.scb.channels.base.helper.CommonConstants;

/**
 * The Class NoValidAccountsException.
 *
 * @author 1411807
 */
public class NoValidAccountsException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6954418507672635146L;

	/**
	 * Instantiates a new no valid accounts exception.
	 *
	 * @param srcAccountNumber the src account number
	 */
	public NoValidAccountsException(String srcAccountNumber) {
		super(srcAccountNumber);
	}
	
	/**
	 * Instantiates a new no valid accounts exception.
	 *
	 * @param srcAccountNumber the src account number
	 * @param destAccountNumber the dest account number
	 */
	public NoValidAccountsException(String srcAccountNumber, String destAccountNumber) {
		super(srcAccountNumber + CommonConstants.COLON + destAccountNumber);
	}
}
