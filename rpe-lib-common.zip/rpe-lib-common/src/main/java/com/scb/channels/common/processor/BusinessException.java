/**
 * 
 */
package com.scb.channels.common.processor;

import com.scb.channels.base.vo.PayloadDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class BusinessException.
 *
 * @author 1411807
 */
public class BusinessException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8513892218511186276L;
	
	/** The bean. */
	private PayloadDTO bean;

	/**
	 * Instantiates a new business exception.
	 */
	public BusinessException() {
	}

	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 */
	public BusinessException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new business exception.
	 *
	 * @param cause the cause
	 */
	public BusinessException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * Instantiates a new business exception.
	 *
	 * @param cause the cause
	 * @param bean the bean
	 */
	public BusinessException(Throwable cause, PayloadDTO bean) {
		super(cause);
		this.bean = bean;
	}

	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 */
	public BusinessException(String message, Throwable cause) {
		super(message, cause);
	}
	
	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 * @param bean the bean
	 */
	public BusinessException(String message, Throwable cause, PayloadDTO bean) {
		super(message, cause);
		this.bean = bean;
	}


	/**
	 * Gets the bean.
	 *
	 * @return the bean
	 */
	public PayloadDTO getBean() {
		return bean;
	}

}
