package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.base.exception.MaskException;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.common.vo.FieldValidationVO;


public interface FieldValidationService {

	public List<FieldValidationVO> getfieldValidationList (String typeCode, String categoryCode, String baseObject, ClientVO clientVO) throws MaskException;
	
}
