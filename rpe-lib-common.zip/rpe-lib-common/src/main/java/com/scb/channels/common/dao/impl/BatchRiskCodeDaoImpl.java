package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchRiskCodeDAO;
import com.scb.channels.common.vo.BatchRiskCodeVO;


/**
 * The Class BatchRiskCodeDaoImpl.
 */
public class BatchRiskCodeDaoImpl extends HibernateDaoSupport implements BatchRiskCodeDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchRiskCodeDAO#getBatchRiskCode(com.scb.channels.common.vo.BatchRiskCodeVO)
	 */
	public List<BatchRiskCodeVO> getBatchRiskCode(BatchRiskCodeVO batchRiskCodeVO) {
		Criteria criteria = getSession().createCriteria(BatchRiskCodeVO.class);
		if(batchRiskCodeVO!=null && batchRiskCodeVO.getId()!=null){
		criteria.add(Restrictions.eq(HibernateHelper.ID, batchRiskCodeVO.getId()));
		List<BatchRiskCodeVO> list = criteria.list();
		return list;
		}else{
		return null;
		}
	}
	
}
