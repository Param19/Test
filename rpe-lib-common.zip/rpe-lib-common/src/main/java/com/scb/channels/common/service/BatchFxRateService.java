package com.scb.channels.common.service;

import java.util.List;

import com.scb.channels.common.vo.BatchFxRateVO;

/**
 * The Interface BatchFxRateService.
 */
public interface BatchFxRateService {
	
	/**
	 * Gets the batch fx rate.
	 *
	 * @param batchFxRateVO the batch fx rate vo
	 * @return the batch fx rate
	 */
	List<BatchFxRateVO> getBatchFxRate(BatchFxRateVO batchFxRateVO);

}
