package com.scb.channels.common.processor.impl;

import java.net.ConnectException;
import java.net.SocketTimeoutException;

import javax.xml.ws.WebServiceException;

import org.apache.camel.CamelException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.HostResponseTypeVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.StatusTypeVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.ConstrtaintException;

public class CreditExceptionHandler implements Processor {

	public static final String JMS_CORRELATION_ID = "JMSCorrelationID";
	public static final String ERROR_CAUGHT = "ERROR_CAUGHT";
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditExceptionHandler.class);

	public void process(Exchange exchange) throws CamelException {
		LOGGER.info("CreditExceptionHandler handling from {}", exchange.getFromRouteId());
		LOGGER.info("Sendmail failed, resetting exchange with original error");
		LOGGER.error("Error ", exchange.getProperty(Exchange.EXCEPTION_CAUGHT));
		Exception ex = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
		InwardPaymentResponseVO inwardPaymentResponseType = new InwardPaymentResponseVO();
		if (ex != null) {
			LOGGER.info("CreditExceptionHandler class :::::"+ex.getClass());
			exchange.setProperty(Exchange.EXCEPTION_CAUGHT, ex);
			PayloadDTO beanNew = exchange.getIn().getBody(PayloadDTO.class);
			if(beanNew == null){
				beanNew = new PayloadDTO();
			}
			if (ex instanceof BusinessException) {
				LOGGER.info("Exception ConstrtaintException class :::::"+ex.getClass());
				StatusTypeVO statusType = new StatusTypeVO();
				statusType.setStatusCode(ExceptionMessages._503.getCode());
				statusType.setStatusDesc(ExceptionMessages._503.getMessage());
				/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setHostName("RPE");
				statusType.setHostResponseTypeVO(hostResponseTypeVO);*/
				inwardPaymentResponseType.setStatusTypeVO(statusType);
				
			} else if(ex instanceof ConstrtaintException) {
				LOGGER.info("CreditExceptionHandler ConstrtaintException class :::::"+ex.getClass());
				StatusTypeVO statusType = new StatusTypeVO();
				statusType.setStatusCode(ExceptionMessages._409.getCode());
				statusType.setStatusDesc(ExceptionMessages._409.getMessage());
				/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setHostName("RPE");
				statusType.setHostResponseTypeVO(hostResponseTypeVO);*/
				inwardPaymentResponseType.setStatusTypeVO(statusType);
			
			} else if(ex instanceof SocketTimeoutException || ex instanceof ConnectException || ex instanceof WebServiceException){
				
				LOGGER.info("CreditExceptionHandler SocketTimeoutException :::::"+ex.getClass());
				StatusTypeVO statusType = new StatusTypeVO();
				statusType.setStatusCode(ExceptionMessages._503.getCode());
				statusType.setStatusDesc(ExceptionMessages._503.getMessage());
				/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setHostName("EBBS");
				statusType.setHostResponseTypeVO(hostResponseTypeVO);*/
				inwardPaymentResponseType.setStatusTypeVO(statusType);
				InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)beanNew.getRequestVO();
				inwardPaymentRequestVO.setPaymentStatus("SRVTIMEOUT");
				beanNew.setRequestVO(inwardPaymentRequestVO);
				
			} else {
				LOGGER.info("CreditExceptionHandler else condition :::::"+ex.getClass());
				
				StatusTypeVO statusType = new StatusTypeVO();
				statusType.setStatusCode(ExceptionMessages._503.getCode());
				statusType.setStatusDesc(ExceptionMessages._503.getMessage());
				/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setHostName("RPE");
				statusType.setHostResponseTypeVO(hostResponseTypeVO);*/
				inwardPaymentResponseType.setStatusTypeVO(statusType);
			}
			if (beanNew != null && beanNew.getRequestVO() != null && beanNew.getRequestVO().getMessageVO()!=null) {
				exchange.getOut().setHeader(JMS_CORRELATION_ID, beanNew.getRequestVO().getMessageVO().getReqID());
			}
			beanNew.setResponseVO(inwardPaymentResponseType);
			exchange.getOut().setBody(beanNew);
		}
	}

	
}
