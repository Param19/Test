package com.scb.channels.common.dao.impl;



import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.common.dao.FuncViewDAO;
import com.scb.channels.common.vo.FuncViewVO;

/**
 * The Class FuncViewDAOImpl.
 */
public class FuncViewDAOImpl extends HibernateDaoSupport implements FuncViewDAO {
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.FuncViewDAO#get(com.scb.channels.common.vo.FuncViewVO)
	 */
	public FuncViewVO get(FuncViewVO funcViewVO) {
		org.hibernate.Criteria criteria = getSession().createCriteria(FuncViewVO.class);
		if (funcViewVO.getuFunc() != null) {
			criteria.add(Restrictions.eq("uFunc", funcViewVO.getuFunc()));
		} else {
			criteria.add(Restrictions.eq("funcCd", funcViewVO.getFuncCd()));
			criteria.add(Restrictions.eq("statusCd", funcViewVO.getStatusCd()));
		}
		List<FuncViewVO> list = criteria.list();
		return list.size() == 0 ? null : list.get(0);
	}

	

}
