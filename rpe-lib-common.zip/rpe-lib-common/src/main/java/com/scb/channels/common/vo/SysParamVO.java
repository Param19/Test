package com.scb.channels.common.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class SysParamVO.
 */
public class SysParamVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7802050791436866349L;
	
	 
	/** The id. */
	private Integer id; 
	
	/** The version. */
	private Integer version;
	
	/** The ctry cd. */
	private String ctryCd;   
	
	/** The category. */
	private String category;   
	
	/** The value. */
	private String value;     
	
	/** The descr. */
	private String descr;
	
	/** The sys cd. */
	private String sysCd;
	
	/** The created by. */
	private String createdBy;	    
	
	/** The upd by. */
	private String updBy;	
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	
	/**
	 * Sets the category.
	 *
	 * @param category the new category
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	
	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	
	/**
	 * Sets the value.
	 *
	 * @param value the new value
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	/**
	 * Gets the descr.
	 *
	 * @return the descr
	 */
	public String getDescr() {
		return descr;
	}
	
	/**
	 * Sets the descr.
	 *
	 * @param descr the new descr
	 */
	public void setDescr(String descr) {
		this.descr = descr;
	}
	
	/**
	 * Gets the sys cd.
	 *
	 * @return the sys cd
	 */
	public String getSysCd() {
		return sysCd;
	}
	
	/**
	 * Sets the sys cd.
	 *
	 * @param sysCd the new sys cd
	 */
	public void setSysCd(String sysCd) {
		this.sysCd = sysCd;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the upd by
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the new upd by
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
}
