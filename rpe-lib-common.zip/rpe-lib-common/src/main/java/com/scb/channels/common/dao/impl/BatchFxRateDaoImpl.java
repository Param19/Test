package com.scb.channels.common.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.common.dao.BatchFxRateDAO;
import com.scb.channels.common.vo.BatchFxRateVO;


/**
 * The Class BatchFxRateDaoImpl.
 */
public class BatchFxRateDaoImpl extends HibernateDaoSupport implements BatchFxRateDAO {

	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.BatchFxRateDAO#getBatchFxRate(com.scb.channels.common.vo.BatchFxRateVO)
	 */
	public List<BatchFxRateVO> getBatchFxRate(BatchFxRateVO batchFxRateVO) {
		Criteria criteria = getSession().createCriteria(BatchFxRateVO.class);
		if(batchFxRateVO!=null && batchFxRateVO.getId()!=null){
		criteria.add(Restrictions.eq(HibernateHelper.ID, batchFxRateVO.getId()));
		List<BatchFxRateVO> list = criteria.list();
		return list;
		}else{
		return null;
		}
	}
	
}
