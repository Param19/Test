package com.scb.channels.common.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.common.dao.CrossCurrencyDAO;
import com.scb.channels.common.service.CrossCurrencyService;
import com.scb.channels.common.vo.CrossCurrencyVO;


/**
 * The Class CrossCurrencyServiceImpl.
 */
public class CrossCurrencyServiceImpl implements CrossCurrencyService {

	/** The cross currency dao. */
	private CrossCurrencyDAO crossCurrencyDAO;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CrossCurrencyServiceImpl.class);
	
	/** The currency map. */
	private Map<String,List<String>> currencyMap = new HashMap<String,List<String>>();
	
	/** The cache manager. */
	private CacheManager cacheManager;
		
	/**
	 * Cross currency check.
	 * 
	 * @param channelId
	 *            the channel id
	 * @param ctryCd
	 *            the ctry cd
	 * @param srcCurrency
	 *            the src currency
	 * @param destCurrency
	 *            the dest currency
	 * @return true, if successful
	 * @see com.scb.channels.common.service.CrossCurrencyService#crossCurrencyCheck(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	public boolean crossCurrencyCheck(String channelId,String ctryCd,String srcCurrency,String destCurrency) {
		LOGGER.info("Entered CrossCurrency SreviceImpl Class..");
		List<CrossCurrencyVO>  list =null;
		if(cacheManager.getCache(CommonConstants.MY_CACHE).get(CommonConstants.CURRENCY_MAP) == null){
			list =  crossCurrencyDAO.getCrossCurrencyList(ctryCd, CommonConstants.STATUS_ACTIVE);
			LOGGER.info("List Size :: "+list.size());
			String chnCurrCntry = null;
			for(CrossCurrencyVO currVO : list){
				chnCurrCntry =currVO.getChannelId()+ CommonConstants.UNDERSCORE + currVO.getCtryCode() 
						+ CommonConstants.UNDERSCORE +currVO.getSrcCurrency();
				getCurrencyList(chnCurrCntry, currVO);
			}
			cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(CommonConstants.CURRENCY_MAP,currencyMap));
		} else {
			currencyMap=(Map<String, List<String>>) cacheManager.getCache(CommonConstants.MY_CACHE).get(CommonConstants.CURRENCY_MAP).getValue();
		}
		LOGGER.info("Currenecy map :: "+currencyMap);
	
		String key = channelId+ CommonConstants.UNDERSCORE + ctryCd + CommonConstants.UNDERSCORE + srcCurrency;
		if(currencyMap.containsKey(key) && currencyMap.get(key).contains(destCurrency)){
			return true;
		}
		LOGGER.error("Currenecy map doensn't have value for this :: "+key);
		return false;
	}

	/**
	 * Gets the currency list.
	 *
	 * @param chnCurrCntry the chn curr cntry
	 * @param currVO the curr vo
	 * @return the currency list
	 */
	
	private void getCurrencyList(String chnCurrCntry, CrossCurrencyVO currVO) {
		List<String> currencyList;
		if(currencyMap.containsKey(chnCurrCntry)){
			currencyList = currencyMap.get(chnCurrCntry);
			if(!currencyList.contains(currVO.getDestCurrency())){
				currencyList.add(currVO.getDestCurrency());
				currencyMap.put(chnCurrCntry,currencyList);			
			}
		}else{
			currencyList =new ArrayList<String>();
			currencyList.add(currVO.getDestCurrency());
			currencyMap.put(chnCurrCntry,currencyList);			
		}
		
	}

	/**
	 * Gets the cross currency dao.
	 *
	 * @return the crossCurrencyDAO
	 */
	public CrossCurrencyDAO getCrossCurrencyDAO() {
		return crossCurrencyDAO;
	}

	/**
	 * Sets the cross currency dao.
	 *
	 * @param crossCurrencyDAO the crossCurrencyDAO to set
	 */
	public void setCrossCurrencyDAO(CrossCurrencyDAO crossCurrencyDAO) {
		this.crossCurrencyDAO = crossCurrencyDAO;
	}

	/**
	 * Gets the cache manager.
	 *
	 * @return the cacheManager
	 */
	public CacheManager getCacheManager() {
		return cacheManager;
	}

	/**
	 * Sets the cache manager.
	 *
	 * @param cacheManager the cacheManager to set
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

}
