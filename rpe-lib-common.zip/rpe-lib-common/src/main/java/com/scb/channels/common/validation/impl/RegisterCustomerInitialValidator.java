/**
 * 
 */
package com.scb.channels.common.validation.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.ValidatorException;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.CustomerProfileVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.dao.CustomerProfileDAO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.validation.MultiFieldValidator;
import com.scb.channels.common.vo.ReferenceVO;

/**
 * The Class AccountValidator.
 *
 * @author 1464143 This class used to check the validation for Account Number
 */
public class RegisterCustomerInitialValidator implements MultiFieldValidator {

	/** The bean. */
	private PayloadDTO bean;
	
	/** The property. */
	private List<String> property;
	
	/** The min length. */
	private String	number_StartsWith ;
	/** The reference service. */
	private ReferenceService referenceService;
	/** The CustomerProfileDAO */
	private CustomerProfileDAO customerProfileDAO;
	
	

	

	/**
	 * Validate.
	 * 
	 * @throws ValidatorException
	 *             the validator exception
	 * @see com.scb.channels.common.validation.MultiFieldValidator#validate()
	 */
	public void validate() throws ValidatorException {
		String userId = null;
		String relNumber = null;
		String strMobThree = null;
		String cntryCd= null;
		try {
			userId = (String) PropertyUtils.getProperty(bean, property.get(0));
			relNumber = (String) PropertyUtils.getProperty(bean, property.get(1));
			cntryCd = (String) PropertyUtils.getProperty(bean, property.get(2));
		} catch (Exception e) {
			throw new ValidatorException(
					"Invalid Mobile Number  or rel number field present");
		}		
		if(!checkForRelationShipNum(cntryCd,userId,relNumber)){
			throw new ValidatorException(" Customer is already registered not allowed for registration.");
		}
		if (userId != null){
			if (!userId.startsWith(number_StartsWith)) {
				throw new ValidatorException("Country mobile number validation fails.");
			}
			
			if (!checkInternalCustomer(relNumber)) {
				throw new ValidatorException("Internal customer not allowed for registration.");
			}
			
			
		}

	}
	
	/**
	 * Check for valid relationship number.
	 * @param cntryCd
	 * @param userId
	 * @param strRelationshipNo
	 * @return
	 * @throws ValidatorException
	 */
	public boolean checkForRelationShipNum(String cntryCd,String userId,String strRelationshipNo) throws ValidatorException {
	
	CustomerProfileVO  customerProfileVO = customerProfileDAO.getCustomerProfile( cntryCd,
			 userId, strRelationshipNo);
	
	if (customerProfileVO != null && customerProfileVO.getStatusCd() != null && (customerProfileVO.getStatusCd().equals(CommonConstants.STATUS_ACTIVE)))
	{	
		return false;
	}else{
		return true;
	}	
	}
	
	public boolean checkInternalCustomer(String strRelationshipNo) throws ValidatorException {
		
		String internalRelNo = null;
		ReferenceVO referenceVO = new ReferenceVO();
		referenceVO.setType(CommonConstants.TYPE_ADC_BO_MASTER);
		referenceVO.setRefCode(CommonConstants.REFCD_INTERNAL_CUSTOMER);
		referenceVO = referenceService.getReference(referenceVO);
		internalRelNo=referenceVO.getRefValue();
		String[] internalRelNoStrArray = internalRelNo.split(CommonConstants.COMMA);
		List<String> internalRelNoList = Arrays.asList(internalRelNoStrArray);

		if (internalRelNoList.contains(strRelationshipNo))
		{
			return false;
		}else{
			return true;
		}
		}
	



	/**
	 * Sets the property.
	 * 
	 * @param property
	 *            the new property
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setProperty(java.util.List)
	 */
	public void setProperty(List<String> property) {
		
		this.property = property;
	}


	/**
	 * Sets the bean.
	 * 
	 * @param bean
	 *            the new bean
	 * @see com.scb.channels.common.validation.MultiFieldValidator#setBean(com.scb.channels.common.vo.PayloadDTO)
	 */
	public void setBean(PayloadDTO bean) {
		this.bean =  bean;
		
	}

	/**
	 * @param number_StartsWith the number_StartsWith to set
	 */
	public void setNumber_StartsWith(String number_StartsWith) {
		this.number_StartsWith = number_StartsWith;
	}


	
	/**
	 * @param customerProfileDAO the customerProfileDAO to set
	 */
	public void setCustomerProfileDAO(CustomerProfileDAO customerProfileDAO) {
		this.customerProfileDAO = customerProfileDAO;
	}
	
	/**
	 * @param referenceService the referenceService to set
	 */
	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	
	
}
