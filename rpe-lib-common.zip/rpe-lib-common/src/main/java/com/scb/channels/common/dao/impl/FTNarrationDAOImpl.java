package com.scb.channels.common.dao.impl;



import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.common.dao.FTNarrationDAO;
import com.scb.channels.common.vo.FTNarrationVO;

/**
 * The Class FTNarrationDAOImpl.
 */
public class FTNarrationDAOImpl extends HibernateDaoSupport implements FTNarrationDAO {
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.dao.FTNarrationDAO#get(com.scb.channels.common.vo.FTNarrationVO)
	 */
	public List<FTNarrationVO> get(String channel,String cntryCd) {
		org.hibernate.Criteria criteria = getSession().createCriteria(FTNarrationVO.class);
			criteria.add(Restrictions.eq("ccountryCode", cntryCd));			
			criteria.add(Restrictions.eq("channel", channel));		
			return	criteria.list();
			//return list.size() == 0 ? null : list.get(0);
	}

	

}
