package com.scb.channel.transformer;

import com.scb.channels.common.transformers.TransformerException;
import com.scb.channels.paymentservice.PaymentRequest;

/**
 * The Interface PaymentsTransformerImpl.
 */
public interface PaymentsTransformer {

	public PaymentRequest doTransform(String paymentRequestXML) throws TransformerException;

}
