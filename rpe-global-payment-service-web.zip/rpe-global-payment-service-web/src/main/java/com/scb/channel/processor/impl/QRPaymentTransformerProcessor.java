package com.scb.channel.processor.impl;

import java.util.Date;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.qrpayments.QrPaymentRequestType;
import com.scb.channels.qrpayments.QrPaymentResponseType;

public class QRPaymentTransformerProcessor {
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(QRPaymentTransformerProcessor.class);

	public QrPaymentRequestType getObject(String qrPaymentRequestXML) {
		QrPaymentRequestType qrPaymentRequest = null;
		
		try {
			LOGGER.info("REQUEST IN TIME ::::::::::"+ new Date()+":::::Transforming qrpayment xml string to object message :::: " + qrPaymentRequestXML);
			qrPaymentRequest = (QrPaymentRequestType)CommonHelper.unMarshall(qrPaymentRequestXML, QrPaymentRequestType.class);
			
			if(qrPaymentRequest != null &&	qrPaymentRequest.getMessageContext() != null) {
				LOGGER.info("Transforming qrpayment request successful --- > "+ qrPaymentRequest.getMessageContext().getReqID());
			}
		
		} catch (TransformerException e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: "+ e.getMessage());
			LOGGER.error(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: "+ e.getMessage());
			LOGGER.error(e.getMessage());
		}
		return qrPaymentRequest;
	}
	
	public String getResponseXml(QrPaymentResponseType qrPaymentResponse) {
		String responseXml = null;
		LOGGER.info("Transforming payment response object to xml string");
		try {
			responseXml = CommonHelper.getXML(qrPaymentResponse, 
					QrPaymentResponseType.class, QrPaymentResponseType.class.getSimpleName());
			
			if(responseXml != null) {
				LOGGER.info("RESPONSE OUT TIME ::::::::::"+ new Date()+":::::Transforming qrpayment response xml successful --- > ::: " + responseXml);
			} else {
				LOGGER.info("RESPONSE OUT TIME ::::::::::"+ new Date()+":::::Transforming qrpayment response xml is NOT successful --- > ::: " + responseXml);
			}
			
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT FINAL RESPONSE XML :::::: "+ e.getMessage());
			LOGGER.error(e.getMessage());
		}
		return responseXml;
	}
	
}
