package com.scb.channel.channelservices.impl;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransferRequestVO;

public class TransactionSupportProcessorImpl {
	
/**process
 * 	
 * @param payloadDTO
 * @return payloadDTO
 */
public PayloadDTO process(PayloadDTO payloadDTO) {
	
		TransferRequestVO transferRequestVO = (TransferRequestVO)payloadDTO.getRequestVO();
		String fromAccountNumber = transferRequestVO.getTransactionInfoVO().getSrcAccountVO().getAccountNumber();
		String toAccountNumber = transferRequestVO.getTransactionInfoVO().getDestAccountVO().getAccountNumber();
		
		// Validate the account number
		validateAccount(fromAccountNumber);
		
		// to check the transaction type is OAT or IFT
		if(toAccountNumber.indexOf("-")!=-1){
			transferRequestVO.getTransactionInfoVO().setTxnTypeCd("OAT");
			// To validate check toAccountNumber if txn type is OAT
			validateAccount(toAccountNumber);
			
		}else{
			transferRequestVO.getTransactionInfoVO().setTxnTypeCd("IFT");
		}
		
		// setting currency code
		transferRequestVO.getTransactionInfoVO().getSrcAccountVO().setCurrency("KES");
		transferRequestVO.getTransactionInfoVO().getDestAccountVO().setCurrency("KES");
		payloadDTO.setRequestVO(transferRequestVO);
		
		return payloadDTO;
	}

	/**validateAccount
	 * @param accountNumber
	 * 
	 * @return boolean
	 */
	private Boolean validateAccount(String accountNumber){
		
		// TODO : check whether the account number exists or not
		
		return true;
	}
	

}
