package com.scb.channel.processor.aggregator;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.scb.channels.base.vo.AccountListResponseVO;
import com.scb.channels.base.vo.BeneficiaryResponseVO;
import com.scb.channels.base.vo.BillerListResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ProductDetailsResponseVO;

/**
 * The Class ProductDetailsAggregationStrategy.
 */
public class ProductDetailsAggregationStrategy implements AggregationStrategy {

	 /* (non-Javadoc)
 	 * @see org.apache.camel.processor.aggregate.AggregationStrategy#aggregate(org.apache.camel.Exchange, org.apache.camel.Exchange)
 	 */
 	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
 		PayloadDTO payload = null;
 		Object newBody = null;
 		Exchange responeExchange = null;
 		if (oldExchange != null) {
 			payload = oldExchange.getIn().getBody(PayloadDTO.class);
 			responeExchange = oldExchange;
 		} else {
 			payload = new PayloadDTO();
 		}
		ProductDetailsResponseVO responseVO = null;
		if (payload != null && payload.getResponseVO() != null ) {
		   	responseVO = (ProductDetailsResponseVO)payload.getResponseVO();
		} else {
		   	responseVO = new ProductDetailsResponseVO();
		}
		if (newExchange != null) {
		    newBody = newExchange.getIn().getBody();
		    if (newBody instanceof BeneficiaryResponseVO) {
		    	responseVO.setBeneficiaryResponseVO((BeneficiaryResponseVO)newBody);
		    } else if (newBody instanceof BillerListResponseVO) {
		    	responseVO.setBillerListResponseVO((BillerListResponseVO)newBody);
		    }  else if (newBody instanceof AccountListResponseVO) {
		    	responseVO.setAccountListResponseVO((AccountListResponseVO)newBody);
		    }
		    if (responeExchange == null) {
		    	responeExchange = newExchange;
		    }
 		} 
	    payload.setResponseVO(responseVO);
	    responeExchange.getIn().setBody(payload);
	    return responeExchange;
	}
}
