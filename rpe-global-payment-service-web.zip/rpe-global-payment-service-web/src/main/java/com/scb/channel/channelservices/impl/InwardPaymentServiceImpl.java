package com.scb.channel.channelservices.impl;

import com.scb.channels.credit.InwardPaymentService;
import com.scb.channels.inward.CreditHistoryRequestType;
import com.scb.channels.inward.CreditHistoryResponseType;
import com.scb.channels.inward.InwardInquiryRequestType;
import com.scb.channels.inward.InwardPaymentRequestType;
import com.scb.channels.inward.InwardResponseType;

public class InwardPaymentServiceImpl implements InwardPaymentService{

	@Override
	public InwardResponseType credit(InwardPaymentRequestType parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InwardResponseType inquiry(InwardInquiryRequestType parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CreditHistoryResponseType creditHistory(
			CreditHistoryRequestType parameters) {
		// TODO Auto-generated method stub
		return null;
	}

}
