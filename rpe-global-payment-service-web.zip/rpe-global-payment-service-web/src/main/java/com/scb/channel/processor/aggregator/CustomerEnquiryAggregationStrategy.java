package com.scb.channel.processor.aggregator;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.collections.CollectionUtils;

import com.scb.channels.base.vo.ContactDetailsVO;
import com.scb.channels.base.vo.CustomerDetailsVO;
import com.scb.channels.base.vo.CustomerEnquiryResponseVO;
import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Class ProductDetailsAggregationStrategy.
 */
public class CustomerEnquiryAggregationStrategy implements AggregationStrategy {

	 /* (non-Javadoc)
 	 * @see org.apache.camel.processor.aggregate.AggregationStrategy#aggregate(org.apache.camel.Exchange, org.apache.camel.Exchange)
 	 */
 	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
 		PayloadDTO payload = null;
 		Object newBody = null;
 		Exchange responeExchange = null;
 		if (oldExchange != null) {
 			payload = oldExchange.getIn().getBody(PayloadDTO.class);
 			responeExchange = oldExchange;
 		} else if (newExchange != null) {
 			payload = newExchange.getIn().getBody(PayloadDTO.class);
 			responeExchange = newExchange;
 		} 
 		if (payload == null) {
 			payload = new PayloadDTO();
 		}
		CustomerEnquiryResponseVO responseVO = null;
		if (payload != null && payload.getResponseVO() != null ) {
		   	responseVO = (CustomerEnquiryResponseVO)payload.getResponseVO();
		} else {
		   	responseVO = new CustomerEnquiryResponseVO();
		}
		if (newExchange != null && oldExchange !=null) {
		    newBody = newExchange.getIn().getBody();
		    if (newBody != null && 
		    		newBody instanceof PayloadDTO 
		    		&& ((PayloadDTO)newBody).getResponseVO() != null) {
		    	CustomerEnquiryResponseVO respVo = (CustomerEnquiryResponseVO)
		    			((PayloadDTO)newBody).getResponseVO();
		    	CustomerDetailsVO customerDetailsVO = responseVO.getCustomerDetailsVO();
				if (respVo.getCustomerDetailsVO() != null 
		    			&& CollectionUtils.isNotEmpty(respVo
		    					.getCustomerDetailsVO().getContactDetailsVO())) {
		    		customerDetailsVO.setContactDetailsVO(respVo
		    					.getCustomerDetailsVO().getContactDetailsVO());
		    	} else {
		    		List<ContactDetailsVO> list = new ArrayList<ContactDetailsVO>();
		    		if (customerDetailsVO != null && CollectionUtils
		    				.isNotEmpty(customerDetailsVO.getContactDetailsVO())) {
		    			list.addAll(customerDetailsVO.getContactDetailsVO());
		    		}
		    		responseVO.setCustomerDetailsVO(respVo.getCustomerDetailsVO());
		    		customerDetailsVO.setContactDetailsVO(list);
		    	}
		    } 
		    if (responeExchange == null) {
		    	responeExchange = newExchange;
		    }
 		} 
	    payload.setResponseVO(responseVO);
	    responeExchange.getOut().setBody(payload);
	    return responeExchange;
	}
}
