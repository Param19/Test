package com.scb.channel.channelservices.impl;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.HostResponseApiVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRAcquirerInfoApiVO;
import com.scb.channels.base.vo.QRPaymentApiResponseVO;
import com.scb.channels.base.vo.QRPaymentHistoryResponseVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.StatusTypeApiVO;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.StatusType;
import com.scb.channels.mapper.helper.QRPaymentMappingHelper;
import com.scb.channels.qrpayments.QrAcquirerInfo;
import com.scb.channels.qrpayments.QrPaymentHistoryResponseType;
import com.scb.channels.qrpayments.QrPaymentResponseType;

public class QRPaymentResponseImpl {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentResponseImpl.class);
	
	public QrPaymentResponseType qrPaymentResponseTransform(PayloadDTO payload){
		
		LOGGER.info("Inside QRPaymentResponseImpl qrPaymentResponseTransform Start  ::::");
		QrPaymentResponseType response = new QrPaymentResponseType();
		Set<HostResponseVO> hostResponseList = new HashSet<HostResponseVO>();
		HostResponseType hostResponse = new HostResponseType();
		StatusType status = new StatusType();
		try{
			
			if(payload != null && payload.getResponseVO()!= null && payload.getRequestVO()!= null){
				QRPaymentResponseVO qrPaymentResponseVO = (QRPaymentResponseVO)payload.getResponseVO();
				QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
				response = QRPaymentMappingHelper.getQRPaymentResponseVOMapping(qrPaymentResponseVO);
				if (qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus() != null && 
						!(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS))){
					QrAcquirerInfo acquirer = new QrAcquirerInfo();
					acquirer.setRetrievalReferenceNumber(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
					response.setAcquirer(acquirer);
				}
				hostResponseList = qrPaymentRequestVO.getHostResponseVO();
				LOGGER.info("Inside QRPaymentResponseImpl Host ResponseList  ::::"+hostResponseList.size());
				//response.setTransactionReferenceNo(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
				if(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus() != null ){
					hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostReference(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
					
					if(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS)) {
						LOGGER.info("AGGREGATOR_PAY_SUCCESS ::: " +qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.SUCCESS);
					} else if(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_TIMEOUT) || 
							qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.ACQUIRER_TIMEOUT)
							|| qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.TIMEOUT)){
						LOGGER.info("TIMEOUT STATUS ::: " + qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
						status.setStatusCode(CommonConstants.SUBMITTED_CODE);
						status.setStatusDesc(CommonConstants.SUBMITTED);
					}else{
						LOGGER.info("FAILURE STATUS ::: " + qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
					}
				 }else{
						LOGGER.info("The response object is not complete TxnActStatus is Null :::");
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						
						hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
						hostResponse.setDesc(CommonConstants.FAILURE);
						hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				 }
				}else{
					LOGGER.info("The response object is not complete payload is Null ::::");
					System.out.println("The response object is not complete");
					status.setStatusCode(CommonConstants.TIMEOUT_CODE);
					status.setStatusDesc(CommonConstants.FAILURE);
					
					hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				}
									
					if(hostResponseList != null && !hostResponseList.isEmpty()) {
						LOGGER.info("Setting the previous host response ::: ");
						System.out.println("Setting the previous host response ::: ");
						
						for(HostResponseVO previousHostResponse : hostResponseList){
							HostResponseType hostResponseType = new HostResponseType();
							
							hostResponseType.setCode(previousHostResponse.getCode());
							hostResponseType.setDesc(previousHostResponse.getDesc());
							hostResponseType.setHostName(previousHostResponse.getHostName());
							status.getHostResponse().add(hostResponseType);
						}
					}else{				
						status.getHostResponse().add(hostResponse);
					}
				response.setStatus(status);
			
		}catch(Exception e){
			LOGGER.error("Exception Raised in QRPaymentResponseImpl ::::"+e.getMessage());
			LOGGER.info("Inside QRPaymentResponseImpl Exception  :::");

			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
			hostResponse.setDesc(CommonConstants.FAILURE);
			hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);

			LOGGER.error("Exception for QR Payment final response :::: "+ response.getMessageContext().getReqID());
			System.out.println("Exception for QR Payment final response :::: " + response.getMessageContext().getReqID());
			LOGGER.error("Exception occurred while QR Payment final response :::: "+ e.getMessage());
			System.out.println("Exception occurred while QR Payment final response :::: " 	+ e.getMessage());
		
		}
		return response;
	}
	
	public QrPaymentHistoryResponseType qrPaymentHistoryResponseTransform(PayloadDTO payload){ 
		
		LOGGER.info("Inside QRPaymentResponseImpl qrPaymentHistoryResponseTransform Start  ::::");
		QrPaymentHistoryResponseType qrPaymentHistoryResponseType = new QrPaymentHistoryResponseType();
		StatusType status = new StatusType();
		
		try{
			
			if(payload != null && payload.getResponseVO()!= null){
				QRPaymentHistoryResponseVO qrPaymentHistoryResponseVO = (QRPaymentHistoryResponseVO)payload.getResponseVO();
				//List<QRPaymentViewVO> qRPaymentViewVO = qrPaymentHistoryResponseVO.getQrPaymentHistoryViewList();
				if(qrPaymentHistoryResponseVO.getQrPaymentHistoryViewList()!=null)
				{
				qrPaymentHistoryResponseType = QRPaymentMappingHelper.getQRHistoryViewResponseVOMapping(qrPaymentHistoryResponseVO);
				}
				else
				{
					status.setStatusCode(CommonConstants.TIMEOUT_CODE);
					status.setStatusDesc("Unable to fetch QRPayment History");
					
					qrPaymentHistoryResponseType.setStatusInfo(status);
				}
			}
			
		}catch(Exception e)
		{
			LOGGER.error("Exception Raised in QRPaymentResponseImpl qrPaymentHistoryResponseTransform ::::"+e.getMessage());
			LOGGER.info("Inside QRPaymentResponseImpl qrPaymentHistoryResponseTransform Exception  :::");
			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			qrPaymentHistoryResponseType.setStatusInfo(status);

		}
		
		return qrPaymentHistoryResponseType;
		
	}

public QRPaymentApiResponseVO qrPaymentApiResponseTransform(PayloadDTO payload){
		
		LOGGER.info("Inside QRPaymentResponseImpl qrPaymentApiResponseTransform Start  ::::");
		QRPaymentApiResponseVO response = new QRPaymentApiResponseVO();
		Set<HostResponseVO> hostResponseList = new HashSet<HostResponseVO>();
		HostResponseApiVO hostResponse = new HostResponseApiVO();
		StatusTypeApiVO status = new StatusTypeApiVO();
		try{
			
			if(payload != null && payload.getResponseVO()!= null && payload.getRequestVO()!= null){
				QRPaymentResponseVO qrPaymentResponseVO = (QRPaymentResponseVO)payload.getResponseVO();	
				QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
				response = QRPaymentMappingHelper.getQRPaymentResponseRestVOMapping(qrPaymentResponseVO);
				if (qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus() != null && 
						!(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS))){
					QRAcquirerInfoApiVO acquirer = new QRAcquirerInfoApiVO();
					acquirer.setRetrievalReferenceNumber(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
					acquirer.setMerchantPan(qrPaymentResponseVO.getQrPaymentDetailVO().getMerchantPan());
					response.setAcquirer(acquirer);
				}
				
				hostResponseList = qrPaymentRequestVO.getHostResponseVO();
				LOGGER.info("Inside QRPaymentResponseImpl Host ResponseList  ::::"+hostResponseList.size());
				
				if(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus() != null ){		
					hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostReference(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
					
					if(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS)) {
						LOGGER.info("AGGREGATOR_PAY_SUCCESS ::: " +qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.SUCCESS);
					} else if(qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_TIMEOUT) || 
							qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.ACQUIRER_TIMEOUT)
							|| qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.TIMEOUT)){
						LOGGER.info("TIMEOUT STATUS ::: " + qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
						status.setStatusCode(CommonConstants.SUBMITTED_CODE);
						status.setStatusDesc(CommonConstants.SUBMITTED);
					}else{
						LOGGER.info("FAILURE STATUS ::: " + qrPaymentResponseVO.getQrPaymentDetailVO().getHost_reference());
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
					}
				 }else{
						LOGGER.info("The response object is not complete TxnActStatus is Null :::");
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						
						hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
						hostResponse.setDesc(CommonConstants.FAILURE);
						hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				 }
				}else{
					LOGGER.info("The response object is not complete payload is Null ::::");
					System.out.println("The response object is not complete");
					status.setStatusCode(CommonConstants.TIMEOUT_CODE);
					status.setStatusDesc(CommonConstants.FAILURE);
					
					hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				}
			
			if(hostResponseList != null && !hostResponseList.isEmpty()) {
				LOGGER.info("Setting the previous host response ::: ");
				System.out.println("Setting the previous host response ::: ");
				
				for(HostResponseVO previousHostResponse : hostResponseList){
					hostResponse = new HostResponseApiVO();
					
					hostResponse.setCode(previousHostResponse.getCode());
					hostResponse.setDesc(previousHostResponse.getDesc());
					hostResponse.setHostName(previousHostResponse.getHostName());
					status.getHostResponse().add(hostResponse);
				}
			}else{				
				status.getHostResponse().add(hostResponse);
			}
			
			response.setStatus(status);
			
		}catch(Exception e){
			LOGGER.error("Exception Raised in QRPaymentResponseImpl ::::"+e.getMessage());
			LOGGER.info("Inside QRPaymentResponseImpl Exception  :::");

			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
			hostResponse.setDesc(CommonConstants.FAILURE);
			hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);

			LOGGER.error("Exception for QR Payment final response :::: "+ response.getMessageContext().getReqID());
			System.out.println("Exception for QR Payment final response :::: " + response.getMessageContext().getReqID());
			LOGGER.error("Exception occurred while QR Payment final response :::: "+ e.getMessage());
			System.out.println("Exception occurred while QR Payment final response :::: " 	+ e.getMessage());
		
		}
		return response;
	}

}
