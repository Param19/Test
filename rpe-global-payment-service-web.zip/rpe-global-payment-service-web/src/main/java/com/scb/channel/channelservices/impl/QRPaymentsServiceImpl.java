package com.scb.channel.channelservices.impl;

import com.scb.channels.qrpayments.QrPaymentHistoryRequestType;
import com.scb.channels.qrpayments.QrPaymentHistoryResponseType;
import com.scb.channels.qrpaymentservice.QrPayments;



public class QRPaymentsServiceImpl implements QrPayments{

	/*@Override
	public QrPaymentResponseType qrPay(QrPaymentRequestType request) {
		return null;
	}
*/
	@Override
	public QrPaymentHistoryResponseType qrPayHistory(QrPaymentHistoryRequestType request) {
		return null;
	}


}
