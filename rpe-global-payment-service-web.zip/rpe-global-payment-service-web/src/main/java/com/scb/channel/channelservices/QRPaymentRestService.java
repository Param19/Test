package com.scb.channel.channelservices;

import com.scb.channels.base.vo.QRPaymentApiRequestVO;
import com.scb.channels.base.vo.QRPaymentApiResponseVO;

public interface QRPaymentRestService{
	
	public QRPaymentApiResponseVO doQRPay(QRPaymentApiRequestVO qrPaymentApiRequest);
	
}
