package com.scb.channel.processor.impl;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.mapper.helper.JetcoPayMappingHelper;
import com.scb.channels.paymentservice.PaymentRequest;



/**
 * JetcoPaymentProcessor
 * 
 * @author 1552545
 * 
 */
public class JetcoPaymentProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(JetcoPaymentProcessor.class);

	/**
	 * Jetco parameters process
	 * 
	 * @param dto
	 * @return
	 */
	public PayloadDTO process(PaymentRequest request) {
		PayloadDTO dto = new PayloadDTO();
		try {
			// transfer paymentRequest to dto;
			JetcoPayRequestVO jetcoRequest = JetcoPayMappingHelper.getJetcoPaymentRequest(request);
			TransactionInfoVO transactionInfo = new TransactionInfoVO();
			jetcoRequest.setTransactionInfo(transactionInfo);
			jetcoRequest.setPaymentDate(new Timestamp(new Date().getTime()));
			dto.setRequestVO(jetcoRequest);
			dto.setCurrentState(CommonConstants.IN_PROGRESS);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return dto;
	}

}
