package com.scb.channel.channelservices.impl;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.scb.channel.channelservices.QRPaymentRestService;
import com.scb.channels.base.vo.QRPaymentApiRequestVO;
import com.scb.channels.base.vo.QRPaymentApiResponseVO;

public class QRPaymentRestServiceImpl implements QRPaymentRestService{

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/")
	public QRPaymentApiResponseVO doQRPay(QRPaymentApiRequestVO qrPaymentApiRequest) {
		return null;
	}
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{transactionReferenceNumber}")
	public QRPaymentApiResponseVO getQRPaymentStatus(@PathParam("transactionReferenceNumber") String transactionRefNumber) {
		return null;
	}
	
}
