package com.scb.channel.channelservices.impl;

import javax.xml.datatype.DatatypeConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.paymentservice.AddPayeeRequest;
import com.scb.channels.paymentservice.BillPresentmentRequest;
import com.scb.channels.paymentservice.BillerBycategoryRequest;
import com.scb.channels.paymentservice.BillerNameBycategoryRequest;
import com.scb.channels.paymentservice.DeletePayeeRequest;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountRequest;
import com.scb.channels.paymentservice.GetPayeeRequest;
import com.scb.channels.paymentservice.JobServiceRequest;
import com.scb.channels.paymentservice.PaymentHistoryRequest;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.ValidatePayeeRequest;

public class PaymentWrapServiceImpl {

	/** The Constant LOGGER_PERF. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonConstants.SERVICE_PERF_LOG);

	public PayloadDTO getPresentment(BillPresentmentRequest parameters) {
		// TODO Auto-generated method stub
		return null;

	}

	public PayloadDTO addPayee(AddPayeeRequest addPayeeRequest) {
		// return
		// RegistrationMappingHelper.getRegisterRequest(registerCustomer);
		LOGGER.info("PaymentWrapServiceImpl :: addPayee :: Start ");
		PayloadDTO payloadDTO = new PayloadDTO();
		try{
		BillerPayRequestVO billerPayRequestVO = BillpaymentMappingHelper.getAddPayeeRequestVOMapping(addPayeeRequest);
		if(billerPayRequestVO !=null && billerPayRequestVO.getServiceVO() != null && 
				billerPayRequestVO.getServiceVO().getServiceName() != null &&  
				billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.WALLET_SERVICE)){
		billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.ADD_WALLET_PAYEE);	
		}
		else {		
		billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.ADD_PAYEE);
		}
		billerPayRequestVO.setErrorCD(CommonConstants.ZERO);
		//billerPayRequestVO.getServiceVO().setServiceTxnType(CommonConstants.INSERT);
		billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(billerPayRequestVO);
		}catch(Exception e){
			LOGGER.info("PaymentWrapServiceImpl :: addPayee :: Exception "+addPayeeRequest.getMessageContext().getReqID());
			LOGGER.error("Exception occurred ::: ",e);
		}
		LOGGER.info("PaymentWrapServiceImpl :: addPayee :: End "+addPayeeRequest.getMessageContext().getReqID());
		return payloadDTO;

	}

	/**
	 * @param parameters
	 * @return
	 */
	public PayloadDTO deletePayee(DeletePayeeRequest deletePayeeRequest) {
		PayloadDTO payloadDTO = new PayloadDTO();
		BillerPayRequestVO billerPayRequestVO = BillpaymentMappingHelper.getDeletePayeeRequestVOMapping(deletePayeeRequest);
		if(billerPayRequestVO !=null && billerPayRequestVO.getServiceVO() != null && 
				billerPayRequestVO.getServiceVO().getServiceName() != null &&
				billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.WALLET_SERVICE)){
		billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.DELETE_WALLET_PAYEE);	
		}
		else {
		billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.DELETE_PAYEE);
		}
		billerPayRequestVO.setErrorCD(CommonConstants.ZERO);
		billerPayRequestVO.getServiceVO().setServiceTxnType(CommonConstants.DELETE_PAYEE);
		billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(billerPayRequestVO);
		return payloadDTO;

	}

	/**
	 * @param getPayeeRequest
	 * @return
	 */
	public PayloadDTO getPayees(GetPayeeRequest getPayeeRequest) {
		LOGGER.info("PaymentWrapServiceImpl :: getPayees :: Start ");
		PayloadDTO payloadDTO = new PayloadDTO();
		ViewPayeeRequestVO viewPayeeRequestVO = BillpaymentMappingHelper.getViewBillerRequestVOMapping(getPayeeRequest);
		// viewPayeeRequestVO.getServiceVO().setServiceName(CommonConstants.VIEWPAYEE);
		if(viewPayeeRequestVO !=null && viewPayeeRequestVO.getServiceVO() != null && 
				viewPayeeRequestVO.getServiceVO().getServiceName() != null &&
						viewPayeeRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.WALLET_SERVICE)){
			viewPayeeRequestVO.getServiceVO().setServiceName(CommonConstants.GET_WALLET_PAYEE);
		} else {
		viewPayeeRequestVO.getServiceVO().setServiceName("getPayeeList");
		}
		viewPayeeRequestVO.setErrorCD(CommonConstants.ZERO);
		viewPayeeRequestVO.getServiceVO().setServiceTxnType(CommonConstants.VIEWPAYEE);
		viewPayeeRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(viewPayeeRequestVO);
		LOGGER.info("PaymentWrapServiceImpl :: getPayees :: END ");
		return payloadDTO;

	}

	public PayloadDTO billerNames(BillerNameBycategoryRequest parameters) {
		PayloadDTO payloadDTO = new PayloadDTO();
		BillerPayRequestVO billerPayRequestVO = BillpaymentMappingHelper.getBillerNamesRequestMapping(parameters);
		if(billerPayRequestVO !=null && billerPayRequestVO.getServiceVO() != null && 
				billerPayRequestVO.getServiceVO().getServiceName() != null &&
						billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.WALLET_SERVICE)){
			billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.GET_WALLET_BILLERLIST);
		}
		else{
		billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.GETBILLERLIST);
		}
		billerPayRequestVO.setErrorCD(CommonConstants.ZERO);
		billerPayRequestVO.getServiceVO().setServiceTxnType(CommonConstants.ENQUIRY);
		billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(billerPayRequestVO);
		return payloadDTO;
	}

	public PayloadDTO payBill(PaymentRequest paymentRequest) {
		LOGGER.info("PaymentWrapServiceImpl :: payBill :: Start ");
		System.out.println("PaymentWrapServiceImpl :: payBill :: Start ");
		
		String customerId = null;
		
		if (paymentRequest != null && paymentRequest.getClientContext() != null && paymentRequest.getClientContext().getDate() != null) {
			LOGGER.info("Setting the Timezone to undefined");
			System.out.println("Setting the Timezone to undefined");
			paymentRequest.getClientContext().getDate().setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		}
		
		if(paymentRequest != null && paymentRequest.getUserContext() != null 
				&& paymentRequest.getUserContext().getCustomerType() != null
				&& !paymentRequest.getUserContext().getCustomerType().isEmpty()
				&& !paymentRequest.getUserContext().getCustomerType().equalsIgnoreCase(CommonConstants.NA)
				&& paymentRequest.getUserContext().getCustomerId() != null) {
				
			customerId = paymentRequest.getUserContext().getCustomerType() + 
					paymentRequest.getUserContext().getCustomerId();
		}

		PayloadDTO payloadDTO = new PayloadDTO();
		BillerPayRequestVO billerPayRequestVO = BillpaymentMappingHelper.getBillerPayRequestVOMapping(paymentRequest);
		LOGGER.info("paymentRequest to billerPayRequest mapping complete");
		System.out.println("paymentRequest to billerPayRequest mapping complete");

		if(billerPayRequestVO.getServiceVO().getServiceName() == null ||
				billerPayRequestVO.getServiceVO().getServiceName().isEmpty() ||
				billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.NA)) {
			billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.PAY_BILL2);
		}
		//billerPayRequestVO.getServiceVO().setServiceTxnType(CommonConstants.INSERT);
		billerPayRequestVO.setErrorCD(CommonConstants.ZERO);
		billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		
		if(customerId != null && !customerId.isEmpty() && billerPayRequestVO != null && 
			billerPayRequestVO.getBillerPayDetailsVO() != null) {
			billerPayRequestVO.getBillerPayDetailsVO().setCustomerId(customerId);
		}
		
		String hostReference = ReferenceNumberGenerator.generateHostReferenceValue(CommonConstants.SIX,
				billerPayRequestVO.getClientVO().getCountry(), billerPayRequestVO.getClientVO().getChannel());
		billerPayRequestVO.getBillerPayDetailsVO().setHostReference(hostReference);

		payloadDTO.setRequestVO(billerPayRequestVO);

		LOGGER.info("PaymentWrapServiceImpl :: payBill :: End :::");
		System.out.println("PaymentWrapServiceImpl :: payBill :: End ");
		if (payloadDTO != null && payloadDTO.getRequestVO() != null) {
			LOGGER.info(":::: Payload request cannot be null :::: " + payloadDTO.getRequestVO().getMessageVO().getReqID());
			System.out.println(":::: Payload request cannot be null :::: " + payloadDTO.getRequestVO().getMessageVO().getReqID());
		}
		return payloadDTO;
	}

	public PayloadDTO billercategory(BillerBycategoryRequest CategoryRequest) {
		PayloadDTO payloadDTO = new PayloadDTO();
		BillerPayRequestVO billerPayRequestVO = BillpaymentMappingHelper.getBillerCategoryRequest(CategoryRequest);
		billerPayRequestVO.getServiceVO().setServiceName(CommonConstants.BILLER_CATEGORY_SERVICE);
		billerPayRequestVO.setErrorCD(CommonConstants.ZERO);
		billerPayRequestVO.getServiceVO().setServiceTxnType(CommonConstants.ENQUIRY);
		billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(billerPayRequestVO);
		return payloadDTO;
	}

	// Added for Customer Overall Payment Amount Service
	public PayloadDTO getCustomerOverallPaymentAmount(GetCustomerOverallPaymentAmountRequest parameters) {
		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info("PaymentWrapServiceImpl :: getCustomerOverallPaymentAmount :: Start ");
		// BillerPayRequestVO billerPayRequestVO
		// =BillpaymentMappingHelper.getCustomerTotalPaymentAmountRequestMapping(parameters);

		CustomerPaymentAmountRequestVO amountRequestVO = BillpaymentMappingHelper.getCustomerOverallPaymentAmountRequestMapping(parameters);
		amountRequestVO.getServiceVO().setServiceName(CommonConstants.CUSTOMER_OVERALL_PAYMENT_AMOUNT);
		amountRequestVO.setErrorCD(CommonConstants.ZERO);
		amountRequestVO.getServiceVO().setServiceTxnType(CommonConstants.GET);
		amountRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(amountRequestVO);
		/*
		 * BillerPayRequestVO billerPayRequestVO
		 * =BillpaymentMappingHelper.getAddBillerRequestVOMapping(addBiller);
		 * billerPayRequestVO
		 * .getServiceVO().setServiceName(CommonConstants.ADD_BILLER);
		 * billerPayRequestVO.setErrorCD(CommonConstants.ZERO);
		 * billerPayRequestVO
		 * .getServiceVO().setServiceTxnType(CommonConstants.INSERT);
		 * billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		 * payloadDTO.setRequestVO(billerPayRequestVO);
		 */
		LOGGER.info("PaymentWrapServiceImpl :: getCustomerOverallPaymentAmount :: End ");
		return payloadDTO;
		// return null;
	}

	// ends Customer Overall Payment Amount

	/**
	 * @param paymentHistReq
	 * @return
	 */
	public PayloadDTO paymentHistory(PaymentHistoryRequest paymentHistReq) {
		PayloadDTO payloadDTO = new PayloadDTO();
		try {
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  paymentHistory----------------" + paymentHistReq);
			PaymentHistoryRequestVO paymentHistRequestVO = BillpaymentMappingHelper.getPaymentHistoryRequest(paymentHistReq);
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  paymentHistory--paymentHistRequestVO--------------" + paymentHistRequestVO);
			paymentHistRequestVO.getServiceVO().setServiceName(CommonConstants.PAYMENT_HISTORY);
			paymentHistRequestVO.getServiceVO().setServiceTxnType(CommonConstants.VIEW);
			paymentHistRequestVO.getClientVO().setVersion(CommonConstants.ONE);
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  paymentHistRequestVO-11---------------" + paymentHistRequestVO);
			payloadDTO.setRequestVO(paymentHistRequestVO);
		} catch (Exception e) {
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  paymentHistRequestVO- Exception Block---------------" + e.getMessage());
		}
		return payloadDTO;
	}

	/*
	 * public PayloadDTO billerDownloadService(BillerDownloadServiceRequest
	 * billerDownloadServiceRequest) { PayloadDTO payloadDTO = new PayloadDTO();
	 * try{ LOGGER.debug(
	 * "----------paymentWrap Service Impl 000000000000  billerDownloadService----------------"
	 * +billerDownloadServiceRequest); BillerDownloadRequest
	 * billerDownloadRequest
	 * =BillpaymentMappingHelper.getBillerDownloadStatusRequest
	 * (billerDownloadServiceRequest); LOGGER.debug(
	 * "----------paymentWrap Service Impl 000000000000  billerDownloadService----------------"
	 * +billerDownloadRequest); payloadDTO.setRequestVO(billerDownloadRequest);
	 * }catch(Exception e){ LOGGER.debug(
	 * "----------paymentWrap Service Impl 000000000000  paymentHistRequestVO- Exception Block---------------"
	 * +e.getMessage()); } return payloadDTO; }
	 */

	// JobService starts here

	public PayloadDTO jobService(JobServiceRequest jobServiceRequest) {
		PayloadDTO payloadDTO = new PayloadDTO();
		try {
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  billerDownloadService----------------" + jobServiceRequest);
			BillerDownloadRequest billerDownloadRequest = BillpaymentMappingHelper.getjobServiceRequest(jobServiceRequest);
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  billerDownloadService----------------" + jobServiceRequest);
			payloadDTO.setRequestVO(billerDownloadRequest);
		} catch (Exception e) {
			LOGGER.debug("----------paymentWrap Service Impl 000000000000  billerDownloadService- Exception Block---------------" + e.getMessage());
		}
		return payloadDTO;
	}

	public PayloadDTO validatePayee(ValidatePayeeRequest validatePayeeRequest) {
		LOGGER.info("PaymentWrapServiceImpl :: validatePayee :: Start "+validatePayeeRequest.getMessageContext().getReqID());
		PayloadDTO payloadDTO = new PayloadDTO();
		BillerPayRequestVO billerPayRequestVO = BillpaymentMappingHelper.getAddPayeeRequestVOMapping(validatePayeeRequest);
		UserVO user = billerPayRequestVO.getUser();
		if(user!=null && user.getCountry().equalsIgnoreCase(CommonConstants.HK_COUNTRY_CODE)){
		user.setCustomerId(user.getCustomerType()+user.getCustomerId());
		}
		if (billerPayRequestVO.getServiceVO() != null) {
			if (billerPayRequestVO.getServiceVO().getServiceTxnType() != null) {
				if (billerPayRequestVO.getServiceVO().getServiceTxnType().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_INSERT)) {
					billerPayRequestVO.getServiceVO().setServiceName(user.getCountry().equalsIgnoreCase(CommonConstants.HK_COUNTRY_CODE)?CommonConstants.VALIDATE_PAYEE_INSERT_ROUTE:CommonConstants.VALIDATE_PAYEE_INSERT_ROUTE_CS);
					LOGGER.info("PaymentWrapServiceImpl :: validatePayee :: CommonConstants.VALIDATE_PAYEE_INSERT_ROUTE ");
				} else if (billerPayRequestVO.getServiceVO().getServiceTxnType().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_FETCH)) {
					LOGGER.info("PaymentWrapServiceImpl :: validatePayee :: CommonConstants.VALIDATE_PAYEE_FETCH_ROUTE");
					billerPayRequestVO.getServiceVO().setServiceName(user.getCountry().equalsIgnoreCase(CommonConstants.HK_COUNTRY_CODE)?CommonConstants.VALIDATE_PAYEE_FETCH_ROUTE:CommonConstants.VALIDATE_PAYEE_FETCH_ROUTE_CS);
				}

			}
		}
		billerPayRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(billerPayRequestVO);
		billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
		LOGGER.info("PaymentWrapServiceImpl :: validatePayee :: End "+validatePayeeRequest.getMessageContext().getReqID());
		return payloadDTO;

	}

}
