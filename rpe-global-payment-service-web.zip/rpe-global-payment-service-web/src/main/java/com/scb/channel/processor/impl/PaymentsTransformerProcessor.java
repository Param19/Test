package com.scb.channel.processor.impl;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.PaymentResponse;

/**
 * The Class SCBMLPaymentResponseTransformer.
 */
public class PaymentsTransformerProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentsTransformerProcessor.class);
	
	/**
	 * Transform.
	 * 
	 * @param paymentRequestXML
	 *            the request xml from the channel
	 * @return the payment request object
	 * @throws TransformerException
	 *             the transformer exception
	 */
	public PaymentRequest getObject(String paymentRequestXML) {
		PaymentRequest paymentRequest = null;
		
		try {
			LOGGER.info("Transforming payment xml string to object message :::: " + paymentRequestXML);
			System.out.println("Transforming payment xml string to object message");
			paymentRequest = (PaymentRequest)CommonHelper.unMarshall(
					paymentRequestXML, PaymentRequest.class);
			
			if(paymentRequest != null &&
					paymentRequest.getMessageContext() != null) {
				LOGGER.info("Transforming payment request successful --- > " 
						+ paymentRequest.getMessageContext().getReqID());
				System.out.println("Transforming payment request successful --- > " 
						+ paymentRequest.getMessageContext().getReqID());
			}
		
		} catch (TransformerException e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: " 
					+ e.getMessage());
			System.out.println("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: " 
					+ e.getMessage());
			LOGGER.error(e.getMessage());
			System.err.println(e.getMessage() + e);
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: " 
					+ e.getMessage());
			System.out.println("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: " 
					+ e.getMessage());
			LOGGER.error(e.getMessage());
			System.err.println(e.getMessage() + e);
		}
		return paymentRequest;
	}
	
	/**
	 * Transform.
	 * 
	 * @param PaymentResponse
	 *            the response object to the channel
	 * @return the payment response xml
	 * @throws TransformerException
	 *             the transformer exception
	 */
	public String getXml(PaymentResponse paymentResponse) {
		String responseXml = null;
		LOGGER.info("Transforming payment object to xml string");
		System.out.println("Transforming payment object to xml string");
		try {
			responseXml = CommonHelper.getXML(paymentResponse, 
					PaymentResponse.class, PaymentResponse.class.getSimpleName());
			
			if(responseXml != null) {
				LOGGER.info("Transforming payment xml successful --- > ::: " + responseXml);
				System.out.println("Transforming payment xml successful --- > ::: " + responseXml);
			} else {
				LOGGER.info("Transforming payment xml is NOT successful --- > ::: " + responseXml);
				System.out.println("Transforming payment xml is NOT successful --- > ::: " + responseXml);
			}
			
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT RESPONSE XML :::::: " 
					+ e.getMessage());
			System.out.println("EXCEPTION OCCURRED WHILE GENERATING PAYMENT RESPONSE XML :::::: " 
					+ e.getMessage());
			LOGGER.error(e.getMessage());
			System.err.println(e.getMessage() + e);
		}
		return responseXml;
	}
}
