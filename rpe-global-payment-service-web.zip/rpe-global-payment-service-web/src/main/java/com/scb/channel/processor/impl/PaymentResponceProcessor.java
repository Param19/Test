package com.scb.channel.processor.impl;

import org.apache.camel.CamelException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.scb.channels.common.StatusType;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.PaymentResponse;



/**
 * The Class PaymentResponceProcessor.
 */
public class PaymentResponceProcessor implements Processor{

	/* (non-Javadoc)
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@Override
	public void process(Exchange exchange) throws CamelException {
		// TODO Auto-generated method stub
	PaymentRequest paymentRequest= (PaymentRequest) exchange.getIn().getHeader("paymentrequest");
		PaymentResponse response =new PaymentResponse();
		response.setUserContext(paymentRequest.getUserContext());
		response.setClientContext(paymentRequest.getClientContext());
		response.setMessageContext(paymentRequest.getMessageContext());
		response.setServiceContext(paymentRequest.getServiceContext());
		StatusType statusType =new StatusType();
		statusType.setStatusCode("201");
		statusType.setStatusDesc("success");
		response.setStatus(statusType);
		//response.setPayRequestType(paymentRequest.getPayRequestType());
		
		exchange.getOut().setBody(response);
		
	}

}
