package com.scb.channel.channelservices.impl;

import com.scb.channels.payments.Payments;
import com.scb.channels.paymentservice.AddPayeeRequest;
import com.scb.channels.paymentservice.AddPayeeResponse;
import com.scb.channels.paymentservice.BillPresentmentRequest;
import com.scb.channels.paymentservice.BillPresentmentResponse;
import com.scb.channels.paymentservice.BillerBycategoryRequest;
import com.scb.channels.paymentservice.BillerBycategoryResponse;
import com.scb.channels.paymentservice.BillerNameBycategoryReponse;
import com.scb.channels.paymentservice.BillerNameBycategoryRequest;
import com.scb.channels.paymentservice.DeletePayeeRequest;
import com.scb.channels.paymentservice.DeletePayeeResponse;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountRequest;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountResponse;
import com.scb.channels.paymentservice.GetPayeeRequest;
import com.scb.channels.paymentservice.GetPayeeResponse;
import com.scb.channels.paymentservice.JobServiceRequest;
import com.scb.channels.paymentservice.JobServiceResponse;
import com.scb.channels.paymentservice.PaymentHistoryRequest;
import com.scb.channels.paymentservice.PaymentHistoryResponse;
import com.scb.channels.paymentservice.ValidatePayeeRequest;
import com.scb.channels.paymentservice.ValidatePayeeResponse;

public class PaymentsServiceImpl implements Payments {

	@Override
	public GetCustomerOverallPaymentAmountResponse getCustomerOverallPaymentAmount(
			GetCustomerOverallPaymentAmountRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GetPayeeResponse getPayeeList(GetPayeeRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AddPayeeResponse addPayee(AddPayeeRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BillPresentmentResponse getPresentment(
			BillPresentmentRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DeletePayeeResponse deletePayee(DeletePayeeRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentHistoryResponse getPaymentHistory(
			PaymentHistoryRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BillerNameBycategoryReponse getBillerDetails(
			BillerNameBycategoryRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BillerBycategoryResponse getBillerCategory(
			BillerBycategoryRequest parameters) {
		// TODO Auto-generated method stub
		return null;

	}

	@Override
	public JobServiceResponse jobService(JobServiceRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ValidatePayeeResponse validatePayee(ValidatePayeeRequest parameters) {
		// TODO Auto-generated method stub
		return null;
	}

}
