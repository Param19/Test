package com.scb.channel.processor.impl;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.xml.datatype.DatatypeConstants;

import org.apache.camel.Exchange;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.AxwayTokenValidationVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardInquiryResponseVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.StatusTypeVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.inward.CreditHistoryRequestType;
import com.scb.channels.inward.CreditHistoryResponseType;
import com.scb.channels.inward.InwardInquiryRequestType;
import com.scb.channels.inward.InwardPaymentRequestType;
import com.scb.channels.inward.InwardResponseType;
import com.scb.channels.inward.StatusType;
import com.scb.channels.mapper.helper.InwardMappingHelper;


/**
 * The Class InwardCreditPaymentProcessor.
 *
 * @author 1493439
 */
public class InwardCreditPaymentProcessor {
	
	/** The reference service. */
	public ReferenceService referenceService;
	
	/** The data bean. */
	private DataBean dataBean;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang
	 * .Object)
	 */
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(InwardCreditPaymentProcessor.class);

	/**
	 * Sets the context data.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 */
	public PayloadDTO setContextData(PayloadDTO payloadDTO){
		
		LOGGER.info("InwardCreditPaymentProcessor setContextData method start:::");
		Object object = payloadDTO.getRequestVO();
		InwardPaymentRequestVO inwardPaymentRequestVO = null;
		InwardInquiryRequestVO inwardInquiryRequestVO = null;
		
		MessageVO messageVO = new MessageVO();
		
		UserVO userVO = new UserVO();
		userVO.setChannelId(CommonConstants.I_BANKING);
		ClientVO clientVO = new ClientVO();
		ServiceVO serviceVO = new ServiceVO();
		
		if(object instanceof InwardPaymentRequestVO){
			
			inwardPaymentRequestVO = (InwardPaymentRequestVO)object;
			LOGGER.info("InwardCreditPaymentProcessor setContextData method object instanceof InwardPaymentRequestVO:::"+inwardPaymentRequestVO.getReferenceNumber());
			messageVO.setRequestCode(inwardPaymentRequestVO.getReferenceNumber());
			userVO.setCountry(inwardPaymentRequestVO.getClientInfoVO().getCountry());
			clientVO.setClientId(inwardPaymentRequestVO.getInwardTransactionInfoVO().getMerchantReceiptNumber());
			inwardPaymentRequestVO.setUser(userVO);;
			inwardPaymentRequestVO.setClientVO(clientVO);
			inwardPaymentRequestVO.setServiceVO(serviceVO);
			inwardPaymentRequestVO.setMessageVO(messageVO);
			payloadDTO.setRequestVO(inwardPaymentRequestVO);
			LOGGER.info("InwardCreditPaymentProcessor setContextData method object instanceof InwardPaymentRequestVO end:::"+payloadDTO);
		} else if(object instanceof InwardInquiryRequestVO){
			inwardInquiryRequestVO = (InwardInquiryRequestVO)object;
			LOGGER.info("InwardCreditPaymentProcessor setContextData method object instanceof InwardInquiryRequestVO:::"+inwardInquiryRequestVO.getReferenceNumber());
			messageVO.setRequestCode(inwardInquiryRequestVO.getReferenceNumber());
			userVO.setCountry(inwardInquiryRequestVO.getClientInfoVO().getCountry());
			clientVO.setClientId(inwardInquiryRequestVO.getReferenceNumber());
			inwardInquiryRequestVO.setUser(userVO);
			inwardInquiryRequestVO.setClientVO(clientVO);
			inwardInquiryRequestVO.setServiceVO(serviceVO);
			inwardInquiryRequestVO.setMessageVO(messageVO);
			payloadDTO.setRequestVO(inwardInquiryRequestVO);
			LOGGER.info("InwardCreditPaymentProcessor setContextData method object instanceof InwardInquiryRequestVO end:::"+payloadDTO);
		}
		LOGGER.info("InwardCreditPaymentProcessor setContextData method end:::"+payloadDTO);
		return payloadDTO;
	}
	
	/**
	 * Generate random.
	 *
	 * @return the string
	 */
	public static String generateRandom(){
		
		Random random = new Random();
		return new BigInteger(35, random).toString(32);
	}
	
	/**
	 * Currency and decimal check.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return true, if successful
	 */
	public String currencyCheck(InwardPaymentRequestVO inwardPaymentRequestVO){
		LOGGER.info("InwardCreditPaymentProcessor currencyCheck start:::"+inwardPaymentRequestVO.getReferenceNumber());
		String flag = "CUFAIL" ;
		
		List<ISOCODESVO> isocodesvos = referenceService.getCurrency(inwardPaymentRequestVO.getClientInfoVO().getCountry());
		
		if(isocodesvos != null && isocodesvos.size()>0){
			LOGGER.info("InwardCreditPaymentProcessor currencyCheck isocodesvos:::"+isocodesvos);
			for(ISOCODESVO isocodesvo : isocodesvos){
				if(isocodesvo.getCurrencycode_char().equalsIgnoreCase(inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency())){
					LOGGER.info("InwardCreditPaymentProcessor currencyCheck isocodesvos currency check:::"+isocodesvos);
					flag = "SUCCESS";
					break;
				}
			}
		} else {
			flag = "COFAIL";
		}

		LOGGER.info("InwardCreditPaymentProcessor currencyCheck end:::"+inwardPaymentRequestVO.getReferenceNumber());
		return flag;
	}
	
	
	public boolean decimalCheck(String decimalNotAllowCountries, String country, double amount){
		
		boolean flag= false;
		
		if(decimalNotAllowCountries != null){
			decimalNotAllowCountries = decimalNotAllowCountries.trim();
			String[] decimalNotAllows = decimalNotAllowCountries.split(",");
			LOGGER.info("InwardPaymentProcessor ValidateData if condition decimalNotAllowTokens:::: "+decimalNotAllows);
			ArrayList<String> arrayList = new ArrayList<String>();
			LOGGER.info("InwardPaymentProcessor ValidateData country.equalsIgnoreCase(country):::: "+country+" ::Amount:: "+amount);
			for(String decimalNotAllow :decimalNotAllows){
				arrayList.add(decimalNotAllow);
			}
			if(arrayList.contains(country)){
				if(amount%1 == 0){
					LOGGER.info("InwardPaymentProcessor ValidateData amount%1 start:::: "+flag);
					flag = true;
					LOGGER.info("InwardPaymentProcessor ValidateData amount%1 end:::: "+flag);
				}
			} else {
				LOGGER.info("InwardPaymentProcessor ValidateData country.equalsIgnoreCase(decimalCountry) else start:::: "+flag);
				flag = true;
				LOGGER.info("InwardPaymentProcessor ValidateData country.equalsIgnoreCase(decimalCountry) else end:::: "+flag);
			}
			
		}
		
		return flag;
		
	}
	
	/**
	 * Sets the inward inquiry request.
	 *
	 * @param inwardInquiryRequestType the inward inquiry request type
	 * @return the payload dto
	 */
	public PayloadDTO setInwardInquiryRequest(InwardInquiryRequestType inwardInquiryRequestType) {
		
		LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryRequest method start:::");
		String referenceNumber = inwardInquiryRequestType.getReferenceNumber();
		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryRequest method:::"+referenceNumber);
		InwardInquiryRequestVO inwardInquiryRequestVO = InwardMappingHelper.inwardInquiryRequest(inwardInquiryRequestType);
		DateFormat dateFormat = new SimpleDateFormat(CommonConstants.INWARD_TIMEFMT);
		Date date = new Date();
		String hostReferenceNumber = inwardInquiryRequestVO.getClientInfoVO().getCountry()+"-"+dateFormat.format(date)+"-"+generateRandom();
		LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryRequest method hostReference :::"+hostReferenceNumber+" ::Reference number:: "+referenceNumber);
		inwardInquiryRequestVO.setHostReferenceNumber(hostReferenceNumber);
		payloadDTO.setRequestVO(inwardInquiryRequestVO);
		payloadDTO = setContextData(payloadDTO);
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest end:::");
		return payloadDTO;
	}

	/**
	 * Sets the inward payment request.
	 *
	 * @param inwardPaymentRequestType the inward payment request type
	 * @return the payload dto
	 */
	public PayloadDTO setInwardPaymentRequest(InwardPaymentRequestType inwardPaymentRequestType) {
		
		if(inwardPaymentRequestType != null && inwardPaymentRequestType.getClientInfo() != null && inwardPaymentRequestType.getClientInfo().getDate()!= null){
			LOGGER.info("Setting the Timezone to undefined");
			inwardPaymentRequestType.getClientInfo().getDate().setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		}

		String referenceNumber = inwardPaymentRequestType.getReferenceNumber();
		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest method start:::");
		InwardPaymentRequestVO inwardPaymentRequestVO = InwardMappingHelper.inwardPaymentRequest(inwardPaymentRequestType);
		DateFormat dateFormat = new SimpleDateFormat(CommonConstants.INWARD_TIMEFMT);
		Date date = new Date();
		String hostReferenceNumber = inwardPaymentRequestVO.getClientInfoVO().getCountry()+"-"+dateFormat.format(date)+"-"+generateRandom();
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest method hostNumber :::"+hostReferenceNumber+" ::Reference Number::"+referenceNumber);
		String mobileNumber = inwardPaymentRequestType.getSenderInfo().getMobileNumber();
		String serviceProvider = inwardPaymentRequestType.getClientInfo().getServiceProvider();
		String country = inwardPaymentRequestType.getClientInfo().getCountry();
		String currency = inwardPaymentRequestType.getTransactionInfo().getCurrency();
		//serviceProvider = StringUtils.trim(serviceProvider);
		serviceProvider = StringUtils.isEmpty(serviceProvider) ? CommonConstants.EMPTY : StringUtils.upperCase(serviceProvider.trim());
		country = StringUtils.isEmpty(country) ? CommonConstants.EMPTY : StringUtils.upperCase(country.trim());
		currency = StringUtils.isEmpty(currency) ? CommonConstants.EMPTY : StringUtils.upperCase(currency.trim());
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest method serviceProvider :::"+serviceProvider+" ::Reference Number::"+referenceNumber+" ::country::"+country+" ::currency:: "+currency);
		inwardPaymentRequestVO.getClientInfoVO().setServiceProvider(serviceProvider);
		inwardPaymentRequestVO.getClientInfoVO().setCountry(country);
		inwardPaymentRequestVO.getInwardTransactionInfoVO().setCurrency(currency);
		
		if(StringUtils.isNotBlank(mobileNumber)){
			LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest method mobileNumber special chars remove :::"+referenceNumber);
			mobileNumber = StringUtils.trimToEmpty(StringUtils.replaceChars(mobileNumber, CommonConstants.SPECIAL_CHARACTERS, StringUtils.EMPTY));
			mobileNumber = StringUtils.stripStart(mobileNumber, CommonConstants.ZERO);
		}
		
		inwardPaymentRequestVO.getSenderInfoVO().setMobileNumber(mobileNumber);
		inwardPaymentRequestVO.setHostReferenceNumber(hostReferenceNumber);
		inwardPaymentRequestVO.setPaymentDate(inwardPaymentRequestType.getClientInfo().getDate());
		inwardPaymentRequestVO.setCreatedBy(CommonConstants.SYSTEM);
		inwardPaymentRequestVO.setCreatedTime(new Timestamp(date.getTime()));
		inwardPaymentRequestVO.setUpdatedBy(CommonConstants.SYSTEM);
		inwardPaymentRequestVO.setUpdatedTime(new Timestamp(date.getTime()));
		inwardPaymentRequestVO.setRetryCount(CommonConstants.ZERO);
		inwardPaymentRequestVO.setVersion(1);
		inwardPaymentRequestVO.setAggregator(inwardPaymentRequestVO.getClientInfoVO().getAggregator());
		inwardPaymentRequestVO.setPaymentStatus(CommonConstants.NEW);
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest method after all request set :::"+referenceNumber);
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		payloadDTO = setContextData(payloadDTO);

		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentRequest end:::");
		return payloadDTO;
	}
	
	/**
	 * Sets the inward inquiry response.
	 *
	 * @param payloadDTO the payload dto
	 * @param referenceNumber the reference number
	 * @return the inward inquiry response type
	 */
	public InwardResponseType setInwardInquiryResponse(PayloadDTO payloadDTO, String referenceNumber) {
		
		InwardInquiryResponseVO inwardInquiryResponseVO = (InwardInquiryResponseVO)payloadDTO.getResponseVO();
		LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryResponse method start:::");
		InwardResponseType inwardResponseType = InwardMappingHelper.inwardInquiryResponse(inwardInquiryResponseVO);
		LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryResponse method referenceNumber:::"+referenceNumber);
		if(inwardResponseType.getStatusType() != null){
			LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryResponse method inwardResponseType.getStatusType() if:::"+referenceNumber);
			inwardResponseType.getStatusType().setReferenceNumber(referenceNumber);
		} else {
			LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryResponse method inwardResponseType.getStatusType() else:::"+referenceNumber);
			StatusType statusType = new StatusType();
			statusType.setReferenceNumber(referenceNumber);
			statusType.setStatusCode(ExceptionMessages._503.getCode());
			statusType.setStatusCode(ExceptionMessages._503.getMessage());
			inwardResponseType.setStatusType(statusType);
		}
		LOGGER.info("InwardCreditPaymentProcessor setInwardInquiryResponse end:::");
		return inwardResponseType;
	}

	/**
	 * Sets the inward payment response.
	 *
	 * @param payloadDTO the payload dto
	 * @param referenceNumber the reference number
	 * @return the inward payment response type
	 */
	public InwardResponseType setInwardPaymentResponse(PayloadDTO payloadDTO, String referenceNumber) {

		InwardPaymentResponseVO inwardPaymentResponseVO = (InwardPaymentResponseVO) payloadDTO.getResponseVO(); 
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentResponse method start:::");
		InwardResponseType inwardResponseType = InwardMappingHelper.inwardPaymentResponse(inwardPaymentResponseVO);
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentResponse method:::"+referenceNumber);
		if(inwardResponseType.getStatusType() != null){
			LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentResponse method inwardResponseType.getStatusType() if :::"+referenceNumber);
			inwardResponseType.getStatusType().setReferenceNumber(referenceNumber);
		} else {
			LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentResponse method inwardResponseType.getStatusType() else :::"+referenceNumber);
			StatusType statusType = new StatusType();
			statusType.setReferenceNumber(referenceNumber);
			statusType.setStatusCode(ExceptionMessages._503.getCode());
			statusType.setStatusCode(ExceptionMessages._503.getMessage());
			inwardResponseType.setStatusType(statusType);
		}
		LOGGER.info("InwardCreditPaymentProcessor setInwardPaymentResponse end:::");
		return inwardResponseType;
	}

	
	/**
	 * Gets the axway token validation.
	 *
	 * @param axwayTokenJson the axway token json
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the axway token validation
	 * @throws JsonParseException the json parse exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public InwardPaymentRequestVO getAxwayPaymentTokenValidation(String axwayTokenJson, InwardPaymentRequestVO inwardPaymentRequestVO) throws JsonParseException, JsonMappingException, IOException {

		ObjectMapper objectMapper = new ObjectMapper();
		AxwayTokenValidationVO axwayTokenValidationVO = null;
		LOGGER.info(":::::::: InwardCreditPaymentProcessor AxwayTokenValidationVO Response ::::::::"+axwayTokenJson+" Reference Number::"+inwardPaymentRequestVO.getReferenceNumber());
		
		axwayTokenValidationVO = objectMapper.readValue(axwayTokenJson, AxwayTokenValidationVO.class);
		if(axwayTokenValidationVO.getAccountNumber().equalsIgnoreCase(inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber())){
			inwardPaymentRequestVO.setStatus("true");
			LOGGER.info(":::::::: InwardCreditPaymentProcessor AxwayTokenValidationVO AccountNumber check ::::::::"+axwayTokenJson+" Reference Number::"+inwardPaymentRequestVO.getReferenceNumber());
		} else {
			inwardPaymentRequestVO.setStatus("false");
			LOGGER.info(":::::::: InwardCreditPaymentProcessor AxwayTokenValidationVO AccountNumber check else ::::::::"+axwayTokenJson+" Reference Number::"+inwardPaymentRequestVO.getReferenceNumber());
		}
			
		LOGGER.info("InwardCreditPaymentProcessor AxwayTokenValidationVO Java Object :::::::::::: "+axwayTokenValidationVO);
		return inwardPaymentRequestVO;
	}
	
	/**
	 * Gets the axway inquiry token validation.
	 *
	 * @param axwayTokenJson the axway token json
	 * @param inwardInquiryRequestVO the inward inquiry request vo
	 * @return the axway inquiry token validation
	 * @throws JsonParseException the json parse exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public InwardInquiryRequestVO getAxwayInquiryTokenValidation(String axwayTokenJson, InwardInquiryRequestVO inwardInquiryRequestVO) throws JsonParseException, JsonMappingException, IOException {

		LOGGER.info(":::::::: InwardCreditPaymentProcessor getAxwayInquiryTokenValidation start ::::::::");
		/*ObjectMapper objectMapper = new ObjectMapper();
		AxwayTokenValidationVO axwayTokenValidationVO = axwayTokenValidationVO = objectMapper.readValue(axwayTokenJson, AxwayTokenValidationVO.class);*/
		LOGGER.info(":::::::: InwardCreditPaymentProcessor AxwayTokenValidationVO Response ::::::::"+axwayTokenJson+" Reference Number::"+inwardInquiryRequestVO.getReferenceNumber());
		inwardInquiryRequestVO.setStatus("true");
		//LOGGER.info("InwardCreditPaymentProcessor AxwayTokenValidationVO Java Object :::::::::::: "+axwayTokenValidationVO);
		LOGGER.info(":::::::: InwardCreditPaymentProcessor getAxwayInquiryTokenValidation end ::::::::");
		
		return inwardInquiryRequestVO;
	} 
	
	/**
	 * Sets the inward payment request after axway.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the payload dto
	 */
	public PayloadDTO settingInwardPaymentRequest(InwardPaymentRequestVO inwardPaymentRequestVO){
		LOGGER.info(":::::::: InwardCreditPaymentProcessor settingInwardPaymentRequest start::::::::");
		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info(":::::::: InwardCreditPaymentProcessor settingInwardPaymentRequest referenceNumber::::::::"+inwardPaymentRequestVO.getReferenceNumber());
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		LOGGER.info(":::::::: InwardCreditPaymentProcessor settingInwardPaymentRequest end::::::::");
		return payloadDTO;
	}
	
	/**
	 * Sets the credit history request.
	 *
	 * @param creditHistoryRequest the credit history request
	 * @return the payload dto
	 */
	public PayloadDTO setCreditHistoryRequest(CreditHistoryRequestType creditHistoryRequest) {
		LOGGER.info("InwardCreditPaymentProcessor :: setCreditHistoryRequest :: Start");
		PayloadDTO payload = new PayloadDTO();
		InwardInquiryRequestVO inwardInquiryRequestVO = InwardMappingHelper.getCreditHistoryRequest(creditHistoryRequest);
		
		MessageVO messageVO = new MessageVO();
		UserVO userVO = new UserVO();
		userVO.setChannelId(CommonConstants.I_BANKING);
		ClientVO clientVO = new ClientVO();
		ServiceVO serviceVO = null;
		if(inwardInquiryRequestVO.getServiceVO()==null){
			serviceVO = new ServiceVO();
		}
			
		LOGGER.info("InwardCreditPaymentProcessor setContextData method object instanceof InwardPaymentRequestVO:::"+inwardInquiryRequestVO.getReferenceNumber());
		messageVO.setRequestCode(inwardInquiryRequestVO.getReferenceNumber());
		userVO.setCountry(inwardInquiryRequestVO.getClientInfoVO().getCountry());
		clientVO.setClientId(inwardInquiryRequestVO.getReferenceNumber());
		inwardInquiryRequestVO.setUser(userVO);;
		inwardInquiryRequestVO.setClientVO(clientVO);
		if(inwardInquiryRequestVO.getServiceVO()==null){
			inwardInquiryRequestVO.setServiceVO(serviceVO);
		}
		inwardInquiryRequestVO.setMessageVO(messageVO);
		payload.setRequestVO(inwardInquiryRequestVO);
		LOGGER.info("InwardCreditPaymentProcessor setContextData method object instanceof InwardPaymentRequestVO end:::"+payload);
		LOGGER.info("InwardCreditPaymentProcessor :: setCreditHistoryRequest :: End");
		return payload;
	}
	
	/**
	 * Sets the credit history response.
	 *
	 * @param payload the payload
	 * @param referenceNumber the reference number
	 * @return the credit history response type
	 */
	public CreditHistoryResponseType setCreditHistoryResponse(PayloadDTO payload,String referenceNumber) {
		LOGGER.info("InwardCreditPaymentProcessor :: setCreditHistoryResponse :: Start");

		CreditHistoryResponseType creditHistoryResponseType = null;
		
		if(payload.getResponseVO() != null) {
			LOGGER.info("Credit history available :: ");
			creditHistoryResponseType = InwardMappingHelper.getCreditHistoryResponse(
					(InwardInquiryResponseVO) payload.getResponseVO());
			
			if(creditHistoryResponseType != null 
					&& creditHistoryResponseType.getCreditHistoryDetails() != null) {
				LOGGER.info("creditHistoryResponseType.getCreditHistoryDetails().size () :: " 
						+ creditHistoryResponseType.getCreditHistoryDetails().size());
			}
		}
		
		LOGGER.info("InwardCreditPaymentProcessor :: setCreditHistoryResponse :: End");
		return creditHistoryResponseType;
	}
	
	/**
	 * Sets the inward inquiry request after axway.
	 *
	 * @param inwardInquiryRequestVO the inward inquiry request vo
	 * @return the payload dto
	 */
	public PayloadDTO settingInwardInquiryRequest(InwardInquiryRequestVO inwardInquiryRequestVO){
		LOGGER.info(":::::::: InwardCreditPaymentProcessor settingInwardInquiryRequest start::::::::");
		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info(":::::::: InwardCreditPaymentProcessor settingInwardInquiryRequest referenceNumber::::::::"+inwardInquiryRequestVO.getReferenceNumber());
		payloadDTO.setRequestVO(inwardInquiryRequestVO);
		LOGGER.info(":::::::: InwardCreditPaymentProcessor settingInwardInquiryRequest end::::::::");
		return payloadDTO;
	}
	
	/**
	 * Sets the inward payment axway error.
	 *
	 * @param exchange the exchange
	 * @return the inward payment response type
	 */
	public InwardResponseType setInwardPaymentAxwayError(Exchange exchange){
		
		LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardPaymentAxwayError start::::::::");
		String axwayError = "ERROR";
		String referenceNo = (String)exchange.getProperty("referenceno");
		Object input = exchange.getIn().getBody();
		
		LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardPaymentAxwayError input::::::::"+input);
		if(input instanceof AxwayTokenValidationVO){
			LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardPaymentAxwayError input instanceof AxwayTokenValidationVO"+input+" Reference Number"+referenceNo);
			AxwayTokenValidationVO axwayTokenValidationVO = (AxwayTokenValidationVO)input; 
			axwayError = axwayTokenValidationVO.getResult();
		}
		
		Exception exception = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
		if(exception !=null){
			exception.printStackTrace();
		}
		LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardPaymentAxwayError start::::::::"+exception+" Reference Number::: "+referenceNo);
		InwardResponseType inwardResponseType = new InwardResponseType();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(ExceptionMessages._401.getCode());
		statusType.setStatusDesc(ExceptionMessages._401.getMessage()+" - "+axwayError);
		statusType.setReferenceNumber(referenceNo);
		/*HostResponseType hostResponseType = new HostResponseType();
		hostResponseType.setCode("201");
		hostResponseType.setDesc(axwayError);
		hostResponseType.setHostName("RPE");
		statusType.setHostResponseType(hostResponseType);*/
		inwardResponseType.setStatusType(statusType);
		
        LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardPaymentAxwayError end::::::::");
        return inwardResponseType;
	}
	
	/**
	 * Sets the inward inquiry axway error.
	 *
	 * @param exchange the exchange
	 * @return the inward inquiry response type
	 */
	public InwardResponseType setInwardInquiryAxwayError(Exchange exchange){
		
		LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardInquiryAxwayError start::::::::");
		String axwayError = "ERROR";
		String referenceNo = (String)exchange.getProperty("referenceno");
		Object input = exchange.getOut().getBody();
		
		if(input instanceof AxwayTokenValidationVO){
			LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardInquiryAxwayError input instanceof AxwayTokenValidationVO"+input+" Reference Number"+referenceNo);
			AxwayTokenValidationVO axwayTokenValidationVO = (AxwayTokenValidationVO)input; 
			axwayError = axwayTokenValidationVO.getResult();
		}
		
		Exception exception = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
		
		if(exception !=null){
			exception.printStackTrace();
		}
		
		LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardInquiryAxwayError start::::::::"+exception+" Reference Number"+referenceNo);
		InwardResponseType inwardResponseType = new InwardResponseType();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(ExceptionMessages._401.getCode());
		statusType.setStatusDesc(ExceptionMessages._401.getMessage()+" - "+axwayError);
		statusType.setReferenceNumber(referenceNo);
		LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardInquiryAxwayError axwayError::::::::"+axwayError);
		/*HostResponseType hostResponseType = new HostResponseType();
		hostResponseType.setCode("201");
		hostResponseType.setDesc(axwayError);
		hostResponseType.setHostName("RPE");
		statusType.setHostResponseType(hostResponseType);*/
		inwardResponseType.setStatusType(statusType);
		
        LOGGER.info(":::::::: InwardCreditPaymentProcessor setInwardInquiryAxwayError end::::::::");
        return inwardResponseType;
	}
	
	/**
	 * Axway token error.
	 *
	 * @param exchange the exchange
	 * @return the axway token validation vo
	 * @throws JsonParseException the json parse exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public AxwayTokenValidationVO axwayTokenError(Exchange exchange) throws JsonParseException, JsonMappingException, IOException {
		LOGGER.info(":::::::: InwardCreditPaymentProcessor axwayTokenError start::::::::");
		Exception exception = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
		LOGGER.info(":::::::: InwardCreditPaymentProcessor axwayTokenError start::::::::"+exception);
		String referenceNo = (String)exchange.getProperty("referenceno");
		exception.printStackTrace();
		AxwayTokenValidationVO axwayTokenValidationVO = new AxwayTokenValidationVO();
		ObjectMapper objectMapper = new ObjectMapper();
		if(exception instanceof HttpOperationFailedException){
			HttpOperationFailedException httpOperationFailedException = (HttpOperationFailedException)exception;
			String inputJson = httpOperationFailedException.getResponseBody();
			LOGGER.info(":::::::: InwardCreditPaymentProcessor axwayTokenError inputJson::::::::"+inputJson+" ::Reference Number:: "+referenceNo);
			axwayTokenValidationVO = objectMapper.readValue(inputJson, AxwayTokenValidationVO.class);
		} 
		LOGGER.info(":::::::: InwardCreditPaymentProcessor axwayTokenError axwayTokenValidationVO::::::::"+axwayTokenValidationVO+" ::Reference Number:: "+referenceNo);
		LOGGER.info(":::::::: InwardCreditPaymentProcessor axwayTokenError end::::::::");
		exchange.getOut().setBody(axwayTokenValidationVO);
		return axwayTokenValidationVO;
	}
	
	
	/**
	 * Validate data.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the payload dto
	 */
	public PayloadDTO ValidateData(InwardPaymentRequestVO inwardPaymentRequestVO){
		PayloadDTO payloadDTO = new PayloadDTO();
		InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
		LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData start::::::::");
		try {
			
			String country = inwardPaymentRequestVO.getClientInfoVO().getCountry();
			String decimalNotAllowCountries = dataBean.getMap().get("INWARD_DECIMAL_NOT_ALLOW_COUNTRIES");
			
			String currencyFlag = "";
			boolean decimalFlag = false;
			String referenceNumber = inwardPaymentRequestVO.getReferenceNumber();
			String accountNumber = inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber();
			String mobileNumber = inwardPaymentRequestVO.getSenderInfoVO().getMobileNumber();
			String currency = inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency();
			LOGGER.info(":::::::: InwardCreditPaymentProcessor amount::: "+inwardPaymentRequestVO.getInwardTransactionInfoVO().getAmount());
			double amount = Double.parseDouble(inwardPaymentRequestVO.getInwardTransactionInfoVO().getAmount());
			if(!currency.isEmpty()){
				currencyFlag = currencyCheck(inwardPaymentRequestVO);
			}
			
			if(amount > 0.0){
				decimalFlag = decimalCheck(decimalNotAllowCountries, country, amount);
			}
			
			LOGGER.info(":::::::: InwardCreditPaymentProcessor amount::: "+inwardPaymentRequestVO.getInwardTransactionInfoVO().getAmount()+" ::Decimal Flag:: "+decimalFlag);
			
			LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData mobileNumbe:::::::: "+mobileNumber+" ::: currency-->"+currency+" ::: Amount-->"+amount+" Reference Number::: "+referenceNumber);
			if(StringUtils.isEmpty(mobileNumber) || StringUtils.isEmpty(currency) || amount <= 0.0 || StringUtils.isEmpty(accountNumber) || StringUtils.isEmpty(country) || StringUtils.isEmpty(referenceNumber)){
				LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData if start:::::::: "+referenceNumber);
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._400.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._400.getMessage());
				/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setHostName("RPE");
				statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);*/
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentResponseVO.setStatus(ExceptionMessages._400.getCode());
				LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData if end:::::::: "+referenceNumber);
				
			} else if(!accountNumber.matches(CommonConstants.INWARD_MOBILE_FMT)){
				
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._400.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._400.getMessage());
				/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setHostName("RPE");
				statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);*/
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentResponseVO.setStatus(ExceptionMessages._400.getCode());
				LOGGER.info(":::::::: InwardCreditPaymentProcessor accountNumber.matches:::::::: "+referenceNumber);
				
			} else if(!decimalFlag){
				
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._453.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._453.getMessage());
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentResponseVO.setStatus(ExceptionMessages._453.getCode());
				LOGGER.info(":::::::: InwardCreditPaymentProcessor decimalFlag:::::::: "+referenceNumber);
				
			} else if(currencyFlag.equalsIgnoreCase("CUFAIL")){
				
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._454.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._454.getMessage());
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentResponseVO.setStatus(ExceptionMessages._454.getCode());
				LOGGER.info(":::::::: InwardCreditPaymentProcessor currencyFlag:::::::: "+referenceNumber);
			
			} else if(currencyFlag.equalsIgnoreCase("COFAIL")){
				
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._456.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._456.getMessage());
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentResponseVO.setStatus(ExceptionMessages._456.getCode());
				LOGGER.info(":::::::: InwardCreditPaymentProcessor currencyFlag:::::::: "+referenceNumber);
			} else {
				
				inwardPaymentResponseVO.setStatus(CommonConstants.THREE_ZEROES);
				LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData success else:::::::: "+referenceNumber);
			}
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData exception::::::::"+e);
			StatusTypeVO statusTypeVO = new StatusTypeVO();
			statusTypeVO.setStatusCode(ExceptionMessages._400.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._400.getMessage());
			/*HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
			hostResponseTypeVO.setHostName("RPE");
			statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);*/
			inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
			inwardPaymentResponseVO.setStatus(ExceptionMessages._400.getCode());
			LOGGER.info(":::::::: InwardCreditPaymentProcessor ValidateData end::::::::");
			payloadDTO.setResponseVO(inwardPaymentResponseVO);
			return payloadDTO;
			
		}
		payloadDTO.setResponseVO(inwardPaymentResponseVO);
		return payloadDTO;
	}
	
	/**
	 * @return the referenceService
	 */
	public ReferenceService getReferenceService() {
		return referenceService;
	}

	/**
	 * @param referenceService the referenceService to set
	 */
	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	/**
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws JsonParseException the json parse exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
		/*String input = "{\"clientID\": \"craft_silicon_stg\",\"nonce\" : \"5176054397714517970\",\"timestamp\": \"1493101670534\"}";
		ObjectMapper mapper = new ObjectMapper();
		AxwayTokenValidationVO axwayTokenValidationVO = mapper.readValue(input, AxwayTokenValidationVO.class);
		System.out.println(axwayTokenValidationVO);*/
		
		/*DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String hostReferenceNumber = "GH"+"-"+dateFormat.format(date)+"-"+generateRandom();
		System.out.println("InwardCreditPaymentProcessor setInwardInquiryRequest method hostReference :::"+hostReferenceNumber);*/
		
		/*String no = "0+a-bc+";
	
		String SPECIAL_CHARACTERS = "~`!#@$%^&*()_}-{:.>; <?\\]+|[/,='\"";
		String m = StringUtils.trimToEmpty(StringUtils.replaceChars(no, SPECIAL_CHARACTERS, StringUtils.EMPTY));
		m = StringUtils.stripStart(m, "0");*/
	
		/*String m =" MMM ";
		String s = StringUtils.trim(m);
		s = s+"C";
		System.out.println(s);
		;*/
		/*double d = 20.9;
		System.out.println(d%1);
		
		if(d%1 == 0){
			System.out.println("succes");
		}*/
		String country = "G";
		String decimalNotAllowCountries = "UG,PG,MG";
		String[] m = decimalNotAllowCountries.split(",");
		ArrayList arrayList = new ArrayList();
		for(String s:m){
			
			arrayList.add(s);
		}
		System.out.println(arrayList.contains(country));
		
	}


}
