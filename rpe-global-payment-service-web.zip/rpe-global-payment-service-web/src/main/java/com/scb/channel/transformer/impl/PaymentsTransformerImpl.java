package com.scb.channel.transformer.impl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.scb.channel.transformer.PaymentsTransformer;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.common.transformers.TransformerException;
import com.scb.channels.paymentservice.PaymentRequest;

/**
 * The Class SCBMLPaymentResponseTransformer.
 */
public class PaymentsTransformerImpl implements PaymentsTransformer {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentsTransformerImpl.class);
	
	/**
	 * Transform.
	 * 
	 * @param paymentRequestXML
	 *            the request xml from the channel
	 * @return the payment request object
	 * @throws TransformerException
	 *             the transformer exception
	 * @see com.scb.channels.transformers.Transformer#transform(java.lang.Object)
	 */
	public PaymentRequest doTransform(String paymentRequestXML) throws TransformerException  {
		PaymentRequest paymentRequest = null;
		try {
			Unmarshaller unmarshaller =  CommonHelper.getUnMarshaller(PaymentRequest.class);			
			SAXSource ss = CommonHelper.getParser(paymentRequestXML);
			LOGGER.info("Topic response:{}",new Object[]{paymentRequestXML});
			
			JAXBElement<PaymentRequest> root = unmarshaller.unmarshal(ss, PaymentRequest.class);
			paymentRequest = root.getValue();
			
		} catch (JAXBException e) {
			LOGGER.error(e.getMessage());
			throw new TransformerException(e.getMessage(), e.getCause());
		} catch (SAXException e) {
			LOGGER.error(e.getMessage());
			throw new TransformerException(e.getMessage(), e.getCause());
		}
		return paymentRequest;
	}

}
