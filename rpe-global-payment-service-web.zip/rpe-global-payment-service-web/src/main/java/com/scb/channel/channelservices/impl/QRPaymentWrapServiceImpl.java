package com.scb.channel.channelservices.impl;

import javax.xml.datatype.DatatypeConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.mapper.helper.QRPaymentMappingHelper;
import com.scb.channels.qrpayments.QrPaymentHistoryRequestType;
import com.scb.channels.qrpayments.QrPaymentRequestType;

public class QRPaymentWrapServiceImpl {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentWrapServiceImpl.class);
	
	public PayloadDTO doQRPayment(QrPaymentRequestType qrPaymentRequest){
		PayloadDTO payloadDTO = new PayloadDTO();
		if(qrPaymentRequest != null && qrPaymentRequest.getQRPaymentInfo().getPaymentDate() != null){
			LOGGER.info("Setting the Timezone to undefined");
			qrPaymentRequest.getQRPaymentInfo().getPaymentDate().setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		}
		QRPaymentRequestVO qrPaymentRequestVO = QRPaymentMappingHelper.getQRPaymentRequestVOMapping(qrPaymentRequest);
		payloadDTO.setRequestVO(qrPaymentRequestVO);
		return payloadDTO;
		
	}
	
	public PayloadDTO getQRPaymentHistory(QrPaymentHistoryRequestType qrPaymentHistoryRequestType){
		PayloadDTO payloadDTO = new PayloadDTO();
		QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO = QRPaymentMappingHelper.getQRPaymentHistoryRequestVOMapping(qrPaymentHistoryRequestType);
		qrPaymentHistoryRequestVO.getServiceVO().setServiceName(CommonConstants.PAYMENT_HISTORY);
		qrPaymentHistoryRequestVO.getServiceVO().setServiceTxnType(CommonConstants.VIEW);
		qrPaymentHistoryRequestVO.getClientVO().setVersion(CommonConstants.ONE);
		payloadDTO.setRequestVO(qrPaymentHistoryRequestVO);
		return payloadDTO;
		
	}

}
