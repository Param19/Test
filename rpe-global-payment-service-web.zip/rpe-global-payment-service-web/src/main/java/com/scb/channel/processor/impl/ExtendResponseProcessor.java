package com.scb.channel.processor.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.jms.receiver.ResponseReceiver;

/**
 * The Class BeneficiaryResponseProcessor.
 */
public class ExtendResponseProcessor {

	private ResponseReceiver extendReceiver;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ExtendResponseProcessor.class);
	/**
	 * 
	 * @param dto PayloadDTO
	 */
	public PayloadDTO process(PayloadDTO dto) {
		LOGGER.debug("Inside ExtendResponseProcessor class ");  
		if (null != dto.getRequestVO().getMessageVO().getReqID()){
			PayloadDTO response = extendReceiver.receiveMessage(dto.getRequestVO().getMessageVO().getReqID());
			if (response !=null) {
				return response;
			} else {
				PayloadDTO responseVO = CommonHelper.getResponseInstance(dto);
				dto.getResponseVO().setClientVO(dto.getRequestVO().getClientVO());
				dto.getResponseVO().setMessageVO(dto.getRequestVO().getMessageVO());
				dto.getResponseVO().setServiceVO(dto.getRequestVO().getServiceVO());
				dto.getResponseVO().setUser(dto.getRequestVO().getUser());
				dto.getResponseVO().setStatus(ExceptionMessages._109.getCode());
				dto.getResponseVO().setStatusDesc(ExceptionMessages._109.getMessage());
				return responseVO;
			}
		}
		return dto;
	}

	public void setExtendReceiver(ResponseReceiver extendReceiver) {
		this.extendReceiver = extendReceiver;
	}

	
}
