package com.scb.channel.processor.impl;

import com.scb.channels.base.vo.AccountListResponseVO;
import com.scb.channels.base.vo.BeneficiaryResponseVO;
import com.scb.channels.base.vo.BillerListResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ProductDetailsRequestVO;

/**
 * The Class ProductDetailsProcessor.
 */
public class ProductDetailsProcessor {

	/**
	 * Process beneficiary.
	 *
	 * @param payloadDTO the payload dto
	 * @return the beneficiary request vo
	 */
	public PayloadDTO processBeneficiary(PayloadDTO payloadDTO) {
		PayloadDTO payloadDTONew = new PayloadDTO();
		payloadDTONew.setRequestVO(((ProductDetailsRequestVO)payloadDTO.getRequestVO()).getBeneficiaryRequestVO());
		payloadDTONew.getRequestVO().getMessageVO().setRequestCode(payloadDTO.getRequestVO().getMessageVO().getRequestCode());
		return payloadDTONew;
	}
	
	/**
	 * Process biller.
	 *
	 * @param payloadDTO the payload dto
	 * @return the biller list request vo
	 */
	public PayloadDTO processBiller(PayloadDTO payloadDTO) {
		PayloadDTO payloadDTONew = new PayloadDTO();
		payloadDTONew.setRequestVO( ((ProductDetailsRequestVO)payloadDTO.getRequestVO()).getBillerListRequestVO());
		payloadDTONew.getRequestVO().getMessageVO().setRequestCode(payloadDTO.getRequestVO().getMessageVO().getRequestCode());
		return payloadDTONew;
	}
	
	/**
	 * Process account list .
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 */
	public PayloadDTO processAccountList(PayloadDTO payloadDTO) {
		PayloadDTO payloadDTONew = new PayloadDTO();
		payloadDTONew.setRequestVO( ((ProductDetailsRequestVO)payloadDTO.getRequestVO()).getAccountListRequestVO());
		payloadDTONew.getRequestVO().getMessageVO().setRequestCode(payloadDTO.getRequestVO().getMessageVO().getRequestCode());
		return payloadDTONew;
	}
	
	/**
	 * Process beneficiary response.
	 *
	 * @param payloadDTO the payload dto
	 * @return the beneficiary response vo
	 */
	public BeneficiaryResponseVO processBeneficiaryResponse(PayloadDTO payloadDTO) {
		return ((BeneficiaryResponseVO)payloadDTO.getResponseVO());
	}
	
	/**
	 * Process biller response.
	 *
	 * @param payloadDTO the payload dto
	 * @return the biller list response vo
	 */
	public BillerListResponseVO processBillerResponse(PayloadDTO payloadDTO) {
		return ((BillerListResponseVO)payloadDTO.getResponseVO());
	}
	
	/**
	 * Process account list response.
	 *
	 * @param payloadDTO the payload dto
	 * @return the account list response vo
	 */
	public AccountListResponseVO processAccountListResponse(PayloadDTO payloadDTO) {
		return ((AccountListResponseVO)payloadDTO.getResponseVO());
	}
}
