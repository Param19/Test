package com.scb.channel.channelservices.impl;


import java.util.Map;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.vo.ClientContextApiVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentApiRequestVO;
import com.scb.channels.base.vo.QRPaymentInfoApiVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserContextApiVO;
import com.scb.channels.mapper.helper.QRPaymentMappingHelper;

public class QRPaymentWrapRestServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentWrapRestServiceImpl.class);

	public PayloadDTO doQRRestPayment(QRPaymentApiRequestVO qrPaymentApiRequest, Exchange camelExchange){
		PayloadDTO payloadDTO = new PayloadDTO();
		ObjectMapper mapper = new ObjectMapper();
		UserContextApiVO userContextVO=null;
		ClientContextApiVO clientContextVO=null;
		try {	
			LOGGER.info("::::doQRRestPayment:::start:");
			Map<String, Object> headers = (Map<String, Object>) camelExchange.getIn().getHeaders();
			LOGGER.info("::::headers:::"+headers);
			String jsonRPEHeader = (String)headers.get("RPE_HEADER");
			LOGGER.info("::::jsonRPEHeader:::"+jsonRPEHeader);
			if(jsonRPEHeader!=null && jsonRPEHeader!=""){
				JsonNode rootNode =(JsonNode)mapper.readTree(jsonRPEHeader);
				
				JsonNode userNode =(JsonNode)rootNode.get("userContext");
				if(userNode!=null){
					String jsonUserString = userNode.toString();				
					userContextVO=mapper.readValue(jsonUserString.getBytes(), UserContextApiVO.class);
				}
				
				JsonNode clientNode =(JsonNode)rootNode.get("clientContext");
				if(clientNode!=null){
					String jsonClientString = clientNode.toString();				
					clientContextVO=mapper.readValue(jsonClientString.getBytes(), ClientContextApiVO.class);
				}				
			}
			LOGGER.info("::::userContextVO:::"+userContextVO+"    clientContextVO:::::::::"+clientContextVO);
			qrPaymentApiRequest.setUserContext(userContextVO);
			qrPaymentApiRequest.setClientContext(clientContextVO);
			LOGGER.info("::::qrPaymentApiRequest::::"+qrPaymentApiRequest);
			
			if(qrPaymentApiRequest != null && qrPaymentApiRequest.getQrPaymentInfo().getPaymentDate() != null){
				String paymentDate=qrPaymentApiRequest.getQrPaymentInfo().getPaymentDate();
				qrPaymentApiRequest.getQrPaymentInfo().setPaymentDateTS(DatatypeFactory.newInstance().newXMLGregorianCalendar(paymentDate));
				qrPaymentApiRequest.getQrPaymentInfo().getPaymentDateTS().setTimezone(DatatypeConstants.FIELD_UNDEFINED);
			}
			
			QRPaymentRequestVO qrPaymentRequestVO = QRPaymentMappingHelper.getQRPaymentRequestRestVOMapping(qrPaymentApiRequest);
			payloadDTO.setRequestVO(qrPaymentRequestVO);
			LOGGER.info("::::qrPaymentRequestVO::::"+qrPaymentRequestVO);
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}	
		return payloadDTO;
	}
	
	public PayloadDTO getQRRestPaymentStatus(String transactionRefNumber, Exchange camelExchange) {
		PayloadDTO payloadDTO = new PayloadDTO();
		ObjectMapper mapper = new ObjectMapper();
		UserContextApiVO userContextVO=null;
		ClientContextApiVO clientContextVO=null;
		QRPaymentApiRequestVO qrPaymentApiRequest = new QRPaymentApiRequestVO();
		QRPaymentInfoApiVO qrPaymentInfo = new QRPaymentInfoApiVO();
		ServiceVO serviceVO = new ServiceVO();
		MessageVO messageVO = new MessageVO();
		try {
			LOGGER.info("::::getQRRestPaymentStatus:::start:");
			Map<String, Object> headers = (Map<String, Object>) camelExchange.getIn().getHeaders();
			String jsonCslHeader = (String)headers.get("RPE_HEADER");
			if(jsonCslHeader!=null && jsonCslHeader!=""){
				JsonNode rootNode =(JsonNode)mapper.readTree(jsonCslHeader);
				
				JsonNode userNode =(JsonNode)rootNode.get("userContext");
				if(userNode!=null){
					String jsonUserString = userNode.toString();				
					userContextVO=mapper.readValue(jsonUserString.getBytes(), UserContextApiVO.class);
				}
				
				JsonNode clientNode =(JsonNode)rootNode.get("clientContext");
				if(clientNode!=null){
					String jsonClientString = clientNode.toString();				
					clientContextVO=mapper.readValue(jsonClientString.getBytes(), ClientContextApiVO.class);
				}				
			}
			
			qrPaymentApiRequest.setUserContext(userContextVO);
			qrPaymentApiRequest.setClientContext(clientContextVO);
			qrPaymentInfo.setTransactionReferenceNumber(transactionRefNumber);
			qrPaymentApiRequest.setQrPaymentInfo(qrPaymentInfo);
			LOGGER.info("::::qrPaymentApiRequest::::"+qrPaymentApiRequest);
			
			QRPaymentRequestVO qrPaymentRequestVO = QRPaymentMappingHelper.getQRPaymentRequestRestVOMapping(qrPaymentApiRequest);
			serviceVO.setServiceName("RPE-QRGetPaymentStatusService");
			qrPaymentRequestVO.setServiceVO(serviceVO);
			qrPaymentRequestVO.setMessageVO(messageVO);
			payloadDTO.setRequestVO(qrPaymentRequestVO);
			LOGGER.info("::::qrPaymentRequestVO::::"+qrPaymentRequestVO);
			
		
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}	
		return payloadDTO;
	}
	
}
