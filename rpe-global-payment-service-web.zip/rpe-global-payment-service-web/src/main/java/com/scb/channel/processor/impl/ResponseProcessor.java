package com.scb.channel.processor.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.jms.receiver.ResponseReceiver;

/**
 * The Class BeneficiaryResponseProcessor.
 */
public class ResponseProcessor {

	private ResponseReceiver receiver;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseProcessor.class);
	
	/**
	 * 
	 * @param dto PayloadDTO
	 */
	public PayloadDTO process(PayloadDTO dto) {
		LOGGER.debug("Inside ResponseProcessor class new 222 ");
		LOGGER.debug("Inside ResponseProcessor class getReqID "+dto.getRequestVO().getMessageVO().getReqID());  
		if (null != dto.getRequestVO().getMessageVO().getReqID()){
			LOGGER.debug(receiver + " receiver Inside ResponseProcessor class new dto.getRequestVO().getMessageVO().getReqID()  "+dto.getRequestVO().getMessageVO().getReqID());			
			PayloadDTO response = receiver.receiveMessage(dto.getRequestVO().getMessageVO().getReqID());
			LOGGER.debug("After Inside ResponseProcessor class response  "+dto.getRequestVO().getMessageVO().getReqID());			
			if (response !=null) {
				return response;
			} else {
				LOGGER.debug("Inside ResponseProcessor Response ! null --->  "+dto.getRequestVO().getMessageVO().getReqID());			
				PayloadDTO responseVO = CommonHelper.getResponseInstance(dto);
				dto.getResponseVO().setClientVO(dto.getRequestVO().getClientVO());
				dto.getResponseVO().setMessageVO(dto.getRequestVO().getMessageVO());
				dto.getResponseVO().setServiceVO(dto.getRequestVO().getServiceVO());
				dto.getResponseVO().setUser(dto.getRequestVO().getUser());
				dto.getResponseVO().setStatus(ExceptionMessages._109_1.getCode());
				dto.getResponseVO().setStatusDesc(ExceptionMessages._109_1.getMessage());
				LOGGER.debug("Inside ResponseProcessor  Final Response ! null --->  ");			
				return responseVO;
			}
		}
		return dto;
	}

	 
	public void setReceiver(ResponseReceiver receiver) {
		this.receiver = receiver;
	}
}
