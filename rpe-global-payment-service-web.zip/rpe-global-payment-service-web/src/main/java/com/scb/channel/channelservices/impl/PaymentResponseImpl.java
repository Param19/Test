package com.scb.channel.channelservices.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ChannelMasterVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentHistoryResponseVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.StatusType;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.paymentservice.AddPayeeRequest;
import com.scb.channels.paymentservice.AddPayeeResponse;
import com.scb.channels.paymentservice.BillerBycategoryRequest;
import com.scb.channels.paymentservice.BillerBycategoryResponse;
import com.scb.channels.paymentservice.BillerNameBycategoryReponse;
import com.scb.channels.paymentservice.BillerNameBycategoryRequest;
import com.scb.channels.paymentservice.DeletePayeeRequest;
import com.scb.channels.paymentservice.DeletePayeeResponse;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountRequest;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountResponse;
import com.scb.channels.paymentservice.GetPayeeRequest;
import com.scb.channels.paymentservice.GetPayeeResponse;
import com.scb.channels.paymentservice.JobServiceRequest;
import com.scb.channels.paymentservice.JobServiceResponse;
import com.scb.channels.paymentservice.PaymentHistoryRequest;
import com.scb.channels.paymentservice.PaymentHistoryResponse;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.PaymentResponse;
import com.scb.channels.paymentservice.ValidatePayeeRequest;
import com.scb.channels.paymentservice.ValidatePayeeResponse;

 /**
 * @author 1460693
 *The Class PaymentResponseImpl.
 */
public class PaymentResponseImpl {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentResponseImpl.class);
	
	/** The Constant LOGGER_PERF. */
	private static final Logger LOGGER_PERF = LoggerFactory.getLogger(CommonConstants.SERVICE_PERF_LOG);

	 
	
	/**
	 * Log performance.
	 *
	 * @param dto the dto
	 */
	private void logPerformance(PayloadDTO dto){
		if (dto != null && dto.getRequestVO()!= null) {
			MessageVO message = dto.getRequestVO().getMessageVO();
			if (message != null && message.getRequestInTime() != null) {
				message.setRequestOutTime(DateUtils.getCurrentDate());
				LOGGER_PERF.info("{},{},{},{}s",new Object[]{dto.getRequestVO().getServiceVO().getServiceName(),
					message.getRequestInTime(), message.getRequestOutTime(), ((message.getRequestOutTime().getTime()- message.getRequestInTime().getTime())/1000.0)});
			}
		}
	}
	
	/**
	 * Log performance.
	 *
	 * @param masterVO the master vo
	 * @param serviceName the service name
	 */
	private void logPerformance(ChannelMasterVO masterVO, String serviceName){
		Date date = DateUtils.getCurrentDate();
		LOGGER_PERF.info("{},{},{},{}",new Object[]{serviceName,
				masterVO.getDate(), date, ((date.getTime()- masterVO.getDate().getTime())/1000.0)});
	}
	
	 
	/**
	 * @param dto
	 * @return
	 */
	public AddPayeeResponse addPayee(PayloadDTO dto,AddPayeeRequest request) {
		AddPayeeResponse response=null;
		BillerPayResponseVO responseVO = null;
		if(dto != null && dto.getResponseVO() instanceof BillerPayResponseVO){
			responseVO = (BillerPayResponseVO) dto.getResponseVO();
			response = BillpaymentMappingHelper.getAddPayeeResponseVOMapping(responseVO);
			LOGGER.debug("responseVO.getStatus {}",new Object[]{responseVO.getStatus()}) ;
			
			//Aggregator Failure
			
			
			if(response.getStatusInfo().getStatusCode().equals(CommonConstants.FAIL) || response.getStatusInfo().getStatusCode().equals(CommonConstants.FAILURE) )  {

				HostResponseType hostVo=new HostResponseType();
				hostVo.setHostName(CommonConstants.AGGREGATOR);
				hostVo.setCode(responseVO.getStatus());
				hostVo.setDesc(responseVO.getStatusDesc());
				
				StatusType statusType = new StatusType();
				statusType.setStatusCode(Messages._1.getCode());
				statusType.setStatusDesc(Messages._1.getMessage());
				statusType.getHostResponse().add(hostVo);	
				
				response.setStatusInfo(statusType);
			} else if (responseVO.getStatus().equals("0")) { //Success
				HostResponseType hostVo=new HostResponseType();
				hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				hostVo.setCode(responseVO.getStatus());
				hostVo.setDesc(responseVO.getStatusDesc());
				
				StatusType statusType = new StatusType();
				statusType.setStatusCode(Messages._0.getCode());
				statusType.setStatusDesc(Messages._0.getMessage());
				statusType.getHostResponse().add(hostVo);	
				response.setStatusInfo(statusType);
			} else { //failure
				HostResponseType hostVo=new HostResponseType();
				hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				hostVo.setCode(responseVO.getStatus());
				hostVo.setDesc(responseVO.getStatusDesc());
				
				StatusType statusType = new StatusType();
				statusType.setStatusCode(Messages._1.getCode());
				statusType.setStatusDesc(Messages._1.getMessage());
				statusType.getHostResponse().add(hostVo);	
				response.setStatusInfo(statusType);
			}
			
			
			 
		}else{
			
			response = new AddPayeeResponse();
			StatusType statusvalue = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._109.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._109.getMessage());
			statusvalue.setStatusCode(Messages._1.getCode());
			statusvalue.setStatusDesc(Messages._1.getMessage());
			statusvalue.getHostResponse().add(hostErrVo);
			response.setStatusInfo(statusvalue);
			
		}
		//logPerformance(dto);
		response.setClientContext(request.getClientContext());
		response.setMessageContext(request.getMessageContext());
		response.setServiceContext(request.getServiceContext());
		response.setUserContext(request.getUserContext());
		return response;
		}
		
	
	/**
	 * @param dto
	 * @return
	 */
	public DeletePayeeResponse deletePayee(PayloadDTO dto,DeletePayeeRequest request) {
		DeletePayeeResponse response=null;
		BillerPayResponseVO responseVO = null;
		try{
		if(dto != null && dto.getResponseVO() !=null){
			responseVO = (BillerPayResponseVO) dto.getResponseVO();
			response = BillpaymentMappingHelper.getDeletePayeeResponseVOMapping(responseVO);
			LOGGER.debug("responseVO.getStatus {}",new Object[]{responseVO.getStatus()});
			if(responseVO.getStatus().equalsIgnoreCase(Messages._1.getCode())){
				HostResponseType hostVo=new HostResponseType();
				StatusType statusvalue = new StatusType();
				statusvalue.setStatusCode(Messages._1.getCode());
				statusvalue.setStatusDesc(Messages._1.getMessage());
				hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				hostVo.setCode(responseVO.getErrorCD());
				hostVo.setDesc(responseVO.getErrorDesc());
				//response.getStatusInfo().getHostResponse().add(hostVo);
				statusvalue.getHostResponse().add(hostVo);
				response.setStatusInfo(statusvalue);
				
			}else
			{
			HostResponseType hostVo=new HostResponseType();
			StatusType statusvalue = new StatusType();
			statusvalue.setStatusCode(Messages._0.getCode());
			statusvalue.setStatusDesc(Messages._0.getMessage());
			hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostVo.setCode(responseVO.getStatus());
			hostVo.setDesc(responseVO.getStatusDesc());
			statusvalue.getHostResponse().add(hostVo);
			//response.getStatusInfo().getHostResponse().add(hostVo);
			response.setStatusInfo(statusvalue);
			}
			 
		}else{
			response = new DeletePayeeResponse();
			StatusType statusvalue = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._146.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._146.getMessage());
			statusvalue.setStatusCode(Messages._1.getCode());
			statusvalue.setStatusDesc(Messages._1.getMessage());
			statusvalue.getHostResponse().add(hostErrVo);
			response.setStatusInfo(statusvalue);
			
		}
		//logPerformance(dto);
		response.setClientContext(request.getClientContext());
		response.setMessageContext(request.getMessageContext());
		response.setServiceContext(request.getServiceContext());
		response.setUserContext(request.getUserContext());
		}catch(Exception e){
			
			////////HKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK
			LOGGER.error("---In PaymentResponseImpl ----- "+e.getMessage());
			
			response = new DeletePayeeResponse();
			StatusType statusvalue = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._146.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._146.getMessage());
			statusvalue.setStatusCode(Messages._1.getCode());
			statusvalue.setStatusDesc(Messages._1.getMessage());
			statusvalue.getHostResponse().add(hostErrVo);
			response.setStatusInfo(statusvalue);
			
		}
		return response;
		}
	
	public GetPayeeResponse getPayees(PayloadDTO dto,GetPayeeRequest request) {
		GetPayeeResponse response=null;
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try{
		if(dto != null && dto.getResponseVO() instanceof ViewPayeeResponseVO){
			viewPayeeResponseVO = (ViewPayeeResponseVO) dto.getResponseVO();
			response = BillpaymentMappingHelper.getViewPayeeResponseVOMapping(viewPayeeResponseVO);
			HostResponseType hostVo=new HostResponseType();
			hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostVo.setCode(viewPayeeResponseVO.getErrorCD());
			hostVo.setDesc(viewPayeeResponseVO.getErrorDesc());
			response.getStatusInfo().setStatusCode(Messages._0.getCode());
			response.getStatusInfo().setStatusDesc(Messages._0.getMessage());
			response.getStatusInfo().getHostResponse().add(hostVo);
		}else{
			response = new GetPayeeResponse();
			StatusType value = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._105.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._105.getMessage());
			value.setStatusCode(Messages._1.getCode());
			value.setStatusDesc(Messages._1.getMessage());
			value.getHostResponse().add(hostErrVo);
			response.setStatusInfo(value);
		}
	
		//logPerformance(dto);
		response.setClientContext(request.getClientContext());
		response.setMessageContext(request.getMessageContext());
		response.setServiceContext(request.getServiceContext());
		response.setUserContext(request.getUserContext());
		}catch(Exception e){
	////////HKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK
				LOGGER.error("---In PaymentResponseImpl --View Payee--- "+e.getMessage());
				
				response = new GetPayeeResponse();
				StatusType value = new StatusType();
				HostResponseType hostErrVo=new HostResponseType();
				hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				hostErrVo.setCode(ExceptionMessages._105.getErrorCode());
				hostErrVo.setDesc(ExceptionMessages._105.getMessage());
				value.setStatusCode(Messages._1.getCode());
				value.setStatusDesc(Messages._1.getMessage());
				value.getHostResponse().add(hostErrVo);
				response.setStatusInfo(value);
		}
		return response;
		}

	
	public BillerBycategoryResponse billercategory(PayloadDTO dto,BillerBycategoryRequest request) {
		BillerPayResponseVO response=null;
		BillerBycategoryResponse billerResponse=null;
		if(dto != null && dto.getResponseVO() instanceof BillerPayResponseVO){
			response=(BillerPayResponseVO)dto.getResponseVO();
			billerResponse=BillpaymentMappingHelper.getBillerCategories(response);
			HostResponseType hostVo=new HostResponseType();
			//hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostVo.setCode(response.getErrorCD());
			hostVo.setDesc(response.getErrorDesc());
			billerResponse.getStatusInfo().getHostResponse().add(hostVo);
			
		}else{
			
			billerResponse= new  BillerBycategoryResponse();
			StatusType statusvalue = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			//hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._105.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._105.getMessage());
			statusvalue.setStatusCode(Messages._1.getCode());
			statusvalue.setStatusDesc(Messages._1.getMessage());
			statusvalue.getHostResponse().add(hostErrVo);
			billerResponse.setStatusInfo(statusvalue);
			}
		
			
		billerResponse.setClientContext(request.getClientContext());
		billerResponse.setMessageContext(request.getMessageContext());
		billerResponse.setServiceContext(request.getServiceContext());
		billerResponse.setUserContext(request.getUserContext());
		
		//response.getStatusInfo().setRefrenceNumber(requestvO.getMessageVO().getReqID());
		
		return billerResponse;
	}
	
	public BillerNameBycategoryReponse billerNames(PayloadDTO dto,BillerNameBycategoryRequest request) {
		BillerPayResponseVO response=null;
		BillerNameBycategoryReponse billerResponse=null;
		if(dto != null && dto.getResponseVO() instanceof BillerPayResponseVO){
			response=(BillerPayResponseVO)dto.getResponseVO();
			billerResponse=BillpaymentMappingHelper.getBillerNamesResponseMapping(response);
			HostResponseType hostVo=new HostResponseType();
			//hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostVo.setCode(response.getErrorCD());
			hostVo.setDesc(response.getErrorDesc());
			billerResponse.getStatusInfo().getHostResponse().add(hostVo);
			
		}else{
			  billerResponse= new  BillerNameBycategoryReponse();
			  StatusType statusvalue = new StatusType();
				HostResponseType hostErrVo=new HostResponseType();
				//hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				hostErrVo.setCode(ExceptionMessages._109.getErrorCode());
				hostErrVo.setDesc(ExceptionMessages._109.getMessage());
				statusvalue.setStatusCode(Messages._1.getCode());
				statusvalue.setStatusDesc(Messages._1.getMessage());
				statusvalue.getHostResponse().add(hostErrVo);
				billerResponse.setStatusInfo(statusvalue);
			}
		
			
		billerResponse.setClientContext(request.getClientContext());
		billerResponse.setMessageContext(request.getMessageContext());
		billerResponse.setServiceContext(request.getServiceContext());
		billerResponse.setUserContext(request.getUserContext());
		
		//response.getStatusInfo().setRefrenceNumber(requestvO.getMessageVO().getReqID());
		
		return billerResponse;
	}
	
	


	public GetCustomerOverallPaymentAmountResponse getCustomerOverallPaymentAmount(PayloadDTO dto, GetCustomerOverallPaymentAmountRequest request) {
		GetCustomerOverallPaymentAmountResponse response = null;
		
		CustomerPaymentAmountResponseVO responseVO = null;
		
		if(dto != null && dto.getResponseVO() instanceof CustomerPaymentAmountResponseVO){
			responseVO = (CustomerPaymentAmountResponseVO) dto.getResponseVO();
			//response.setUserContext(requetsvO.getUser());
			
			response = BillpaymentMappingHelper.getCustomerOverallPaymentAmountResponseMapping(responseVO);
			LOGGER.info("responseVO.getStatus {}",new Object[]{responseVO.getStatus()}) ;
			 
		}else{
			response = new GetCustomerOverallPaymentAmountResponse();
			StatusType value = new StatusType();
			value.setStatusCode(Messages._1.getCode());
			value.setStatusDesc(Messages._1.getMessage());
			response.setStatusInfo(value);
		}
		response.setClientContext(request.getClientContext());
		response.setMessageContext(request.getMessageContext());
		response.setServiceContext(request.getServiceContext());
		response.setUserContext(request.getUserContext());
				
		logPerformance(dto);		
		return response;
	}
	 
	public PaymentHistoryResponse paymentHistResponseTransform(PayloadDTO dto,PaymentHistoryRequest request) {
		PaymentHistoryResponseVO response=null;
		PaymentHistoryResponse paymenyHistResponse=null;
		StatusType status = new StatusType();
		HostResponseType host=new HostResponseType();
		try{
			
			LOGGER.info("Entry Point At PaymentResponseImpl --> paymentHistResponseTransform -  convert  wsdl object ");
			if(dto != null && dto.getResponseVO() instanceof PaymentHistoryResponseVO){
				LOGGER.info("At paymentHistResponseTransform -  convert  wsdl object ");
				response=(PaymentHistoryResponseVO)dto.getResponseVO();
				paymenyHistResponse=BillpaymentMappingHelper.getPaymentHistoryResponse(response);
				host.setCode(Messages._150.getCode());
				host.setDesc(Messages._150.getMessage());
				host.setHostName(CommonConstants.SOURCE_SYSTEM);
				status.setStatusCode(Messages._0.getCode());
				status.setStatusDesc(Messages._0.getMessage());
			} else {
				paymenyHistResponse = new PaymentHistoryResponse();
				LOGGER.info("At paymentHistResponseTransform -  Empty Response convert  wsdl object ");
				status.setStatusCode(Messages._1.getCode());
				status.setStatusDesc(Messages._1.getMessage());
				host.setCode(Messages._1.getCode());
				host.setDesc(Messages._1.getMessage());
				host.setHostName(CommonConstants.SOURCE_SYSTEM);
				LOGGER.info("At paymentHistResponseTransform - Failure block --  empty payload  ");
			}
			status.getHostResponse().add(host);
			paymenyHistResponse.setClientContext(request.getClientContext());
			paymenyHistResponse.setMessageContext(request.getMessageContext());
			paymenyHistResponse.setServiceContext(request.getServiceContext());
			paymenyHistResponse.setUserContext(request.getUserContext());
			paymenyHistResponse.setStatusInfo(status);
			}catch(Exception e){
				LOGGER.error(" At paymentHistResponseTransform Error Block  --- "+e.getMessage());
				status.setStatusCode(Messages._1.getCode());
				status.setStatusDesc(Messages._1.getMessage());
				paymenyHistResponse.setStatusInfo(status);
			}
			return paymenyHistResponse;
	}
	
	public PaymentResponse respondPaybillSubmitted(PayloadDTO dto,PaymentRequest request) {
        LOGGER.info("PaymentResponseImpl --- respondPaybillSubmitted --0000- Start");
        System.out.println("PaymentResponseImpl --- respondPaybillSubmitted --- Start");
        
        HostResponseType hostResponse = new HostResponseType();
        PaymentResponse response = new PaymentResponse();
        StatusType status = new StatusType();
        try {
               if (dto != null && dto.getRequestVO() != null
                            && dto.getRequestVO() instanceof BillerPayRequestVO) {

                      BillerPayRequestVO billerRequest = (BillerPayRequestVO) dto.getRequestVO();
                      status.setRefrenceNumber(billerRequest.getBillerPayDetailsVO().getHostReference());
                      
                      if (dto.getRequestVO().getUser() != null
                                   && dto.getRequestVO().getServiceVO() != null
                                   && dto.getRequestVO().getClientVO() != null
                                   && dto.getRequestVO().getMessageVO() != null) {
                            LOGGER.info("Incoming request has details");
                            System.out.println("Incoming request has details");
                            
                            hostResponse.setCode(CommonConstants.ZERO);
                            hostResponse.setDesc(CommonConstants.SUBMITTED);
                             hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
                            
                            status.getHostResponse().add(hostResponse);
                            status.setStatusCode(CommonConstants.ZERO);
                            status.setStatusDesc(CommonConstants.SUCCESS);
                            
                      } else {
                            LOGGER.info("Incoming request is not complete");
                            System.out.println("Incoming request is not complete");
                            
                            hostResponse.setCode(CommonConstants.NEGATIVE);
                            hostResponse.setDesc(CommonConstants.FAILURE);
                             hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
                            
                            status.getHostResponse().add(hostResponse);
                            status.setStatusCode(CommonConstants.NEGATIVE);
                            status.setStatusDesc(CommonConstants.FAILURE);
                      }
                      
               } else {
                      LOGGER.info("Incoming request is not complete");
                      System.out.println("Incoming request is not complete");
                      
                      hostResponse.setCode(CommonConstants.NEGATIVE);
                      hostResponse.setDesc(CommonConstants.FAILURE);
                      hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
                      
                      status.getHostResponse().add(hostResponse);
                      status.setStatusCode(CommonConstants.NEGATIVE);
                      status.setStatusDesc("The Request is not complete. Missing context details.");
               }
               
               response.setStatus(status);
               response.setClientContext(request.getClientContext());
               response.setMessageContext(request.getMessageContext());
               response.setServiceContext(request.getServiceContext());
               response.setUserContext(request.getUserContext());
               
               LOGGER.info("Payment response generated for :::::: " + 
                            response.getMessageContext().getReqID());
               System.out.println("Payment response generated for :::::: " + 
                            response.getMessageContext().getReqID());
               
               LOGGER.info("PaymentResponseImpl --- respondPaybillSubmitted --- End");
               System.out.println("PaymentResponseImpl --- respondPaybillSubmitted --- End");
        }catch(Exception e){
               status.setStatusCode("-1");
               status.setStatusDesc(e.getMessage());
               LOGGER.error("Exception for Payment :::: " 
                            + request.getMessageContext().getReqID());
               System.out.println("Exception for Payment :::: " 
                            + request.getMessageContext().getReqID());
               LOGGER.error("Exception occurred while submitting Payment :::: " 
                            + e.getMessage());
               System.out.println("Exception occurred while submitting Payment :::: " 
                            + e.getMessage());
               System.err.println(e);
        }
        return response;
  }
	
	public JobServiceResponse respondBillerDownloadService(PayloadDTO dto) {
        LOGGER.info("PaymentResponseImpl --- respondBillerDownloadService --0000- Start");
        System.out.println("PaymentResponseImpl --- respondBillerDownloadService --- Start");
        
        HostResponseType hostResponse = new HostResponseType();
        JobServiceResponse response = new JobServiceResponse();
        StatusType status = new StatusType();
        try {
        	/*if (dto.getRequestVO().getUser() != null
					&& dto.getRequestVO().getServiceVO() != null
					&& dto.getRequestVO().getClientVO() != null
					&& dto.getRequestVO().getMessageVO() != null
					&& dto.getResponseVO().getStatus() != null
					&& dto.getResponseVO().getStatus()
							.equalsIgnoreCase(CommonConstants.SUCC)) {*/
				hostResponse.setCode(CommonConstants.ZERO);
				hostResponse.setDesc(CommonConstants.SUBMITTED);
				hostResponse
						.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				status.getHostResponse().add(hostResponse);
				status.setStatusCode(CommonConstants.ZERO);
				status.setStatusDesc(CommonConstants.SUCCESS);
			
        	/* }else {
                 LOGGER.info("Incoming request is not complete");
                 System.out.println("Incoming request is not complete");
                 
                 hostResponse.setCode(CommonConstants.NEGATIVE);
                 hostResponse.setDesc(CommonConstants.FAILURE);
                  hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
                 
                 status.getHostResponse().add(hostResponse);
                 status.setStatusCode(CommonConstants.NEGATIVE);
                 status.setStatusDesc(CommonConstants.FAILURE);
           }*/
        	 response.setStatusInfo(status);
           
    
               LOGGER.info("BillerDownloadServiceResponse response - Completed :::::: " );
               System.out.println("BillerDownloadServiceResponse response Completed:::::: ");
               
        }catch(Exception e){
               status.setStatusCode("-1");
               status.setStatusDesc(e.getMessage());
               LOGGER.error("Exception occurred while calling biller Download Service:::: " 
                            + e.getMessage());
               System.out.println("Exception occurred while biller Download Service:::: " 
                            + e.getMessage());
               System.err.println(e);
               response.setStatusInfo(status);
        }
        return response;
  }
	
	// Added for Biller Download Service status
	
	public JobServiceResponse billerDownloadStatusResponseTransform(PayloadDTO dto,JobServiceRequest request) {
		BillerDownloadResponseVO response = null;
		JobServiceResponse jobServiceResponse = null;

			StatusType status = new StatusType();
			HostResponseType host=new HostResponseType();
			try{
				
				if (dto.getRequestVO().getUser() != null
						&& dto.getRequestVO().getServiceVO() != null
						&& dto.getRequestVO().getClientVO() != null
						&& dto.getRequestVO().getMessageVO() != null
						&& dto.getResponseVO().getStatus() != null) {
				
				LOGGER.info("Entry Point At PaymentResponseImpl --> billerDownloadStatusResponseTransform -  convert  wsdl object ");
					LOGGER.info("At billerDownloadStatusResponseTransform -  convert  wsdl object ");
					response=(BillerDownloadResponseVO)dto.getResponseVO();
					jobServiceResponse=BillpaymentMappingHelper.getBillerDownloadStatusResponse(response);
					/*host.setCode(Messages._0.getCode());
					host.setDesc(Messages._0.getMessage());
					host.setHostName(CommonConstants.SOURCE_SYSTEM);*/
					
					if(jobServiceResponse != null && jobServiceResponse.getStatusInfo().getStatusCode() != null
						&& jobServiceResponse.getStatusInfo().getStatusCode().equalsIgnoreCase("BILLER_DOWNLOAD_COMPLETED")){
					status.setStatusCode(Messages._0.getCode());
					status.setStatusDesc(jobServiceResponse.getStatusInfo().getStatusCode());
					}
					
					if(jobServiceResponse != null && jobServiceResponse.getStatusInfo().getStatusCode() != null
							&& jobServiceResponse.getStatusInfo().getStatusCode().equalsIgnoreCase("BILLER_DOWNLOAD_IN_PROGRESS")){
					status.setStatusCode(Messages._11.getCode());
					status.setStatusDesc(jobServiceResponse.getStatusInfo().getStatusCode());
					}
				}
				
				else {
					jobServiceResponse = new JobServiceResponse();
					LOGGER.info("Incoming request is not complete for Biller Download Status Service");
					System.out.println("Incoming request is not complete for Biller Download Status Service");
					
					status.setStatusCode(CommonConstants.NEGATIVE);
					status.setStatusDesc(CommonConstants.FAILURE);
				}
					
				//status.getHostResponse().add(host);
				jobServiceResponse.setClientContext(request.getClientContext());
				jobServiceResponse.setMessageContext(request.getMessageContext());
				jobServiceResponse.setServiceContext(request.getServiceContext());
				jobServiceResponse.setUserContext(request.getUserContext());
				jobServiceResponse.setStatusInfo(status);
				
				}catch(Exception e){
					LOGGER.error(" At billerDownloadStatusResponseTransform Error Block  --- "+e.getMessage());
					status.setStatusCode(Messages._1.getCode());
					status.setStatusDesc(Messages._1.getMessage());
					jobServiceResponse.setStatusInfo(status);
				}
				return jobServiceResponse;
		}
	
	
	// Added for Job Service
	
			public JobServiceResponse jobServiceResponseTransform(PayloadDTO dto) {
				
		        LOGGER.info("PaymentResponseImpl --- respondJobService --0000- Start");
		        System.out.println("PaymentResponseImpl --- JobServiceResponse --- Start");
		        
		        HostResponseType hostResponse = new HostResponseType();
		        JobServiceResponse response = new JobServiceResponse();
		        StatusType status = new StatusType();
		        try {

						hostResponse.setCode(CommonConstants.ZERO);
						hostResponse.setDesc(CommonConstants.SUBMITTED);
						hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
						status.getHostResponse().add(hostResponse);
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.SUCCESS);

		        	 response.setStatusInfo(status);
		    
		               LOGGER.info("JobServiceResponse response - Completed :::::: " );
		               System.out.println("JobServiceResponse response Completed:::::: ");
		               
		        }catch(Exception e){
		               status.setStatusCode("-1");
		               status.setStatusDesc(e.getMessage());
		               LOGGER.error("Exception occurred while calling Job Service:::: " 
		                            + e.getMessage());
		               System.out.println("Exception occurred while Job Service:::: " 
		                            + e.getMessage());
		               System.err.println(e);
		               response.setStatusInfo(status);
		        }
		        return response;
		  }
	
			
	/**
	 * @param dto
	 * @param request
	 * @return
	 */
	public ValidatePayeeResponse validatePayee(PayloadDTO dto, ValidatePayeeRequest request) {
		LOGGER.error("PaymentResponseImpl ::  validatePayee --Start");
		ValidatePayeeResponse response = null;
		BillerPayResponseVO responseVO = null;
		try {
			if (dto != null && dto.getResponseVO() instanceof BillerPayResponseVO) {
				LOGGER.error("PaymentResponseImpl ::  validatePayee --Inside ");
				responseVO = (BillerPayResponseVO) dto.getResponseVO();
				response = BillpaymentMappingHelper.getValidatePayeeResponseVOMapping(responseVO);
				if (response.getPayeeDetails() != null) {
					if (response.getPayeeDetails().getBillerDetails() != null) {
						if (response.getPayeeDetails().getBillerDetails().getPayLimit() != null) {
							response.getPayeeDetails().getBillerDetails().getPayLimit()
									.setBillerMaxPmt(responseVO.getBillerPayDetailsVO().getBillerMaxPmt());
							response.getPayeeDetails().getBillerDetails().getPayLimit()
									.setBillerMinPmt(responseVO.getBillerPayDetailsVO().getBillerMinPmt());
						}
					}
				}
				HostResponseType hostVo = new HostResponseType();
				if(responseVO.getBillerPayDetailsVO() !=null){
				if(responseVO.getBillerPayDetailsVO().getHostName()==null || responseVO.getBillerPayDetailsVO().getHostName().trim().isEmpty()){
				    hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				}else{
					hostVo.setHostName(responseVO.getBillerPayDetailsVO().getHostName());
				}
				}else{
					hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				}
				hostVo.setCode(responseVO.getErrorCD());
				hostVo.setDesc(responseVO.getErrorDesc());
				StatusType statusInfo = new StatusType();
				statusInfo.setStatusCode(responseVO.getStatus());
				statusInfo.setStatusDesc(responseVO.getStatusDesc());
				// response.getStatusInfo().setStatusCode(responseVO.getStatus());
				// response.getStatusInfo().setStatusDesc(responseVO.getStatusDesc());
				response.setStatusInfo(statusInfo);
				response.getStatusInfo().getHostResponse().add(hostVo);
			}
			response.setClientContext(request.getClientContext());
			response.setMessageContext(request.getMessageContext());
			response.setServiceContext(request.getServiceContext());
			response.setUserContext(request.getUserContext());
			LOGGER.error("PaymentResponseImpl ::  validatePayee --END");
		} catch (Exception e) {
			LOGGER.error("PaymentResponseImpl ::  validatePayee --Exception" + e.getMessage());
			response = new ValidatePayeeResponse();
			StatusType value = new StatusType();
			HostResponseType hostErrVo = new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._164.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._164.getMessage());
			value.setStatusCode(Messages._1.getCode());
			value.setStatusDesc(Messages._1.getMessage());
			value.getHostResponse().add(hostErrVo);
			response.setStatusInfo(value);
			response.setClientContext(request.getClientContext());
			response.setMessageContext(request.getMessageContext());
			response.setServiceContext(request.getServiceContext());
			response.setUserContext(request.getUserContext());

		}
		return response;
	}

	/**
	 * @param dto
	 * @param request
	 * @return
	 */
	public ValidatePayeeResponse validatePayeeCS(PayloadDTO dto, ValidatePayeeRequest request) {
		LOGGER.error("PaymentResponseImpl ::  validatePayeeCS --Start"+request.getMessageContext().getReqID());
		ValidatePayeeResponse response = null;
		BillerPayResponseVO responseVO = (BillerPayResponseVO)dto.getResponseVO();
		try {
			if (dto != null && dto.getResponseVO() instanceof BillerPayResponseVO) {
				LOGGER.error("PaymentResponseImpl ::  validatePayeeCS --Inside "+request.getMessageContext().getReqID());
				response = BillpaymentMappingHelper.getValidatePayeeResponseVOMapping(responseVO);
				HostResponseType hostVo = new HostResponseType();
				hostVo.setCode(responseVO.getErrorCD());
				hostVo.setDesc(responseVO.getErrorDesc());
				StatusType statusInfo = new StatusType();
				statusInfo.setStatusCode(responseVO.getStatus());
				statusInfo.setStatusDesc(responseVO.getStatusDesc());
				response.setStatusInfo(statusInfo);
				response.getStatusInfo().getHostResponse().add(hostVo);
			}
			response.setClientContext(request.getClientContext());
			response.setMessageContext(request.getMessageContext());
			response.setServiceContext(request.getServiceContext());
			response.setUserContext(request.getUserContext());
			LOGGER.error("PaymentResponseImpl ::  validatePayeeCS --END "+request.getMessageContext().getReqID());
		} catch (Exception e) {
			LOGGER.error("PaymentResponseImpl ::  validatePayeeCS --Exception " +request.getMessageContext().getReqID()+" "+ e);
			response = new ValidatePayeeResponse();
			StatusType value = new StatusType();
			HostResponseType hostErrVo = new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._149.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._149.getMessage());
			value.setStatusCode(Messages._1.getCode());
			value.setStatusDesc(Messages._1.getMessage());
			value.getHostResponse().add(hostErrVo);
			response.setStatusInfo(value);
			response.setClientContext(request.getClientContext());
			response.setMessageContext(request.getMessageContext());
			response.setServiceContext(request.getServiceContext());
			response.setUserContext(request.getUserContext());

		}
		return response;
	}
	
	/**
	 * @param dto
	 * @param request
	 * @return
	 */
	public AddPayeeResponse addPayeeCS(PayloadDTO dto, AddPayeeRequest request) {
		AddPayeeResponse response=new AddPayeeResponse();
		BillerPayResponseVO responseVO = null;
		try{
		if(dto != null && dto.getResponseVO() instanceof BillerPayResponseVO){
			responseVO = (BillerPayResponseVO) dto.getResponseVO();
				HostResponseType hostVo=new HostResponseType();
				hostVo.setHostName(CommonConstants.SOURCE_SYSTEM);
				hostVo.setCode(responseVO.getErrorCD());
				hostVo.setDesc(responseVO.getErrorDesc());
				
				StatusType statusType = new StatusType();
				statusType.setStatusCode(responseVO.getStatus());
				statusType.setStatusDesc(responseVO.getStatusDesc());
				statusType.getHostResponse().add(hostVo);	
				response.setStatusInfo(statusType);
		}else{
			response = new AddPayeeResponse();
			StatusType statusvalue = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._109.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._109.getMessage());
			statusvalue.setStatusCode(Messages._1.getCode());
			statusvalue.setStatusDesc(Messages._1.getMessage());
			statusvalue.getHostResponse().add(hostErrVo);
			response.setStatusInfo(statusvalue);
		}
		response.setClientContext(request.getClientContext());
		response.setMessageContext(request.getMessageContext());
		response.setServiceContext(request.getServiceContext());
		response.setUserContext(request.getUserContext());
		}catch(Exception e){
			response = new AddPayeeResponse();
			StatusType statusvalue = new StatusType();
			HostResponseType hostErrVo=new HostResponseType();
			hostErrVo.setHostName(CommonConstants.SOURCE_SYSTEM);
			hostErrVo.setCode(ExceptionMessages._109.getErrorCode());
			hostErrVo.setDesc(ExceptionMessages._109.getMessage());
			statusvalue.setStatusCode(Messages._1.getCode());
			statusvalue.setStatusDesc(Messages._1.getMessage());
			statusvalue.getHostResponse().add(hostErrVo);
			response.setStatusInfo(statusvalue);
			response.setClientContext(request.getClientContext());
			response.setMessageContext(request.getMessageContext());
			response.setServiceContext(request.getServiceContext());
			response.setUserContext(request.getUserContext());

			
		}
		return response;
		}

			
}