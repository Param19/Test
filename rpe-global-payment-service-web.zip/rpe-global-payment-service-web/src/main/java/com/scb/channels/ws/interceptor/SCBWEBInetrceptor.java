package com.scb.channels.ws.interceptor;
 
import java.util.Map;
import java.util.logging.Logger;

import org.apache.cxf.common.logging.LogUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.LoggingInInterceptor;
 
import org.apache.cxf.message.Message;
 
import org.slf4j.MDC;



 
public class SCBWEBInetrceptor extends LoggingInInterceptor {
     
    private static final Logger LOG = LogUtils.getLogger(SCBWEBInetrceptor.class);

    public void handleMessage(Message message) throws Fault {
    	
    	
    	
    	try{
    	 
    		if(MDC.get("userId")!=null){
        		
        		MDC.remove("userId");
        		
        	}if(MDC.get("customerId")!=null){
    	    		
    			MDC.remove("customerId");
    	      	}
    	    if(MDC.get("sessionId")!=null){
	
    			MDC.remove("sessionId");
    			
    		}
    	 
    		if(MDC.get("scbSessionId")!=null){
    			
    			MDC.remove("scbSessionId");
    			
    		}
    		if(MDC.get("DEVICE")!=null){
    			
    			MDC.remove("DEVICE");
    			
    		}
    	 
    		 
    		
      super.handleMessage(message);
    //  System.out.println("after Meesaage");
      
    	}catch(Exception e){
    		
    		System.out.println(e.getMessage());
    		System.out.println(e.getStackTrace());
    	}
    	
    	//System.out.println("final Execustion");
    }

   
}
