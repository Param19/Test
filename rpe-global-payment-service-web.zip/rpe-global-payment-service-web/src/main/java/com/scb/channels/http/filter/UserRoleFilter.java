package com.scb.channels.http.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.cxf.common.util.Base64Exception;
import org.apache.cxf.common.util.Base64Utility;

import com.scb.channels.security.adapter.UserRoleRequestWrapper;

/**
 * Servlet Filter implementation class UserRoleFilter
 */
public class UserRoleFilter implements Filter {

    /**
     * Default constructor. 
     */
    public UserRoleFilter() {
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
	    String user = null;
	    String password = null;
	    String credentials = req.getHeader("Authorization");
	    if (credentials != null) {
		    String authType = credentials.split(" ")[0];
	        if ("Basic".equals(authType)) {
	            String authEncoded = credentials.split(" ")[1];
	            try {
	                String authDecoded = new String(Base64Utility.decode(authEncoded));
	                int idx = authDecoded.indexOf(':');
	                if (idx == -1) {
	                	user = authDecoded;
	                } else {
	                	user = authDecoded.substring(0, idx);
	                	password = authDecoded.substring((idx+1));
	                }
	                
	            } catch (Base64Exception ex) {
	                // Invalid authentication => treat as not authenticated or use the Principal
	            }
	        } 
	    } else if (req.getHeader("username")!=null){
	    	user = req.getHeader("username");
	    }
		 List<String> roles = new ArrayList<String>(); 
		 String role = req.getHeader("ROLE");
		 if (role!=null) {
			 String[] roleArray = role.split(";");
			 CollectionUtils.addAll(roles, roleArray);
		 }
		 chain.doFilter(new UserRoleRequestWrapper(user,password, roles, req), response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
