package com.scb.channels.rs.bindings;

import java.lang.reflect.Method;

import javax.security.auth.Subject;

import org.apache.camel.component.cxf.jaxrs.DefaultCxfRsBinding;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.security.SecurityContext;

/**
 * The Class ChannelCXFRsBindings.
 */
public class ChannelCXFRsBindings extends DefaultCxfRsBinding {

	/* (non-Javadoc)
	 * @see org.apache.camel.component.cxf.jaxrs.DefaultCxfRsBinding#populateExchangeFromCxfRsRequest(org.apache.cxf.message.Exchange, org.apache.camel.Exchange, java.lang.reflect.Method, java.lang.Object[])
	 */
	@Override
	public void populateExchangeFromCxfRsRequest(Exchange cxfExchange,
			org.apache.camel.Exchange camelExchange, Method method,
			Object[] paramArray) {
		super.populateExchangeFromCxfRsRequest(cxfExchange, camelExchange, method,
				paramArray);
		 // propagate the security subject from CXF security context
        SecurityContext securityContext = cxfExchange.getInMessage().get(SecurityContext.class);
        if (securityContext != null && securityContext.getUserPrincipal() != null) {
            Subject subject = new Subject();
            subject.getPrincipals().add(securityContext.getUserPrincipal());
            camelExchange.getIn().getHeaders().put(org.apache.camel.Exchange.AUTHENTICATION, subject);
        }
	}
}
