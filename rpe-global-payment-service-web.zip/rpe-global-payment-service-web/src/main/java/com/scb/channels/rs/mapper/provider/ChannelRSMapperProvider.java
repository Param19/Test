package com.scb.channels.rs.mapper.provider;

import org.codehaus.jackson.jaxrs.Annotations;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

/**
 * The Class ChannelRSMapperProvider.
 *
 * @author 1411807
 */
public class ChannelRSMapperProvider extends JacksonJsonProvider {
	

	
	/* (non-Javadoc)
	 * @see org.codehaus.jackson.jaxrs.JacksonJsonProvider#setMapper(org.codehaus.jackson.map.ObjectMapper)
	 */
	public void setMapper(ObjectMapper m) {
        super.setMapper(m);
        configure(SerializationConfig.Feature.WRAP_ROOT_VALUE, true);
        configure(SerializationConfig.Feature.WRITE_NULL_PROPERTIES, false);
        setAnnotationsToUse(new Annotations[]{Annotations.JACKSON, Annotations.JAXB});
    }
}
