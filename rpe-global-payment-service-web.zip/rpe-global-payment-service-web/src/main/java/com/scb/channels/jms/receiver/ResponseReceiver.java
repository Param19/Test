package com.scb.channels.jms.receiver;

import javax.jms.Message;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Class ChannelReceiver.
 */
public class ResponseReceiver {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseReceiver.class);
	
    /** The jms template. */
    private JmsTemplate jmsTemplate;

	/**
	 * Receive message.
	 *
	 * @param requestId the request id
	 * @return the transfer response vo
	 */
	public PayloadDTO receiveMessage(String requestId)  {
		
		LOGGER.debug("Waiting for Response for  receiveMessage ----------");
		LOGGER.debug("Waiting for Response for  receiveMessage "+ jmsTemplate.getDefaultDestinationName());
		LOGGER.debug("Waiting for Response for id {} on destination ", new Object[]{requestId,jmsTemplate.getDefaultDestinationName()});
		
		Message message=jmsTemplate.receiveSelected("JMSCorrelationID='"+requestId+"'");
		ObjectMessage objectMessage = null;
        if (message instanceof ObjectMessage) {
        	LOGGER.debug("Response received for request id {}", message);
        	objectMessage = (ObjectMessage)message;
            try {
            	Object obj = objectMessage.getObject();
            	if (obj instanceof PayloadDTO) {
            		LOGGER.debug("Response received for request id {}", requestId);
            		return ((PayloadDTO)obj);
            	}
            } catch (Exception e) {
            	LOGGER.error(e.getMessage());
            }
        }
        LOGGER.debug("Response received for request id {}", message);
        LOGGER.error("Invalid response message recieved for request id {}", requestId);
        return null;
    }	
	
	/**
	 * Sets the jms template.
	 *
	 * @param jmsTemplate the jmsTemplate to set
	 */
	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	
    
}