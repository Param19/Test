package com.scb.channels.ws.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.namespace.QName;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.security.SecurityContext;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;

import com.scb.channels.base.exception.BaseException;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.security.adapter.UserRoleRequestWrapper;



/**
 * The Class AuthInterceptor.
 */
public class AuthInInterceptor extends AbstractPhaseInterceptor<Message> {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthInInterceptor.class);
	
	/** The Constant ONE_MINUTE. */
	public static final long ONE_MINUTE = 1000 * 60;
	
	/** The session timeout. */
	private String sessionTimeout;
	 

	/**
     * Default Constructor.
     */
    public AuthInInterceptor() {
        super(Phase.USER_LOGICAL);
        if (sessionTimeout == null) {
        	sessionTimeout = "20";
        }
    }

	/* (non-Javadoc)
	 * @see org.apache.cxf.interceptor.Interceptor#handleMessage(org.apache.cxf.message.Message)
	 */
	public void handleMessage(Message message) throws Fault {
		 String path = "" ;
		 Object obj = message.get(Message.WSDL_OPERATION);
		 if (obj != null && obj instanceof QName) {
			 QName qName = (QName)message.get(Message.WSDL_OPERATION);
			 path = qName.getLocalPart();
		 }

	        try {
	        	
	        	boolean secured = isSecure(path);
	        	LOGGER.debug("isSecure(path): {},{}", path, secured);
	        	
	        	HttpServletRequest request = (HttpServletRequest) message.get(AbstractHTTPDestination.HTTP_REQUEST);
	    		HttpSession session = request.getSession(false);
	        	
	        	if (path.endsWith("login")) {
					if ((session != null) && (session.getId() != null)) {
						UserRoleRequestWrapper userRoleRequestWrapper = (UserRoleRequestWrapper) session.getAttribute("SESSION_PRINCIPAL");
						Authentication auth = (Authentication)userRoleRequestWrapper.getPrincipal();
						if (auth != null) {
							auth.setAuthenticated(false);

							LOGGER.info("Valid session of the user {} in Login Request ", auth.getName());
						}
						LOGGER.debug("Session ID in Login Request ", session.getId().toString());
						session.invalidate();
					}     	       		
				} else {
		            if (secured) {
		                //Check for valid session
		                LOGGER.debug("Session: {}", session);
		                if (session != null) {
		        			long sessionUpTime = (System.currentTimeMillis() - session.getCreationTime());
		                    LOGGER.debug("Session UpTime: {}", sessionUpTime);
		        			
		                    long absSessionTimeout = Long.parseLong( this.sessionTimeout );
		                    LOGGER.debug("SessionTimeout: {}", absSessionTimeout);
	
		        			if (sessionUpTime > absSessionTimeout * ONE_MINUTE) {
		                        LOGGER.warn("Session expired");
		        				session.invalidate();
								throw new Fault(new BaseException(ExceptionMessages._110.getCode(), ExceptionMessages._110.getMessage()));
		        			}
	
		        		} else {
		                    LOGGER.warn("Session is null");
		                    throw new Exception(ExceptionMessages._110.getMessage());
		        		}
		                		
		        		String sessionId = session.getId();
						LOGGER.debug("Session ID from Container: {}", sessionId);
	
		        		LOGGER.info("authenticating session");
				        boolean validSession = authenticateSession(session);
			
		                if (!validSession) {
		                	session.invalidate();
							LOGGER.warn("Wrong token has been used.");
							throw new Fault(new BaseException(ExceptionMessages._111.getMessage()));
						}
	
		                //Validate Login
						validateLogin(session, message);
	
						LOGGER.debug("Valid Login");
		            }
		         }
	            
	         } catch (Exception e) {
	        	LOGGER.error("Error occurred in SessionAuthInterceptor", e);
	            throw new Fault(e.getCause());
	        }
	}

	/**
	 * Validate login.
	 *
	 * @param session the session
	 * @param message the message
	 */
	private void validateLogin(HttpSession session, Message message) {
	   final UserRoleRequestWrapper userRoleRequestWrapper = (UserRoleRequestWrapper) session.getAttribute("SESSION_PRINCIPAL");
	   SecurityContext securityContext = message.get(SecurityContext.class);
        if ((userRoleRequestWrapper != null && securityContext != null 
        		&& securityContext.getUserPrincipal() != null 
        		&& securityContext.getUserPrincipal().equals(userRoleRequestWrapper.getPrincipal()))) {
        	message.put(SecurityContext.class, userRoleRequestWrapper);
        }
	}

	/**
	 * Authenticate session.
	 *
	 * @param session the session
	 * @return true, if successful
	 */
	private boolean authenticateSession(HttpSession session) {
		return true;
	}

	/**
	 * Checks if is secure.
	 *
	 * @param path the path
	 * @return true, if is secure
	 */
	private boolean isSecure(String path) {
		return true;
	}

	/**
	 * Sets the session timeout.
	 *
	 * @param sessionTimeout the sessionTimeout to set
	 */
	public void setSessionTimeout(String sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}
	
	
}
