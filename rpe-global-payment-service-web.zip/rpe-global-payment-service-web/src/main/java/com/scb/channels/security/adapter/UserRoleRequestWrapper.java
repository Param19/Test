package com.scb.channels.security.adapter;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.cxf.security.SecurityContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;

// TODO: Auto-generated Javadoc
/**
 * The Class UserRoleRequestWrapper.
 */
public class UserRoleRequestWrapper extends HttpServletRequestWrapper implements SecurityContext {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 314719232740487482L;
	
	/** The user. */
	private String user;
	
	/** The roles. */
	private List<String> roles = null;
	
	/** The real request. */
	private HttpServletRequest realRequest;
	
	/** The password. */
	private String password;
	
	/** The authenticated. */
	private boolean authenticated = false;
	  
	/**
	 * Instantiates a new user role request wrapper.
	 *
	 * @param user the user
	 * @param password the password
	 * @param roles the roles
	 * @param request the request
	 */
	public UserRoleRequestWrapper(String user, String password, List<String> roles, HttpServletRequest request) {
	    super(request);
	    this.user = user;
	    this.password = password;
	    this.roles = roles;
	    this.realRequest = request;
	  }
	
	/**
	 * Instantiates a new user role request wrapper.
	 *
	 * @param user the user
	 * @param roles the roles
	 * @param request the request
	 */
	public UserRoleRequestWrapper(String user, List<String> roles, HttpServletRequest request) {
	    this(user, null, roles, request);
	}

	  /* (non-Javadoc)
  	 * @see javax.servlet.http.HttpServletRequestWrapper#isUserInRole(java.lang.String)
  	 */
  	@Override
	  public boolean isUserInRole(String role) {
	    if (roles == null) {
	      return this.realRequest.isUserInRole(role);
	    }
	    return roles.contains(role);
	  }

	  /* (non-Javadoc)
  	 * @see javax.servlet.http.HttpServletRequestWrapper#getUserPrincipal()
  	 */
  	@Override
	  public Principal getUserPrincipal() {
	    if (this.user == null) {
	      return realRequest.getUserPrincipal();
	    }
	    return new Authentication() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = 6510407942995021795L;

			public String getName() {
				// TODO Auto-generated method stub
				return user;
			}
			
			public void setAuthenticated(boolean arg0) throws IllegalArgumentException {
				authenticated = arg0;				
			}
			
			public boolean isAuthenticated() {
				return authenticated;
			}
			
			public Object getPrincipal() {
				return this.getPrincipal();
			}
			
			public Object getDetails() {
				return null;
			}
			
			public Object getCredentials() {
				return password;
			}
			
			public Collection<? extends GrantedAuthority> getAuthorities() {
				if (roles !=null && !roles.isEmpty()) {
					GrantedAuthority authority = new GrantedAuthorityImpl(roles.get(0));
					List<GrantedAuthority> list = new ArrayList<GrantedAuthority>();
					list.add(authority);
					return list;
				}
				return null;
			}
		};
	  }

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return user;
	}

	/**
	 * Gets the authorities.
	 *
	 * @return the authorities
	 */
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
	}

	/**
	 * Gets the credentials.
	 *
	 * @return the credentials
	 */
	public Object getCredentials() {
		return this.realRequest.getHeader("Authorization");
	}

	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public Object getDetails() {
		return null;
	}

	/**
	 * Gets the principal.
	 *
	 * @return the principal
	 */
	public Object getPrincipal() {
		return realRequest.getUserPrincipal();
	}

	/**
	 * Checks if is authenticated.
	 *
	 * @return true, if is authenticated
	 */
	public boolean isAuthenticated() {
		return authenticated;
	}

	/**
	 * Sets the authenticated.
	 *
	 * @param arg0 the new authenticated
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	public void setAuthenticated(boolean arg0) throws IllegalArgumentException {
		this.authenticated = true;
		
	}
}
