package com.scb.channels.security.adapter;

import java.util.Set;

import javax.security.auth.Subject;

import org.apache.camel.component.spring.security.AuthenticationAdapter;
import org.springframework.security.core.Authentication;

public class ChannelAuthenticationAdapter implements AuthenticationAdapter {

	public Authentication toAuthentication(Subject subject) {
		if (subject == null || subject.getPrincipals().size() == 0) {
            return null;
        }
        Set<Authentication> authentications  = subject.getPrincipals(Authentication.class);
        if (authentications.size() > 0) {
            // just return the first one 
            return authentications.iterator().next();
        } 
		return null;
	}

}
