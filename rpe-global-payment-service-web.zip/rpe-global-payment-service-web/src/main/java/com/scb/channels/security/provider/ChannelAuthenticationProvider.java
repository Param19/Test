/**
 * 
 */
package com.scb.channels.security.provider;

import java.util.Map;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;

import com.scb.channels.security.adapter.UserRoleRequestWrapper;

/**
 * @author 1411807
 *
 */
public class ChannelAuthenticationProvider implements AuthenticationProvider {
	
	private Map<String, String> userMap;
	
	private Map<String, String> roleMap;

	/* (non-Javadoc)
	 * @see org.springframework.security.authentication.AuthenticationProvider#authenticate(org.springframework.security.core.Authentication)
	 */
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		// TODO Auto-generated method stub
		String value = userMap.get(authentication.getName());
		if (value == null) {
			authentication.setAuthenticated(false);
		} else if (value.equals(String.valueOf(authentication.getCredentials()))) {
			if (roleMap.containsKey(authentication.getName())) {
				for (GrantedAuthority authority : authentication.getAuthorities()) {
					if (authority.getAuthority().equals(roleMap.get(authentication.getName()))){
						authentication.setAuthenticated(true);
						break;
					}
				}
			}
		}
		return authentication;
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.authentication.AuthenticationProvider#supports(java.lang.Class)
	 */
	public boolean supports(Class<?> authentication) {
		 return (UserRoleRequestWrapper.class.isAssignableFrom(authentication) 
				 || Authentication.class.isAssignableFrom(authentication));
	}

	/**
	 * @return the userMap
	 */
	public Map<String, String> getUserMap() {
		return userMap;
	}

	/**
	 * @param userMap the userMap to set
	 */
	public void setUserMap(Map<String, String> userMap) {
		this.userMap = userMap;
	}

	/**
	 * @return the roleMap
	 */
	public Map<String, String> getRoleMap() {
		return roleMap;
	}

	/**
	 * @param roleMap the roleMap to set
	 */
	public void setRoleMap(Map<String, String> roleMap) {
		this.roleMap = roleMap;
	}

}
