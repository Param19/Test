package com.scb.channels.channelservices.helper;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.DynamicDestinationResolver;


public class JMSQueuePostMessageTest {

	private static ApplicationContext context = null;
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(JMSQueuePostMessageTest.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = new FileSystemXmlApplicationContext("C:\\WORK\\alipay\\SVNFolder\\source\\globalPaymentServiceWeb\\src\\main\\webapp\\WEB-INF\\spring\\channel-jms-context.xml");
		//context = TestHelper.getContext();
	}
	
	@Test
	public void testMessageSender(){
		/*PaymentsServiceTest pst = new PaymentsServiceTest();
		sendMessageToQueue(pst.getXML(pst.createPaymentRequest(), PaymentRequest.class));*/
		sendMessageToQueue(readRequestFromFile());
	}
	
	//@Test
	/*public void testMessageSenderForObject() throws Exception {
		PaymentsServiceTest pst = new PaymentsServiceTest();
		PayloadDTO payload = new PaymentWrapServiceImpl().payBill(pst.createPaymentRequest());
		payload = new ContextInitializationProcessor().process(payload);
		
		sendMessageToQueue(payload);
	}*/
	
	private static void sendMessageToQueue(Object messageString){

		Connection conn = null;
		Session sess  = null;
		
		try {
			//QueueConnectionFactory conf = (QueueConnectionFactory) context.getBean("channelJmsQueueConnectionFactory");
			QueueConnectionFactory conf = (QueueConnectionFactory) context.getBean("channelAlipayJmsQueueConnectionFactory");
			
			System.out.println(conf.toString());
			
			DestinationResolver destinationResolver = (DynamicDestinationResolver) context.getBean("channelDestinationResolver");
			//org.springframework.jms.support.destination.DynamicDestinationResolver
			//org.springframework.jms.support.destination.JndiDestinationResolver
			conn = conf.createConnection();
			System.out.println(conn.toString());
	
			sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			//For Active MQ
			//Destination dest = destinationResolver.resolveDestinationName(sess, "chnlPayBillRequestQ", false);
			
			//For IBM MQ
			//Destination dest = destinationResolver.resolveDestinationName(sess, "SRM.UAT.CHNLPAYBILLREQQUEUE", false);
			Destination dest = destinationResolver.resolveDestinationName(sess, "RPE.HK.UAT.CHNLPAYBILLREQQUEUE", false);
			
			System.out.println(dest.toString());
			
			MessageProducer mp = sess.createProducer(dest);
			
			if(messageString instanceof String){
				TextMessage message = sess.createTextMessage(String.valueOf(messageString));
				mp.send(message);
			} else {
				Message message = sess.createObjectMessage();
				message.setObjectProperty("PayloadDTO", messageString);
				mp.send(message);
			}
			
			sess.close();
			conn.close();
		} catch (Exception exception) {
			if(sess != null) {
				try {
					sess.close();
				} catch (JMSException e) {
					LOGGER.error("Exception occurred ::: ",e);
				}
			}
				
			if(conn != null){
				try {
					conn.close();
				} catch (JMSException e) {
					LOGGER.error("Exception occurred ::: ",e);
				}
			}
		}
	}
	
	private static String readRequestFromFile(){
		File file = null;
		StringBuffer buffer = new StringBuffer();
		Scanner sc = null;
		try {
			file = new File("C:\\Users\\1521723\\Desktop\\card_auth_EDMI_REs.txt");
			sc = new Scanner(file);
			while (sc.hasNextLine()) {
				buffer.append(sc.nextLine());
				//System.out.println(sCurrentLine);
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("Exception occurred duirng readFile::: ",e);
		} finally {
		        if(sc != null){
		            sc.close();
		        }
		}
		return buffer.toString();
	}
}
