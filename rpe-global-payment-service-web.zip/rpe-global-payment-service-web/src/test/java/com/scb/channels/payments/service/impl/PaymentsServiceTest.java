package com.scb.channels.payments.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import junit.framework.Assert;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.channelservices.helper.TestHelper;
import com.scb.channels.common.Biller;
import com.scb.channels.common.ClientContext;
import com.scb.channels.common.Consumer;
import com.scb.channels.common.MessageContext;
import com.scb.channels.common.ServiceContext;
import com.scb.channels.common.UserContext;
import com.scb.channels.paymentservice.PayeeDetails;
import com.scb.channels.paymentservice.PaymentInformation;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.PaymentRequestType;

public class PaymentsServiceTest {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentsServiceTest.class);
	
	@Test
	public void testRequestProcessed() throws Exception {
		ApplicationContext appcontext = TestHelper.getContext();
		Assert.assertNotNull(appcontext);
		
		CamelContext camelContext = (CamelContext) appcontext.getBean("csCamelConfig");
		Assert.assertNotNull(camelContext);
		
		//Thread.sleep(120000);
		
		ProducerTemplate template = camelContext.createProducerTemplate();
		//Object obj = template.requestBody("direct:payBill",getXML(createPaymentRequest(), PaymentRequest.class));
		Object obj = template.requestBody("direct:payBill",readRequestFromFile());
		Assert.assertNotNull(obj);
		
		/*String xml = getXML(createPaymentRequest(), PaymentRequest.class);
		Object object = CommonHelper.unMarshall(xml, PaymentRequest.class);*/
		//System.out.println("complete");
	}
	
	//@Test
	public void testPaymentPerformance() throws Exception{
		
		ApplicationContext context = null;
		try{
 			context = new ClassPathXmlApplicationContext("/spring/channel-jms-context.xml");
		} catch(Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		for(int i=0;i<150;i++){
			
			Thread.sleep(500);
			
			sendMessageToQueue(getXML(createPaymentRequest(), PaymentRequest.class), context);
		}
	}
	
	
	public PaymentRequest createPaymentRequest_UAT() {
		
		String txnId = "IBNK-SRM-PAY-TEST-1904-" + RandomStringUtils.random(7, true, true);
		
		//System.out.println("txnId-txnId-txnId-txnId-txnId :::: " + txnId);
		
		PaymentRequest payment = new PaymentRequest();
		PaymentRequestType payRequest = new PaymentRequestType();
		PayeeDetails payee = new PayeeDetails();
		PaymentInformation paymentInfo = new PaymentInformation();
		
		ClientContext client = new ClientContext();
		client.setChannel("IBNK");
		client.setCountry("NG");
		client.setDate(getGregorianCalendar());
		
		MessageContext message = new MessageContext();
		message.setReqID(txnId);
		
		ServiceContext service = new ServiceContext();
		service.setServiceName("payBill");
		
		UserContext user = new UserContext();
		user.setCustName("Test");
		user.setCustomerId("Test1234");
		
		Consumer consumer = new Consumer();
		consumer.setConsumerNo("987654321");
		
		Biller biller = new Biller();
		biller.setBillerId("NGIS04102101");
		biller.setBillerName("Emirates");
		biller.setBillerCategoryId("1");
		biller.setBillerCategoryName("Airlines and Hotels Payments");
		
		payee.setPayeeId("9");
		payee.setPayeeNickname("Arun");
		payee.setPayeeMobileNumber("9386248");
		payee.setPayeeEmailId("a@b.c");
		payee.setBillerDetails(biller);
		payee.setConsumer(consumer);
		
		paymentInfo.setSourceAccountNumber("0000062488");
		paymentInfo.setPaymentAmount(2);
		paymentInfo.setSourceAccountType("CASA");
		paymentInfo.setSourceAccountCurrency("NGN");
		paymentInfo.setTransactionCurrency("NGN");
		paymentInfo.setPaymentDescription("For Testing");
		
		payRequest.setPaymentType("R");
		payRequest.setPaymentReference(txnId);
		payRequest.setPayeeInformation(payee);
		payRequest.setPaymentInformation(paymentInfo);
		
		payment.setClientContext(client);
		payment.setUserContext(user);
		payment.setServiceContext(service);
		payment.setMessageContext(message);
		payment.setPaymentRequestType(payRequest);
		
		return payment;
	}
	
public PaymentRequest createPaymentRequest() {
		
		String txnId = "IBNK-SRM-PAY-TEST-1406-" + RandomStringUtils.random(7, true, true);
		
		//System.out.println("txnId-txnId-txnId-txnId-txnId :::: " + txnId);
		
		PaymentRequest payment = new PaymentRequest();
		PaymentRequestType payRequest = new PaymentRequestType();
		PayeeDetails payee = new PayeeDetails();
		PaymentInformation paymentInfo = new PaymentInformation();
		Consumer consumer = new Consumer();
		
		ClientContext client = new ClientContext();
		client.setChannel("IBNK");
		client.setDate(getGregorianCalendar());
		
		MessageContext message = new MessageContext();
		message.setReqID(txnId);
		
		ServiceContext service = new ServiceContext();
		service.setServiceName("payBill");
		
		UserContext user = new UserContext();
		user.setCustName("Test");
		user.setCustomerId("Test1234");
		user.setIsStaff("Y");
		
		//SIT
		/*client.setCountry("KE");
		payee.setPayeeId("4462");
		consumer.setConsumerNo("124578");
		paymentInfo.setSourceAccountNumber("0100701756100");
		paymentInfo.setSourceAccountCurrency("KES");
		paymentInfo.setTransactionCurrency("KES");*/
		
		//DEV
		/*client.setCountry("KE");
		payee.setPayeeId("1404");
		consumer.setConsumerNo("12457855");
		paymentInfo.setSourceAccountNumber("0100701756100");
		paymentInfo.setSourceAccountCurrency("KES");
		paymentInfo.setTransactionCurrency("KES");*/
		
		//UAT
		client.setCountry("KE");
		payee.setPayeeId("1445");
		consumer.setConsumerNo("124578");
		paymentInfo.setSourceAccountNumber("0100701756100");
		paymentInfo.setSourceAccountCurrency("KES");
		paymentInfo.setTransactionCurrency("KES");
		
		payee.setConsumer(consumer);
		payee.setPayeeNickname("Arun");
		
		paymentInfo.setPaymentAmount(2);
		paymentInfo.setSourceAccountType("CASA");
		paymentInfo.setPaymentDescription("For Testing");
		
		payRequest.setPaymentType("R");
		payRequest.setPaymentReference(txnId);
		payRequest.setPayeeInformation(payee);
		payRequest.setPaymentInformation(paymentInfo);
		
		payment.setClientContext(client);
		payment.setUserContext(user);
		payment.setServiceContext(service);
		payment.setMessageContext(message);
		payment.setPaymentRequestType(payRequest);
		
		return payment;
	}
	
	public String getXML(Object object, Class clazz) {//AccountEnquiryReq accountEnquiryReq
		String xml = null;
		try {
			Marshaller marshaller = CommonHelper
					.getMarshaller(clazz);
			ByteArrayOutputStream stream = new ByteArrayOutputStream();

			//System.out.println("clazz.getSimpleName();" + clazz.getSimpleName());
			//System.out.println("clazz.getCanonicalName();" + clazz.getCanonicalName());
			
			marshaller.marshal(new JAXBElement(new QName(
					clazz.getSimpleName()), clazz, object), stream);
			
			xml = new String(stream.toByteArray());
			//System.out.println("XML for object : " + xml);
		} catch (JAXBException e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return xml;
	}
	
	private static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(new Date());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
			return date;
		}
	
	private static void sendMessageToQueue(Object messageString, ApplicationContext context){

		Connection conn = null;
		Session sess  = null;
		
		try {
			TopicConnectionFactory conf = (TopicConnectionFactory) context.getBean("channelJmsQueueConnectionFactory");
			
			DestinationResolver destinationResolver = (DynamicDestinationResolver) context.getBean("channelDestinationResolver");
			conn = conf.createConnection();
	
			sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			//For Active MQ
			//Destination dest = destinationResolver.resolveDestinationName(sess, "chnlPayBillRequestQ", false);
			
			//For IBM MQ
			Destination dest = destinationResolver.resolveDestinationName(sess, "SRM.PRD.CHNLPAYBILLREQQUEUE", false);
			
			MessageProducer mp = sess.createProducer(dest);
			
			if(messageString instanceof String){
				TextMessage message = sess.createTextMessage(String.valueOf(messageString));
				mp.send(message);
			} else {
				Message message = sess.createObjectMessage();
				message.setObjectProperty("PayloadDTO", messageString);
				mp.send(message);
			}
			
		} catch (Exception exception) {
			LOGGER.error("Exception occurred ::: ",exception);
		} finally {
			if(sess != null) {
				try {
					sess.close();
				} catch (JMSException e) {
					LOGGER.error("Exception occurred ::: ",e);
				}
			}
				
			if(conn != null){
				try {
					conn.close();
				} catch (JMSException e) {
					LOGGER.error("Exception occurred ::: ",e);
				}
			}
		}
	}
	
	private static String readRequestFromFile(){
		File file = null;
		StringBuffer buffer = new StringBuffer();
		Scanner sc = null;
		try {
			file = new File("C:\\Project\\Development\\Picasso_Payments\\global_payments_prd\\nfs_request.txt");
			sc = new Scanner(file);
			while (sc.hasNextLine()) {
				buffer.append(sc.nextLine());
				//System.out.println(sCurrentLine);
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("Exception occurred duirng readFile::: ",e);
		} finally {
		        if(sc != null){
		            sc.close();
		        }
		}
		return buffer.toString();
	}
}
