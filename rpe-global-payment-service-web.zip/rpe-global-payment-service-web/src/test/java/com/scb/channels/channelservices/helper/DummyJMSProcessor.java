/**
 * 
 */
package com.scb.channels.channelservices.helper;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;



/**
 * @author 1411807
 *
 */
public class DummyJMSProcessor implements Processor {

	/* (non-Javadoc)
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@Override
	public void process(Exchange exchange) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> mp = exchange.getIn().getHeaders();
		for (Entry<String, Object> entry : mp.entrySet()) {
			System.out.println(entry.getKey());
		}
		//exchange.getOut().setBody(//new AddBillerResponse());
	}

}
