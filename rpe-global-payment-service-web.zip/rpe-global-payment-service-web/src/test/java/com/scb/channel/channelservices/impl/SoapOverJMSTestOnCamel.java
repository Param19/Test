package com.scb.channel.channelservices.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SoapOverJMSTestOnCamel {

	private ApplicationContext context = null;

	@Before
	public void setUp() throws Exception {
		context = new ClassPathXmlApplicationContext("spring/test-soapoverjms.xml");
	}

	@Test
	public void test() throws InterruptedException {
		assertNotNull(context);
		Thread.currentThread().sleep(1000*60*60);
	}

}
