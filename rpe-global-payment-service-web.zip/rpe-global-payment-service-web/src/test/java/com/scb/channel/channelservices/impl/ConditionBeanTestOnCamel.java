package com.scb.channel.channelservices.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ConditionBeanTestOnCamel {

	private ApplicationContext context = null;

	@Before
	public void setUp() throws Exception {
		context = new ClassPathXmlApplicationContext("spring/test-context.xml");
	}

	@Test
	public void test() {
		assertNotNull(context);
	}

}
