import static org.junit.Assert.assertNotNull;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.audit.service.AuditService;


public class TestClass {
	
	private static ApplicationContext context = null;

	//@Before
	public void setUp() throws Exception {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("/spring/auditweb-context.xml");
		}
	}

	//@Test
	public void test() {
		assertNotNull(context);
		AuditService auditService = (AuditService)context.getBean("auditService");
		assertNotNull(auditService);
		
		
	}

}
