/**
 * 
 */
package mapper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.scb.channels.base.helper.DateUtils;

/**
 * @author 1411807
 *
 */
public class DateFormatTest {

	@Test
	public void testAccounDetailReq() {
		DateFormat format = new SimpleDateFormat(DateUtils.DateFormat){
			 public StringBuffer format(Date date, StringBuffer toAppendTo, java.text.FieldPosition pos) {
		            StringBuffer toFix = super.format(date, toAppendTo, pos);
		            return toFix.insert(toFix.length()-2, ':');
		        };
		};
		System.out.println(format.format(DateUtils.getCurrentDate()));
		
	}
}
