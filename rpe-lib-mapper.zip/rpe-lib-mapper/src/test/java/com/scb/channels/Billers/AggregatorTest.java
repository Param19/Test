package com.scb.channels.Billers;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import junit.framework.Assert;

import org.junit.Test;

import com.sc.cash.payment.mobile.v1.invoice.InvoiceInfo;
import com.sc.cash.payment.mobile.v1.ws.provider.invoice.GetBillerCategoriesReq;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerTypeVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.base.vo.TempBillerField;
import com.scb.channels.base.vo.TempBillerVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.Biller;
import com.scb.channels.common.ClientContext;
import com.scb.channels.common.Consumer;
import com.scb.channels.common.MessageContext;
import com.scb.channels.common.ServiceContext;
import com.scb.channels.common.UserContext;
import com.scb.channels.mapper.helper.AggregatorMappingHelper;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.paymentservice.BillerBycategoryRequest;
import com.scb.channels.paymentservice.BillerBycategoryResponse;
import com.scb.channels.paymentservice.BillerNameBycategoryReponse;
import com.scb.channels.paymentservice.PayeeDetails;
import com.scb.channels.Billers.*;

public class AggregatorTest {

	//@Test
	public void testRequest() {
		 
	
		BillerDownloadRequest billerDownload= new BillerDownloadRequest();
		UserVO u=new UserVO();
		u.setCountry("NG");
		ClientVO c= new ClientVO();
		c.setCountry("NG");
		MessageVO m = new MessageVO();
		m.setReqID("123123");
		billerDownload.setPayloadFormat("XML");
		billerDownload.setUser(u);
		billerDownload.setClientVO(c);
		billerDownload.setMessageVO(m);
		billerDownload.setCaptureSystem("Interswitch");
		//billerDownload.setCaptureSystem("CraftSilicon");
		billerDownload.setCurrentTime(getGregorianCalendar());
		
		GetBillerCategoriesReq agg=AggregatorMappingHelper.getBillerCategoryMapping(billerDownload);
        agg.getHeader().getOriginationDetails().setMessageTimestamp(getGregorianCalendar());
        agg.getHeader().getOriginationDetails().setInitiatedTimestamp(getGregorianCalendar());
		
		System.out.println(agg);
		assertNotNull(agg);
	}
	
	private static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
			return date;
		}

	//@Test
	public void AggregatorcategoriesTest(){
		
		com.sc.cash.payment.mobile.v1.invoice.Invoice in= new com.sc.cash.payment.mobile.v1.invoice.Invoice();
		 
		InvoiceInfo ifs=TestData.getTestdata();
		 in.setInvoiceInfo(ifs);
		 BillerDownloadResponse billerDownload = AggregatorMappingHelper.getBillerCategoryMapping(in);
	
		 	System.out.println(billerDownload);
		 	assertNotNull(billerDownload);
	}
	 @Test
public void ListtoListTesting(){
		
		 
		 
	/*List<com.sc.cash.payment.mobile.v1.invoice.BillerCategory> category = new ArrayList<com.sc.cash.payment.mobile.v1.invoice.BillerCategory>();
	com.sc.cash.payment.mobile.v1.invoice.BillerCategory b1= new com.sc.cash.payment.mobile.v1.invoice.BillerCategory();
	
	b1.setCategoryID("23");
	b1.setCategoryName("telecommunication");
		com.sc.cash.payment.mobile.v1.invoice.Biller be1= new com.sc.cash.payment.mobile.v1.invoice.Biller(); 
			be1.setBillerID("24");
			be1.setBillerName("vodafone");
			b1.getBiller().add(be1);
			com.sc.cash.payment.mobile.v1.invoice.BillerCategory b2= new com.sc.cash.payment.mobile.v1.invoice.BillerCategory();
			TempBillerCategoryVO temp=AggregatorMappingHelper.getBillerResponseSingleMapping(b1);
			System.out.println(temp);
			assertNotNull(temp);*/
	
	List<TempBillerCategoryVO> tempcategory = new ArrayList<TempBillerCategoryVO>();
	
		TempBillerCategoryVO t1=new TempBillerCategoryVO();
		TempBillerVO tb1= new TempBillerVO();
		tb1.setBillerId("1");
		tb1.setBillerDesc("Vodafone");
		t1.setCategoryId("1");	
		t1.setCategoryName("telecommunication");	
		
		
		TempBillerField tf1=new TempBillerField();
		tf1.setFieldLabelName("mobileno");
		tb1.getBillerFields().add(tf1);
		t1.getBillers().add(tb1);
		
		TempBillerCategoryVO t2=new TempBillerCategoryVO();
		TempBillerVO tb2= new TempBillerVO();
		tb2.setBillerId("2");
		tb2.setBillerDesc("jntucollege");
		t2.setCategoryName("Education");


		TempBillerField tf2=new TempBillerField();
		tf2.setFieldLabelName("hallticketno");
		tb2.getBillerFields().add(tf2);
		t2.getBillers().add(tb2);
		
		t2.setCategoryId("2");	
		tempcategory.add(t1);
		tempcategory.add(t2);
		
		List<BillerCategoryVO> Master =new ArrayList<BillerCategoryVO>();
	//	AggregatorMappingHelper.getMappingempBillersToMasterBiller(tempcategory,Master);
		System.out.println(Master);
		assertNotNull(Master);	
		}
}
