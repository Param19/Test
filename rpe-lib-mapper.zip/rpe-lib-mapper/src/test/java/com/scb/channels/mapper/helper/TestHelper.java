package com.scb.channels.mapper.helper;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author 1411807
 *
 */
public class TestHelper {
	
	public static final String CUST_NAME= "Sachin";
	public static final String CUSTOMER_ID= "000000001";
	public static final String CUSTOMER_TYPE= "FOA";
	public static final String BILL_PAY_CUSTOMER_TYPE= "01";
	public static final String ROLE= "FOA_CUST_NG";
	public static final String ENVIRONMENT= "Local";
	public static final String LOGIN_ID= "000002002";
	public static final String SEGMENT_CODE= "01";
	public static final String CHANNEL_IBNK= "IBNK";
	public static final String CHANNEL_ADC= "ADC";
	public static final String COUNTRY= "NG";
	public static final String CHANNEL= "IBNK";
	public static final String CLIENT_ID= "1122";
	public static final String ORG= "IBK";
	public static final String APP_NAME= "NFSIBNK";
	public static final String SESSION_ID= "10101";
	
	public static final String BILLER_NAME= "Airtel";
	public static final String BILLER_PAY_REF= "Ref";
	public static final String DB_ACC_SRC_TYPE= "CASA";
	public static final String BILLER_CD= "1005";
	public static final String BILLER_DESC= "Biller";
	public static final String UTILITY_CD= "10000";
	public static final String UTILITY_DESC= "Utility";
	public static final String CONSUMER_NO= "12345";
	public static final String CONSUMER_DESC= "Consumer";
	public static final String TXN_TYPE_CD= "Txn";
	public static final String BANK_NAME= "SCB";
	public static final String BRANCH_NAME= "SCB1";
	public static final String CURRENCY= "NGN";
	public static final String ACC_NUM= "000000001";
	public static final String PRODUCT_CODE= "112233";
	public static final String UNIVERSAL_ACC_NUM= "000000001";
	public static final String MEMO= "Memo";
	
	private static ApplicationContext context = null;
	
	public static ApplicationContext getContext(){
		if (context == null) {
			context = new ClassPathXmlApplicationContext("spring/*-context.xml");
		}
		return context;
	}
	

	private TestHelper() { }

}
