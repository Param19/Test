package com.scb.channels.Billers;

import java.util.List;

import com.sc.cash.payment.mobile.v1.invoice.BillerCategory;
import com.sc.cash.payment.mobile.v1.invoice.BillerCategoryList;
import com.sc.cash.payment.mobile.v1.invoice.InvoiceInfo;

public class TestData extends InvoiceInfo {
	
  	 
	public static InvoiceInfo  getTestdata(){
		TestData t= new TestData();
		
		
		BillerCategory b= new BillerCategory();
		b.setCategoryID("1");
		b.setCategoryName("telecommunication");
		BillerCategory b2= new BillerCategory();
		b.setCategoryID("2");
		b.setCategoryName("Education");
		t.getBillerCategory().add(b);
		t.getBillerCategory().add(b2);
		 
		return t;
	}
	

}
