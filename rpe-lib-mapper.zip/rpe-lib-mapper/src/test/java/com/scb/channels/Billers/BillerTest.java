package com.scb.channels.Billers;

import static org.junit.Assert.*;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import junit.framework.Assert;

import org.junit.Test;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerTypeVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.common.Biller;
import com.scb.channels.common.ClientContext;
import com.scb.channels.common.Consumer;
import com.scb.channels.common.MessageContext;
import com.scb.channels.common.ServiceContext;
import com.scb.channels.common.UserContext;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.paymentservice.BillerBycategoryRequest;
import com.scb.channels.paymentservice.BillerBycategoryResponse;
import com.scb.channels.paymentservice.BillerNameBycategoryReponse;
import com.scb.channels.paymentservice.PayeeDetails;

public class BillerTest {

	//@Test
	public void testRequest() {
		 
		UserContext userContext =new UserContext();
		ClientContext clientContext=new ClientContext();
		ServiceContext serviceContext=new ServiceContext();
		MessageContext messageContext=new MessageContext();
		userContext.setCustName("CUSTOMER");
		userContext.setCustomerId("TEST01");
		userContext.setCustomerIdType("01");
		clientContext.setAppName("IBK");
		clientContext.setClientId("130827-152150710-959283-244");
		clientContext.setCountry("SG");
		messageContext.setRequestCode("130827-152150710-959283-244");

		 
		PayeeDetails payee= new PayeeDetails();
		Biller biller = new Biller();
		 biller.setBillerCategoryName("telecommunication");
		 biller.setBillerCategoryId("200");
		 biller.setDefaultAmount(200);
		 
		payee.setBillerDetails(biller);
		 
		Consumer con= new Consumer();
		con.setConsumerDesc("my name");
		con.setConsumerNo("9884564685");
		payee.setConsumer(con);
		payee.setPayeeId("10010");
		payee.setStatus("A");
		payee.setLastUpdatedDate(getGregorianCalendar());
		
		BillerBycategoryRequest ad= new BillerBycategoryRequest();
	
		ad.setUserContext(userContext);
		ad.setMessageContext(messageContext);
		ad.setServiceContext(serviceContext);
		ad.setClientContext(clientContext);
		
		BillerPayRequestVO  BillerVo=BillpaymentMappingHelper.getBillerCategoryRequest(ad);
		System.out.println(BillerVo);
		Assert.assertNotNull(BillerVo);
		
		//PayeeDetailVO pay=BillpaymentMappingHelper.getAddPayeeserviceMapping(BillerVo);
		 
		//Assert.assertNotNull(pay);
	}
		
	@Test
	public void testBillersResponse(){
		
		
		BillerPayResponseVO response = new BillerPayResponseVO();
		
		BillerPayDetailsVO details= new BillerPayDetailsVO();
		
		BillerCategoryVO bo= new BillerCategoryVO();
		BillerVO b1  = new BillerVO();
		BillerVO b2 =new BillerVO();
		b1.setBillerId("101");
		 
		b2.setBillerId("102");
		 
		
		bo.getBillers().add(b1);
		bo.getBillers().add(b2);

		//details.getBillerCategoryVO().add(bo);
		response.setBillerPayDetailsVO(details);
		response.setStatus("101");
		response.setStatusDesc("one not one");
		response.setErrorCD("102");
		response.setErrorDesc("one not two");
		
		BillerNameBycategoryReponse resp=BillpaymentMappingHelper.getBillerNamesResponseMapping(response);
		 
		System.out.println(resp);
		assertNotNull(resp);
		
		
	}
	
		
		/*public void testBillerCategoryResponse(){
			
			
			BillerPayResponseVO response = new BillerPayResponseVO();
			
			BillerPayDetailsVO details= new BillerPayDetailsVO();
			
			BillerCategoryVO type= new BillerCategoryVO();
			type.setId("1001");
			type.setCategoryName("telecommunication");
		 
			BillerCategoryVO type2= new BillerCategoryVO();
			type2.setBillerTypeCd("1003");
			type2.setBillerTypeDesc("education");
		 
			details.getBillerCategoryVO().add(type);
			
			details.getBillerCategoryVO().add(type2);
			
			
		 
			response.setBillerPayDetailsVO(details);
			response.setStatus("123");
			response.setStatusDesc("added biller found");
			response.setErrorCD("12312");
			
			BillerBycategoryResponse bp=BillpaymentMappingHelper.getBillerCategories(response);
			System.out.println(bp);
			assertNotNull(bp);
			
		}
	*/
	
	
	private static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
			return date;
		}

}
