package com.scb.channels.Billers;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.junit.Test;

import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.ReverseCardPurchaseReq;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.mapper.helper.DebitCardMappingHelper;

public class DebitCardTest {
	@Test
	public void testQRPaymentRequestMapping(){

		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		
		qrPaymentDetailVO.setClient_reference("NFS_0001");
		qrPaymentDetailVO.setHost_reference("123456789101");
		qrPaymentDetailVO.setHost_system("VISA");
		qrPaymentDetailVO.setHostResponseCode("00");
		qrPaymentDetailVO.setHostResponseDesc("APPROVED");
		qrPaymentDetailVO.setHostReasonCode("05");
		
		qrPaymentDetailVO.setMerchantCategoryCode("3456");
		qrPaymentDetailVO.setMerchantCity("Delhi");
		qrPaymentDetailVO.setMerchantPostalCode("600333");
		qrPaymentDetailVO.setTipOrConvenienceFee(new BigDecimal(10.00));
		qrPaymentDetailVO.setTxnAmount(new BigDecimal(100.00));
		qrPaymentDetailVO.setTxnCurrencyCode("356");
		
		QRMerchantPanTypeVO merchantpan = new QRMerchantPanTypeVO();
		merchantpan.setRefId("04");
		merchantpan.setRefValue("55345436783456453");
		qrPaymentDetailVO.getMerchantPanList().add(merchantpan);
		
		QRMerchantPanTypeVO merchantpan1 = new QRMerchantPanTypeVO();
		merchantpan1.setRefId("02");
		merchantpan1.setRefValue("4345643334566544");
		qrPaymentDetailVO.getMerchantPanList().add(merchantpan1);
		
		qrPaymentDetailVO.setAccountCurrency("INR");
		qrPaymentDetailVO.setAccountNumber("424105046466");
		qrPaymentDetailVO.setCardNumber("5546232908812323");
		qrPaymentDetailVO.setTotalPaymentAmt(new BigDecimal(110.00));
		//System.out.println("::::::::::::::::::"+getGregorianCalendar());
		qrPaymentDetailVO.setPaymentDate(new Timestamp(20170325));
		qrPaymentDetailVO.setHost_txn_Identifier("21345");
		qrPaymentDetailVO.setSourceOfFund("CARD");
		qrPaymentDetailVO.setPayment_status("AGGSUCC");
		qrPaymentDetailVO.setCustomerId("0000022122");
		qrPaymentDetailVO.setCustomerType("02");
		qrPaymentDetailVO.setCustomer_full_name("XXXXXX");
		qrPaymentDetailVO.setStan("100001");
		qrPaymentDetailVO.setHost_reference("201705080001");
		qrPaymentDetailVO.setCardExpiryDate("2112");
		//AuthorizeCardPurchaseReq request = DebitCardMappingHelper.getDebitCardAuthorizationRequest(qrPaymentDetailVO);
		ReverseCardPurchaseReq reverseRequest = DebitCardMappingHelper.getDebitCardReverseAuthorizationRequest(qrPaymentDetailVO);
		System.out.println(reverseRequest.toString());
	}
	
	private static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			System.out.println("date.............."+date);
		} catch (DatatypeConfigurationException e) {
		}
			return date;
		}

}
