/**
 * 
 */
package com.scb.channels.mapper.helper;


 
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.invoice.Invoice;
import com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo;
import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.invoice.TransactionStatus;
import com.sc.cash.payment.mobile.v2.invoice.TransactionStatus2;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentStatusReq;
import com.sc.corebanking.v1.transaction.Transaction;
import com.sc.corebanking.v1.transaction.TransactionInfo;
import com.sc.corebanking.v5.customer.GetCustomerContactDetails;
import com.sc.corebanking.v5.customer.GetCustomerContactDetailsReqPayload;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerContactDetailsReq;
import com.sc.corebanking.v6.account.GetAccountDetails;
import com.sc.corebanking.v6.account.GetAccountDetailsReqPayload;
import com.sc.corebanking.v6.transaction.PostTransactionReqPayload;
import com.sc.corebanking.v6.ws.provider.account.GetAccountDetailsReq;
import com.sc.scbcorebankinginvoice.v1.ws.provider.invoice.PayBillRes;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.GetTransactionReq;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.GetTransactionRes;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.ReverseTransactionReq;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.ReverseTransactionRes;
import com.sc.scbml_1.DomainName;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.GetPaymentDetailsReqPayload;
import com.sc.scbml_1.GetPaymentStatusReqPayload;
import com.sc.scbml_1.GetTransactionReqPayload;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.MessageSender;
import com.sc.scbml_1.MessageSenderType;
import com.sc.scbml_1.MessageType;
import com.sc.scbml_1.OriginationDetailsType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.ProcessType;
import com.sc.scbml_1.ReverseTransactionReqPayload;
import com.sc.scbml_1.SCBMLHeaderType;
import com.sc.scbml_1.SenderDomainType;
import com.sc.scbml_1.SubDomainName;
import com.sc.scbml_1.SubType;
import com.sc.scbml_1.TagType;
import com.sc.scbml_1.TagsType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.BillPresentmentRequestVO;
import com.scb.channels.base.vo.BillPresentmentResponseVO;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerFieldItemVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerServiceRequestVO;
import com.scb.channels.base.vo.BillerServiceResponseVO;
import com.scb.channels.base.vo.BillerUtilityRequestVO;
import com.scb.channels.base.vo.BillerUtilityResponseVO;
import com.scb.channels.base.vo.ChannelMasterVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.MenuResponseParams;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.PaymentHistoryResponseVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.paymentservice.AddPayeeRequest;
import com.scb.channels.paymentservice.AddPayeeResponse;
import com.scb.channels.paymentservice.BillPresentmentRequest;
import com.scb.channels.paymentservice.BillPresentmentResponse;
import com.scb.channels.paymentservice.BillerBycategoryRequest;
import com.scb.channels.paymentservice.BillerBycategoryResponse;
import com.scb.channels.paymentservice.BillerNameBycategoryReponse;
import com.scb.channels.paymentservice.BillerNameBycategoryRequest;
import com.scb.channels.paymentservice.DeletePayeeRequest;
import com.scb.channels.paymentservice.DeletePayeeResponse;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountRequest;
import com.scb.channels.paymentservice.GetCustomerOverallPaymentAmountResponse;
import com.scb.channels.paymentservice.GetPayeeRequest;
import com.scb.channels.paymentservice.GetPayeeResponse;
import com.scb.channels.paymentservice.JobServiceRequest;
import com.scb.channels.paymentservice.JobServiceResponse;
import com.scb.channels.paymentservice.PaymentHistoryRequest;
import com.scb.channels.paymentservice.PaymentHistoryResponse;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.PaymentResponse;
import com.scb.channels.paymentservice.ValidatePayeeRequest;
//import com.sc.cash.payment.mobile.v1.invoice.Invoice;
import com.scb.channels.paymentservice.ValidatePayeeResponse;


// TODO: Auto-generated Javadoc

public final class BillpaymentMappingHelper extends MappingHelper {
	

	public static final String YYYY_MM_DD = "yyyy-MM-dd";

	public static final String MM_DD_YYYY = "MM-dd-yyyy";

	/** The Constant DEB_NARR. */
	public static final String DEB_NARR = "debNarr";

	/** The Constant CREDIT_NARR. */
	public static final String CREDIT_NARR = "creditNarr";

	/** The Constant PAY_REQ_MAP. */
	public static final String PAY_REQ_MAP = "payReqMap";

	/** The Constant GUID. */
	public static final String GUID = "http://www.sc.com/cashAddBillerRequest";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(BillpaymentMappingHelper.class);
	
	/** The Constant PAYMENT_XML. */
	public static final String PAYMENT_XML = "com/scb/channels/mapper/vo/mapping/PaymentsBeanMapping.xml";

	/**
	 * Instantiates a new billpayment mapping helper.
	 */
	private BillpaymentMappingHelper() {
	}
	
	static{
		MAPPER_FILES.add(PAYMENT_XML);
		reloadMapper();
	}
	
	
	 /**
 	 * Gets the adds the AuditServiceVO  mapping.
 	 *
 	 * @param request is the BillerPayRequestVO
 	 * @return the adds the AuditServiceVO   mapping
 	 */
 	public static AuditServiceVO getAuditServiceVOMapping(BillerPayRequestVO RequestVo) {
			return  MappingHelper.MAPPER.map(RequestVo, AuditServiceVO.class);
		}
  
	/**
	 * Gets the menu param biller service response mapping.
	 *
	 * @param billerServiceResponseVO the biller service response vo
	 * @return the menu param biller service response mapping
	 */
	public static MenuResponseParams getMenuParamBillerServiceResponseMapping(BillerServiceResponseVO billerServiceResponseVO){
		return MappingHelper.MAPPER.map(billerServiceResponseVO, MenuResponseParams.class);
	}
	
	
 
	/**
	 * Gets the bilpayment request mapping.
	 *
	 * @param channelMasterVO the channel master vo
	 * @return the bilpayment request mapping
	 */
	public static BillerPayRequestVO getBilpaymentRequestMapping(ChannelMasterVO channelMasterVO) {
		
		return MappingHelper.MAPPER.map(channelMasterVO,BillerPayRequestVO.class);
	}
	
	/**
	 * Gets the biller pay response.
	 *
	 * @param responseVO the response vo
	 * @return the biller pay response
	 */
	public static MenuResponseParams getBillerPayResponse(BillerPayResponseVO responseVO) {
		return MappingHelper.MAPPER.map(responseVO, MenuResponseParams.class);
	}
	
	
	/**
	 * Gets the bill presentment request mapping.
	 *
	 * @param channelMasterVO the channel master vo
	 * @return the bill presentment request mapping
	 */
	public static BillPresentmentRequestVO getBillPresentmentRequestMapping(ChannelMasterVO channelMasterVO) {
		
		return MappingHelper.MAPPER.map(channelMasterVO,BillPresentmentRequestVO.class);
	}
	
	/**
	 * Gets the bill presentment response.
	 *
	 * @param responseVO the response vo
	 * @return the bill presentment response
	 */
	public static MenuResponseParams getBillPresentmentResponse(BillPresentmentResponseVO responseVO) {
		return MappingHelper.MAPPER.map(responseVO, MenuResponseParams.class);
	}
	
	
	/**
	 * Gets the audit service bill presentment request mapping.
	 *
	 * @param billPresentmentRequestVO the bill presentment request vo
	 * @return the audit service bill presentment request mapping
	 */
	public static AuditServiceVO getAuditServiceBillPresentmentRequestMapping(BillPresentmentRequestVO billPresentmentRequestVO){
		return MappingHelper.MAPPER.map(billPresentmentRequestVO,AuditServiceVO.class);
	}
	 
	 
	public static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
			return date;
		}

	 
	 
	
	/**
	 * Populate aggregator payment header.
	 *
	 * @param country the country
	 * @param channel the channel
	 * @param date2 the date2
	 * @param requestCode the request code
	 * @param typeName the type name
	 * @param subTypeName the sub type name
	 * @param msgSender the msg sender
	 * @param dmnName the dmn name
	 * @param subDmnName the sub dmn name
	 * @return the sCBML header type
	 */
	  
 	public static String convertStringToSqlDate(String dateString) {
	        java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat(YYYY_MM_DD);
	        Date date = null;
	        String  dueDate=null;
	        try {
	             date = dateFormat.parse(dateString);
	             DateFormat formatter = new SimpleDateFormat(MM_DD_YYYY); 
	             dueDate=formatter.format(date);
   	        } catch (ParseException e) {
   	        	LOGGER.error("Unable to convert date from string" + dateString, e.getCause() );
	        }
	        return dueDate ;
	 }
	 
	 /**
 	 * Gets the adds the biller request vo mapping.
 	 *
 	 * @param addBillerRequest the add biller request
 	 * @return the adds the biller request vo mapping
 	 */
 	 

 	 
 	
 	public static BillerBycategoryResponse getBillerCategories(BillerPayResponseVO category) {
		return  MappingHelper.MAPPER.map(category, BillerBycategoryResponse.class);
		
	}
 	
 	
 	
	public static BillerPayRequestVO getBillerCategoryRequest(BillerBycategoryRequest category) {
		return  MappingHelper.MAPPER.map(category, BillerPayRequestVO.class); 
		
	}
 	
	
	/**
	 * @param BillerBycategoryRequest
	 * @return BillerPayRequestVO
	 */
	public static BillerPayRequestVO getBillerNamesRequestMapping(BillerNameBycategoryRequest category) {
		return  MappingHelper.MAPPER.map(category, BillerPayRequestVO.class); 
		
	}
 	
 	
	/**
	 * @param BillerPayResponseVO
	 * @return BillerNameBycategoryReponse
	 */
	public static BillerNameBycategoryReponse getBillerNamesResponseMapping(BillerPayResponseVO category) {
		return  MappingHelper.MAPPER.map(category, BillerNameBycategoryReponse.class); 
		
	}
	
 	
 	
	 /**
 	 * Gets the adds the biller response vo mapping.
 	 *
 	 * @param responseVO the response vo
 	 * @return the adds the biller response vo mapping
 	 */
 	 
 	
 	
 	/**
 	 * @param getPayeeRequest
 	 * @return
 	 */
 	public static ViewPayeeRequestVO getViewBillerRequestVOMapping(GetPayeeRequest getPayeeRequest) {
			return  MappingHelper.MAPPER.map(getPayeeRequest, ViewPayeeRequestVO.class);
			
		}
	
	 
	 	
 	
 	/**
 	 * @param responseVO
 	 * @return
 	 */
 	public static GetPayeeResponse getViewPayeeResponseVOMapping(ViewPayeeResponseVO viewPayeeResponseVO) {
			return MappingHelper.MAPPER.map(viewPayeeResponseVO, GetPayeeResponse.class);
		}

	/**
	 * Perform add biller payment request.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the adds the biller req
	 */
	 
	 /**
 	 * Gets the pay bill response mapping.
 	 *
 	 * @param responseVO the response vo
 	 * @return the pay bill response mapping
 	 */
 	public static PaymentResponse getPayBillResponseMapping(BillerPayResponseVO responseVO) {
			return MappingHelper.MAPPER.map(responseVO, PaymentResponse.class);
		}

	/**
	 * Perform account inquiry request.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the gets the customer enrolments req
	 */
	 

	 
	
	  

	
	/**
	 * Perform bill pay mapping.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the com.sc.cashpaybillrequest. mfep
	 */
	
	 

	 
 
	 
 
	
	 

	 
	
	/**
	 * Perform get bill present ment request.
	 *
	 * @param getBillDetailsRequest the get bill details request
	 * @return the biller pay request vo
	 */
	public static BillerPayRequestVO performGetBillPresentMentRequest(BillPresentmentRequest getBillDetailsRequest) {
		return  MappingHelper.MAPPER.map(getBillDetailsRequest, BillerPayRequestVO.class);
	}
	
	/**
	 * Perform get bill present ment response.
	 *
	 * @param responseVO the response vo
	 * @return the bill presentment response
	 */
	public static BillPresentmentResponse performGetBillPresentMentResponse(BillerPayResponseVO responseVO) {
		return  MappingHelper.MAPPER.map(responseVO, BillPresentmentResponse.class);
	}

	 
	/**
	 * Gets the audit service biller utility request mapping.
	 *
	 * @param billerUtilityRequestVO the biller utility request vo
	 * @return AuditServiceVO
	 */
	public static AuditServiceVO getAuditServiceBillerUtilityRequestMapping(BillerUtilityRequestVO billerUtilityRequestVO){
		return MappingHelper.MAPPER.map(billerUtilityRequestVO,AuditServiceVO.class);
	}
	
	/**
	 * Gets the audit service biller service request mapping.
	 *
	 * @param billerServiceRequestVO the biller service request vo
	 * @return AuditServiceVO
	 */
	public static AuditServiceVO getAuditServiceBillerServiceRequestMapping(BillerServiceRequestVO billerServiceRequestVO){
		return MappingHelper.MAPPER.map(billerServiceRequestVO,AuditServiceVO.class);
	}
	
	/**
	 * Audit transform request object.
	 *
	 * @param billerPayRequestVO the transfer request vo
	 * @return the audit sum txn vo
	 */
	public static AuditSumTxnVO auditTransformRequestObject(BillerPayRequestVO billerPayRequestVO){
		return MappingHelper.MAPPER.map(billerPayRequestVO, AuditSumTxnVO.class);
	}
	
	
	/**
	 * Populate request vo.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @param billerPayDetailsVO
	 *            the biller pay details vo
	 * @return the transfer request vo
	 */
	public static BillerPayRequestVO populateRequestVO(AuditSumTxnVO auditSumTxnVO, BillerPayDetailsVO billerPayDetailsVO) {
		BillerPayRequestVO requestVO = new BillerPayRequestVO();
		UserVO userVO = MappingHelper.MAPPER.map(auditSumTxnVO, UserVO.class) ;
		userVO.setLoginId(auditSumTxnVO.getAuditBy());
		userVO.setCustomerIdType(auditSumTxnVO.getCustIdType());
		requestVO.setUser(userVO);
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName(auditSumTxnVO.getFuncCd());
		serviceVO.setHostEnv(auditSumTxnVO.getEnvironment());
		requestVO.setServiceVO(serviceVO);
		//Added to match the record for regular entry and retry in audit
		billerPayDetailsVO.setBillerCd(auditSumTxnVO.getFromAcctName());
		//End
		MessageVO messageVO = new MessageVO();
		messageVO.setRequestCode(auditSumTxnVO.getTxnId());
		messageVO.setReqID(auditSumTxnVO.getTxnId());
		requestVO.setMessageVO(messageVO);
		ClientVO clientVO=new ClientVO();
		clientVO.setChannel(CommonConstants.DOMAIN_TYPE);
		clientVO.setClientId(billerPayDetailsVO.getTransactionInfoVO().getUserVO().getRequestId());
		clientVO.setCountry(billerPayDetailsVO.getTransactionInfoVO().getUserVO().getCountry());
		clientVO.setSessionId(auditSumTxnVO.getSessionId());
		requestVO.setClientVO(clientVO);
		billerPayDetailsVO.getTransactionInfoVO().setClientVO(clientVO);
		billerPayDetailsVO.getTransactionInfoVO().setMessageVO(messageVO);
		billerPayDetailsVO.getTransactionInfoVO().setServiceVO(serviceVO);
		requestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		return requestVO;
	}
	public static BillerUtilityRequestVO getBillerUtilityRequsetVOMapping(ChannelMasterVO channelMasterVO){
		return MappingHelper.MAPPER.map(channelMasterVO, BillerUtilityRequestVO.class);
	}
	
	/**
	 * Gets the biller service requset vo mapping.
	 *
	 * @param channelMasterVO the channel master vo
	 * @return the biller service requset vo mapping
	 */
	public static BillerServiceRequestVO getBillerServiceRequsetVOMapping(ChannelMasterVO channelMasterVO){
		return MappingHelper.MAPPER.map(channelMasterVO, BillerServiceRequestVO.class);
	}
	public static MenuResponseParams getMenuParamBillerUtilityResponseMapping(BillerUtilityResponseVO billerUtilityResponseVO){
		return MappingHelper.MAPPER.map(billerUtilityResponseVO, MenuResponseParams.class);
	}
	
	//Added for Customer Overall Payment Amount Service
	 public static CustomerPaymentAmountRequestVO getCustomerOverallPaymentAmountRequestMapping(GetCustomerOverallPaymentAmountRequest paymentAmountRequest) {
		 LOGGER.info("Inside BillpaymentMappingHelper -> getCustomerOverallPaymentAmountRequestMapping");
		 return MappingHelper.MAPPER.map(paymentAmountRequest, CustomerPaymentAmountRequestVO.class);
	 }
	 
	 public static GetCustomerOverallPaymentAmountResponse getCustomerOverallPaymentAmountResponseMapping(CustomerPaymentAmountResponseVO paymentAmountResponseVO) {
		 return MappingHelper.MAPPER.map(paymentAmountResponseVO, GetCustomerOverallPaymentAmountResponse.class);
	 }
	 
	 // Audit Service Mapping -  Overall Payment Amount Service
	public static AuditServiceVO getPaymentAmountRespAuditService(CustomerPaymentAmountResponseVO  amountResponseVO) {
			return   MAPPER.map(amountResponseVO, AuditServiceVO.class);
		}
	public static AuditServiceVO getPaymentAmountReqAuditService(CustomerPaymentAmountRequestVO  amountRequestVO) {
		return   MAPPER.map(amountRequestVO, AuditServiceVO.class);
	}
		
	//ends Customer Overall Payment Amount
	 
	 
	/** Request Mapping -  Payment History Service*/ 
	public static PaymentHistoryRequestVO getPaymentHistoryRequest(PaymentHistoryRequest paymentHistReq) {
		PaymentHistoryRequestVO payHis = new PaymentHistoryRequestVO();
		try{
		 payHis =  MappingHelper.MAPPER.map(paymentHistReq,PaymentHistoryRequestVO.class);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("---------------------------e"+e.getMessage());
		}
		return payHis;
	}

	/** Response Mapping -  Payment History Service*/
	public static PaymentHistoryResponse getPaymentHistoryResponse(PaymentHistoryResponseVO paymentHistRes) {
		return MappingHelper.MAPPER.map(paymentHistRes,PaymentHistoryResponse.class);

	}
	
	/** Audit Service Mapping -  Payment History Service*/
	public static AuditServiceVO getPaymentHistoryRespAuditService(PaymentHistoryResponseVO paymentHistoryResponseVO) {
		return   MAPPER.map(paymentHistoryResponseVO, AuditServiceVO.class);
	}
	
	
	/** Audit Service Mapping -  Payment History Service*/
	public static AuditSumTxnVO getPaymentRespAuditTxnService(BillerPayResponseVO billerPayResponseVO) {
		try{
		return   MAPPER.map(billerPayResponseVO, AuditSumTxnVO.class);
		}catch(Exception e){
			System.out.println("---------------"+e.getMessage());
			return null;
			}
	}
	
	
	
	/**
 	 * Gets the adds the biller request vo mapping.
 	 *
 	 * @param addBillerRequest the add biller request
 	 * @return the adds the biller request vo mapping
 	 */
 	public static BillerPayRequestVO getAddPayeeRequestVOMapping(AddPayeeRequest addPayeeRequest) {
			return  MappingHelper.MAPPER.map(addPayeeRequest, BillerPayRequestVO.class);
			
		}
 	/**
 	 * Gets the adds the biller request vo mapping.
 	 *
 	 * @param addBillerRequest the add biller request
 	 * @return the adds the biller request vo mapping
 	 */
 	public static BillerPayRequestVO getAddPayeeRequestVOMapping(ValidatePayeeRequest validatePayeeRequest) {
			return  MappingHelper.MAPPER.map(validatePayeeRequest, BillerPayRequestVO.class);
			
		}
	 /**
		 * @param billerPayRequestVO
		 * @return
		 */
    public static PayeeDetailVO getAddPayeeserviceMapping(BillerPayRequestVO billerPayRequestVO){
		 
		 return MappingHelper.MAPPER.map(billerPayRequestVO, PayeeDetailVO.class);
		 
	 }

		

     /**
	 * Gets the adds the biller response vo mapping.
	 *
	 * @param responseVO the response vo
	 * @return the adds the biller response vo mapping
	 */
	public static AddPayeeResponse getAddPayeeResponseVOMapping(BillerPayResponseVO responseVO) {
		return MappingHelper.MAPPER.map(responseVO, AddPayeeResponse.class);
	}

	
	/**
 	 * Gets the delete biller request vo mapping.
 	 *
 	 * @param deleteBillerRequest the delete biller request
 	 * @return the delete biller request vo mapping
 	 */
 	public static BillerPayRequestVO getDeletePayeeRequestVOMapping(DeletePayeeRequest deletePayeeRequest) {
			return  MappingHelper.MAPPER.map(deletePayeeRequest, BillerPayRequestVO.class);
			
		}
	
 	public static PayeeDetailVO getDeletePayeeserviceMapping(BillerPayRequestVO billerPayRequestVO){
		 
		 return MappingHelper.MAPPER.map(billerPayRequestVO, PayeeDetailVO.class);
		 
	 }
 	
 	 /**
 	 * Gets the delete biller response vo mapping.
 	 *
 	 * @param responseVO the response vo
 	 * @return the delete biller response vo mapping
 	 */
 	public static DeletePayeeResponse getDeletePayeeResponseVOMapping(BillerPayResponseVO responseVO) {
			return MappingHelper.MAPPER.map(responseVO, DeletePayeeResponse.class);
		}
 	


	 
		 /**
		 * Biller Pay request.
		 *
		 * @param billerPayRequestVO the billerPay request vo
		 * @return the Reverse Transaction Req
		 */
		public static ReverseTransactionReq performReverseBillPaymentRequestPayload(BillerPayRequestVO billerPayRequestVO){
			
			ReverseTransactionReq reverseTransactionReq = new ReverseTransactionReq();
			
			ReverseTransactionReqPayload reverseTransactionReqPayload = new ReverseTransactionReqPayload();
			reverseTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
			reverseTransactionReqPayload.setOperationType(CommonConstants.REVERSE_TRANSACTION);
			reverseTransactionReqPayload.setPayloadVersion(CommonConstants.VERSION);
			
			Transaction transaction = new Transaction();
			TransactionInfo transactionInfo = new TransactionInfo();
			transactionInfo.setUniqueReferenceIdentifier(billerPayRequestVO.
					getBillerPayDetailsVO().getHostReference());
			transactionInfo.setChannelID(CommonConstants.EBBS_CHANNEL_ID);
			/*transactionInfo.setForcePostFlag(CommonConstants.FLAG_NO);
			transactionInfo.setApproveInSufficientFundsFlag(CommonConstants.FLAG_NO);*/
			
			/*XMLGregorianCalendar transactionPostDate = getGregorianCalendar();
			
			Maker  maker = new Maker();
			maker.setDate(transactionPostDate);
			maker.setTime("00:00:00.000");
			transactionInfo.setMaker(maker);
			
			Checker checker = new Checker();
			checker.setDate(transactionPostDate);
			checker.setTime("00:00:00.000");
			transactionInfo.setChecker(checker);*/
			
			transaction.setTransactionInfo(transactionInfo);
			reverseTransactionReqPayload.setReverseTransactionReq(transaction);
			reverseTransactionReq.setReverseTransactionReqPayload(reverseTransactionReqPayload);
			reverseTransactionReq.setHeader(populateSCBMLHeader(billerPayRequestVO,CommonConstants.REVERSE_TRANSFER_SUB_TYPE_NAME,
								CommonConstants.REVERSE_TRANSFER_MESSAGE_TYPE_NAME,	CommonConstants.REVERSE_TARNSFER_EVENT_TYPE,CommonConstants.REVERSE_IFT_PROCESSNAME));
			return reverseTransactionReq;
			
		}

				/**
		 * Gets the reversal fund transfer response.
		 *
		 * @param reverseTransactionRes the reverse transaction res
		 * @param billerPayRequestVO the biller pay request vo
		 * @return the reversal fund transfer response
		 */
		public static BillerPayResponseVO getReversalBillPaymentResponse(
				ReverseTransactionRes reverseTransactionRes, BillerPayRequestVO billerPayRequestVO){
			
			BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
			BillerPayDetailsVO billpayDetails = billerPayRequestVO.getBillerPayDetailsVO();
			
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			
			try{
				if (reverseTransactionRes.getHeader().getExceptions() != null) {
					// Check if there is any exception from eBBS response
					for (ExceptionType exceptionType : reverseTransactionRes.getHeader()
							.getExceptions().getException()) {
						LOGGER.info("Exceptions present in the reversal response ::: " +	billpayDetails.getPayRef());
						LOGGER.info("Reversal Exceptions code ::: " + exceptionType.getCode().getValue() 
								+ " ::: " +	billpayDetails.getPayRef());
						LOGGER.info("Reversal Exceptions description ::: " +	exceptionType.getDescription()
								+ " ::: " +	billpayDetails.getPayRef());
						
						if (exceptionType.getCode().getValue()
								.equals(CommonConstants.TIMEOUT_CODE)) {
							
							LOGGER.info("Reversal Timeout occurred ::: " 
									+ billpayDetails.getPayRef()
									+ exceptionType.getCode().getValue()
									+ exceptionType.getDescription());
							
							billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_TIMEOUT);
							billpayDetails.getTransactionInfoVO()
									.setTxnStatusCd(CommonConstants.TIMEOUT);
							
							billerPayResponseVO.setStatus(ExceptionMessages._124
									.getCode());
							billerPayResponseVO.setStatusDesc(ExceptionMessages._124
									.getMessage());
							billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
						} else if (exceptionType.getCode().getValue()
								.equals("112")) {
							
							LOGGER.info("Reversal already done ::: " 
									+ billpayDetails.getPayRef()
									+ exceptionType.getCode().getValue()
									+ exceptionType.getDescription());
							
							billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_SUCCESS);
							billpayDetails.getTransactionInfoVO()
									.setTxnStatusCd(CommonConstants.SUCC);
							
							billerPayResponseVO.setStatus(ExceptionMessages._124
									.getCode());
							billerPayResponseVO.setStatusDesc(ExceptionMessages._124
									.getMessage());
							billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
						} else if (exceptionType.getCode().getValue()
								.equals("90749")) {
							
							LOGGER.info("Transaction not available for reversal ::: " 
									+ billpayDetails.getPayRef()
									+ exceptionType.getCode().getValue()
									+ exceptionType.getDescription());
							
							billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_SUCCESS);
							billpayDetails.getTransactionInfoVO()
									.setTxnStatusCd(CommonConstants.SUCC);
							
							billerPayResponseVO.setStatus(ExceptionMessages._124
									.getCode());
							billerPayResponseVO.setStatusDesc(ExceptionMessages._124
									.getMessage());
							billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
						} else {
							LOGGER.info("Reversal Failed ::: " 
									+ billpayDetails.getPayRef()
									+ exceptionType.getCode().getValue()
									+ exceptionType.getDescription());
							
							billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
							billpayDetails.getTransactionInfoVO()
									.setTxnStatusCd(CommonConstants.FAIL);
							
							billerPayResponseVO.setStatusDesc(
									exceptionType.getDescription());
							billerPayResponseVO.setStatus(
									exceptionType.getCode().getValue());
						}
						
						billpayDetails.getTransactionInfoVO()
							.setHostRespCd(exceptionType.getCode().getValue());
						billpayDetails.getTransactionInfoVO()
							.setHostRespDesc(exceptionType.getDescription());
					}
					
				} else {
					if(reverseTransactionRes.getReverseTransactionResPayload() != null &&
							reverseTransactionRes.getReverseTransactionResPayload().
							getResponse() != null) {
						
						LOGGER.info("Reversal Successful ::: " 
								+ billpayDetails.getPayRef()
								+ reverseTransactionRes.getReverseTransactionResPayload()
									.getResponse().getCode()
								+ reverseTransactionRes.getReverseTransactionResPayload()
									.getResponse().getDescription());
						
						billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_SUCCESS);
						billpayDetails.getTransactionInfoVO()
							.setTxnStatusCd(CommonConstants.SUCC);
						
						billpayDetails.getTransactionInfoVO()
							.setHostRespCd(reverseTransactionRes
							.getReverseTransactionResPayload()
							.getResponse().getCode());
						billpayDetails.getTransactionInfoVO()
							.setHostRespDesc(reverseTransactionRes
							.getReverseTransactionResPayload()
							.getResponse().getDescription());
					
					}
				}
				
				billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
			} catch (Exception exception) {
				LOGGER.info("Exception occurred while reversal payment ::: " + exception);
				LOGGER.error("Exception occurred while reversal payment ::: " + exception);
				
				throw exception;
			}
				
			LOGGER.info("performBillPayment ::: TransactionServiceImpl ::: End");
			return billerPayResponseVO;
		}
		
		/**
		 * Gets the transfer response values.
		 *
		 * @param transaction the transaction
		 * @return the transfer response values
		 */
		public static BillerPayResponseVO getTransferResponseValues(Transaction transaction) {
			TransactionInfo transactionInfo =  transaction.getTransactionInfo();
			return MappingHelper.MAPPER.map(transactionInfo, BillerPayResponseVO.class);
		}
	 
		
		/**
		 * Pay bill response mapping.
		 *
		 * @param payBillRes the pay bill res
		 * @return the biller pay response vo
		 */
		public static BillerPayResponseVO payBillResponseMapping(PayBillRes payBillRes) {
			return MappingHelper.MAPPER.map(payBillRes,BillerPayResponseVO.class);
		}
		
		/**
		 * Pay bill request mapping.
		 *
		 * @param billerPayRequestVO the biller pay request vo
		 * @return the invoice
		 */
		public static com.sc.corebanking.v1.invoice.Invoice payBillRequestMapping(BillerPayRequestVO billerPayRequestVO) {
			
			com.sc.corebanking.v1.invoice.Invoice invoice = MappingHelper.MAPPER.map(billerPayRequestVO,com.sc.corebanking.v1.invoice.Invoice.class);
			
			if(invoice != null && invoice.getInvoiceInfo() != null) {
				invoice.getInvoiceInfo().setTransactionPostingDate(getGregorianCalendar());
			}

			return invoice;
		}
		
		public static PaymentDetailVO getPaymentDetails(BillerPayDetailsVO billerPayDetails) {
			return MappingHelper.MAPPER.map(billerPayDetails,PaymentDetailVO.class);
		}
		
		public static BillerPayDetailsVO getBillPayRequestFromPaymentDetails(PaymentDetailVO paymentDetails) {
			
			BillerPayDetailsVO billerPayDetailsVO = MappingHelper.MAPPER.map(paymentDetails,BillerPayDetailsVO.class);
			if(billerPayDetailsVO != null && paymentDetails != null 
					&& paymentDetails.getPayee() != null 
					&& paymentDetails.getPayee().getBillerVO() != null) {
				 LOGGER.info("Setting biller id with token :::: " + 
						 paymentDetails.getPayee().getBillerVO().getBillerUniqueId());
				 
				billerPayDetailsVO.setUtilityCd(paymentDetails.
						getPayee().getBillerVO().getBillerUniqueId());
			}
			return billerPayDetailsVO;
		}
		
		/**
		    * Populate scbml header.
		    *
		    * @param billerPayRequestVO the biller pay request vo
		    * @param subTypeName the sub type name
		    * @param messageTypeName the message type name
		    * @param eventType the event type
		    * @param processName the process name
		    * @return the sCBML header type
		    */
			protected static SCBMLHeaderType populateSCBMLHeader(BillerPayRequestVO billerPayRequestVO,String subTypeName,String messageTypeName,String eventType,String processName) {
				 
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				
				MessageType  messageType  = new MessageType();
				SubType subType = new SubType();
				subType.setSubTypeName(subTypeName);
				messageType.setTypeName(messageTypeName);
				messageType.setSubType(subType);
				messageDetailsType.setMessageVersion(new BigDecimal("1.0"));
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				originationDetailsType.setTrackingId(
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				originationDetailsType.setPossibleDuplicate(true);
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(CommonConstants.I_BANKING);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				
				DomainName domainName = new DomainName();
				domainName.setValue(CommonConstants.DOMAIN_NAME);
				
				SubDomainName subDomainName = new SubDomainName();
				subDomainName.setSubDomainType(subTypeName);
				
				senderDomainType.setDomainName(domainName);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setCountryCode(billerPayRequestVO.
						getBillerPayDetailsVO().getCountryCode());
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				
				XMLGregorianCalendar date = getGregorianCalendar();

				originationDetailsType.setMessageTimestamp(date);
				originationDetailsType.setInitiatedTimestamp(date);
				
				ProcessType processType = new ProcessType();
				processType.setEventType(eventType);
				processType.setProcessName(processName);
				
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				sCBMLHeaderType.setCaptureSystem(CommonConstants.CAPTURING_SYSTEM);
				sCBMLHeaderType.setProcess(processType);
				return sCBMLHeaderType;
			}
			
			   /**
			    * Populate header.
			    *
			    * @param country the country
			    * @param channel the channel
			    * @param date2 the date2
			    * @param requestCode the request code
			    * @return the sCBML header type
			    */
			   public static SCBMLHeaderType populateHeader(String country, String channel, XMLGregorianCalendar date2, String requestCode) {
					
					SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
					sCBMLHeaderType.setCaptureSystem(CommonConstants.CAPTURING_SYSTEM);
					
					ProcessType processType = new ProcessType();
					processType.setProcessName(CommonConstants.PAY_BILL);
					processType.setEventType(CommonConstants.TRANSACTION_POSTING);
					sCBMLHeaderType.setProcess(processType);
				
					
					BigDecimal bg = new BigDecimal("1.0") ;
					
					MessageDetailsType messageDetailsType = new MessageDetailsType();
					messageDetailsType.setMessageVersion(bg);
					
					MessageType messageType = new MessageType();
					messageType.setTypeName(CommonConstants.CORE_BANKING_INVOICE);
					SubType  subType = new SubType();
					subType.setSubTypeName(CommonConstants.PAY_BILL2);
					messageType.setSubType(subType);
					messageDetailsType.setMessageType(messageType);
					
					OriginationDetailsType originationDetailsType = new OriginationDetailsType();
					
					MessageSenderType messageSenderType = new MessageSenderType();
					MessageSender messageSender = new MessageSender();
					messageSender.setValue(channel);
					messageSenderType.setMessageSender(messageSender);
					messageSenderType.setCountryCode(country);
					
					SenderDomainType senderDomainType = new SenderDomainType();
					DomainName domainName = new DomainName();
					domainName.setValue(CommonConstants.DOMAIN_NAME);
					senderDomainType.setDomainName(domainName);
					
					SubDomainName subDomainName = new SubDomainName();
					subDomainName.setSubDomainType(CommonConstants.PAY_BILL2);
					senderDomainType.setSubDomainName(subDomainName);
					messageSenderType.setSenderDomain(senderDomainType);
					
					originationDetailsType.setMessageSender(messageSenderType);
					originationDetailsType.setMessageTimestamp(date2);
					originationDetailsType.setInitiatedTimestamp(date2);
					originationDetailsType.setTrackingId(requestCode);		
					originationDetailsType.setConversationID(requestCode);
					originationDetailsType.setPossibleDuplicate(true);
					originationDetailsType.setCorrelationID(requestCode);
					sCBMLHeaderType.setMessageDetails(messageDetailsType);
					sCBMLHeaderType.setOriginationDetails(originationDetailsType);
					
					return sCBMLHeaderType;
					
				}
			   
	 public static GetTransactionReq performStatusCheckPaymentRequestPayload(BillerPayRequestVO billerPayRequestVO){
			
		GetTransactionReq getTransactionReq = new GetTransactionReq();
		GetTransactionReqPayload getTransactionReqPayload = new GetTransactionReqPayload();
		getTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		getTransactionReqPayload.setOperationType(CommonConstants.TRANSACTION_STATUS_ENQUIRY);
		getTransactionReqPayload.setPayloadVersion(CommonConstants.VERSION);
		
		Transaction transaction = new Transaction();
		TransactionInfo transactionInfo = new TransactionInfo();
		
		String uniqueID = billerPayRequestVO.getBillerPayDetailsVO().getHostReference();
		transactionInfo.setTransactionReferenceNumber(uniqueID);
		transactionInfo.setSourceSystemName(CommonConstants.I_BANKING);
		
		transaction.setTransactionInfo(transactionInfo);
		getTransactionReqPayload.setGetTransactionReq(transaction);
		getTransactionReq.setGetTransactionReqPayload(getTransactionReqPayload);
		
		getTransactionReq.setHeader(populateSCBMLHeader(billerPayRequestVO,
				CommonConstants.GET_TRANSACTION_STATUS_SUB_TYPE_NAME,
				CommonConstants.GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME, 
				CommonConstants.TRANSACTION_STATUS_ENQUIRY,
				CommonConstants.GET_TRANSACTION_STATUS_PROCESSNAME));

		return getTransactionReq;
		
	}
	 
	 /*Inward status header*/
	 public static GetTransactionReq performStatusCheckPaymentRequestPayload(String referenceNumber, String hostReferenceNumber, String country){
			
		GetTransactionReq getTransactionReq = new GetTransactionReq();
		GetTransactionReqPayload getTransactionReqPayload = new GetTransactionReqPayload();
		getTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		getTransactionReqPayload.setOperationType(CommonConstants.TRANSACTION_STATUS_ENQUIRY);
		getTransactionReqPayload.setPayloadVersion(CommonConstants.VERSION);
		
		Transaction transaction = new Transaction();
		TransactionInfo transactionInfo = new TransactionInfo();
		
		transactionInfo.setTransactionReferenceNumber(hostReferenceNumber);
		transactionInfo.setSourceSystemName(CommonConstants.I_BANKING);
		
		transaction.setTransactionInfo(transactionInfo);
		getTransactionReqPayload.setGetTransactionReq(transaction);
		getTransactionReq.setGetTransactionReqPayload(getTransactionReqPayload);
		
		getTransactionReq.setHeader(populateCreditStatusHeader(referenceNumber,country,
				CommonConstants.GET_TRANSACTION_STATUS_SUB_TYPE_NAME,
				CommonConstants.GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME, 
				CommonConstants.TRANSACTION_STATUS_ENQUIRY,
				CommonConstants.GET_TRANSACTION_STATUS_PROCESSNAME));

		return getTransactionReq;
			
	}
	 public static BillerPayResponseVO getStatusCheckPaymentResponse(
			 GetTransactionRes  getTransactionRes,BillerPayRequestVO billerPayRequestVO){
		 LOGGER.info("PaymentTransactionServiceImpl :::: getStatusCheckPaymentResponse ::: Start");
		String txnId = null;
		TagsType metaData = null;
		boolean transactionAvailable = false;
		ExceptionListType exceptions = null;
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		
		LOGGER.info("PaymentTransactionServiceImpl :::: getStatusCheckPaymentResponse ::: Start");
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			
		if (getTransactionRes != null) {
			exceptions = getTransactionRes.getExceptions();
			metaData = getTransactionRes.getHeader().getMetadata();
				
			if (getTransactionRes.getHeader() != null
					&& getTransactionRes.getHeader().getOriginationDetails() != null) {
				 txnId = getTransactionRes.getHeader().getOriginationDetails().getTrackingId();
				 
				 if(metaData != null && metaData.getTag() != null 
							&& !metaData.getTag().isEmpty()) {
					 
					 // IF the value is "1", then transaction is available
					 TagType tag = metaData.getTag().get(0);
					 transactionAvailable = tag.getValue() != null 
							 && tag.getValue().equals("1");

					 /*billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
					 	setTxnStatusCd(transactionAvailable ? "DONE" : "DOIT");*/
					 
					 billerPayResponseVO.setStatus(transactionAvailable ? "DONE" : "DOIT");
					 
					 //custom entries for audit ONLY - billpayment table entry differs
					 if(billerPayResponseVO.getBillerPayDetailsVO()!=null){						 
						 billerPayResponseVO.getBillerPayDetailsVO().setTxnActStatus(transactionAvailable ? CommonConstants.COREBANK_PAY_SUCCESS: CommonConstants.COREBANK_PAY_TIMEOUT);
						 billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(transactionAvailable ? CommonConstants.PAYEE_ENTRY_FOUND :CommonConstants.PAYEE_ENTRY_NOT_FOUND);//EXISTS or NOT_EXISTS
						 billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(billerPayResponseVO.getStatus()); // DONE or DOIT
						 billerPayResponseVO.getBillerPayDetailsVO().setHostName(CommonConstants.EBBS + " - " + CommonConstants.TRANSACTION_STATUS_ENQUIRY);
					 }
				}
				
				if(!transactionAvailable && exceptions != null){
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
				 		setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 			setHostRespCd(exceptions.getException().get(0).getCode().getValue());
					
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 			setHostRespDesc(exceptions.getException().get(0).getDescription());
				}
				
				LOGGER.info("Details for txnId {} ::  tranxStatus: {} :: hostRespCd {} :: hostRespDesc {} :: hostName {} :: txnStatusCd {} ", new Object[] {txnId, 
						 billerPayResponseVO.getBillerPayDetailsVO().getTxnActStatus(),
						 billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd(),
						 billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc(),
						 billerPayResponseVO.getBillerPayDetailsVO().getHostName(),billerPayResponseVO.getBillerPayDetailsVO().
							getTransactionInfoVO().getTxnStatusCd() });
			} else {
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
		 		setTxnStatusCd(CommonConstants.FAIL);
			
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
		 			setHostRespCd("-1");
				
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
		 			setHostRespDesc("Missing Tracking id in core banking transactionStaus details");
				LOGGER.info("Missing Tracking id in core banking transactionStaus details");
			}
		} else {
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
	 		setTxnStatusCd(CommonConstants.FAIL);
		
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
	 			setHostRespCd("-1");
			
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
	 			setHostRespDesc("Missing response in core banking transactionStaus");
			LOGGER.info("Missing response in core banking transactionStaus");
		}
		
		LOGGER.info("PaymentTransactionServiceImpl :::: getStatusCheckPaymentResponse ::: End");
		return billerPayResponseVO;
	}
	
		/**
		 * Perform bill pay mapping.
		 *
		 * @param billerPayRequestVO the biller pay request vo
		 * @return the com.sc.cashpaybillrequest. mfep
		 */
	 	public static BillerPayRequestVO getBillerPayRequestVOMapping(PaymentRequest paymentRequest) {
			return MappingHelper.MAPPER.map(paymentRequest, BillerPayRequestVO.class);
		}
	 	
	 	public static PaymentResponse getPaymentResponseVOMapping(BillerPayResponseVO billerPayResponseVO) {
			return MappingHelper.MAPPER.map(billerPayResponseVO, PaymentResponse.class);
		}
	 	
	 // Added for Payment Details - Validate Payee -- Start
		
 	 	public static GetPaymentDetailsReq performPaymentDetailsInvoiceRequestPayload(BillerPayRequestVO billerPayRequestVO,String aggregatorIdentifier){
 	 		GetPaymentDetailsReq getPaymentDetailsReq = new GetPaymentDetailsReq();
 	 				try{
 	 				LOGGER.info("Inside BillpaymentMappingHelper:: performPaymentDetailsInvoiceRequestPayload-Start"+billerPayRequestVO.getMessageVO().getReqID());
 	 				GetPaymentDetailsReqPayload getPaymentDetailsReqPayload = new GetPaymentDetailsReqPayload();
 	 				getPaymentDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
 	 				//getPaymentDetailsReqPayload.setOperationType(CommonConstants.TRANSACTION_STATUS_ENQUIRY);
 	 				getPaymentDetailsReqPayload.setPayloadVersion(CommonConstants.PAYLOAD_API_21);
 	 				
 	 				InvoiceInfo invoiceInfo = new InvoiceInfo();
 	 				invoiceInfo.setAggregatorIdentifier(aggregatorIdentifier);
 	 				invoiceInfo.setApplicationUserID(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserID());
 	 				invoiceInfo.setApplicationUserKey(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserKey());
 	 				
 	 				PaymentDetails paymentDetails = new PaymentDetails();
 	 				//LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo() ---- "+ billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
 	 				//paymentDetails.setAccountNumber(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
 	 				//LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getBillerCd() ---- "+ billerPayRequestVO.getBillerPayDetailsVO().getBillerCd());
 	 				//paymentDetails.setBillerID(billerPayRequestVO.getBillerPayDetailsVO().getBillerCd());
 	 				
 	 				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getAggId() ---- "+ billerPayRequestVO.getBillerPayDetailsVO().getAggId());
 	 				paymentDetails.setBillerID(billerPayRequestVO.getBillerPayDetailsVO().getBillerCd());
 	 				String fieldsDelimitedStr="";
 	 				for (BillerField billerFieldInput : billerPayRequestVO.getBillerPayDetailsVO().getBillerFields()) {
 	 					LOGGER.info("performPaymentDetailsInvoiceRequestPayload field info "+
 	 				              "getFieldLabelName : "+  billerFieldInput.getFieldLabelName()+
 	 				              "getFieldType : "+  billerFieldInput.getFieldType()+
 	 				              "getFieldDataType : "+  billerFieldInput.getFieldDataType()+
 	 				              "getFieldValue : "+  billerFieldInput.getFieldValue()+
 	 							  "ReqId : "+billerPayRequestVO.getMessageVO().getReqID());
 	 					fieldsDelimitedStr=fieldsDelimitedStr.concat(billerFieldInput.getFieldLabelName().concat(CommonConstants.COLON).concat(billerFieldInput.getFieldValue())).concat(CommonConstants.COLON);
 	 					//fieldsDelimitedStr=fieldsDelimitedStr.concat(billerFieldInput.getFieldLabelName().concat(CommonConstants.COLON).concat(billerFieldInput.getFieldValue()));
 	 					/*switch (billerFieldInput.getFieldDataType()) {
 						case CommonConstants.FIELD_DATETYPE_LIST:
 							for (BillerFieldItemVO item : billerFieldInput.getBillerFieldItems()){
 								fieldsDelimitedStr=fieldsDelimitedStr.concat(billerFieldInput.getFieldLabelName().concat(CommonConstants.COLON).concat(item.getId().toString())).concat(CommonConstants.COLON);
 							}
 							break;
 						default:
 							fieldsDelimitedStr=fieldsDelimitedStr.concat(billerFieldInput.getFieldLabelName().concat(CommonConstants.COLON).concat(billerFieldInput.getFieldValue())).concat(CommonConstants.COLON);
 							break;
 						   }*/
 	 					} 
 	 				if(fieldsDelimitedStr.length()>1){
 	 					fieldsDelimitedStr=fieldsDelimitedStr.substring(0,fieldsDelimitedStr.length()-1);
 	 				}
 	 				//paymentDetails.setBillerDetails(fieldsDelimitedStr);
 	 				 paymentDetails.setBillerDetails(fieldsDelimitedStr);
 	 				
 	 				invoiceInfo.getPaymentDetails().add(paymentDetails);	
 	 				com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
 	 				invoice.setInvoiceInfo(invoiceInfo);
 	 				
 	 				getPaymentDetailsReqPayload.setGetPaymentDetailsReq(invoice);
 	 				
 	 				getPaymentDetailsReq.setGetPaymentDetailsReqPayload(getPaymentDetailsReqPayload);
 	 				
 	 				getPaymentDetailsReqPayload.getGetPaymentDetailsReq().setInvoiceInfo(invoiceInfo);
 	 				getPaymentDetailsReq.setHeader(populateSRMSCBMLHeader(billerPayRequestVO,CommonConstants.AGGREGATOR_PROCESS_NAME,CommonConstants.INVOICE_NAME,CommonConstants.GET_PROCESS_EVENT_TYPE,CommonConstants.AGGREGATOR_PROCESS_NAME));
 	 				}catch(Exception e){
 	 					LOGGER.info("Inside BillpaymentMappingHelper:: performPaymentDetailsInvoiceRequestPayload-Exception"+billerPayRequestVO.getMessageVO().getReqID());
 	 					LOGGER.error(" Bill PaymentMapping Hleper::performPaymentDetailsInvoiceRequestPayload--StackStrace",e);
 	 					e.printStackTrace();
 	 				}
 	 				LOGGER.info("Inside BillpaymentMappingHelper:: performPaymentDetailsInvoiceRequestPayload-End"+billerPayRequestVO.getMessageVO().getReqID());
 	 				return getPaymentDetailsReq;
 	 				
 	 			}

 	 	/*public static BillerPayResponseVO getPaymentDetailsInvoiceResponse(GetPaymentDetailsRes getPaymentDetailsRes,BillerPayRequestVO billerPayRequestVO){
 	 		LOGGER.info("BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse Start "+billerPayRequestVO.getMessageVO().getReqID() ) ;
 	 		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
 	 		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
 	 		TransactionInfoVO tranVO = new TransactionInfoVO();
 	 		billerPayDetailsVO.setTransactionInfoVO(tranVO);
 	 		billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
 	 		String txnId = null;
 	 		ExceptionListType exceptions = null;
 	 		
 	 		//GetPaymentDetailsResPayload getPaymentDetailsResPayload = null;
 	 		if (getPaymentDetailsRes != null) {
 	 			//getPaymentDetailsResPayload = getPaymentDetailsRes.getGetPaymentDetailsResPayload();
 	 			if (getPaymentDetailsRes.getHeader() != null
 	 					&& getPaymentDetailsRes.getHeader().getOriginationDetails() != null){
 	 				LOGGER.info("getPaymentDetailsInvoiceResponse When getPaymentDetailsRes !=  null " ) ;
 	 				 txnId = getPaymentDetailsRes.getHeader().getOriginationDetails().getTrackingId();
 	 				LOGGER.info("getPaymentDetailsInvoiceResponse When getPaymentDetailsRes !=  null  and txnId -- "+txnId ) ;
 	 			}
 	 			if (getPaymentDetailsResPayload != null
 	 					&& getPaymentDetailsResPayload.getGetPaymentDetailsRes() != null){
 	 				//billerPayResponseVO = getTransferResponseValues(getPaymentDetailsResPayload.getGetPaymentDetailsRes());
 	 				billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
 	 			}
 	 		}
 	 		
 	 		if (exceptions == null){
 	 			LOGGER.info("getPaymentDetailsInvoiceResponse When Exception !!!!=  null " ) ;
 	 			billerPayResponseVO.setStatus(getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo().getPaymentDetails().get(0).getTransactionStatus().getStatusCode());
 	 			billerPayResponseVO.setStatusDesc(getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo().getPaymentDetails().get(0).getTransactionStatus().getStatusDescription());
 	 			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnId(txnId);
 	 			LOGGER.info("Response received for payment details transaction txn id , status {} {} {}", new Object[]{txnId, 
 	 					getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo().getPaymentDetails().get(0).getTransactionStatus().getStatusCode(), 
 	 					getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo().getPaymentDetails().get(0).getTransactionStatus().getStatusDescription()});
 	 		}
 	 		LOGGER.info("BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse end "+billerPayRequestVO.getMessageVO().getReqID() ) ;
 	 		return billerPayResponseVO;
 	 	}*/
 	 	
 	 	
 	 	public static BillerPayResponseVO getPaymentDetailsInvoiceResponse(GetPaymentDetailsRes getPaymentDetailsRes,
				BillerPayRequestVO billerPayRequestVO) {
			LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse --Start "+billerPayRequestVO.getMessageVO().getReqID());
			BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
			BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
			TransactionInfoVO tranVO = new TransactionInfoVO();
			billerPayDetailsVO.setTransactionInfoVO(tranVO);
			billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
			String txnId = null;
			ExceptionListType exceptions = null;
			com.sc.scbml_1.GetPaymentDetailsResPayload getPaymentDetailsResPayload = null;
			if (getPaymentDetailsRes != null) {
				getPaymentDetailsResPayload = getPaymentDetailsRes.getGetPaymentDetailsResPayload();
				if (getPaymentDetailsRes.getHeader() != null && getPaymentDetailsRes.getHeader().getOriginationDetails() != null) {
					exceptions = getPaymentDetailsRes.getHeader().getExceptions();
					LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse got headers");
					txnId = getPaymentDetailsRes.getHeader().getOriginationDetails().getTrackingId();
					LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse get headersand txnId -- " + txnId);
				}
			}

			if (exceptions == null) {
				LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: NO Exceptions"+txnId);
				if (getPaymentDetailsRes != null) {
					if (getPaymentDetailsRes.getGetPaymentDetailsResPayload() != null) {
						if (getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes() != null) {
							if (getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo() != null) {
								if (getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo()
										.getPaymentDetails() != null) {
									/*TransactionStatus transactionStatus = getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes()
											.getInvoiceInfo().getTransactionStatus();
									LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse transactionStatus.getStatus() ::"
											+ transactionStatus.getStatus() + ", transactionStatus.getStatusCode() ::"
											+ transactionStatus.getStatusCode() + ",transactionStatus.getStatusCodeID() ::"
											+ transactionStatus.getStatusCodeID() + ", transactionStatus.getStatusDescription() ::"
											+ transactionStatus.getStatusDescription());
									billerPayResponseVO.setStatus(transactionStatus.getStatus());
									billerPayResponseVO.setStatusDesc(transactionStatus.getStatusDescription());*/
									List<PaymentDetails> listPaymentDetails = getPaymentDetailsRes.getGetPaymentDetailsResPayload()
											.getGetPaymentDetailsRes().getInvoiceInfo().getPaymentDetails();

									for (PaymentDetails paymentDetails : listPaymentDetails) {
										String paymentInfo=paymentDetails.getPaymentInfo();
										LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: paymentinfo"+paymentInfo+":: req id"+billerPayRequestVO.getMessageVO().getReqID());
										PaymentDetailVO paymentDetailVO=new PaymentDetailVO();
										paymentDetailVO.setPaymentDescription(paymentInfo);
										billerPayDetailsVO.setPaymentDetailsVO(paymentDetailVO);
										/*LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper paymentDetails.getMinAmountValue() ::"
												+ paymentDetails.getMinAmountValue()
												+ ", paymentDetails.getMinAmountCurrency() ::"
												+ paymentDetails.getMinAmountCurrency()
												+ ",paymentDetails.getMaxAmountValue() ::"
												+ paymentDetails.getMaxAmountValue()
												+ ", paymentDetails.getMaxAmountCurrency() ::"
												+ paymentDetails.getMaxAmountCurrency());
										if(paymentDetails.getMinAmountValue() !=null){
										billerPayDetailsVO.setBillerMinPmt(Double.parseDouble(paymentDetails.getMinAmountValue()));
										}
										if(paymentDetails.getMinAmountValue()!=null){
										billerPayDetailsVO.setBillerMaxPmt(Double.parseDouble(paymentDetails.getMaxAmountValue()));
										}*/
										
										//billerPayDetailsVO.setTxnCurrency(paymentDetails.getMinAmountCurrency());
										TransactionStatus2 transactionStatus2=paymentDetails.getTransactionStatus();
										if(transactionStatus2!=null){
										billerPayResponseVO.setStatus(transactionStatus2.getStatusCode());
										billerPayResponseVO.setStatusDesc(transactionStatus2.getStatusDescription());
										}
										LOGGER.info("transactionStatus2.getStatusCodeID()"+transactionStatus2.getStatusCodeID()+" reqid"+billerPayRequestVO.getMessageVO().getReqID());
										LOGGER.info("transactionStatus2.getStatusDescription()"+transactionStatus2.getStatusDescription()+" reqid"+billerPayRequestVO.getMessageVO().getReqID());
										LOGGER.info("transactionStatus2.getStatus()"+transactionStatus2.getStatus()+" reqid"+billerPayRequestVO.getMessageVO().getReqID());
										LOGGER.info("transactionStatus2.getStatusCode()"+transactionStatus2.getStatusCode()+" reqid"+billerPayRequestVO.getMessageVO().getReqID());
									
									}
									billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
								}else{
									//Transaction info is null
									LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo().getTransactionStatus() != null "+billerPayRequestVO.getMessageVO().getReqID());
								}
							}else{
								//Invoice info is null getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo() != null
								LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo() != null "+billerPayRequestVO.getMessageVO().getReqID());
							}
								
						}else{
							//Payment details is null getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes() != null
							LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes() != null "+billerPayRequestVO.getMessageVO().getReqID());
						}
					}else{
						//Response payload is null
						LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: getPaymentDetailsRes.getGetPaymentDetailsResPayload() != null "+billerPayRequestVO.getMessageVO().getReqID());
					}
				}else{
					//"Response is null"
					LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse :: getPaymentDetailsRes != null "+billerPayRequestVO.getMessageVO().getReqID());
				}

			} else {
				LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse Entered exceptoin block"+billerPayRequestVO.getMessageVO().getReqID());
				for (ExceptionType exceptionType : exceptions.getException()) {
					LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse Exception code {} :: descrption {} :: txnId {} " ,
								new Object[] {exceptionType.getCode(),exceptionType.getDescription(),billerPayRequestVO.getMessageVO().getReqID()});
				}
			}

			LOGGER.info("Inside BillpaymentMappingHelper :: getPaymentDetailsInvoiceResponse --End " +billerPayRequestVO.getMessageVO().getReqID());
			return billerPayResponseVO;
		}



 	 	protected static SCBMLHeaderType populateSRMSCBMLHeader(BillerPayRequestVO billerPayRequestVO,String subTypeName,String messageTypeName,String eventType,String processName) {

 	 		SubType subType = new SubType();
 	 		subType.setSubTypeName(subTypeName);
 	 		
 	 		MessageType  messageType  = new MessageType();
 	 		messageType.setTypeName(messageTypeName);
 	 		messageType.setSubType(subType);
 	 		
 	 		MessageDetailsType messageDetailsType = new MessageDetailsType();
 	 		messageDetailsType.setMessageVersion(new BigDecimal(CommonConstants.DECIMAL_ONE));
 	 		messageDetailsType.setMessageType(messageType); 
 	 		
 	 		OriginationDetailsType originationDetailsType = new OriginationDetailsType();
 	 		//String txnId = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnId().replaceAll(CommonConstants.HYPHEN, CommonConstants.EMPTY);
 	 		String txnId = billerPayRequestVO.getMessageVO().getReqID().replaceAll(CommonConstants.HYPHEN, CommonConstants.EMPTY);
 	 		originationDetailsType.setTrackingId(txnId);
 	 		originationDetailsType.setPossibleDuplicate(true);
 	 		
 	 		MessageSenderType messageSenderType = new MessageSenderType();
 	 		MessageSender messageSender = new MessageSender();
 	 		messageSender.setValue(CommonConstants.IBANK);
 	 		
 	 		DomainName domainName = new DomainName();
 	 		domainName.setValue(CommonConstants.AGGREGATOR_DOMAIN_NAME);
 	 		
 	 		SubDomainName subDomainName = new SubDomainName();
 	 		subDomainName.setSubDomainType(CommonConstants.AGGREGATOR_PROCESS_NAME);
 	 		
 	 		SenderDomainType senderDomainType = new SenderDomainType();
 	 		senderDomainType.setDomainName(domainName);
 	 		senderDomainType.setSubDomainName(subDomainName);
            messageSenderType.setCountryCode(billerPayRequestVO.getUser().getCountry());
 	 		//messageSenderType.setCountryCode("KE");
 	 		messageSenderType.setMessageSender(messageSender);
 	 		messageSenderType.setSenderDomain(senderDomainType);
 	 		
 	 		originationDetailsType.setMessageSender(messageSenderType);
 	 		
 	 		GregorianCalendar c = new GregorianCalendar();
 	 		c.setTime(DateUtils.getCurrentDate());
 	 		XMLGregorianCalendar date = null;
 	 		try {
 	 			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
 	 						
 	 		} catch (DatatypeConfigurationException e) {
 	 			LOGGER.error("Exception occurred ::: ",e);
 	 		}
 	 		
 	 		originationDetailsType.setMessageTimestamp(date);
 	 		originationDetailsType.setInitiatedTimestamp(date);
 	 		
 	 		ProcessType processType = new ProcessType();
 	 		processType.setEventType(eventType);
 	 		processType.setProcessName(processName);
 	 		
 	 		SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
 	 		sCBMLHeaderType.setMessageDetails(messageDetailsType);
 	 		sCBMLHeaderType.setOriginationDetails(originationDetailsType);
 	 		sCBMLHeaderType.setCaptureSystem(CommonConstants.CRAFTSILICON);
 	 		sCBMLHeaderType.setProcess(processType);
 	 		return sCBMLHeaderType;
 	 	}
 	 			
 	  // Added for Payment Details - Validate Payee -- End
 	 	
 	 	
 	 	
 	 	public static GetPaymentStatusReq performGetPaymentStatusRequestPayload(BillerPayRequestVO billerPayRequestVO) {
 			LOGGER.info("BillpaymentMappingHelper :: performGetPaymentStatusRequestPayload :: Start");
 			GetPaymentStatusReq getPaymentStatusReq = new GetPaymentStatusReq();
 			String country="";
 			String aggregator="";
 			String eventType="";
 			GetPaymentStatusReqPayload getPaymentStatusReqPayload = new GetPaymentStatusReqPayload();
 			getPaymentStatusReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
 			getPaymentStatusReqPayload.setPayloadVersion(CommonConstants.VERSION);
 			Invoice invoice=new Invoice();
 			InvoiceInfo invoiceInfo = new InvoiceInfo();
 			if(billerPayRequestVO.getUser().getCountry().equalsIgnoreCase(CommonConstants.NG)){
 				eventType=CommonConstants.GET_PROCESS_EVENT_TYPE;
 				country=CommonConstants.NG;
 				aggregator=CommonConstants.INTERSWITCH;
 				invoiceInfo.setTransactionID(billerPayRequestVO.getBillerPayDetailsVO().getHostReference());
 	 			//invoiceInfo.setTransactionID(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnId());
 	 			invoice.setInvoiceInfo(invoiceInfo);
 			}else if(billerPayRequestVO.getUser().getCountry().equalsIgnoreCase(CommonConstants.KE)){
 				eventType=CommonConstants.POST_PROCESS_EVENT_TYPE;
 				country=CommonConstants.KE;
 				aggregator=CommonConstants.CRAFTSILICON;
 				invoiceInfo.setApplicationUserID(CommonConstants.APPLICATION_USERID);
 				invoiceInfo.setApplicationUserKey(CommonConstants.APPLICATION_USERKEY);
 				SimpleDateFormat format = new SimpleDateFormat("dd MMM YYYY");
 				invoiceInfo.setPaymentDate(format.format(billerPayRequestVO.getBillerPayDetailsVO().getPaymentDetailsVO().getPaymentDate().getTime()));
 				//invoiceInfo.setPaymentDate("11 MAR 2016"); // for test
 				invoice.setInvoiceInfo(invoiceInfo);
 			}else{
 				country=billerPayRequestVO.getUser().getCountry();
 			}
 			
 			getPaymentStatusReqPayload.setGetPaymentStatusReq(invoice);;
 			getPaymentStatusReq.setGetPaymentStatusReqPayload(getPaymentStatusReqPayload);
 			getPaymentStatusReq.setHeader(populateSCBHeaderForAggregator(country, CommonConstants.GET_PAYMENTSTATUS, 
 					billerPayRequestVO.getBillerPayDetailsVO().getHostReference(), aggregator, eventType));
 			LOGGER.info("BillpaymentMappingHelper :: performGetPaymentStatusRequestPayload :: End");
 			return getPaymentStatusReq;
 		}

 		/**
 		 * Populate scbml header.
 		 * 
 		 * @param billerPayRequestVO
 		 *            the biller pay request vo
 		 * @param subTypeName
 		 *            the sub type name
 		 * @param messageTypeName
 		 *            the message type name
 		 * @param eventType
 		 *            the event type
 		 * @param processName
 		 *            the process name
 		 * @return the sCBML header type
 		 */
 		public static SCBMLHeaderType populateSCBHeaderForAggregator(
 				String country, String service, String trackingId, String aggregator, String eventType) {
 			LOGGER.info("BillpaymentMappingHelper :: populateSCBHeaderForAggrigator :: Start");
 			//Header prepared with sample values given, going forward updates may require
 			SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
 			try{
 			MessageDetailsType messageDetailsType = new MessageDetailsType();
 			MessageType messageType = new MessageType();
 			SubType subType = new SubType();
 			subType.setSubTypeName(service);
 			messageType.setTypeName(CommonConstants.INVOICE_NAME);
 			messageType.setSubType(subType);
 			messageDetailsType.setMessageVersion(new BigDecimal("1.0"));
 			messageDetailsType.setMessageType(messageType);

 			OriginationDetailsType originationDetailsType = new OriginationDetailsType();
 			MessageSenderType messageSenderType = new MessageSenderType();
 			MessageSender messageSender = new MessageSender();
 			messageSender.setValue(CommonConstants.IBANK);

 			SenderDomainType senderDomainType = new SenderDomainType();
 			DomainName domainName = new DomainName();
 			domainName.setValue(CommonConstants.DOMAIN_NAME_AGG);
 			SubDomainName subDomainName = new SubDomainName();
 			subDomainName.setSubDomainType(service);

 			senderDomainType.setDomainName(domainName);
 			senderDomainType.setSubDomainName(subDomainName);
 			messageSenderType.setCountryCode(country);
 			messageSenderType.setMessageSender(messageSender);
 			messageSenderType.setSenderDomain(senderDomainType);
 			originationDetailsType.setMessageSender(messageSenderType);

 			XMLGregorianCalendar date = getGregorianCalendar();
 			originationDetailsType.setMessageTimestamp(date);
 			originationDetailsType.setInitiatedTimestamp(date);

 			originationDetailsType.setTrackingId(trackingId);
 			originationDetailsType.setCorrelationID(trackingId);
 			originationDetailsType.setConversationID(trackingId);
 			originationDetailsType.setPossibleDuplicate(true);
 			
 			ProcessType processType = new ProcessType();
 			processType.setEventType(eventType);
 			processType.setProcessName(service);
 			sCBMLHeaderType.setMessageDetails(messageDetailsType);
 			sCBMLHeaderType.setOriginationDetails(originationDetailsType);
 			sCBMLHeaderType.setCaptureSystem(CommonConstants.AGGREGATOR);
 			sCBMLHeaderType.setProcess(processType);
 			}catch(Exception e){
 				LOGGER.info("BillpaymentMappingHelper :: populateSCBHeaderForAggrigator :: Exception " +e.getMessage());	
 			}
 			LOGGER.info("BillpaymentMappingHelper :: populateSCBHeaderForAggrigator :: End");
 			return sCBMLHeaderType;
 		}

 		/** Audit Service Mapping -  View payee Service*/
 		public static AuditServiceVO getPayeeReqAuditService(ViewPayeeRequestVO viewPayeeRequestVO) {
 			return   MAPPER.map(viewPayeeRequestVO, AuditServiceVO.class);
 		}
 		
 		/** Audit Service Mapping -  View payee Service*/
 		public static AuditServiceVO getPayeeResAuditService(ViewPayeeResponseVO viewPayeeResponseVO) {
 			return   MAPPER.map(viewPayeeResponseVO, AuditServiceVO.class);
 		}
 		

 		/** Audit Service Mapping -  View payee Service*/
 		public static AuditServiceVO getPaymentReqAuditService(BillerPayRequestVO billerPayRequestVO) {
 			return   MAPPER.map(billerPayRequestVO, AuditServiceVO.class);
 		}
 		
 		/** Audit Service Mapping -  View payee Service*/
 		public static AuditServiceVO getPaymentResAuditService(BillerPayResponseVO BillerPayResponseVO) {
 			return   MAPPER.map(BillerPayResponseVO, AuditServiceVO.class);
 		}
 		
 		
 		// Added for Biller Download Service Job
 		
 		/** Request Mapping -  Biller Download Status Service*/ 
 		/*public static BillerDownloadRequest getBillerDownloadStatusRequest(BillerDownloadServiceRequest billerDownloadServiceRequest) {
 			BillerDownloadRequest billerDownloadReq = new BillerDownloadRequest();
 			
 			try{
 				billerDownloadReq =  MappingHelper.MAPPER.map(billerDownloadServiceRequest,BillerDownloadRequest.class);
 			}catch(Exception e){
 				e.printStackTrace();
 				System.out.println("---------------------------e"+e.getMessage());
 			}
 			return billerDownloadReq;
 		}*/

 		/** Response Mapping -  Biller Download Status Service*/ 
 		public static JobServiceResponse getBillerDownloadStatusResponse(BillerDownloadResponseVO billerDwndRes) {
 			return MappingHelper.MAPPER.map(billerDwndRes,JobServiceResponse.class);

 		}
 		
 	// Added for Job Service Job
 		
 		/** Request Mapping -  Job Service*/ 
 		public static BillerDownloadRequest getjobServiceRequest(JobServiceRequest jobServiceRequest) {
 			BillerDownloadRequest billerDownloadReq = new BillerDownloadRequest();
 			
 			try{
 				billerDownloadReq =  MappingHelper.MAPPER.map(jobServiceRequest,BillerDownloadRequest.class);
 			}catch(Exception e){
 				e.printStackTrace();
 				System.out.println("---------------------------e"+e.getMessage());
 			}
 			return billerDownloadReq;
 		}
 		
 		public static AuditServiceVO getBillPymtArchieveRespAuditService(BillerDownloadResponseVO billerDownloadResponseVO) {
 			return   MAPPER.map(billerDownloadResponseVO, AuditServiceVO.class);
 		}
 		/**
 	 	 * @param responseVO
 	 	 * @return
 	 	 */
 	 	public static ValidatePayeeResponse getValidatePayeeResponseVOMapping(BillerPayResponseVO billerPayResponseVO) {
 				return MappingHelper.MAPPER.map(billerPayResponseVO, ValidatePayeeResponse.class);
 			}
 	 	
 	 	public static GetPaymentDetailsReq validateWalletDetatilsWraper(BillerPayRequestVO billerPayRequestVO){
 	 		GetPaymentDetailsReq getPaymentDetailsReq = new GetPaymentDetailsReq();
 	 				try{
 	 					LOGGER.info("Inside BillpaymentMappingHelper :: validateWalletDetatilsWraper --Start ");
 	 				GetPaymentDetailsReqPayload getPaymentDetailsReqPayload = new GetPaymentDetailsReqPayload();
 	 				getPaymentDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
 	 				//getPaymentDetailsReqPayload.setOperationType(CommonConstants.TRANSACTION_STATUS_ENQUIRY);
 	 				getPaymentDetailsReqPayload.setPayloadVersion(CommonConstants.VERSION);
 	 				
 	 				InvoiceInfo invoiceInfo = new InvoiceInfo();
 	 				invoiceInfo.setApplicationUserID(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserID());
 	 				invoiceInfo.setApplicationUserKey(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserKey());
 	 				
 	 				PaymentDetails paymentDetails = new PaymentDetails();
 	 				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo() ---- "+ billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
 	 				paymentDetails.setAccountNumber(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
 	 				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getAggId() ---- "+ billerPayRequestVO.getBillerPayDetailsVO().getAggId());
 	 				paymentDetails.setBillerID(billerPayRequestVO.getBillerPayDetailsVO().getAggId());
 	 				
 	 				invoiceInfo.getPaymentDetails().add(paymentDetails);	
 	 				
 	 				com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
 	 				invoice.setInvoiceInfo(invoiceInfo);
 	 				
 	 				getPaymentDetailsReqPayload.setGetPaymentDetailsReq(invoice);
 	 				
 	 				getPaymentDetailsReq.setGetPaymentDetailsReqPayload(getPaymentDetailsReqPayload);
 	 				
 	 				getPaymentDetailsReqPayload.getGetPaymentDetailsReq().setInvoiceInfo(invoiceInfo);
 	 				
 	 				getPaymentDetailsReq.setHeader(populateSRMSCBMLHeader(billerPayRequestVO,"getPaymentDetails",
 	 						"Invoice","get","getPaymentDetails"));

 	 				System.out.println(getPaymentDetailsReq);
 	 				}catch(Exception e){
 	 					LOGGER.error("Inside BillpaymentMappingHelper :: validateWalletDetatilsWraper --Exception ",e);
 	 					//e.printStackTrace();
 	 				}
 	 				LOGGER.info("Inside BillpaymentMappingHelper :: validateWalletDetatilsWraper --End ");
 	 				return getPaymentDetailsReq;
 	 				
 	 			}
 	 	public static GetCustomerContactDetailsReq processCustomerEnquiryRequest(InwardPaymentRequestVO inwardPaymentRequestVO) throws DatatypeConfigurationException{
 			
 			GetCustomerContactDetailsReq contactDetailsReq = new GetCustomerContactDetailsReq();
 			SCBMLHeaderType headerType = new SCBMLHeaderType();
 			headerType.setCaptureSystem("eBBS");
 			MessageDetailsType messageDetailsType = new MessageDetailsType();
 			messageDetailsType.setMessageVersion(new BigDecimal("5.0"));
 			MessageType messageType = new MessageType();
 			SubType subType = new SubType();
 			subType.setSubTypeName(CommonConstants.CONTACT_DETAILS);
 			messageType.setSubType(subType);
 			messageType.setTypeName(CommonConstants.CUSTOMER_TYPE_NAME);
 			messageDetailsType.setMessageType(messageType);
 			OriginationDetailsType originationDetailsType = new OriginationDetailsType();
 			originationDetailsType.setPossibleDuplicate(true);
 			originationDetailsType.setTrackingId(inwardPaymentRequestVO.getReferenceNumber());
 			GregorianCalendar c = new GregorianCalendar();
 			c.setTime(DateUtils.getCurrentDate());
 			XMLGregorianCalendar date = null;
 			try {
 				date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
 				LOGGER.info("Calender::: "+date);
 				originationDetailsType.setInitiatedTimestamp(date);
 				originationDetailsType.setMessageTimestamp(date);
 			} catch (DatatypeConfigurationException e) {
 			}
 			MessageSender messageSender = new MessageSender();
 			messageSender.setValue("IBNK");
 			MessageSenderType messageSenderType = new MessageSenderType();
 			messageSenderType.setCountryCode(inwardPaymentRequestVO.getClientInfoVO().getCountry());
 			SenderDomainType senderDomainType = new SenderDomainType();
 			DomainName domainName = new DomainName();
 			domainName.setValue("CoreBanking");
 			senderDomainType.setDomainName(domainName);
 			SubDomainName subDomainName = new SubDomainName();
 			subDomainName.setSubDomainType("IBNK");
 			senderDomainType.setSubDomainName(subDomainName);
 			
 			messageSenderType.setMessageSender(messageSender);
 			messageSenderType.setSenderDomain(senderDomainType);
 			
 			originationDetailsType.setMessageSender(messageSenderType);
 			headerType.setOriginationDetails(originationDetailsType);
 			headerType.setMessageDetails(messageDetailsType);
 			
 			ProcessType processType = new ProcessType();
 			processType.setEventType("get");
 			processType.setProcessName("getCustomerContactDetails");
 			headerType.setProcess(processType);
 			
 			contactDetailsReq.setHeader(headerType);
 			GetCustomerContactDetailsReqPayload customerContactDetailsReqPayload = new GetCustomerContactDetailsReqPayload();
 			GetCustomerContactDetails customerContactDetails = new GetCustomerContactDetails();
 			LOGGER.info("InwardPaymentEDMIRequestProcessor relID"+inwardPaymentRequestVO.getRelId());
 			customerContactDetails.setCustomerIdentificationNumber(inwardPaymentRequestVO.getRelId());
 			customerContactDetailsReqPayload.setGetCustomerContactDetailsReq(customerContactDetails);
 			customerContactDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
 			customerContactDetailsReqPayload.setPayloadVersion(CommonConstants.CB_CUST_PAYLOAD_VERSION);
 			contactDetailsReq.setGetCustomerContactDetailsReqPayload(customerContactDetailsReqPayload);
 			
 			return contactDetailsReq;
 		}
 	 	
 	 	public static GetAccountDetailsReq processAccountEnquiryRequest(InwardPaymentRequestVO inwardPaymentRequestVO) throws DatatypeConfigurationException{
 			
 	 		GetAccountDetailsReq accountDetailsReq = new GetAccountDetailsReq();
 			SCBMLHeaderType headerType = new SCBMLHeaderType();
 			headerType.setCaptureSystem("eBBS");
 			MessageDetailsType messageDetailsType = new MessageDetailsType();
 			messageDetailsType.setMessageVersion(new BigDecimal(CommonConstants.DECIMAL_FOUR));
 			MessageType messageType = new MessageType();
 			SubType subType = new SubType();
 			subType.setSubTypeName("getAccountDetails");
 			messageType.setSubType(subType);
 			messageType.setTypeName("CoreBanking:Account");
 			messageDetailsType.setMessageType(messageType);
 			OriginationDetailsType originationDetailsType = new OriginationDetailsType();
 			originationDetailsType.setPossibleDuplicate(true);
 			originationDetailsType.setTrackingId(inwardPaymentRequestVO.getReferenceNumber());
 			GregorianCalendar c = new GregorianCalendar();
 			c.setTime(DateUtils.getCurrentDate());
 			XMLGregorianCalendar date = null;
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			LOGGER.info("Calender::: "+date);
			originationDetailsType.setInitiatedTimestamp(date);
			originationDetailsType.setMessageTimestamp(date);
 			MessageSender messageSender = new MessageSender();
 			messageSender.setValue("IBNK");
 			MessageSenderType messageSenderType = new MessageSenderType();
 			messageSenderType.setCountryCode(inwardPaymentRequestVO.getClientInfoVO().getCountry());
 			SenderDomainType senderDomainType = new SenderDomainType();
 			DomainName domainName = new DomainName();
 			domainName.setValue("CoreBanking");
 			senderDomainType.setDomainName(domainName);
 			SubDomainName subDomainName = new SubDomainName();
 			subDomainName.setSubDomainType("getAccountDetails");
 			senderDomainType.setSubDomainName(subDomainName);
 			
 			messageSenderType.setMessageSender(messageSender);
 			messageSenderType.setSenderDomain(senderDomainType);
 			
 			originationDetailsType.setMessageSender(messageSenderType);
 			headerType.setOriginationDetails(originationDetailsType);
 			headerType.setMessageDetails(messageDetailsType);
 			
 			ProcessType processType = new ProcessType();
 			processType.setEventType("get");
 			processType.setProcessName("getAccountDetails");
 			headerType.setProcess(processType);
 			
 			accountDetailsReq.setHeader(headerType);
 			GetAccountDetailsReqPayload accountDetailsReqPayload = new GetAccountDetailsReqPayload();
 			
 			GetAccountDetails accountDetails = new GetAccountDetails();
 			LOGGER.info("InwardPaymentEDMIRequestProcessor relID"+inwardPaymentRequestVO.getRelId());
 			accountDetails.setAccountNumber(inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber());
 			accountDetails.setAccountCurrencyCode(inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency());
 			accountDetailsReqPayload.setGetAccountDetailsReq(accountDetails);
 			accountDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
 			accountDetailsReqPayload.setPayloadVersion(CommonConstants.DECIMAL_ONE);
 			accountDetailsReq.setGetAccountDetailsReqPayload(accountDetailsReqPayload);
 		
 			return accountDetailsReq;
 		}
 	 	/**
		    * Populate header.
		    *
		    * @param country the country
		    * @param channel the channel
		    * @param date2 the date2
		    * @param requestCode the request code
		    * @return the sCBML header type
		    * 
		    * Added for Inward Header
		    */
		   public static SCBMLHeaderType populateHeader(
				   String country, String channel, XMLGregorianCalendar date2, String requestCode,
				   String captureSystem, String processName, String eventType, String typeName, String domain) {
				
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				sCBMLHeaderType.setCaptureSystem(captureSystem);
				
				ProcessType processType = new ProcessType();
				processType.setProcessName(processName);
				processType.setEventType(eventType);
				sCBMLHeaderType.setProcess(processType);
			
				
				BigDecimal bg = new BigDecimal(CommonConstants.DECIMAL_ONE) ;
				
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				messageDetailsType.setMessageVersion(bg);
				
				MessageType messageType = new MessageType();
				messageType.setTypeName(typeName);
				SubType  subType = new SubType();
				//subType.setSubTypeName(processName);
				subType.setSubTypeName(eventType);
				messageType.setSubType(subType);
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(channel);
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setCountryCode(country);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				DomainName domainName = new DomainName();
				domainName.setValue(domain);
				senderDomainType.setDomainName(domainName);
				
				SubDomainName subDomainName = new SubDomainName();
				//subDomainName.setSubDomainType(processName);
				subDomainName.setSubDomainType(domain);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				originationDetailsType.setMessageTimestamp(date2);
				originationDetailsType.setInitiatedTimestamp(date2);
				originationDetailsType.setTrackingId(requestCode);		
				originationDetailsType.setConversationID(requestCode);
				originationDetailsType.setPossibleDuplicate(true);
				originationDetailsType.setCorrelationID(requestCode);
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				
				return sCBMLHeaderType;
				
			}
		   
		   public static SCBMLHeaderType populateInwardHeader(
				   String country, String channel, XMLGregorianCalendar date2, String requestCode,
				   String captureSystem, String processName, String eventType, String typeName, String domain) {
			   
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				sCBMLHeaderType.setCaptureSystem(captureSystem);
				
				ProcessType processType = new ProcessType();
				processType.setProcessName(processName);
				processType.setEventType(eventType);
				sCBMLHeaderType.setProcess(processType);
				
				BigDecimal bg = new BigDecimal(CommonConstants.DECIMAL_SIX) ;
				
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				messageDetailsType.setMessageVersion(bg);
				
				MessageType messageType = new MessageType();
				messageType.setTypeName(typeName);
				SubType  subType = new SubType();
				subType.setSubTypeName(processName);
				messageType.setSubType(subType);
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(channel);
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setCountryCode(country);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				DomainName domainName = new DomainName();
				domainName.setValue(domain);
				senderDomainType.setDomainName(domainName);
				
				SubDomainName subDomainName = new SubDomainName();
				subDomainName.setSubDomainType(domain);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				originationDetailsType.setMessageTimestamp(date2);
				originationDetailsType.setInitiatedTimestamp(date2);
				originationDetailsType.setTrackingId(requestCode);		
				originationDetailsType.setConversationID(requestCode);
				originationDetailsType.setPossibleDuplicate(true);
				originationDetailsType.setCorrelationID(requestCode);
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				
				return sCBMLHeaderType;
				
			}
		   /**
		    * Populate scbml header.
		    *
		    * @param billerPayRequestVO the biller pay request vo
		    * @param subTypeName the sub type name
		    * @param messageTypeName the message type name
		    * @param eventType the event type
		    * @param processName the process name
		    * @return the sCBML header type
		    */
			protected static SCBMLHeaderType populateCreditStatusHeader(String referenceNumber,String country,String subTypeName,String messageTypeName,String eventType,String processName) {
				 
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				
				MessageType  messageType  = new MessageType();
				SubType subType = new SubType();
				subType.setSubTypeName(subTypeName);
				messageType.setTypeName(messageTypeName);
				messageType.setSubType(subType);
				messageDetailsType.setMessageVersion(new BigDecimal("1.0"));
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				originationDetailsType.setTrackingId(referenceNumber);
				originationDetailsType.setPossibleDuplicate(true);
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(CommonConstants.I_BANKING);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				
				DomainName domainName = new DomainName();
				domainName.setValue(CommonConstants.DOMAIN_NAME);
				
				SubDomainName subDomainName = new SubDomainName();
				subDomainName.setSubDomainType(subTypeName);
				
				senderDomainType.setDomainName(domainName);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setCountryCode(country);
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				
				XMLGregorianCalendar date = getGregorianCalendar();

				originationDetailsType.setMessageTimestamp(date);
				originationDetailsType.setInitiatedTimestamp(date);
				
				ProcessType processType = new ProcessType();
				processType.setEventType(eventType);
				processType.setProcessName(processName);
				
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				sCBMLHeaderType.setCaptureSystem(CommonConstants.CAPTURING_SYSTEM);
				sCBMLHeaderType.setProcess(processType);
				return sCBMLHeaderType;
			}
		   
		   /*public static com.sc.corebanking.v6.transaction.Transaction postTransactionRequestMapping(InwardPaymentRequestVO inwardPaymentRequestVO) {
				LOGGER.info("Inside inward SingleLeg postTransactionRequestMapping ::Start");
				com.sc.corebanking.v6.transaction.Transaction transaction = new com.sc.corebanking.v6.transaction.Transaction();
						if(transaction != null && transaction.getTransactionInfo() != null) {
							LOGGER.info("Inside inward SingleLeg postTransactionRequestMapping ::After Bean Mapping ::::::::");
						    transaction.getTransactionInfo().setTransactionDate(getGregorianCalendar().toString());
							transaction.getTransactionInfo().setMessageSubType(CommonConstants.POST_SINGLE_LEG);
						    transaction.getTransactionInfo().setChannelID(CommonConstants.DOMAIN_TYPE);
							transaction.getTransactionInfo().setSCBWalletIdentifier(CommonConstants.ALIPAY_WALLET_IDENTIFIER_6);
						    transaction.getTransactionInfo().setChannelSubID(CommonConstants.ALIPAY_MAKER_ID);
						    transaction.getTransactionInfo().setTransactionBranch(CommonConstants.ALIPAY_TRANSACTION_BRANCH);
							transaction.getTransactionInfo().setTransactionStatusCode(CommonConstants.ALIPAY_TRANS_CODE_0);
							
							DebitNarration debitNaration = new DebitNarration();
							//debitNaration.setDebitNarration(txnPurpose);
							transaction.getTransactionInfo().getDebitNarration().add(debitNaration);
							
							transaction.getTransactionInfo().setTransactionType(CommonConstants.ALIPAY_CASA_TOP_UP);
							com.sc.corebanking.v6.transaction.Maker m= new com.sc.corebanking.v6.transaction.Maker();
							m.setID(CommonConstants.ALIPAY_MAKER_ID);
							transaction.getTransactionInfo().setMaker(m);
							
						}
						LOGGER.info("Inside inward SingleLeg postTransactionRequestMapping ::End");
						return transaction;
					}*/
 	 	
 	 	 /**
		 * @param billerPayRequestVO
		 * @return
		 */
    public static PayeeDetailVO getAddPayeeCSserviceMapping(BillerPayRequestVO billerPayRequestVO){
		 
		 return MappingHelper.MAPPER.map(billerPayRequestVO, PayeeDetailVO.class);
		 
	 }
    
    
    
  //CR1477, Orange Money changes Starts, 03Feb18, Vijayan A

  //Payment Transaction mappings

  public static void populateTransactionInfo(PostTransactionReqPayload postTransactionReqPayload) {

  postTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
  postTransactionReqPayload.setPayloadVersion(CommonConstants.TWO_DECIMAL);
  com.sc.corebanking.v6.transaction.Transaction transaction = new com.sc.corebanking.v6.transaction.Transaction();
//  com.sc.corebanking.v6.transaction.TransactionInfo transactionInfo = transaction.getTransactionInfo();
  com.sc.corebanking.v6.transaction.TransactionInfo transactionInfo = new com.sc.corebanking.v6.transaction.TransactionInfo();
  transactionInfo.setMessageSubType(CommonConstants.POST_SINGLE_LEG);
  transactionInfo.setForcePostFlag(CommonConstants.FLAG_NO);
  transactionInfo.setApproveInSufficientFundsFlag(CommonConstants.FLAG_NO);
  transactionInfo.setTransactionBranch(CommonConstants.EMPTY);
  transactionInfo.setTransactionPostingDate(BillpaymentMappingHelper.getGregorianCalendar().toString());
  transactionInfo.setSourceSystemName(CommonConstants.I_BANKING);
  transactionInfo.setSuspectedTransactionFlag(CommonConstants.TRUE);
  if(transaction != null ) {
	  transaction.setTransactionInfo(transactionInfo);
  }
  postTransactionReqPayload.setPostTransactionReq(transaction);

  }

  //CR1477, Orange Money changes Ends, 03Feb18, Vijayan A
  
  //Added for Orange Money
  
  public static GetPaymentDetailsReq performPaymenWallettDetailsInvoiceRequestPayload(BillerPayRequestVO billerPayRequestVO,String aggregatorIdentifier,String fieldsDelimitedStr){
		GetPaymentDetailsReq getPaymentDetailsReq = new GetPaymentDetailsReq();
				try{
				LOGGER.info("Inside BillpaymentMappingHelper:: performPaymentDetailsInvoiceRequestPayload-Start"+billerPayRequestVO.getMessageVO().getReqID());
				GetPaymentDetailsReqPayload getPaymentDetailsReqPayload = new GetPaymentDetailsReqPayload();
				getPaymentDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
				//getPaymentDetailsReqPayload.setOperationType(CommonConstants.TRANSACTION_STATUS_ENQUIRY);
				getPaymentDetailsReqPayload.setPayloadVersion(CommonConstants.PAYLOAD_API_21);
				
				InvoiceInfo invoiceInfo = new InvoiceInfo();
				invoiceInfo.setAggregatorIdentifier(aggregatorIdentifier);
				invoiceInfo.setApplicationUserID(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserID());
				invoiceInfo.setApplicationUserKey(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserKey());
				
				PaymentDetails paymentDetails = new PaymentDetails();
				
				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getAggId() ---- "+ billerPayRequestVO.getBillerPayDetailsVO().getAggId());
				if(billerPayRequestVO.getBillerPayDetailsVO().getId()!=null){
					paymentDetails.setBillerID(billerPayRequestVO.getBillerPayDetailsVO().getBillerCd()+CommonConstants.DEREG);
					LOGGER.info("paymentDetails.setBillerID for De Linking the wallet --- "+ paymentDetails.getBillerID());
				}else{
					paymentDetails.setBillerID(billerPayRequestVO.getBillerPayDetailsVO().getBillerCd()+CommonConstants.REG);
					LOGGER.info("paymentDetails.setBillerID for Linking the wallet --- "+ paymentDetails.getBillerID());
				if(billerPayRequestVO.getBillerPayDetailsVO().getBillerFields() != null){
					for (BillerField billerFieldInput : billerPayRequestVO.getBillerPayDetailsVO().getBillerFields()) {
						LOGGER.info("performPaymentDetailsInvoiceRequestPayload field info "+
					              "getFieldLabelName : "+  billerFieldInput.getFieldLabelName()+
					              "getFieldType : "+  billerFieldInput.getFieldType()+
					              "getFieldDataType : "+  billerFieldInput.getFieldDataType()+
					              "getFieldValue : "+  billerFieldInput.getFieldValue()+
								  "ReqId : "+billerPayRequestVO.getMessageVO().getReqID());
						if(!(billerFieldInput.getFieldLabelName().equalsIgnoreCase("ACCOUNT") || billerFieldInput.getFieldLabelName().equalsIgnoreCase("INFOFIELD3"))){						
							fieldsDelimitedStr=fieldsDelimitedStr.concat(billerFieldInput.getFieldLabelName().concat(CommonConstants.COLON).concat(billerFieldInput.getFieldValue())).concat(CommonConstants.COLON);
						 }
					  } 
					}
				}
				
				
					//String strBICValue = strBIC.substring(strBIC.length() - 1);
					
				/*	String strExtraField="INFOFIELD3".concat(CommonConstants.COLON).concat(strBICValue).
							concat(CommonConstants.COLON).concat("INFOFIELD2").concat(CommonConstants.COLON).concat(strCurrencyCode).concat(CommonConstants.COLON).concat("ACCOUNTID").
							concat(CommonConstants.COLON).concat(strBIC).concat(CommonConstants.COLON).concat("INFOFIELD4").concat(CommonConstants.COLON).concat(strRegDate).concat(CommonConstants.COLON).concat("INFOFIELD1").concat(CommonConstants.COLON).concat(billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName());
				*/	
				
				//fieldsDelimitedStr = fieldsDelimitedStr.concat(strExtraField);
				
				if(fieldsDelimitedStr.length()>1 && billerPayRequestVO.getBillerPayDetailsVO().getId()!=null){
					fieldsDelimitedStr=fieldsDelimitedStr.substring(0,fieldsDelimitedStr.trim().length());
				}
				else{
					fieldsDelimitedStr=fieldsDelimitedStr.substring(0,fieldsDelimitedStr.trim().length()-1);
				}
				//paymentDetails.setBillerDetails(fieldsDelimitedStr);
				 paymentDetails.setBillerDetails(fieldsDelimitedStr);
				 
				
				invoiceInfo.getPaymentDetails().add(paymentDetails);	
				com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
				invoice.setInvoiceInfo(invoiceInfo);
				
				getPaymentDetailsReqPayload.setGetPaymentDetailsReq(invoice);
				
				getPaymentDetailsReq.setGetPaymentDetailsReqPayload(getPaymentDetailsReqPayload);
				
				getPaymentDetailsReqPayload.getGetPaymentDetailsReq().setInvoiceInfo(invoiceInfo);
				getPaymentDetailsReq.setHeader(populateSRMSCBMLHeader(billerPayRequestVO,CommonConstants.AGGREGATOR_PROCESS_NAME,CommonConstants.INVOICE_NAME,CommonConstants.GET_PROCESS_EVENT_TYPE,CommonConstants.AGGREGATOR_PROCESS_NAME));
				}catch(Exception e){
					LOGGER.info("Inside BillpaymentMappingHelper:: performPaymentDetailsInvoiceRequestPayload-Exception"+billerPayRequestVO.getMessageVO().getReqID());
					LOGGER.error(" Bill PaymentMapping Helper::performPaymentDetailsInvoiceRequestPayload--StackStrace",e);
					//e.printStackTrace();
				}
				LOGGER.info("Inside BillpaymentMappingHelper:: performPaymentDetailsInvoiceRequestPayload-End"+billerPayRequestVO.getMessageVO().getReqID());
				return getPaymentDetailsReq;
				
			}
  
  

}
