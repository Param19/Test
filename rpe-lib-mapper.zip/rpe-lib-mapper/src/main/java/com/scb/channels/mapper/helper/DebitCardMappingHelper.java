package com.scb.channels.mapper.helper;

import java.math.BigDecimal;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.AuthorizeCardPurchaseReq;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.AuthorizeCardPurchaseRes;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.ReverseCardPurchaseReq;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.ReverseCardPurchaseRes;
import com.sc.scbml_1.DomainName;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.MessageSender;
import com.sc.scbml_1.MessageSenderType;
import com.sc.scbml_1.MessageType;
import com.sc.scbml_1.OriginationDetailsType;
import com.sc.scbml_1.ProcessType;
import com.sc.scbml_1.SCBMLHeaderType;
import com.sc.scbml_1.SenderDomainType;
import com.sc.scbml_1.SubDomainName;
import com.sc.scbml_1.SubType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;

public class DebitCardMappingHelper extends MappingHelper{
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(DebitCardMappingHelper.class);
	
	public static final String DEBIT_CARD_MAPPING_XML = "com/scb/channels/mapper/vo/mapping/DebitCardBeanMapping.xml";
	
	private DebitCardMappingHelper() { }
	
	static{
		MAPPER_FILES.add(DEBIT_CARD_MAPPING_XML);
		reloadMapper();
		
		LOGGER.info("Loaded DebitCard mapping file");
	}
	
	public static AuthorizeCardPurchaseReq getDebitCardAuthorizationRequest(QRPaymentDetailVO qrPaymentDetailVO) {			
		return MappingHelper.MAPPER.map(qrPaymentDetailVO, AuthorizeCardPurchaseReq.class);
	}
	
	public static QRPaymentResponseVO getDebitCardAuthorizationResponse(AuthorizeCardPurchaseRes debitCardAuthResponse) {
		return  MappingHelper.MAPPER.map(debitCardAuthResponse, QRPaymentResponseVO.class);
	}

	public static ReverseCardPurchaseReq getDebitCardReverseAuthorizationRequest(QRPaymentDetailVO qrPaymentDetailVO) {	
		return  MappingHelper.MAPPER.map(qrPaymentDetailVO, ReverseCardPurchaseReq.class);
	}

	public static QRPaymentResponseVO getDebitCardReverseAuthorizationResponse(ReverseCardPurchaseRes revDebitCardAuthResponse) {
		return  MappingHelper.MAPPER.map(revDebitCardAuthResponse, QRPaymentResponseVO.class);
	}
	
	public static SCBMLHeaderType populateHeader(
			String country, String channel, XMLGregorianCalendar date2, String requestCode,
			String captureSystem,String eventType, String typeName, String domain, String subTypeName,XMLGregorianCalendar paymentDate) {
			
			SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
			sCBMLHeaderType.setCaptureSystem(captureSystem);
			
			ProcessType processType = new ProcessType();
			processType.setEventType(eventType);
			sCBMLHeaderType.setProcess(processType);
				
			BigDecimal bg = new BigDecimal(CommonConstants.DECIMAL_ONE) ;
			
			MessageDetailsType messageDetailsType = new MessageDetailsType();
			messageDetailsType.setMessageVersion(bg);
			
			MessageType messageType = new MessageType();
			messageType.setTypeName(typeName);
			SubType  subType = new SubType();
			//subType.setSubTypeName(processName);
			subType.setSubTypeName(subTypeName);
			messageType.setSubType(subType);
			messageDetailsType.setMessageType(messageType);
			
			OriginationDetailsType originationDetailsType = new OriginationDetailsType();
			
			MessageSenderType messageSenderType = new MessageSenderType();
			MessageSender messageSender = new MessageSender();
			messageSender.setValue(channel);
			messageSenderType.setMessageSender(messageSender);
			messageSenderType.setCountryCode(country);
			
			SenderDomainType senderDomainType = new SenderDomainType();
			DomainName domainName = new DomainName();
			domainName.setValue(domain);
			senderDomainType.setDomainName(domainName);
			
			SubDomainName subDomainName = new SubDomainName();
			//subDomainName.setSubDomainType(processName);
			subDomainName.setSubDomainType(typeName);
			senderDomainType.setSubDomainName(subDomainName);
			messageSenderType.setSenderDomain(senderDomainType);
			
			originationDetailsType.setMessageSender(messageSenderType);
			originationDetailsType.setMessageTimestamp(paymentDate);
			originationDetailsType.setInitiatedTimestamp(date2);
			originationDetailsType.setTrackingId(requestCode);		
			originationDetailsType.setConversationID(requestCode);
			originationDetailsType.setPossibleDuplicate(false);
			originationDetailsType.setCorrelationID(requestCode);
			sCBMLHeaderType.setMessageDetails(messageDetailsType);
			sCBMLHeaderType.setOriginationDetails(originationDetailsType);
			
			return sCBMLHeaderType;
			
		}

}
