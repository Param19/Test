package com.scb.channels.mapper.helper;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCashAdvanceTransactionReq;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCashAdvanceTransactionRes;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCashAdvanceTransactionReq;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCashAdvanceTransactionRes;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;

/**
 * @author 1571157
 *
 */
public class CreditCardC400MappingHelper extends MappingHelper{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CreditCardC400MappingHelper.class);
	
	/** The Constant PAYMENT_XML. */
	public static final String CREDITCARD_MAPPING_C400 = "com/scb/channels/mapper/vo/mapping/CreditCardC400BeanMapping.xml";
	
	static{
		MAPPER_FILES.add(CREDITCARD_MAPPING_C400);
		reloadMapper();
		LOGGER.info("Loading CreditCard C400 mapping complete");
	}

	/**
	 * Mapping for C400 Card Authorize Purchase Request  
	 * @param billerPayRequest
	 * @return
	 */
	public static AuthorizeCardPurchaseTransactionReq getCardAuthorizationRequestC400(BillerPayRequestVO billerPayRequest) {
		AuthorizeCardPurchaseTransactionReq cardPurchaseRequestC400 = 
				MappingHelper.MAPPER.map(billerPayRequest, AuthorizeCardPurchaseTransactionReq.class,"CardAuthRequestC400");
	//	LOGGER.info("CreDtTime in C400MappingHelper: "+cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getHdr().getCreDtTm());
		/*//authorizeCardPurchaseTransactionReqPayload.authorizeCardPurchaseTransactionReq.document.acqrrAuthstnInitn.hdr.creDtTm
		if(cardPurchaseRequestC400!=null && cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload() !=null 
				&& cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq() !=null 
				&& cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument() !=null 
				&& cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn() !=null
				&& cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getHdr() !=null ){
			cardPurchaseRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getHdr().setCreDtTm(BillpaymentMappingHelper.getGregorianCalendar()); 
		}*/
		return cardPurchaseRequestC400;
	}
	
	/**
	 * Mapping for C400 Card Auth Purchase Response 
	 * @param cardAuthResponse
	 * @return
	 */
	public static BillerPayResponseVO getCardAuthorizationResponseC400(AuthorizeCardPurchaseTransactionRes cardAuthResponse) {
		return  MappingHelper.MAPPER.map(cardAuthResponse, BillerPayResponseVO.class,"CardAuthResponseC400");
	}

	/**
	 * Mapping for C400 Card Auth Reverse Purchase Response 
	 * @param revCardAuthResponse
	 * @return
	 */
	public static BillerPayResponseVO getReverseCardAuthorizationResponseC400(ReverseCardPurchaseTransactionRes revCardAuthResponse) {
		return  MappingHelper.MAPPER.map(revCardAuthResponse, BillerPayResponseVO.class,"ReverseCardAuthResponseC400");
	}
	
	/**
	 * Mapping for C400 Reverse Card Auth Purchase Request
	 * @param billerPayRequest
	 * @return
	 */
	public static ReverseCardPurchaseTransactionReq getReverseCardAuthorizationRequestC400(BillerPayRequestVO billerPayRequest) {
		ReverseCardPurchaseTransactionReq reverseCardPurchReq = MappingHelper.MAPPER.map(billerPayRequest, ReverseCardPurchaseTransactionReq.class,"ReverseCardAuthRequestC400");
		/*//reverseCardPurchaseTransactionReqPayload.reverseCardPurchaseTransactionReq.document.acqrrRvslInitn.rvslInitn.tx.accptrTxDtTm
		if(reverseCardPurchReq!=null && reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload()!=null
				&& reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq() !=null 
				&& reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument() !=null 
				&& reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn() !=null
				&& reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn() !=null 
				&& reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getTx() !=null){
			reverseCardPurchReq.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getTx().setAccptrTxDtTm(BillpaymentMappingHelper.getGregorianCalendar());
		}*/
		return  reverseCardPurchReq;
	}
	
	/**
	 * Method to convert amount as per C400's requirement
	 * Ex. 1234 will be consider as 12.34
	 * 123400 is consider as value 1234
	 * @param amount
	 * @return
	 */
	public static String getConvertedStrAmount(BigDecimal amount) {
		return (Arrays.asList((String.valueOf(amount.multiply(new BigDecimal(CommonConstants.HUNDRED))).split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
	}

	/**
	 * Method to populate original data elements in a single field for C400 reversal
	 * @param orgMsgTypId - lookup value of the Message Type Id - 4 chars
	 * @param orgSTAN  - STAN sent during the authorization - 6 chars
	 * @param OrgTranxDtTime - datetime sent during authorize txn - 11 chars
	 * @param orgAcquiringInst - original acquiring institution - 11 chars
	 * @param orgForwardingInst - original forwarding institution - 11 chars
	 * @return originalMessageType of total 42 chars
	 */
	public static String populateOrgMessageType(String orgMsgTypId, String orgSTAN, Date OrgTranxDtTime, String orgAcquiringInst, String orgForwardingInst){
		  LOGGER.info("PopulateOrgMessageType : start");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(CommonConstants.CARDS400_DATEFORMAT);
        String originalMessageType="";
        try{
            String paymentDateStr = simpleDateFormat.format(OrgTranxDtTime);
            originalMessageType = orgMsgTypId + orgSTAN + paymentDateStr + orgAcquiringInst + orgForwardingInst;
        }catch(Exception ex){
               LOGGER.info(":::::: error in getOriginalMessageType::::::"+ex.getMessage());
        }
        LOGGER.info("PopulateOrgMessageType: end : originalMessageType: "+originalMessageType);
        return originalMessageType;
	}
	

}
