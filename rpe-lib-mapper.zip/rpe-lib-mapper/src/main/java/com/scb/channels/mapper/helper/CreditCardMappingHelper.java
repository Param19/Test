package com.scb.channels.mapper.helper;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;

public class CreditCardMappingHelper  extends MappingHelper {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CreditCardMappingHelper.class);
	
	/** The Constant PAYMENT_XML. */
	public static final String CREDITCARD_MAPPING = "com/scb/channels/mapper/vo/mapping/CreditCardBeanMapping.xml";
	
	static{
		MAPPER_FILES.add(CREDITCARD_MAPPING);
		reloadMapper();
		LOGGER.info("Loading CreditCard mapping complete");
	}
	
	public static AuthorizeCardPurchaseTransactionReq getCardAuthorizationRequest(BillerPayRequestVO billerPayRequest) {
		
		String narration = CommonConstants.ALIPAY_AGGREGATOR + " C" + 
				billerPayRequest.getBillerPayDetailsVO().getConsumerNo();
		billerPayRequest.getBillerPayDetailsVO().getTransactionInfoVO().setTxnAuthId(narration);
		
		AuthorizeCardPurchaseTransactionReq cardPurchaseRequest = 
				MappingHelper.MAPPER.map(billerPayRequest, AuthorizeCardPurchaseTransactionReq.class);
		
		if(cardPurchaseRequest != null && cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().
					getAcqrrAuthstnInitn().getAuthstnInitn() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().
					getAcqrrAuthstnInitn().getAuthstnInitn().getTx() != null) {
			
			LOGGER.info("Setting date value in post payment request ::: "
					+ billerPayRequest.getBillerPayDetailsVO().getPayRef());
			
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
			getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().
			getAcqrrAuthstnInitn().getAuthstnInitn().getTx().setAccptrTxDtTm(getGregorianCalendar());
		}
		
		return  cardPurchaseRequest;
		
		
	}
	
	public static BillerPayResponseVO getCardAuthorizationResponse(AuthorizeCardPurchaseTransactionRes cardAuthResponse) {
		return  MappingHelper.MAPPER.map(cardAuthResponse, BillerPayResponseVO.class);
	}
	
	public static ReverseCardPurchaseTransactionReq getReverseCardAuthorizationRequest(BillerPayRequestVO billerPayRequest) {
		
		String narration = CommonConstants.ALIPAY_AGGREGATOR + " C" + 
				billerPayRequest.getBillerPayDetailsVO().getConsumerNo() + "-REV";
		billerPayRequest.getBillerPayDetailsVO().getTransactionInfoVO().setTxnAuthId(narration);
		
		return  MappingHelper.MAPPER.map(billerPayRequest, ReverseCardPurchaseTransactionReq.class);
	}
	
	public static BillerPayResponseVO getReverseCardAuthorizationResponse(ReverseCardPurchaseTransactionRes revCardAuthResponse) {
		return  MappingHelper.MAPPER.map(revCardAuthResponse, BillerPayResponseVO.class);
	}
	
	private static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
		return date;
	}
		
public static AuthorizeCardPurchaseTransactionReq getQRCardAuthorizationRequest(QRPaymentDetailVO qrPaymentDetailVO) {
		
	
		AuthorizeCardPurchaseTransactionReq cardPurchaseRequest = 
				MappingHelper.MAPPER.map(qrPaymentDetailVO, AuthorizeCardPurchaseTransactionReq.class);
		
		if(cardPurchaseRequest != null && cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().
					getAcqrrAuthstnInitn().getAuthstnInitn() != null &&
				cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
					getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().
					getAcqrrAuthstnInitn().getAuthstnInitn().getTx() != null) {
			
			LOGGER.info("Setting date value in post payment request ::: ");
			
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
			getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().
			getAcqrrAuthstnInitn().getAuthstnInitn().getTx().setAccptrTxDtTm(getGregorianCalendar());
		}
		
		return  cardPurchaseRequest;
		
	}

public static QRPaymentResponseVO getQRCardAuthorizationResponse(AuthorizeCardPurchaseTransactionRes cardAuthResponse) {
	return  MappingHelper.MAPPER.map(cardAuthResponse, QRPaymentResponseVO.class);
}

public static ReverseCardPurchaseTransactionReq getQRReverseCardAuthorizationRequest(QRPaymentDetailVO qrPaymentDetailVO) {
	
	/*String narration = CommonConstants.ALIPAY_AGGREGATOR + " C" + 
			billerPayRequest.getBillerPayDetailsVO().getConsumerNo() + "-REV";
	billerPayRequest.getBillerPayDetailsVO().getTransactionInfoVO().setTxnAuthId(narration);*/
	
	return  MappingHelper.MAPPER.map(qrPaymentDetailVO, ReverseCardPurchaseTransactionReq.class);
}

public static QRPaymentResponseVO getQRReverseCardAuthorizationResponse(ReverseCardPurchaseTransactionRes revCardAuthResponse) {
	return  MappingHelper.MAPPER.map(revCardAuthResponse, QRPaymentResponseVO.class);
}

public static com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq getQRCardAuthorizationV2Request(QRPaymentDetailVO qrPaymentDetailVO) {
	
	
	com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq cardPurchaseRequest = 
			MappingHelper.MAPPER.map(qrPaymentDetailVO, com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq.class);
	
	if(cardPurchaseRequest != null && cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload() != null &&
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq() != null &&
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
			getAuthorizeCardPurchaseTransactionReq().getDocument() != null &&
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
			getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn() != null &&
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
			getAuthorizeCardPurchaseTransactionReq().getDocument().
				getAcqrrAuthstnInitn().getAuthstnInitn() != null &&
			cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
			getAuthorizeCardPurchaseTransactionReq().getDocument().
				getAcqrrAuthstnInitn().getAuthstnInitn().getTx() != null) {
		
		LOGGER.info("Setting date value in post payment request ::: ");
		
		cardPurchaseRequest.getAuthorizeCardPurchaseTransactionReqPayload().
		getAuthorizeCardPurchaseTransactionReq().getDocument().
		getAcqrrAuthstnInitn().getAuthstnInitn().getTx().setAccptrTxDtTm(getGregorianCalendarWithoutMS());
	}
	
	return  cardPurchaseRequest;
	
}
	public static QRPaymentResponseVO getQRCardAuthorizationV2Response(com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes cardAuthResponse) {
		return  MappingHelper.MAPPER.map(cardAuthResponse, QRPaymentResponseVO.class);
	}
	
	private static XMLGregorianCalendar getGregorianCalendarWithoutMS() {
	    XMLGregorianCalendar date = null;
	    try {
			GregorianCalendar c = new GregorianCalendar();
			c.setTime(DateUtils.getCurrentDate());
	        date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
	        date.setMillisecond(DatatypeConstants.FIELD_UNDEFINED);
	    } catch (DatatypeConfigurationException e) {
	    }
	    return date;
	}
	
	
	/**
	 * @param qrPaymentDetailVO
	 * @return
	 */
	public static com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq getQRReverseCardAuthorizationV2Request(
			QRPaymentDetailVO qrPaymentDetailVO) {

		/*
		 * String narration = CommonConstants.ALIPAY_AGGREGATOR + " C" +
		 * billerPayRequest.getBillerPayDetailsVO().getConsumerNo() + "-REV";
		 * billerPayRequest
		 * .getBillerPayDetailsVO().getTransactionInfoVO().setTxnAuthId
		 * (narration);
		 */

		com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq reverseAuthorizeCardRequest= MappingHelper.MAPPER.map(qrPaymentDetailVO,
				com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq.class);
		
		if (reverseAuthorizeCardRequest != null
				&& reverseAuthorizeCardRequest
						.getReverseCardPurchaseTransactionReqPayload() != null
				&& reverseAuthorizeCardRequest
						.getReverseCardPurchaseTransactionReqPayload()
						.getReverseCardPurchaseTransactionReq() != null
				&& reverseAuthorizeCardRequest
						.getReverseCardPurchaseTransactionReqPayload()
						.getReverseCardPurchaseTransactionReq().getDocument() != null
				&& reverseAuthorizeCardRequest
						.getReverseCardPurchaseTransactionReqPayload()
						.getReverseCardPurchaseTransactionReq().getDocument()
						.getAcqrrRvslInitn() != null
				&& reverseAuthorizeCardRequest
						.getReverseCardPurchaseTransactionReqPayload()
						.getReverseCardPurchaseTransactionReq().getDocument()
						.getAcqrrRvslInitn().getRvslInitn() != null
				&& reverseAuthorizeCardRequest
						.getReverseCardPurchaseTransactionReqPayload()
						.getReverseCardPurchaseTransactionReq().getDocument()
						.getAcqrrRvslInitn().getRvslInitn().getTx() != null) {

						LOGGER.info("Setting date value in post payment request ::: ");

							reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload()
								.getReverseCardPurchaseTransactionReq().getDocument()
								.getAcqrrRvslInitn().getRvslInitn().getTx()
								.setAccptrTxDtTm(getGregorianCalendarWithoutMS());
			}
		
		return reverseAuthorizeCardRequest;
	}

	/**
	 * @param revCardAuthResponse
	 * @return
	 */
	public static QRPaymentResponseVO getQRReverseCardAuthorizationV2Response(
			com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes revCardAuthResponse) {
		return MappingHelper.MAPPER.map(revCardAuthResponse,
				QRPaymentResponseVO.class);
	}
	
}
