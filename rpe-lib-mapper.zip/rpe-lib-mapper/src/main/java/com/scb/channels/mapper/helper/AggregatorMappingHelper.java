/**
 * 
 */
package com.scb.channels.mapper.helper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.sc.cash.payment.mobile.v2.invoice.Invoice;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillerCategoriesReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersProductsReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersReq;
import com.scb.channels.base.vo.BackupMasterBillerCategoryVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.base.vo.TempBillerVO;


 


 
public final class AggregatorMappingHelper extends MappingHelper {
	
 
	/** The Constant LOGGER. */
	//private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AggregatorMappingHelper.class);
	
	/** The Constant PAYMENT_XML. */
	public static final String Aggregator_XML = "com/scb/channels/mapper/vo/mapping/AggregatorBeanMapping.xml";

	/**
	 * Instantiates a new billpayment mapping helper.
	 */
	private AggregatorMappingHelper() {
	}
	
	static{
		MAPPER_FILES.add(Aggregator_XML);
		reloadMapper();
	}
	
	/**
	 * <P> MAPPING  for the aggregator mapping request.
	 * @param BillerDownloadRequest
	 * @return GetBillerCategoriesReq 
	 */
	public static GetBillerCategoriesReq getBillerCategoryMapping(BillerDownloadRequest RequestVo) {
		return  MappingHelper.MAPPER.map(RequestVo, GetBillerCategoriesReq.class);
	}
	
	/**
	 * <P> MAPPING  for the aggregator reponse billerCategory
	 * @param Invoice
	 * @return BillerDownloadResponse 
	 */
	public static BillerDownloadResponse getBillerCategoryMapping(Invoice resposne) {
		return  MappingHelper.MAPPER.map(resposne, BillerDownloadResponse.class);
	}
	
	
	/**
	 * <P> MAPPING  for the aggregator mapping request.
	 * @param BillerDownloadRequest
	 * @return GetBillerCategoriesReq 
	 */
	public static GetBillersProductsReq getBillerProductMapping(BillerDownloadRequest RequestVo) {
		return  MappingHelper.MAPPER.map(RequestVo, GetBillersProductsReq.class);
	}
	
	
	/**
	 * <P> MAPPING  for the aggregator Biller mapping request.
	 * @param BillerDownloadRequest
	 * @return GetBillersReq 
	 */
	public static GetBillersReq getAllBillerMapping(BillerDownloadRequest RequestVo) {
		
		return  MappingHelper.MAPPER.map(RequestVo, GetBillersReq.class);
	}
	
	
	/**
	 * <P> MAPPING  for the aggregator Biller mapping request.
	 * @param BillerDownloadRequest
	 * @return GetBillersReq 
	 */
	public static Set<TempBillerCategoryVO> getAllBillerResponseMappings(List<com.sc.cash.payment.mobile.v2.invoice.BillerCategory> category) {
		  Set<TempBillerCategoryVO> tempCategory=new HashSet<TempBillerCategoryVO>();
		  MappingHelper.MAPPER.map(category,tempCategory,"AggeId2");
		  return tempCategory;
	}
	
	public static TempBillerCategoryVO getBillerResponseSingleMapping(com.sc.cash.payment.mobile.v2.invoice.BillerCategory category) {
		 
		
		  return   MappingHelper.MAPPER.map(category,TempBillerCategoryVO.class,"AggeId9");
	}
	 
	public static void getMappingempBillersCatgeoryToMasterCatgeory(List<TempBillerCategoryVO> tempcategory,List<BillerCategoryVO> Master) {
		
		     MappingHelper.MAPPER.map(tempcategory,Master,"tempBillerToMasterBillers");
	}
	
	public static void getMappingBillersToMasterBiller(Set<TempBillerVO> tempcategory,Set<BillerVO> Master) {
		
	     MappingHelper.MAPPER.map(tempcategory,Master,"tempSpecificBillerToMasterSpecificBillers");
	}
	public static void getMappingBillersToMasterBiller(TempBillerVO tempcategory,BillerVO Master) {
		
	     MappingHelper.MAPPER.map(tempcategory,Master);
	}
	
	public static void getStaticCategoryfromRefCategeory(List<BillerCatgegoryReference>  categoryRef,List<TempBillerCategoryVO> tempCategory) {
		
	     MappingHelper.MAPPER.map(categoryRef,tempCategory,"staticCategoryFromRefCategory");
	}
	public static void getBackupfromMaster(List<BillerCategoryVO> tempCategory,List<BackupMasterBillerCategoryVO>  backupCategory) {
		
	     MappingHelper.MAPPER.map(tempCategory,backupCategory,"Masterbackup");
	}
	
}
