package com.scb.channels.mapper.helper;

import com.scb.channels.base.vo.QRAuditTxnVO;
import com.scb.channels.base.vo.QRPaymentApiRequestVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentHistoryResponseVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.qrpayments.QrPaymentHistoryRequestType;
import com.scb.channels.qrpayments.QrPaymentHistoryResponseType;
import com.scb.channels.qrpayments.QrPaymentRequestType;
import com.scb.channels.qrpayments.QrPaymentResponseType;
import com.scb.channels.base.vo.QRPaymentApiResponseVO;

public final class QRPaymentMappingHelper extends MappingHelper{
	
	/** The Constant PAYMENT_XML. */
	public static final String QRPAYMENT_XML = "com/scb/channels/mapper/vo/mapping/QRPaymentsBeanMapping.xml";

	private QRPaymentMappingHelper(){
		
	}
	
	static{
		MAPPER_FILES.add(QRPAYMENT_XML);
		reloadMapper();
	}
	
	public static QRPaymentRequestVO getQRPaymentRequestVOMapping(QrPaymentRequestType qrPaymentRequestType) {
		return  MappingHelper.MAPPER.map(qrPaymentRequestType, QRPaymentRequestVO.class);
		
	}
	
	public static QRPaymentVO getQRPaymentVO(QRPaymentDetailVO qrPaymentDetailVO){
		return MappingHelper.MAPPER.map(qrPaymentDetailVO, QRPaymentVO.class);
	}
	
	public static QRPaymentHistoryRequestVO getQRPaymentHistoryRequestVOMapping(QrPaymentHistoryRequestType qrPaymentHistoryRequestType) {
		return  MappingHelper.MAPPER.map(qrPaymentHistoryRequestType, QRPaymentHistoryRequestVO.class);
	}
	
	public static QrPaymentResponseType getQRPaymentResponseVOMapping(QRPaymentResponseVO qrPaymentResponseVO){
		return  MappingHelper.MAPPER.map(qrPaymentResponseVO, QrPaymentResponseType.class);
	}
	
	public static QrPaymentHistoryResponseType getQRHistoryViewResponseVOMapping(QRPaymentHistoryResponseVO qRPaymentHistoryResponseVO){
		return  MappingHelper.MAPPER.map(qRPaymentHistoryResponseVO, QrPaymentHistoryResponseType.class);
	}
	
	/**Changes made for QRAudit VO*/

	public static QRAuditTxnVO getQRAuditVO(QRPaymentDetailVO qRPaymentDetailVO) {
		return   MAPPER.map(qRPaymentDetailVO, QRAuditTxnVO.class);
	}
	
	public static QRPaymentDetailVO getQRPaymentDetailMapping(QRPaymentVO qrPaymentVO){
		return   MappingHelper.MAPPER.map(qrPaymentVO, QRPaymentDetailVO.class,"QRPaymentDetailVO");
	}

	public static QRPaymentRequestVO getQRPaymentRequestRestVOMapping(QRPaymentApiRequestVO qrPaymentApiRequest) {
		return  MappingHelper.MAPPER.map(qrPaymentApiRequest, QRPaymentRequestVO.class);
		
	}

	public static QRPaymentApiResponseVO getQRPaymentResponseRestVOMapping(QRPaymentResponseVO qrPaymentResponseVO){
		return  MappingHelper.MAPPER.map(qrPaymentResponseVO, QRPaymentApiResponseVO.class);
	}
	
}
