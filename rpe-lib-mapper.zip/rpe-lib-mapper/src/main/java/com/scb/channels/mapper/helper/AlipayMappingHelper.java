package com.scb.channels.mapper.helper;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.invoice.TransactionStatus2;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsRes;
import com.sc.corebanking.v6.transaction.DebitNarration;
import com.sc.corebanking.v6.transaction.GetTransactionStatusReq;
import com.sc.corebanking.v6.transaction.GetTransactionStatusReqPayload;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.GetTransactionStatusResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.ReverseTransactionResponse;
import com.sc.scbml_1.DomainName;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.MessageSender;
import com.sc.scbml_1.MessageSenderType;
import com.sc.scbml_1.MessageType;
import com.sc.scbml_1.OriginationDetailsType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.ProcessType;
import com.sc.scbml_1.SCBMLHeaderType;
import com.sc.scbml_1.SenderDomainType;
import com.sc.scbml_1.SubDomainName;
import com.sc.scbml_1.SubType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.TransactionInfoVO;

public class AlipayMappingHelper extends MappingHelper {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AlipayMappingHelper.class);
	
	/** The Constant ALIPAY_MAPPING_XML. */
	public static final String ALIPAY_MAPPING_XML = "com/scb/channels/mapper/vo/mapping/AlipayBeanMapping.xml";

	/**
	 * Instantiates a new ALIPAY mapping helper.
	 */
	private AlipayMappingHelper() {	}
	
	static{
		MAPPER_FILES.add(ALIPAY_MAPPING_XML);
		reloadMapper();
		
		LOGGER.info("Loaded Alipay mapping file");
	}

	public static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
		return date;
	}

	public static XMLGregorianCalendar getGregorianCalFromTimestamp(Timestamp dateTime) {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(dateTime);
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
		return date;
	}
	
	// Added for Hogan - Start
	
		/** postTransactionRequestMapping - Hogan Service
		 * @param billerPayRequestVO
		 * @return
		 */
	
	public static com.sc.corebanking.v6.transaction.Transaction postTransactionRequestMapping(
			BillerPayRequestVO billerPayRequestVO, String action) {
		LOGGER.info("Inside Alipay SingleLeg postTransactionRequestMapping ::Start");
		com.sc.corebanking.v6.transaction.Transaction transaction = MappingHelper.MAPPER.map(billerPayRequestVO,com.sc.corebanking.v6.transaction.Transaction.class);
				
				if(transaction != null && transaction.getTransactionInfo() != null) {
					LOGGER.info("Inside Alipay SingleLeg postTransactionRequestMapping ::After Bean Mapping ::::::::");
				    transaction.getTransactionInfo().setTransactionDate(getGregorianCalendar().toString());
					transaction.getTransactionInfo().setMessageSubType(CommonConstants.POST_SINGLE_LEG);
				    transaction.getTransactionInfo().setChannelID(CommonConstants.DOMAIN_TYPE);
					transaction.getTransactionInfo().setSCBWalletIdentifier(CommonConstants.ALIPAY_WALLET_IDENTIFIER_6);
				    transaction.getTransactionInfo().setChannelSubID(CommonConstants.ALIPAY_MAKER_ID);
				    transaction.getTransactionInfo().setTransactionBranch(CommonConstants.ALIPAY_TRANSACTION_BRANCH);
					transaction.getTransactionInfo().setTransactionStatusCode(CommonConstants.ALIPAY_TRANS_CODE_0);
					
					String txnPurpose = CommonConstants.ALIPAY_AGGREGATOR + " A" + 
							billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo();
					if(action != null && action.equalsIgnoreCase(CommonConstants.REVERSAL)){
						txnPurpose = txnPurpose + "-REV";
					}
					
					/*if(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnPurpose() != null) {
						txnPurpose = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnPurpose();
					}
					txnPurpose = txnPurpose != null ? ((txnPurpose.length() > 25) ? txnPurpose.substring(0, 24) : txnPurpose) 
							: "Wallet id " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo();*/

					LOGGER.info("Naration for Alipay top up ::: " + txnPurpose + "Paymemnt reference ::: "
							+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
					
					DebitNarration debitNaration = new DebitNarration();
					debitNaration.setDebitNarration(txnPurpose);
					transaction.getTransactionInfo().getDebitNarration().add(debitNaration);
					
					transaction.getTransactionInfo().setTransactionType(CommonConstants.ALIPAY_CASA_TOP_UP);
					/*if(billerPayRequestVO.getBillerPayDetailsVO().getPaymentType().equalsIgnoreCase(CommonConstants.CASA)){
						transaction.getTransactionInfo().setTransactionType(CommonConstants.ALIPAY_CASA_TOP_UP);
					}else{
						transaction.getTransactionInfo().setTransactionType(CommonConstants.ALIPAY_THRU_CREDIT_CARD);
					}*/
					com.sc.corebanking.v6.transaction.Maker m= new com.sc.corebanking.v6.transaction.Maker();
					m.setID(CommonConstants.ALIPAY_MAKER_ID);
					transaction.getTransactionInfo().setMaker(m);
					
				}
				LOGGER.info("Inside Alipay SingleLeg postTransactionRequestMapping ::End");
				return transaction;
			}
				
		
		/**
		 * @param postTransactionResponse
		 * @return
		 */
		public static BillerPayResponseVO postTransactionResponseMapping(PostTransactionResponse postTransactionResponse) {
			return MappingHelper.MAPPER.map(postTransactionResponse,BillerPayResponseVO.class);
		}
		
		
		/**
		 * @param reversalTransactionResponse
		 * @return
		 */
		public static BillerPayResponseVO reverseTransactionResponseMapping(ReverseTransactionResponse reverseTransactionResponse) {
			return MappingHelper.MAPPER.map(reverseTransactionResponse,BillerPayResponseVO.class);
		}
		   /**
		    * Populate header.
		    *
		    * @param country the country
		    * @param channel the channel
		    * @param date2 the date2
		    * @param requestCode the request code
		    * @return the sCBML header type
		    */
		   public static SCBMLHeaderType populateHeader(
				   String country, String channel, XMLGregorianCalendar date2, String requestCode,
				   String captureSystem, String processName, String eventType, String typeName, String domain) {
				
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				sCBMLHeaderType.setCaptureSystem(captureSystem);
				
				ProcessType processType = new ProcessType();
				processType.setProcessName(processName);
				processType.setEventType(eventType);
				sCBMLHeaderType.setProcess(processType);
			
				
				BigDecimal bg = new BigDecimal(CommonConstants.DECIMAL_ONE) ;
				
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				messageDetailsType.setMessageVersion(bg);
				
				MessageType messageType = new MessageType();
				messageType.setTypeName(typeName);
				SubType  subType = new SubType();
				//subType.setSubTypeName(processName);
				subType.setSubTypeName(eventType);
				messageType.setSubType(subType);
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(channel);
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setCountryCode(country);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				DomainName domainName = new DomainName();
				domainName.setValue(domain);
				senderDomainType.setDomainName(domainName);
				
				SubDomainName subDomainName = new SubDomainName();
				//subDomainName.setSubDomainType(processName);
				subDomainName.setSubDomainType(domain);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				originationDetailsType.setMessageTimestamp(date2);
				originationDetailsType.setInitiatedTimestamp(date2);
				originationDetailsType.setTrackingId(requestCode);		
				originationDetailsType.setConversationID(requestCode);
				originationDetailsType.setPossibleDuplicate(true);
				originationDetailsType.setCorrelationID(requestCode);
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				
				return sCBMLHeaderType;
				
			}
		   
		   /**
		    * Populate header.
		    *
		    * @param country the country
		    * @param channel the channel
		    * @param date2 the date2
		    * @param requestCode the request code
		    * @return the sCBML header type
		    */
		   public static SCBMLHeaderType populateHeaderGetPaymentStatus(
				   String country, String channel, XMLGregorianCalendar date2, String requestCode,
				   String captureSystem, String processName, String eventType, String typeName, String domain) {
				
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				sCBMLHeaderType.setCaptureSystem(captureSystem);
				
				ProcessType processType = new ProcessType();
				processType.setProcessName(processName);
				processType.setEventType(processName);
				sCBMLHeaderType.setProcess(processType);
			
				
				BigDecimal bg = new BigDecimal(2.0) ;
				
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				messageDetailsType.setMessageVersion(bg);
				
				MessageType messageType = new MessageType();
				messageType.setTypeName("Cash:MobileInvoice");
				SubType  subType = new SubType();
				//subType.setSubTypeName(processName);
				subType.setSubTypeName(processName);
				messageType.setSubType(subType);
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(channel);
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setCountryCode(country);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				DomainName domainName = new DomainName();
				domainName.setValue(domain);
				senderDomainType.setDomainName(domainName);
				
				SubDomainName subDomainName = new SubDomainName();
				//subDomainName.setSubDomainType(processName);
				subDomainName.setSubDomainType(domain);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				originationDetailsType.setMessageTimestamp(date2);
				originationDetailsType.setInitiatedTimestamp(date2);
				originationDetailsType.setTrackingId(requestCode);		
				originationDetailsType.setConversationID(requestCode);
				originationDetailsType.setPossibleDuplicate(true);
				originationDetailsType.setCorrelationID(requestCode);
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				
				return sCBMLHeaderType;
				
			}
		   
			/**
			 * Gets the reversal fund transfer response.
			 *
			 * @param reverseTransactionRes the reverse transaction res
			 * @param billerPayRequestVO the biller pay request vo
			 * @return the reversal fund transfer response
			 */
			public static BillerPayResponseVO reversalPostPaymentResponseMapping(
					ReverseTransactionResponse reverseTransactionRes, BillerPayRequestVO billerPayRequestVO){
				LOGGER.info("::::::::::::::reversalPostPaymentResponseMapping method ::::Start::: " );
				BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
				BillerPayDetailsVO billpayDetails = billerPayRequestVO.getBillerPayDetailsVO();
				
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
				
				try{
					if (reverseTransactionRes.getReverseTransactionResponse().getHeader().getExceptions() != null) {
						// Check if there is any exception from eBBS response
						for (ExceptionType exceptionType : reverseTransactionRes.getReverseTransactionResponse().getHeader()
								.getExceptions().getException()) {
							LOGGER.info("Exceptions present in the reversal response :Alipay:: " +	billpayDetails.getPayRef());
							LOGGER.info("Reversal Exceptions code ::Alipay: " + exceptionType.getCode().getValue() 
									+ " ::: " +	billpayDetails.getPayRef());
							LOGGER.info("Reversal Exceptions description :Alipay:: " +	exceptionType.getDescription()
									+ " ::: " +	billpayDetails.getPayRef());
							
								LOGGER.info("Reversal Failed ::Alipay: " 
										+ billpayDetails.getPayRef()
										+ exceptionType.getCode().getValue()
										+ exceptionType.getDescription());
								
								billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
								billpayDetails.getTransactionInfoVO()
										.setTxnStatusCd(CommonConstants.FAIL);
								
								billerPayResponseVO.setStatusDesc(
										exceptionType.getDescription());
								billerPayResponseVO.setStatus(
										exceptionType.getCode().getValue());
							
							
							billpayDetails.getTransactionInfoVO()
								.setHostRespCd(exceptionType.getCode().getValue());
							billpayDetails.getTransactionInfoVO()
								.setHostRespDesc(exceptionType.getDescription());
						}
						
					} else {
						if(reverseTransactionRes.getReverseTransactionResponse().
								getReverseTransactionResPayload() != null &&
							reverseTransactionRes.getReverseTransactionResponse().
								getReverseTransactionResPayload().getReverseTransactionRes() != null &&
							reverseTransactionRes.getReverseTransactionResponse().
								getReverseTransactionResPayload().getReverseTransactionRes().
								getTransactionInfo() != null && 
							reverseTransactionRes.getReverseTransactionResponse().
								getReverseTransactionResPayload().getReverseTransactionRes().
								getTransactionInfo().getTransactionStatusCode() != null &&
							reverseTransactionRes.getReverseTransactionResponse().
								getReverseTransactionResPayload().getReverseTransactionRes().
								getTransactionInfo().getTransactionStatusCode().equalsIgnoreCase("00000")) {
							
							LOGGER.info("Reversal Successful :: Alipay ::: " 
								+ billpayDetails.getPayRef() + " - "
								+ reverseTransactionRes.getReverseTransactionResponse().getReverseTransactionResPayload().
									getReverseTransactionRes().getTransactionInfo().getTransactionStatus()
								+" - "+ reverseTransactionRes.getReverseTransactionResponse().getReverseTransactionResPayload().
									getReverseTransactionRes().getTransactionInfo().getTransactionStatusCode()
								+" - "+reverseTransactionRes.getReverseTransactionResponse().getReverseTransactionResPayload().
									getReverseTransactionRes().getTransactionInfo().getTransactionStatusDescription());
							
							billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_SUCCESS);
							billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.SUCC);
							
						} else {
							
							LOGGER.info("Reversal Failure :: Alipay ::: " 
								+ billpayDetails.getPayRef() + " - "
								+ reverseTransactionRes.getReverseTransactionResponse().getReverseTransactionResPayload().
									getReverseTransactionRes().getTransactionInfo().getTransactionStatus()
								+" - "+ reverseTransactionRes.getReverseTransactionResponse().getReverseTransactionResPayload().
									getReverseTransactionRes().getTransactionInfo().getTransactionStatusCode()
								+" - "+reverseTransactionRes.getReverseTransactionResponse().getReverseTransactionResPayload().
									getReverseTransactionRes().getTransactionInfo().getTransactionStatusDescription());
							
							billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
							billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
						}
						
						billpayDetails.getTransactionInfoVO().setHostRespCd(
							reverseTransactionRes.getReverseTransactionResponse().
							getReverseTransactionResPayload().getReverseTransactionRes().
							getTransactionInfo().getTransactionStatusCode());
						billpayDetails.getTransactionInfoVO().setHostRespDesc(
							reverseTransactionRes.getReverseTransactionResponse().
							getReverseTransactionResPayload().getReverseTransactionRes().
							getTransactionInfo().getTransactionStatusDescription());
					}
					
					billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
				} catch (Exception exception) {
					LOGGER.info("Exception occurred while getReversalBillPaymentResponse reversal Alipay payment ::: " + exception);
					LOGGER.error("Exception occurred while getReversalBillPaymentResponse reversal Alipay payment ::: " + exception);
					
					throw exception;
				}
					
				LOGGER.info("reversal Bill payment :::Alipay::::: End");
				return billerPayResponseVO;
			}
	
			
			/**
			 * @param billerPayRequestVO
			 * @return
			 */
			/**
			 * @param billerPayRequestVO
			 * @return
			 */
			public static com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsReq validateWalletDetatilsRequestWraper(
					BillerPayRequestVO billerPayRequestVO) {
				LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsWraper --Start ");
				com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsReq getPaymentDetailsReq = null;
				try {
					getPaymentDetailsReq = new com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsReq();
					com.sc.scbml_1.GetPaymentDetailsReqPayload getPaymentDetailsReqPayload = new com.sc.scbml_1.GetPaymentDetailsReqPayload();
					getPaymentDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
					getPaymentDetailsReqPayload.setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
					
					com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo invoiceInfo = new com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo();
					invoiceInfo.setApplicationUserID(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserID());
					invoiceInfo.setApplicationUserKey(billerPayRequestVO.getBillerPayDetailsVO().getApplicationUserKey());
					
					com.sc.cash.payment.mobile.v2.invoice.PaymentDetails paymentDetails = new com.sc.cash.payment.mobile.v2.invoice.PaymentDetails();
					com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
					
					LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo()" + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
					paymentDetails.setAccountNumber(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
					paymentDetails.setTransactionAmountValue(billerPayRequestVO.getBillerPayDetailsVO().getTopupAmount());
					//paymentDetails.setTransactionAmount("");
					paymentDetails.setTransactionCurrencyCode(billerPayRequestVO.getBillerPayDetailsVO().getTxnCurrency());
					paymentDetails.setFundSource(billerPayRequestVO.getBillerPayDetailsVO().getSrcAccountName());
					//paymentDetails.setClientSecret("");
					LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getAggId() ---- " + billerPayRequestVO.getBillerPayDetailsVO().getAggId());
					paymentDetails.setBillerID(billerPayRequestVO.getBillerPayDetailsVO().getAggId());
					invoiceInfo.getPaymentDetails().add(paymentDetails);
					invoice.setInvoiceInfo(invoiceInfo);
					getPaymentDetailsReqPayload.setGetPaymentDetailsReq(invoice);
					getPaymentDetailsReq.setGetPaymentDetailsReqPayload(getPaymentDetailsReqPayload);
					getPaymentDetailsReq.setHeader(populateHeaderForValidatePayee(billerPayRequestVO, "getPaymentDetails", "Invoice", "get",
							"getPaymentDetails"));

				} catch (Exception e) {
					LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsWraper --Exception " + e.getMessage());
					e.printStackTrace();
				}
				LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsWraper --End ");
				return getPaymentDetailsReq;

			}

			/**
			 * @param billerPayRequestVO
			 * @param subTypeName
			 * @param messageTypeName
			 * @param eventType
			 * @param processName
			 * @return
			 */
			protected static SCBMLHeaderType populateHeaderForValidatePayee(BillerPayRequestVO billerPayRequestVO, String subTypeName,
					String messageTypeName, String eventType, String processName) {
				LOGGER.info("Inside AlipayMappingHelper :: populateHeaderForValidatePayee --Start ");
				
				//billerPayRequestVO, "getPaymentDetails", "Invoice", "get","getPaymentDetails"));
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				MessageDetailsType messageDetailsType = new MessageDetailsType();

				MessageType messageType = new MessageType();
				SubType subType = new SubType();
				subType.setSubTypeName("getPaymentDetails");
				messageType.setTypeName("Cash:MobileInvoice");
				messageType.setSubType(subType);
				messageDetailsType.setMessageVersion(new BigDecimal("2.0"));
				messageDetailsType.setMessageType(messageType);

				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				// String txnId =
				// billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnId().replaceAll(CommonConstants.HYPHEN,
				// CommonConstants.EMPTY);
				String txnId = billerPayRequestVO.getMessageVO().getReqID().replaceAll(CommonConstants.HYPHEN, CommonConstants.EMPTY);
				originationDetailsType.setTrackingId(txnId);
				originationDetailsType.setPossibleDuplicate(true);

				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue("IBNK");

				SenderDomainType senderDomainType = new SenderDomainType();
				DomainName domainName = new DomainName();
				domainName.setValue("Cash");

				SubDomainName subDomainName = new SubDomainName();
				subDomainName.setSubDomainType("Cash");
				senderDomainType.setDomainName(domainName);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setCountryCode(billerPayRequestVO.getUser().getCountry());
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setSenderDomain(senderDomainType);
				originationDetailsType.setMessageSender(messageSenderType);

				GregorianCalendar c = new GregorianCalendar();
				c.setTime(DateUtils.getCurrentDate());
				XMLGregorianCalendar date = null;
				try {
					date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
				} catch (DatatypeConfigurationException e) {
					LOGGER.info("Inside AlipayMappingHelper :: populateHeaderForValidatePayee --Excetion " + e.getMessage());
				}
				originationDetailsType.setMessageTimestamp(date);
				originationDetailsType.setInitiatedTimestamp(date);
				originationDetailsType.setPossibleDuplicate(true);
				ProcessType processType = new ProcessType();
				processType.setEventType("getPaymentDetails");
				processType.setProcessName("getPaymentDetails");
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				sCBMLHeaderType.setCaptureSystem("Alipay");
				sCBMLHeaderType.setProcess(processType);
				LOGGER.info("Inside AlipayMappingHelper :: populateHeaderForValidatePayee --END ");
				return sCBMLHeaderType;
			}

			public static BillerPayResponseVO validateWalletDetatilsResponseWraper(GetPaymentDetailsRes getPaymentDetailsRes,
					BillerPayRequestVO billerPayRequestVO) {
				LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper --Start ");
				BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
				BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
				TransactionInfoVO tranVO = new TransactionInfoVO();
				billerPayDetailsVO.setTransactionInfoVO(tranVO);
				billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
				String txnId = null;
				ExceptionListType exceptions = null;

				com.sc.scbml_1.GetPaymentDetailsResPayload getPaymentDetailsResPayload = null;
				if (getPaymentDetailsRes != null) {
					getPaymentDetailsResPayload = getPaymentDetailsRes.getGetPaymentDetailsResPayload();
					if (getPaymentDetailsRes.getHeader() != null && getPaymentDetailsRes.getHeader().getOriginationDetails() != null) {
						exceptions = getPaymentDetailsRes.getHeader().getExceptions();
						LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper got headers");
						txnId = getPaymentDetailsRes.getHeader().getOriginationDetails().getTrackingId();
						LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper get headersand txnId -- " + txnId);
					}
				}

				if (exceptions == null) {
					LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper :: NO Exceptions");
					if (getPaymentDetailsRes != null) {
						if (getPaymentDetailsRes.getGetPaymentDetailsResPayload() != null) {
							if (getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes() != null) {
								if (getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo() != null) {
									if (getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo()
											.getPaymentDetails() != null) {
										/*TransactionStatus transactionStatus = getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes()
												.getInvoiceInfo().getTransactionStatus();
										LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper transactionStatus.getStatus() ::"
												+ transactionStatus.getStatus() + ", transactionStatus.getStatusCode() ::"
												+ transactionStatus.getStatusCode() + ",transactionStatus.getStatusCodeID() ::"
												+ transactionStatus.getStatusCodeID() + ", transactionStatus.getStatusDescription() ::"
												+ transactionStatus.getStatusDescription());*/
										//billerPayResponseVO.setStatus(transactionStatus.getStatusCodeID());
										//billerPayResponseVO.setStatusDesc(transactionStatus.getStatusDescription());
										List<PaymentDetails> listPaymentDetails = getPaymentDetailsRes.getGetPaymentDetailsResPayload()
												.getGetPaymentDetailsRes().getInvoiceInfo().getPaymentDetails();

										for (PaymentDetails paymentDetails : listPaymentDetails) {
											LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper paymentDetails.getMinAmountValue() ::"
													+ paymentDetails.getMinAmountValue()
													+ ", paymentDetails.getMinAmountCurrency() ::"
													+ paymentDetails.getMinAmountCurrency()
													+ ",paymentDetails.getMaxAmountValue() ::"
													+ paymentDetails.getMaxAmountValue()
													+ ", paymentDetails.getMaxAmountCurrency() ::"
													+ paymentDetails.getMaxAmountCurrency());
											if(paymentDetails.getMinAmountValue() !=null){
											billerPayDetailsVO.setBillerMinPmt(Double.parseDouble(paymentDetails.getMinAmountValue()));
											}
											if(paymentDetails.getMinAmountValue()!=null){
											billerPayDetailsVO.setBillerMaxPmt(Double.parseDouble(paymentDetails.getMaxAmountValue()));
											}
											
											billerPayDetailsVO.setTxnCurrency(paymentDetails.getMinAmountCurrency());
											TransactionStatus2 transactionStatus2=paymentDetails.getTransactionStatus();
											if(transactionStatus2!=null){
											billerPayResponseVO.setStatus(transactionStatus2.getStatusCodeID());
											billerPayResponseVO.setStatusDesc(transactionStatus2.getStatusDescription());
											}
											LOGGER.info("transactionStatus2.getStatusCodeID()"+transactionStatus2.getStatusCodeID()+" Consumer Num"+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
											LOGGER.info("transactionStatus2.getStatusDescription()"+transactionStatus2.getStatusDescription()+" Consumer Num"+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
											LOGGER.info("transactionStatus2.getStatus()"+transactionStatus2.getStatus()+" Consumer Num"+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
											LOGGER.info("transactionStatus2.getStatusCode()"+transactionStatus2.getStatusCode()+" Consumer Num"+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
										}
										billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
									}else{
										//Transaction info is null
										LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper :: getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo().getTransactionStatus() != null "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
									}
								}else{
									//Invoice info is null getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo() != null
									LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper :: getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes().getInvoiceInfo() != null "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
								}
									
							}else{
								//Payment details is null getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes() != null
								LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper :: getPaymentDetailsRes.getGetPaymentDetailsResPayload().getGetPaymentDetailsRes() != null "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
							}
						}else{
							//Response payload is null
							LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper :: getPaymentDetailsRes.getGetPaymentDetailsResPayload() != null "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						}
					}else{
						//"Response is null"
						LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper :: getPaymentDetailsRes != null "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
					}

				} else {
					LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper Entered exceptoin block");
					for (ExceptionType exceptionType : exceptions.getException()) {
						LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper Exception code" + exceptionType.getCode());
						LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper Exception code" + exceptionType.getDescription());
					}
				}

				LOGGER.info("Inside AlipayMappingHelper :: validateWalletDetatilsResponseWraper --End ");
				return billerPayResponseVO;
			}
			
			/**
			 * Method to populate GetTransactionStatusReqPayload and header
			 * @param billerPayRequestVO
			 * @return
			 */
			public static GetTransactionStatusReq populateHoganGetTransReqPayloadAndHeader(BillerPayRequestVO billerPayRequestVO, String currMultiplier){
				LOGGER.info("AlipayMappingHelper populateHoganGetTransReqPayloadAndHeader: "+billerPayRequestVO.getBillerPayDetailsVO().getHostReference());
			   	GetTransactionStatusReq getTranxStatusReq = new GetTransactionStatusReq();
				GetTransactionStatusReqPayload getTranxStatusReqPayload = new GetTransactionStatusReqPayload();
				getTranxStatusReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
				getTranxStatusReqPayload.setPayloadVersion(CommonConstants.HOGAN_PAYLOAD_VERSION);//6.3
				//v6 Transaction
				com.sc.corebanking.v6.transaction.Transaction transaction  = new  com.sc.corebanking.v6.transaction.Transaction();
				// v6 TransactionInfo
				com.sc.corebanking.v6.transaction.TransactionInfo transactionInfo = new com.sc.corebanking.v6.transaction.TransactionInfo();
				transactionInfo.setTransactionReferenceNumber(billerPayRequestVO.getBillerPayDetailsVO().getHostReference());//host ref
				transactionInfo.setTransactionType(CommonConstants.ALIPAY_TRANS_TYPE); // transaction type=01
				transactionInfo.setFromAccountNumber(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().getAccountNumber());// from acc
				String strAmount  = null;
				// transaction amount with multiplier logic 
				if (currMultiplier != null && !currMultiplier.isEmpty()) {	 	
					BigDecimal amount =	(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().getAmount() !=null) ? billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
					strAmount = (Arrays.asList((String.valueOf(
									amount.multiply(new BigDecimal(currMultiplier))).
											split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();			
					LOGGER.info("Alipay amount from populateHoganGetTransReqPayloadAndHeader to Hogan: strAmount::::" + strAmount);
					transactionInfo.setTransactionAmount(strAmount);//amount
				}else{
					transactionInfo.setTransactionAmount(new BigDecimal(CommonConstants.ZERO).toString());//amount
				}
				
				LOGGER.info("Alipay populateHoganGetTransReqPayloadAndHeader : Conversion Part::TransactionAmount : End:::"+strAmount);
				// date conversion
				transactionInfo.setTransactionDate(CommonConstants.ONE+new SimpleDateFormat(CommonConstants.HOGAN_DATE_FORMAT).format(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getDtProcessed()));//date
				//TODO reversal indicator is 'Y' as per requirement but differs with existing logic TBD
				transactionInfo.setTransactionReverseIndicator(CommonConstants.SPACE);//SPACE for non-reversal
				transaction.setTransactionInfo(transactionInfo);
				getTranxStatusReqPayload.setGetTransactionStatusReq(transaction);
				//set GetTransactionStatusReqPayload
				getTranxStatusReq.setGetTransactionStatusReqPayload(getTranxStatusReqPayload);
				// Header 				
				getTranxStatusReq.setHeader(populateHoganSCBMLHeader(billerPayRequestVO,
						CommonConstants.GET_TRANSACTION_STATUS,//HOGAN_MSG_SUBTYPE_NAME
						CommonConstants.GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME, 
						CommonConstants.GET_TRANSACTION_STATUS,//HOGAN_EVENTTYPE_NAME
						CommonConstants.GET_TRANSACTION_STATUS,//HOGAN_PROCESS_NAME
						CommonConstants.HOGAN_CAPTURE_SYSTEM,
						CommonConstants.DECIMAL_SIX));
				LOGGER.info("AlipayMappingHelper populateHoganGetTransReqPayloadAndHeader ends ");
				return getTranxStatusReq;
			}
			
			
			
			/**
			 * Wrapper method to set Hogan related values 
			 * @return
			 */
			protected static SCBMLHeaderType populateHoganSCBMLHeader(BillerPayRequestVO billerPayRequestVO, String msgSubType, String txnStatusMsgType, 
					String eventType, String processName, String captureSystem, String msgVersion ){
				SCBMLHeaderType hoganHeader= new SCBMLHeaderType();
				LOGGER.info("Inside populateHoganSCBMLHeader");
				// call existing populate header method
				hoganHeader = populateSCBMLHeader(billerPayRequestVO,msgSubType,txnStatusMsgType,eventType,processName);
				
				// overwrite the parameters to satisfy hogan requirement 
				hoganHeader.setCaptureSystem(captureSystem);//Hogan
				hoganHeader.getMessageDetails().setMessageVersion(new BigDecimal(msgVersion));//6.0
				LOGGER.info("Inside populateHoganSCBMLHeader: hoganHeader: "+hoganHeader);
				return hoganHeader;
			}
			
			 /**
			  *@ Method to get Hogan Transaction status check response
			 * @param getTranxStatusResp
			 * @param billerPayRequestVO 
			 * @return billerPayResponseVO
			 */
			public static BillerPayResponseVO getHoganTransStatusCheckResponse(
						 GetTransactionStatusResponse getTranxStatusResp,BillerPayRequestVO billerPayRequestVO){
					LOGGER.info("AlipayPaymentTransactionServiceImpl :::: getHoganTransStatusCheckResponse ::: Start");
					String txnId = null;
					boolean transactionAvailable = false;
					ExceptionListType exceptions = null;
					BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
					
					billerPayResponseVO.setUser(billerPayRequestVO.getUser());
					billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
					billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
					billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
					billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
					
					if (getTranxStatusResp != null && getTranxStatusResp.getGetTransactionStatusResponse() !=null 
							&& getTranxStatusResp.getGetTransactionStatusResponse().getHeader()!=null) {
						LOGGER.info("getHoganTransStatusCheckResponse: getTranxStatusResp.getGetTransactionStatusResponse().getHeader() is not null");
						exceptions = getTranxStatusResp.getGetTransactionStatusResponse().getHeader().getExceptions();
						if (getTranxStatusResp.getGetTransactionStatusResponse().getHeader().getOriginationDetails().getTrackingId() != null) {
							 //trackingId
							 txnId = getTranxStatusResp.getGetTransactionStatusResponse().getHeader().getOriginationDetails().getTrackingId();
							 LOGGER.info("AlipayPaymentTransactionServiceImpl:: getHoganTransStatusCheckResponse:: "+txnId);
							 if(getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload() !=null
										&& getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload().getGetTransactionStatusRes() !=null
										&& getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload().getGetTransactionStatusRes().getTransactionInfo()!=null
										&& getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload().getGetTransactionStatusRes().getTransactionInfo().getTransactionResponse()!=null){
								 //check for transaction availability
								 //00 - available 01 - not available
								 transactionAvailable = (getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload().getGetTransactionStatusRes().getTransactionInfo().getTransactionResponse().getCode().equals("00")?true:false);
								 LOGGER.info("AlipayPaymentTransactionServiceImpl: getHoganTransStatusCheckResponse : transactionAvailable?:: "+transactionAvailable);
								 
								 if(transactionAvailable){
									 if( billerPayResponseVO.getBillerPayDetailsVO().getPaymentType().equals(CommonConstants.CASA)){
										 billerPayResponseVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.COREBANK_PAY_SUCCESS);
									 }else if (billerPayResponseVO.getBillerPayDetailsVO().getPaymentType().equals(CommonConstants.CARD)){
										 billerPayResponseVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);
									 }
								 }else{
									 if( billerPayResponseVO.getBillerPayDetailsVO().getPaymentType().equals(CommonConstants.CASA)){
										 billerPayResponseVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
										 //setting hostname for sending the response back to iBanking
										// billerPayResponseVO.getBillerPayDetailsVO().setHostName(CommonConstants.HOGAN +" - "+CommonConstants.POST_TRANSACTION);//PostTransaction
									 }else if (billerPayResponseVO.getBillerPayDetailsVO().getPaymentType().equals(CommonConstants.CARD)){
										 billerPayResponseVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
										// billerPayResponseVO.getBillerPayDetailsVO().setHostName(CommonConstants.HOGAN +" - "+CommonConstants.CARD_AUTHORIZE);//cardAuthorize
									 }
								 }
								 //set hostCode and hostDescription
								 billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload().getGetTransactionStatusRes().getTransactionInfo().getTransactionResponse().getCode());
								 billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(getTranxStatusResp.getGetTransactionStatusResponse().getGetTransactionStatusResPayload().getGetTransactionStatusRes().getTransactionInfo().getTransactionResponse().getDescription());
								 LOGGER.info("hostRespCd: "+billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd()
										+"\n hostRespDesc: "+billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc()
										+"\n hostName: "+billerPayResponseVO.getBillerPayDetailsVO().getHostName());
							 }
							 
							if(!transactionAvailable && exceptions != null){
								LOGGER.info("transaction not available ...Received response with exception, "+ exceptions.getException().get(0).getDescription());
								billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
							 		setTxnStatusCd(CommonConstants.FAIL);
								
								billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
						 			setHostRespCd(exceptions.getException().get(0).getCode().getValue());
								
								billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
						 			setHostRespDesc(exceptions.getException().get(0).getDescription());
							}
							
						} else {
							billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
						
							billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd("-1");
							
							billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc("Missing Tracking id in core banking transactionStaus details");
							LOGGER.info("Missing Tracking id in core banking transactionStaus details");
						}
					} else {
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
					
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd("-1");
						
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc("Missing response in core banking transactionStaus");
						LOGGER.info("Missing response in core banking transactionStaus");
					}
					
					 LOGGER.info("hostRespCd: "+billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd()
								+"\n hostRespDesc: "+billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc()
								+"\n hostName: "+billerPayResponseVO.getBillerPayDetailsVO().getHostName());
				
					LOGGER.info("AlipayPaymentTransactionServiceImpl :::: getHoganTransStatusCheckResponse  ::: End");
					return billerPayResponseVO;
				}
			
			protected static SCBMLHeaderType populateSCBMLHeader(BillerPayRequestVO billerPayRequestVO,String subTypeName,String messageTypeName,String eventType,String processName) {
				 
				SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
				MessageDetailsType messageDetailsType = new MessageDetailsType();
				
				MessageType  messageType  = new MessageType();
				SubType subType = new SubType();
				subType.setSubTypeName(subTypeName);
				messageType.setTypeName(messageTypeName);
				messageType.setSubType(subType);
				messageDetailsType.setMessageVersion(new BigDecimal("1.0"));
				messageDetailsType.setMessageType(messageType);
				
				OriginationDetailsType originationDetailsType = new OriginationDetailsType();
				originationDetailsType.setTrackingId(
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				originationDetailsType.setPossibleDuplicate(true);
				
				MessageSenderType messageSenderType = new MessageSenderType();
				MessageSender messageSender = new MessageSender();
				messageSender.setValue(CommonConstants.I_BANKING);
				
				SenderDomainType senderDomainType = new SenderDomainType();
				
				DomainName domainName = new DomainName();
				domainName.setValue(CommonConstants.DOMAIN_NAME);
				
				SubDomainName subDomainName = new SubDomainName();
				subDomainName.setSubDomainType(subTypeName);
				
				senderDomainType.setDomainName(domainName);
				senderDomainType.setSubDomainName(subDomainName);
				messageSenderType.setCountryCode(billerPayRequestVO.
						getBillerPayDetailsVO().getCountryCode());
				messageSenderType.setMessageSender(messageSender);
				messageSenderType.setSenderDomain(senderDomainType);
				
				originationDetailsType.setMessageSender(messageSenderType);
				
				XMLGregorianCalendar date = getGregorianCalendar();

				originationDetailsType.setMessageTimestamp(date);
				originationDetailsType.setInitiatedTimestamp(date);
				
				ProcessType processType = new ProcessType();
				processType.setEventType(eventType);
				processType.setProcessName(processName);
				
				sCBMLHeaderType.setMessageDetails(messageDetailsType);
				sCBMLHeaderType.setOriginationDetails(originationDetailsType);
				sCBMLHeaderType.setCaptureSystem(CommonConstants.CAPTURING_SYSTEM);
				sCBMLHeaderType.setProcess(processType);
				return sCBMLHeaderType;
			}
}
