package com.scb.channels.mapper.helper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PaginationReqVO;
import com.scb.channels.base.vo.PaginationRespVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.ClientContext;
import com.scb.channels.common.MessageContext;
import com.scb.channels.common.PaginationReq;
import com.scb.channels.common.PaginationResp;
import com.scb.channels.common.ServiceContext;
import com.scb.channels.common.UserContext;

/**
 * The Class MappingHelper.
 *
 * @author 1411807
 */
public abstract class MappingHelper {
	
	public static final String MAPPING_XML = "com/scb/channels/mapper/vo/mapping/BeanMapping.xml";
	
	/** The FORMAT. */
	protected static final SimpleDateFormat FORMAT = new SimpleDateFormat(CommonConstants.DATE_TIME_FORMAT);
	
	public static final List<String> MAPPER_FILES = new ArrayList<String>();
	
	/** The Constant MAPPER. */
	protected static DozerBeanMapper MAPPER = new DozerBeanMapper(MAPPER_FILES);
	
	static{
		MAPPER_FILES.add(MAPPING_XML);
	}
	
	public static void reloadMapper(){
		MAPPER = null;
		MAPPER = new DozerBeanMapper(MAPPER_FILES);
	}
	
	/**
	 * Gets the user context mapping.
	 *
	 * @param userVO the user vo
	 * @return the user context mapping
	 */
	public static UserContext getUserContextMapping(UserVO userVO) {
		return   MAPPER.map(userVO, UserContext.class);
		
	}
	
	/**
	 * Gets the service context mapping.
	 *
	 * @param serviceVO the service vo
	 * @return the service context mapping
	 */
	public static ServiceContext getServiceContextMapping(ServiceVO serviceVO) {
		return MAPPER.map(serviceVO, ServiceContext.class);
		
	}
	
	/**
	 * Gets the client context mapping.
	 *
	 * @param clientVO the client vo
	 * @return the client context mapping
	 */
	public static ClientContext getClientContextMapping(ClientVO clientVO) {
		return  MAPPER.map(clientVO, ClientContext.class);
		
	}
	
	/**
	 * Gets the message context mapping.
	 *
	 * @param messageVO the message vo
	 * @return the message context mapping
	 */
	public static MessageContext getMessageContextMapping(MessageVO messageVO) {
		return  MAPPER.map(messageVO, MessageContext.class);
		
	}
	
	/**
	 * Gets the pagination context mapping.
	 *
	 * @param paginationReqVO the pagination req vo
	 * @return the pagination context mapping
	 */
	public static PaginationReq getPaginationContextMapping(PaginationReqVO paginationReqVO) {
		return MAPPER.map(paginationReqVO, PaginationReq.class); 
		
	}
	
	/**
	 * Gets the pagination context mapping.
	 *
	 * @param paginationReqVO the pagination req vo
	 * @return the pagination context mapping
	 */
	public static PaginationResp getPaginationResponseContextMapping(PaginationRespVO paginationRespVO) {
		return MAPPER.map(paginationRespVO, PaginationResp.class); 
		
	}
	
	
	//Reversal Mapping 
	/**
	 * Gets the user vo mapping.
	 *
	 * @param userContext the user context
	 * @return the user vo mapping
	 */
	public static UserVO getUserVOMapping(UserContext userContext) {
		return MAPPER.map(userContext, UserVO.class);
	}
	
	/**
	 * Gets the service vo mapping.
	 * 
	 * @param serviceContext
	 *            the service context
	 * @return ServiceVO
	 */
	public static ServiceVO getServiceVOMapping(ServiceContext serviceContext) {
		return MAPPER.map(serviceContext, ServiceVO.class);
	}
	
	/**
	 * Gets the message vo mapping.
	 *
	 * @param messageContext the message context
	 * @return the message vo mapping
	 */
	public static MessageVO getMessageVOMapping(MessageContext messageContext) {
		return MAPPER.map(messageContext, MessageVO.class);
	}
	
	/**
	 * Gets the client vo mapping.
	 *
	 * @param clientContext the client context
	 * @return the client vo mapping
	 */
	public static ClientVO getClientVOMapping(ClientContext clientContext) {
		return MAPPER.map(clientContext, ClientVO.class);
	}

	/**
	 * Gets the pagination req vo mapping.
	 *
	 * @param paginationReq the pagination req
	 * @return the pagination req vo mapping
	 */
	public static PaginationReqVO getPaginationReqVOMapping(PaginationReq paginationReq) {
		return MAPPER.map(paginationReq, PaginationReqVO.class);
	}
	
	/**
	 * Gets the pagination resp vo mapping.
	 *
	 * @param paginationResp the pagination req
	 * @return the pagination req vo mapping
	 */
	public static PaginationRespVO getPaginationRespVOMapping(PaginationResp paginationResp) {
		return MAPPER.map(paginationResp, PaginationRespVO.class);
	}
	
	/**
	 * Populate header.
	 * 
	 * @param country
	 *            the country
	 * @param channelId
	 *            the channel id
	 * @param service
	 *            the service
	 * @param version
	 *            the version
	 * @param processName
	 *            the process name
	 * @param processEventType
	 *            the process event type
	 * @param requestId
	 *            the request id
	 * @return the header
	 */
	/*protected static Header populateHeader(String country, 
			String channelId, String service, String version, 
			String processName, String processEventType, String requestId) {
		
		MessageType  messageType  = new MessageType();
		SubType subType = new SubType();
		subType.setSubTypeName(CommonConstants.SUB_TYPE_NAME);
		messageType.setTypeName(CommonConstants.MESSAGE_TYPE_NAME);
		messageType.setSubType(subType);
		
		SenderDomain senderDomain = new SenderDomain();
		SubDomain subDomain = new SubDomain();
		subDomain.setSubDomainName(channelId);
		senderDomain.setSubDomain(subDomain);
		
		MessageSender messageSender = new MessageSender();
		messageSender.setMessageSender(CommonConstants.MESSAGE_SENDER);
		messageSender.setSenderDomain(senderDomain);
		
		OriginationDetails originationDetails = new OriginationDetails();
		originationDetails.setMessageSender(messageSender);
		originationDetails.setMessageTimeStamp(FORMAT.format(DateUtils.getCurrentDate()));
		originationDetails.setTrackingId(requestId);
		
		Header header = new Header();
		MessageDetails messagedetails = new MessageDetails();
		messagedetails.setMessageVersion(CommonConstants.MESSAGE_VERSION);
		messagedetails.setMessageType(messageType);
		
		Tag countryTag = new Tag();
		countryTag.setKey(CommonConstants.COUNTRY_KEY);
		countryTag.setValue(country);
		
		Tag serviceName = new Tag();
		serviceName.setKey(CommonConstants.SERVICE_KEY);
		serviceName.setValue(service);
		
		Tag versionTag = new Tag();
		versionTag.setKey(CommonConstants.VERSION_KEY);
		versionTag.setValue(version);

		AnyMetaData anyMetaData = new AnyMetaData();
		anyMetaData.getTag().add(countryTag);
		anyMetaData.getTag().add(serviceName);
		anyMetaData.getTag().add(versionTag);
		
		com.scb.edmi.afropay.accountservices.Process process = new com.scb.edmi.afropay.accountservices.Process();
		process.setProcessName(processName);
		process.setEventType(processEventType);
		
		CaptureSystem captureSytem = new CaptureSystem();
		captureSytem.setCaptureSystem(new JAXBElement<String>(new QName(CommonConstants.CAPTURE_SYSTEM), String.class, CommonConstants.EDMI));
		
		TypeMetaData typeMetadata = new TypeMetaData();
		typeMetadata.setCaptureSystem(captureSytem);
		typeMetadata.setProcess(process);
		typeMetadata.setAnyMetaData(anyMetaData);
		
		header.setMessageDetails(messagedetails);
		header.setOriginationDetails(originationDetails);
		header.setTypeMetadata(new JAXBElement<TypeMetaData>(new QName("typeMetadata"), TypeMetaData.class, typeMetadata));
	
		
		return header;
	}*/
	
	
}
