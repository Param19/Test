package com.scb.channels.mapper.helper;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AuditCreditTxVO;
import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardInquiryResponseVO;
import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.inward.CreditHistoryRequestType;
import com.scb.channels.inward.CreditHistoryResponseType;
import com.scb.channels.inward.InwardInquiryRequestType;
import com.scb.channels.inward.InwardPaymentRequestType;
import com.scb.channels.inward.InwardResponseType;

// TODO: Auto-generated Javadoc
/**
 * The Class InwardMappingHelper.
 */
public class InwardMappingHelper extends MappingHelper {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(InwardMappingHelper.class);
	
	/** The Constant INWARD_MAPPING_XML. */
	public static final String INWARD_MAPPING_XML = "com/scb/channels/mapper/vo/mapping/InwardPaymentMapping.xml";
	
	/**
	 * Instantiates a new Inward mapping helper.
	 */
	private InwardMappingHelper() {	}
	
	static{
		MAPPER_FILES.add(INWARD_MAPPING_XML);
		reloadMapper();
		
		LOGGER.info("Loaded Inward mapping file");
	}
	
	/**
	 * Gets the gregorian calendar.
	 *
	 * @return the gregorian calendar
	 */
	public static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
		return date;
	}

	/**
	 * Post transaction response mapping.
	 *
	 * @param inwardPaymentRequestType the inward payment response type
	 * @return the inward inquiry request vo
	 */
	public static InwardPaymentRequestVO inwardPaymentRequest(InwardPaymentRequestType inwardPaymentRequestType) {
		return MappingHelper.MAPPER.map(inwardPaymentRequestType,InwardPaymentRequestVO.class);
	}
	
	/**
	 * Inward payment response.
	 *
	 * @param inwardPaymentResponseVO the inward payment response vo
	 * @return the inward inquiry request vo
	 */
	public static InwardResponseType inwardPaymentResponse(InwardPaymentResponseVO inwardPaymentResponseVO) {
		return MappingHelper.MAPPER.map(inwardPaymentResponseVO,InwardResponseType.class);
	}
	
	
	/**
	 * Inward inquiry request.
	 *
	 * @param inwardInquiryRequestType the inward inquiry request type
	 * @return the inward inquiry request vo
	 */
	public static InwardInquiryRequestVO inwardInquiryRequest(InwardInquiryRequestType inwardInquiryRequestType) {
		return MappingHelper.MAPPER.map(inwardInquiryRequestType,InwardInquiryRequestVO.class);
	}
	
	/**
	 * Inward inquiry response.
	 *
	 * @param inwardInquiryResponseVO the inward inquiry response vo
	 * @return the inward inquiry request vo
	 */
	public static InwardResponseType inwardInquiryResponse(InwardInquiryResponseVO inwardInquiryResponseVO) {
		return MappingHelper.MAPPER.map(inwardInquiryResponseVO,InwardResponseType.class);
	}
	
	/**
	 * Sets the inward payment detail.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the inward payment detail vo
	 */
	public static InwardPaymentDetailVO setInwardPaymentDetail(InwardPaymentRequestVO inwardPaymentRequestVO){
		return MappingHelper.MAPPER.map(inwardPaymentRequestVO,InwardPaymentDetailVO.class);
	}
	
	/**
	 * Sets the inward payment detail.
	 *
	 * @param inwardInquiryRequestVO the inward inquiry request vo
	 * @return the inward payment detail vo
	 */
	public static InwardPaymentDetailVO setInwardPaymentDetail(InwardInquiryRequestVO inwardInquiryRequestVO){
		return MappingHelper.MAPPER.map(inwardInquiryRequestVO,InwardPaymentDetailVO.class);
	}
	
	//CR1477 Orange Money Changes Ends, 20Feb18, Vijayan A
	/**
	 * Sets the inward payment detail to InwardInquiryRequestVO.
	 *
	 * @param inwardPaymentDetailVO the inward payment vo
	 * @return the inwardInquiryRequestVO vo
	 */
	public static InwardInquiryRequestVO setInwardPaymentDetail(InwardPaymentDetailVO inwardPaymentDetailVO){
		return MappingHelper.MAPPER.map(inwardPaymentDetailVO, InwardInquiryRequestVO.class);
	}
	//CR1477 Orange Money Changes Starts, 20Feb18, Vijayan A
	
	/**
	 * Sets the audit credit tx vo.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the audit credit tx vo
	 */
	public static AuditCreditTxVO setAuditCreditTxVO(InwardPaymentRequestVO inwardPaymentRequestVO){
		return MappingHelper.MAPPER.map(inwardPaymentRequestVO,AuditCreditTxVO.class);
	}
	
	/**
	 * Sets the audit credit tx vo.
	 *
	 * @param inquiryRequestVO the inward payment request vo
	 * @return the audit credit tx vo
	 */
	public static AuditCreditTxVO setAuditCreditTxVO(InwardInquiryRequestVO inquiryRequestVO){
		return MappingHelper.MAPPER.map(inquiryRequestVO,AuditCreditTxVO.class);
	}
	
	/**
	 * Inward inquiry request.
	 *
	 * @param creditHistoryRequestType the credit history request type
	 * @return the inward inquiry request vo
	 */
	public static InwardInquiryRequestVO getCreditHistoryRequest(CreditHistoryRequestType creditHistoryRequestType) {
		return MappingHelper.MAPPER.map(creditHistoryRequestType,InwardInquiryRequestVO.class);
	}
	
	/**
	 * Gets the credit history response.
	 *
	 * @param inquiryResponseVO the inquiry response vo
	 * @return the credit history response
	 */
	public static CreditHistoryResponseType getCreditHistoryResponse(InwardInquiryResponseVO inquiryResponseVO) {
		return MappingHelper.MAPPER.map(inquiryResponseVO,CreditHistoryResponseType.class);
	}
	
}
