package com.scb.channels.mapper.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.JetcoAuditTxn;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.JetcoPayResponseVO;
import com.scb.channels.base.vo.JetcoPaymentDetailVO;
import com.scb.channels.paymentservice.PaymentRequest;
import com.scb.channels.paymentservice.PaymentResponse;

/**
 * JETCO Pay mapping helper
 * 
 * @author 1552545
 * 
 */
public class JetcoPayMappingHelper extends MappingHelper {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(JetcoPayMappingHelper.class);

	/** The Constant JETCO_MAPPING_XML. */
	public static final String JETCO_MAPPING_XML = "com/scb/channels/mapper/vo/mapping/JetcoBeanMapping.xml";

	/**
	 * Instantiates a new Jetco mapping helper.
	 */
	private JetcoPayMappingHelper() {

	}

	static {
		MAPPER_FILES.add(JETCO_MAPPING_XML);
		reloadMapper();
		LOGGER.info("Loaded Jetco mapping file");
	}


	/**
	 * convert paymentRequest to jetcoPayReqeust
	 * 
	 * @param request
	 * @return
	 */
	public static JetcoPayRequestVO getJetcoPaymentRequest(PaymentRequest request) {
		return MappingHelper.MAPPER.map(request, JetcoPayRequestVO.class);
	}

	/**
	 * convert JetcoPayRequestVO to JetcoPaymentDetailVO
	 * 
	 * @param request
	 * @return
	 */
	public static JetcoPaymentDetailVO getJetcoPaymentDetails(JetcoPayRequestVO request) {
		return MappingHelper.MAPPER.map(request, JetcoPaymentDetailVO.class);
	}

	/**
	 * convert jetcoPayRequestVO to Transaction - Hogan Service
	 * 
	 * @param jetcoPayRequestVO
	 * @return
	 */

	public static com.sc.corebanking.v6.transaction.Transaction postTransactionRequestMapping(JetcoPayRequestVO jetcoPayRequestVO) {
		return MappingHelper.MAPPER.map(jetcoPayRequestVO, com.sc.corebanking.v6.transaction.Transaction.class);
	}

	/**
	 * convert JetcoPayRequestVO to JetcoPayResponseVO
	 * 
	 * @param JetcoPayRequestVO
	 * @return
	 */
	public static JetcoPayResponseVO getJetcoPaymentResponse(JetcoPayRequestVO request) {
		return MappingHelper.MAPPER.map(request, JetcoPayResponseVO.class);
	}

	/**
	 * convert JetcoPayResponseVO to JetcoPayRequestVO
	 * 
	 * @param JetcoPayResponseVO
	 * @return
	 */
	public static JetcoPayRequestVO getJetcoPaymentRequest(JetcoPayResponseVO responseVo) {
		return MappingHelper.MAPPER.map(responseVo, JetcoPayRequestVO.class);
	}

	/**
	 * convert JetcoPayResponseVO to PaymentResponse
	 * 
	 * @param JetcoPayResponseVO
	 * @return
	 */
	public static PaymentResponse getPaymentResponseVOMapping(JetcoPayResponseVO responseVo) {
		return MappingHelper.MAPPER.map(responseVo, PaymentResponse.class);
	}

	/**
	 * convert JetcoPaymentDetailVO to JetcoPayRequestVO
	 * 
	 * @param JetcoPaymentDetailVO
	 * @return
	 */
	public static JetcoPayRequestVO getJetcoPayRequestFromPaymentDetails(JetcoPaymentDetailVO paymentDetails) {
		return MappingHelper.MAPPER.map(paymentDetails, JetcoPayRequestVO.class);
	}

	/**
	 * convert JetcoPayRequestVO to JetcoAuditTxn
	 * 
	 * @param request
	 * @return
	 */
	public static JetcoAuditTxn getJetcoAuditTxn(JetcoPayRequestVO request) {
		return MappingHelper.MAPPER.map(request, JetcoAuditTxn.class);
	}

}
