package com.scb.channels.audit.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.AddressVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.BankInfoVO;
import com.scb.channels.base.vo.BeneficiaryVO;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ChargesTypeVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.FXRateInfoVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PresentmentVO;
import com.scb.channels.base.vo.RefInfoTypeVO;
import com.scb.channels.base.vo.RountingInfoVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.TransferRequestVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.helper.TestHelper;

public class AuditTransformRequestServiceImplTest {
	
	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void testGetAuditTransformRequestObjectBillerPayRequestVO() {
		RequestTransformerService<BillerPayRequestVO, AuditSumTxnVO> auditTransformRequestService = (RequestTransformerService<BillerPayRequestVO, AuditSumTxnVO>)context.getBean("paymentsAuditTransformReqServiceImpl");
		AuditSumTxnVO sumTxnVO = auditTransformRequestService.tranformRequest(testBillerPayRequestVO());
		Assert.assertNotNull(sumTxnVO);
	}
	
	@Test
	public void testGetAuditTransformRequestObjectTransferRequestVO() {
		RequestTransformerService<TransferRequestVO, AuditSumTxnVO> auditTransformRequestService = (RequestTransformerService<TransferRequestVO, AuditSumTxnVO>)context.getBean("transfersAuditTransformerReqService");
		AuditSumTxnVO sumTxnVO = auditTransformRequestService.tranformRequest((TransferRequestVO)getTransferPayload().getRequestVO());
		Assert.assertNotNull(sumTxnVO);
		Assert.assertNotNull(sumTxnVO.getEnvironment());
	}
	
	private BillerPayRequestVO testBillerPayRequestVO() {
		
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
		TransactionInfoVO transationInfoVO = new TransactionInfoVO();
		
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_IBNK);
		user.setCountry(TestHelper.COUNTRY);
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerType(TestHelper.CUSTOMER_TYPE);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setEmailNotification(true);
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel(TestHelper.CHANNEL);
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment(TestHelper.ENVIRONMENT);
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(TestHelper.SESSION_ID);
		clientVO.setVersion(CommonConstants.VERSION);
		clientVO.setDate(Calendar.getInstance());
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName(CommonConstants.SERVICE_NAME);
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID(ReferenceNumberGenerator.generateReferenceNumber(TestHelper.COUNTRY, "Biller", TestHelper.CHANNEL_IBNK));
		messageVO.setRequestType(CommonConstants.REQUEST_TYPE);
		messageVO.setRequestCode(messageVO.getReqID());
		
		billerPayRequestVO.setUser(user);
		billerPayRequestVO.setClientVO(clientVO);
		billerPayRequestVO.setServiceVO(serviceVO);
		billerPayRequestVO.setMessageVO(messageVO);
		
	//Biller
		billerPayDetailsVO.setBillerCd(TestHelper.BILLER_CD);
		billerPayDetailsVO.setBillerDesc(TestHelper.BILLER_DESC);
		billerPayDetailsVO.setUtilityCd(TestHelper.UTILITY_CD);
		billerPayDetailsVO.setUtilltyTypeDesc(TestHelper.UTILITY_DESC);

	//Consumer
		billerPayDetailsVO.setConsumerNo(TestHelper.CONSUMER_NO);
		billerPayDetailsVO.setConsumerDesc(TestHelper.CONSUMER_DESC);
		
		billerPayDetailsVO.setBillerNickName("Airtel");	
		
	//Biller Address
		AddressVO addressVO = new AddressVO();
		addressVO.setAddress1("Addr1");
		addressVO.setAddress2("Addr2");
		addressVO.setAddress3("Addr3");
		addressVO.setCity("NGcity");
		addressVO.setCountry("NG");
		billerPayDetailsVO.setBillerAddress(addressVO);
		
	//BillerAcct
		AccountVO billerAccountVO = new AccountVO();
		billerAccountVO.setAccountNumber("11223344");
		billerAccountVO.setUniversalAccNumber("1122");
		billerAccountVO.setProductCode("001");
		billerAccountVO.setAccountType("CASA");
		billerAccountVO.setCurrency("NGN");
		billerAccountVO.setMemo("Y");
		billerPayDetailsVO.setDebitAcctSrcType("SRC ACC");
	
	//Biller Fields
		BillerField billerField = new BillerField();
		/*billerField.setDisplayOrder(1);
		billerField.setDynamicFieldName("Y");
		billerField.setDynamicFieldValue("Y");
		billerField.setLenMax("10");
		billerField.setLenMin("5");*/
		List<BillerField> billerFields = new ArrayList<BillerField>();
		billerFields.add(billerField);
		billerPayDetailsVO.setBillerFields(billerFields);
		
	//PayLimit
		
		billerPayDetailsVO.setBillerMaxPmt(500.00);
		billerPayDetailsVO.setBillerMinPmt(200.00);
		
	//Denomination
		List<String> value = new ArrayList<String>();
		value.add("Denomination");
		billerPayDetailsVO.setValue(value);
		
		billerPayDetailsVO.setPayRef("REF");
		billerPayDetailsVO.setIsAuthReq("Auth");
		billerPayDetailsVO.setIsForSme("Y");
		billerPayDetailsVO.setDtEffFrom(Calendar.getInstance().getTime());
		billerPayDetailsVO.setPayMthd("R");
	
	//PresentmentType
		PresentmentVO presentmentType = new PresentmentVO();
		presentmentType.setDueDate(""+Calendar.getInstance().getTime());
		presentmentType.setMinAmt(123.00);
		presentmentType.setAmt(500.00);
		presentmentType.setMinAmtAftDueDt(200.00);
		presentmentType.setAmtAftDueDt(600.00);
		presentmentType.setTxnDaysBfrDueDt(5);
		presentmentType.setTxnDaysAftDueDt(7);
		billerPayDetailsVO.setPresentmentVO(presentmentType);
		
	//TxnContextType
		transationInfoVO.setDestAccountVO(billerAccountVO);
		transationInfoVO.setTxnTypeCd("CD");
		transationInfoVO.setTxnId("ID");
		transationInfoVO.setTxnTypeCd("IFT");
		transationInfoVO.setTxnTime(Calendar.getInstance().getTime());
		transationInfoVO.setTxnCurrency("NGN");
		transationInfoVO.setTxnAmount(400.00);
		
		transationInfoVO.setDebitCurrency("NGN");
		transationInfoVO.setDebitAmount(400.00);
		
		transationInfoVO.setCreditCurrency("NGN");
		transationInfoVO.setCreditAmount(400.00);
		
		transationInfoVO.setDueDate(Calendar.getInstance().getTime());
		transationInfoVO.setTxnStatusCd("SUCC");
		transationInfoVO.setTxnForceFlg(true);
		transationInfoVO.setTxnAuthDtl("Dtl");
		transationInfoVO.setTxnAuthId("txnauthid");
		transationInfoVO.setTxnMode("S");
		
		AccountVO destAccountVO = new AccountVO();
		destAccountVO.setAccountNumber("123444");
		destAccountVO.setUniversalAccNumber("7876");
		destAccountVO.setProductCode("001");
		destAccountVO.setAccountType("CASA");
		destAccountVO.setCurrency("NGN");
		destAccountVO.setMemo("Y");
		transationInfoVO.setSrcAccountVO(destAccountVO);
		
	//FXRateInfoType
		FXRateInfoVO fXRateInfoVO = new FXRateInfoVO();
		fXRateInfoVO.setCurRate(200.00);
		fXRateInfoVO.setCurConvertRule("Rule");
		fXRateInfoVO.setCustDealNo(2);
		fXRateInfoVO.setCustDealRate(234.00);
		fXRateInfoVO.setCustPrefRate(145.00);
		fXRateInfoVO.setCostRate(345.00);
		fXRateInfoVO.setCounterRate(120.00);
		transationInfoVO.setfXRateInfoVO(fXRateInfoVO);
		
	//ChargesTypeVO
		ChargesTypeVO chargesTypeVO = new ChargesTypeVO();
		chargesTypeVO.setChargeOn("ONUS");
		chargesTypeVO.setChargeType("Cash");
		chargesTypeVO.setAmount(340.00);
		chargesTypeVO.setCurrency("NGN");
		chargesTypeVO.setChargeAccountNumber("121");
		chargesTypeVO.setChargeUniversalAccNumber("232");
		chargesTypeVO.setChargeProductCode("23444");
		chargesTypeVO.setChargeAccType("CASA");
		chargesTypeVO.setChargeCurrency("NGN");
		chargesTypeVO.setChargeMemo("Y");
		transationInfoVO.setChargesTypeVO(chargesTypeVO);
		billerPayDetailsVO.setTransactionInfoVO(transationInfoVO);
		
		return billerPayRequestVO;
	}
	
	private PayloadDTO getTransferPayload() {
		
		Calendar cal= DateUtils.getCountryCalendar();
		cal.set(Calendar.DATE, 01);
		cal.set(Calendar.MONTH, Calendar.DECEMBER);
		cal.set(Calendar.YEAR, 2012);
		
		TransferRequestVO transferRequestVO = new TransferRequestVO();
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_IBNK);
		user.setCountry(TestHelper.COUNTRY);
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerType(TestHelper.LOGIN_ID);
		user.setCustomerIdType(TestHelper.LOGIN_ID);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setUserId("userId");
		user.setPhone("+1234234345");
		user.setEmailId("a@a.com");
		user.setEmailNotification(true);
		user.setInboxNotification(true);
		user.setSmsNotification(true);
		transferRequestVO.setUser(user);
		
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel(TestHelper.CHANNEL);
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment("");
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(RandomStringUtils.randomAlphanumeric(16));
		clientVO.setVersion(CommonConstants.VERSION);
		clientVO.setDate(cal);
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		
		transferRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName(CommonConstants.SERVICE_NAME);
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		serviceVO.setServiceTxnType("GPS");
		
		transferRequestVO.setServiceVO(serviceVO);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID(ReferenceNumberGenerator.generateReferenceNumber(TestHelper.COUNTRY, "IFT", TestHelper.CHANNEL_IBNK));
		messageVO.setRequestType(CommonConstants.REQUEST_TYPE);
		messageVO.setRequestCode(messageVO.getReqID());
		
		transferRequestVO.setMessageVO(messageVO);
	
		
		TransactionInfoVO transationInfoVO = new TransactionInfoVO();
		
		transationInfoVO.setTxnForceFlg(true);
		transationInfoVO.setTxnId(messageVO.getReqID());
		transationInfoVO.setTxnTypeCd("IFT");
		transationInfoVO.setTxnTime(cal.getTime());
		transationInfoVO.setDueDate(cal.getTime());
		transationInfoVO.setTxnStatusCd("SUBM");
		transationInfoVO.setTransferCurrencyCd("NGN");
		transationInfoVO.setTxnAmount(150.23);
		transationInfoVO.setTxnCurrency("NGN");
		transationInfoVO.setDebitCurrency("NGN");
		transationInfoVO.setDebitAmount(150.23);    //Needs to clarify
		transationInfoVO.setCreditCurrency("NGN");
		transationInfoVO.setCreditAmount(150.23);
		transationInfoVO.setTxnAuthId("12");
		transationInfoVO.setTxnAuthDtl("12233");
		
		transationInfoVO.setDtTransfer(cal.getTime());
		transationInfoVO.setTransferMode("S");
		transationInfoVO.setTxnRef1("Ref1");
		transationInfoVO.setTxnRef2("Ref2");
		transationInfoVO.setTxnRef3("Ref3");
		transationInfoVO.setTxnRef4("Ref4");
		
		RountingInfoVO rountingInfoVO = new RountingInfoVO();
		rountingInfoVO.setBankCode("SCB");
		rountingInfoVO.setBranchCode("SCB");
		rountingInfoVO.setRoutingCode("123");
		rountingInfoVO.setRoutingType("IFT");
		System.out.println(String.valueOf(DateUtils.getCurrentDate()));
		List<RountingInfoVO> rInfo = new ArrayList<RountingInfoVO>();
		rInfo.add(rountingInfoVO);
		
		BankInfoVO bankInfoVO = new BankInfoVO(); 
		bankInfoVO.setAddress1("NG1");
		bankInfoVO.setAddress2("NG2");
		bankInfoVO.setAddress3("NG3");
		bankInfoVO.setBankId("1122");
		bankInfoVO.setBankName("SCB");
		bankInfoVO.setBranchName("NGSCB");
		bankInfoVO.setCity("NGCITY");
		bankInfoVO.setCountry("NG");
		bankInfoVO.setState("NGSTATE");
		bankInfoVO.setZipCode("500640");
		bankInfoVO.setRountingInfoVO(rInfo);
		
		transationInfoVO.setSrcAccountVO(new AccountVO());
		transationInfoVO.getSrcAccountVO().setAccountNumber("0000050456");   //SourceAccount
		transationInfoVO.getSrcAccountVO().setUniversalAccNumber("0000050456");
		transationInfoVO.getSrcAccountVO().setProductCode("001");
		transationInfoVO.getSrcAccountVO().setAccountType("CASA");
		transationInfoVO.getSrcAccountVO().setCurrency("NGN");
		transationInfoVO.getSrcAccountVO().setMemo("FundTransfer");
		transationInfoVO.getSrcAccountVO().setBankInfo(bankInfoVO);
		
		transationInfoVO.setInterAccountVO(transationInfoVO.getSrcAccountVO());
		
		transationInfoVO.setDestAccountVO(new AccountVO());
		transationInfoVO.getDestAccountVO().setAccountNumber("5000051726");  //DestAccount
		transationInfoVO.getDestAccountVO().setUniversalAccNumber("5000051726");
		transationInfoVO.getDestAccountVO().setProductCode("001");
		transationInfoVO.getDestAccountVO().setAccountType("CASA");
		transationInfoVO.getDestAccountVO().setCurrency("NGN");
		transationInfoVO.getDestAccountVO().setMemo("FundTransfer");
		transationInfoVO.getDestAccountVO().setBankInfo(bankInfoVO);
		
		transationInfoVO.setBeneficiaryVO(new BeneficiaryVO());
		transationInfoVO.getBeneficiaryVO().setBeneId("22323");
		transationInfoVO.getBeneficiaryVO().setName("Dhoni");           // Beneficiary
		transationInfoVO.getBeneficiaryVO().setBeneEmail("dhoni@gmail.com");
		transationInfoVO.getBeneficiaryVO().setBenePhone("9891122334");
		
		transationInfoVO.setfXRateInfoVO(new FXRateInfoVO());
		
	/*	transationInfoVO.setStandingInsVO(new StandingInsVO());
		transationInfoVO.getStandingInsVO().setFrequency("W");       //StandingsInfo
		transationInfoVO.getStandingInsVO().setRecurring(true);
		transationInfoVO.getStandingInsVO().setFirstExecDate(Calendar.getInstance());
		transationInfoVO.getStandingInsVO().setNextExecDate(Calendar.getInstance());*/
		
		/*transationInfoVO.setChargesTypeVO(new ChargesTypeVO());
		transationInfoVO.getChargesTypeVO().setAmount(234);      //ChargesType
		transationInfoVO.getChargesTypeVO().setCurrency("NGN");
		transationInfoVO.getChargesTypeVO().setChargeType("TX");
		transationInfoVO.getChargesTypeVO().setChargeOn("ONUS");
		transationInfoVO.getChargesTypeVO().setChargeAccountNumber("9999");
		transationInfoVO.getChargesTypeVO().setChargeUniversalAccNumber("7777");
		transationInfoVO.getChargesTypeVO().setChargeProductCode("123");
		transationInfoVO.getChargesTypeVO().setChargeType("CASA");
		transationInfoVO.getChargesTypeVO().setChargeMemo("NO");
		transationInfoVO.getChargesTypeVO().setChargeAccountNumber("456789");
		transationInfoVO.getChargesTypeVO().setChargeUniversalAccNumber("1010101");
		transationInfoVO.getChargesTypeVO().setChargeAccType("CASA");
		transationInfoVO.getChargesTypeVO().setChargeCurrency("NGN");
		transationInfoVO.getChargesTypeVO().setChargeBankAddress1("NG1");
		transationInfoVO.getChargesTypeVO().setChargeBankAddress2("NG2");
		transationInfoVO.getChargesTypeVO().setChargeBankAddress3("NG3");
		transationInfoVO.getChargesTypeVO().setChargeBankCity("NGCITY");
		transationInfoVO.getChargesTypeVO().setChargeBankCountry("NGCOUNTRY");
		transationInfoVO.getChargesTypeVO().setChargeBankName("SCB");
		transationInfoVO.getChargesTypeVO().setChargeBankState("NGSTATE");
		transationInfoVO.getChargesTypeVO().setChargeBankZipCode("550450");*/
		
		transationInfoVO.setRglatoryRpt("REG");
		RefInfoTypeVO creditRefInfoType = new RefInfoTypeVO();
		creditRefInfoType.setRefId("IBANKING TRF FROM 0000050456");
		creditRefInfoType.setRefType("CreditNarration1");
		RefInfoTypeVO creditRef1 = new RefInfoTypeVO();
		creditRef1.setRefId("");
		creditRef1.setRefType("CreditNarration2");
		RefInfoTypeVO creditRef2 = new RefInfoTypeVO();
		creditRef2.setRefId("");
		creditRef2.setRefType("CreditNarration3");
		RefInfoTypeVO creditRef3 = new RefInfoTypeVO();
		creditRef3.setRefId("");
		creditRef3.setRefType("CreditNarration4");
		RefInfoTypeVO creditRef4 = new RefInfoTypeVO();
		creditRef4.setRefId("");
		creditRef4.setRefType("CreditNarration5");
		RefInfoTypeVO creditRef5 = new RefInfoTypeVO();
		creditRef5.setRefId("");
		creditRef5.setRefType("CreditNarration6");
		
		RefInfoTypeVO debitRefInfoType = new RefInfoTypeVO();
		debitRefInfoType.setRefId("IBANKING TRF TO 5000051726");
		debitRefInfoType.setRefType("DebitNarration1");
		RefInfoTypeVO debitRef1 = new RefInfoTypeVO();
		debitRef1.setRefId("");
		debitRef1.setRefType("DebitNarration2");
		RefInfoTypeVO debitRef2 = new RefInfoTypeVO();
		debitRef2.setRefId("");
		debitRef2.setRefType("DebitNarration3");
		RefInfoTypeVO debitRef3 = new RefInfoTypeVO();
		debitRef3.setRefId("");
		debitRef3.setRefType("DebitNarration4");
		RefInfoTypeVO debitRef4 = new RefInfoTypeVO();
		debitRef4.setRefId("");
		debitRef4.setRefType("DebitNarration5");
		RefInfoTypeVO debitRef5 = new RefInfoTypeVO();
		debitRef5.setRefId("");
		debitRef5.setRefType("DebitNarration6");
		
	/*	RefInfoTypeVO external = new RefInfoTypeVO();
		external.setRefId("ADC-mBanking");
		external.setRefType("external");*/
		
		List<RefInfoTypeVO> refInfo= new ArrayList<RefInfoTypeVO>();
	
		refInfo.add(debitRefInfoType);
		refInfo.add(debitRef1);
		refInfo.add(debitRef2);
		refInfo.add(debitRef3);
		refInfo.add(debitRef4);
		refInfo.add(debitRef5);
		refInfo.add(creditRefInfoType);
		refInfo.add(creditRef1);
		refInfo.add(creditRef2);
		refInfo.add(creditRef3);
		refInfo.add(creditRef4);
		refInfo.add(creditRef5);
	//	refInfo.add(external);
		transationInfoVO.setRefInfo(refInfo);
		transferRequestVO.setTransactionInfoVO(transationInfoVO);
		
		PayloadDTO payloadDTO = new PayloadDTO();
		payloadDTO.setRequestVO(transferRequestVO);
		return payloadDTO;
	}

}
