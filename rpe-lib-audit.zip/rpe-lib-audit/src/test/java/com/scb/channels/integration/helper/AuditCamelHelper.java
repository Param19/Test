/**
 * 
 */
package com.scb.channels.integration.helper;

import org.apache.camel.CamelContext;
import org.apache.camel.ConsumerTemplate;
import org.apache.camel.ProducerTemplate;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.helper.TestHelper;

/**
 * @author 1411807
 *
 */
public class AuditCamelHelper {
	
	private AuditCamelHelper() {
	}
	
	public static void sendObject(PayloadDTO payloadDTO, String uri){
		CamelContext context = (CamelContext) TestHelper.getContext().getBean("auditCamelConfig");
		ProducerTemplate template = context.createProducerTemplate();
		template.sendBody(uri, payloadDTO);
	}
	
	public static PayloadDTO recieveObject(String uri){
		CamelContext context = (CamelContext) TestHelper.getContext().getBean("auditCamelConfig");
		ConsumerTemplate template = context.createConsumerTemplate();
		PayloadDTO payloadDTO = template.receiveBody(uri, 1000*60, PayloadDTO.class);
		return payloadDTO;
	}

}
