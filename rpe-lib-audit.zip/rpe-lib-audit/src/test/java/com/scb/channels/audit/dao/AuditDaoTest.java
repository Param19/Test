package com.scb.channels.audit.dao;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.helper.TestHelper;

public class AuditDaoTest {
	
	ApplicationContext context;
	AuditSumTxnVO auditSumTxnVO;
	AuditDAO auditDaoTest;
	PayloadDTO payloadDTO;

	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		auditSumTxnVO = new AuditSumTxnVO();
		auditDaoTest = context.getBean("auditDAO",AuditDAO.class);
	}
	
	
	//@Test
	public void AuditDaoTest(){
		auditSumTxnVO.setTxnId("NG-IBNK-012-130826-120728248-669478-002");
		auditSumTxnVO.setTxtStatusCd("SUCC");
		auditSumTxnVO.setDateUpd(DateUtils.getCurrentDate());
		auditDaoTest.updateTxnStatus(auditSumTxnVO);
	}
	
	@Test
	public void fetchAuditServiceListDaoTest(){
		auditSumTxnVO.setCustId("CU122");
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		String toDate = dateFormat.format(date);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -90);
        Date todate1 = cal.getTime();
        String fromDate = dateFormat.format(todate1.getTime());
		List<AuditSumTxnVO> auditServiceList= auditDaoTest.getAuditTxnList(auditSumTxnVO,fromDate,toDate);
		System.out.println("List Size :: "+auditServiceList.size());
		
	}
	
	
	//@Test
	public void saveAuditTest(){
		auditSumTxnVO = new AuditSumTxnVO();
		auditSumTxnVO.setAuditBy("Auditor");
		auditSumTxnVO.setChannel("IBNK");
		auditSumTxnVO.setCreatedBy("DEV");
		auditSumTxnVO.setCtryCd("NG01");
		auditSumTxnVO.setCustGroupId("GRP12");
		auditSumTxnVO.setCustId("CU122");
		auditSumTxnVO.setCustIdType("CUID11");
		auditSumTxnVO.setCustomDate(Calendar.getInstance().getTime());
		auditSumTxnVO.setCustomDec01(11.23);
		auditSumTxnVO.setCustomDec02(12.23);
		auditSumTxnVO.setCustomDec03(13.23);
		auditSumTxnVO.setCustomDec04(14.23);
		auditSumTxnVO.setCustomDec05(15.23);
		auditSumTxnVO.setCustomVar01("VAR01");
		auditSumTxnVO.setCustomVar02("VAR02");
		auditSumTxnVO.setCustomVar03("VAR03");
		auditSumTxnVO.setCustomVar04("VAR04");
		auditSumTxnVO.setCustomVar05("VAR05");
		auditSumTxnVO.setDateCreated(Calendar.getInstance().getTime());
		auditSumTxnVO.setDateUpd(Calendar.getInstance().getTime());
		auditSumTxnVO.setDtAudit(Calendar.getInstance().getTime());
		auditSumTxnVO.setEnvironment("ENV");
		auditSumTxnVO.setErrorCd("ER0077");
		auditSumTxnVO.setErrorDesc("ERRDESC");
		auditSumTxnVO.setFromAcctName("FRACNAME");
		auditSumTxnVO.setFromAcctNo("FRACCNO");
		auditSumTxnVO.setFuncCd("FUNCCD");
		auditSumTxnVO.setMobileNo("988948");
		auditSumTxnVO.setSessionId("SSID99");
		auditSumTxnVO.setStatusCd("SC");
		auditSumTxnVO.setSystemType("SSTYPE");
		auditSumTxnVO.setToAccCurrCd("TOACCCURCD");
		auditSumTxnVO.setFromAccCurrCd("FromAccCurrCD");
		auditSumTxnVO.setToAcctName("TOACCNAME");
		auditSumTxnVO.setToAcctNo("TOACCNO");
		auditSumTxnVO.setTxnAmt(12.88);
		auditSumTxnVO.setTxnCurr("TXNCURR");
		auditSumTxnVO.setTxnDate(Calendar.getInstance().getTime()); 
		auditSumTxnVO.setTxnId("TXNID0045454");
		auditSumTxnVO.setTxnType("IB");
		auditSumTxnVO.setTxtStatusCd("TXNSTSCD");
		auditSumTxnVO.setUserId("00001110");
		auditSumTxnVO.setVersion(1);
		auditSumTxnVO.setIpAddress("192.11.22");
		auditSumTxnVO.setClientIpAddress("101.34.6");
		auditDaoTest.saveAudit(auditSumTxnVO);
		
	}

}
