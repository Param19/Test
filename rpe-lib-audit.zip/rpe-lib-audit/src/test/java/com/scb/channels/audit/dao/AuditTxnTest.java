package com.scb.channels.audit.dao;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import junit.framework.Assert;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ChargesTypeVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.helper.TestHelper;


public class AuditTxnTest {
	
	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}
	
	@Test
	public void test() throws InterruptedException {
		PayloadDTO bean = getPayeePayload(); 
		
		//PayloadDTO bean = getPayeePayload(); 
		//String uri = "nwmq:queue:chnlNotifReqQueue";
		//NotificationCamelHelper.sendObject(bean, uri);
		//Thread.sleep(1000 * 240);
		
		System.out.println(bean.getRequestVO());
		//String uri = "tmq:queue:CHNL.TRNFR.REQ.QUEUE";
		//String resUri = "tmq:queue:CHNL.NOTIF.REQ.QUEUE";
		
		
		CamelContext camelContext = (CamelContext) context.getBean("auditCamelConfig");
		Assert.assertNotNull(camelContext);
		
		ProducerTemplate template = camelContext.createProducerTemplate();
		
		Object obj = template.requestBody("direct:auditTest", getResponsePayload());
		
	//	PaymentHistoryHelper.sendObject(bean, "direct-vm:addPayeeService");
		
		//PaymentHistoryHelper.sendObject(bean, "direct:addPayeeServiceKenya");
		Assert.assertNotNull(obj);
		 
	System.out.println("---------------------------------------------------------");
	}
	
public static PayloadDTO getPayload() {
		
		Calendar cal= DateUtils.getCountryCalendar();
		cal.set(Calendar.DATE, 01);
		cal.set(Calendar.MONTH, Calendar.DECEMBER);
		cal.set(Calendar.YEAR, 2012);
		
		PaymentHistoryRequestVO requestVO = new PaymentHistoryRequestVO();
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_ADC);
		user.setCountry(TestHelper.COUNTRY);
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerType(TestHelper.LOGIN_ID);
		user.setCustomerIdType(TestHelper.LOGIN_ID);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setUserId("userId");
		user.setPhone("+1234234345");
		user.setEmailId("a@a.com");
		user.setEmailNotification(false);
		user.setInboxNotification(false);
		user.setSmsNotification(true);
		requestVO.setUser(user);
		
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel(TestHelper.CHANNEL_ADC);
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment("EDMI_TEST");
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(RandomStringUtils.randomAlphanumeric(16));
		clientVO.setVersion(CommonConstants.VERSION);
		clientVO.setDate(cal);
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		
		requestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName(CommonConstants.SERVICE_NAME);
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		serviceVO.setServiceTxnType("GPS");
		
		requestVO.setServiceVO(serviceVO);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID(ReferenceNumberGenerator.generateReferenceNumber(TestHelper.COUNTRY, "IFT", "ADC"));
		messageVO.setRequestType(CommonConstants.REQUEST_TYPE);
		messageVO.setRequestCode(messageVO.getReqID());
		
		requestVO.setMessageVO(messageVO);
		
		
	
		PayloadDTO payloadDTO = new PayloadDTO();
		payloadDTO.setRequestVO(requestVO);
		return payloadDTO;
	}

public static PayloadDTO getPayeePayload() {
	
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();

		billerPayDetailsVO.setConsumerNo("1149433");

		billerPayDetailsVO.setBillerNickName("Raja");

		//billerPayDetailsVO.setBillerCd("KECSKPLC POSTPAID");
		
		billerPayDetailsVO.setBillerCd("KECSNAIROBI WATER");
		
		billerPayDetailsVO.setBillerCategoryCd("12");

		BillerPayRequestVO vO = new BillerPayRequestVO();
		
		BillerPayResponseVO billerPayRequestVO = new BillerPayResponseVO();
		

		PayloadDTO payloadDTO = new PayloadDTO();

	
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_ADC);
		user.setCountry(TestHelper.COUNTRY);
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerType(TestHelper.LOGIN_ID);
		user.setCustomerIdType(TestHelper.LOGIN_ID);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setUserId("userId");
		user.setPhone("+1234234345");
		user.setEmailId("a@a.com");
		user.setEmailNotification(false);
		user.setInboxNotification(false);
		user.setSmsNotification(true);
		billerPayRequestVO.setUser(user);
		
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel(TestHelper.CHANNEL_ADC);
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment("EDMI_TEST");
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(RandomStringUtils.randomAlphanumeric(16));
		//clientVO.setVersion(CommonConstants.VERSION);
		//clientVO.setDate(cal);
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		
		billerPayRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName(CommonConstants.SERVICE_NAME);
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		serviceVO.setServiceTxnType("GPS");
		
		billerPayRequestVO.setServiceVO(serviceVO);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID(ReferenceNumberGenerator.generateReferenceNumber(TestHelper.COUNTRY, "IFT", "ADC"));
		messageVO.setRequestType(CommonConstants.REQUEST_TYPE);
		messageVO.setRequestCode(messageVO.getReqID());
		TransactionInfoVO t = new TransactionInfoVO();
		t.setTxnId("1010010");
		billerPayDetailsVO.setTransactionInfoVO(t);
	
		billerPayRequestVO.setMessageVO(messageVO);
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		payloadDTO.setResponseVO(billerPayRequestVO);
	

		return payloadDTO;

}


private static PayloadDTO getResponsePayload() {
	Calendar cal= DateUtils.getCountryCalendar();
	
	BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
	
	UserVO user = new UserVO();
	user.setChannelId(TestHelper.CHANNEL_IBNK);
	user.setCountry("NG");
	user.setCustName(TestHelper.CUST_NAME);
	user.setCustomerId(TestHelper.LOGIN_ID);
	user.setCustomerType(TestHelper.CUSTOMER_TYPE);
	user.setRole(TestHelper.ROLE);
	user.setEnvironment(TestHelper.ENVIRONMENT);
	user.setLanguage(CommonConstants.LANGUAGE);
	user.setLoginId(TestHelper.LOGIN_ID);
	user.setUserId(TestHelper.LOGIN_ID);
	user.setSegmentCode(TestHelper.SEGMENT_CODE);
	user.setPhone("254722665319");
	user.setEmailId("test@scb.com");
	user.setEmailNotification(true);
	user.setInboxNotification(true);
	user.setSmsNotification(true);
	billerPayResponseVO.setUser(user);
	
	ClientVO clientVO = new ClientVO();
	clientVO.setAppName(TestHelper.APP_NAME);
	clientVO.setChannel("IBNK");
	clientVO.setClientId(TestHelper.CLIENT_ID);
	clientVO.setCountry("NG");
	clientVO.setEnvironment(TestHelper.ENVIRONMENT);
	clientVO.setLanguage(CommonConstants.LANGUAGE);
	clientVO.setOrg(TestHelper.ORG);
	clientVO.setSessionId(TestHelper.SESSION_ID);
	clientVO.setVersion(CommonConstants.VERSION);
	clientVO.setDate(cal);
	clientVO.setIpAddress("127.0.0.1");
	clientVO.setClientIpAddress("127.0.0.1");
	billerPayResponseVO.setClientVO(clientVO);
	
	ServiceVO serviceVO = new ServiceVO();
	serviceVO.setServiceName("BILL");
	serviceVO.setServiceTxnType("GPS");
	serviceVO.setHostEnv(CommonConstants.HOST_ENV);
	billerPayResponseVO.setServiceVO(serviceVO);
	
	MessageVO messageVO = new MessageVO();
	messageVO.setReqID("IBNK-SRM-2803-00");
	messageVO.setRequestType(CommonConstants.BILL_PAYMENT);
	messageVO.setRequestCode(messageVO.getReqID());
	billerPayResponseVO.setMessageVO(messageVO);	
	
	BillerPayDetailsVO billerPayDetailsVO= new BillerPayDetailsVO();
	billerPayDetailsVO.setPayeeId("107");
	billerPayDetailsVO.setCountryCode("NG");
	billerPayDetailsVO.setChannel("IBNK");
	billerPayDetailsVO.setPayMthd("R");
	billerPayDetailsVO.setPaymentType("CASA");
	billerPayDetailsVO.setCustomerId("Arun1234");
	billerPayDetailsVO.setConsumerNo("0000000001");
	billerPayDetailsVO.setBillerCategoryCd("2");
	billerPayDetailsVO.setBillerCategoryDesc("Cable TV Bills");
	billerPayDetailsVO.setBillerCd("NGIS10406");
	billerPayDetailsVO.setBillerDesc("ASIAN BOUQUET");
	billerPayDetailsVO.setMobileNumber("0987654321");
	billerPayDetailsVO.setEmailId("a@b.c");
	
	billerPayDetailsVO.setTxnActStatus("SUCC");
	
	billerPayDetailsVO.setPayRef("IBNK-SRM-2803-00");
	billerPayDetailsVO.setHostReference("1380AR280300");
	
	AccountVO srcAccountVO = new AccountVO();
	
	//right- for positive case
	srcAccountVO.setAccountNumber("0000087762");
	//wrong- for exception case
	//srcAccountVO.setAccountNumber("000007183501");
	
	srcAccountVO.setCurrency("NGN");
	srcAccountVO.setAmount(new BigDecimal(111));
	
	AccountVO destAccountVO = new AccountVO();
	destAccountVO.setAccountNumber("01020584440111");

	ChargesTypeVO charge = new ChargesTypeVO();
	charge.setAmount(12);
	
	TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
	transactionInfoVO.setSrcAccountVO(srcAccountVO);
	transactionInfoVO.setDestAccountVO(destAccountVO);
	transactionInfoVO.setChargesTypeVO(charge);
	transactionInfoVO.setTxnPurpose("Testing");
	transactionInfoVO.setTransferCurrencyCd("NGN");
	transactionInfoVO.setDtProcessed(DateUtils.getCurrentDate());

    transactionInfoVO.setTxnId(messageVO.getReqID());
	billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
	
	PayloadDTO payloadDTO = new PayloadDTO();
	billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
	payloadDTO.setResponseVO(billerPayResponseVO);
	
	return payloadDTO;
}

}
