package com.scb.channels.audit.dao;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.common.helper.TestHelper;

public class AuditServiceDaoTest {
	
	ApplicationContext context;
	AuditServiceVO auditServiceVO;
	AuditServiceDAO auditServiceDaoTest;		

	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		auditServiceVO = new AuditServiceVO();
		auditServiceDaoTest = context.getBean("auditServiceDAO",AuditServiceDAO.class);
	}
	
	
	/*//@Test
	public void AuditServiceUpdateDaoTest(){
		auditServiceVO.setId(5);
		auditServiceVO.setStatusCd("H");
		auditServiceVO.setDtUpd(DateUtils.getCurrentDate());
		auditServiceDaoTest.updateAuditServiceStatus(auditServiceVO);
		
	}*/
	
	@Test
	public void fetchAuditServiceListDaoTest(){
		auditServiceVO.setCustId("CU122");
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		String toDate = dateFormat.format(date);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -90);
        Date todate1 = cal.getTime();
        String fromDate = dateFormat.format(todate1.getTime());
		List<AuditServiceVO> auditServiceList= auditServiceDaoTest.getAuditServiceList(auditServiceVO,fromDate,toDate);
		System.out.println("List Size :: "+auditServiceList.size());
		
	}
	
	
	//@Test
	public void saveAuditServiceTest(){
		auditServiceVO = new AuditServiceVO();
		auditServiceVO.setMoblNo("343434");
		auditServiceVO.setChannel("IBNK");
		auditServiceVO.setSessionId("SS232");
		auditServiceVO.setSessionGroupId("SSGRID11");
		auditServiceVO.setErrorCd("ER0077");
		auditServiceVO.setCtryCd("NG01");
		auditServiceVO.setType("SSTYPE");
		auditServiceVO.setFuncCd("FUNCCD");
		auditServiceVO.setEventCd("EVCD11");
		auditServiceVO.setuUser("UUSR2");
		auditServiceVO.setUserId("110022");
		auditServiceVO.setCustGroupId("GRP12");
		auditServiceVO.setName("Sachin100");
		auditServiceVO.setDtAudit(Calendar.getInstance().getTime());
		auditServiceVO.setAuditBy("Auditor");
		auditServiceVO.setDtCreated(Calendar.getInstance().getTime());
		auditServiceVO.setCreatedBy("DEV");
		auditServiceVO.setDtUpd(Calendar.getInstance().getTime());
		auditServiceVO.setVersion(1);

		auditServiceVO.setCustId("CU122");
		auditServiceVO.setCustIdType("CUID11");
		auditServiceVO.setCustomDt(Calendar.getInstance().getTime());
		auditServiceVO.setCustomDec01(11.23);
		auditServiceVO.setCustomDec02(12.23);
		auditServiceVO.setCustomDec03(13.23);
		auditServiceVO.setCustomDec04(14.23);
		auditServiceVO.setCustomDec05(15.23);
		auditServiceVO.setClientId("VAR01");
		auditServiceVO.setClientId("VAR02");
		auditServiceVO.setRole("VAR03");
		auditServiceVO.setCustomVar04("VAR04");
		auditServiceVO.setCustomVar05("VAR05");
		auditServiceVO.setEnvironment("ENV");
		auditServiceVO.setErrorDesc("ERRDESC");
		auditServiceDaoTest.saveAuditService(auditServiceVO);
		
	}

}
