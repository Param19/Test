package com.scb.channels.audit.service.impl;


import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.audit.service.AuditServiceService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.common.helper.TestHelper;

public class AuditServiceServiceTest {
	
	ApplicationContext context;
	AuditServiceVO auditServiceVO;
	AuditServiceService auditServiceService;  

	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		auditServiceVO = new AuditServiceVO();
		auditServiceService = context.getBean("auditServiceService",AuditServiceService.class); 
	}
	
	
	/*//@Test
	public void AuditServiceUpdateDaoTest(){
		auditServiceVO.setId(5);
		auditServiceVO.setStatusCd("H");
		auditServiceVO.setDtUpd(DateUtils.getCurrentDate());
		auditServiceService.updateTransactionStatus(auditServiceVO);
	}*/
	

	@Test
	public void fetchAuditServiceListTest(){
		auditServiceVO.setCustId("CU122");
		List<AuditServiceVO> list = auditServiceService.getAuditServiceList(auditServiceVO);
		System.out.println(list.size());
		
	}
	
	
	
	//@Test
	public void saveAuditServiceTest(){
		auditServiceVO = new AuditServiceVO();
		auditServiceVO.setMoblNo("32353");
		auditServiceVO.setChannel("ADC");
		auditServiceVO.setSessionId("SS232");
		auditServiceVO.setSessionGroupId("SSGRI32");
		auditServiceVO.setErrorCd("ER0077");
		auditServiceVO.setCtryCd("NG01");
		auditServiceVO.setType("SSTYPE");
		auditServiceVO.setFuncCd("FUNCCD");
		auditServiceVO.setEventCd("EVCD11");
		auditServiceVO.setuUser("UUSR2");
		auditServiceVO.setUserId("334123");
		auditServiceVO.setCustGroupId("GRP12");
		auditServiceVO.setName("Dhoni07");
		auditServiceVO.setDtAudit(Calendar.getInstance().getTime());
		auditServiceVO.setAuditBy("Auditor");
		auditServiceVO.setDtCreated(Calendar.getInstance().getTime());
		auditServiceVO.setCreatedBy("DEV");
		auditServiceVO.setDtUpd(Calendar.getInstance().getTime());
		auditServiceVO.setVersion(1);

		auditServiceVO.setCustId("CU122");
		auditServiceVO.setCustIdType("CUID11");
		auditServiceVO.setCustomDt(Calendar.getInstance().getTime());
		auditServiceVO.setCustomDec01(11.23);
		auditServiceVO.setCustomDec02(12.23);
		auditServiceVO.setCustomDec03(13.23);
		auditServiceVO.setCustomDec04(14.23);
		auditServiceVO.setCustomDec05(15.23);
		auditServiceVO.setClientId("VAR01");
		auditServiceVO.setClientId("VAR02");
		auditServiceVO.setRole("VAR03");
		auditServiceVO.setCustomVar04("VAR04");
		auditServiceVO.setCustomVar05("VAR05");
		auditServiceVO.setEnvironment("ENV");
		auditServiceVO.setErrorDesc("ERRDESC");
		auditServiceService.saveAuditService(auditServiceVO);
		
		
		
	}

}
