/**
 * 
 */
package com.scb.channels.common.helper;

import javax.naming.NamingException;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import com.scb.channels.base.vo.PayloadDTO;


/**
 * @author 1411807
 *
 */
public class TestHelper {
	
	public static final String CUST_NAME= "Sachin";
	public static final String CUSTOMER_ID= "000000001";
	public static final String CUSTOMER_TYPE= "FOA";
	public static final String BILL_PAY_CUSTOMER_TYPE= "01";
	public static final String ROLE= "FOA_CUST_NG";
	public static final String ENVIRONMENT= "Local";
	public static final String LOGIN_ID= "000002002";
	public static final String SEGMENT_CODE= "01";
	public static final String CHANNEL_IBNK= "IBNK";
	public static final String CHANNEL_ADC= "ADC";
	public static final String COUNTRY= "NG";
	public static final String CHANNEL= "IBNK";
	public static final String CLIENT_ID= "1122";
	public static final String ORG= "IBK";
	public static final String APP_NAME= "NFSIBNK";
	public static final String SESSION_ID= "10101";
	
	public static final String BILLER_NAME= "Airtel";
	public static final String BILLER_PAY_REF= "Ref";
	public static final String DB_ACC_SRC_TYPE= "CASA";
	public static final String BILLER_CD= "1005";
	public static final String BILLER_DESC= "Biller";
	public static final String UTILITY_CD= "10000";
	public static final String UTILITY_DESC= "Utility";
	public static final String CONSUMER_NO= "12345";
	public static final String CONSUMER_DESC= "Consumer";
	public static final String TXN_TYPE_CD= "Txn";
	public static final String BANK_NAME= "SCB";
	public static final String BRANCH_NAME= "SCB1";
	public static final String CURRENCY= "NGN";
	public static final String ACC_NUM= "000000001";
	public static final String PRODUCT_CODE= "112233";
	public static final String UNIVERSAL_ACC_NUM= "000000001";
	public static final String MEMO= "Memo";
	
	private static ApplicationContext context = null;
	
	public static ApplicationContext getContext(){
		/*if (context == null) {
			context = new ClassPathXmlApplicationContext("/spring/*-context.xml","/spring/*-integration.xml");
		}*/
		loadContext();	
		return context;
	}
	

	private TestHelper() { }
	public static SimpleNamingContextBuilder namingContext = new SimpleNamingContextBuilder();
	private static void loadContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("/spring/audit*.xml","/spring/base-dao-context.xml","/spring/audit-test-jms-context.xml");
			//namingContext.bind("jdbc/srmDataSource", ods);
			/*namingContext.bind("jdbc/srmDataSource", context.getBean("dataSource")); 
			namingContext.bind("srmConnFactory",context.getBean("auditJmsQueueConnectionFactory"));
			
			namingContext.bind("chnlAuditReqQueue",context.getBean("chnlAuditReqQueue"));	
			namingContext.bind("chnlAuditRespQueue",context.getBean("chnlAuditRespQueue"));	
			namingContext.bind("chnlAuditServiceReqQueue",context.getBean("chnlAuditServiceReqQueue"));	
			namingContext.bind("chnlAuditServiceRespQueue",context.getBean("chnlAuditServiceRespQueue"));	
			*/
			
			
			/*namingContext.bind("CHNL.LOGIN.REQ.QUEUE",context.getBean("loginReqQueue"));*/
			/*namingContext.bind("CHNL.LOGIN.RESP.QUEUE",context.getBean("LoginRespQuue"));	
			namingContext.bind("CHNL.LOGOUT.REQ.QUEUE",context.getBean("logoutReqQueue"));	
			namingContext.bind("CHNL.LOGOUT.RESP.QUEUE",context.getBean("logoutRespQueue"));	
			namingContext.bind("CHNL.RESP.QUEUE",context.getBean("respQueue"));	*/
			
			
			try {
				/*namingContext.activate();				
				context = new ClassPathXmlApplicationContext("/spring/*-context.xml", "/spring/*-integration.xml");*/	
				
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	public static void sendObject(PayloadDTO payloadDTO, String uri){
		try{
		CamelContext context = (CamelContext) TestHelper.getContext().getBean("auditCamelConfig");
		ProducerTemplate template = context.createProducerTemplate();
		template.sendBody(uri, payloadDTO);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("----------------------");
		}
	}

}
