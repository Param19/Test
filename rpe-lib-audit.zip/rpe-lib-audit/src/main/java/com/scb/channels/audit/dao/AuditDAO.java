package com.scb.channels.audit.dao;

import java.util.List;

import com.scb.channels.base.vo.AuditCreditTxVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.JetcoAuditTxn;
import com.scb.channels.base.vo.QRAuditTxnVO;



/**
 * The Interface AuditDAO.
 */
public interface AuditDAO {
	
	/**
	 * Save audit.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 */
	void saveAudit(AuditSumTxnVO auditSumTxnVO);
	
	/**
	 * Update txn status.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 */
	void updateTxnStatus(AuditSumTxnVO auditSumTxnVO);
	
	/**
	 * Gets the audit vo.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 * @return the audit vo
	 */
	AuditSumTxnVO getAuditVO(AuditSumTxnVO auditSumTxnVO);
	
	
	/**
	 * Gets the audit txn vo list.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 * @return the audit vo list
	 */
	List<AuditSumTxnVO> getAuditTxnList(AuditSumTxnVO auditSumTxnVO,String fromDate,String toDate);
	/**
	 * Save credit audit.
	 *
	 * @param auditCreditTxVO the audit credit tx vo
	 */
	void saveCreditAudit(AuditCreditTxVO auditCreditTxVO);
	
		/**
	 * Save qr audit txn vo.
	 *
	 * @param qrAuditTxnVO the qr audit txn vo
	 */
	void saveQrAudit(QRAuditTxnVO qrAuditTxnVO);
	
	/**
	 * save jetco payment audit
	 * @param jetcoAuditTxn
	 */
	void saveJetcoAudit(JetcoAuditTxn jetcoAuditTxn);
}
