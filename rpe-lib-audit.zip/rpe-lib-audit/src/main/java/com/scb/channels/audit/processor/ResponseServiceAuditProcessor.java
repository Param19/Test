package com.scb.channels.audit.processor;

import com.scb.channels.audit.service.AuditServiceService;
import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class ResponseServiceAuditProcessor.
 */
public class ResponseServiceAuditProcessor extends AbstractProcessor {


	/** The audit service. */
	private AuditServiceService auditServiceService;
	
	/** The response transformer service. */
	private ResponseTransformerService<PayloadDTO, AuditServiceVO> responseTransformerService;
	
	

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		AuditServiceVO auditServiceVO = responseTransformerService.tranformResponse(bean);
		if (auditServiceVO != null) {
			auditServiceVO.setCreatedBy(CommonHelper.getJVMName());
			auditServiceVO.setAuditBy(CommonHelper.getJVMName());
				auditServiceService.saveAuditService(auditServiceVO);
		}
		return bean;
	}

	/** 
	 * 
	 * @param responseTransformerService
	 */
	public void setResponseTransformerService(
			ResponseTransformerService<PayloadDTO, AuditServiceVO> responseTransformerService) {
		this.responseTransformerService = responseTransformerService;
	}

	/**
	 * 
	 * @param auditServiceService
	 */
	public void setAuditServiceService(AuditServiceService auditServiceService) {
		this.auditServiceService = auditServiceService;
	}
}
