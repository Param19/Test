package com.scb.channels.audit.processor;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditCallable;
import com.scb.channels.base.helper.ExecutorServiceHelper;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class AuditProcessor.
 */
public class AuditProcessor extends AbstractProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AuditProcessor.class);
	
	/** The callable. */
	private AuditCallable callable;
	
	/** The blocking. */
	private boolean blocking = true;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		callable.setBean(bean);
		FutureTask<AuditSumTxnVO> task = new FutureTask<AuditSumTxnVO>(callable);
		ExecutorServiceHelper.EXECUTOR_SERVICE.submit(task);
		if (blocking) {
			try {
				task.get();
			} catch (InterruptedException e) {
				LOGGER.error(e.getMessage());
			} catch (ExecutionException e) {
				LOGGER.error(e.getMessage());
			}
		}
		return bean;
	}
	
	/* (non-Javadoc)
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	/*public void process(Exchange exchange) throws Exception {
		PayloadDTO payloadDTO = exchange.getIn().getBody(PayloadDTO.class);
		process(payloadDTO);
	}*/
	

	/**
	 * Sets the callable.
	 *
	 * @param callable the callable to set
	 */
	public void setCallable(AuditCallable callable) {
		this.callable = callable;
	}


	/**
	 * Checks if is blocking.
	 *
	 * @return the blocking
	 */
	public boolean isBlocking() {
		return blocking;
	}


	/**
	 * Sets the blocking.
	 *
	 * @param blocking the blocking to set
	 */
	public void setBlocking(boolean blocking) {
		this.blocking = blocking;
	}


	
	

}
