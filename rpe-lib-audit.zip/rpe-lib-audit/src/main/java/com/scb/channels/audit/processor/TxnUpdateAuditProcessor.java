package com.scb.channels.audit.processor;


import com.scb.channels.audit.service.AuditService;
import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class TxnUpdateAuditProcessor.
 */
public class TxnUpdateAuditProcessor extends AbstractProcessor {


	/** The audit service. */
	private AuditService auditService;
	
	/** The response transformer service. */
	private ResponseTransformerService<PayloadDTO, AuditSumTxnVO> responseTransformerService;
	
	

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		AuditSumTxnVO auditSumTxnVO = responseTransformerService.tranformResponse(bean);
		if (auditSumTxnVO != null) {
			auditSumTxnVO.setCreatedBy(CommonHelper.getJVMName());
			auditSumTxnVO.setAuditBy(CommonHelper.getJVMName());
			auditService.saveAudit(auditSumTxnVO);
		}
		return bean;
	}


	/**
	 * Sets the audit service.
	 *
	 * @param auditService the auditService to set
	 */
	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}
	


	/**
	 * Sets the response transformer service.
	 *
	 * @param responseTransformerService the response transformer service
	 */
	public void setResponseTransformerService(
			ResponseTransformerService<PayloadDTO, AuditSumTxnVO> responseTransformerService) {
		this.responseTransformerService = responseTransformerService;
	}

}
