package com.scb.channels.audit.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.AuditCreditTxVO;
import com.scb.channels.base.vo.HostResponseTypeVO;
import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.StatusTypeVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.InwardMappingHelper;

/**
 * The Class CreditTxAuditProcessor.
 *
 * @author 1493439
 */
public class CreditTxAuditProcessor extends AbstractProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CreditTxAuditProcessor.class);
	
	/** The audit service. */
	private AuditService auditService;
	
	/** The response transformer service. *//*
	private ResponseTransformerService<PayloadDTO, AuditCreditTxVO> responseTransformerService;*/
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

		LOGGER.info("::::::::::::::::: CreditTxAuditProcessor doTasks start:::::::::::");
		
		AuditCreditTxVO auditCreditTxVO = tranformResponse(bean);
		
		if(auditCreditTxVO != null){
			LOGGER.info("::::::::::::::::: CreditTxAuditProcessor doTasks auditCreditTxVO != null:::::::::::");
			auditService.saveCreditAudit(auditCreditTxVO);
		}
		
		LOGGER.info("::::::::::::::::: CreditTxAuditProcessor doTasks end:::::::::::");
		return bean;
	}

	public AuditCreditTxVO tranformResponse(PayloadDTO payloadDTO) {
		
		InwardPaymentRequestVO inwardPaymentRequestVO = null;
		InwardPaymentResponseVO inwardPaymentResponseVO = null;
		InwardInquiryRequestVO inquiryRequestVO = null;
		AuditCreditTxVO auditCreditTxVO = null;
		LOGGER.info("::::::::::::::::: CreditTxAuditProcessor tranformResponse start:::::::::::");
	
		if(payloadDTO != null && payloadDTO.getRequestVO() != null && payloadDTO.getRequestVO() instanceof InwardPaymentRequestVO){
			inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
			LOGGER.info("::::::::::::::::: CreditTxAuditProcessor tranformResponse if condition InwardPaymentRequestVO:::::::::::"+inwardPaymentRequestVO);
			auditCreditTxVO = InwardMappingHelper.setAuditCreditTxVO(inwardPaymentRequestVO);
		} 
		
		if(payloadDTO != null && payloadDTO.getRequestVO() != null && payloadDTO.getRequestVO() instanceof InwardInquiryRequestVO){
			inquiryRequestVO = (InwardInquiryRequestVO)payloadDTO.getRequestVO();
			LOGGER.info("::::::::::::::::: CreditTxAuditProcessor tranformResponse if condition InwardInquiryRequestVO:::::::::::"+inquiryRequestVO);
			auditCreditTxVO = InwardMappingHelper.setAuditCreditTxVO(inquiryRequestVO);
			auditCreditTxVO.setCreatedBy("SYSTEM");
			auditCreditTxVO.setVersion(1);
		}
		
		if(payloadDTO != null && payloadDTO.getResponseVO() != null && payloadDTO.getResponseVO() instanceof InwardPaymentResponseVO){
			inwardPaymentResponseVO = (InwardPaymentResponseVO)payloadDTO.getResponseVO();
			LOGGER.info("::::::::::::::::: CreditTxAuditProcessor tranformResponse if condition InwardPaymentResponseVO:::::::::::"+inwardPaymentRequestVO);
		} 
		//AuditCreditTxVO auditCreditTxVO = InwardMappingHelper.setAuditCreditTxVO(inwardPaymentRequestVO);
		auditCreditTxVO.setAuditBy(CommonHelper.getJVMName());
		//auditCreditTxVO.setServiceName(inwardPaymentRequestVO.getServiceName());
		
		if(inwardPaymentResponseVO != null){
			LOGGER.info("::::::::::::::::: CreditTxAuditProcessor tranformResponse inwardPaymentResponseVO != null:::::::::::"+inwardPaymentResponseVO);
			StatusTypeVO statusTypeVO = inwardPaymentResponseVO.getStatusTypeVO();
			//auditCreditTxVO.setStatusCd(inwardPaymentRequestVO.getPaymentStatus());
			
			if(statusTypeVO != null){
				HostResponseTypeVO hostResponseTypeVO = statusTypeVO.getHostResponseTypeVO();
				if(hostResponseTypeVO != null){
					auditCreditTxVO.setErrorCd(hostResponseTypeVO.getCode());
					auditCreditTxVO.setErrorDesc(hostResponseTypeVO.getDesc());
				}
			}
		}
		
		if(inwardPaymentRequestVO != null){
			if(inwardPaymentRequestVO.getPaymentStatus().equalsIgnoreCase("SRVTIMEOUT")){
				auditCreditTxVO.setErrorCd(ExceptionMessages._503.getCode());
				auditCreditTxVO.setErrorDesc(CommonConstants.HOST_TIMEOUT_MESSAGE);
			}
		}
		LOGGER.info("::::::::::::::::: CreditTxAuditProcessor tranformResponse END:::::::::::");
		
		return auditCreditTxVO;
	}

	/**
	 * @return the auditService
	 */
	public AuditService getAuditService() {
		return auditService;
	}

	/**
	 * @param auditService the auditService to set
	 */
	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}

	/**
	 * @return the responseTransformerService
	 *//*
	public ResponseTransformerService<PayloadDTO, AuditCreditTxVO> getResponseTransformerService() {
		return responseTransformerService;
	}

	*//**
	 * @param responseTransformerService the responseTransformerService to set
	 *//*
	public void setResponseTransformerService(
			ResponseTransformerService<PayloadDTO, AuditCreditTxVO> responseTransformerService) {
		this.responseTransformerService = responseTransformerService;
	}*/

}
