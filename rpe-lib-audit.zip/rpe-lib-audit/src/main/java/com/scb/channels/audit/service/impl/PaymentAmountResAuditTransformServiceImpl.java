/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;

/**
 * @author 1317590
 *
 */
public class PaymentAmountResAuditTransformServiceImpl implements ResponseTransformerService<PayloadDTO, AuditServiceVO>{

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentAmountResAuditTransformServiceImpl.class);
	
	public AuditServiceVO tranformResponse(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformResponse PaymentAmountResAuditTransformServiceImpl ->  Audit Service ");
		if (bean.getResponseVO() instanceof CustomerPaymentAmountResponseVO) {
			CustomerPaymentAmountResponseVO paymentAmountResponseVO = (CustomerPaymentAmountResponseVO) bean.getResponseVO(); 
			paymentAmountResponseVO.setCreatedBy(CommonConstants.SYSTEM);
			paymentAmountResponseVO.getServiceVO().setServiceTxnType(CommonConstants.RESPONSE);
			paymentAmountResponseVO.setDateUpdated(Calendar.getInstance());
			AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPaymentAmountRespAuditService(paymentAmountResponseVO);
			LOGGER.debug("---------After tranformResponse paymentAmountResponseVO ->  Audit Service "+auditServiceVO);
			return auditServiceVO;
		}
		
		return null;
	}

}
