package com.scb.channels.audit.service.impl;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.dao.AuditDAO;
import com.scb.channels.audit.service.AuditService;
import com.scb.channels.base.vo.AuditCreditTxVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.JetcoAuditTxn;
import com.scb.channels.base.vo.QRAuditTxnVO;

/**
 * The Class AuditServiceImpl.
 */
public class AuditServiceImpl implements AuditService {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AuditServiceImpl.class);
	/** The audit dao. */
	private AuditDAO auditDAO;
	
	/**
	 * Save audit.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @see com.scb.channels.common.service.AuditService#saveAudit(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public void saveAudit(AuditSumTxnVO auditSumTxnVO) {
		try{
		auditDAO.saveAudit(auditSumTxnVO);
		}
		catch(Exception e){
			LOGGER.error("Exception occurred ::: ",e);
		}
	}
	
	/**
	 * Update transaction status.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @see com.scb.channels.common.service.AuditService#updateTransactionStatus(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public void updateTransactionStatus(AuditSumTxnVO auditSumTxnVO) {
		auditDAO.updateTxnStatus(auditSumTxnVO);
	}
	
	/**
	 * Gets the audit vo.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @return the audit vo
	 * @see com.scb.channels.common.service.AuditService#getAuditVO(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public AuditSumTxnVO getAuditVO(AuditSumTxnVO auditSumTxnVO) {
		return auditDAO.getAuditVO(auditSumTxnVO);
	}
	
	/**
	 * Gets the audit service List.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @return the audit vo
	 * @see com.scb.channels.common.service.AuditServiceImpl#getAuditVO(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public List<AuditSumTxnVO> getAuditTxnList(AuditSumTxnVO auditSumTxnVO) {
		
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		String toDate = dateFormat.format(date);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -90);
        Date fromDate1 = cal.getTime();
        String fromDate = dateFormat.format(fromDate1.getTime());
        /*System.out.println("FromDate :: "+fromDate+"  To Date :: "+toDate);*/
		return auditDAO.getAuditTxnList(auditSumTxnVO,fromDate,toDate);
	}
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.audit.service.AuditService#saveAudit(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public void saveCreditAudit(AuditCreditTxVO auditCreditTxVO) {
		try{
		LOGGER.info("::::::::::::::::: AuditServiceImpl saveCreditAudit start:::::::::::");	
		auditDAO.saveCreditAudit(auditCreditTxVO);
		LOGGER.info("::::::::::::::::: AuditServiceImpl saveCreditAudit end:::::::::::");	
		}
		catch(Exception e){
			LOGGER.info("::::::::::::::::: AuditServiceImpl saveCreditAudit exception:::::::::::",e);	
		}
	}

	/**
	 * Gets the audit dao.
	 *
	 * @return the auditDAO
	 */
	public AuditDAO getAuditDAO() {
		return auditDAO;
	}

	/**
	 * Sets the audit dao.
	 *
	 * @param auditDAO the auditDAO to set
	 */
	public void setAuditDAO(AuditDAO auditDAO) {
		this.auditDAO = auditDAO;
	}
	
		/**
	 * Save audit.
	 * 
	 * @param qrAuditTxnVO
	 *            the qr audit txn vo
	 * @see com.scb.channels.common.service.AuditService#saveQrAudit(com.scb.channels.base.vo.QRAuditTxnVO)
	 */
	public void saveQrAudit(QRAuditTxnVO qrAuditTxnVO) {
		try{
		auditDAO.saveQrAudit(qrAuditTxnVO);
		}
		catch(Exception e){
			LOGGER.error("Exception occurred ::: ",e);
		}
	}

	@Override
	public void saveJetcoAudit(JetcoAuditTxn jetcoAuditTxn) {
		try {
			auditDAO.saveJetcoAudit(jetcoAuditTxn);
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
	}
	
	

}
