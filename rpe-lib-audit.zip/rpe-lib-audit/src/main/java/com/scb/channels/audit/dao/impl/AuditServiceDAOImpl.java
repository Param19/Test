package com.scb.channels.audit.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.audit.dao.AuditServiceDAO;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadHistory;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;

/**
 * The Class AuditServiceDAOImpl.
 */
public class AuditServiceDAOImpl extends HibernateDaoSupport implements AuditServiceDAO {
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AuditServiceDAOImpl.class);
	/**
	 * Save audit.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @see com.scb.channels.audit.dao.AuditServiceDAO#saveAudit(com.scb.channels.base.vo.AuditServiceVO)
	 */
	public void saveAuditService(AuditServiceVO auditServiceVO) {
		LOGGER.info("AuditServiceDAOImpl :: saveAuditService :: Start ");
		
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction transaction = null;
		try{
			LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
			transaction = session.beginTransaction();
			LOGGER.info(":::::::::::::; doing insert :::::::::::::");
			session.save(auditServiceVO);
			transaction.commit();
			session.flush();
			session.close();
			LOGGER.info(":::::::::::::;  saveAuditService Commit successfull :::::::::::::");
		} catch (Exception exception) {
			LOGGER.info(":::::::::::::; going to rollback add saveAuditService :::::::::::::");
			transaction.rollback();
			session.close();
			exception.printStackTrace();
			LOGGER.info(":::::::::::::; saveAuditService Rollback successfull :::::::::::::");
		}
		LOGGER.info("AuditServiceDAOImpl :: saveAuditService :: End ");
	}
	/**
	 * Gets the audit vo.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @return the audit vo
	 * @see com.scb.channels.audit.dao.AuditServiceDAO#getAuditServiceVO(com.scb.channels.base.vo.AuditServiceVO)
	 */
	public AuditServiceVO getAuditServiceVO(AuditServiceVO auditServiceVO) {
		Criteria criteria = getSession().createCriteria(AuditServiceVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.AUD_CUST_ID, auditServiceVO.getCustId()));
		criteria.addOrder(Order.desc(HibernateHelper.AUD_CUST_ID));
		List<AuditServiceVO> auditVOList = criteria.list();
		if (!CollectionUtils.isEmpty(auditVOList)) {
			return auditVOList.get(0);
		} else {
			return null;
		}
	}

	
	
	
	/**
	 * Gets the Audit Service List.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @return the audit vo
	 * @see com.scb.channels.audit.dao.AuditServiceDAO#getAuditServiceVO(com.scb.channels.base.vo.AuditServiceVO)
	 */
	public List<AuditServiceVO> getAuditServiceList(AuditServiceVO auditServiceVO,String fromDate,String toDate) {
		Query query = getSession().createQuery("from AuditServiceVO where dt_audit between '"+fromDate+"' and '"+toDate+"' and custId=:custId ");
		query.setParameter(HibernateHelper.AUD_CUST_ID, auditServiceVO.getCustId());
		List<AuditServiceVO> auditVOList = query.list();
		return auditVOList;
	}
	
	
	public void saveDownloadHistory(List<BillerDownloadHistory> history) {
		getHibernateTemplate().saveOrUpdateAll(history);
		}
	
	
	@Override
	public BillerDownloadResponseVO archiveAuditService(
			BillerDownloadRequest billerDownloadRequest) {
		
		LOGGER.info("ArchivalDAO inside archiveAudit method");
		
		Session session = null;
		
		BillerDownloadResponseVO billerDownloadResponse = new BillerDownloadResponseVO();
		try {
 			session = getHibernateTemplate().getSessionFactory().openSession();
			
 			Query auditServiceQuery = session.getNamedQuery("callStockStoreProcedureAudit");
 			auditServiceQuery.setString("i_tablename", "AUDIT_SERVICE");
			List auditServiceList = auditServiceQuery.list();
			
			System.out.println("----auditServiceList----------value ---------" + auditServiceList);
			LOGGER.info("-----auditServiceList---------value --------- ::: " + auditServiceList);
			
			Query auditTxnQuery = session.getNamedQuery("callStockStoreProcedureAudit");
			auditTxnQuery.setString("i_tablename", "AUDIT_TRANSACTION");
			List auditTxnList = auditTxnQuery.list();
			
			System.out.println("-----auditTxnList---------value ---------" + auditTxnList);
			LOGGER.info("-------auditTxnList-------value --------- ::: " + auditTxnList);
			
			billerDownloadResponse.setStatus("Submitted");
			billerDownloadResponse.setStatusDesc("Submitted");
			
		}catch(Exception e) {
			 
			 LOGGER.info("Exception occurred duirng archiveAudit Process::: " + e.getMessage());
			 
		} finally {
			if(session != null) {
				LOGGER.info("ArchivalDAOImpl archiveAudit closing Session ");
				session.close();
			}
		}	
		return billerDownloadResponse; 
	}
	 
		 
}
