package com.scb.channels.audit.processor;

import com.scb.channels.audit.service.AuditServiceService;
import com.scb.channels.audit.service.DownloadHistoryService;
import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class ResponseServiceAuditProcessor.
 */
public class BillerDownloadHistoryProcessor extends AbstractProcessor {


	/** The audit service. */
	private DownloadHistoryService downloadService;
	
	 

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		BillerDownloadResponse resposne=(BillerDownloadResponse)bean.getResponseVO();
			downloadService.saveDownloadHistory(resposne.getBillerDownloadHistory());	
		return bean;
	}



	public DownloadHistoryService getDownloadService() {
		return downloadService;
	}



	public void setDownloadService(DownloadHistoryService downloadService) {
		this.downloadService = downloadService;
	}

	 

	/**
	 * 
	 * @param auditServiceService
	 */
	 
}
