package com.scb.channels.audit.service.impl;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.dao.AuditServiceDAO;
import com.scb.channels.audit.service.DownloadHistoryService;
import com.scb.channels.base.vo.BillerDownloadHistory;

/**
 * The Class AuditServiceServiceImpl.
 */
public class DownloadHistoryServiceImpl implements DownloadHistoryService {


	/** The AuditServiceDAO. */
	private AuditServiceDAO auditServiceDAO;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadHistoryServiceImpl.class);
	
	public void setAuditServiceDAO(AuditServiceDAO auditServiceDAO) {
		this.auditServiceDAO = auditServiceDAO;
	}

	@Override
	public void saveDownloadHistory(List<BillerDownloadHistory> history) {
		try{
			auditServiceDAO.saveDownloadHistory(history);
			
		}catch(Exception e){
			LOGGER.error("Exception occurred ::: ",e);
		}
		
	}
 
}
