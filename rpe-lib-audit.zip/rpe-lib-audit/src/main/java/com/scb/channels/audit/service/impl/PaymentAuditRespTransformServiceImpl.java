package com.scb.channels.audit.service.impl;

import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;

/**
 * The Class AuditTransformRequestServiceImpl.
 */
public class PaymentAuditRespTransformServiceImpl implements ResponseTransformerService<PayloadDTO, AuditSumTxnVO> {
	

	/**
	 * Gets the audit transform request object.
	 * 
	 * @param billerPayRequestVO
	 *            the biller pay request vo
	 * @return the audit transform request object
	 * @see com.scb.channels.common.service.RequestTransformerService#tranformRequest(com.scb.channels.common.vo.BillerPayRequestVO)
	 */
	public AuditSumTxnVO tranformResponse(PayloadDTO bean) {
		if (bean.getResponseVO() instanceof BillerPayResponseVO) {
			BillerPayResponseVO billerPayResponseVO =(BillerPayResponseVO) bean.getResponseVO(); 
			if (billerPayResponseVO.getBillerPayDetailsVO() != null 
					&& billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() !=null) {
				
				AuditSumTxnVO auditSumTxnVO = BillpaymentMappingHelper.getPaymentRespAuditTxnService(billerPayResponseVO);
			/*	auditSumTxnVO.setTxnId(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnId());
				auditSumTxnVO.setTxtStatusCd(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnStatusCd());
				auditSumTxnVO.setStatusCd(billerPayResponseVO.getStatus());*/
				return auditSumTxnVO;
			}
		}
		return null;
	}

}
