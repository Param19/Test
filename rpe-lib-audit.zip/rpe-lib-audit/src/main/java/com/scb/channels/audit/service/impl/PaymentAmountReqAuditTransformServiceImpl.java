/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;

/**
 * @author 1317590
 * 
 */
public class PaymentAmountReqAuditTransformServiceImpl implements RequestTransformerService<PayloadDTO, AuditServiceVO>{

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentAmountReqAuditTransformServiceImpl.class);
	
	public AuditServiceVO tranformRequest(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformResponse PaymentAmountReqAuditTransformServiceImpl ->  Audit Service ");
				
		if (bean.getRequestVO() instanceof CustomerPaymentAmountRequestVO) {
			LOGGER.debug("---------After tranformResponse CustomerPaymentAmountRequestVO ->  Audit Service ");
			CustomerPaymentAmountRequestVO paymentAmountResquestVO = (CustomerPaymentAmountRequestVO) bean.getRequestVO(); 
			paymentAmountResquestVO.setCreatedBy(CommonConstants.SYSTEM);
			paymentAmountResquestVO.getServiceVO().setServiceTxnType(CommonConstants.REQUEST);
			paymentAmountResquestVO.setStatus(CommonConstants.NA);
			paymentAmountResquestVO.setDateUpdated(Calendar.getInstance());
			
			AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPaymentAmountReqAuditService(paymentAmountResquestVO);
			LOGGER.debug("---------After tranformResponse CustomerPaymentAmountRequestVO ->  Audit Service "+auditServiceVO);
			return auditServiceVO;
		}
		return null;
	}

}
