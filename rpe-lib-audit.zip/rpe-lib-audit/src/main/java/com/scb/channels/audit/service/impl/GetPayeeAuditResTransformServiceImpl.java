/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;


/**
 * @author 1521723
 *
 */
public class GetPayeeAuditResTransformServiceImpl implements ResponseTransformerService<PayloadDTO, AuditServiceVO>{

	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(GetPayeeAuditResTransformServiceImpl.class);
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.audit.service.ResponseTransformerService#tranformResponse(java.lang.Object)
	 */
	public AuditServiceVO tranformResponse(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformResponse GetPayeeAuditRepTransformServiceImpl ->  Audit Service ");
		if (bean.getResponseVO() instanceof ViewPayeeResponseVO) {
			ViewPayeeResponseVO viewPayeeResponseVO =(ViewPayeeResponseVO) bean.getResponseVO();
			ViewPayeeRequestVO viewPayeeRequestVO =(ViewPayeeRequestVO) bean.getRequestVO();
			viewPayeeResponseVO.setClientVO(viewPayeeRequestVO.getClientVO());
			viewPayeeResponseVO.setCreatedBy("SYSTEM");
			viewPayeeResponseVO.setDateUpdated(Calendar.getInstance());
			viewPayeeResponseVO.setDateCreated(Calendar.getInstance());
				AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPayeeResAuditService(viewPayeeResponseVO);
				LOGGER.debug("---------After tranformResponse GetPayeeAuditRepTransformServiceImpl ->  Audit Service "+auditServiceVO);
				auditServiceVO.setFuncCd(viewPayeeRequestVO.getServiceVO().getServiceName());
				auditServiceVO.setSessionId(viewPayeeRequestVO.getMessageVO().getReqID());
				return auditServiceVO;
		}
		return null;
	}


}
