package com.scb.channels.audit.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.audit.dao.AuditDAO;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.AuditCreditTxVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.JetcoAuditTxn;
import com.scb.channels.base.vo.QRAuditTxnVO;

/**
 * The Class AuditDAOImpl.
 */
public class AuditDAOImpl extends HibernateDaoSupport implements AuditDAO {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AuditDAOImpl.class);
	/**
	 * Save audit.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @see com.scb.channels.audit.dao.AuditDAO#saveAudit(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public void saveAudit(AuditSumTxnVO auditSumTxnVO) {
		getHibernateTemplate().save(auditSumTxnVO);
	}

	/**
	 * Update txn status.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @see com.scb.channels.audit.dao.AuditDAO#updateTxnStatus(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public void updateTxnStatus(AuditSumTxnVO auditSumTxnVO) {
		AuditSumTxnVO auditVO = getAuditVO(auditSumTxnVO);
		if (auditVO != null) {
			auditVO.setTxtStatusCd(auditSumTxnVO.getTxtStatusCd());
			auditVO.setStatusCd(auditSumTxnVO.getStatusCd());
			auditVO.setDateUpd(DateUtils.getCurrentDate());
			getSession().update(auditVO);
		}
	}
	
	/**
	 * Gets the audit vo.
	 * 
	 * @param auditSumTxnVO
	 *            the audit sum txn vo
	 * @return the audit vo
	 * @see com.scb.channels.audit.dao.AuditDAO#getAuditVO(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public AuditSumTxnVO getAuditVO(AuditSumTxnVO auditSumTxnVO) {
		Criteria criteria = getSession().createCriteria(AuditSumTxnVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.AUD_TXN_ID, auditSumTxnVO.getTxnId()));
		criteria.addOrder(Order.desc(HibernateHelper.AUD_TXN_ID));
		List<AuditSumTxnVO> auditVOList = criteria.list();
		if (!CollectionUtils.isEmpty(auditVOList)) {
			return auditVOList.get(0);
		} else {
			return null;
		}
	}
	
	
	/**
	 * Gets the Audit Txn List.
	 * 
	 * @param auditSumTxnVO
	 *            the audit service vo
	 * @return the audit vo
	 * @see com.scb.channels.audit.dao.AuditServiceDAO#getAuditTxnList(com.scb.channels.base.vo.AuditSumTxnVO)
	 */
	public List<AuditSumTxnVO> getAuditTxnList(AuditSumTxnVO auditSumTxnVO,String fromDate,String toDate) {
		Query query = getSession().createQuery("from AuditServiceVO where dt_audit between '"+fromDate+"' and '"+toDate+"' and custId=:custId ");
		query.setParameter(HibernateHelper.AUD_CUST_ID, auditSumTxnVO.getCustId());
		List<AuditSumTxnVO> auditVOList = query.list();
		return auditVOList;
	}
	
	/**
	 * Save audit.
	 *
	 * @param auditCreditTxVO the audit credit tx vo
	 */
	public void saveCreditAudit(AuditCreditTxVO auditCreditTxVO) {
		LOGGER.info("::::::::::::::::: AuditDAOImpl saveCreditAudit start:::::::::::");	
		getHibernateTemplate().save(auditCreditTxVO);
		LOGGER.info("::::::::::::::::: AuditDAOImpl saveCreditAudit start:::::::::::");	
	}

/**
	 * Save audit.
	 * 
	 * @param qrAuditTxnVO
	 *            the qr audit txn vo
	 * @see com.scb.channels.audit.dao.AuditDAO#saveQrAudit(com.scb.channels.base.vo.QRAuditTxnVO)
	 */
	public void saveQrAudit(QRAuditTxnVO qrAuditTxnVO) {
		getHibernateTemplate().save(qrAuditTxnVO);
	}

	@Override
	public void saveJetcoAudit(JetcoAuditTxn jetcoAuditTxn) {
		getHibernateTemplate().save(jetcoAuditTxn);
	}
}
