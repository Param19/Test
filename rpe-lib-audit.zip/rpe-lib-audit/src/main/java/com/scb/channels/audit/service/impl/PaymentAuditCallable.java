package com.scb.channels.audit.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditCallable;
import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Class AuditCallable.
 */
public class PaymentAuditCallable extends AuditCallable {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentAuditCallable.class);
	
	/** The audit transform request service. */
	private RequestTransformerService<PayloadDTO, AuditSumTxnVO> auditTransformRequestService;


	/**
	 * 
	 * @param bean PayloadDTO
	 * @return
	 */
	public AuditSumTxnVO transform(PayloadDTO bean) {			
			return auditTransformRequestService.tranformRequest(bean);
		
	}
	
	/**
	 * Sets the audit transform request service.
	 *
	 * @param auditTransformRequestService the auditTransformRequestService to set
	 */
	public void setAuditTransformRequestService(
			RequestTransformerService<PayloadDTO, AuditSumTxnVO> auditTransformRequestService) {
		this.auditTransformRequestService = auditTransformRequestService;
	}


}
