package com.scb.channels.audit.dao;

import java.util.List;

import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadHistory;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;



/**
 * The Interface AuditServiceDAO.
 */
public interface AuditServiceDAO {
	
	/**
	 * Save audit.
	 *
	 * @param auditServiceVO the audit service vo
	 */
	void saveAuditService(AuditServiceVO auditServiceVO);
	
	
	/**
	 * Gets the audit vo.
	 *
	 * @param auditServiceVO the audit service vo
	 * @return the AuditServiceVO
	 */
	AuditServiceVO getAuditServiceVO(AuditServiceVO auditServiceVO);
	
	/**
	 * Gets the Audit Service List.
	 *
	 * @param auditServiceVO the audit service vo
	 * @return the AuditServiceVO
	 */
	List<AuditServiceVO> getAuditServiceList(AuditServiceVO auditServiceVO,String fromDate,String toDate);
	
	/**
	 * @param history
	 */
	public void saveDownloadHistory(List<BillerDownloadHistory> history);
	
	BillerDownloadResponseVO archiveAuditService(
			BillerDownloadRequest billerDownloadRequest);

	
}
