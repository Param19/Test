/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;


/**
 * @author 1521723
 *
 */
public class PaymentReqTransformServiceImpl implements RequestTransformerService<PayloadDTO, AuditServiceVO>{

	/**
	 * 
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentReqTransformServiceImpl.class);
	
	/* (non-Javadoc)
	 * @see com.scb.channels.audit.service.RequestTransformerService#tranformRequest(java.lang.Object)
	 */
	public AuditServiceVO tranformRequest(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformRequest PaymentReqTransformServiceImpl ->  Audit Service ");
		if (bean.getRequestVO() instanceof BillerPayRequestVO) {
			BillerPayRequestVO billerPayRequestVO =(BillerPayRequestVO) bean.getRequestVO(); 
			billerPayRequestVO.setCreatedBy("SYSTEM");
			billerPayRequestVO.setDateUpdated(Calendar.getInstance());
			billerPayRequestVO.setDateCreated(Calendar.getInstance());
			AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPaymentReqAuditService(billerPayRequestVO);
			auditServiceVO.setStatusCd("NA"); // For request value is hard coded
				LOGGER.debug("---------After tranformRequest PaymentReqTransformServiceImpl ->  Audit Service "+auditServiceVO);
				return auditServiceVO;
		}
		return null;
	}
	

}
