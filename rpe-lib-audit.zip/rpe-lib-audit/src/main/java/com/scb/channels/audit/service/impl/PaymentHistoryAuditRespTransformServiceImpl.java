/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentHistoryResponseVO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;

/**
 * @author 1470817
 *
 */
public class PaymentHistoryAuditRespTransformServiceImpl implements ResponseTransformerService<PayloadDTO, AuditServiceVO>{

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentHistoryAuditRespTransformServiceImpl.class);
	
	public AuditServiceVO tranformResponse(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformResponse paymentHistoryresponseVo ->  Audit Service ");
		if (bean.getResponseVO() instanceof PaymentHistoryResponseVO) {
			PaymentHistoryResponseVO paymentHistoryResponseVO =(PaymentHistoryResponseVO) bean.getResponseVO(); 
				//paymentHistoryResponseVO.setCreatedBy(CommonHelper.getJVMName());
				paymentHistoryResponseVO.setDateUpdated(Calendar.getInstance());
				paymentHistoryResponseVO.setDateCreated(Calendar.getInstance());
				AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPaymentHistoryRespAuditService(paymentHistoryResponseVO);
				auditServiceVO.setAuditBy(CommonHelper.getJVMName());
				LOGGER.debug("---------After tranformResponse paymentHistoryresponseVo -->  Audit Service "+auditServiceVO);
				return auditServiceVO;
		}
		return null;
	}

}
