package com.scb.channels.audit.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditService;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.JetcoAuditTxn;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.JetcoPayMappingHelper;

/**
 * JetcoAuditTxnProcessor
 * 
 * @author 1552545
 * 
 */
public class JetcoAuditTxnProcessor extends AbstractProcessor {

	private AuditService auditService;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(JetcoAuditTxnProcessor.class);

	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

		LOGGER.info("AUDIT TXN PROCESSOR TO BEGIN");

		JetcoPayRequestVO jetcoPayRequestVO = (JetcoPayRequestVO) bean
				.getRequestVO();

		JetcoAuditTxn jetcoAuditTxn = JetcoPayMappingHelper
				.getJetcoAuditTxn(jetcoPayRequestVO);

		if (jetcoAuditTxn != null) {
			jetcoAuditTxn.setCreatedBy(CommonHelper.getJVMName());
			jetcoAuditTxn.setUpdatedBy(CommonHelper.getJVMName());
			auditService.saveJetcoAudit(jetcoAuditTxn);
		}

		LOGGER.info("AUDIT TXN PROCESSOR TO END");
		return bean;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}

}
