package com.scb.channels.helper;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * The Class LocatorService.
 */
public class AuditLocatorService implements ApplicationContextAware {
	
	/** The context. */
	private static ApplicationContext context;

	/**
	 * Sets the application context.
	 * 
	 * @param context
	 *            the new application context
	 * @throws BeansException
	 *             the beans exception
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		AuditLocatorService.context = context;

	}
	
	/**
	 * Gets the application context.
	 *
	 * @return the application context
	 */
	public static ApplicationContext getApplicationContext(){
		return context;
	}

}
