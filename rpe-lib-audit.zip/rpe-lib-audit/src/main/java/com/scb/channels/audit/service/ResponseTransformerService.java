package com.scb.channels.audit.service;



/**
 * The Interface AuditTransformRequestService.
 */
public interface ResponseTransformerService<S, K> {

	/**
	 * Gets the audit transform request object.
	 *
	 * @param transferRequestVO the transfer request vo
	 * @return the audit transform request object
	 */
	K tranformResponse(S s);
	
	
}
