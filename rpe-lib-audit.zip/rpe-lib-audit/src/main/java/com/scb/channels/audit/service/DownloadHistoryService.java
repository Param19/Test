package com.scb.channels.audit.service;

import java.util.List;

import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadHistory;


/**
 * The Interface AuditService.
 */
public interface DownloadHistoryService {
	
	/**
	 * Save Download  audit.
	 *
	 * @param auditServiceVO the audit service vo
	 */
	void saveDownloadHistory(List<BillerDownloadHistory> history);
	
	 
}	
