package com.scb.channels.audit.service;

import java.util.List;

import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;


/**
 * The Interface AuditService.
 */
public interface AuditServiceService {
	
	/**
	 * Save audit.
	 *
	 * @param auditServiceVO the audit service vo
	 */
	void saveAuditService(AuditServiceVO auditServiceVO);
	
	/**
	 * Gets the audit vo.
	 *
	 * @param auditServiceVO the audit service vo
	 * @return the audit vo
	 */
	AuditServiceVO getAuditServiceVO(AuditServiceVO auditServiceVO);
	
	/**
	 * Gets the Audit Service List.
	 *
	 * @param auditServiceVO the audit service vo
	 * @return the AuditServiceVO
	 */
	List<AuditServiceVO> getAuditServiceList(AuditServiceVO auditServiceVO);
	
	/**
	 * Gets the Archive Audit Service List.
	 *
	 * @param BillerDownloadRequest the Biller download request vo
	 * @return the BillerDownloadResponseVO
	 */
	BillerDownloadResponseVO archiveAuditService(BillerDownloadRequest billerDownloadRequest);

}
