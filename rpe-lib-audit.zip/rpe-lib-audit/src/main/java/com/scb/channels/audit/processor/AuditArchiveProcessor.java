package com.scb.channels.audit.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditServiceService;
import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class ResponseServiceAuditProcessor.
 */
public class AuditArchiveProcessor /*extends AbstractProcessor */{


	/** The audit service. */
	private AuditServiceService auditServiceService;
	
	/** The response transformer service. */
	private ResponseTransformerService<PayloadDTO, AuditServiceVO> responseTransformerService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AuditArchiveProcessor.class);

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	public PayloadDTO process(PayloadDTO bean) throws BusinessException {
		LOGGER.debug("---------Inside AuditArchiveProcessor !!!!!!!!!!!!!!!!!!!! ->  Audit Service ");
		AuditServiceVO auditServiceVO = responseTransformerService.tranformResponse(bean);
		if (auditServiceVO != null) {
			LOGGER.debug("---------Inside AuditArchiveProcessor !!!!!!!!!!!!!!!!!!!! -> inside if condition Audit Service ");
			auditServiceVO.setCreatedBy(CommonHelper.getJVMName());
			auditServiceVO.setAuditBy(CommonHelper.getJVMName());
				auditServiceService.saveAuditService(auditServiceVO);
		}
		LOGGER.debug("---------Inside AuditArchiveProcessor !!!!!!!!!!!!!!!!!!!! ->  End Audit Service ");
		return bean;
	}
	
	public PayloadDTO saveAuditServices(PayloadDTO bean) {
		LOGGER.debug("---------Inside AuditArchiveProcessor !!!!!!!!!!!!!!!!!!!! -> inside if condition Audit Service ");
		
		BillerDownloadRequest billerDownloadRequest = (BillerDownloadRequest)bean.getRequestVO();
		BillerDownloadResponseVO billerDownloadResponseVO = null;
		
		if (billerDownloadRequest != null) {
			
			LOGGER.debug("---------billerDownloadRequest !!!!!!!!!!!!!!!!!!!! -> billerDownloadRequest ");

			billerDownloadResponseVO = auditServiceService.archiveAuditService(billerDownloadRequest);
			bean.setResponseVO(billerDownloadResponseVO);
		}
		LOGGER.debug("---------Inside AuditArchiveProcessor !!!!!!!!!!!!!!!!!!!! ->  End Audit Service ");
		return bean;
		
	}

	/** 
	 * 
	 * @param responseTransformerService
	 */
	public void setResponseTransformerService(
			ResponseTransformerService<PayloadDTO, AuditServiceVO> responseTransformerService) {
		this.responseTransformerService = responseTransformerService;
	}

	/**
	 * 
	 * @param auditServiceService
	 */
	public void setAuditServiceService(AuditServiceService auditServiceService) {
		this.auditServiceService = auditServiceService;
	}
	 
}
