package com.scb.channels.audit.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRAuditTxnVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.mapper.helper.QRPaymentMappingHelper;

public class QRAuditTxnProcessor extends AbstractProcessor {
	
	/** The audit service. */
	private AuditService auditService;

	private static final Logger LOGGER = LoggerFactory.getLogger(QRAuditTxnProcessor.class);
	
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		
		LOGGER.info("AUDIT TXN PROCESSOR TO BEGIN");
		
		QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)bean.getRequestVO();
		
		//QRPaymentResponseVO qrPaymentResponseVO = (QRPaymentResponseVO)bean.getResponseVO();
		
		//QRPaymentDetailVO qRPaymentDetailVO = qrPaymentResponseVO.getQrPaymentDetailVO();
		QRPaymentDetailVO qRPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
		//Call to be made to mapping 
		
		//LOGGER.info("AUDIT TXN PROCESSOR DETAILVO OBJECT::::"+qRPaymentDetailVO.getTxnActStatus());

		//QRAuditTxnVO qrAuditTxn = BillpaymentMappingHelper.getQRAuditVO(qRPaymentDetailVO);
		QRAuditTxnVO qrAuditTxn = QRPaymentMappingHelper.getQRAuditVO(qRPaymentDetailVO);
		
		if (qrAuditTxn != null) {
			if((null == qrAuditTxn.getTxtStatusCd()) || (("").equals(qrAuditTxn.getTxtStatusCd())))
			{
				qrAuditTxn.setTxtStatusCd(CommonConstants.NEW);
			}
			qrAuditTxn.setCreatedBy(CommonHelper.getJVMName());
			qrAuditTxn.setUpdatedBy(CommonHelper.getJVMName());
			auditService.saveQrAudit(qrAuditTxn);
		}
		
		LOGGER.info("AUDIT TXN PROCESSOR TO END");
		return bean;
	}


	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}
	
	
}
