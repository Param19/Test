package com.scb.channels.audit.service;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class AuditCallable.
 *
 * @param <S> the generic type
 */
public abstract class AuditCallable implements Callable<AuditSumTxnVO> {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AuditCallable.class);
	
	/** The audit service. */
	protected AuditService auditService;
	
	/** The bean. */
	protected PayloadDTO bean;

	/**
	 * Call.
	 * 
	 * @return the audit sum txn vo
	 * @throws BusinessException
	 *             the business exception
	 * @see java.util.concurrent.Callable#call()
	 */
	public AuditSumTxnVO call() throws BusinessException {
		AuditSumTxnVO auditSumTxnVO = null;
		try{
			auditSumTxnVO = transform(bean);
			if (auditSumTxnVO != null) {
				auditService.saveAudit(auditSumTxnVO);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new BusinessException(e.getCause());
		}
		return auditSumTxnVO;
	}
	
	
	/**
	 * Transform.
	 *
	 * @param bean the bean
	 * @return the audit sum txn vo
	 */
	public abstract AuditSumTxnVO transform(PayloadDTO bean);
	
	

	/**
	 * Sets the audit service.
	 *
	 * @param auditService the auditService to set
	 */
	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}

	/**
	 * Sets the bean.
	 *
	 * @param bean the bean to set
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;
	}

}
