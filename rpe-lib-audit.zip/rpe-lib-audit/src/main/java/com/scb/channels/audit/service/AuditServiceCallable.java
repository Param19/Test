package com.scb.channels.audit.service;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class AuditCallable.
 *
 * @param <S> the generic type
 */
public abstract class AuditServiceCallable implements Callable<AuditServiceVO> {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AuditServiceCallable.class);
	
	/** The audit service. */
	protected AuditServiceService auditServiceService;
	
	/** The bean. */
	protected PayloadDTO bean;

	/**
	 * Call.
	 * 
	 * @return the audit sum txn vo
	 * @throws BusinessException
	 *             the business exception
	 * @see java.util.concurrent.Callable#call()
	 */
	public AuditServiceVO call() throws BusinessException {
		AuditServiceVO auditServiceVO = null;
		try{
			auditServiceVO = transform(bean);
			if (auditServiceVO != null) {
				auditServiceVO.setCreatedBy(auditServiceVO.getName());
				auditServiceVO.setDtAudit(DateUtils.getCurrentDate());
				auditServiceVO.setDtCreated(auditServiceVO.getDtAudit());
				auditServiceVO.setDtUpd(auditServiceVO.getDtAudit());
				auditServiceService.saveAuditService(auditServiceVO);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new BusinessException(e.getCause());
		}
		return auditServiceVO;
	}
	
	
	/**
	 * Transform.
	 *
	 * @param bean the bean
	 * @return the audit sum txn vo
	 */
	public abstract AuditServiceVO transform(PayloadDTO bean);
	
	

	/**
	 * Sets the bean.
	 *
	 * @param bean the bean to set
	 */
	public void setBean(PayloadDTO bean) {
		this.bean = bean;
	}


	public void setAuditServiceService(AuditServiceService auditServiceService) {
		this.auditServiceService = auditServiceService;
	}

}
