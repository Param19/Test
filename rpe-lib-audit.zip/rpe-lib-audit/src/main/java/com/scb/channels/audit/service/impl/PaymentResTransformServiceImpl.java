/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.ResponseTransformerService;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;


/**
 * @author 1521723
 *
 */
public class PaymentResTransformServiceImpl implements ResponseTransformerService<PayloadDTO, AuditServiceVO>{

	/**
	 * 
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentResTransformServiceImpl.class);
	
	/* (non-Javadoc)
	 * @see com.scb.channels.audit.service.RequestTransformerService#tranformRequest(java.lang.Object)
	 */
	public AuditServiceVO tranformResponse(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformRequest PaymentReqTransformServiceImpl ->  Audit Service ");
		if (bean.getResponseVO() instanceof BillerPayResponseVO) {
			BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			if (billerPayRequestVO.getAuditIdentifier().equalsIgnoreCase(CommonConstants.PAYEE_AUDIT_REQUEST)) {
				BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO) bean.getResponseVO();
				BillerPayRequestVO BillerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			    AuditServiceVO auditServiceVO =new AuditServiceVO();
				auditServiceVO.setCtryCd(BillerPayRequestVO.getClientVO().getCountry());
				auditServiceVO.setChannel(BillerPayRequestVO.getClientVO().getChannel());
				auditServiceVO.setFuncCd(BillerPayRequestVO.getServiceVO().getServiceName());
				auditServiceVO.setCreatedBy(CommonHelper.getJVMName());
				auditServiceVO.setAuditBy(CommonHelper.getJVMName());
				billerPayResponseVO.setDateUpdated(Calendar.getInstance());
				billerPayResponseVO.setDateCreated(Calendar.getInstance());
				auditServiceVO.setUserId(BillerPayRequestVO.getUser().getCustomerId());
				auditServiceVO.setSessionId(BillerPayRequestVO.getMessageVO().getReqID());
				String customVar="NickName:"+BillerPayRequestVO.getBillerPayDetailsVO().getBillerNickName()+
						", BillerId : "+BillerPayRequestVO.getBillerPayDetailsVO().getBillerCd()+
						",ConsurmerNo : "+BillerPayRequestVO.getBillerPayDetailsVO().getConsumerNo()+
						",TxnType : "+BillerPayRequestVO.getServiceVO().getServiceTxnType()+
						",ReferenceNo : "+BillerPayRequestVO.getMessageVO().getReqID();
				if(customVar.length()>245)
				customVar=customVar.substring(0, 245);
				auditServiceVO.setCustomVar04(customVar);
				auditServiceVO.setCustomVar05("PartnerName : "+BillerPayRequestVO.getClientVO().getPartnerName()+
				",PartnerType : "+BillerPayRequestVO.getClientVO().getPartnerType());
				auditServiceVO.setCustId(BillerPayRequestVO.getUser().getCustomerId());
				if(billerPayResponseVO!=null){
					auditServiceVO.setErrorDesc(billerPayResponseVO.getErrorDesc());
					auditServiceVO.setErrorCd(billerPayResponseVO.getErrorCD());
					auditServiceVO.setStatusCd(billerPayResponseVO.getStatus());
				}
				return auditServiceVO;
			} else {
				BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO) bean.getResponseVO();
				BillerPayRequestVO BillerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
				billerPayResponseVO.setClientVO(BillerPayRequestVO.getClientVO());
				billerPayResponseVO.setCreatedBy("SYSTEM");
				billerPayResponseVO.setDateUpdated(Calendar.getInstance());
				billerPayResponseVO.setDateCreated(Calendar.getInstance());
				AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPaymentResAuditService(billerPayResponseVO);
				LOGGER.debug("---------After tranformRequest PaymentReqTransformServiceImpl ->  Audit Service " + auditServiceVO);
				auditServiceVO.setFuncCd(BillerPayRequestVO.getServiceVO().getServiceName());
				auditServiceVO.setSessionId(BillerPayRequestVO.getMessageVO().getReqID());
				return auditServiceVO;
			}
		}
		return null;
	}
	

}
