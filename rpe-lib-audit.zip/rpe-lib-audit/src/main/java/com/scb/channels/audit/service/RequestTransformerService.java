package com.scb.channels.audit.service;



/**
 * The Interface AuditTransformRequestService.
 */
public interface RequestTransformerService<S, K> {

	/**
	 * Gets the audit transform request object.
	 *
	 * @param transferRequestVO the transfer request vo
	 * @return the audit transform request object
	 */
	K tranformRequest(S s);
	
	
}
