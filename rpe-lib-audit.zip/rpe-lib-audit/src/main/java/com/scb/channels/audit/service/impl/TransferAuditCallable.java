package com.scb.channels.audit.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditCallable;
import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransferRequestVO;

/**
 * The Class AuditCallable.
 */
public class TransferAuditCallable extends AuditCallable {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TransferAuditCallable.class);
	
	/** The audit transform request service. */
	private RequestTransformerService<PayloadDTO, AuditSumTxnVO> auditTransformRequestService;


	/**
	 * Transform.
	 *
	 * @param bean PayloadDTO
	 * @return the audit sum txn vo
	 */
	public AuditSumTxnVO transform(PayloadDTO bean) {
		if (bean.getRequestVO() instanceof TransferRequestVO) {
			return auditTransformRequestService.tranformRequest(bean);
		} 
		LOGGER.warn("Invalid request object");
		return null;
	}


	public RequestTransformerService<PayloadDTO, AuditSumTxnVO> getAuditTransformRequestService() {
		return auditTransformRequestService;
	}


	public void setAuditTransformRequestService(
			RequestTransformerService<PayloadDTO, AuditSumTxnVO> auditTransformRequestService) {
		this.auditTransformRequestService = auditTransformRequestService;
	}
	
	

}
