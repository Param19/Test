package com.scb.channels.audit.service.impl;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.scb.channels.audit.dao.AuditServiceDAO;
import com.scb.channels.audit.service.AuditServiceService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;

/**
 * The Class AuditServiceServiceImpl.
 */
public class AuditServiceServiceImpl implements AuditServiceService {

	/** The AuditServiceDAO. */
	private AuditServiceDAO auditServiceDAO;
	private String auditLogDays;
	
	/**
	 * Save audit.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @see com.scb.channels.common.service.AuditService#saveAudit(com.scb.channels.base.vo.AuditServiceVO)
	 */
	public void saveAuditService(AuditServiceVO auditServiceVO) {
		auditServiceDAO.saveAuditService(auditServiceVO);
		
	}
	
	public BillerDownloadResponseVO archiveAuditService(BillerDownloadRequest billerDownloadRequest) {
		return auditServiceDAO.archiveAuditService(billerDownloadRequest);
		
	}
	
	
	/**
	 * Gets the audit vo.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @return the audit vo
	 * @see com.scb.channels.common.service.AuditService#getAuditVO(com.scb.channels.base.vo.AuditServiceVO)
	 */
	public AuditServiceVO getAuditServiceVO(AuditServiceVO auditServiceVO) {
		return auditServiceDAO.getAuditServiceVO(auditServiceVO);
	}
	
	
	/**
	 * Gets the audit service List.
	 * 
	 * @param auditServiceVO
	 *            the audit service vo
	 * @return the audit vo
	 * @see com.scb.channels.common.service.AuditService#getAuditVO(com.scb.channels.base.vo.AuditServiceVO)
	 */
	public List<AuditServiceVO> getAuditServiceList(AuditServiceVO auditServiceVO) {
		
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		String toDate = dateFormat.format(date);
        Calendar cal = Calendar.getInstance();
        int auditLogDay = Integer.parseInt(auditLogDays);
        System.out.println("auditLogDayss :: "+auditLogDay);
        cal.add(Calendar.DATE, -auditLogDay);
        Date fromDate1 = cal.getTime();
        String fromDate = dateFormat.format(fromDate1.getTime());
        System.out.println("FromDate :: "+fromDate+"  To Date :: "+toDate);
		return auditServiceDAO.getAuditServiceList(auditServiceVO,fromDate,toDate);
	}
	
	

	public AuditServiceDAO getAuditServiceDAO() {
		return auditServiceDAO;
	}

	public void setAuditServiceDAO(AuditServiceDAO auditServiceDAO) {
		this.auditServiceDAO = auditServiceDAO;
	}


	public String getAuditLogDays() {
		return auditLogDays;
	}


	public void setAuditLogDays(String auditLogDays) {
		this.auditLogDays = auditLogDays;
	}



}
