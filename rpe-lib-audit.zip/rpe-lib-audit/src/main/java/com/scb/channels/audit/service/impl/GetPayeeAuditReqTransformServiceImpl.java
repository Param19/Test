/**
 * 
 */
package com.scb.channels.audit.service.impl;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;


/**
 * @author 1521723
 *
 */
public class GetPayeeAuditReqTransformServiceImpl implements RequestTransformerService<PayloadDTO, AuditServiceVO>{

	/**
	 * 
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(GetPayeeAuditReqTransformServiceImpl.class);
	
	/* (non-Javadoc)
	 * @see com.scb.channels.audit.service.RequestTransformerService#tranformRequest(java.lang.Object)
	 */
	public AuditServiceVO tranformRequest(PayloadDTO bean) {
		LOGGER.debug("---------Inside tranformRequest GetPayeeAuditReqTransformServiceImpl ->  Audit Service ");
		if (bean.getRequestVO() instanceof ViewPayeeRequestVO) {
			ViewPayeeRequestVO viewPayeeRequestVO =(ViewPayeeRequestVO) bean.getRequestVO(); 
			viewPayeeRequestVO.setCreatedBy("SYSTEM");
			viewPayeeRequestVO.setDateUpdated(Calendar.getInstance());
			viewPayeeRequestVO.setDateCreated(Calendar.getInstance());
				AuditServiceVO auditServiceVO = BillpaymentMappingHelper.getPayeeReqAuditService(viewPayeeRequestVO);
				auditServiceVO.setStatusCd("NA");
				LOGGER.debug("---------After tranformRequest GetPayeeAuditReqTransformServiceImpl ->  Audit Service "+auditServiceVO);
				return auditServiceVO;
		}
		return null;
	}
	

}
