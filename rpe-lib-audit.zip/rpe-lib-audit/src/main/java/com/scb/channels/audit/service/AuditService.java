package com.scb.channels.audit.service;

import java.util.List;

import com.scb.channels.base.vo.AuditCreditTxVO;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.JetcoAuditTxn;
import com.scb.channels.base.vo.QRAuditTxnVO;


/**
 * The Interface AuditService.
 */
public interface AuditService {
	
	/**
	 * Save audit.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 */
	void saveAudit(AuditSumTxnVO auditSumTxnVO);
	
	/**
	 * Update transaction status.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 */
	void updateTransactionStatus(AuditSumTxnVO auditSumTxnVO);
	
	/**
	 * Gets the audit vo.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 * @return the audit vo
	 */
	AuditSumTxnVO getAuditVO(AuditSumTxnVO auditSumTxnVO);
	
	
	/**
	 * Gets the audit txn vo list.
	 *
	 * @param auditSumTxnVO the audit sum txn vo
	 * @return the audit vo list
	 */
	List<AuditSumTxnVO> getAuditTxnList(AuditSumTxnVO auditSumTxnVO);
	/**
	 * Save credit audit.
	 *
	 * @param auditCreditTxVO the audit credit tx vo
	 */
	void saveCreditAudit(AuditCreditTxVO auditCreditTxVO);
	
		/**
	 * Save QR audit.
	 *
	 * @param qrAuditTxnVO the qr audit txn vo
	 */
	void saveQrAudit(QRAuditTxnVO qrAuditTxnVO);

	/**
	 * save jetco payment audit
	 * 
	 * @param jetcoAuditTxn
	 */
	void saveJetcoAudit(JetcoAuditTxn jetcoAuditTxn);

}
