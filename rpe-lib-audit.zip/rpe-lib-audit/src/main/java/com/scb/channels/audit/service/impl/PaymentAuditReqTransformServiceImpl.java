package com.scb.channels.audit.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AuditSumTxnVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;

/**
 * The Class AuditTransformRequestServiceImpl.
 */
public class PaymentAuditReqTransformServiceImpl implements RequestTransformerService<PayloadDTO, AuditSumTxnVO> {
	

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentAuditReqTransformServiceImpl.class);
	/**
	 * Gets the audit transform request object.
	 * 
	 * @param billerPayRequestVO
	 *            the biller pay request vo
	 * @return the audit transform request object
	 * @see com.scb.channels.common.service.RequestTransformerService#tranformRequest(com.scb.channels.common.vo.BillerPayRequestVO)
	 */
	public AuditSumTxnVO tranformRequest(PayloadDTO bean) {
		BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO) bean.getResponseVO();
		AuditSumTxnVO  auditSumTxnVO =   BillpaymentMappingHelper.auditTransformRequestObject((BillerPayRequestVO) bean.getRequestVO()); 
		LOGGER.debug("PaymentAuditReqTransformServiceImpl-Txn Id :"+auditSumTxnVO.getTxnId()+" Status"+billerPayResponseVO.getStatus()+" TxnStatusCd :"+auditSumTxnVO.getTxtStatusCd());
		auditSumTxnVO.setDateUpd(DateUtils.getCurrentDate());
		auditSumTxnVO.setStatusCd(billerPayResponseVO.getStatus());
		 return auditSumTxnVO;
		
	}

	

}
