package com.scb.channels.audit.processor;


import com.scb.channels.audit.service.AuditServiceService;
import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;

/**
 * The Class TxnUpdateAuditProcessor.
 */
public class LoginRequestAuditProcessor extends AbstractProcessor {


	/** The audit service. */
	private AuditServiceService auditServiceService;
	
	/** The audit login request transformer service. */
	private RequestTransformerService<PayloadDTO, AuditServiceVO> auditLoginRequestTransformerService;
	

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		AuditServiceVO auditServiceVO = auditLoginRequestTransformerService.tranformRequest(bean);
		if (auditServiceVO != null) {
			auditServiceVO.setDtAudit(DateUtils.getCurrentDate());
			auditServiceVO.setDtCreated(auditServiceVO.getDtAudit());
			auditServiceVO.setDtUpd(auditServiceVO.getDtAudit());
			auditServiceService.saveAuditService(auditServiceVO);
		}
		return bean;
	}


	/**
	 * Gets the audit service service.
	 *
	 * @return the audit service service
	 */
	public AuditServiceService getAuditServiceService() {
		return auditServiceService;
	}


	/**
	 * Sets the audit service service.
	 *
	 * @param auditServiceService the new audit service service
	 */
	public void setAuditServiceService(AuditServiceService auditServiceService) {
		this.auditServiceService = auditServiceService;
	}



	/**
	 * Sets the audit login request transformer service.
	 *
	 * @param auditLoginRequestTransformerService the audit login request transformer service
	 */
	public void setAuditLoginRequestTransformerService(
			RequestTransformerService<PayloadDTO, AuditServiceVO> auditLoginRequestTransformerService) {
		this.auditLoginRequestTransformerService = auditLoginRequestTransformerService;
	}

}
