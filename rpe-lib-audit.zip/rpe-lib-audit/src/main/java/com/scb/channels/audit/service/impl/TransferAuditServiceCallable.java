package com.scb.channels.audit.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.audit.service.AuditServiceCallable;
import com.scb.channels.audit.service.RequestTransformerService;
import com.scb.channels.base.vo.AuditServiceVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransferRequestVO;

/**
 * The Class AuditCallable.
 */
public class TransferAuditServiceCallable extends AuditServiceCallable {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(TransferAuditServiceCallable.class);
	
	/** The audit transform request service. */
	private RequestTransformerService<TransferRequestVO, AuditServiceVO> auditTransformRequestService;


	/**
	 * Transform.
	 *
	 * @param bean PayloadDTO
	 * @return the audit sum txn vo
	 */
	public AuditServiceVO transform(PayloadDTO bean) {
		if (bean.getRequestVO() instanceof TransferRequestVO) {
			TransferRequestVO transferRequestVO =(TransferRequestVO)bean.getRequestVO(); 
			return auditTransformRequestService.tranformRequest(transferRequestVO);
		} 
		LOGGER.warn("Invalid request object");
		return null;
	}
	
	
	/**
	 * Sets the audit transform request service.
	 *
	 * @param auditTransformRequestService the audit transform request service
	 */
	public void setAuditTransformRequestService(
			RequestTransformerService<TransferRequestVO, AuditServiceVO> auditTransformRequestService) {
		this.auditTransformRequestService = auditTransformRequestService;
	}

}
