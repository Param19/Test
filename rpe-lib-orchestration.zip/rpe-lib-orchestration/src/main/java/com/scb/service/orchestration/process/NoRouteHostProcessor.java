package com.scb.service.orchestration.process;

import org.apache.camel.CamelException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.PayloadDTO;

/**
 * The Class NoRouteHostProcessor.
 */
public class NoRouteHostProcessor implements Processor {

	/* (non-Javadoc)
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	public void process(Exchange exchange) throws CamelException {
		PayloadDTO bean = exchange.getIn().getBody(PayloadDTO.class);
		if (bean == null ){
			bean = new PayloadDTO();
		}
		if (bean.getResponseVO()!=null) {
			bean.getResponseVO().setStatus(ExceptionMessages._145.getCode());
			bean.getResponseVO().setStatusDesc(ExceptionMessages._145.getMessage());
		} else {
			BaseVO response = new BaseVO();
			response.setStatus(ExceptionMessages._145.getCode());
			response.setStatusDesc(ExceptionMessages._145.getMessage());
			bean.setResponseVO(response);
		}
		exchange.getOut().setBody(bean);
	}

}
