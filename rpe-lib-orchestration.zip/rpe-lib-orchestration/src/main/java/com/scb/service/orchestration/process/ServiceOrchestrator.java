package com.scb.service.orchestration.process;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.camel.CamelException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.srm.orchestration.dao.OrchestrationDao;
import com.scb.srm.orchestration.vo.ServiceOrchestrationVo;

/**
 * The Class ServiceOrchestrator.
 */
public class ServiceOrchestrator implements Processor {

	public static final String NOROUTE = "direct:noroute";
	public static final String TRUE = "true";
	public static final String SERVICE_INVOKED = "SERVICE_INVOKED";
	public static final String ROUTENAME = "routename";
	private static final String EQUALS = "=";
	private static final String SEMICOLON = ";";
	public static final String SERVICE_NAME = "serviceName";
	public static final String MODULE_TYPE = "moduleType";
	public static final String CTRY_CD = "country";
	/** The orches dao. */
	private OrchestrationDao orchesDao;
	
	/** The cache manager. */
	private CacheManager cacheManager;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceOrchestrator.class);
	

	/**
	 * Execute pattern.
	 *
	 * @param routename the routename
	 * @param properties the properties
	 * @return the string
	 */
	public String executePattern(String routename, Map<String, String> properties) {
		
		if(isInvoked(properties)){
			return null;
		}
		else{
			markInvoked(properties);
			return routename;
		}
		
	}
	
	/**
	 * Mark invoked.
	 *
	 * @param properties the properties
	 */
	private void markInvoked(Map<String, String> properties) {
		properties.put(SERVICE_INVOKED, TRUE);
	}

	/**
	 * Checks if is invoked.
	 *
	 * @param properties the properties
	 * @return true, if is invoked
	 */
	private boolean isInvoked(Map<String, String> properties) {
		return Boolean.valueOf((String)properties.get(SERVICE_INVOKED));
	}

	

	

	/* (non-Javadoc)
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	public void process(Exchange exchange) {
		Map<String, String> properties =new HashMap<String, String>();
		try {
			String routename=null;
			properties = extractContext(exchange, properties);
			LOGGER.info("properties ::: {}", properties);
			routename = getRouteName(properties,exchange);
			LOGGER.info("Route name ::: {}", routename);
			exchange.getOut().setHeader(ROUTENAME,this.executePattern(routename, properties));
			exchange.getOut().setBody(exchange.getIn().getBody());
		} catch (Exception exception) {
			LOGGER.error("::: Exception occurred in Orchestrator ::: ");
			LOGGER.error(exception.getMessage());
			exchange.getOut().setHeader(ROUTENAME,this.executePattern(NOROUTE, properties));
		}
	}

	

	/**
	 * Extract context.
	 *
	 * @param exchange the exchange
	 * @param properties the properties
	 * @return the map
	 */
	private Map<String, String> extractContext(Exchange exchange,Map<String,String>properties) {
		if(null != MDC.getCopyOfContextMap()) {
			properties.putAll(MDC.getCopyOfContextMap());
		}
		properties.put(MODULE_TYPE,(String) exchange.getIn().getHeader(MODULE_TYPE));
		return properties;
	}

	

	/**
	 * Convertto map.
	 *
	 * @param properties the properties
	 * @param context the context
	 * @return the map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, String> converttoMap(Map<String, String> properties,
			Object context) {
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> objectAsMap = objectMapper.convertValue(context, Map.class);
		
		return objectAsMap;
	}
	
	/**
	 * Gets the route name.
	 *
	 * @param properties the properties
	 * @param exchange the exchange
	 * @return the route name
	 * @throws  
	 */
	private String getRouteName(Map<String, String> properties,Exchange exchange) throws Exception  {
		
		String routename=NOROUTE;
		String parameters=null;
		
		String country = properties.get(CTRY_CD);
		String module = properties.get(MODULE_TYPE);
		String service = properties.get(SERVICE_NAME);
		LOGGER.debug("Fetching orchestration service for {}-{}-{}", new Object[] {country, module, service});

		List<ServiceOrchestrationVo>  orchRouteList =null;
		if(cacheManager.getCache(CommonConstants.MY_CACHE).get(country+module+service) == null){
			LOGGER.debug("Calling DB orchestration service for {}-{}-{}", new Object[] {country, module, service});
			orchRouteList = orchesDao.fetchOrcheatrationRoute(country, module, service);
			cacheManager.getCache(CommonConstants.MY_CACHE).put(new Element(country+module+service , orchRouteList));
			LOGGER.debug("Getting from DB orchestration service for {}-{}-{}", new Object[] {country, module, service});
		} else {
			orchRouteList = (List<ServiceOrchestrationVo>) cacheManager.getCache(CommonConstants.MY_CACHE).get(country+module+service).getValue();
			LOGGER.debug("Getting from cache orchestration service for {}-{}-{}", new Object[] {country, module, service});
		}
		
		LOGGER.debug("Size fetched orchestration service {}-{}-{}-{}", new Object[] { country, module, service,
				CollectionUtils.isEmpty(orchRouteList) ? 0 : orchRouteList.size()});
		
		for (ServiceOrchestrationVo orchestrationVo : orchRouteList) {
			routename = (String) orchestrationVo.getRouteName();
			parameters = (String) orchestrationVo.getParameters();
			if (StringUtils.isNotEmpty(parameters)) {
				String[] param = parameters.split(SEMICOLON);
				PayloadDTO bean = exchange.getIn().getBody(PayloadDTO.class);
				boolean foundKey = true;
				for (String i : param) {
					String[] paramsplit = i.split(EQUALS);
					String field = null;
					try {
						Object value = PropertyUtils.getProperty(bean, paramsplit[0]);
						String valueStr = String.valueOf(value);
						if (valueStr.contains(CommonConstants.COMMA)) {
							String[] values = valueStr.split(CommonConstants.COMMA);
							if (!ArrayUtils.contains(values, paramsplit[1])){
								foundKey = false;
								break;
							}
						} else {
							if (!paramsplit[1].equals(valueStr)) {
								foundKey = false;
								break;
							}
						}
					} catch (Exception e) {
						LOGGER.error(field, e.getMessage());
					} 
				}
				if (foundKey) {
					LOGGER.info("Route found for service {}-{}-{}-{}", new Object[] { country, module, service, routename});
					return routename;
				}else{
					routename=NOROUTE;
				}
			} else {
				LOGGER.info("Route found for service {}-{}-{}", new Object[] { country, module, service, routename});
				return routename;
			}
		}
		LOGGER.info("No Route found for service {}-{}-{}", new Object[] { country, module, service, NOROUTE});
		return routename;
		
	}
	
	/**
	 * Gets the orches dao.
	 *
	 * @return the orches dao
	 */
	public OrchestrationDao getOrchesDao() {
		return orchesDao;
	}

	/**
	 * Sets the orches dao.
	 *
	 * @param orchesDao the new orches dao
	 */
	public void setOrchesDao(OrchestrationDao orchesDao) {
		this.orchesDao = orchesDao;
	}

	/**
	 * @return the cacheManager
	 */
	public CacheManager getCacheManager() {
		return cacheManager;
	}

	/**
	 * @param cacheManager the cacheManager to set
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}
}
