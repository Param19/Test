package com.scb.srm.orchestration.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.exception.DAOException;
import com.scb.srm.orchestration.dao.OrchestrationDao;
import com.scb.srm.orchestration.vo.ServiceOrchestrationVo;

public class OrchestrationDaoImpl extends HibernateDaoSupport implements OrchestrationDao {

	/* (non-Javadoc)
	 * @see com.scb.srm.orchestration.dao.impl.OrchestrationDao#fetchOrcheatrationRoute(java.lang.String, java.lang.String, java.lang.String)
	 */
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(OrchestrationDaoImpl.class);
	
	@SuppressWarnings("rawtypes")
	public List<ServiceOrchestrationVo> fetchOrcheatrationRoute(String country, String module, String operation) throws DAOException {
		LOGGER.debug("Call to get Service name..");
		List<ServiceOrchestrationVo> orchestrationRouteList=null;
		Session session=null;
		try{
		session=getSession();
		Criteria criteria = session.createCriteria(ServiceOrchestrationVo.class)
				.add(Restrictions.eq("countryCode", country))
				.add(Restrictions.eq("moduleType", module))
				.add(Restrictions.eq("operationName", operation))
				.addOrder(Order.asc("executionOrder"));
		
		orchestrationRouteList = criteria.list();
		if(orchestrationRouteList!=null)
			LOGGER.debug("orchestrationRouteList - Size "+orchestrationRouteList.size());
		LOGGER.debug("orchestrationRouteList  done..");
		}catch(Exception e){
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			throw new DAOException(e.getMessage());
		}
		finally{
			releaseSession(session);
		}
		return orchestrationRouteList;
	}

	
}
