package com.scb.srm.orchestration.dao;

import java.util.List;

import com.scb.channels.base.exception.DAOException;
import com.scb.srm.orchestration.vo.ServiceOrchestrationVo;

public interface OrchestrationDao {

	List<ServiceOrchestrationVo> fetchOrcheatrationRoute(String country, String module,
			String operation) throws DAOException;

}