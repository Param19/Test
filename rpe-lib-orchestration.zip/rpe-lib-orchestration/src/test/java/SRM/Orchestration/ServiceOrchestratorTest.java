package SRM.Orchestration;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.srm.orchestration.dao.OrchestrationDao;

public class ServiceOrchestratorTest {
	private static ApplicationContext context = null;
	@Test
	public void test() {
		OrchestrationDao orchestrationDao = context.getBean("orchestrationDao",OrchestrationDao.class);
		try {
			orchestrationDao.fetchOrcheatrationRoute("NG", "payment", "BillerCategory");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		@Before
		public void setUp() throws Exception {
			if (context == null) {
				context = new ClassPathXmlApplicationContext("/spring/orchestration-dao-context.xml");
			}			
			
		}
	}


