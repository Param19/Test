package com.scb.service.orchestration.process;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.scb.srm.orchestration.dao.OrchestrationDao;
import com.scb.srm.orchestration.vo.ServiceOrchestrationVo;

/**
 * @author 1305778
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/resources/srm-orchestration-context.xml" })
public class ServiceOrchestrationTest {
	@Resource(name = "srmOrchestrator")
	private ServiceOrchestrator Orchestrator;
	private OrchestrationDao orchestrationDao;

	@Before
	public void setup() {
		orchestrationDao = Mockito.mock(OrchestrationDao.class);
		Orchestrator.setOrchesDao(orchestrationDao);

	}

	@Test
	public void testAccountOpenPositive() throws Exception {

		CamelContext ctx = new DefaultCamelContext();
		Exchange exchange = new DefaultExchange(ctx);

		when(
				orchestrationDao.fetchOrcheatrationRoute("NG", "account",
						"accopen")).thenReturn(
				createrespList("opertationType=accopen;operation=accopen",
						"direct-vm:AccountOpen"));
		exchange = requestformater(exchange, "accopen", "accopen");

		Orchestrator.process(exchange);

		Assert.assertNotNull(exchange);
		Assert.assertEquals("direct-vm:AccountOpen", exchange.getOut()
				.getHeader("routename"));

	}

	@Test
	public void testAccountOpenNegative() throws Exception {

		CamelContext ctx = new DefaultCamelContext();
		Exchange exchange = new DefaultExchange(ctx);

		when(
				orchestrationDao.fetchOrcheatrationRoute("NG", "account",
						"accopenvalidation")).thenReturn(new ArrayList());

		exchange = requestformater(exchange, "accopenvalidation",
				"accopenvalidation");

		Orchestrator.process(exchange);

		Assert.assertNotNull(exchange);
		Assert.assertNotSame("direct-vm:AccountOpen", exchange.getOut()
				.getHeader("routename"));

	}

	@Test
	public void testOutPutNull() throws Exception {

		CamelContext ctx = new DefaultCamelContext();
		Exchange exchange = new DefaultExchange(ctx);

		when(
				orchestrationDao.fetchOrcheatrationRoute("NG", "account",
						"accopenvalidation")).thenReturn(new ArrayList());

		exchange = requestformater(exchange, "null", "accopen");

		Orchestrator.process(exchange);
		Assert.assertNotNull(exchange);
		Assert.assertNull(exchange.getOut().getBody());
		Assert.assertEquals(null, exchange.getOut().getHeader("routename"));

	}

	@Test
	public void testAccountValidationPositive() throws Exception {

		CamelContext ctx = new DefaultCamelContext();
		Exchange exchange = new DefaultExchange(ctx);

		when(
				orchestrationDao.fetchOrcheatrationRoute("NG", "account",
						"accopenvalidation"))
				.thenReturn(
						createrespList(
								"opertationType=accopenvalidation;operation=accopenvalidation",
								"direct-vm:AccountValidation"));
		exchange = requestformater(exchange, "accopenvalidation",
				"accopenvalidation");

		Orchestrator.process(exchange);
		Assert.assertNotNull(exchange);
		Assert.assertNull(exchange.getOut().getBody());
		Assert.assertEquals("direct-vm:AccountValidation", exchange.getOut()
				.getHeader("routename"));

	}

	private Exchange requestformater(Exchange exchange, String operation,
			String operationtype) {
		exchange.getIn().setHeader("moduleType", "account");
		return exchange;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List createrespList(String parameters, String routeName) {
		ServiceOrchestrationVo orchestrationVo = new ServiceOrchestrationVo();
		orchestrationVo.setCountryCode("NG");
		orchestrationVo.setParameters(parameters);
		orchestrationVo.setRouteName(routeName);
		List orchestration = new ArrayList();
		orchestration.add(orchestrationVo);

		return orchestration;
	}
}
