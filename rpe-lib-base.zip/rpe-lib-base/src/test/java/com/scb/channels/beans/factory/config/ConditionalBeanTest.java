package com.scb.channels.beans.factory.config;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.common.helper.TestHelper;

public class ConditionalBeanTest {

	private ApplicationContext context = null;

	@Before
	public void setUp() throws Exception {
		context = new ClassPathXmlApplicationContext("test-context.xml");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSetLocationsResourceArray() {
		assertNotNull(context);
	}

	

}
