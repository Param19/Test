package com.scb.channels.beans.factory.config;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.common.helper.TestHelper;

public class PropertiesHolderTest {

	private ApplicationContext context = null;

	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSetLocationsResourceArray() {
		assertNotNull(context);
	}

	@Test
	public void testSetLocationsResourceArray2() {
		Object o = context.getBean("velocityEngine");
		assertNotNull(o);
		
	}

}
