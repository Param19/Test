/*
 * 
 */
package com.scb.channels.common.helper;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

public class MultiCountryDBTest {

	private ApplicationContext context = null;
	
	@Before
	public void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}
	
	@Test
	public void test() throws SQLException {
		DataSource dataSource = (DataSource) context.getBean("dataSource");
		assertNotNull(dataSource);
		assertNotNull(dataSource.getConnection());
	}

}
