package com.scb.channels.common.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.common.util.Base64Utility;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ApplicationContext;
import com.scb.channels.base.helper.CommonMaskEncoder;
import com.scb.channels.base.helper.Masker;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;

public class LoggerTest {
	
	private static final Logger logger = LoggerFactory.getLogger(LoggerTest.class);
	
	@Test
	public void tTest(){
		System.out.println(Base64Utility.encode("000002002:ibnk1357".getBytes()));
	}
	
	 
	@Test
	public void loggerTest() {
		UserVO vo= new UserVO();
		vo.setChannelId("IBNK");
		vo.setCountry("KE");
		vo.setPassword("123456");
		ClientVO cV= new ClientVO();
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("Login");
		Map<String, List<Masker>> map = new HashMap<String, List<Masker>>();
		List<Masker> value = new ArrayList<Masker>();
		Masker m = new Masker("(mPin:|password)([^<]*)",2, "ER1,*");
		value.add(m);
		map.put("KE-Login", value);
		
		CommonMaskEncoder.maskerMaster.putAll(map);
		ApplicationContext.initializeContext(vo, cV, serviceVO);
		
		logger.debug("mPin:"+vo.getPassword());
		logger.debug("password"+vo.getPassword());
		logger.debug("password"+vo.getPassword());
		
		/*logger.debug(ApplicationContext.getContext().getChannelId());
		logger.debug(ApplicationContext.getContext().getCountry());
		logger.info(ApplicationContext.getContext().getChannelId());
		logger.info(ApplicationContext.getContext().getCountry());
		logger.warn(ApplicationContext.getContext().getChannelId());
		logger.warn(ApplicationContext.getContext().getCountry());
		logger.error(ApplicationContext.getContext().getChannelId());
		logger.error(ApplicationContext.getContext().getCountry());
		vo= new UserVO();
		vo.setChannelId("ADC");
		vo.setCountry("KE");
		ApplicationContext.initializeContext(vo, cV, serviceVO);
		logger.debug(ApplicationContext.getContext().getChannelId());
		logger.debug(ApplicationContext.getContext().getCountry());
		logger.info(ApplicationContext.getContext().getChannelId());
		logger.info(ApplicationContext.getContext().getCountry());
		logger.warn(ApplicationContext.getContext().getChannelId());
		logger.warn(ApplicationContext.getContext().getCountry());
		logger.error(ApplicationContext.getContext().getChannelId());
		logger.error(ApplicationContext.getContext().getCountry());
		vo= new UserVO();
		vo.setChannelId("ADC");
		vo.setCountry("KE");
		ApplicationContext.initializeContext(vo, cV, serviceVO);
		logger.debug(ApplicationContext.getContext().getChannelId());
		logger.debug(ApplicationContext.getContext().getCountry());
		logger.info(ApplicationContext.getContext().getChannelId());
		logger.info(ApplicationContext.getContext().getCountry());
		logger.warn(ApplicationContext.getContext().getChannelId());
		logger.warn(ApplicationContext.getContext().getCountry());
		logger.error(ApplicationContext.getContext().getChannelId());
		logger.error(ApplicationContext.getContext().getCountry());*/
	}

}
