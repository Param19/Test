/**
 * 
 */
package com.scb.channels.common.helper;

/**
 * @author 1411807
 *
 */
public class Test1 {

	public Test1() {
		System.out.println("Test1");
	}
}
