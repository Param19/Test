/**
 * 
 */
package com.scb.channels.common.helper;

/**
 * @author 1411807
 *
 */
public class Test2 {

	public Test2() {
		System.out.println("Test2");
	}
}
