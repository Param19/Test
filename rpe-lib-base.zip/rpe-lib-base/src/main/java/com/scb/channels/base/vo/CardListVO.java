package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class CardListVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4644279111474000645L;
	
	private String number;
    private String name;
    private String status;
    private String type;
    private String accountCurrencyCode;
    private String accountNumber;
    private Calendar expiryDate;
    private String customerIdentificationNumber;
	
    
    public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAccountCurrencyCode() {
		return accountCurrencyCode;
	}
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Calendar getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Calendar expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getCustomerIdentificationNumber() {
		return customerIdentificationNumber;
	}
	public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
		this.customerIdentificationNumber = customerIdentificationNumber;
	}

}
