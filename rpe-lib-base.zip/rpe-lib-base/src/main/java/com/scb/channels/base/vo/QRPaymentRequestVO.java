package com.scb.channels.base.vo;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class QRPaymentRequestVO.
 */
public class QRPaymentRequestVO extends BaseVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2377063438723121783L;
	
	/** The qr payment detail vo. */
	private QRPaymentDetailVO qrPaymentDetailVO;

	/**
	 * Gets the qr payment detail vo.
	 *
	 * @return the qr payment detail vo
	 */
	public QRPaymentDetailVO getQrPaymentDetailVO() {
		return qrPaymentDetailVO;
	}

	/**
	 * Sets the qr payment detail vo.
	 *
	 * @param qrPaymentDetailVO the new qr payment detail vo
	 */
	public void setQrPaymentDetailVO(QRPaymentDetailVO qrPaymentDetailVO) {
		this.qrPaymentDetailVO = qrPaymentDetailVO;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "QRPaymentRequestVO [qrPaymentDetailVO=" + qrPaymentDetailVO
				+ "]";
	}
	
	
}
