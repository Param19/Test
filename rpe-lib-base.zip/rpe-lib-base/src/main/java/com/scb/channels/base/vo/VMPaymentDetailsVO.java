package com.scb.channels.base.vo;

import java.io.Serializable;


public class VMPaymentDetailsVO extends PaymentDetailVO implements Serializable{

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String  operationMode;
	 private String  blockNumber;
	 private String	 blockSetDate;
	 private String  blockType;
	 private String  blockRelease;
	 private String  blockAmount;
	 private String  accountChargeCode;
	 private String  actualDebitAmount;
	 private String  debitAmountReleasedFromBlock;
	 private String	  accountBlockExpiryDate;
	 private String  blockAmountInstructionNumber;
	 private String  limitMasterNumber;
	 private String  limitNumber;
	 private String  accountLimitBlockIndicator;
	 private String  deleteBlockOnExpiry;
	 private String	  blockEffectiveExecutionDate;
	 private String    blockBatchEntryDate;
	 private String  blockBatchNumber;
	 private String  blockEntryChannelNumber;
	 private String  blockEntryTransactionBranch;
	 private String  blockStatusFlag;
	 private String  sweepBlockReferenceNumber;
	 private String  blockAmountPendingForRelease;
	 private String  creditTransactionCode;
	 private String  debitTransactionCode;
	 private String  productCode;
	 private String  blockPartialFlag;
	 private String  externalSystemID;
	 private String  externalSystemReferenceNumber;
	 private String  blockActionOnExpiryFlag;
	 private String  creditNarrative1;
	 private String  creditNarrative2;
	 private String  creditNarrative3;
	 private String  creditNarrative4;
	 private String  creditNarrative6;
	 private String  debitNarrative1;
	 private String  debitNarrative2;
	 private String  debitNarrative3;
	 private String  debitNarrative4;
	 private String  debitNarrative5;
	 private String  debitNarrative6;
	 private String  creditAccount;
	 private String  debitAccount;
	 private String  responseCode;
	 private String  responseDesc;
	 private PayeeVO payeeVO;
	public String getOperationMode() {
		return operationMode;
	}
	public void setOperationMode(String operationMode) {
		this.operationMode = operationMode;
	}
	public String getBlockNumber() {
		return blockNumber;
	}
	public void setBlockNumber(String blockNumber) {
		this.blockNumber = blockNumber;
	}
	public String getBlockSetDate() {
		return blockSetDate;
	}
	public void setBlockSetDate(String blockSetDate) {
		this.blockSetDate = blockSetDate;
	}
	public String getBlockType() {
		return blockType;
	}
	public void setBlockType(String blockType) {
		this.blockType = blockType;
	}
	public String getBlockRelease() {
		return blockRelease;
	}
	public void setBlockRelease(String blockRelease) {
		this.blockRelease = blockRelease;
	}
	public String getBlockAmount() {
		return blockAmount;
	}
	public void setBlockAmount(String blockAmount) {
		this.blockAmount = blockAmount;
	}
	public String getAccountChargeCode() {
		return accountChargeCode;
	}
	public void setAccountChargeCode(String accountChargeCode) {
		this.accountChargeCode = accountChargeCode;
	}
	public String getActualDebitAmount() {
		return actualDebitAmount;
	}
	public void setActualDebitAmount(String actualDebitAmount) {
		this.actualDebitAmount = actualDebitAmount;
	}
	public String getDebitAmountReleasedFromBlock() {
		return debitAmountReleasedFromBlock;
	}
	public void setDebitAmountReleasedFromBlock(String debitAmountReleasedFromBlock) {
		this.debitAmountReleasedFromBlock = debitAmountReleasedFromBlock;
	}
	public String getAccountBlockExpiryDate() {
		return accountBlockExpiryDate;
	}
	public void setAccountBlockExpiryDate(String accountBlockExpiryDate) {
		this.accountBlockExpiryDate = accountBlockExpiryDate;
	}
	public String getBlockAmountInstructionNumber() {
		return blockAmountInstructionNumber;
	}
	public void setBlockAmountInstructionNumber(String blockAmountInstructionNumber) {
		this.blockAmountInstructionNumber = blockAmountInstructionNumber;
	}
	public String getLimitMasterNumber() {
		return limitMasterNumber;
	}
	public void setLimitMasterNumber(String limitMasterNumber) {
		this.limitMasterNumber = limitMasterNumber;
	}
	public String getLimitNumber() {
		return limitNumber;
	}
	public void setLimitNumber(String limitNumber) {
		this.limitNumber = limitNumber;
	}
	public String getAccountLimitBlockIndicator() {
		return accountLimitBlockIndicator;
	}
	public void setAccountLimitBlockIndicator(String accountLimitBlockIndicator) {
		this.accountLimitBlockIndicator = accountLimitBlockIndicator;
	}
	public String getDeleteBlockOnExpiry() {
		return deleteBlockOnExpiry;
	}
	public void setDeleteBlockOnExpiry(String deleteBlockOnExpiry) {
		this.deleteBlockOnExpiry = deleteBlockOnExpiry;
	}
	public String getBlockEffectiveExecutionDate() {
		return blockEffectiveExecutionDate;
	}
	public void setBlockEffectiveExecutionDate(String blockEffectiveExecutionDate) {
		this.blockEffectiveExecutionDate = blockEffectiveExecutionDate;
	}
	public String getBlockBatchEntryDate() {
		return blockBatchEntryDate;
	}
	public void setBlockBatchEntryDate(String blockBatchEntryDate) {
		this.blockBatchEntryDate = blockBatchEntryDate;
	}
	public String getBlockBatchNumber() {
		return blockBatchNumber;
	}
	public void setBlockBatchNumber(String blockBatchNumber) {
		this.blockBatchNumber = blockBatchNumber;
	}
	public String getBlockEntryChannelNumber() {
		return blockEntryChannelNumber;
	}
	public void setBlockEntryChannelNumber(String blockEntryChannelNumber) {
		this.blockEntryChannelNumber = blockEntryChannelNumber;
	}
	public String getBlockEntryTransactionBranch() {
		return blockEntryTransactionBranch;
	}
	public void setBlockEntryTransactionBranch(String blockEntryTransactionBranch) {
		this.blockEntryTransactionBranch = blockEntryTransactionBranch;
	}
	public String getBlockStatusFlag() {
		return blockStatusFlag;
	}
	public void setBlockStatusFlag(String blockStatusFlag) {
		this.blockStatusFlag = blockStatusFlag;
	}
	public String getSweepBlockReferenceNumber() {
		return sweepBlockReferenceNumber;
	}
	public void setSweepBlockReferenceNumber(String sweepBlockReferenceNumber) {
		this.sweepBlockReferenceNumber = sweepBlockReferenceNumber;
	}
	public String getBlockAmountPendingForRelease() {
		return blockAmountPendingForRelease;
	}
	public void setBlockAmountPendingForRelease(String blockAmountPendingForRelease) {
		this.blockAmountPendingForRelease = blockAmountPendingForRelease;
	}
	public String getCreditTransactionCode() {
		return creditTransactionCode;
	}
	public void setCreditTransactionCode(String creditTransactionCode) {
		this.creditTransactionCode = creditTransactionCode;
	}
	public String getDebitTransactionCode() {
		return debitTransactionCode;
	}
	public void setDebitTransactionCode(String debitTransactionCode) {
		this.debitTransactionCode = debitTransactionCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getBlockPartialFlag() {
		return blockPartialFlag;
	}
	public void setBlockPartialFlag(String blockPartialFlag) {
		this.blockPartialFlag = blockPartialFlag;
	}
	public String getExternalSystemID() {
		return externalSystemID;
	}
	public void setExternalSystemID(String externalSystemID) {
		this.externalSystemID = externalSystemID;
	}
	public String getExternalSystemReferenceNumber() {
		return externalSystemReferenceNumber;
	}
	public void setExternalSystemReferenceNumber(
			String externalSystemReferenceNumber) {
		this.externalSystemReferenceNumber = externalSystemReferenceNumber;
	}
	public String getBlockActionOnExpiryFlag() {
		return blockActionOnExpiryFlag;
	}
	public void setBlockActionOnExpiryFlag(String blockActionOnExpiryFlag) {
		this.blockActionOnExpiryFlag = blockActionOnExpiryFlag;
	}
	public String getCreditAccount() {
		return creditAccount;
	}
	public void setCreditAccount(String creditAccount) {
		this.creditAccount = creditAccount;
	}
	public String getDebitAccount() {
		return debitAccount;
	}
	public void setDebitAccount(String debitAccount) {
		this.debitAccount = debitAccount;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public String getCreditNarrative1() {
		return creditNarrative1;
	}
	public void setCreditNarrative1(String creditNarrative1) {
		this.creditNarrative1 = creditNarrative1;
	}
	public String getCreditNarrative2() {
		return creditNarrative2;
	}
	public void setCreditNarrative2(String creditNarrative2) {
		this.creditNarrative2 = creditNarrative2;
	}
	public String getCreditNarrative3() {
		return creditNarrative3;
	}
	public void setCreditNarrative3(String creditNarrative3) {
		this.creditNarrative3 = creditNarrative3;
	}
	public String getCreditNarrative4() {
		return creditNarrative4;
	}
	public void setCreditNarrative4(String creditNarrative4) {
		this.creditNarrative4 = creditNarrative4;
	}
	public String getCreditNarrative6() {
		return creditNarrative6;
	}
	public void setCreditNarrative6(String creditNarrative6) {
		this.creditNarrative6 = creditNarrative6;
	}
	public String getDebitNarrative1() {
		return debitNarrative1;
	}
	public void setDebitNarrative1(String debitNarrative1) {
		this.debitNarrative1 = debitNarrative1;
	}
	public String getDebitNarrative2() {
		return debitNarrative2;
	}
	public void setDebitNarrative2(String debitNarrative2) {
		this.debitNarrative2 = debitNarrative2;
	}
	public String getDebitNarrative3() {
		return debitNarrative3;
	}
	public void setDebitNarrative3(String debitNarrative3) {
		this.debitNarrative3 = debitNarrative3;
	}
	public String getDebitNarrative4() {
		return debitNarrative4;
	}
	public void setDebitNarrative4(String debitNarrative4) {
		this.debitNarrative4 = debitNarrative4;
	}
	public String getDebitNarrative5() {
		return debitNarrative5;
	}
	public void setDebitNarrative5(String debitNarrative5) {
		this.debitNarrative5 = debitNarrative5;
	}
	public String getDebitNarrative6() {
		return debitNarrative6;
	}
	public void setDebitNarrative6(String debitNarrative6) {
		this.debitNarrative6 = debitNarrative6;
	}
	public PayeeVO getPayeeVO() {
		return payeeVO;
	}
	public void setPayeeVO(PayeeVO payeeVO) {
		this.payeeVO = payeeVO;
	}
	
}
