package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 1470817
 *
 */
public class PaymentHistoryRequestVO extends BaseVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Date fromDate;
	private Date toDate;
	private String paymentStatus;
	private String paymentType;
	private BigDecimal minimumAmount;
	private BigDecimal maximumAmount;
	private String recordsperPage;
	private String transactionPeriod;
	
	
	/**
	 * @return the fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return the toDate
	 */
	public Date getToDate() {
		return toDate;
	}
	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}
	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	/**
	 * @return the minimumAmount
	 */
	public BigDecimal getMinimumAmount() {
		return minimumAmount;
	}
	/**
	 * @param minimumAmount the minimumAmount to set
	 */
	public void setMinimumAmount(BigDecimal minimumAmount) {
		this.minimumAmount = minimumAmount;
	}
	/**
	 * @return the maximumAmount
	 */
	public BigDecimal getMaximumAmount() {
		return maximumAmount;
	}
	/**
	 * @param maximumAmount the maximumAmount to set
	 */
	public void setMaximumAmount(BigDecimal maximumAmount) {
		this.maximumAmount = maximumAmount;
	}
	/**
	 * @return the recordsperPage
	 */
	public String getRecordsperPage() {
		return recordsperPage;
	}
	/**
	 * @param recordsperPage the recordsperPage to set
	 */
	public void setRecordsperPage(String recordsperPage) {
		this.recordsperPage = recordsperPage;
	}
	/**
	 * @return the transactionPeriod
	 */
	public String getTransactionPeriod() {
		return transactionPeriod;
	}
	/**
	 * @param transactionPeriod the transactionPeriod to set
	 */
	public void setTransactionPeriod(String transactionPeriod) {
		this.transactionPeriod = transactionPeriod;
	}
	
	
	}
