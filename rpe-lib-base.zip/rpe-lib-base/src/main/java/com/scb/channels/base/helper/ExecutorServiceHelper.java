package com.scb.channels.base.helper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The Class ExecutorServiceHelper.
 */
public final class ExecutorServiceHelper {
	
	/** The Constant EXECUTOR_SERVICE. */
	public static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(CommonConstants.TWENTY_FIVE);
	
	/**
	 * Instantiates a new executor service helper.
	 */
	private ExecutorServiceHelper() {}
}
