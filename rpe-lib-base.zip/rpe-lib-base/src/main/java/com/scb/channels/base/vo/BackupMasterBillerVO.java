package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

public class BackupMasterBillerVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4720180687847563960L;
	
	private int id;
	/** Biller id **/
	private String billerUniqueId;
	/**   billerTypeCd one to many reference **/
	
	private String billerTypeCode;
	
	/**  ctryCd **/
	private String countryCode;	
	
	/**  channelId **/
	
	private String channel;
	
	/** BilerCd **/
	private String billerId;
	
	/** billerDesc  * */
	private String billerDesc;
	
	 
	/** statusCd  * */
	private String statusCode;
	
	/** paymentType  * */
	
	private String paymentType;
	
	/** aggregatePaymentCode  * */
	private String aggregatePaymentCode;
	
	/** currency  * */
	private String currency;
	
	/** defaultAmount  * */
	private Double defaultAmount ;
	
	/** minAmount  * */
	private Double minimumAmount;
	
	/** billerProductName  * */
	private String billerProductName;
	
	/** maxAmount  * */
	private Double maximumAmount;
	
	/** billPresentmentType  * */
	private String billPresentmentType;
	
	/** createdBy  * */
	private String createdBy;
	
	/** updBy  * */
 	private String updatedBy;
 	
	
	private Date dateCreated;
	
	private Date dateUpdated;	
	
	private int version;
	
	/** billerName  * */
	private String billerShortName="";
	
	private  BackupMasterBillerCategoryVO categorytype;
	
	  
	
	private Set<BackupMasterBillerField> billerFields;
	
	private String isOnline;
	
	 
	 
	/**
	 * @return the isOnline
	 */
	public String getIsOnline() {
		return isOnline;
	}



	/**
	 * @param isOnline the isOnline to set
	 */
	public void setIsOnline(String isOnline) {
		this.isOnline = isOnline;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getBillerUniqueId() {
		return billerUniqueId;
	}



	public void setBillerUniqueId(String billerUniqueId) {
		this.billerUniqueId = billerUniqueId;
	}



	public String getBillerTypeCode() {
		return billerTypeCode;
	}



	public void setBillerTypeCode(String billerTypeCode) {
		this.billerTypeCode = billerTypeCode;
	}



	public String getCountryCode() {
		return countryCode;
	}



	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}



	public String getChannel() {
		return channel;
	}



	public void setChannel(String channel) {
		this.channel = channel;
	}



	public String getBillerId() {
		return billerId;
	}



	public void setBillerId(String billerId) {
		this.billerId = billerId;
	}



	public String getBillerDesc() {
		return billerDesc;
	}



	public void setBillerDesc(String billerDesc) {
		this.billerDesc = billerDesc;
	}



	public String getStatusCode() {
		return statusCode;
	}



	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}



	public String getPaymentType() {
		return paymentType;
	}



	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}



	public String getAggregatePaymentCode() {
		return aggregatePaymentCode;
	}



	public void setAggregatePaymentCode(String aggregatePaymentCode) {
		this.aggregatePaymentCode = aggregatePaymentCode;
	}



	public String getCurrency() {
		return currency;
	}



	public void setCurrency(String currency) {
		this.currency = currency;
	}



	public Double getDefaultAmount() {
		return defaultAmount;
	}



	public void setDefaultAmount(Double defaultAmount) {
		this.defaultAmount = defaultAmount;
	}



	public Double getMinimumAmount() {
		return minimumAmount;
	}



	public void setMinimumAmount(Double minimumAmount) {
		this.minimumAmount = minimumAmount;
	}



	public String getBillerProductName() {
		return billerProductName;
	}



	public void setBillerProductName(String billerProductName) {
		this.billerProductName = billerProductName;
	}



	public Double getMaximumAmount() {
		return maximumAmount;
	}



	public void setMaximumAmount(Double maximumAmount) {
		this.maximumAmount = maximumAmount;
	}



	public String getBillPresentmentType() {
		return billPresentmentType;
	}



	public void setBillPresentmentType(String billPresentmentType) {
		this.billPresentmentType = billPresentmentType;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	public Date getDateCreated() {
		return dateCreated;
	}



	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}



	public Date getDateUpdated() {
		return dateUpdated;
	}



	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}



	public int getVersion() {
		return version;
	}



	public void setVersion(int version) {
		this.version = version;
	}



	public String getBillerShortName() {
		return billerShortName;
	}



	public void setBillerShortName(String billerShortName) {
		this.billerShortName = billerShortName;
	}



	public BackupMasterBillerCategoryVO getCategorytype() {
		return categorytype;
	}



	public void setCategorytype(BackupMasterBillerCategoryVO categorytype) {
		this.categorytype = categorytype;
	}



	public Set<BackupMasterBillerField> getBillerFields() {
		return billerFields;
	}



	public void setBillerFields(Set<BackupMasterBillerField> billerFields) {
		this.billerFields = billerFields;
	}



	
 
}
