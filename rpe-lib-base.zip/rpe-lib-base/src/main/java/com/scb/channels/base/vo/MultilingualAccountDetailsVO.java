package com.scb.channels.base.vo;

import java.io.Serializable;

public class MultilingualAccountDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 831885361202257545L;
	
	private String accountFullName;
	private String accountLanguageCode;
	
	
	public String getAccountFullName() {
		return accountFullName;
	}
	public void setAccountFullName(String accountFullName) {
		this.accountFullName = accountFullName;
	}
	public String getAccountLanguageCode() {
		return accountLanguageCode;
	}
	public void setAccountLanguageCode(String accountLanguageCode) {
		this.accountLanguageCode = accountLanguageCode;
	}

}
