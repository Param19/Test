/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;



/**
 * The Class BankInfoVO.
 *
 * @author 1411807
 */
public class BankInfoVO implements Serializable, Cloneable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1279788676540918519L;
	
	/** The bank id. */
	private String bankId;
	
	/** The bank name. */
	private String bankName;
	
	/** The branch id. */
	private String branchId;
	
	/** The branch name. */
	private String branchName;
	
	 /** The address1. */
 	private String address1;
		
	 /** The address2. */
 	private String address2;
			
	 /** The address3. */
 	private String address3;
			
	 /** The city. */
 	private String city;
			
	 /** The state. */
 	private String state;
			
	 /** The zip code. */
 	private String zipCode;
			
	 /** The country. */
 	private String country;
	 
	 /** The rounting info vo. */
 	private List<RountingInfoVO> rountingInfoVO;

	/**
	 * Gets the bank id.
	 *
	 * @return the bankId
	 */
	public String getBankId() {
		return bankId;
	}

	/**
	 * Sets the bank id.
	 *
	 * @param bankId the bankId to set
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * Gets the bank name.
	 *
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * Sets the bank name.
	 *
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Gets the branch id.
	 *
	 * @return the branchId
	 */
	public String getBranchId() {
		return branchId;
	}

	/**
	 * Sets the branch id.
	 *
	 * @param branchId the branchId to set
	 */
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	/**
	 * Gets the branch name.
	 *
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}

	/**
	 * Sets the branch name.
	 *
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	/**
	 * Gets the address1.
	 *
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * Sets the address1.
	 *
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * Gets the address2.
	 *
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * Sets the address2.
	 *
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * Gets the address3.
	 *
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}

	/**
	 * Sets the address3.
	 *
	 * @param address3 the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the zip code.
	 *
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * Sets the zip code.
	 *
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the rounting info vo.
	 *
	 * @return the rountingInfoVO
	 */
	public List<RountingInfoVO> getRountingInfoVO() {
		return rountingInfoVO;
	}

	/**
	 * Sets the rounting info vo.
	 *
	 * @param rountingInfoVO the rountingInfoVO to set
	 */
	public void setRountingInfoVO(List<RountingInfoVO> rountingInfoVO) {
		this.rountingInfoVO = rountingInfoVO;
	}



}
