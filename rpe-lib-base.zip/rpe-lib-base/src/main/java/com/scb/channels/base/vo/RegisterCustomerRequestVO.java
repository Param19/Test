/**
 * 
 */
package com.scb.channels.base.vo;

import java.math.BigInteger;
import java.util.List;


/**
 * @author 1411807
 *
 */
public class RegisterCustomerRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1054048227139719592L;
	
	private String emailAlertType;
	    
	private String mobileOperator;
	    
	private String defaultAccount;
	
	private BigInteger encrypted;
	private	Boolean cardAlert;
	private List<String> cardList;
	
	private CustomerDetailsVO customerDetailsVO;
	
	private AccountListDetailsVO accountListDetails;

	public CustomerDetailsVO getCustomerDetailsVO() {
		return customerDetailsVO;
	}

	public void setCustomerDetailsVO(CustomerDetailsVO customerDetailsVO) {
		this.customerDetailsVO = customerDetailsVO;
	}

	/**
	 * @return the emailAlertType
	 */
	public String getEmailAlertType() {
		return emailAlertType;
	}

	/**
	 * @param emailAlertType the emailAlertType to set
	 */
	public void setEmailAlertType(String emailAlertType) {
		this.emailAlertType = emailAlertType;
	}

	/**
	 * @return the mobileOperator
	 */
	public String getMobileOperator() {
		return mobileOperator;
	}

	/**
	 * @param mobileOperator the mobileOperator to set
	 */
	public void setMobileOperator(String mobileOperator) {
		this.mobileOperator = mobileOperator;
	}

	/**
	 * @return the defaultAccount
	 */
	public String getDefaultAccount() {
		return defaultAccount;
	}

	/**
	 * @param defaultAccount the defaultAccount to set
	 */
	public void setDefaultAccount(String defaultAccount) {
		this.defaultAccount = defaultAccount;
	}

	public BigInteger getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(BigInteger encrypted) {
		this.encrypted = encrypted;
	}

	public Boolean getCardAlert() {
		return cardAlert;
	}

	public void setCardAlert(Boolean cardAlert) {
		this.cardAlert = cardAlert;
	}

	public List<String> getCardList() {
		return cardList;
	}

	public void setCardList(List<String> cardList) {
		this.cardList = cardList;
	}

	/**
	 * @return the accountListDetails
	 */
	public AccountListDetailsVO getAccountListDetails() {
		return accountListDetails;
	}

	/**
	 * @param accountListDetails the accountListDetails to set
	 */
	public void setAccountListDetails(AccountListDetailsVO accountListDetails) {
		this.accountListDetails = accountListDetails;
	}

}
