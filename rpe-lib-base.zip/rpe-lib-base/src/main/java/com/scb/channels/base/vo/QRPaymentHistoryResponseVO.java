package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

public class QRPaymentHistoryResponseVO extends BaseVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4305665492936422240L;
	
	/*private List<QRPaymentVO> qrPaymentHistoryList;

	public List<QRPaymentVO> getQrPaymentHistoryList() {
		return qrPaymentHistoryList;
	}

	public void setQrPaymentHistoryList(List<QRPaymentVO> qrPaymentHistoryList) {
		this.qrPaymentHistoryList = qrPaymentHistoryList;
	}
	*/
	
	private List<QRPaymentVO> qrPaymentHistoryViewList;

	public List<QRPaymentVO> getQrPaymentHistoryViewList() {
		return qrPaymentHistoryViewList;
	}

	public void setQrPaymentHistoryViewList(
			List<QRPaymentVO> qrPaymentHistoryViewList) {
		this.qrPaymentHistoryViewList = qrPaymentHistoryViewList;
	}


}
