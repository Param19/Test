package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterResponseTransactionHistory {

	private QRPaymentMasterResponseTransaction Transaction;

	public QRPaymentMasterResponseTransaction getTransaction() {
		return Transaction;
	}

	public void setTransaction(QRPaymentMasterResponseTransaction transaction) {
		Transaction = transaction;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterResponseTransactionHistory [Transaction="
				+ Transaction + "]";
	}
	
	
	
}
