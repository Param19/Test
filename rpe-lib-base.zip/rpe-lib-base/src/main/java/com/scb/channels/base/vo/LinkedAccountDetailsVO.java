package com.scb.channels.base.vo;

import java.io.Serializable;

public class LinkedAccountDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 155913406132978973L;
	
	private String currencyCode;
    private String accountNumber;
    private String currentStatus;
	
    
    public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	} 

}
