package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * 
 * @author 1552545
 * 
 */
public class JetcoAuditTxn implements Serializable, Cloneable {

	private static final long serialVersionUID = -5810455700544699463L;

	private Long id;
	private String customerId;
	private String customerIdType;
	private String bankMessageId;
	private String bankMessageCreationDateTime;
	private String bankTransactionId;
	private String bankTransactionCreationDateTime;
	private String maskedReceiverAccountName;
	private String receiverMobileNumber;
	private String senderAccountNumber;
	private String senderAccountType;
	private String paymentDescription;
	private String senderAccountCurrency;
	private String paymentType;
	private String paymentStatus;
	private String reasonCode;
	private String channel;
	private BigDecimal transactionAmount;
	private Timestamp paymentDate;
	private Timestamp createdDate;
	private String createdBy;
	private Timestamp updatedDate;
	private String updatedBy;
	private String referenceNumber;
	private String hostStatusCode;
	private String hostStatusDesc;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerIdType() {
		return customerIdType;
	}

	public void setCustomerIdType(String customerIdType) {
		this.customerIdType = customerIdType;
	}

	public String getBankMessageId() {
		return bankMessageId;
	}

	public void setBankMessageId(String bankMessageId) {
		this.bankMessageId = bankMessageId;
	}

	public String getBankTransactionId() {
		return bankTransactionId;
	}

	public void setBankTransactionId(String bankTransactionId) {
		this.bankTransactionId = bankTransactionId;
	}

	public String getMaskedReceiverAccountName() {
		return maskedReceiverAccountName;
	}

	public void setMaskedReceiverAccountName(String maskedReceiverAccountName) {
		this.maskedReceiverAccountName = maskedReceiverAccountName;
	}

	public String getReceiverMobileNumber() {
		return receiverMobileNumber;
	}

	public void setReceiverMobileNumber(String receiverMobileNumber) {
		this.receiverMobileNumber = receiverMobileNumber;
	}

	public String getSenderAccountNumber() {
		return senderAccountNumber;
	}

	public void setSenderAccountNumber(String senderAccountNumber) {
		this.senderAccountNumber = senderAccountNumber;
	}

	public String getSenderAccountType() {
		return senderAccountType;
	}

	public void setSenderAccountType(String senderAccountType) {
		this.senderAccountType = senderAccountType;
	}

	public String getPaymentDescription() {
		return paymentDescription;
	}

	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	public String getSenderAccountCurrency() {
		return senderAccountCurrency;
	}

	public void setSenderAccountCurrency(String senderAccountCurrency) {
		this.senderAccountCurrency = senderAccountCurrency;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public BigDecimal getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Timestamp getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getHostStatusCode() {
		return hostStatusCode;
	}

	public void setHostStatusCode(String hostStatusCode) {
		this.hostStatusCode = hostStatusCode;
	}

	public String getHostStatusDesc() {
		return hostStatusDesc;
	}

	public void setHostStatusDesc(String hostStatusDesc) {
		this.hostStatusDesc = hostStatusDesc;
	}

	public String getBankMessageCreationDateTime() {
		return bankMessageCreationDateTime;
	}

	public void setBankMessageCreationDateTime(
			String bankMessageCreationDateTime) {
		this.bankMessageCreationDateTime = bankMessageCreationDateTime;
	}

	public String getBankTransactionCreationDateTime() {
		return bankTransactionCreationDateTime;
	}

	public void setBankTransactionCreationDateTime(
			String bankTransactionCreationDateTime) {
		this.bankTransactionCreationDateTime = bankTransactionCreationDateTime;
	}

}
