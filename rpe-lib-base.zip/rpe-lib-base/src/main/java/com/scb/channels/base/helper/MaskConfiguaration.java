package com.scb.channels.base.helper;

import org.apache.commons.lang.StringUtils;

/**
 * The Class MaskConfiguaration.
 */
public class MaskConfiguaration {
	
	private static final String NONE = "NONE";

	private static final String R = "R";

	private static final String L = "L";

	private static final String ER = "ER";

	private static final String EL = "EL";

	/** The type. */
	private String type;
	  
  	/** The number. */
  	private int number;
	  
  	/** The mask character. */
  	private char maskCharacter = '*';
	  
  	/** The fix legnth. */
  	private int fixLegnth = 4;

	  /**
  	 * Instantiates a new mask configuaration.
  	 *
  	 * @param configurationString the configuration string
  	 */
  	private MaskConfiguaration(String configurationString)
	  {
	    if (configurationString == null) {
	      configurationString = CommonConstants.ALL;
	    }

	    if (configurationString.indexOf(CommonConstants.COMMA) > 0) {
	      this.maskCharacter = configurationString.charAt(configurationString.indexOf(CommonConstants.COMMA) + 1);
	      configurationString = configurationString.substring(0, configurationString.indexOf(CommonConstants.COMMA));
	    }
	    if (configurationString.startsWith(EL)) {
	      this.number = Integer.valueOf(configurationString.substring(2)).intValue();
	      this.type = EL;
	    } else if (configurationString.startsWith(ER)) {
	      this.number = Integer.valueOf(configurationString.substring(2)).intValue();
	      this.type = ER;
	    } else if (configurationString.startsWith(L)) {
	      this.type = L;
	      this.number = Integer.valueOf(configurationString.substring(1)).intValue();
	    } else if (configurationString.startsWith(R)) {
	      this.type = R;
	      this.number = Integer.valueOf(configurationString.substring(1)).intValue();
	    } else if (configurationString.equals(NONE)) {
	      this.type = NONE;
	    } else {
	      this.type = CommonConstants.ALL;
	    }
	  }

	  /**
  	 * Mask string.
  	 *
  	 * @param content the content
  	 * @return the string
  	 */
  	public String maskString(String content) {
	    StringBuilder sb = new StringBuilder();
	    int contentLength = content.length();
	    if (EL.equals(this.type))
	      if (this.number > contentLength) {
	        sb.append(content);
	      } else {
	        sb.append(content.substring(0, this.number));
	        sb.append(getMaskString(contentLength - this.number));
	      }
	    else if (ER.equals(this.type))
	      if (this.number > contentLength) {
	        sb.append(content);
	      } else {
	        sb.append(getMaskString(content.length() - this.number));
	        sb.append(content.substring(contentLength - this.number));
	      }
	    else if (L.equals(this.type))
	      if (this.number > contentLength) {
	        sb.append(getMaskString(contentLength));
	      } else {
	        sb.append(getMaskString(this.number));
	        sb.append(content.substring(this.number));
	      }
	    else if (R.equals(this.type))
	      if (this.number > contentLength) {
	        sb.append(getMaskString(contentLength));
	      } else {
	        sb.append(content.substring(0, contentLength - this.number));
	        sb.append(getMaskString(this.number));
	      }
	    else if (NONE.equals(this.type))
	      sb.append(content);
	    else if ("ALL".equals(this.type)) {
	      sb.append(getMaskString(this.fixLegnth));
	    }
	    return sb.toString();
	  }

	  /**
  	 * Gets the mask string.
  	 *
  	 * @param length the length
  	 * @return the mask string
  	 */
  	private String getMaskString(int length) {
	    return StringUtils.repeat(this.maskCharacter + "", length);
	  }

	  /**
  	 * Builds the.
  	 *
  	 * @param configuraitonString the configuraiton string
  	 * @return the mask configuaration
  	 */
  	public static MaskConfiguaration build(String configuraitonString) {
	    return new MaskConfiguaration(configuraitonString);
	  }
}
