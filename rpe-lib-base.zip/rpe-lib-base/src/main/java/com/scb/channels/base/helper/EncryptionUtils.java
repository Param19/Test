package com.scb.channels.base.helper;

import java.io.ByteArrayOutputStream;
import java.security.Key;
import java.util.StringTokenizer;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptionUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(EncryptionUtils.class);

	public static String encrypt(String strKey, String strSource) {
		try {
			// Get our secret key
			Key key = getKey(strKey);

			// Create the cipher
			Cipher desCipher = Cipher.getInstance(new String(
					"DESede/ECB/PKCS5Padding")); //$NON-NLS-1$//Triple DES Encryption 

			// Initialize the cipher for encryption
			desCipher.init(Cipher.ENCRYPT_MODE, key);

			// Our cleartext as bytes
			byte[] cleartext = strSource.getBytes();

			// Encrypt the cleartext
			byte[] ciphertext = desCipher.doFinal(cleartext);

			// Return a String representation of the cipher text
			return getString(ciphertext);
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return null;
	}

	public static String decrypt(String strKey, String strSource) {
		try {

			// Get our secret key
			Key key = getKey(strKey);

			// Create the cipher
			Cipher desCipher = Cipher.getInstance("DESede/ECB/PKCS5Padding"); //$NON-NLS-1$

			// Encrypt the cleartext
			byte[] ciphertext = getBytes(strSource);

			// Initialize the same cipher for decryption
			desCipher.init(Cipher.DECRYPT_MODE, key);

			// Decrypt the ciphertext
			byte[] cleartext = desCipher.doFinal(ciphertext);

			// Return the clear text
			return new String(cleartext);
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return null;
	}

	private static Key getKey(String strKey) {
		try {
			byte[] bKey = new byte[DESedeKeySpec.DES_EDE_KEY_LEN];

			byte[] bTemp = strKey.getBytes();
			int iKeyLen = 0;
			if (bTemp.length < DESedeKeySpec.DES_EDE_KEY_LEN)
				iKeyLen = bTemp.length;
			else
				iKeyLen = DESedeKeySpec.DES_EDE_KEY_LEN;
			for (int iCounter = 0; iCounter < iKeyLen; iCounter++) {
				bKey[iCounter] = bTemp[iCounter];
			}
			for (int iCounter = iKeyLen; iCounter < DESedeKeySpec.DES_EDE_KEY_LEN; iCounter++) {
				bKey[iCounter] = (byte) 0;
			}

			DESedeKeySpec pass = new DESedeKeySpec(bKey);
			SecretKeyFactory skf = SecretKeyFactory.getInstance("DESede"); //$NON-NLS-1$
			SecretKey s = skf.generateSecret(pass);
			return s;
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return null;
	}

	private static String getString(byte[] bytes) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			byte b = bytes[i];
			sb.append((int) (0x00FF & b));
			if (i + 1 < bytes.length) {
				sb.append("-"); //$NON-NLS-1$
			}
		}
		return sb.toString();
	}

	private static byte[] getBytes(String str) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		StringTokenizer st = new StringTokenizer(str, "-", false); //$NON-NLS-1$
		while (st.hasMoreTokens()) {
			int i = Integer.parseInt(st.nextToken());
			bos.write((byte) i);
		}
		return bos.toByteArray();
	}
}
