package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * @author 1460693
 *
 */
 
/**
 * @author 1460693
 *
 */
public class PaymentStatusVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	  /**
	 * 
	 */
	private String transactionStatus;
	  /**
	 * 
	 */
	private String transactionID;
	  /**
	 * 
	 */
	private String amount;
	  /**
	 * 
	 */
	private String accountNumber;
	  /**
	 * 
	 */
	private String billerID;
	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}
	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	/**
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	/**
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the billerID
	 */
	public String getBillerID() {
		return billerID;
	}
	/**
	 * @param billerID the billerID to set
	 */
	public void setBillerID(String billerID) {
		this.billerID = billerID;
	}
	
	
}
