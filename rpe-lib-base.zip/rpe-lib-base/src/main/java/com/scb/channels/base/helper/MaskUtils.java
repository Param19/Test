/**
 * 
 */
package com.scb.channels.base.helper;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Class MaskUtils.
 *
 * @author 1411807
 */
public class MaskUtils {

	 /**
 	 * Mask.
 	 *
 	 * @param content the content
 	 * @param pattern the pattern
 	 * @param group the group
 	 * @param maskConfiguration the mask configuration
 	 * @return the string
 	 */
 	public static String mask(String content, Pattern pattern, int group, MaskConfiguaration maskConfiguration) {
	    if (content == null) {
	      return null;
	    }
	    Matcher matcher = pattern.matcher(content);
	    StringBuffer sb = new StringBuffer();
	    while (matcher.find()) {
	    	matcher.appendReplacement(sb, matcher.group(1) + maskConfiguration.maskString(matcher.group(group)));
	    }
	    matcher.appendTail(sb);
	    return sb.toString();
	  }

	  /**
  	 * Mask.
  	 *
  	 * @param content the content
  	 * @param context the context
  	 * @return the string
  	 */
  	public static String mask(String content, MaskContext context) {
	    List<Masker> maskers = context.getMaskersList();
	    String maskedContent = content;
	    for (Masker masker : maskers) {
	      maskedContent = mask(maskedContent, masker.getPattern(), masker.getGroupNumber(), masker.getMaskRule());
	    }
	    return maskedContent;
	  }
  
}
