package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillPresentmentResponseVO.
 */
public class BillPresentmentResponseVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3054532474676266411L;
	
	/** The biller pay details vo. */
	private BillerPayDetailsVO billerPayDetailsVO;
    
	/**
	 * Gets the biller pay details vo.
	 *
	 * @return the billerPayDetailsVO
	 */
	public BillerPayDetailsVO getBillerPayDetailsVO() {
		return billerPayDetailsVO;
	}

	/**
	 * Sets the biller pay details vo.
	 *
	 * @param billerPayDetailsVO the billerPayDetailsVO to set
	 */
	public void setBillerPayDetailsVO(BillerPayDetailsVO billerPayDetailsVO) {
		this.billerPayDetailsVO = billerPayDetailsVO;
	}


}
