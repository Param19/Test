package com.scb.channels.base.vo;

import java.io.Serializable;

public class InterestBandVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1835026955493088794L;
	
	 	private String amount;
	 	private String offset;
	    private String creditDebitExcessFlag;
	    private String penaltyRate;
	    private String rateApplicablePeriod;
	    private String sequenceNumber;
	    private String rateTerm;
	    private String interestAddToGlobalRateBandFlag;
		
	    public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		public String getOffset() {
			return offset;
		}
		public void setOffset(String offset) {
			this.offset = offset;
		}
		public String getCreditDebitExcessFlag() {
			return creditDebitExcessFlag;
		}
		public void setCreditDebitExcessFlag(String creditDebitExcessFlag) {
			this.creditDebitExcessFlag = creditDebitExcessFlag;
		}
		public String getPenaltyRate() {
			return penaltyRate;
		}
		public void setPenaltyRate(String penaltyRate) {
			this.penaltyRate = penaltyRate;
		}
		public String getRateApplicablePeriod() {
			return rateApplicablePeriod;
		}
		public void setRateApplicablePeriod(String rateApplicablePeriod) {
			this.rateApplicablePeriod = rateApplicablePeriod;
		}
		public String getSequenceNumber() {
			return sequenceNumber;
		}
		public void setSequenceNumber(String sequenceNumber) {
			this.sequenceNumber = sequenceNumber;
		}
		public String getRateTerm() {
			return rateTerm;
		}
		public void setRateTerm(String rateTerm) {
			this.rateTerm = rateTerm;
		}
		public String getInterestAddToGlobalRateBandFlag() {
			return interestAddToGlobalRateBandFlag;
		}
		public void setInterestAddToGlobalRateBandFlag(
				String interestAddToGlobalRateBandFlag) {
			this.interestAddToGlobalRateBandFlag = interestAddToGlobalRateBandFlag;
		}

}
