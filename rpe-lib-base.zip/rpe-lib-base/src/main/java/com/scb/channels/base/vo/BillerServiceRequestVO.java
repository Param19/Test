package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerListRequestVO.
 */
public class BillerServiceRequestVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4434006636186262503L;	
	
    private int version;


	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	

}
 