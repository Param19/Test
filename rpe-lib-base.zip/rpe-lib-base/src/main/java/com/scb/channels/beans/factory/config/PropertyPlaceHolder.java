/**
 * 
 */
package com.scb.channels.beans.factory.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.scb.channels.base.helper.CommonConstants;

/**
 * The Class PropertyPlaceHolder.
 *
 * @author 1411807
 */
public class PropertyPlaceHolder extends PropertyPlaceholderConfigurer {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PropertyPlaceHolder.class);
	
	/** The properties map. */
	private static final Map<String, String> propertiesMap = new HashMap<String, String>();
	
	   // Default as in PropertyPlaceholderConfigurer
    /** The spring system properties mode. */
   	private int springSystemPropertiesMode = SYSTEM_PROPERTIES_MODE_FALLBACK;
	
	/* (non-Javadoc)
	 * @see org.springframework.core.io.support.PropertiesLoaderSupport#setLocations(org.springframework.core.io.Resource[])
	 */
	@Override
	public void setLocations(Resource[] locations) {
		if (locations != null) {
			int i=0;
			for (Resource resource: locations) {
				locations[i] = convertToEnvironmentResource(resource);
				i++;
			}
		}
		super.setLocations(locations);
	}

	/**
	 * Converts the ordinary resource to environment based resource.
	 *
	 * @param resource Resource
	 * @return Resource
	 */
	private Resource convertToEnvironmentResource(Resource resource) {
		try {
			String fileName = resource.getFilename();
			if (resource instanceof ClassPathResource) {
				String[] farry = fileName.split(CommonConstants.FILENAME_SPLIT_PATTERN);
				String environment = System.getProperty(CommonConstants.ENV);
				String newFileName = new StringBuilder().append(farry[0]).append(CommonConstants.HYPHEN)
					.append((environment != null ? environment : CommonConstants.DEFAULT_ENV)).append(CommonConstants.DOT).append(farry[1]).toString();
				LOGGER.debug("Resource loading after conversion {} {} {}", new Object[] {environment, fileName, newFileName});
				return new ClassPathResource(newFileName);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return resource;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.PropertyPlaceholderConfigurer#processProperties(org.springframework.beans.factory.config.ConfigurableListableBeanFactory, java.util.Properties)
	 */
	@Override
    protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props) throws BeansException {
        super.processProperties(beanFactory, props);
        for (Object key : props.keySet()) {
            String keyStr = key.toString();
            String valueStr = resolvePlaceholder(keyStr, props, springSystemPropertiesMode);
            propertiesMap.put(keyStr, valueStr);
        }
    }
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.PropertyPlaceholderConfigurer#setSystemPropertiesMode(int)
	 */
	@Override
    public void setSystemPropertiesMode(int systemPropertiesMode) {
        super.setSystemPropertiesMode(systemPropertiesMode);
        springSystemPropertiesMode = systemPropertiesMode;
    }
	
	/**
	 * Gets the property.
	 *
	 * @param name the name
	 * @return the property
	 */
	public static String getProperty(String name) {
		String property = System.getProperty(name);
		if (property!=null) {
			return property;
		}
	     return String.valueOf(propertiesMap.get(name));
	}
	

}
