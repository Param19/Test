package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * The Class BillerField.
 */
public class BackupMasterBillerField implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2842399165283725824L;

	 
	private Integer id;
																																																																																																																																																																
	/** The BILLER_ID   value. *//*
	private Number  billerId;*/
	
	/** The countryCode */
	private String countryCode;
	
	/** The channelCode. */
	private String channelCode;
	
	/** The language. */
	private String language;
	

	/** The fieldLabelName. */
	private String fieldLabelName;
	
	/** The FIELD_TYPE. */
	private String fieldType;
	
	/**  FIELD_DEFAULT_VALUES	 */
	private String fieldDefaultValues;
	
	/**  FIELD_MIN_LENGTH	 */
	private String fieldMinLength;
	
	/**  FIELD_MAX_LENGTH	 */
	private String fieldMaxLength;
	
	/**  fieldDataType	 */
	
	private String fieldDataType;
	
	

	/**  FIELD_REQUIRED	 */
 	private String  isfieldRequired;
	
	/**  orderSequence	 */
	private Integer orderSequence;
	

	/** createdBy  * */
	private String createdBy;
	
	/** updBy  * */
 	private String updatedBy;
 	
 	/** dateCreated  * */
	private Date dateCreated;
	
	/** dateUpdated  * */
	private Date dateUpdated;	
	
	/** version  **/
	private int version;
	
	
	private String caption ;
	
	Set<BackupBillerFieldItemVO> billerFieldItems=new HashSet<BackupBillerFieldItemVO>(0);


	/**
	 * @return the billerFieldItems
	 */
	public Set<BackupBillerFieldItemVO> getBillerFieldItems() {
		return billerFieldItems;
	}

	/**
	 * @param billerFieldItems the billerFieldItems to set
	 */
	public void setBillerFieldItems(Set<BackupBillerFieldItemVO> billerFieldItems) {
		this.billerFieldItems = billerFieldItems;
	}

	/**
	 * @return the caption
	 */
	public String getCaption() {
		return caption;
	}

	/**
	 * @param caption the caption to set
	 */
	public void setCaption(String caption) {
		this.caption = caption;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	private String status;
	
	private BackupMasterBillerVO billerId;
	
 

	public BackupMasterBillerVO getBillerId() {
		return billerId;
	}

	public void setBillerId(BackupMasterBillerVO billerId) {
		this.billerId = billerId;
	}

	public String getCountryCode() {
		return countryCode;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFieldDataType() {
		return fieldDataType;
	}

	public void setFieldDataType(String fieldDataType) {
		this.fieldDataType = fieldDataType;
	}
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getIsfieldRequired() {
		return isfieldRequired;
	}

	public void setIsfieldRequired(String isfieldRequired) {
		this.isfieldRequired = isfieldRequired;
	}
	
	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}
	public Integer getOrderSequence() {
		return orderSequence;
	}

	public void setOrderSequence(Integer orderSequence) {
		this.orderSequence = orderSequence;
	}

	public String getFieldLabelName() {
		return fieldLabelName;
	}

	public void setFieldLabelName(String fieldLabelName) {
		this.fieldLabelName = fieldLabelName;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getFieldDefaultValues() {
		return fieldDefaultValues;
	}

	public void setFieldDefaultValues(String fieldDefaultValues) {
		this.fieldDefaultValues = fieldDefaultValues;
	}

	public String getFieldMinLength() {
		return fieldMinLength;
	}

	public void setFieldMinLength(String fieldMinLength) {
		this.fieldMinLength = fieldMinLength;
	}

	public String getFieldMaxLength() {
		return fieldMaxLength;
	}

	public void setFieldMaxLength(String fieldMaxLength) {
		this.fieldMaxLength = fieldMaxLength;
	}

	 

	 

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	
}
