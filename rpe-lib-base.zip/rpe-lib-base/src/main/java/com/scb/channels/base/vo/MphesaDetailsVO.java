/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * @author 1464157
 *
 */
public class MphesaDetailsVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5870130465497754838L;
	
    private String payBillNo;
    private String mpesaCustRefNo;
    private String mpesaReceiptNo;
    private String paymentdesc;
	/**
	 * @return the payBillNo
	 */
	public String getPayBillNo() {
		return payBillNo;
	}
	/**
	 * @param payBillNo the payBillNo to set
	 */
	public void setPayBillNo(String payBillNo) {
		this.payBillNo = payBillNo;
	}
	/**
	 * @return the mpesaCustRefNo
	 */
	public String getMpesaCustRefNo() {
		return mpesaCustRefNo;
	}
	/**
	 * @param mpesaCustRefNo the mpesaCustRefNo to set
	 */
	public void setMpesaCustRefNo(String mpesaCustRefNo) {
		this.mpesaCustRefNo = mpesaCustRefNo;
	}
	/**
	 * @return the mpesaReceiptNo
	 */
	public String getMpesaReceiptNo() {
		return mpesaReceiptNo;
	}
	/**
	 * @param mpesaReceiptNo the mpesaReceiptNo to set
	 */
	public void setMpesaReceiptNo(String mpesaReceiptNo) {
		this.mpesaReceiptNo = mpesaReceiptNo;
	}
	public String getPaymentdesc() {
		return paymentdesc;
	}
	public void setPaymentdesc(String paymentdesc) {
		this.paymentdesc = paymentdesc;
	}

}
