package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerPayRequestVO.
 */
public class CreditCardRequestVO extends BaseVO implements Serializable {
 
	
	/**
	 * 
	 * @author 1460693 <b>created by Srikanth.V</>
	 * @since <p>Picasso-SRM</p>
	 * 
	 */
	private CreditCardVO creditCardvo;
	private String statusCode;
	private String Statusdescription;
	
	 public CreditCardVO getCreditCardvo() {
		return creditCardvo;
	}
	public void setCreditCardvo(CreditCardVO creditCardvo) {
		this.creditCardvo = creditCardvo;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusdescription() {
		return Statusdescription;
	}
	public void setStatusdescription(String statusdescription) {
		Statusdescription = statusdescription;
	}
	
	 

}
