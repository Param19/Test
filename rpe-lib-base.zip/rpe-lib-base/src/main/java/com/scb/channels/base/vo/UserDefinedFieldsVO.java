package com.scb.channels.base.vo;

import java.io.Serializable;

public class UserDefinedFieldsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8216675675388650380L;
	
	 	private String accountUDFSequence;
	 	private String accountUDFCode;
	 	private String accountUDFValue;
		
	 	
	 	public String getAccountUDFSequence() {
			return accountUDFSequence;
		}
		public void setAccountUDFSequence(String accountUDFSequence) {
			this.accountUDFSequence = accountUDFSequence;
		}
		public String getAccountUDFCode() {
			return accountUDFCode;
		}
		public void setAccountUDFCode(String accountUDFCode) {
			this.accountUDFCode = accountUDFCode;
		}
		public String getAccountUDFValue() {
			return accountUDFValue;
		}
		public void setAccountUDFValue(String accountUDFValue) {
			this.accountUDFValue = accountUDFValue;
		}

}
