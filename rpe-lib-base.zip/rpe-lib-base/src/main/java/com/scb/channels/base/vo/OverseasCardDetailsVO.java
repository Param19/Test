package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;


public class OverseasCardDetailsVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 246780622778594577L;
	
	private String indicator;
    private String channelID;
    private String status;
    private Calendar date;
    private String time;
    private String tokenCardIndicator;
	
    
    public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public String getChannelID() {
		return channelID;
	}
	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Calendar getDate() {
		return date;
	}
	public void setDate(Calendar date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTokenCardIndicator() {
		return tokenCardIndicator;
	}
	public void setTokenCardIndicator(String tokenCardIndicator) {
		this.tokenCardIndicator = tokenCardIndicator;
	}

}
