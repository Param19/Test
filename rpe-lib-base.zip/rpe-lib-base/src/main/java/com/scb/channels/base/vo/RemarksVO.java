package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class RemarksVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7214291111568835887L;
	
	private String remarksSequenceNumber;
    private String remarks;
    private String remarksTypeCode;
    private Calendar remarksExpiryDate;
    private String remarksReviewFlag;
    private String remarksDepartmentCode;
    private String makerID;
    private String makerTime;
    private Calendar lastModifiedDate;
	
    
    public String getRemarksSequenceNumber() {
		return remarksSequenceNumber;
	}
	public void setRemarksSequenceNumber(String remarksSequenceNumber) {
		this.remarksSequenceNumber = remarksSequenceNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getRemarksTypeCode() {
		return remarksTypeCode;
	}
	public void setRemarksTypeCode(String remarksTypeCode) {
		this.remarksTypeCode = remarksTypeCode;
	}
	public Calendar getRemarksExpiryDate() {
		return remarksExpiryDate;
	}
	public void setRemarksExpiryDate(Calendar remarksExpiryDate) {
		this.remarksExpiryDate = remarksExpiryDate;
	}
	public String getRemarksReviewFlag() {
		return remarksReviewFlag;
	}
	public void setRemarksReviewFlag(String remarksReviewFlag) {
		this.remarksReviewFlag = remarksReviewFlag;
	}
	public String getRemarksDepartmentCode() {
		return remarksDepartmentCode;
	}
	public void setRemarksDepartmentCode(String remarksDepartmentCode) {
		this.remarksDepartmentCode = remarksDepartmentCode;
	}
	public String getMakerID() {
		return makerID;
	}
	public void setMakerID(String makerID) {
		this.makerID = makerID;
	}
	public String getMakerTime() {
		return makerTime;
	}
	public void setMakerTime(String makerTime) {
		this.makerTime = makerTime;
	}
	public Calendar getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Calendar lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
    
    

}
