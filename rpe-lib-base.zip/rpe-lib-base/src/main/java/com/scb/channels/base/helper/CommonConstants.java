/**
 * 
 */
package com.scb.channels.base.helper;

import java.util.HashMap;
import java.util.List;

import scala.actors.threadpool.Arrays;


// TODO: Auto-generated Javadoc
/**
 * The Class CommonConstants.
 *
 * @author 1411807
 */

public final class CommonConstants {
	
	/** The Constant HYPHEN. */
	public static final String HYPHEN = "-";
	
	public static final String SPACE_HYPHEN_SPACE =" - ";
	
	/** The Constant EMPTY. */
	public static final String EMPTY = "";
	
	/** The Constant ALL_KEY. */
	public static final String ALL_KEY = "ALL-ALL";
	
	/** The Constant ALL. */
	public static final String ALL = "ALL";
	
	/** The Constant ENV. */
	public static final String ENV = "ENV";
	
	/** The Constant FILENAME_SPLIT_PATTERN. */
	public static final String FILENAME_SPLIT_PATTERN = "\\.";
	
	/** The Constant DOT. */
	public static final String DOT = ".";
	
	/** The Constant DEFAULT_ENV. */
	public static final String DEFAULT_ENV = "DEV";
	
	/** The Constant LANGUAGE. */
	public static final String LANGUAGE= "EN";
	
	/** The Constant VERSION. */
	public static final String VERSION= "1";
	
	/** The Constant SERVICE_NAME. */
	public static final String SERVICE_NAME= "IFT";
	
	/** The Constant BILL_PAY_SERVICE_NAME. */
	public static final String BILL_PAY_SERVICE_NAME= "GPS";
	
	/** The Constant HOST_ENV. */
	public static final String HOST_ENV= "EDMI_TEST";
	
	
	/** The Constant REQUEST_TYPE. */
	public static final String REQUEST_TYPE= "LocalBeneList";
	
	/** The Constant REQUEST_TYPE_LOGOUT. */
	public static final String REQUEST_TYPE_LOGOUT= "Logout";
	
	/** The Constant REQUEST_TYPE_PINCHANGE. */
	public static final String REQUEST_TYPE_PINCHANGE= "PinChange";
	
	/** The Constant COUNTRY_KEY. */
	public static final String COUNTRY_KEY= "Country";
	
	/** The Constant NG. */
	public static final String NG= "NG";
	
	/** The Constant KE. */
	public static final String KE= "KE";
	
	/** The Constant KEMOBILE. */
	public static final String KEMOBILE= "KEMOBILE";
	
	/** The Constant IBANK. */
	public static final String IBANK= "IBANK"; 
	
	/** The Constant SERVICE_KEY. */
	public static final String SERVICE_KEY= "ENTERPRISE_SERVICE_NAME";
	
	/** The Constant BENEFICIARY. */
	public static final String BENEFICIARY= "beneficiary";
	
	/** The Constant BILLER. */
	public static final String BILLER= "biller";
	
	/** The Constant IFT. */
	public static final String IFT= "fundTransfer";
	
	/** The Constant IFT. */
	public static final String REVERSE_IFT_PROCESSNAME= "Transaction";
	
	/** The Constant VERSION_KEY. */
	public static final String VERSION_KEY= "ENTERPRISE_SERVICE_VERSION";
	
	/** The Constant VERSION_VALUE. */
	public static final String VERSION_VALUE= "1";
	
	/** The Constant SERVICE_TYPE_KEY. */
	public static final String SERVICE_TYPE_KEY= "ENTERPRISE_SERVICE_TYPE";
	
	/** The Constant LOCAL_FUND_TRANSFER. */
	public static final String LOCAL_FUND_TRANSFER= "localFundTransfer";
	
	/** The Constant BILL_PAYMENT. */
	public static final String BILL_PAYMENT= "billPayment";
	
	/** The Constant SUB_TYPE_NAME. */
	public static final String SUB_TYPE_NAME= "Transactions";
	
	/** The Constant SUB_TYPE_NAME. */
	public static final String REVERSE_TRANSFER_SUB_TYPE_NAME= "reverseTransaction";
	
	/** The Constant MESSAGE_TYPE_NAME. */
	public static final String MESSAGE_TYPE_NAME= "Transactions:Fund";
	
	/** The Constant MESSAGE_TYPE_NAME. */
	public static final String REVERSE_TRANSFER_MESSAGE_TYPE_NAME= "CoreBanking:TransactionServices";
	
	/** The Constant BENE_PROCESS_NAME. */
	public static final String BENE_PROCESS_NAME= "Beneficiary";
	
	/** The Constant BILLER_PROCESS_NAME. */
	public static final String BILLER_PROCESS_NAME= "Biller";
	
	/** The Constant PAYMENT_HISTORY. */
	public static final String PAYMENT_HISTORY= "paymentHistory";
		
	/** The Constant IFT_PROCESS_NAME. */
	public static final String IFT_PROCESS_NAME= "LocalThirdPartyTransfer";
	
	/** The Constant GET_PROCESS_EVENT_TYPE. */
	public static final String GET_PROCESS_EVENT_TYPE= "get";
	
	/** The Constant POST_PROCESS_EVENT_TYPE. */
	public static final String POST_PROCESS_EVENT_TYPE= "post";
	
	/** The Constant BILL_PAY_PROCESS_NAME. */
	public static final String BILL_PAY_PROCESS_NAME= "billPayment";
	
	/** The Constant MESSAGE_SENDER. */
	public static final String MESSAGE_SENDER= "CBS";
	
	/** The Constant EDMI. */
	public static final String EDMI= "EDMI";
	
	/** The Constant TIMEZONE_PROP_PREFIX. */
	public static final String TIMEZONE_PROP_PREFIX = "timezone.";
	
	/** The Constant TRUE. */
	public static final String TRUE = "true";
	
	/** The Constant STATIC_DATE_FLAG. */
	public static final String STATIC_DATE_FLAG = "static.date.flag";
	
	/** The Constant DELAY_TIME. */
	public static final String DELAY_TIME = "delaySecond.";
	
	/** The Constant DELAY_TIME_VALUE. */
	public static final String DELAY_TIME_VALUE = "delaySecondValue.";
	
	/** The Constant STATIC_YEAR. */
	public static final String STATIC_YEAR = "static.date.year.";
	
	/** The Constant STATIC_MONTH. */
	public static final String STATIC_MONTH = "static.date.month.";
	
	/** The Constant STATIC_DAY. */
	public static final String STATIC_DAY = "static.date.day.";
	
	/** The Constant CAPTURE_SYSTEM. */
	public static final String CAPTURE_SYSTEM = "captureSystem";
	
	
	/** The Constant MESSAGE_VERSION. */
	public static final String MESSAGE_VERSION= "1";
	
	/** The Constant PAYLOAD_FORMAT. */
	public static final String PAYLOAD_FORMAT= "BeneReq";
	
	/** The Constant IFT_PAYLOAD_FORMAT. */
	public static final String IFT_PAYLOAD_FORMAT= "fundTransferReq";
	
	/** The Constant BILLER_LIST_PAYLOAD_FORMAT. */
	public static final String BILLER_LIST_PAYLOAD_FORMAT= "billerReq";
	
	/** The Constant BILL_PAY_PAYLOAD_FORMAT. */
	public static final String BILL_PAY_PAYLOAD_FORMAT= "billPayReq";
	
	/** The Constant PAYLOAD_VERSION. */
	public static final String PAYLOAD_VERSION= "1";
	
	/** The Constant UNDERSCORE. */
	public static final String UNDERSCORE = "_";
	
	/** The Constant EMAIL_BODY. */
	public static final String EMAIL_BODY = "_EMAIL_BODY";
	
	/** The Constant EMAIL_SUBJECT. */
	public static final String EMAIL_SUBJECT = "_EMAIL_SUBJECT";
	
	/** The Constant INBOX_BODY. */
	public static final String INBOX_BODY = "_INBOX_BODY";
	
	/** The Constant INBOX_SUBJECT. */
	public static final String INBOX_SUBJECT = "_INBOX_SUBJECT";
	
	/** The Constant SMS_BODY. */
	public static final String SMS_BODY = "_SMS_BODY";
	
	/** The Constant SMS_SUBJECT. */
	public static final String SMS_SUBJECT = "_SMS_SUBJECT";
	
	/** The Constant OIDL. */
	public static final String OIDL = "OIDL";

	/** The Constant CDTL. */
	public static final String CDTL = "CDTL";

	/** The Constant PTL. */
	public static final String PTL = "PTL";
	
	/** The Constant SUCC. */
	public static final String SUCC = "SUCC";
	

	/** The Constant PSUCC. */
	public static final String PSUCC = "PSUCC";
	
	/** The Constant PSUCC. */
	public static final String PFAIL = "PFAIL";

	
	/** The Constant FAIL. */
	public static final String FAIL = "FAIL";
	
	/** The Constant RTRYF. */
	public static final String RTRYF = "RTRYF";
	
	/** The Constant PSUCC. */
	public static final String RELBKF = "RELBKF";
	
	/** The Constant MRTRY. */
	public static final String MRTRY = "MRTRY";
	/** The Constant MRTRY. */
	public static final String VISA_RTRY = "VRTRY";
	
	/** The Constant TIMEOUT. */
	public static final String TIMEOUT = "TIMEOUT";
	
	/** The Constant AGGTMOUT. */
	public static final String AGGTMOUT = "AGGTMOUT";
	
	/** The Constant RTMOUT. */
	public static final String RTMOUT = "RTMOUT";
	
	/** The Constant TIMEOUT_MSG. */
	public static final String TIMEOUT_MSG = "Your transaction has been submitted . Please wait for further notification.";
	
	/** The Constant TIMEOUT_MSG. */
	public static final String EXCEPTION_MESSAGE = "The request has been timed out. Please try again later.";
	
	
	/** The Constant MDTL. */
	private static final String MDTL = "MDTL";
	
	/** The Constant NDTL. */
	public static final String NDTL = "NDTL";
	
	/** The Constant LIMIT_ORDER_LIST. */
	public static final String[] LIMIT_ORDER_LIST = new String[]{CDTL, OIDL, NDTL};
	
	/** The Constant LIMIT_ORDER_LIST. */
	public static final String[] PER_TXN_LIMIT_ORDER_LIST = new String[]{PTL};
	
	/** The Constant MAX_LIMIT_ORDER_LIST. */
	public static final String[] MAX_LIMIT_ORDER_LIST = new String[]{MDTL};
	
	/** The Constant ZERO. */
	public static final String ZERO ="0";
	
	/** The Constant THREE_ZEROES. */
	public static final String THREE_ZEROES ="000";
	
	/** The Constant LISTENER. */
	public static final String LISTENER = "LISTENER";
	
	/** The Constant SUBMITTED. */
	public static final String SUBMITTED = "SUBMITTED";
	
	/** The Constant CONDITION_NOT_MET. */
	public static final String CONDITION_NOT_MET = "Condition not met";
	
	/** The Constant EMAIL. */
	public static final String EMAIL = "EMAIL";
	
	/** The Constant INBOX. */
	public static final String INBOX = "INBOX";
	
	/** The Constant SMS. */
	public static final String SMS = "SMS";
	
	/** The Constant DEFAULT_AGGREGATOR. */
	public static final String DEFAULT_AGGREGATOR = "SYBASE365";
	
	/** The Constant STATUS_ACTIVE. */
	public static final String STATUS_ACTIVE = "A";
	
	/** The Constant STATUS_DELETE. */
	public static final String STATUS_DELETE = "T";
	
	/** The Constant STATUS_PENDING_ACTIVE. */
	public static final String STATUS_PENDING_ACTIVE = "PA";
	
	/** The Constant STATUS_PENDING_DELETE. */
	public static final String STATUS_PENDING_DELETE = "PD";
	
	/** The Constant IMMEDIATE. */
	public static final String IMMEDIATE="IMMD";
	
	/** The Constant POST. */
	public static final String POST="POST";
	
	/** The Constant N. */
	public static final String N="N";
	
	/** The Constant SIX. */
	public static final Integer SIX=6;
	
	/** The Constant ELEVEN. */
	public static final Integer ELEVEN=11;
	
	/** The Constant ELEVEN. */
	public static final Integer THIRTEEN=13;
	
	/** The Constant MY_CACHE. */
	public static final String MY_CACHE = "myCache";
	
	/** The Constant MY_CACHE. */
	public static final String BILLER_CACHE = "BILLER_CACHE";
	
	/** The Constant APPLICATION_MESSAGE_CACHE. */
	public static final String APPLICATION_MESSAGE_CACHE = "APPLICATION_MESSAGE_CACHE";
	
	public static final String APPLICATION_MESSAGE = "APPLICATION_MESSAGE";
	
	/** The Constant NARRATION_CACHE. */
	public static final String NARRATION_CACHE = "NARRATION_CACHE";
	
	/** Narration List**/
	public static final String NARRATION_LIST = "_NARRATION_LIST";
	
	/** The Constant ACCOUNT. */
	public static final String ACCOUNT_LIST = "_ACCOUNT_LIST";
	
	/** The Constant BENE_LIST. */
	public static final String BENE_LIST = "_BENE_LIST";
	
	/** The Constant BILLER_LIST. */
	public static final String BILLER_LIST = "_BILLER_LIST";
	
	/** Biller Category List**/
	public static final String BILLER_CATEGORY_LIST = "_BILLER_CATEGORY_LIST";
	
	/** The Constant BENE_ACCOUNT. */
	public static final String BENE_ACCOUNT = "_BENE_ACCOUNT";
	
	/** The Constant CURRENCY_MAP. */
	public static final String CURRENCY_MAP = "currencyMap";
	
	/** The Constant REFERENCE_LIST. */
	public static final String REFERENCE_LIST = "referenceList";
	
	/** The Constant REFERENCE_VO. */
	public static final String REFERENCE_VO = "referenceVO";
	
	/** The Constant FTNARRATION_MAP. */
	public static final String FTNARRATION_MAP="ftNarrationMap";
	
	/** The Constant DOUBLE_ZERO. */
	public static final String DOUBLE_ZERO = "00";
	
	/** The Constant ZERO_INT. */
	public static final int ZERO_INT = 0;
	
	/** The Constant SEVEN. */
	public static final int SEVEN = 7;
	
	/** The Constant TEN. */
	public static final int TEN = 10;
	
	
	/** The Constant HUNDRED. */
	public static final int HUNDRED = 100;
	
	/** The Constant TRIPLE_NINE. */
	public static final int TRIPLE_NINE = 999;
	
	/** The Constant THIRTY. */
	public static final int THIRTY = 30;
	
	/** The Constant THREE. */
	public static final int THREE = 3;
	
	/** The Constant TWENTY_FIVE. */
	public static final int TWENTY_FIVE = 25;
	
	/** The Constant YES. */
	public static final String YES = "Y";
	
	/** The Constant YES -full String. */
	public static final String YES_Y= "YES";
	
	/** The Constant AUTHENTICATION_SUCCESSFUL. */
	public static final String AUTHENTICATION_SUCCESSFUL = "3";
	
	/** The Constant AUTHENTICATION_FAILURE. */
	public static final String AUTHENTICATION_FAILURE = "1";
	
	/** The Constant PIN_LOCKED. */
	public static final String PIN_LOCKED = "0";
	
	/** The Constant FORCE_PASSWORD_CHANGE. */
	public static final String FORCE_PASSWORD_CHANGE = "2";
	
	/** The Constant SESSION_ALREADY_EXISTS. */
	public static final String SESSION_ALREADY_EXISTS = "300";
	
	/** The Constant INVALID_USER. */
	public static final String INVALID_USER = "1";
	
	/** The Constant NA_00. */
	public static final String NA_00 = "na,00";
	
	/** The Constant ENCRYPTION. */
	public static final String ENCRYPTION = "ENCRYPTION";
	
	/** The Constant ASYNC. */
	public static final String ASYNC="ASYNC";
	
	/** The Constant SYNC. */
	public static final String SYNC="SYNC";
	
	/** The Constant DO_CHEQUE_BOOK_REQUEST. */
	public static final String DO_CHEQUE_BOOK_REQUEST = "doChequeBookRequest";
	
	/** The Constant DO_STOP_CHEQUE_REQUEST. */
	public static final String DO_STOP_CHEQUE_REQUEST = "doStopChequeRequest";
	
	/** The Constant SYSTEM. */
	public static final String SYSTEM = "SYSTEM";
	
	/** The Constant CHEQUE. */
	public static final String CHEQUE = "CHEQUE";
	
	/** The Constant ONE. */
	public static final String ONE = "1";
	
	/** The Constant SERVICE_MODE. */
	public static final String SERVICE_MODE = "SERVICE_MODE";
	
	/** The Constant DEVICE_MODE. */
	public static final String DEVICE_MODE = "DEVICE_MODE";
	
	/** The Constant USSD. */
	public static final String USSD = "USSD";
	
	/** The Constant BLACKBERRY. */
	public static final String BLACKBERRY = "BLACKBERRY";
	
	/** The Constant IPHONE. */
	public static final String IPHONE = "IPHONE";
	
	/** The Constant ANDROID. */
	public static final String ANDROID = "ANDROID";
	
	/** The Constant ON_CUST_AUTHENTICATE. */
	public static final String ON_CUST_AUTHENTICATE = "onCustAuthenticate";
	
	/** The Constant USER_STATUS. */
	public static final String USER_STATUS = "getUserStatus";
	
	/** The Constant STATEMENT. */
	public static final String STATEMENT = "STATEMENT";
	
	/** The Constant MAIL. */
	public static final String MAIL = "MAIL";
	
	/** The Constant ON_SESSION_END. */
	public static final String ON_SESSION_END = "onSessionEnd";
	
	/** The Constant GET_CREDIT_CARD_MINI_STATEMENT. */
	public static final String GET_CREDIT_CARD_MINI_STATEMENT = "getCreditCardMiniStatement";
	
	/** The Constant GET_BILLER_SERVICE_DETAILS. */
	public static final String GET_BILLER_SERVICE_DETAILS = "getBillerServiceDetails";
	
	/** The Constant GET_UTILITY_BILLER. */
	public static final String GET_UTILITY_BILLER = "getUtilityBiller";
	
	/** The Constant CUST_PIN_CHANGE. */
	public static final String CUST_PIN_CHANGE = "custPinChange";
	/** The Constant GET_CREDIT_CARD_DETAILS. */
	public static final String GET_CREDIT_CARD_DETAILS = "getCreditCardDetails";
	/** The Constant GET_MINI_STATEMENT. */
	public static final String GET_MINI_STATEMENT = "TRANSACTION_ENQUIRY";
	/** The Constant GET_ACCOUNT_BALANCE. */
	public static final String GET_ACCOUNT_BALANCE = "getAccountBalance";
	/** The Constant GET_CUST_ACCOUNT_NUMERS. */
	public static final String GET_CUST_ACCOUNT_NUMERS = "getCustAccountNumers";
	/** The Constant GET_CUST_CASA_CARD_BALANCE. */
	public static final String GET_CUST_CASA_CARD_BALANCE = "getCustCasaCardBalance";
	/** The Constant GET_THIRD_PARTY_NOMINATED_ACCOUNT_ALIASE. */
	public static final String GET_THIRD_PARTY_NOMINATED_ACCOUNT_ALIASE = "getThirdPartyNominatedAccountAliase";
	
	/** The Constant DO_STATEMENT_REQUEST. */
	public static final String DO_STATEMENT_REQUEST = "doStatementRequest";
	
	/** The Constant CUSTOMER_INFO_APPS. */
	public static final String CUSTOMER_INFO_APPS = "customerInfoApps";
	
	/** The Constant PROCESS_NAME. */
	public static final String PROCESS_NAME = "CustomerEnquiry";
	
	/** The Constant STOP_CHEQUE_PROCESS_NAME. */
	public static final String STOP_CHEQUE_PROCESS_NAME = "requestStopCheque";
	
	/** The Constant DOMAIN_TYPE. */
	public static final String DOMAIN_TYPE = "IBK";
	
	/** The Constant DOMAIN_NAME. */
	public static final String DOMAIN_NAME_AGG = "Cash";
	
	
	/** The Constant DOMAIN_NAME. */
	public static final String DOMAIN_NAME = "CoreBanking";
	
	/** The Constant TRACKING_ID. */
	public static final String TRACKING_ID = "IVR002";
	
	/** The Constant MSG_SUB_TYPE. */
	public static final String MSG_SUB_TYPE = "customerEnquiry";
	
	/** The Constant STOP_CHQ_MSG_SUB_TYPE. */
	public static final String STOP_CHQ_MSG_SUB_TYPE = "StopCheque";
	
	/** The Constant MSG_TYPE. */
	public static final String MSG_TYPE = "Customer:Enquiry";
	
	/** The Constant STOP_CHQ_MSG_TYPE. */
	public static final String STOP_CHQ_MSG_TYPE = "Cheque:Request";
	
	/** The Constant EVENT_TYPE. */
	public static final String EVENT_TYPE = "Insert";
	
	/** The Constant EVENT_TYPE. */
	public static final String REVERSE_TARNSFER_EVENT_TYPE = "TransactionPosting";
	
	/** The Constant CAPTURING_SYSTEM. */
	public static final String CAPTURING_SYSTEM = "eBBS";
	
	/** The Constant DO_EXCHANGE_REQUEST. */
	public static final String DO_EXCHANGE_REQUEST = "doExchangeRate";
	
	/** The Constant DO_OPERATING_ACC_REQUEST. */
	public static final String DO_OPERATING_ACC_REQUEST = "doOperatingAccountChange";
	
	/** The Constant DO_DEFAULT_ACC_REQUEST. */
	public static final String DO_DEFAULT_ACC_REQUEST = "doDefaultAccountChange";
	
	/** The Constant GET_CUSTOMER_UTILITY. */
	public static final String GET_CUSTOMER_UTILITY = "getCustomerUtilityCompanyInfo";
	
	/** The Constant NO_OF_DAYS_TO_GET_MINI_STATEMENT. */
	public static final String NO_OF_DAYS_TO_GET_MINI_STATEMENT = "numOfDaysToGetMiniStatement";
	
	/** The Constant MULTISESSION. */
	public static final String MULTISESSION = "MULTISESSION";
	
	/** The Constant SESSION_VALIDATION. */
	public static final String SESSION_VALIDATION = "SESSION_VALIDATION";
	
	/** The Constant FALSE. */
	public static final String FALSE ="false";
	
	/** The Constant FAILURE. */
	public static final String FAILURE = "FAILURE";
	
	/** The Constant ADC_TIMEOUT. */
	public static final String ADC_TIMEOUT = "ADCTimeout";
	
	/** The Constant COLON. */
	public static final String COLON = ":";
	
	/** The Constant SESSION_IS_ACTIVE. */
	public static final String SESSION_IS_ACTIVE = "You already logged in, please logout if any other session is active";
	
	/** The Constant DO_FUND_TRANSFER. */
	public static final String DO_FUND_TRANSFER = "doFundsTransfer";
	
	/** The Constant TRANSFER_FUND. */
	public static final String TRANSFER_FUND = "transferFund";
	
	/** The Constant SOURCE_SYSTEM_NAME. */
	public static final String SOURCE_SYSTEM_NAME = "ADC";
	
	/** The Constant SOURCE_SYSTEM. */
	public static final String SOURCE_SYSTEM = "SRM";
	
	/** The Constant SRM_SOURCE_SYSTEM_NAME. */
	public static final String SRM_SOURCE_SYSTEM_NAME = "SRM";
	
	/** The Constant FLAG_NO. */
	public static final String FLAG_NO = "N";
	
	/** The Constant LOCATION. */
	public static final String LOCATION = "location";
	/** The Constant CPG. */
	public static final String CPG = "SRM";
	/** The Constant APP_NAME. */
	public static final String APP_NAME = "appName";
	/** The Constant CLASS. */
	public static final String CLASS = "class";
	
	/** The Constant BROWSER. */
	public static final String BROWSER = "BROWSER";
	
	/** The Constant FIVE. */
	public static final String FIVE = "5";
	
	/** The Constant FOUR. */
	public static final String FOUR = "4";
	
	/** The Constant TWO. */
	public static final String TWO = "2";
	
	/** The Constant THREE_STR. */
	public static final String THREE_STR = "3";
	
	/** The Constant Inquiry. */
	public static final String ENQUIRY = "ENQ";
	
	/** The Constant TILDE. */
	public static final String TILDE = "~";
	
	/** The Constant SPACE. */
	public static final String SPACE = " ";
	
	/** The Constant REQUEST_IS_NOT_VALID. */
	public static final String REQUEST_IS_NOT_VALID = "Request is invalid";
	
	/** The Constant RESPONSE_IS_NOT_VALID. */
	public static final String RESPONSE_IS_NOT_VALID = "Invalid Response/technical error occurred in response processing";
	
	/** The Constant DR2. */
	public static final String DR2 = " DR";
	
	/** The Constant CR2. */
	public static final String CR2 = " CR";
	
	/** The Constant COMMA. */
	public static final String COMMA = ",";
	
	/** The Constant PIPE. */
	public static final String PIPE = "|";
	
	/** The Constant CR. */
	public static final String CR = "CR~";
	
	/** The Constant DR. */
	public static final String DR = "DR~";
	
	/** The Constant D. */
	public static final String D = "D";
	
	/** The Constant P  Passive Status. */
	public static final String P = "P";
	
	/** The Constant D. */
	public static final String SEVENTY_TWO = "72";
	
	/** The Constant DEBIT. */
	public static final String DEBIT = " D ";
	
	/** The Constant CREDIT. */
	public static final String CREDIT = " C ";
	
	/** The Constant HASH. */
	public static final String HASH = "##";
	
	/** The Constant DD_MMM. */
	public static final String DD_MMM = "dd MMM";
	
	/** The Constant DATE_FORMAT. */
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	
	/** The Constant TXN_ENQUIRY_FOR. */
	public static final String TXN_ENQUIRY_FOR = "Txn Enquiry for||";
	
	/** The Constant CLOSED. */
	public static final String CLOSED = "C";
	
	/** The Constant COMPLETED. */
	public static final String COMPLETED = "C";
	
	/** The Constant OPEN. */
	public static final String OPEN = "O";
	
	/** The Constant DATE_TIME_FORMAT. */
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SZ";
	
	/** The Constant DECIMAL_ONE. */
	public static final String DECIMAL_ONE = "1.0";
	
	/** The Constant DECIMAL_SIX. */
	public static final String DECIMAL_SIX = "6.0";
	/** The Constant XML. */
	public static final String XML = "XML";
	
	/** The Constant REQUEST_STOP_CHEQUE. */
	public static final String REQUEST_STOP_CHEQUE = "requestStopCheque";
	/** The Constant ACC_STATUS_FLAG_MAP. */
	public static final String ACC_STATUS_FLAG_MAP = "accStatusFlagMap";
	
	/** The Constant ACC_STATUS_BLOCK_FLAG_MAP. */
	public static final String ACC_STATUS_BLOCK_FLAG_MAP = "accStatusBlockFlagMap";
	/** The Constant CURR_CODE_FLAG_MAP. */
	public static final String CURR_CODE_FLAG_MAP = "currCodeFlagMap";
	
	/** The Constant CURR_CODE_BLOCK_FLAG_MAP. */
	public static final String CURR_CODE_BLOCK_FLAG_MAP = "currCodeBlockFlagMap";
	/** The Constant OPS_INS_FLAG_MAP. */
	public static final String OPS_INS_FLAG_MAP = "opsInsFlagMap";
	
	/** The Constant OPS_INS_BLOCK_FLAG_MAP. */
	public static final String OPS_INS_BLOCK_FLAG_MAP = "opsInsBlockFlagMap";
	/** The Constant CURR_CODE_MAP. */
	public static final String CURR_CODE_MAP = "currCodeMap";
	/** The Constant ACC_CODE_FLAG_MAP. */
	public static final String ACC_CODE_FLAG_MAP = "accCodeFlagMap";
	
	/** The Constant ACC_CODE_BLOCK_FLAG_MAP. */
	public static final String ACC_CODE_BLOCK_FLAG_MAP = "accCodeBlockFlagMap";
	/** The Constant ACCOUNT_STATUS_MAP. */
	public static final String ACCOUNT_STATUS_MAP = "accountStatusMap";
	
	/** The Constant BLOCK_CODE_MAP. */
	public static final String BLOCK_CODE_MAP = "blockCodeMap";
	
	/** The Constant BLOCK_CODE_FLAG_MAP. */
	public static final String BLOCK_CODE_FLAG_MAP = "blockCodeFlagMap";
	
	

	/** The Constant ACC_CODE_MAP. */
	public static final String ACC_CODE_MAP = "accCodeMap";
	/** The Constant OPS_INS_MAP. */
	public static final String OPS_INS_MAP = "opsInsMap";
	
	/** The Constant ALL_ASTERIK. */
	public static final String ALL_ASTERIK = ".*";
	
	/** The Constant PIPE_REGEX. */
	public static final String PIPE_REGEX = "\\|";
	
	/** The Constant WHITELIST. */
	public static final String WHITELIST = "W";
	
	/** The Constant BLOCKLIST. */
	public static final String BLOCKLIST = "B";
	
	/** The Constant SRC. */
	public static final String SRC = "SRC";

	/** The Constant DEST. */
	public static final String DEST = "DEST";

	/** The Constant KES. */
	public static final String KES = "KES";

	/** The Constant IFT_KEY. */
	public static final String IFT_KEY = "IFT";

	/** The Constant OAT_KEY. */
	public static final String OAT_KEY = "OAT";

	/** The Constant SCB. */
	public static final String SCB = "SCB";

	/** The Constant IMMD. */
	public static final String IMMD = "IMMD";

	/** The Constant SUBM. */
	public static final String SUBM = "SUBM";

	/** The Constant CASA. */
	public static final String CASA = "CASA";
	
	/** The Constant ACCOUNT. */
	public static final String ACCOUNT = "Account";

	/** The Constant BILL. */
	public static final String BILL = "BILL";
	
	/** The Constant SELECT. */
	public static final String SELECT = "Select";

	/** The Constant EN. */
	public static final String EN = "EN";

	/** The Constant EMR. */
	public static final String EMR = "EMR";

	/** The Constant MOB. */
	public static final String MOB = "MOB";

	/** The Constant _00800. */
	public static final String _00800 = "00800";



	/** The Constant OED. */
	public static final String OED = "OED";

	/** The Constant REG. */
	public static final String REG = "REG";

	/** The Constant _1001. */
	public static final String _1001 = "1001";

	/** The Constant SUSPENSE_ACCOUNT_CURRENCY. */
	public static final String SUSPENSE_ACCOUNT_CURRENCY = "SUSPENSE_ACCOUNT_CURRENCY";

	/** The Constant SUSPENSE_ACCOUNT. */
	public static final String SUSPENSE_ACCOUNT = "SUSPENSE_ACCOUNT";

	/** The Constant REQUEST_ID. */
	public static final String REQUEST_ID = "{RequestId}";

	/** The Constant FROM_ACCOUNT_NO. */
	public static final String FROM_ACCOUNT_NO = "{FromAccountNo}";

	/** The Constant MOBILE_NUMBER. */
	public static final String MOBILE_NUMBER = "{MobileNumber}";

	/** The Constant TO_ACCOUNT_NO. */
	public static final String TO_ACCOUNT_NO = "{ToAccountNo}";

	/** The Constant PAY_BILL2. */
	public static final String PAY_BILL2 = "payBill";

	/** The Constant CORE_BANKING_INVOICE. */
	public static final String CORE_BANKING_INVOICE = "CoreBanking:Invoice";

	/** The Constant TRANSACTION_POSTING. */
	public static final String TRANSACTION_POSTING = "TransactionPosting";
	
	/** The Constant GET. */
	public static final String GET = "Get";

	
	/** The Constant PUT . */
	public static final String PUT = "put";
	
	/** The Constant PAY_BILL. */
	public static final String PAY_BILL = "PayBill";
	
	/** The Constant TRANSFER_FUND. */
	public static final String REVERSE_TRANSACTION = "reverseTransaction";
	
		/** The Constant SAFARICOM. */
	public static final String SAFARICOM = "SAFARICOM";
	
	/** The Constant ATP. */
	public static final String ATP = "ATP";

	/** The Constant PRIORITY_ORDER. */
	public static final String PRIORITY_ORDER = "PRIORITY_ORDER";

	/** The Constant SEGMENT. */
	public static final String SEGMENT = "SEGMENT";

	/** The Constant SERVICE_PERF_LOG. */
	public static final String SERVICE_PERF_LOG = "ServicePerfLog";

	/** The Constant _07. */
	public static final String _07 = "07";

	/** The Constant ADCUSBILRQ. */
	public static final String ADCUSBILRQ = "ADCUSBILRQ";

	/** The Constant BLOCK. */
	public static final String BLOCK = "BLOCK";
	
	/** The Constant BLOCK. */
	public static final String BRTRY = "BRTRY";
	
	/** The Constant CCBLOCK. */
	public static final String CCBLOCK = "CCBLOCK";
	
	/** The Constant CCBLOCK. */
	public static final String CCBRTRY = "CCBRTRY";

	/** The Constant JOB. */
	public static final String JOB = "JOB";

	/** The Constant CCSUCC. */
	public static final String CCSUCC = "CCSUCC";
	
	/** The Constant CCFAIL. */
	public static final String CCFAIL = "CCFAIL";

	/** The Constant MODIFY_ACCOUNT. */
	public static final String MODIFY_ACCOUNT = "modifyAccount";

	/** The Constant MODIFY_BLOCK_DEXTER. */
	public static final String MODIFY_BLOCK_DEXTER = "modifyBlock";

	//public static String VISA_ACCOUNT_VERIFY="enquireAccountVisa";
	/** The master account verify. */
	public static String MASTER_ACCOUNT_VERIFY="enquireAccountMaster";

	/** The master payment reversal. */
	public static String MASTER_PAYMENT_REVERSAL="transferReversalMasterCard";

	//	public static final String PAY_VISA_PAYMENT = "visaPayment";
	//private static String PAY_VISA_PAYMENT_ENQUIRE="enquireTransactionVisa";
	/** The master card payment. */
	public static String MASTER_CARD_PAYMENT="transferFundsMasterCard";

	/** The Constant INTERNET. */
	public static final String INTERNET = "INTERNET";

	/** The Constant PMT_NEW. */
	public static final String PMT_NEW = "PmtNew";

	/** The Constant CCARD. */
	public static final String CCARD = "CCARD";

	/** The Constant ACTDEB. */
	public static final String ACTDEB = "ACTDEB";
	/**
	 * Instantiates a new common constants.
	 */
	private CommonConstants() { }


	/** The Constant PROCESSING_MODE_POST. */
	public static final int PROCESSING_MODE_POST=0;
	
	
	/** The Constant PROCESSING_MODE_REVERSAL. */
	public static final int PROCESSING_MODE_REVERSAL=1;
	
	/** The Constant DO_BILLPAYMENT_REQUEST. */
	public static final String DO_BILLPAYMENT_REQUEST = "doBillpayment";
	
	/** The Constant NA. */
	public static final String NA="NA";
	
	/** The Constant DO_BILLPAYMENT_REQUEST. */
	public static final String DO_BANKTOMPESA_REQUEST = "doBankToMpesaRequest";
	
	/** The Constant DO_MPESATOBANK_REQUEST. */
	public static final String DO_MPESATOBANK_REQUEST = "doMpesaToBankRequest";

	/** The Constant B2M. */
	public static final String B2M = "B2M";
	
	/** The Constant M2B. */
	public static final String M2B = "M2B";

	/** The Constant MPHESA_DEST_ACCOUNT_DTLS. */
	public static final String MPHESA_DEST_ACCOUNT_DTLS = "B2M_DEST";
	
	/** The Constant M2B_DEST_ACCOUNT_DTLS. */
	public static final String M2B_DEST_ACCOUNT_DTLS = "M2B_DEST";
	

	/** The Constant B2M. */
	public static final String B2A = "B2A";
	
	/** The Constant M2B. */
	public static final String A2B = "A2B";

	/** The Constant MPHESA_DEST_ACCOUNT_DTLS. */
	public static final String B2A_DEST_ACCOUNT_DTLS = "B2A_DEST";
	
	/** The Constant M2B_DEST_ACCOUNT_DTLS. */
	public static final String A2B_DEST_ACCOUNT_DTLS = "A2B_DEST";
	
	/** The Constant DO_AIRTIMETOPUP_REQUEST. */
	public static final String DO_AIRTIMETOPUP_REQUEST = "doAirTimeTopup";
	
	/** The Constant DEVICE_NOT_SUPPORT. */
	public static final String DEVICE_NOT_SUPPORT = "Device Not Supported";

	/** The Constant DO_AIRTEL_TO_BANK. */
	public static final String DO_AIRTEL_TO_BANK = "fundTransferMobileToAccount";
	
	/** The Constant DO_BANK_TO_AIRTEL. */
	public static final String DO_BANK_TO_AIRTEL = "fundTransferAccountToMobile";
	
	/** The Constant EBBS_CHANNEL_ID. */
	public static final String EBBS_CHANNEL_ID = "0009";
	
	/** The Constant EBBS_CHANNEL_ID. */
	public static final String TRANSACTION_BRANCH = "00800";
	
	/** The Constant TRANSACTION_BANK_CODE. */
	public static final String TRANSACTION_BANK_CODE = "7144";
	
	/** The Constant TRANSACTION_ROUTING_NUMBER. */
	public static final String TRANSACTION_ROUTING_NUMBER = "12345";
	
	/** The Constant TIMEOUT_CODE. */
	public static final String TIMEOUT_CODE="-1";
	
	/** The Constant SOCKET_TIMEOUT. */
	public static final String SOCKET_TIMEOUT = "SocketTimeoutException";
	
	/** The Constant NO_OPERATIVE_ACCOUNT. */
	public static final String NO_OPERATIVE_ACCOUNT ="You do not have any valid accounts. Please contact customer care";

	/** The Constant SERVICE_NAME_KEY. */
	public static final String SERVICE_NAME_KEY = "serviceName";
	
	/*** The Constant MASK_EXCEPT_RIGHT. */
	public static final String MASK_EXCEPT_RIGHT="ER";
	
	/*** The Constant EXCEPT_LEFT. */
	public static final String MASK_EXCEPT_LEFT="EL";
	
	/*** The Constant MASK_ALL. */
	public static final String MASK_ALL="AL";
	
	/*** The Constant MASK_MIDDLE. */
	public static final String MASK_MIDDLE="MD";
	/** The Constant REFERENCE_LIST. */
	public static final String BILLER_VALID_FIELD_LIST = "billerValidFieldList";
	
	/** The Constant CONSUME_NO. */
	public static final String CONSUME_NO = "consumerNo";
	
	/** The Constant ACTIVE. */
	public static final String ACTIVE= "A";
	
	
	
	/** The Constant DO_BILLPRESENTMENT_REQUEST. */
	public static final String DO_BILLPRESENTMENT_REQUEST = "doBillPresentment";

	/** The Constant GETPAYMENT_EVENT_TYPE. */
	public static final String GETPAYMENT_EVENT_TYPE = "enquiry";

	/** The Constant GETPAYMENT_PROCESS_NAME. */
	public static final String GETPAYMENT_PROCESS_NAME = "getPaymentDetails";

	/** The Constant GETPAYMENT_CAPTURING_SYSYTEM. */
	public static final String GETPAYMENT_CAPTURING_SYSYTEM = "Cellulant";

	/** The Constant AGGREGATOR_DOMAIN_NAME. */
	public static final String AGGREGATOR_DOMAIN_NAME = "Cash";

	/** The Constant AGGREGATOR_DOMAIN_TYPE. */
	public static final String AGGREGATOR_DOMAIN_TYPE = "Payment";
	
	/** The Constant BILLER_PRESENTMENT_MAP. */
	public static final String BILLER_PRESENTMENT_MAP = "billerPresentmentMap";
	
	/** The Constant BILLER_VALID_FIELD_MAP. */
	public static final String BILLER_VALID_FIELD_MAP = "billerValidFieldMap";

	/** The Constant TXN_COUNT. */
	public static final String TXN_COUNT = "10";
	
	/** The Constant SERVICE_INDICATOR. */
	public static final String SERVICE_INDICATOR = "1";
	
	/** The Constant AGGREGATOR_SUBTYPE. */
	public static final String AGGREGATOR_SUBTYPE = "postPaymentRequest";
	
	/** The Constant AGGREGATOR_PROCESS_NAME. */
	public static final String AGGREGATOR_PROCESS_NAME = "getPaymentDetails"; 
	
	/** The Constant AGGREGATOR_MESSAGE_TYPE. */
	public static final String AGGREGATOR_MESSAGE_TYPE = "Mobile Invoice";
	
	/** The Constant AGGREGATOR_CAPTURING_SYSYTEM. */
	public static final String AGGREGATOR_CAPTURING_SYSYTEM = "Cellulant";
	
	/** The Constant AGGREGATOR_EVENT_TYPE. */
	public static final String AGGREGATOR_EVENT_TYPE = "create";
	
	/** The Constant REVS. */
	public static final String REVS="REVS";
	
	/** The Constant REVT. */
	public static final String REVT="REVT";
	
	/** The Constant REVF. */
	public static final String REVF = "REVF";

	/** The Constant WACK. */
	public static final String WACK = "WACK";
	
	/** The Constant PACK. */
	public static final String PACK = "PACK";
	
	/** The Constant POST_SUCC. */
	public static final String POST_SUCC = "139";
	
	/** The Constant AUTH_SUCC. */
	public static final String AUTH_SUCC = "131";
	
	/** The Constant NEGATIVE. */
	public static final String NEGATIVE = "-1";

	/** The Constant NOTIF_STATUS_SUCC. */
	public static final String NOTIF_STATUS_SUCC = "183|217";

	/** The Constant CHAR_Y. */
	public static final Character CHAR_Y = 'Y';
	
	/** The Constant DB_AUTH. */
	public static final String DB_AUTH="DBAuth";
	
	/** The Constant _300. */
	public static final String _300 = "300";
	
	/** The Constant _301. */
	public static final String _301 = "301";
	/** The Constant ONE_INT. */
	public static final int ONE_INT = 1;
	
	/** The Constant NO. */
	public static final String NO="NO";
	
	/** The Constant REGISTER_CUSTOMER. */
	public static final String REGISTER_CUSTOMER = "registerCustomer";

	/** The Constant REGISTER_CUSTOMER. */
	public static final String GET_REGISTRATION_DETAILS = "getRegistrationDetails";
	
	/** The Constant PAYMENT_BILL. */
	public static final String MAKE_BILL_PAYMENT = "makeBillPayment";
	/** The Constant PAYMENT_BILL. */
	public static final String BILL_PAYMENT_INSRT = "makeBillInsert";
	
	/** The Constant CARD_ENQ. */
	public static final String MAKE_CARD_ENQUIRY = "makeCardEnquiry";

	/** The Constant REGISTER_CUSTOMER. */
	public static final String ONLINE_PIN_CHANGE = "onlinePinChange";

	/** The Constant VIEW. */
	public static final String VIEW = "VIEW";
	
	/** The Constant UPDATE. */
	public static final String UPDATE = "UPDATE";
	
	/** The Constant INSERT. */
	public static final String INSERT = "INSERT";
	
	/** The Constant ADC_BO_MASTER. */
	public static final String TYPE_ADC_BO_MASTER = "ADC_BO_MASTER";
	/** The Constant INTERNAL_CUSTOMER. */
	public static final String REFCD_INTERNAL_CUSTOMER = "INTERNAL_CUSTOMER";
	/** The Constant ALLOWED_OPERATING_INSTRUCTION. */
	public static final String REFCD_ALLOWED_OPERATING_INSTRUCTION = "ALLOWED_OPERATING_INSTRUCTION";
	/** The Constant ALLOWED_CURRENCY_CODES. */
	public static final String REFCD_ALLOWED_CURRENCY_CODES = "ALLOWED_CURRENCY_CODES";
	/** The Constant ALLOWED_SEGMENTS. */
	public static final String REFCD_ALLOWED_SEGMENTS = "ALLOWED_SEGMENTS";
	
	/** The Constant ALLOWED_COUNTRY_MOBILE_CODE. */
	public static final String ALLOWED_COUNTRY_MOBILE_CODE = "allowed.country.mobile.num";
	
	/** The Constant SUSPENSE_ACCOUNT_CURRENCY. */
	public static final String B2M_TXN_REF1 = "TXN_REF1";

	/** The Constant GET_TRANSACTION_STATUS_SUB_TYPE_NAME. */
	public static final String GET_TRANSACTION_STATUS_SUB_TYPE_NAME = "getTransaction";

	/** The Constant GET_TRANSACTION_STATUS_PROCESSNAME. */
	public static final String GET_TRANSACTION_STATUS_PROCESSNAME = "Transaction";

	/** The Constant GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME. */
	public static final String GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME = "CoreBanking:TransactionServices";
	
	/** The Constant GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME. */
	public static final String INWARD_TRANSACTION_STATUS_MESSAGE_TYPE_NAME = "CoreBanking:Transaction";
	
	/** The Constant GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME. */
	public static final String CARD_AUTHENTICATION_MESSAGE_TYPE_NAME = "CoreBanking:CardPurchaseTransaction";

	/** The Constant GET_TRANSACTION_STATUS_EVENT_TYPE. */
	public static final String GET_TRANSACTION_STATUS_EVENT_TYPE = "TransactionEnquiry";

	/** The Constant TRANSACTION_STATUS_ENQUIRY. */
	public static final String TRANSACTION_STATUS_ENQUIRY = "transactionStatusEnquiry";
	
	/** The Constant TRANSACTION_STATUS_ENQUIRY. */
	public static final String PAYMENT_STATUS_ENQUIRY = "getPaymentStatus";

	/** The Constant INTERMEDIATE. */
	public static final String INTERMEDIATE = "INTER";

	/** The Constant SRMADC. */
	public static final String SRMADC= "SRM ADC";
	
	/** The Constant SERVICE_REQUEST. */
	public static final String SERVICE_REQUEST="SERVICE REQUEST";
	/** The Constant DO_STOP_CHEQUE_REQUEST. */
	public static final String DO_ON_SERVICE_REQUEST = "onServiceRequest";
	
	/** VPP Changes *. */
	public static final String VISA="VISA";
	
	/** The Constant MASTER. */
	public static final String MASTER="MASTER";
	
	/** The Constant ACQUIRING_BIN. */
	public static final String ACQUIRING_BIN="ACQUIRING_BIN";
	
	/** The Constant REQUEST_CHAR. */
	public static final String REQUEST_CHAR="-";
	
	/** The Constant REQUEST_REPLACE. */
	public static final String REQUEST_REPLACE="";
	
	/** The Constant BUSINESS_APPID. */
	public static final String BUSINESS_APPID="BUSINESS_APPID";
	
	/** The Constant SOURCE_FUND. */
	public static final String SOURCE_FUND="SOURCE_FUND";
	
	/** The Constant CARD_ACCEPTOR_NAME. */
	public static final String CARD_ACCEPTOR_NAME="CARD_ACP_NAME";
	
	/** The Constant CARD_ACCEPTOR_CITY. */
	public static final String CARD_ACCEPTOR_CITY="CARD_ACP_CITY";
	public static final String CARD_ACCEPTOR_COUNTRY="CARD_ACP_COUNTRY";

	/** The Constant PROCESSOR_ID. */
	public static final String PROCESSOR_ID="PROCESSOR_ID";
	
	
	
	/** The Constant COUNTRY_CODE. */
	public static final String COUNTRY_CODE="COUNTRY_CODE";
	
	/** The Constant COUNTRY_CODE. */
	public static final String CITY_NAME="CITY_NAME";
	/** The Constant COUNTRY_CODE_NUMERIC. */
	public static final String COUNTRY_CODE_NUMERIC="COUNTRY_CODE_NUM";
	
	/** The Constant CURRENCY_NUMERIC. */
	public static final String CURRENCY_NUMERIC="CURRENCY_CODE_NUM";
	
	/** The Constant TRANS_DESC. */
	public static final String TRANS_DESC="TRANS_DESC";
	
	/** The Constant ROUTE_TXN_NUM. */
	public static final String ROUTE_TXN_NUM="ROUTE_TXN_NUM";
	
	/** The Constant SENDER_CNTRY_CD. */
	public static final String SENDER_CNTRY_CD="SENDER_CNTRY_CD";
	
	/** The Constant SENDER_CODE. */
	public static final String SENDER_CODE="SENDER_CODE";
	
	/** The Constant MASTER_CARD. */
	public static final String MASTER_CARD="5";
	
	/** The Constant DATEFORMAT. */
	public final static String DATEFORMAT="yyyyDHH";
	
	/** The Constant VISA_CARD. */
	public static final String VISA_CARD="4";
	//Header
	/** The Constant CAPTURING_SYSTEM_VPP. */
	public static final String CAPTURING_SYSTEM_VPP="IBANK";
	
	/** The Constant VM_PAYMENT_VERSION. */
	public static final String VM_PAYMENT_VERSION="1.0";
	
	/** The Constant EBBS_PAYMENT. */
	public static final String PAYMENT="payment";
	
	/** The Constant EBBS_PAYMENT_VERSION. */
	public static final String EBBS_PAYMENT_VERSION="2.8";
	
	/** The Constant VM_PAYMENT. */
	public static final String VM_PAYMENT="Card Payment";
	
	/** The Constant CHANNEL_KEY. */
	public static final String CHANNEL_KEY="CHANNEL";
	
	/** The Constant REQUESTID_KEY. */
	public static final String REQUESTID_KEY="REQUEST_ID";
	
	/** The Constant CURRENCY_CODE_NUM. */
	public static final String CURRENCY_CODE_NUM="CURRENCY_CODE_NUM";
	
	/** The Constant SUBTYPE_KEY. */
	public static final String SUBTYPE_KEY="SUBTYPE";
	
	/** The Constant SUBTYPE_NAME_VISA_RETRY. */
	public static final String SUBTYPE_NAME_VISA_RETRY="enquireTransactionVisa";
	
	/** The Constant SUBTYPE_NAME_MASTER_PAYMENT. */
	public static final String SUBTYPE_NAME_MASTER_PAYMENT="transferFundsMasterCard";
	
	/** The Constant SUBTYPE_NAME_MASTER_REVERSAL. */
	public static final String SUBTYPE_NAME_MASTER_REVERSAL="transferReversalMasterCard";
	
	/** The Constant EBBS_CREATE_BLK_PAYMENT. */
	public static final String EBBS_CREATE_BLK_PAYMENT="CoreBanking:AccountService";
	
	/** The Constant MODIFY_BLOCK. */
	public static final String MODIFY_BLOCK="CoreBanking:Account";
	//public static final String CREATE_BLOCK_TYPE="CoreBanking:AccountService";
	/** The Constant EBBS_DOMAIN_NAME. */
	public static final String EBBS_DOMAIN_NAME="CoreBanking";
	
	/** The Constant VM_DOMAIN_NAME. */
	public static final String VM_DOMAIN_NAME="Cash";
	
	/** The Constant VM_SUB_DOMAIN_NAME. */
	public static final String VM_SUB_DOMAIN_NAME="Payment";
	
	/** The Constant POSSIBLE_DUPLICATE_FALSE. */
	public static final String POSSIBLE_DUPLICATE_FALSE="FALSE";
	
	/** The Constant EBBS. */
	public static final String EBBS="eBBS";
	
	/** The Constant CCMS. */
	public static final String CARD_AUTHORIZE="cardAuthorize";
	
	/** The Constant CCMS. */
	public static final String CARD_AUTHORIZE_REVERSE="authorizeReversal";
	/** The Constant VISA_MASTER. */
	public static final String VISA_MASTER="VM";
	
	/** The Constant SUBTYPE_NAME_VISA_PAYMENT. */
	public static final String SUBTYPE_NAME_VISA_PAYMENT="transferFundsVisa";
	
	/** The Constant SUBTYPE_NAME_VISA_ACC_ENQ. */
	public static final String SUBTYPE_NAME_VISA_ACC_ENQ="enquireAccountVisa";
	
	/** The Constant SUBTYPE_NAME_MASTER_ACC_ENQ. */
	public static final String SUBTYPE_NAME_MASTER_ACC_ENQ="enquireAccountMasterCard";
	
	/** The Constant SUBTYPE_NAME_CREATE_BLOCK. */
	public static final String SUBTYPE_NAME_CREATE_BLOCK="createBlock";
	
	/** The Constant SUBTYPE_NAME_MODIFY_BLOCK. */
	public static final String SUBTYPE_NAME_MODIFY_BLOCK="modifyBlock";
	
	/** The Constant SUBTYPE_NAME_ENQUIRY_BLOCK. */
	public static final String SUBTYPE_NAME_ENQUIRY_BLOCK="accountEnquiry";
	
	/** The Constant MASTER_RESP_CD. */
	public static final  String MASTER_RESP_CD="ResponseCode";
	
	/** The Constant MASTER_RESP_DESC. */
	public static final  String MASTER_RESP_DESC="ResponseDescription";
	
	/** The Constant MASTER_RESP_ERR_DTL. */
	public static final  String MASTER_RESP_ERR_DTL="ErrorDetailCode";
	
	/** The Constant MASTER_CARD_ELIGIBLE. */
	public static final  String MASTER_CARD_ELIGIBLE="TRUE";
	
	/** The Constant EDMI_PROCESS_NAME. */
	public static final  String EDMI_PROCESS_NAME="PROCESS_NAME";
	
	/** The Constant VISA_PYMT_PROCESS_NAME. */
	public static final  String VISA_PYMT_PROCESS_NAME="transferFundsVisaRequest";
	
	/** The Constant MASTER_PYMT_PROCESS_NAME. */
	public static final  String MASTER_PYMT_PROCESS_NAME="transferFundsMasterCard";
	
	/** The Constant MASTER_PYMT_REVERSAL_PROCESS_NAME. */
	public static final  String MASTER_PYMT_REVERSAL_PROCESS_NAME="transferReversalMasterCard";
	
	/** The Constant VISA_ACC_ENQ_PROCESS_NAME. */
	public static final  String VISA_ACC_ENQ_PROCESS_NAME="enquireAccountVisaRequest";
	
	/** The Constant EDMI_EVENT_TYPE. */
	public static final  String EDMI_EVENT_TYPE="EVENT_TYPE";
	
	/** The Constant EVENT_TYPE_ENQ. */
	public static final  String EVENT_TYPE_ENQ="enq";
	
	/** The Constant EVENT_TYPE_PYMT. */
	public static final  String EVENT_TYPE_PYMT="txn";
	
	/** The Constant TRACTING_ID. */
	public static final  String TRACTING_ID="TRACTING_ID";
	
	/** The Constant VISA_PYMT_TRACTING_ID. */
	public static final  String VISA_PYMT_TRACTING_ID="transferFunds-visa-";
	
	/** The Constant MASTER_ACC_ENQ_TRACTING_ID. */
	public static final  String MASTER_ACC_ENQ_TRACTING_ID="Enq-Account-master-";
	
	/** The Constant MASTER_PYMT_TRACTING_ID. */
	public static final  String MASTER_PYMT_TRACTING_ID="transferFunds-master-";
	
	/** The Constant MASTER_PYMT_REVERSAL_TRACTING_ID. */
	public static final  String MASTER_PYMT_REVERSAL_TRACTING_ID="transferReversal-master-";
	
	/** The Constant EDMI_CAPTURING_SYSTEM. */
	public static final  String EDMI_CAPTURING_SYSTEM="CAPTURING_SYSTEM";
	
	/** The Constant VISA_HEADER. */
	public static final String VISA_HEADER="Visa";
	
	/** The Constant MASTER_HEADER. */
	public static final String MASTER_HEADER="Master";
	
	/** The Constant VISA_TXN_ENQ_PROCESS_NAME. */
	public static final  String VISA_TXN_ENQ_PROCESS_NAME="enquireTransactionVisa";
	
	/** The Constant VISA_TXN_ENQ_TRACTING_ID. */
	public static final  String VISA_TXN_ENQ_TRACTING_ID="enquireTransaction-visa-";

	/** The Constant VISA_ACC_ENQ_TRACTING_ID. */
	public static final  String VISA_ACC_ENQ_TRACTING_ID="Enq-Account-visa-";
	
	/** The Constant EBBS_CREATE_ACC_TRACTING_ID. */
	public static final  String EBBS_CREATE_ACC_TRACTING_ID="ADDIT";
	
	/** The Constant EVENT_TYPE_CREATE_BLK. */
	public static final  String EVENT_TYPE_CREATE_BLK="Create";
	
	/** The Constant EVENT_TYPE_MODIFY_BLK. */
	public static final  String EVENT_TYPE_MODIFY_BLK="Modify";
	
	/** The Constant MESSAGE_TYPE. */
	public static final  String MESSAGE_TYPE="MESSAGE_TYPE";
	
	/** The Constant MODIFY_BLK_MESSAGE_TYPE. */
	public static final  String MODIFY_BLK_MESSAGE_TYPE="CoreBanking:Account";
	
	/** The Constant ACC_BLK_ENQ_MESSAGE_TYPE. */
	public static final  String ACC_BLK_ENQ_MESSAGE_TYPE="Account:Enquiry";
	
	/** The Constant OPERATION_BLK_ENQ. */
	public static final  String OPERATION_BLK_ENQ="blockEnquiry";
	
	//Status
	/** The Constant TIME_OUT. */
	//public static final String TIME_OUT="T";
	
	/** The Constant FAILED. */
	public static final String FAILED="FAIL";
	
	/** The Constant FAILED. */
	public static final String FAILED_STAT="FAILED";
	
	/** The Constant SUCCESS. */
	public static final String SUCCESS="SUCCESS";
	
	/** The Constant NEW. */
	public static final String NEW="NEW";
	
	/** The Constant VISA_PAYMENT. */
	public static final String VISA_PAYMENT="VP";
	
	/** The Constant MASTER_PAYMENT. */
	public static final String MASTER_PAYMENT="MP";
	
	/** The Constant MASTER_REVERSAL. */
	public static final String MASTER_REVERSAL="MR";
	
	/** The Constant CREATE_BLOCK. */
	public static final String CREATE_BLOCK="CB";
	
	/** The Constant AGG_POST. */
	public static final String AGG_POST="AGP";
	
	/** The Constant DELETE_BLOCK. */
	public static final String DELETE_BLOCK="DB";
	
	/** The Constant RELEASE_BLOCK. */
	public static final String RELEASE_BLOCK="RB";
	
	/** The Constant INVOICE_PAY. */
	public static final String INVOICE_PAY="IP";
	
	/** The Constant BLOCK_DATE_FORMAT. */
	public static final  String BLOCK_DATE_FORMAT="yyyy-MM-dd HH:mm:ss";
	
	/** The Constant PAYMENT_DATE_FORMAT. */
	public static final  String PAYMENT_DATE_FORMAT="yyyy-MM-dd'T'HH:mm:ss";
	
	/** The Constant _00000. */
	public static final  String _00000="00000";
	
	/** The Constant TIME_FORMAT. */
	public static final String TIME_FORMAT="T";
	//Payment reference Values
	/** The Constant TRANSACTION_MODE. */
	public static final String TRANSACTION_MODE="I";
	
	/** The Constant CAT_CREDIT_TXN_CODE. */
	public static final  String CAT_CREDIT_TXN_CODE="CREDIT_TXN_CODE";
	
	/** The Constant CODE_EBBS. */
	public static final  String CODE_EBBS="EBBS";
	
	/** The Constant CAT_DEBIT_TXN_CODE. */
	public static final  String CAT_DEBIT_TXN_CODE="DEBIT_TXN_CODE";
	
	/** The Constant CAT_VISA_SUSPENSE_ACCOUNT. */
	public static final  String CAT_VISA_SUSPENSE_ACCOUNT="VISA_SUSPENSE_ACCOUNT";
	
	/** The Constant CAT_MASTER_SUSPENSE_ACCOUNT. */
	public static final  String CAT_MASTER_SUSPENSE_ACCOUNT="MASTER_SUSPENSE_ACCOUNT";
	
	/** The Constant CAT_BLOCK_TYPE. */
	public static final  String CAT_BLOCK_TYPE="BLOCK_TYPE";
	
	/** The Constant CAT_BLOCK_ACTION_ON_EXPIRY. */
	public static final  String CAT_BLOCK_ACTION_ON_EXPIRY="BLOCK_ACTION_ON_EXPIRY";
	
	/** The Constant CAT_BLOCK_PARTIAL. */
	public static final  String CAT_BLOCK_PARTIAL="BLOCK_PARTIAL_FLAG";
	
	/** The Constant MODIFY_DELETE. */
	public static final  String MODIFY_DELETE="D";
	
	/** The Constant MODIFY_RELEASE. */
	public static final  String MODIFY_RELEASE="R";
	
	/** The Constant DEBIT_NARRATION1. */
	public static final  String DEBIT_NARRATION1="ONLINE PAY CARD";
	
	/** The Constant DEBIT_NARRATION2. */
	public static final  String DEBIT_NARRATION2="TO CARD ";
	
	/** The Constant CREDIT_NARRATION1. */
	public static final  String CREDIT_NARRATION1="OLPAYCRD ";
	
	/** The Constant CREDIT_NARRATION2. */
	public static final  String CREDIT_NARRATION2="TO CARD ";
	
	/** The Constant VISA_CREDIT_NARRATION3_TI. */
	public static final  String VISA_CREDIT_NARRATION3_TI="TI ";
	
	/** The Constant NARRATION3_SD. */
	public static final  String NARRATION3_SD=",SD";
	
	/** The Constant NARRATION3_SD. */
	public static final  String NARRATION3_DATE=",D";

	/** The Constant NARRATION3_STA. */
	public static final  String NARRATION3_AUDIT=",A";
	
	/** The Constant NARRATION3_STA. */
	public static final  String NARRATION3_STA=",STA";
	
	/** The Constant VISA_NARRATION4_AC. */
	public static final  String VISA_NARRATION4_AC="AC ";
	
	/** The Constant VISA_NARRATION4_RN. */
	public static final  String VISA_NARRATION4_RN=",RN ";
	
	/** The Constant MASTER_CREDIT_NARRATION3_TRF. */
	public static final  String MASTER_CREDIT_NARRATION3_TRF="R";
	
	/** The Constant MASTER_CREDIT_NARRATION4. */
	public static final  String MASTER_CREDIT_NARRATION4="NTR ";
	
	/** The Constant ENQUIRY_CREATE_BLOCK_STATUS. */
	public static final  String ENQUIRY_CREATE_BLOCK_STATUS="00001";
	
	/** The Constant ENQUIRY_RELEASE_DELETE_BLOCK_STATUS. */
	public static final  String ENQUIRY_RELEASE_DELETE_BLOCK_STATUS="00002";
	
	/** The Constant RETRY_BLOCK_STATUS. */
	public static final  String RETRY_BLOCK_STATUS="9999";
	
	/** The Constant EBBS_SUCCESS. */
	public static final  String EBBS_SUCCESS="000";
	
	/** The Constant VISA_SUCCESS. */
	public static final  String VISA_SUCCESS="00";
	
	/** The Constant VISA_ENQ_FAIL. */
	public static final  String VISA_ENQ_FAIL="4";
	
	/** The Constant VISA_TIMEOUT. */
	public static final  String _202="202";
	
	/** The Constant VISA_TIMEOUT. */
	public static final  String _303="303";
	
	/** The Constant Block Enq. */
	public static final  String _90210="90210";
	/** The Constant MASTER_SUCCESS. */
	public static final  String MASTER_SUCCESS="00";
	
	/** The Constant MASTER_ENQ_FAIL. */
	public static final  String MASTER_ENQ_FAIL="4";
	
	/** The Constant MASTER_ENQ_SUCCESS. */
	public static final  String MASTER_ENQ_SUCCESS="00";
	
	/** The Constant SUBMIT. */
	public static final  String SUBMIT="2";
	
	/** The Constant PMT_FAIL. */
	public static final  String PMT_FAIL="4";
	
	/** The Constant EDMI_TIME_OUT. */
	public static final  String EDMI_TIME_OUT="109";

	/** The Constant ADD_BILLER. */
	public static final String ADD_PAYEE = "addPayee";
	
	
	/** The Constant DELETE_BILLER. */
	public static final String DELETE_PAYEE = "deletePayee";

	
	/** The Constant ACCOUNT_INQ. */
	public static final String ACCOUNT_INQ = "accountInquiry";
	//Field Validation
	
	/** The Constant AMOUNT. */
	public static final String AMOUNT="Amount";
	
	/** The Constant TXN_STATUS. */
	public static final Object[] TXN_STATUS = new Object[]{"TIMEOUT","REVT","AGGTMOUT","RTMOUT"};
	
	/** The Constant I_BANKING. */
	public static final String I_BANKING= "IBNK";
	
	/** The Constant MSG_SUB_TYPE. */
	public static final String CUSTOMER = "Customer";
	
	/** The Constant ACCOUNT_PROCESS_NAME. */
	public static final String ACCOUNT_PROCESS_NAME = "AccountEnquiry";
	
	/** Biller category **/
	public static final String BILLER_CATEGORY_SERVICE = "BillerCategory";
	
	/** The Constant DAO_EXCEPTION. */
	public static final String DAO_EXCEPTION="Unable to insert the record";

	/** The Constant EFAWATEER. */
	public static final String EFAWATEER = "EFAWATEER";

	/** The Constant IBANKING. */
	public static final String IBANKING = "iBanking";

	/** The Constant MERCHANT. */
	public static final String MERCHANT = "Merchant";

	/** The Constant ADDBILLER. */
	public static final String ADDBILLER = "AddBiller";
	
	/** The Constant ADDBILLER. */
	public static final String VIEWPAYEE = "ViewPayee";
	
	
	/** AGG_BILLER_CATEGORIES	 **/
	public static final String  AGG_BILLER_CATEGORIES="getBillerCategories";
	
	/** The Constant GETBILLERLIST. */
	public static final String GETBILLERLIST = "GetBillerList";
	
	/** The Constant GETBILLS. */
	public static final String GETBILLS = "GetBills";

	/** The Constant AGGREGATOR_SUB_DOMAIN_TYPE. */
	public static final String AGGREGATOR_SUB_DOMAIN_TYPE = "Coll";

	/** The Constant ERROR. */
	public static final String ERROR = "Error";

	/** The Constant BILL_ENROL. */
	public static final String BILL_ENROL= "BillEnrol";
	
	/** The Constant ENROL_CUSTOMER. */
	public static final String ENROL_CUSTOMER = "EnrolCustomer";
	
	/** The Constant SUB_DOMAIN_COLL. */
	public static final String SUB_DOMAIN_COLL = "Coll";
	
	/** The Constant VERSION_1. */
	public static final String VERSION_1 = "v1";

	/** The Constant RMVCUSBILRQ. */
	public static final String RMVCUSBILRQ = "RMVCUSBILRQ";

	/** The Constant DELETEBILLER. */
	public static final String DELETEBILLER = "DeleteBiller";
	
	/** The Constant INVOICE_DETAILS. */
	public static final String INVOICE_DETAILS = "INVOICE_DETAILS";
	
	/** The Constant BILLER_DOWNLOAD. */
	
	public static final String BILLER_DOWNLOAD_FREQUENCY_TIME_IN_MINUTES="BILLER_DOWNLOAD_FREQUENCY_TIME_IN_MINUTES";
	
	public static final String MAX_MINT_PER_DAY = "1440";
	
	public static final String BILLER_DOWNLOAD = "BILLER_DOWNLOAD";
	
	public static final String BILLER_DOWNLOAD_IN_PROGRESS = "BILLER_DOWNLOAD_IN_PROGRESS";

 	public static final String BILLER_DOWNLOAD_COMPLETED = "BILLER_DOWNLOAD_COMPLETED";

	/** The Constant BILLER_DOWNLOAD. */
	public static final String BILLER_DOWNLOAD_COUNTRIES = "BILLER_DOWNLOAD_COUNTRIES";

	public static final Object TXN_TYPE = "TXN_TYPE";

	public static final Object SRC_SYS = "SRC_SYS";

	public static final Object TXN_BRANCH = "TXN_BRANCH";
	
	/** The Constant SG. */
	public static final String SG= "SG";

	/** The Constant TXN_SUB_TYPE. */
	public static final String TXN_SUB_TYPE_PACV ="PACV";
	
	/** The Constant TXN_SUB_TYPE. */
	public static final String TXN_SUB_TYPE_PACM ="PACM";
	
	/** The Constant EBBS DEFAULT ERROR. */
	public static final String EBBS_ERROR ="EBBS_ERROR";
	
	/** The Constant EBBS DEFAULT ERROR. */
	public static final String EBBS_ERROR_CD ="4444";
	
	/** The Constant RETRY. */
	public static final String RETRY_1 ="RETRY_1";
	
	/** The Constant RETRY. */
	public static final String RETRY_2 ="RETRY_2";
	
	/** The Constant RETRY. */
	public static final String RETRY_COUNT ="RETRY_COUNT";

	/** The Constant VISA_AMT_FORMAT. */
	public static final String VISA_AMT_FORMAT ="#.##";

	/** The Constant MASTER_AMT_FORMAT. */
	public static final String MASTER_AMT_FORMAT ="#";
	
	/** The Constant ENQFAIL. */
	public static final String TXN_ENQ_FAIL ="ENQFAIL";
	
	/** The Constant ENQFAIL. */
	public static final String TXN_ENQ_SUCC ="ENQSUCC";
	
	public static final String SERVICE_NOT_AVAILABLE = "Service Unavailable";
	
	public enum Status {
	        NEW, BLOCK, FAIL, SUCC;

	}
	
	
	/**BILLER_CATEGORY_AGGREGATOR_FETCH**/
	public static final String BILLER_CATEGORY_AGGREGATOR_FETCH="BILLER_CATEGORY_AGGREGATOR_FETCH";
	
	/**  BILLERDOWNLOAD_TERMINAL_ID**/
	public static final String INVOICE_NAME= "Invoice";
	
	/**  BILLERDOWNLOAD_TERMINAL_ID**/
	public static final String BILLERDOWNLOAD_TERMINAL_ID= "BILLERDOWNLOAD_TERMINAL_ID";
	

	/**  BILLERDOWNLOAD_TERMINAL_ID**/
	public static final String BILLERDOWNLOAD_DISABLE= "BILLERDOWNLOAD_DISABLE";
		
	/**  AGGEREGATOR_SHORT_CODE **/
	public static final String AGGEREGATOR_SHORT_CODE= "AGGEREGATOR_SHORT_CODE";
	
	
	/**  Edmi Aggregator Biller Product Key **/
	public static final String EDMI_GETBILLER_PRODUCTS_NAME= "getBillersProducts";
	
	/**  Edmi Aggregator Biller key **/
	public static final String EDMI_GETBILLERS_NAME="getBillers";
	
	public static final String  DEFUALT_BILLER_FIELD_TYPE="freetext";
	/* the A2D */
	public static final String A2D= "Active-To-Deactivate";
	
	/* the d2A */
	public static final String D2A= "Deactivate-To-Active";
	
	/* the d2A */
	public static final String  NEW_BILLER= "NEW_BILLER";
	
	
	/* the AGG_BILLER_FETCH_EXCEPTION */
	public static final String  AGG_BILLER_FETCH_EXCEPTION= "AGG_BILLER_FETCH_EDMI_EXCEPTIONS";
	
	/* the AGG_BILLER_RESPONSE_NULL */
	public static final String  AGG_BILLER_RESPONSE_NULL= "AGG_BILLER_RESPONSE_NULL";
	
	/* the AGG_BILLER_FETCH_FAIL */
	public static final String  AGG_BILLER_FETCH_FAIL= "AGG_BILLER_FETCH_FAIL";
	
	
	//Added for Customer Overall Payment Amount Service
	public static final String CUSTOMER_OVERALL_PAYMENT_AMOUNT ="CustomerOverallPaymentAmount";
	public static final String REQUEST ="REQUEST";
	public static final String RESPONSE ="RESPONSE";
	//ends Customer Overall Payment Amount	
	
		/** The Constant SRMADC. */
	public static final String GET_PAYMENTSTATUS= "getPaymentStatus";
	
	public static final String BILLER_DOWNLOAD_CATEGORY_TYPE="BILLER_DOWNLOAD_CATEGORY_TYPE";
	
	public static final String DYNAMIC="DYNAMIC";

	public static final String STATIC="STATIC";

	public static final String Biller_DOWNLOAD_ApplicationUserID="ApplicationUserID";
	
	public static final String Biller_DOWNLOAD_ApplicationUserKey="ApplicationUserKey";
	public static final String DEFAULT_BILLER_LABEL="DEFAULT_BILLER_LABEL";
	
	public static final String was_server_name="was.server.name";

	public static final String AGGREGATOR="AGGREGATOR";

	/** The Constant Payment SUCCESS. */
	public static final String PAY_SUCCESS="SUCC";
	
	/**
	 * REGISTERED_USER
	 */
	public static final String REGISTERED_USER="R";
	
/*	public static final List<String> AGGREGATOR_INPROCESS_STATUS_LIST = 
			Arrays.asList(new String[] {"INPROCESS"});
	
	public static final List<String> AGGREGATOR_SUCCESS_STATUS_LIST =Arrays.asList(new String[]
			{"90000", "90010", "90011", "90016", "SUCCESS", "OK", "SUCCESSFUL"});
	
	public static final List<String> INTERSWITCH_PAYMENT_STATUS =Arrays.asList(new String[]
			{"90000", "90010", "90011", "90016", "SUCCESS"});
	
	public static final List<String> CRAFTSILICON_PAYMENT_STATUS =Arrays.asList(new String[]
			{"OK", "INPROCESS"});*/
	
	public static final String SAVE_SUCCESS = "SAVESUCC";
	
	public static final String SAVE_FAIL = "SAVEFAIL";
	
	public static final String REGISTER_PAYEE= "R";
	
	public static final String CARD_AUTH_SUCCESS = "CCAUTSUCC";

	public static final String CARD_AUTH_FAILURE = "CCAUTFAIL";
	
	public static final String CARD_AUTH_TIMEOUT = "CCAUTTMOT";

	public static final String CARD_AUTH_REV_SUCCESS = "AUTREVSUCC";

	public static final String CARD_AUTH_REV_FAILURE = "AUTREVFAIL";
	
	public static final String CARD_AUTH_REV_TIMEOUT = "AUTREVTMOT";
	
	public static final String COREBANK_PAY_SUCCESS = "CBPAYSUCC";

	public static final String COREBANK_PAY_FAILURE = "CBPAYFAIL";

	public static final String COREBANK_PAY_TIMEOUT = "CBTIMEOUT";

	public static final String AGGREGATOR_PAY_SUCCESS = "AGGPAYSUCC";
	
	public static final String AGGREGATOR_PAY_NOT_SUCCESS = "AGGNOTSUCC";

	public static final String AGGREGATOR_PAY_FAILURE = "AGGPAYFAIL";

	public static final String AGGREGATOR_PAY_INPROGRESS = "AGGPAYPGRS";
	
	public static final String AGGREGATOR_INPROCESS = "AGGPROCESS";
	
	public static final String AGGREGATOR_PAY_TIMEOUT = "AGGTIMEOUT";

	public static final String REVERSAL_PAY_SUCCESS = "REVPAYSUCC";

	public static final String REVERSAL_PAY_FAILURE = "REVPAYFAIL";

	public static final String REVERSAL_PAY_TIMEOUT = "REVTIMEOUT";
	
	public static final String INTERSWITCH = "Interswitch";
	
	public static final String CRAFTSILICON = "CraftSilicon";
	
	/** The Constant SUCCESS_PAYMENT_LIST. */
    public static final List<String> SUCCESS_PAYMENT_LIST =Arrays.asList(new String[]{AGGREGATOR_PAY_SUCCESS,SUCC});
    
    /** The Constant FAIL_PAYMENT_LIST. */
    //public static final List<String> FAIL_PAYMENT_LIST = Arrays.asList(new String[]{FAIL,SAVE_FAIL,COREBANK_PAY_FAILURE,AGGREGATOR_PAY_FAILURE,REVERSAL_PAY_FAILURE,REVERSAL_PAY_SUCCESS});
    /** The Constant FAIL_PAYMENT_LIST. *///Modifying for CCSOF
    public static final List<String> FAIL_PAYMENT_LIST = Arrays.asList(new String[]{FAIL,SAVE_FAIL,COREBANK_PAY_FAILURE,AGGREGATOR_PAY_FAILURE,REVERSAL_PAY_FAILURE,REVERSAL_PAY_SUCCESS,CARD_AUTH_FAILURE,CARD_AUTH_REV_SUCCESS,CARD_AUTH_REV_FAILURE,CARD_AUTH_TIMEOUT,CARD_AUTH_REV_TIMEOUT});

    /** The Constant SUBMIT_PAYMENT_LIST. */
    public static final List<String> SUBMIT_PAYMENT_LIST = Arrays.asList(new String[]{SAVE_SUCCESS,COREBANK_PAY_SUCCESS,COREBANK_PAY_TIMEOUT,AGGREGATOR_PAY_INPROGRESS,AGGREGATOR_PAY_TIMEOUT,REVERSAL_PAY_TIMEOUT,SUBMITTED});
	
	public static final List<String> TIME_OUT_LIST = Arrays.asList(new String[]{COREBANK_PAY_TIMEOUT,AGGREGATOR_PAY_TIMEOUT,REVERSAL_PAY_TIMEOUT});

	public static final List<String> AFRICAN_COUNTRIES = Arrays.asList(new String[]{"NG","KE","GH","BW","UG","ZW","ZM","TZ","CI"});
	
    public static final String APPLICATION_USERID="SCBKENYA";
    
    public static final String APPLICATION_USERKEY="HFUDK^HUREO";
    
    public static final String IN_PROGRESS="IN_PROGRESS";
    
    public static final String COMPLETE="COMPLETE";
    
    public static final String DEFAULT_CATEGORY = "Default";
    
    public static final String CURRENCY_CONVERSION_MULTIPLIER = "CURRENCY_CONVERSION_MULTIPLIER";
    
    public static final String encryptPrefix = "(enc)";
    
    public static final String AGGREGATOR_INPROCESS_STATUS = "AGGREGATOR_INPROCESS_STATUS";
    
    public static final String AGGREGATOR_SUCCESS_STATUS = "AGGREGATOR_SUCCESS_STATUS";
    
    public static final String AGGREGATOR_NOT_SUCCESS = "AGGREGATOR_NOT_SUCCESS";
    
    public static final String AGGREGATOR_NODATA_STATUS = "AGGREGATOR_NODATA_STATUS";
    
    public static final String PAYMENT_RETRY_JOB = "RETRY_PAYMENTS";
    
    public static final String PAYMENT_INPROCESS_JOB = "INPROCESS_PAYMENTS";
    
    public static final String PAYMENT_RETRY_TIMER = "PAYMENT_RETRY_TIMER";
    
    public static final String PAYMENT_INPROCESS_TIMER = "PAYMENT_INPROCESS_TIMER";
    
    public static final String BILLERS_WITH_TOKEN = "BILLERS_WITH_TOKEN";
    
    public static final String MOBILE_NO = "Mobile Number";
    
    public static final String INFOFIELD1 = "INFOFIELD1";
    
    public static final String CS_INFOFILED = "CS_INFOFIELD";
                                                
    public static final String DEL_SQUARE_OPN = "DEL_SQUARE_OPN";
    
    public static final String DEL_SQUARE_CLOSE = "DEL_SQUARE_CLOSE";
    
    public static final String MANUAL_PROCESS_STATUS = "MANPROCESS";
    
    public static final String MANUAL_PROCESS = "MANUAL PROCESS";
    
    public static final String INPROCESS_STATUS = "INPROCESS";
    
    public static final String AGGREGATOR_MANUAL_PROCESS_STATUS = "AGGREGATOR_MANUAL_PROCESS_STATUS";
    
    public static final String PAYMENT_INPROCESS_RETRY_COUNT = "PAYMENT_INPROCESS_RETRY_COUNT";
    
    public static final String PAYMENT_TIMEOUT_RETRY_COUNT = "PAYMENT_TIMEOUT_RETRY_COUNT";

	//Alipay
    public static final String BANKACCOUNT = "BANKACCOUNT";

    public static final String CREDITCARD = "CREDITCARD";
    
    public static final String CREDIT_CARD = "CreditCard";

    public static final Integer MAXIMUM_PAYEE_ALLOWED_ALIPAY_WALLET = 40;

    public static final String WALLET_SERVICE="WALLET";

    public static final Integer MAXIMUM_PAYEE_ALLOWED_PER_DAY = 10;
    
    public static final String VALIDATE_PAYEE_INSERT = "insertion";
    
    public static final String VALIDATE_PAYEE_FETCH = "fetch";
    
    public static final String VALIDATE_PAYEE_INSERT_ROUTE = "validatePayeeRPE";
    
    public static final String VALIDATE_PAYEE_FETCH_ROUTE = "validatePayeeAlipay";
    
    public static final String STATUS_IN_ACTIVE = "I";
    
    public static final String STATUS_NEW = "N";
    
    public static final String PAYEE_STATUS_DESCRIPTION_DELETED = "Payee Deleted";
    
    public static final String PAYEE_STATUS_DESCRIPTION_TERMINATED = "Payee Terminated By System";
    
    public static final String PAYEE_STATUS_DESCRIPTION_NEW = "New Payee Request";
    
    public static final String PAYEE_STATUS_DESCRIPTION_ACTIVE = "Active Payee";
    
    public static final String PAYEE_STATUS_DESCRIPTION_SUCCESS_ALIPAY = "Payee Validation Success At Alipay";
    
    public static final String PAYEE_STATUS_DESCRIPTION_FAILED_ALIPAY = "Payee  Validation Falied at Alipay";
    
    public static final String PAYEE_STATUS_STRING = "status";
    
    public static final String PAYEE_ENTRY_NOT_FOUND = "NOT_EXISTS";
    
    public static final String PAYEE_ENTRY_FOUND = "EXISTS";
    
    public static final String PAYEE_UPDATE_EXCEPTION = "EXCEPTION";
    
    public static final String PAYEE_CONSUMER_NUM = "consumerNumber";
    
    public static final String PAYEE_CUST_ID = "customerId";
    
    public static final String PAYEE_COUNTRY_CODE = "countryCode";
    
    public static final String PAYEE_REMARKS = "remarks";
    
    public static final String PAYEE_REFERENCE_NUM = "referenceNumber";
    
    public static final String PAYEE_UPDATED_TIMESTAMP = "updateTime";
    
    public static final String PAYEE_SHORTNAME = "payeeShortName";
    
    public static final String PAYEE_CHNLID = "channelId";
    
    public static final String PAYEE_AUTH_AGG_SUCCESS = "NEW_REQUEST_AGG_SUCCESS";
    
    public static final String PAYEE_AUTH_AGG_FAILED = "NEW_REQUEST_AGG_FAILED";
    
    public static final String PAYEE_AUTH_AGG_EXCEPTION = "NEW_REQUEST_AGG_EXCEPTION";
    
    public static final String PAYEE_AUDIT_REQUEST = "REQ_PAYEE";
    
    public static final String PAYEE_AUDIT_RESPONSE = "RES";
  //Alipay
      
	public static final String VERSION_2 = "v2";

	public static final String POST_TRANSACTION = "PostTransaction";
    
    public static final String HOGAN = "Hogan";
    
    public static final String ALIPAY = "1";
    
    public static final String POST_SINGLE_LEG = "postSingleLeg";
    
    public static final String ALIPAY_CASA_TOP_UP ="XAL1";
    
    public static final String ALIPAY_THRU_CREDIT_CARD = "XAL2";
    
    public static final String HOGAN_STATUS_A = "Accepted";
    
    public static final String HOGAN_STATUS_V = "Voided";   // means Rejected
    
    public static final String HOGAN_STATUS_S = "Supervisor Override Requested";  //means Rejected
    
    public static final String HOGAN_STATUS_O = "Operator Override Requested";  //means Rejected
    
    public static final List<String> HOGAN_FAILUR_LIST = Arrays.asList(new String[]{"V","S","O"});
    
    //Added for HOGAN getTransactionStatus inquiry
    public static final String HOGAN_PAYLOAD_VERSION = "6.3";
	 
	public static final String HOGAN_MSG_VERSION="6.0";
	
	public static final String GET_TRANSACTION_STATUS = "getTransactionStatus";
	
	public static final String HOGAN_DOMAIN_SUBTYPE_NAME="CoreBanking";
	
	public static final String HOGAN_CAPTURE_SYSTEM="Hogan";
	
	public static final String HOGAN_DATE_FORMAT = "yyMMdd";
	
	public static final String ALIPAY_TRANS_TYPE = "01";
    
    // Added for getPaymentStatus for Alipay
    public static final String ALIPAY_AGGREGATOR = "ALIPAY";
    
    public static final String POST_PAYMENT = "postPayment";
    
  public static final String REVERSAL = "Reversal";
    
    public static final String REVERSAL_INDICATOR = "X";
    
    public static final String MASKING = "MASKING_";
    
    /** The Constant TRANSFER_FUND. */
	public static final String ALIPAY_REVERSE_POSTING = "reversePosting";
	
	public static final String POST_SINGLE_LEG_TRANSACTION = "postSingleLegTransaction";
	
	public static final String CARD_AUTHORIZATION_TRANSACTION = "authorizeCardPurchaseTransaction";
	
	public static final String REVERSE_CARD_AUTHORIZATION_TRANSACTION = "reverseCardPurchaseTransaction";
	
	public static final String REQUEST_TOPIC = "REQUEST_TOPIC";
	
	public static final String ALIPAY_WALLET_IDENTIFIER_6 = "6";
	
	public static final String ALIPAY_MAKER_ID = "10501";
	
	public static final String ALIPAY_TRANS_CODE_0 = "0";
	
	public static final String ALIPAY_PAYLOAD_VERSION = "1.0";
	
	public static final int UNIQUE_IDENTIFIER_COUNT_17 = 17;
	
	public static final int TRANS_REF_COUNT_7 = 7;
	
	public static final String ALIPAY_TRANSACTION_BRANCH = "00105";
	
	public static final String ALIPAY_SUCCESS="00000000";
	
	public static final String ALIPAY_ACCOUNT_STATUS_ABNORMAL="22005204";
	
	public static final String ALIPAY_PAYEE_ACCOUNT_NOT_EXIST="12007306";
	
	public static final String ALIPAY_AMOUNT_EXCEED_LIMIT ="12007321";
	
	public static final String ALIPAY_SYSTEM_ERROR ="00000900";
	
	public static final String WALLET_PAYMENT = "WalletPayment";
	
	public static final String PAYEE_TYPE ="payeeType";
	
	public static final String HK_COUNTRY_CODE ="HK";
	
	public static final String PAYEE_ID ="payeeId";
	
	public static final String PAYMENT_TIMEOUT_RETRY_STATUS = "PAYMENT_TIMEOUT_RETRY_STATUS";
	
	public static final String PAYMENT_TIMEOUT_RETRY_COUNTRY = "PAYMENT_TIMEOUT_RETRY_COUNTRY";
	
	public static final String ALIPAY_NO_FUND_ORDER = "12007201";
	
	public static final String ALIPAY_UNKNOWN_CLIENT = "12014155";
	
	public static final String PAYMENT_INPROCESS_RETRY_COUNTRY = "PAYMENT_INPROCESS_RETRY_COUNTRY";

	public static final String PAYMENT_TIMER_BUFFER = "PAYMENT_TIMER_BUFFER";
	/** The Constant DECIMAL_FOUR. */
	public static final String DECIMAL_FOUR = "4.0"; 
	
	/** The Constant CONTACT_DETAILS. */
	public static final String CONTACT_DETAILS = "getCustomerContactDetails";
	
	/** The Constant CUSTOMER_TYPE_NAME. */
	public static final String CUSTOMER_TYPE_NAME = "CoreBanking:Customer";
	
	/** The Constant VALIDATION_SUCCESS. */
	public static final String VALIDATION_SUCCESS="VALIDATION SUCCESS";
	
	/** The Constant CONTACT_TYPE. */
	public static final String CONTACT_TYPE = "M";
	
	/** The Constant VALIDSUCC. */
	public static final String VALIDSUCC = "VALIDSUCC";
	
	/** The Constant VALIDFAIL. */
	public static final String VALIDFAIL = "VALIDFAIL";
	
	/** The Constant MOBILE_VALIDATION_SUCCESS. */
	public static final String MOBILE_VALIDATION_SUCCESS = "MOBILE VALIDATION SUCCESS";
	
	/** The Constant RPE. */
	public static final String RPE = "RPE";
	
	/** The Constant TRANSACTION_TYPE. */
	public static final String TRANSACTION_TYPE = "MM1";
	
	/** The Constant PAYMENT_DESC. */
	public static final String PAYMENT_DESC = "PAYMENT SUCESS";
	
	/** The Constant CORE_BANKING_ERROR. */
	public static final String CORE_BANKING_ERROR = "Technical error. Please try again.";
	
	/** The Constant SPECIAL_CHARACTERS. */
	public static final String SPECIAL_CHARACTERS = "~`!#@$%^&*()_}-{:.>; <?\\]+|[/,='\"";
	
	/** The Constant CUSTOMER_STATUS_CHECK_CD. */
	public static final String CUSTOMER_STATUS_CHECK_CD = "C000";
	
	/** The Constant ACCOUNT_STATUS_CHECK_CD. */
	public static final String ACCOUNT_STATUS_CHECK_CD = "A000";
	
	/** The Constant ACC_SUCCESS. */
	public static final String ACC_SUCCESS = "ACCSUCCESS";
	
	/** The Constant ACC_FAIL. */
	public static final String ACC_FAIL = "ACCFAIL";
	
	/** The Constant CB_ACCOUNT_SERVICE_NAME. */
	public static final String CB_ACCOUNT_SERVICE_NAME = "getAccountDetails";
	
	/** The Constant CB_CUSTOMER_SERVICE_NAME. */
	public static final String CB_CUSTOMER_SERVICE_NAME = "getCustomerContactDetails";
	
	/** The Constant INWARD_TIMEFMT. */
	public static final String INWARD_TIMEFMT ="yyyyMMddHHmmss";
	
	/** The Constant INWARD_MOBILE_FMT. */
	public static final String INWARD_MOBILE_FMT = "[0-9]+";
	
	/** The Constant TWO_DECIMAL. */
	public static final String TWO_DECIMAL = "2.0";
	
	public static final String INWARD_PAYMENT = "INWARDPAYMENT";
	
	public static final String FAILURE_STATUS = "001";
	
	public static final String ISO_LIST = "_ISO_LIST";
	
	public static final String GET_TRANSACTION = "getTransaction";
	
	public static final String INWARD_FETCH_TYPE = "INWARD_PAYMENT";
	
	public static final String HISTORY_DATE_FORMAT =  "yyyy/MM/dd";
	
	public static final String CB_CUST_PAYLOAD_VERSION = "5.2";
	
	public static final String CCMS = "CCMS";
	
	public static final String MASTER_INDICATOR = "5";
	
	public static final String VISA_INDICATOR = "4";
	
	public static final String VISA_MERCHANT_02 = "02";
	
	public static final String VISA_MERCHANT_03 = "03";
	
	public static final String MASTER_MERCHANT_04 = "04";
	
	public static final String MASTER_MERCHANT_05 = "05";
	
	public static final String MASTER_FUNDING_SOURCE_DEBIT ="02";
	
	public static final String MASTER_FUNDING_SOURCE_CREDIT ="01";
	
	public static final String LANGUAGE_IDENTIFICATION ="ENG";
	
	public static final String QR_CHANNEL="M";
	
	public static final String MASTER_TRANSACTION_DESC="IPP";
	
	public static final String VISA_BUSINESS_APPLICATION_ID="MP";
	
	public static final String VISA_CARD_ACCEPTOR_NAME="mVisa merchant";
	
	public static final String VISA_CARD_ACCEPTOR_CITY="mVisa payment";
	
	public static final String QR_ADDITIONAL_TAG_BILL_NUMBER="01";
	
	public static final String QR_ADDITIONAL_TAG_MOBILE_NUMBER="02";
	
	public static final String QR_ADDITIONAL_TAG_STORE_ID="03";
	
	public static final String QR_ADDITIONAL_TAG_LOYALITY_NUMBER="04";
	
	public static final String QR_ADDITIONAL_TAG_REFERENCE_ID="05";
	
	public static final String QR_ADDITIONAL_TAG_CONSUMER_ID="06";
	
	public static final String QR_ADDITIONAL_TAG_TERMINAL_ID="07";
	
	public static final String QR_ADDITIONAL_TAG_PURPOSE="08";
	
	public static final String QR_ADDITIONAL_TAG_MAID="11";
	
	public static final String QR_FLAT_FEE_INDICATOR="02";
	
	public static final String QR_PERCENTAGE_FEE_INDICATOR="03";
	
	public static final String QR_CUSTOMER_ENTERED_TIP="01";
	
	public static final String CARD_AUTHORIZATION_REVERSAL_TRANSACTION = "revereseAuthorizeCardPurchaseTransaction";
	
	public static final String CARD_AUTH_REVERSE_EVENT_TYPE = "reverseAuthorizeCard";
	
	public static final String CARD = "CARD";
	
	public static final String VISA_MCC = "6012";
	
	public static final String ACQUIRER_TIMEOUT = "ACQTMOUT";
	
	public static final String DEBIT_CARD_AUTH_SUCCESS = "DCAUTSUCC";

	public static final String DEBIT_CARD_AUTH_FAILURE = "DCAUTFAIL";
	
	public static final String DEBIT_CARD_AUTH_TIMEOUT = "DCAUTTMOT";

	public static final String DEBIT_CARD_AUTH_REV_SUCCESS = "DCAUTREVSUCC";

	public static final String DEBIT_CARD_AUTH_REV_FAILURE = "DCAUTREVFAIL";
	
	public static final String DEBIT_CARD_AUTH_REV_TIMEOUT = "DCAUTREVTMOT";
	
	public static final String EURONET ="Euronet";

	public static final String DEBIT_CARD_AUTHORIZE = "debitCardAuthorize";
	
	public static final String DEBIT_CARD_REVERSE = "debitCardReverse";

	public static final String DEBIT_CARD_AUTHORIZE_REVERSE = "debitCardAuthorizeReversal";
	
	public static final String TYPE_NAME = "DebitCard";
	
	public static final String DEBIT_CARD_PURCHASE = "authorizeCardPurchase";
	
	public static final String DEBIT_CARD_REVERSE_PURCHASE = "reverseCardPurchase";
	
	public static final String DECIMAL_FIVE = "5.0";
	
	public static final String SUBMITTED_CODE = "1";
	
	public static final String ACQUIRER_TIMEOUT_CODE = "202";
	
	public static final String ACQUIRER_DUPLICATE_TXN = "303";
	
	public static final String HTTP_SUCCESS_STATUS = "200";
	
	public static final String QR_PAYMENT= "QRPAYMENT";
	
	public static final String QR_COUNTRIES ="QR_COUNTRIES";
	
	public static final List<String> QR_COUNTRY_LIST = Arrays.asList(new String[]{"IN,KE,NG,BW,GH,TZ,UG,ZM,ZW,CI,PK"});
	
	public static final List<String> QR_FUND_LIST = Arrays.asList(new String[]{"CASA","CARD"});
	
	public static final String QR_PAYMENTTYPE ="QR_PAYMENTTYPE";
	
	 public static final String HOST_TIMEOUT_MESSAGE = "HOST SYSTEM TIMEOUT";
	 
	 public static final String DOUBLE_SPACE = "  ";
	 
	 public static final String QR_MERCHANT_DUMMY_NAME = "XXXXXXXXXXXXXXXXXXXXXXX";
	 
	 public static final String QR_MERCHANT_DUMMY_CITY = "XXXXXXXXXXXXX";
	
	 public static final String VALIDATE_PAYEE_INSERT_ROUTE_CS = "validatePayeeRPECS";
	    
	 public static final String VALIDATE_PAYEE_FETCH_ROUTE_CS = "validatePayeeCS";
	 
	 public static final String FIELD_DATETYPE_LIST = "List";
	 
	 public static final String STRING_NO = "N";
	 
	 public static final String ONE_TIME_PAYMENT = "O";
	  
	 public static final String PAYEE_STATUS_DESCRIPTION_ONETIME = "One Time Payment";
	 
	 public static final String R="R";
	 
	 public static final String RESPONSE_FIELDS_DELIMITER="//|";
	 
	 public static final String AMOUNT_FIELD="Amount";
	 
	 public static final String PAYEE_UPDATE_PROCESS_KEY="PAYEE_UPDATE_PROCESS_KEY";

     public static final List<String> AFRICAN_COUNTRIES_IS = Arrays.asList(new String[]{"NG"});
	 
	 public static final List<String> AFRICAN_COUNTRIES_CS = Arrays.asList(new String[]{"KE","GH","BW","UG","ZW","ZM","TZ","CI"});
	 
	 public static final String PAYLOAD_API_21="2.1";
	 
	 public static final String CS_DONOT_DISPLAY_TAGS_ADDPAYEE="CS_DONOT_DISPLAY_TAGS_ADDPAYEE";
	 
	 public static final String CS_RESPOSNE_AMT_FIELDS="CS_RESPOSNE_AMT_FIELDS";
	 
	 public static final String PAYEE_DELETE_PAYMENT_INPROCESS_STATUS="PAYEE_DELETE_PAYMENT_INPROCESS_STATUS";
	 
	 public static final String AggregatorIdentifier="AggregatorIdentifier";
	 
	 /** jetco **/

	public static final String JETCO = "JETCO";

	public static final String JETCO_PAY_TYPE = "JETCO PAY";

	public static final String JETCO_PAYLOAD_VERSION = "3.0";

	public static final String JETCO_EXE_PAYLOAD_VERSION = "1.0";

	public static final String JETCO_AGGREGATOR = "JETCO";

	public static final String JETCO_MAKER_ID = "10501";

	public static final String JETCO_TRANSACTION_DEBIT = "JPOR";
	
	public static final String JETCO_TRANSACTION_ON_US = "JTFR";

	public static final String JETCO_HOGAN_TRANS_SEQ_NUM = "0000678";
	
	public static final String JETCO_HOGAN_MAC = "12345678";

	public static final String JETCO_WALLET_IDENTIFIER_7 = "7";

	public static final String JETCO_TRANSACTION_BRANCH = "00105";

	public static final String JETCO_TRANS_CODE_0 = "0";

	public static final String JETCO_REVERSE_POSTING = "reversePosting";

	public static final String JETCO_MAC_VALUE = "XMNM";

	public static final String JETCO_TRANSACTIONS_NUMBER = "1";

	public static final String JETCO_IDENTIFICATION_ID = "JP2P";

	public static final String JETCO_PROPRIETARY_CRFID = "CRFID";

	public static final String JETCO_PROPRIETARY_P2PID = "P2PID";

	public static final String JETCO_PROPRIETARY_ACCNO = "ACCNO";

	public static final String JETCO_MSG_SUBTYPE_NAME = "ExecuteFASTCustomerCreditTransfer";

	public static final String JETCO_MSG_TYPE_NAME = "Cash:OutwardCustomerCreditClearing";

	public static final String JETCO_SENDER_DOMAIN_SUB_DOMAINTYPE = "Payments";

	public static final String JETCO_PROCESS_EVENT_TYPE = "Request";

	public static final String JETCO_CHARSET = "UTF-8";

	public static final String JETCO_MEG_TYPE = "pacs.008.001.06";
	
	public static final String POST_BY_PAYMENT_ID = "transferFundsByPymtId";
	
	public static final String TRANSFER_FUNDS_BY_PYMTID_TRANSACTION = "transferFundsByPymtIdTransaction";

	public static final String JETCO_SUBTYPE = "executeFastCustomerCreditTransferRequest";

	public static final String JETCO_SENDER_BANK = "SCT";

	public static final String JETCO_PAY = "JetcoPay";

	public static final String JETCO_PAY_SUCCESS = "0000";

	public static final String JETCO_DEFAULT_BANK_CODE = "0003";

	// For CR659 - CCSOF
	public static final String PAY_BILL_BY_CARD = "payBillByCard";

	public static final String C400 = "C400";
	
	public static final String CREDIT_CARD_AUTH= "creditCardAuthorization";
	
	public static final String DEFAULT = "Default";

	public static final String XXX = "XXX";

	public static final String ECTL = "ECTL";

	public static final String CNAT = "CNAT";
	
	public static final String ELEVEN_SPACES = "           ";
	
	public static final String FNCQ_LOOKUP_VALUE= "0200";
	
	public static final String CARDS400_DATEFORMAT= "MMddHHmmss";
	
	public static final String CASHADVANCE_BILLERCATEGORIES = "cashAdvance_billerCategories";
	
	public static final String CASHADVANCE_COUNTRIES = "cashAdvance_countries";
	
	public static final String 	SETTLEMENT_AMT = "SettlementAmount";
	
	public static final String CARD_HOLDER_BILLING_AMT = "Card Holder Billing Amount";
	
	public static final String  CASH_ADV_REQ =  "cashAdvanceReq";
	
	public static final String CARD_AUTH_REQ = "cardAuthReq";
	
	public static final String TRANSACTION_FEE = "TransactionFee";
	
	public static final List<String> QR_TIME_OUT_LIST = Arrays.asList(new String[]{CARD_AUTH_REV_TIMEOUT,DEBIT_CARD_AUTH_REV_TIMEOUT});
	
	public static final String MODULE = "QR_PAYMENT";
	
	public static final String IN = "IN";
	
	public static final String FIELD_VALIDATION = "FIELD_VALIDATION";
	
	public static final String QR_NUM_REGEX = "[0-9]+";
	
	public static final String QR_PAY_DTLS_VO = "QRPaymentDetailVO";
	
	public static final String QR_COUNTRY_VALID = "QRCountryValid";
	
	public static final String QR_ADDITIONAL_TAG_MAID_STR="QR_ADDITIONAL_TAG_MAID";
	
	public static final String BIN="BIN";
	
	public static final String VISA_CARD_SCH_INDR="001001V";
	
	public static final String MASTER_CARD_SCH_INDR="001001M";
	
	public static final String QR_MTI_0100="0100";
	
	public static final String QR_MTI_0200="0200";	
	
	public static final String FIVE_ZEROES ="00000";
	
	public static final String ELEVEN_ZEROES ="00000000000";
	
	public static final String MERCHID ="MERCHID";
	
	public static final String VISA_INDR ="V";
	
	public static final String MASTER_INDR ="M";
	//Added for Orange Money
	
	public static final String ADD_WALLET_PAYEE = "addWalletPayee";

	public static final String DELETE_WALLET_PAYEE = "deleteWalletPayee";
	
	public static final String GET_WALLET_PAYEE = "getWalletPayeeList";
	
	public static final String REGISTERED_WALLET="W";
	
	public static final String GET_WALLET_BILLERLIST ="getWalletBillerList";
	
	//CR1477, OrangeMoney Changes Starts, 01Feb18, Vijayan A
	public static final String WALLET_CATEGORY = "AFR-WALLET";

	public static final String WALLET_PAYEE = "W";

	public static final String CUSTOMER_CONTACT_TYPE = "CUSTOMER_CONTACT_TYPE";

	public static final String BANK_IDENTIFICATION_CODE = "BANK_IDENTIFICATION_CODE";

	public static final String CHARGE = "CREDIT";

	public static final String DISCHARGE = "DEBIT";

	public static final String INWARD_DECIMAL_NOT_ALLOW_COUNTRIES = "INWARD_DECIMAL_NOT_ALLOW_COUNTRIES";

	public static final String WALLET_MOBILE_VALIDATION_ENABLED = "WALLET_MOBILE_VALIDATION_ENABLED";
	
	/** The Constant DEBIT. */
	public static final String DEBIT_WALLET = D;
	
	/** The Constant CREDIT. */
	public static final String CREDIT_WALLET = COMPLETED;
	
	public static final String TRANSFER_TYPE_TEXT = "Transfer Type";
	
	public static final HashMap<String, String> hmWalletTransferType = new HashMap<String, String>();
	static {
		hmWalletTransferType.put("Account to Wallet", "1");
		hmWalletTransferType.put("Wallet to Account", "2");
		hmWalletTransferType.put("Both", "3");
	}
	
	/** The Constant REG. */
	public static final String DEREG = "DEREG";
	/** The Constant Alias. */
	public static final String ALIAS = "Alias";
	
	public static final String WALLET_ACC_LINK_MAX = "WALLET_ACC_LINK_MAX";
	
	public static final List<String> WALLET_PAYMENT_AFRICAN_COUNTRIES = Arrays.asList(new String[]{"GH","BW","UG","ZW","ZM","TZ","CI"}); //TZ is not available for Orange MOney Project
	
	public static final String WALLET_PAYMENT_RETRY_TIMER = "WALLET_PAYMENT_RETRY_TIMER"; //Default 15
	
	public static final String WALLET_PAYMENT_TIMEOUT_RETRY_COUNT = "WALLET_PAYMENT_TIMEOUT_RETRY_COUNT"; //Default 5
	
	public static final String WALLET_PAYMENT_TIMEOUT_RETRY_STATUS = "WALLET_PAYMENT_TIMEOUT_RETRY_STATUS";
	
	public static final String WALLET_PAYMENT_TIMEOUT_RETRY_COUNTRY = "WALLET_PAYMENT_TIMEOUT_RETRY_COUNTRY";

	public static final String PAYEE_STATUS_DESCRIPTION_DELETED_VIA_BO = "BO Wallet Deactivated";
	
	public static final String PAYEE_STATUS_DESCRIPTION_ACTIVATED_VIA_BO = "BO Wallet activated";
	
	public static final String INWARD = "INWARD";
	
	public static final String COMPONENT_NAME = "componentName";
	
	public static final String MODULE_NAME = "moduleName";
	
	public static final String BACK_OFFICE = "BO";

	public static final String WALLET_LIMITCHECK_COUNTRIES = "walletLimit_countries";
	
	public static final String WALLET_DAILY_LIMIT = "daily_walletLimit";
	
	public static final String WALLET_REFERENCE_NUM_GENERATOR = "WALLET_REFERENCE_NUM_GENERATOR";
	
	public static final String INFOFIELD9 = "INFOFIELD9";
	
	public static final String ISO_LIST_CURR_PRECISION = "_ISO_LIST_CURR_PRECISION";
	
}
