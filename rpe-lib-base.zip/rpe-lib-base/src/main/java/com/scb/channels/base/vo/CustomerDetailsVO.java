package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CustomerDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5794226757204914223L;
	
	private String uUser;
	private String ctryCd;
	private String custIdType;
	private String custId;
	private String custName1;
	private String custName2;
	private String custName3;
	private String nickname;
	private String segmentCd;
	private Calendar dtReg;
	private Calendar dtAct;
	private String custSex;
	private String custMaritalStsCd;
	private Calendar dateOfBirth;
	private String countryOfResidence;
	private String countryOfOrigin;
	private String residentStatus; 
	private Date dtCreated;
	private String createdBy;
	private Date dtUpd;
	private Integer version;
	private String email;
	private String mobile;
	private List<ContactDetailsVO> contactDetailsVO;
	
	private List<MasterDetailsVO> masterVO;
	
	public String getuUser() {
		return uUser;
	}
	public void setuUser(String uUser) {
		this.uUser = uUser;
	}
	public String getCtryCd() {
		return ctryCd;
	}
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	public String getCustIdType() {
		return custIdType;
	}
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustName1() {
		return custName1;
	}
	public void setCustName1(String custName1) {
		this.custName1 = custName1;
	}
	public String getCustName2() {
		return custName2;
	}
	public void setCustName2(String custName2) {
		this.custName2 = custName2;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public Calendar getDtReg() {
		return dtReg;
	}
	public void setDtReg(Calendar dtReg) {
		this.dtReg = dtReg;
	}
	public Calendar getDtAct() {
		return dtAct;
	}
	public void setDtAct(Calendar dtAct) {
		this.dtAct = dtAct;
	}
	public String getCustSex() {
		return custSex;
	}
	public void setCustSex(String custSex) {
		this.custSex = custSex;
	}
	public String getCustMaritalStsCd() {
		return custMaritalStsCd;
	}
	public void setCustMaritalStsCd(String custMaritalStsCd) {
		this.custMaritalStsCd = custMaritalStsCd;
	}
	public Calendar getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Calendar dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getCountryOfResidence() {
		return countryOfResidence;
	}
	public void setCountryOfResidence(String countryOfResidence) {
		this.countryOfResidence = countryOfResidence;
	}
	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}
	public String getResidentStatus() {
		return residentStatus;
	}
	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getDtUpd() {
		return dtUpd;
	}
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return the custName3
	 */
	public String getCustName3() {
		return custName3;
	}
	/**
	 * @param custName3 the custName3 to set
	 */
	public void setCustName3(String custName3) {
		this.custName3 = custName3;
	}
	public List<ContactDetailsVO> getContactDetailsVO() {
		return contactDetailsVO;
	}
	public void setContactDetailsVO(List<ContactDetailsVO> contactDetailsVO) {
		this.contactDetailsVO = contactDetailsVO;
	}
	/**
	 * @return the masterVO
	 */
	public List<MasterDetailsVO> getMasterVO() {
		return masterVO;
	}
	/**
	 * @param masterVO the masterVO to set
	 */
	public void setMasterVO(List<MasterDetailsVO> masterVO) {
		this.masterVO = masterVO;
	}
	
}
