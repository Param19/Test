package com.scb.channels.base.vo;

public class AccountChangeRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7577555641944000032L;
	private String relNO;
	private String defaultAccountNo;
	private String opreatingAccountNo;
	
	private int version;
	
	public String getRelNO() {
		return relNO;
	}
	public void setRelNO(String relNO) {
		this.relNO = relNO;
	}
	public String getDefaultAccountNo() {
		return defaultAccountNo;
	}
	public void setDefaultAccountNo(String defaultAccountNo) {
		this.defaultAccountNo = defaultAccountNo;
	}
	public String getOpreatingAccountNo() {
		return opreatingAccountNo;
	}
	public void setOpreatingAccountNo(String opreatingAccountNo) {
		this.opreatingAccountNo = opreatingAccountNo;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	
	
	
}
