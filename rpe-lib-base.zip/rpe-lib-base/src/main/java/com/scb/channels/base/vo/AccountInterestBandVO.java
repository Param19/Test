package com.scb.channels.base.vo;

import java.io.Serializable;

public class AccountInterestBandVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2474231526846707051L;
	
	private String addToGlobalRateBandFlag;
    private String bandAmount;
    private String bandOffset;
    private String creditDebitExcessFlag;
    private String bandSequenceNumber;
	
    
    public String getAddToGlobalRateBandFlag() {
		return addToGlobalRateBandFlag;
	}
	public void setAddToGlobalRateBandFlag(String addToGlobalRateBandFlag) {
		this.addToGlobalRateBandFlag = addToGlobalRateBandFlag;
	}
	public String getBandAmount() {
		return bandAmount;
	}
	public void setBandAmount(String bandAmount) {
		this.bandAmount = bandAmount;
	}
	public String getBandOffset() {
		return bandOffset;
	}
	public void setBandOffset(String bandOffset) {
		this.bandOffset = bandOffset;
	}
	public String getCreditDebitExcessFlag() {
		return creditDebitExcessFlag;
	}
	public void setCreditDebitExcessFlag(String creditDebitExcessFlag) {
		this.creditDebitExcessFlag = creditDebitExcessFlag;
	}
	public String getBandSequenceNumber() {
		return bandSequenceNumber;
	}
	public void setBandSequenceNumber(String bandSequenceNumber) {
		this.bandSequenceNumber = bandSequenceNumber;
	}

}
