package com.scb.channels.base.vo;

import org.apache.commons.lang.ArrayUtils;

/**
 * The Class MenuRequestParams.
 */
public class MenuRequestParams {
	
	/** The customer number. */
	private String customerNumber;
	// Mobile Number
	/** The mobile number. */
	private String mobileNumber;
    // Country Code	
	/** The country code. */
    private String countryCode;
    // Service Code  
	/** The service code. */
    private String serviceCode;
    // Customer Account Number
	/** The account number. */
    private String accountNumber;
    //Customer from Account Numbere - (while doing funds Transfer)
	/** The from account number. */
    private String fromAccountNumber;
	//Customer To Account Numbere - (while doing funds Transfer)
	/** The to account number. */
	private String toAccountNumber;
    // Transaction Amount for Funds transfer
	/** The trn amount. */
    private String trnAmount;
    // Customer Credit Card Number
	/** The creditc card number. */
    private String creditcCardNumber;
    // Currency type
	/** The currency type. */
    private String currencyType;
    // Customer mobile Banking old PIN
	/** The Cust old pin. */
    private String CustOldPin;
	// Customer mobile Banking New PIN
	/** The Cust new pin. */
	private String CustNewPin;
	
	/** The biller id. */
	private String billerId;
	
	/** The userid. */
	private String userid;
	
	/** The passwd. */
	private String passwd;
	
	/** The IBF t_ bank name. */
	private String IBFT_BankName;
	
	/** The IBF t_acct aliase name. */
	private String IBFT_acctAliaseName;
	
	/** The Sessionid_reversal. */
	private String Sessionid_reversal;
	
	/** The biller category. */
	private String billerCategory;
	// Customer Credit Card Number List
	/** The card number list. */
	private java.util.List<String> cardNumberList;
	// Customer Card Type List 
	/** The card type list. */
	private java.util.List<String> cardTypeList;
	// Customer Credit Card Outstanding Balance List
	/** The out standing balance list. */
	private java.util.List<String> outStandingBalanceList;
	//Customer AccountNumber List
	/** The Account numbers. */
	private java.util.List<String> AccountNumbers;	
    // Customer own Account Numnbers
	/** The str from account number. */
    private String[] strFromAccountNumber;
    //Customer Nominated Account Numbers or To Account Number for Funds Transfer
	/** The str to account number. */
    private String[] strToAccountNumber;
    // Mobile Banking PIN
	/** The m pin. */
    private String mPin;
    // Card Paymment Amount
	/** The cardpayment amount. */
    private String cardpaymentAmount;
	
	/** The topup amount. */
	private String topupAmount;
	
	/** The Billpay account. */
	private String BillpayAccount;
	
	/** The Billpay details. */
	private String BillpayDetails;

	/** The topup mobile no. */
	private String topupMobileNo;
	
	/** The topup debit account. */
	private String topupDebitAccount;
	
	/** The transaction id. */
	private String transactionId;

	/** The function code. */
	private String functionCode;
	
	/** The etran status. */
	private String etranStatus;
    
    /** The SCB sessionid. */
    private String SCBSessionid;
    
    /** The Biller no. */
    private String BillerNo;
    
    /** The provider. */
    private String provider;
    
    /** The device id. */
    private String deviceID; 
    
    private String DeviceID;
    
    /** The cheque no. */
    private String chequeNo;
    
    /** The reason desc. */
    private String reasonDesc;
    
    
    private String payBillNo;
    private String mpesaCustRefNo;
    private String mpesaReceiptNo;
    
    /**
     * Gets the provider.
     *
     * @return the provider
     */
    public String getProvider() {
		return provider;
	}

	/**
	 * Sets the provider.
	 *
	 * @param provider the new provider
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}

	/**
	 * Gets the biller no.
	 *
	 * @return the biller no
	 */
	public String getBillerNo() {
		return BillerNo;
	}

	/**
	 * Sets the biller no.
	 *
	 * @param billerNo the new biller no
	 */
	public void setBillerNo(String billerNo) {
		BillerNo = billerNo;
	}

	
    
   //1-USSD,2-Black Berry,3-Iphone,4-Andriod
    
	/**
    * Gets the device id.
    *
    * @return the device id
    */
   public String getDeviceID() {
		return deviceID == null ? DeviceID : deviceID;
	}

	/**
	 * Sets the device id.
	 *
	 * @param deviceID the new device id
	 */
	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
		this.DeviceID = deviceID;
	}

	/**
	 * Gets the sCB sessionid.
	 *
	 * @return the sCB sessionid
	 */
	public String getSCBSessionid() {
		return SCBSessionid;
	}

	/**
	 * Sets the sCB sessionid.
	 *
	 * @param sCBSessionid the new sCB sessionid
	 */
	public void setSCBSessionid(String sCBSessionid) {
		SCBSessionid = sCBSessionid;
	}

	/**
	 * Gets the etran status.
	 *
	 * @return the etran status
	 */
	public String getEtranStatus() {
		return etranStatus;
	}

	/**
	 * Sets the etran status.
	 *
	 * @param etranStatus the new etran status
	 */
	public void setEtranStatus(String etranStatus) {
		this.etranStatus = etranStatus;
	}

	/**
	 * Gets the function code.
	 *
	 * @return the function code
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * Sets the function code.
	 *
	 * @param functionCode the new function code
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	/**
	 * Gets the transaction id.
	 *
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	//mini statement - Transactions Details Count
	/** The trn count. */
	int trnCount;
    
    /**
     * Gets the trn count.
     *
     * @return the trn count
     */
    public int getTrnCount() {
		return trnCount;
	}

    /** The from date. */
    private String fromDate;
    
    /**
     * Gets the from date.
     *
     * @return the from date
     */
    public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/** The to date. */
	private String toDate;
    
	/**
	 * Gets the to date.
	 *
	 * @return the to date
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the new to date
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * Sets the trn count.
	 *
	 * @param trnCount the new trn count
	 */
	public void setTrnCount(int trnCount) {
		this.trnCount = trnCount;
	}

	/**
	 * Gets the cardpayment amount.
	 *
	 * @return the cardpayment amount
	 */
	public String getCardpaymentAmount() {
		return cardpaymentAmount;
	}

	/**
	 * Sets the cardpayment amount.
	 *
	 * @param cardpaymentAmount the new cardpayment amount
	 */
	public void setCardpaymentAmount(String cardpaymentAmount) {
		this.cardpaymentAmount = cardpaymentAmount;
	}

	/**
	 * Gets the m pin.
	 *
	 * @return the m pin
	 */
	public String getmPin() {
		return mPin;
	}

	/**
	 * Sets the m pin.
	 *
	 * @param mPin the new m pin
	 */
	public void setmPin(String mPin) {
		this.mPin = mPin;
	}

	/**
	 * Gets the customer number.
	 *
	 * @return the customer number
	 */
	public String getCustomerNumber() {
		return customerNumber;
	}

	/**
	 * Sets the customer number.
	 *
	 * @param customerNumber the new customer number
	 */
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	/**
	 * Gets the mobile number.
	 *
	 * @return the mobile number
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Sets the mobile number.
	 *
	 * @param mobileNumber the new mobile number
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * Sets the country code.
	 *
	 * @param countryCode the new country code
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * Gets the service code.
	 *
	 * @return the service code
	 */
	public String getServiceCode() {
		return serviceCode;
	}

	/**
	 * Sets the service code.
	 *
	 * @param serviceCode the new service code
	 */
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the from account number.
	 *
	 * @return the from account number
	 */
	public String getFromAccountNumber() {
		return fromAccountNumber;
	}

	/**
	 * Sets the from account number.
	 *
	 * @param fromAccountNumber the new from account number
	 */
	public void setFromAccountNumber(String fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}

	/**
	 * Gets the to account number.
	 *
	 * @return the to account number
	 */
	public String getToAccountNumber() {
		return toAccountNumber;
	}

	/**
	 * Sets the to account number.
	 *
	 * @param toAccountNumber the new to account number
	 */
	public void setToAccountNumber(String toAccountNumber) {
		this.toAccountNumber = toAccountNumber;
	}

	/**
	 * Gets the trn amount.
	 *
	 * @return the trn amount
	 */
	public String getTrnAmount() {
		return trnAmount;
	}

	/**
	 * Sets the trn amount.
	 *
	 * @param trnAmount the new trn amount
	 */
	public void setTrnAmount(String trnAmount) {
		this.trnAmount = trnAmount;
	}

	/**
	 * Gets the creditc card number.
	 *
	 * @return the creditc card number
	 */
	public String getCreditcCardNumber() {
		return creditcCardNumber;
	}

	/**
	 * Sets the creditc card number.
	 *
	 * @param creditcCardNumber the new creditc card number
	 */
	public void setCreditcCardNumber(String creditcCardNumber) {
		this.creditcCardNumber = creditcCardNumber;
	}

	/**
	 * Gets the currency type.
	 *
	 * @return the currency type
	 */
	public String getCurrencyType() {
		return currencyType;
	}

	/**
	 * Sets the currency type.
	 *
	 * @param currencyType the new currency type
	 */
	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	/**
	 * Gets the cust old pin.
	 *
	 * @return the cust old pin
	 */
	public String getCustOldPin() {
		return CustOldPin;
	}

	/**
	 * Sets the cust old pin.
	 *
	 * @param custOldPin the new cust old pin
	 */
	public void setCustOldPin(String custOldPin) {
		CustOldPin = custOldPin;
	}


	
	/**
	 * Gets the billpay details.
	 *
	 * @return the billpay details
	 */
	public String getBillpayDetails() {
		return BillpayDetails;
	}

	/**
	 * Sets the billpay details.
	 *
	 * @param billpayDetails the new billpay details
	 */
	public void setBillpayDetails(String billpayDetails) {
		BillpayDetails = billpayDetails;
	}

	/**
	 * Gets the billpay account.
	 *
	 * @return the billpay account
	 */
	public String getBillpayAccount() {
		return BillpayAccount;
	}

	/**
	 * Sets the billpay account.
	 *
	 * @param billpayAccount the new billpay account
	 */
	public void setBillpayAccount(String billpayAccount) {
		BillpayAccount = billpayAccount;
	}

	/**
	 * Gets the topup amount.
	 *
	 * @return the topup amount
	 */
	public String getTopupAmount() {
		return topupAmount;
	}

	/**
	 * Gets the topup mobile no.
	 *
	 * @return the topup mobile no
	 */
	public String getTopupMobileNo() {
		return topupMobileNo;
	}

	/**
	 * Sets the topup mobile no.
	 *
	 * @param topupMobileNo the new topup mobile no
	 */
	public void setTopupMobileNo(String topupMobileNo) {
		this.topupMobileNo = topupMobileNo;
	}

	/**
	 * Gets the topup debit account.
	 *
	 * @return the topup debit account
	 */
	public String getTopupDebitAccount() {
		return topupDebitAccount;
	}

	/**
	 * Sets the topup debit account.
	 *
	 * @param topupDebitAccount the new topup debit account
	 */
	public void setTopupDebitAccount(String topupDebitAccount) {
		this.topupDebitAccount = topupDebitAccount;
	}

	/**
	 * Sets the topup amount.
	 *
	 * @param topupAmount the new topup amount
	 */
	public void setTopupAmount(String topupAmount) {
		this.topupAmount = topupAmount;
	}


	/**
	 * Gets the card number list.
	 *
	 * @return the card number list
	 */
	public java.util.List<String> getCardNumberList() {
		return this.cardNumberList;
	}

	/**
	 * Sets the card number list.
	 *
	 * @param cardNumberList the new card number list
	 */
	public void setCardNumberList(java.util.List<String> cardNumberList) {
		this.cardNumberList = cardNumberList;
	}

	/**
	 * Gets the card type list.
	 *
	 * @return the card type list
	 */
	public java.util.List<String> getCardTypeList() {
		return cardTypeList;
	}

	/**
	 * Sets the card type list.
	 *
	 * @param cardTypeList the new card type list
	 */
	public void setCardTypeList(java.util.List<String> cardTypeList) {
		this.cardTypeList = cardTypeList;
	}

	/**
	 * Gets the out standing balance list.
	 *
	 * @return the out standing balance list
	 */
	public java.util.List<String> getOutStandingBalanceList() {
		return outStandingBalanceList;
	}

	/**
	 * Sets the out standing balance list.
	 *
	 * @param outStandingBalanceList the new out standing balance list
	 */
	public void setOutStandingBalanceList(java.util.List<String> outStandingBalanceList) {
		this.outStandingBalanceList = outStandingBalanceList;
	}

	/**
	 * Gets the account numbers.
	 *
	 * @return the account numbers
	 */
	public java.util.List<String> getAccountNumbers() {
		return AccountNumbers;
	}

	/**
	 * Sets the account numbers.
	 *
	 * @param accountNumbers the new account numbers
	 */
	public void setAccountNumbers(java.util.List<String> accountNumbers) {
		AccountNumbers = accountNumbers;
	}

	/**
	 * Gets the str from account number.
	 *
	 * @return the str from account number
	 */
	public String[] getStrFromAccountNumber() {
		return strFromAccountNumber;
	}

	/**
	 * Sets the str from account number.
	 *
	 * @param strFromAccountNumber the new str from account number
	 */
	public void setStrFromAccountNumber(String[] strFromAccountNumber) {
		 if (strFromAccountNumber != null && ArrayUtils.isNotEmpty(strFromAccountNumber)) {
			   this.strFromAccountNumber = new String[strFromAccountNumber.length];
			   ArrayUtils.addAll(this.strFromAccountNumber, strFromAccountNumber);
		 }
	}

	/**
	 * Gets the str to account number.
	 *
	 * @return the str to account number
	 */
	public String[] getStrToAccountNumber() {
		return strToAccountNumber;
	}

	/**
	 * Sets the str to account number.
	 *
	 * @param strToAccountNumber the new str to account number
	 */
	public void setStrToAccountNumber(String[] strToAccountNumber) {
		 if (strToAccountNumber != null && ArrayUtils.isNotEmpty(strToAccountNumber)) {
			   this.strToAccountNumber = new String[strToAccountNumber.length];
			   ArrayUtils.addAll(this.strToAccountNumber, strToAccountNumber);
		 }
	}
	
	/**
	 * Gets the userid.
	 *
	 * @return the userid
	 */
	public String getUserid() {
		return userid;
	}
	
	/**
	 * Sets the userid.
	 *
	 * @param userid the new userid
	 */
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	/**
	 * Gets the passwd.
	 *
	 * @return the passwd
	 */
	public String getPasswd() {
		return passwd;
	}
	
	/**
	 * Sets the passwd.
	 *
	 * @param passwd the new passwd
	 */
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	
	/**
	 * Gets the iBF t_ bank name.
	 *
	 * @return the iBF t_ bank name
	 */
	public String getIBFT_BankName() {
		return IBFT_BankName;
	}
	
	/**
	 * Sets the iBF t_ bank name.
	 *
	 * @param iBFT_BankName the new iBF t_ bank name
	 */
	public void setIBFT_BankName(String iBFT_BankName) {
		IBFT_BankName = iBFT_BankName;
	}
	
	/**
	 * Gets the iBF t_acct aliase name.
	 *
	 * @return the iBF t_acct aliase name
	 */
	public String getIBFT_acctAliaseName() {
		return IBFT_acctAliaseName;
	}
	
	/**
	 * Sets the iBF t_acct aliase name.
	 *
	 * @param iBFT_acctAliaseName the new iBF t_acct aliase name
	 */
	public void setIBFT_acctAliaseName(String iBFT_acctAliaseName) {
		IBFT_acctAliaseName = iBFT_acctAliaseName;
	}
	
	/**
	 * Gets the biller id.
	 *
	 * @return the biller id
	 */
	public String getBillerId() {
		return billerId;
	}
	
	/**
	 * Sets the biller id.
	 *
	 * @param billerId the new biller id
	 */
	public void setBillerId(String billerId) {
		this.billerId = billerId;
	}
	
	 /**
 	 * Gets the biller category.
 	 *
 	 * @return the biller category
 	 */
 	public String getBillerCategory() {
			return billerCategory;
		}
		
		/**
		 * Sets the biller category.
		 *
		 * @param billerCategory the new biller category
		 */
		public void setBillerCategory(String billerCategory) {
			this.billerCategory = billerCategory;
		}
	     
	    /**
    	 * Gets the sessionid_reversal.
    	 *
    	 * @return the sessionid_reversal
    	 */
    	public String getSessionid_reversal() {
			return Sessionid_reversal;
		}

		/**
		 * Sets the sessionid_reversal.
		 *
		 * @param sessionid_reversal the new sessionid_reversal
		 */
		public void setSessionid_reversal(String sessionid_reversal) {
			Sessionid_reversal = sessionid_reversal;
		}
		 
		/**
		 * Gets the cust new pin.
		 *
		 * @return the cust new pin
		 */
		public String getCustNewPin() {
			return CustNewPin;
		}

		/**
		 * Sets the cust new pin.
		 *
		 * @param custNewPin the new cust new pin
		 */
		public void setCustNewPin(String custNewPin) {
			CustNewPin = custNewPin;
		}

		
	 /**
 	 * Instantiates a new menu request params.
 	 */
 	public MenuRequestParams()
	 {
		 
	 }
    
    /**
     * Instantiates a new menu request params.
     *
     * @param mobileNumber the mobile number
     * @param customerNumber the customer number
     * @param countryCode the country code
     * @param serviceCode the service code
     * @param accountNumber the account number
     * @param fromAccountNumber the from account number
     * @param toAccountNumber the to account number
     * @param trnAmount the trn amount
     * @param creditcCardNumber the creditc card number
     * @param currencyType the currency type
     * @param CustOldPin the cust old pin
     * @param custNewPin the cust new pin
     * @param strCardBalDeatils the str card bal deatils
     * @param strCasaAccountDeatils the str casa account deatils
     * @param cardNumberList the card number list
     * @param cardTypeList the card type list
     * @param outStandingBalanceList the out standing balance list
     * @param AccountNumbers the account numbers
     * @param strFromAccountNumber the str from account number
     * @param strToAccountNumber the str to account number
     */
    public MenuRequestParams(
           String mobileNumber,
           String customerNumber,
           String countryCode,
           String serviceCode,
           String accountNumber,
           String fromAccountNumber,
           String toAccountNumber,
           String trnAmount,
           String creditcCardNumber,
           String currencyType,
           String CustOldPin,
           String custNewPin,  
           String[] strCardBalDeatils,
           String[] strCasaAccountDeatils,   
           java.util.List<String> cardNumberList,
       	   java.util.List<String> cardTypeList,
       	   java.util.List<String> outStandingBalanceList,
       	   java.util.List<String> AccountNumbers,	
           String[] strFromAccountNumber,
           String[] strToAccountNumber) 
    {
    	  this.mobileNumber=mobileNumber;
    	  this.customerNumber=customerNumber;
    	  this.countryCode=countryCode;
    	  this.serviceCode=serviceCode;
    	  this.accountNumber=accountNumber;
    	  this.fromAccountNumber=fromAccountNumber;
    	  this.toAccountNumber=toAccountNumber;
    	  this.trnAmount=trnAmount;
    	  this.creditcCardNumber=creditcCardNumber;
    	  this.currencyType=currencyType;
    	  this.CustOldPin=CustOldPin;
    	  this.CustNewPin=custNewPin;     
          this.cardNumberList=cardNumberList;
      	  this.cardTypeList=cardTypeList;
      	  this.outStandingBalanceList=outStandingBalanceList;
      	  this.AccountNumbers=AccountNumbers;
      	 if (strFromAccountNumber != null && ArrayUtils.isNotEmpty(strFromAccountNumber)) {
			   this.strFromAccountNumber = new String[strFromAccountNumber.length];
			   ArrayUtils.addAll(this.strFromAccountNumber, strFromAccountNumber);
		 }
      	 if (strToAccountNumber != null && ArrayUtils.isNotEmpty(strToAccountNumber)) {
			   this.strToAccountNumber = new String[strToAccountNumber.length];
			   ArrayUtils.addAll(this.strToAccountNumber, strToAccountNumber);
		 }
    }

	/**
	 * Gets the cheque no.
	 *
	 * @return the chequeNo
	 */
	public String getChequeNo() {
		return chequeNo;
	}

	/**
	 * Sets the cheque no.
	 *
	 * @param chequeNo the chequeNo to set
	 */
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	/**
	 * Gets the reason desc.
	 *
	 * @return the reasonDesc
	 */
	public String getReasonDesc() {
		return reasonDesc;
	}

	/**
	 * Sets the reason desc.
	 *
	 * @param reasonDesc the reasonDesc to set
	 */
	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}

	/**
	 * @return the payBillNo
	 */
	public String getPayBillNo() {
		return payBillNo;
	}

	/**
	 * @param payBillNo the payBillNo to set
	 */
	public void setPayBillNo(String payBillNo) {
		this.payBillNo = payBillNo;
	}

	/**
	 * @return the mpesaCustRefNo
	 */
	public String getMpesaCustRefNo() {
		return mpesaCustRefNo;
	}

	/**
	 * @param mpesaCustRefNo the mpesaCustRefNo to set
	 */
	public void setMpesaCustRefNo(String mpesaCustRefNo) {
		this.mpesaCustRefNo = mpesaCustRefNo;
	}

	/**
	 * @return the mpesaReceiptNo
	 */
	public String getMpesaReceiptNo() {
		return mpesaReceiptNo;
	}

	/**
	 * @param mpesaReceiptNo the mpesaReceiptNo to set
	 */
	public void setMpesaReceiptNo(String mpesaReceiptNo) {
		this.mpesaReceiptNo = mpesaReceiptNo;
	}

}
