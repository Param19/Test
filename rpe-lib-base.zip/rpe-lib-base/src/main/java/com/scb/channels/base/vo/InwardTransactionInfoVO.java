package com.scb.channels.base.vo;

/**
 * The Class InwardTransactionInfo.
 *
 * @author 1493439
 */
public class InwardTransactionInfoVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5890941885710419965L;

	/** The account number. */
	private String accountNumber;
	
	/** The amount. */
	private String amount;
	
	/** The currency. */
	private String currency;
	
	/** The remarks. */
	private String remarks;
	
	/** The merchant receipt number. */
	private String merchantReceiptNumber;
	
	/** The reserve1. */
	private String reserve1;
	
	/** The reserve2. */
	private String reserve2;
	
	/** The reserve3. */
	private String reserve3;
	
	/** The reference number. */
	private String referenceNumber;

	/**
	 * Gets the account number.
	 *
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * Gets the merchant receipt number.
	 *
	 * @return the merchantReceiptNumber
	 */
	public String getMerchantReceiptNumber() {
		return merchantReceiptNumber;
	}

	/**
	 * Sets the merchant receipt number.
	 *
	 * @param merchantReceiptNumber the merchantReceiptNumber to set
	 */
	public void setMerchantReceiptNumber(String merchantReceiptNumber) {
		this.merchantReceiptNumber = merchantReceiptNumber;
	}

	/**
	 * Gets the reserve1.
	 *
	 * @return the reserve1
	 */
	public String getReserve1() {
		return reserve1;
	}

	/**
	 * Sets the reserve1.
	 *
	 * @param reserve1 the reserve1 to set
	 */
	public void setReserve1(String reserve1) {
		this.reserve1 = reserve1;
	}

	/**
	 * Gets the reserve2.
	 *
	 * @return the reserve2
	 */
	public String getReserve2() {
		return reserve2;
	}

	/**
	 * Sets the reserve2.
	 *
	 * @param reserve2 the reserve2 to set
	 */
	public void setReserve2(String reserve2) {
		this.reserve2 = reserve2;
	}

	/**
	 * Gets the reserve3.
	 *
	 * @return the reserve3
	 */
	public String getReserve3() {
		return reserve3;
	}

	/**
	 * Sets the reserve3.
	 *
	 * @param reserve3 the reserve3 to set
	 */
	public void setReserve3(String reserve3) {
		this.reserve3 = reserve3;
	}

	/**
	 * Gets the reference number.
	 *
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * Sets the reference number.
	 *
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InwardTransactionInfo [accountNumber=" + accountNumber
				+ ", amount=" + amount + ", currency=" + currency
				+ ", remarks=" + remarks + ", merchantReceiptNumber="
				+ merchantReceiptNumber + ", reserve1=" + reserve1
				+ ", reserve2=" + reserve2 + ", reserve3=" + reserve3
				+ ", referenceNumber=" + referenceNumber + "]";
	}
	
}
