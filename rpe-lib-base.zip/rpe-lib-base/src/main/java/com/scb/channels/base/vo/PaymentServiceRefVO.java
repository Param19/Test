package com.scb.channels.base.vo;



//@Entity
//@Table(name="TBL_PYMT_SERVICE_REF")
public class PaymentServiceRefVO {

//	@Id
//	@GeneratedValue
	private int id;
	
//	@Column(name="CATEGORY")
	private String category;
	
	//@Column(name="CODE")
	private String code;
	
	//@Column(name="VALUE")
	private String value;

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
