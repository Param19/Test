package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterErrorResponse {
	
	private String RequestId;
	
	private String Source;
	
	private String ReasonCode;
	
	private String Description;
	
	private String Recoverable;
	
	private QRPaymentMasterErrorDetailsResponse Details;

	public String getRequestId() {
		return RequestId;
	}

	public void setRequestId(String requestId) {
		RequestId = requestId;
	}

	public String getSource() {
		return Source;
	}

	public void setSource(String source) {
		Source = source;
	}

	public String getReasonCode() {
		return ReasonCode;
	}

	public void setReasonCode(String reasonCode) {
		ReasonCode = reasonCode;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getRecoverable() {
		return Recoverable;
	}

	public void setRecoverable(String recoverable) {
		Recoverable = recoverable;
	}

	public QRPaymentMasterErrorDetailsResponse getDetails() {
		return Details;
	}

	public void setDetails(QRPaymentMasterErrorDetailsResponse details) {
		Details = details;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterErrorResponse [RequestId=" + RequestId
				+ ", Source=" + Source + ", ReasonCode=" + ReasonCode
				+ ", Description=" + Description + ", Recoverable="
				+ Recoverable + ", Details=" + Details + "]";
	}
	
	

}
