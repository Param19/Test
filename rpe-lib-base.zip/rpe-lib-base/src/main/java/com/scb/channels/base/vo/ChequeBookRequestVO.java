/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ChequeBookRequestVO.
 *
 * @author 1411807
 */
public class ChequeBookRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6912254585635401769L;
	
	/** The status cd. */
	private String statusCd;	
	
	/** The application type. */
	private String applicationType;
	
	/** The no of check book. */
	private String noOfCheckBook;
	
	/** The no of leaf. */
	private String noOfLeaf;
	
	/** The version. */
	private int version;
	
	private String accountNo;
	
	

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the application type.
	 *
	 * @return the application type
	 */
	public String getApplicationType() {
		return applicationType;
	}
	
	/**
	 * Sets the application type.
	 *
	 * @param applicationType the new application type
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	
	/**
	 * Gets the no of check book.
	 *
	 * @return the no of check book
	 */
	public String getNoOfCheckBook() {
		return noOfCheckBook;
	}
	
	/**
	 * Sets the no of check book.
	 *
	 * @param noOfCheckBook the new no of check book
	 */
	public void setNoOfCheckBook(String noOfCheckBook) {
		this.noOfCheckBook = noOfCheckBook;
	}
	
	/**
	 * Gets the no of leaf.
	 *
	 * @return the no of leaf
	 */
	public String getNoOfLeaf() {
		return noOfLeaf;
	}
	
	/**
	 * Sets the no of leaf.
	 *
	 * @param noOfLeaf the new no of leaf
	 */
	public void setNoOfLeaf(String noOfLeaf) {
		this.noOfLeaf = noOfLeaf;
	}
	
	/**
	 * Gets the segment cd.
	 *
	 * @return the segment cd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	
	/**
	 * Sets the segment cd.
	 *
	 * @param segmentCd the new segment cd
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	
	/** The segment cd. */
	private String segmentCd;



	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	

}
