package com.scb.channels.base.vo;

import javax.xml.datatype.XMLGregorianCalendar;

public class BillerDownloadRequest extends BaseVO {
 
	private static final long serialVersionUID = 1933813025334615512L;
	private String channelName;
	private String internalRequestId;	
	private String  aggregatorName;
	private String  aggregatorShortCode;
	private String  typeName;
 	private String 	subTypeName;
 	private String  messageSender;
 	private String  domainName;
 	private String  eventType;
 	private String  payloadFormat;
 	private String  envName;
 	private String  subDomainType;
 	private XMLGregorianCalendar  currentTime;
 	private String captureSystem;
 	private String aggregatorRefNo;
	private boolean possibleDuplicate=true;
	private String billerCatgoryId;
	private String billerId;
	private String defaultBillerField;
	private String aggregatorTerminalId;
	private String billerDownloadCategoryType;
	private String applicationUserID;
	private String applicationUserKey;
	private String downloadJobStatus;
	private String aggregatorIdentifier; 
	/**
	 * @return the aggregatorIdentifier
	 */
	public String getAggregatorIdentifier() {
		return aggregatorIdentifier;
	}
	/**
	 * @param aggregatorIdentifier the aggregatorIdentifier to set
	 */
	public void setAggregatorIdentifier(String aggregatorIdentifier) {
		this.aggregatorIdentifier = aggregatorIdentifier;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getDownloadJobStatus() {
		return downloadJobStatus;
	}
	public void setDownloadJobStatus(String downloadJobStatus) {
		this.downloadJobStatus = downloadJobStatus;
	}
	public String getDefaultBillerField() {
		return defaultBillerField;
	}
	public void setDefaultBillerField(String defaultBillerField) {
		this.defaultBillerField = defaultBillerField;
	}
	public String getApplicationUserID() {
		return applicationUserID;
	}
	public void setApplicationUserID(String applicationUserID) {
		this.applicationUserID = applicationUserID;
	}
	public String getApplicationUserKey() {
		return applicationUserKey;
	}
	public void setApplicationUserKey(String applicationUserKey) {
		this.applicationUserKey = applicationUserKey;
	}
	public String getBillerDownloadCategoryType() {
		return billerDownloadCategoryType;
	}
	public void setBillerDownloadCategoryType(String billerDownloadCategoryType) {
		this.billerDownloadCategoryType = billerDownloadCategoryType;
	}
	public String getAggregatorTerminalId() {
		return aggregatorTerminalId;
	}
	public void setAggregatorTerminalId(String aggregatorTerminalId) {
		this.aggregatorTerminalId = aggregatorTerminalId;
	}
	public String getInternalRequestId() {
		return internalRequestId;
	}
	public void setInternalRequestId(String internalRequestId) {
		this.internalRequestId = internalRequestId;
	}
	public String getBillerCatgoryId() {
		return billerCatgoryId;
	}
	public void setBillerCatgoryId(String billerCatgoryId) {
		this.billerCatgoryId = billerCatgoryId;
	}
	public String getBillerId() {
		return billerId;
	}
	public void setBillerId(String billerId) {
		this.billerId = billerId;
	}
	 
	public String getAggregatorRefNo() {
		return aggregatorRefNo;
	}
	public void setAggregatorRefNo(String aggregatorRefNo) {
		this.aggregatorRefNo = aggregatorRefNo;
	}
	public String getAggregatorShortCode() {
		return aggregatorShortCode;
	}
	public void setAggregatorShortCode(String aggregatorShortCode) {
		this.aggregatorShortCode = aggregatorShortCode;
	}
 	
	public String getCaptureSystem() {
		return captureSystem;
	}
	public void setCaptureSystem(String captureSystem) {
		this.captureSystem = captureSystem;
	}
	
	public boolean isPossibleDuplicate() {
		return possibleDuplicate;
	}
	public void setPossibleDuplicate(boolean possibleDuplicate) {
		this.possibleDuplicate = possibleDuplicate;
	}
	public XMLGregorianCalendar getCurrentTime() {
		return currentTime;
	}
	public void setCurrentTime(XMLGregorianCalendar currentTime) {
		this.currentTime = currentTime;
	}
	public String getSubDomainType() {
		return subDomainType;
	}
	public void setSubDomainType(String subDomainType) {
		this.subDomainType = subDomainType;
	}
	public String getEnvName() {
		return envName;
	}
	public void setEnvName(String envName) {
		this.envName = envName;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getPayloadFormat() {
		return payloadFormat;
	}
	public void setPayloadFormat(String payloadFormat) {
		this.payloadFormat = payloadFormat;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getMessageSender() {
		return messageSender;
	}
	public void setMessageSender(String messageSender) {
		this.messageSender = messageSender;
	}
	public String getSubTypeName() {
		return subTypeName;
	}
	public void setSubTypeName(String subTypeName) {
		this.subTypeName = subTypeName;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	 
 	public String getAggregatorName() {
		return aggregatorName;
	}
	public void setAggregatorName(String aggregatorName) {
		this.aggregatorName = aggregatorName;
	} 
	
}
