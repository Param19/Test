package com.scb.channels.base.vo;

public class AccountChangeResponseVO extends BaseVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5901784141093596255L;
	private String relNO;
	private String defaultAccountNo;
	private String opreatingAccountNo;
	private String changeStatus;
	private String respMsg;
	public String getRelNO() {
		return relNO;
	}
	public void setRelNO(String relNO) {
		this.relNO = relNO;
	}
	public String getDefaultAccountNo() {
		return defaultAccountNo;
	}
	public void setDefaultAccountNo(String defaultAccountNo) {
		this.defaultAccountNo = defaultAccountNo;
	}
	public String getOpreatingAccountNo() {
		return opreatingAccountNo;
	}
	public void setOpreatingAccountNo(String opreatingAccountNo) {
		this.opreatingAccountNo = opreatingAccountNo;
	}
	public String getChangeStatus() {
		return changeStatus;
	}
	public void setChangeStatus(String changeStatus) {
		this.changeStatus = changeStatus;
	}
	public String getRespMsg() {
		return respMsg;
	}
	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
