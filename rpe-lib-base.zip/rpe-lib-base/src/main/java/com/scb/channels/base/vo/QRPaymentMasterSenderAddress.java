package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentMasterSenderAddress implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8623365914467081212L;

	private String Line1;
	
	private String City;
	
	private String CountrySubdivision;
	
	private String PostalCode;
	
	private String Country;

	public String getLine1() {
		return Line1;
	}
	@JsonSetter("Line1")
	public void setLine1(String line1) {
		Line1 = line1;
	}

	public String getCity() {
		return City;
	}
	@JsonSetter("City")
	public void setCity(String city) {
		City = city;
	}

	public String getCountrySubdivision() {
		return CountrySubdivision;
	}
	@JsonSetter("CountrySubdivision")
	public void setCountrySubdivision(String countrySubdivision) {
		CountrySubdivision = countrySubdivision;
	}

	public String getPostalCode() {
		return PostalCode;
	}
	@JsonSetter("PostalCode")
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}

	public String getCountry() {
		return Country;
	}
	@JsonSetter("Country")
	public void setCountry(String country) {
		Country = country;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterSenderAddress [Line1=" + Line1 + ", City="
				+ City + ", CountrySubdivision=" + CountrySubdivision
				+ ", PostalCode=" + PostalCode + ", Country=" + Country + "]";
	}
	
	

}
