package com.scb.channels.base.vo;

import java.util.ArrayList;
import java.util.List;


public class QRMerchantVO {
	
	private Long merchant_seq_id;
	private String merchant_pan;
	private String merchant_city;
	private String merchant_name;
	private String merchant_category_code;
	private String merchant_postcode;
	private String network;
	private List<QRMerchantPanTypeVO> merchantPanList = new ArrayList<QRMerchantPanTypeVO>();

	public String getMerchant_city() {
		return merchant_city;
	}
	public void setMerchant_city(String merchant_city) {
		this.merchant_city = merchant_city;
	}
	public String getMerchant_name() {
		return merchant_name;
	}
	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}
	public String getMerchant_category_code() {
		return merchant_category_code;
	}
	public void setMerchant_category_code(String merchant_category_code) {
		this.merchant_category_code = merchant_category_code;
	}
	public String getMerchant_postcode() {
		return merchant_postcode;
	}
	public void setMerchant_postcode(String merchant_postcode) {
		this.merchant_postcode = merchant_postcode;
	}
	public Long getMerchant_seq_id() {
		return merchant_seq_id;
	}
	public void setMerchant_seq_id(Long merchant_seq_id) {
		this.merchant_seq_id = merchant_seq_id;
	}
	public String getMerchant_pan() {
		return merchant_pan;
	}
	public void setMerchant_pan(String merchant_pan) {
		this.merchant_pan = merchant_pan;
	}
	public List<QRMerchantPanTypeVO> getMerchantPanList() {
		return merchantPanList;
	}
	public void setMerchantPanList(List<QRMerchantPanTypeVO> merchantPanList) {
		this.merchantPanList = merchantPanList;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	@Override
	public String toString() {
		return "QRMerchantVO [merchant_seq_id=" + merchant_seq_id
				+ ", merchant_pan=" + merchant_pan + ", merchant_city="
				+ merchant_city + ", merchant_name=" + merchant_name
				+ ", merchant_category_code=" + merchant_category_code
				+ ", merchant_postcode=" + merchant_postcode + ", network="
				+ network + ", merchantPanList=" + merchantPanList + "]";
	}
	
}
