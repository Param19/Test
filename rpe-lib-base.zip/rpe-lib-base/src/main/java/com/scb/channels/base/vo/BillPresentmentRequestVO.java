package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillPresentmentRequestVO.
 */
public class BillPresentmentRequestVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7683864660547612191L;
	
	/** The biller pay details vo. */
	private BillerPayDetailsVO billerPayDetailsVO;
	
	private int version;
	
	
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	/**
	 * @return the billerPayDetailsVO
	 */
	public BillerPayDetailsVO getBillerPayDetailsVO() {
		return billerPayDetailsVO;
	}
	/**
	 * @param billerPayDetailsVO the billerPayDetailsVO to set
	 */
	public void setBillerPayDetailsVO(BillerPayDetailsVO billerPayDetailsVO) {
		this.billerPayDetailsVO = billerPayDetailsVO;
	}
	


}
