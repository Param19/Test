/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.scb.channels.base.helper.CommonConstants;

// TODO: Auto-generated Javadoc
/**
 * The Class BaseVO.
 *
 * @author 1464143
 */
public class BaseVO implements Serializable, Cloneable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2476180876061857348L;
	
	/** The host response vo. */
	private Set<HostResponseVO> hostResponseVO = new HashSet<HostResponseVO>();
	
	/** The user. */
	private UserVO user;
	
	/** The date created. */
	private Calendar dateCreated;
	
	/** The date updated. */
	private Calendar dateUpdated;
	
	/** The created by. */
	private String createdBy;
	
	/** The client vo. */
	private ClientVO clientVO;
	
	/** The service vo. */
	private ServiceVO serviceVO;
	
	/** The message vo. */
	private MessageVO messageVO;
	
	/** The pagination req vo. */
	private PaginationReqVO paginationReqVO;
	
	/** The pagination resp vo. */
	private PaginationRespVO paginationRespVO;
	
	/** The status. */
	private String status;
		
	/** The status desc. */
	private String statusDesc;
	
	/** The error cd. */
	private String errorCD;
	
	/** The error desc. */
	private String errorDesc;
	
	/** The processing mode. */
	private String processingMode = CommonConstants.ASYNC;
	
	/** The severity. */
	private String severity;
	
	
	/**
	 * Instantiates a new base vo.
	 */
	public BaseVO() {
	}

	/**
	 * Constructor for RequestVO.
	 *
	 * @param user UserVO
	 */
	public BaseVO(UserVO user) {
		this.user = user;
	}

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public UserVO getUser() {
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user the user to set
	 */
	public void setUser(UserVO user) {
		this.user = user;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the date created.
	 *
	 * @return the dateCreated
	 */
	public Calendar getDateCreated() {
		return dateCreated;
	}

	/**
	 * Sets the date created.
	 *
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(Calendar dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * Gets the date updated.
	 *
	 * @return the dateUpdated
	 */
	public Calendar getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * Sets the date updated.
	 *
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(Calendar dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	public BaseVO clone() throws CloneNotSupportedException {
		return (BaseVO) super.clone();
	}

	/**
	 * Gets the client vo.
	 *
	 * @return the clientVO
	 */
	public ClientVO getClientVO() {
		return clientVO;
	}

	/**
	 * Sets the client vo.
	 *
	 * @param clientVO the clientVO to set
	 */
	public void setClientVO(ClientVO clientVO) {
		this.clientVO = clientVO;
	}

	/**
	 * Gets the service vo.
	 *
	 * @return the serviceVO
	 */
	public ServiceVO getServiceVO() {
		return serviceVO;
	}

	/**
	 * Sets the service vo.
	 *
	 * @param serviceVO the serviceVO to set
	 */
	public void setServiceVO(ServiceVO serviceVO) {
		this.serviceVO = serviceVO;
	}

	/**
	 * Gets the message vo.
	 *
	 * @return the messageVO
	 */
	public MessageVO getMessageVO() {
		return messageVO;
	}

	/**
	 * Sets the message vo.
	 *
	 * @param messageVO the messageVO to set
	 */
	public void setMessageVO(MessageVO messageVO) {
		this.messageVO = messageVO;
	}

	

	/**
	 * Gets the status desc.
	 *
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * Sets the status desc.
	 *
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * Gets the pagination req vo.
	 *
	 * @return the paginationReqVO
	 */
	public PaginationReqVO getPaginationReqVO() {
		return paginationReqVO;
	}

	/**
	 * Sets the pagination req vo.
	 *
	 * @param paginationReqVO the paginationReqVO to set
	 */
	public void setPaginationReqVO(PaginationReqVO paginationReqVO) {
		this.paginationReqVO = paginationReqVO;
	}

	/**
	 * Gets the error cd.
	 *
	 * @return the errorCD
	 */
	public String getErrorCD() {
		return errorCD;
	}

	/**
	 * Sets the error cd.
	 *
	 * @param errorCD the errorCD to set
	 */
	public void setErrorCD(String errorCD) {
		this.errorCD = errorCD;
	}

	/**
	 * Gets the error desc.
	 *
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}

	/**
	 * Sets the error desc.
	 *
	 * @param errorDesc the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	/**
	 * Gets the pagination resp vo.
	 *
	 * @return the paginationRespVO
	 */
	public PaginationRespVO getPaginationRespVO() {
		return paginationRespVO;
	}

	/**
	 * Sets the pagination resp vo.
	 *
	 * @param paginationRespVO the paginationRespVO to set
	 */
	public void setPaginationRespVO(PaginationRespVO paginationRespVO) {
		this.paginationRespVO = paginationRespVO;
	}

	/**
	 * Gets the processing mode.
	 *
	 * @return the processingMode
	 */
	public String getProcessingMode() {
		return processingMode;
	}

	/**
	 * Sets the processing mode.
	 *
	 * @param processingMode the processingMode to set
	 */
	public void setProcessingMode(String processingMode) {
		this.processingMode = processingMode;
	}

	/**
	 * Gets the severity.
	 *
	 * @return the severity
	 */
	public String getSeverity() {
		return severity;
	}

	/**
	 * Sets the severity.
	 *
	 * @param severity the severity to set
	 */
	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public Set<HostResponseVO> getHostResponseVO() {
		return hostResponseVO;
	}

	public void setHostResponseVO(Set<HostResponseVO> hostResponseVO) {
		this.hostResponseVO = hostResponseVO;
	}

}
