/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class DBAuthVO.
 *
 * @author 1411807
 */
public class DBAuthVO extends AuthVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3121528935595439743L;
	
	/** The DB host name. */
	private String DBHostName;

	/**
	 * Gets the dB host name.
	 *
	 * @return the dBHostName
	 */
	public String getDBHostName() {
		return DBHostName;
	}

	/**
	 * Sets the dB host name.
	 *
	 * @param dBHostName the dBHostName to set
	 */
	public void setDBHostName(String dBHostName) {
		DBHostName = dBHostName;
	}

}
