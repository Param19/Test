/**
 * 
 */
package com.scb.channels.base.exception;

/**
 * The Class MessageTransformException.
 *
 * @author 1382158
 */
public class MaskException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -392284074075609738L;

	/**
	 * Instantiates a new message formatting exception.
	 *
	 * @param e the e
	 */
	public MaskException(Throwable e) {
		super(e);
	}
}