package com.scb.channels.base.vo;

import java.io.Serializable;

public class StatisticalBalanceVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8574917143145486847L;
	
	private String balanceDetailsAsOfIndicator;
    private String accountNumber;
    private String averageAvailableBalance;
    private String averageLedgerBalance;
    private String countOfCreditTransactions;
    private String creditAmountSum;
    private String accountCurrencyCode;
    private String countOfDebitTransactions;
    private String debitAmountSum;
    private String averageCreditAmount;
    private String averageDebitAmount;
    private String maximumAvailableBalance;
    private String maximumLedgerBalance;
    private String minimumAvailableBalance;
    private String minimumLedgerBalance;
    private String availableBalance;
    private String ledgerBalance;
    private String balanceApplicablePeriod;
    private String countOfTotalTransactions;
	
    
    public String getBalanceDetailsAsOfIndicator() {
		return balanceDetailsAsOfIndicator;
	}
	public void setBalanceDetailsAsOfIndicator(String balanceDetailsAsOfIndicator) {
		this.balanceDetailsAsOfIndicator = balanceDetailsAsOfIndicator;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAverageAvailableBalance() {
		return averageAvailableBalance;
	}
	public void setAverageAvailableBalance(String averageAvailableBalance) {
		this.averageAvailableBalance = averageAvailableBalance;
	}
	public String getAverageLedgerBalance() {
		return averageLedgerBalance;
	}
	public void setAverageLedgerBalance(String averageLedgerBalance) {
		this.averageLedgerBalance = averageLedgerBalance;
	}
	public String getCountOfCreditTransactions() {
		return countOfCreditTransactions;
	}
	public void setCountOfCreditTransactions(String countOfCreditTransactions) {
		this.countOfCreditTransactions = countOfCreditTransactions;
	}
	public String getCreditAmountSum() {
		return creditAmountSum;
	}
	public void setCreditAmountSum(String creditAmountSum) {
		this.creditAmountSum = creditAmountSum;
	}
	public String getAccountCurrencyCode() {
		return accountCurrencyCode;
	}
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}
	public String getCountOfDebitTransactions() {
		return countOfDebitTransactions;
	}
	public void setCountOfDebitTransactions(String countOfDebitTransactions) {
		this.countOfDebitTransactions = countOfDebitTransactions;
	}
	public String getDebitAmountSum() {
		return debitAmountSum;
	}
	public void setDebitAmountSum(String debitAmountSum) {
		this.debitAmountSum = debitAmountSum;
	}
	public String getAverageCreditAmount() {
		return averageCreditAmount;
	}
	public void setAverageCreditAmount(String averageCreditAmount) {
		this.averageCreditAmount = averageCreditAmount;
	}
	public String getAverageDebitAmount() {
		return averageDebitAmount;
	}
	public void setAverageDebitAmount(String averageDebitAmount) {
		this.averageDebitAmount = averageDebitAmount;
	}
	public String getMaximumAvailableBalance() {
		return maximumAvailableBalance;
	}
	public void setMaximumAvailableBalance(String maximumAvailableBalance) {
		this.maximumAvailableBalance = maximumAvailableBalance;
	}
	public String getMaximumLedgerBalance() {
		return maximumLedgerBalance;
	}
	public void setMaximumLedgerBalance(String maximumLedgerBalance) {
		this.maximumLedgerBalance = maximumLedgerBalance;
	}
	public String getMinimumAvailableBalance() {
		return minimumAvailableBalance;
	}
	public void setMinimumAvailableBalance(String minimumAvailableBalance) {
		this.minimumAvailableBalance = minimumAvailableBalance;
	}
	public String getMinimumLedgerBalance() {
		return minimumLedgerBalance;
	}
	public void setMinimumLedgerBalance(String minimumLedgerBalance) {
		this.minimumLedgerBalance = minimumLedgerBalance;
	}
	public String getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}
	public String getLedgerBalance() {
		return ledgerBalance;
	}
	public void setLedgerBalance(String ledgerBalance) {
		this.ledgerBalance = ledgerBalance;
	}
	public String getBalanceApplicablePeriod() {
		return balanceApplicablePeriod;
	}
	public void setBalanceApplicablePeriod(String balanceApplicablePeriod) {
		this.balanceApplicablePeriod = balanceApplicablePeriod;
	}
	public String getCountOfTotalTransactions() {
		return countOfTotalTransactions;
	}
	public void setCountOfTotalTransactions(String countOfTotalTransactions) {
		this.countOfTotalTransactions = countOfTotalTransactions;
	}

}
