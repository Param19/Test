package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;


public class QRFeeTypeVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -218740420153868674L;
	
	private String refId;
	private BigDecimal refValue;
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public BigDecimal getRefValue() {
		return refValue;
	}
	public void setRefValue(BigDecimal refValue) {
		this.refValue = refValue;
	}
	@Override
	public String toString() {
		return "QRFeeTypeVO [refId=" + refId + ", refValue=" + refValue + "]";
	}
	
	

}
