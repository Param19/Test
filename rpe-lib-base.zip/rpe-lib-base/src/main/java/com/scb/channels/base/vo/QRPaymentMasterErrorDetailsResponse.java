package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterErrorDetailsResponse {
	
	private QRPaymentMasterErrorDetailResponse Detail;

	public QRPaymentMasterErrorDetailResponse getDetail() {
		return Detail;
	}

	public void setDetail(QRPaymentMasterErrorDetailResponse detail) {
		Detail = detail;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterErrorDetailsResponse [Detail=" + Detail + "]";
	}
	
	

}
