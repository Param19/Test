package com.scb.channels.base.vo;


/**
 * The Class SecurityInfo.
 *
 * @author 1493439
 */
public class SecurityInfoVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3326047059759109074L;

	/** The apikey. */
	private String apikey;
	
	/** The auth token. */
	private String authToken;

	/**
	 * @return the apikey
	 */
	public String getApikey() {
		return apikey;
	}

	/**
	 * @param apikey the apikey to set
	 */
	public void setApikey(String apikey) {
		this.apikey = apikey;
	}

	/**
	 * @return the authToken
	 */
	public String getAuthToken() {
		return authToken;
	}

	/**
	 * @param authToken the authToken to set
	 */
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SecurityInfo [apikey=" + apikey + ", authToken=" + authToken
				+ "]";
	}
	
}
