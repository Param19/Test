package com.scb.channels.base.vo;
import java.util.Date;

public class CustInfoVO {

	private Integer id;
	private Integer uUser;
	private String ctryCd;
	private String custGroupId;
	private String custIdType;
	private String custId;
	private String custName1;
	private String custName2;
	private String nickname;
	private String email;
	private String mobilePhone;
	private String address1;
	private String address2;
	private String address3;
	private String address4;
	private String district;
	private String state;
	private String armCd;
	private String segmentCd;
	private Date dtReg;
	private String regBy;
	private String isRereg;
	private String isLetterGen;
	private String isAct;
	private Date dtAct;
	private Date dtServStart;
	private Date dtServEnd;
	private String custAccessKey;
	private Date dtSuspendStart;
	private Date dtSuspendEnd;
	private String ftlBrowserId;
	private Date ftlTermsAcceptDate;
	private String regMode;
	private String actvType;
	private String pinMailerSerNo;
	private Date dtPinMailerExp;
	private String twoFaTypCd;
	private String notifType;
	private Integer pinMailerCounter;
	private String remark;
	private String migrateFlag;
	private Date dtCreated;
	private String createdBy;
	private Date dtUpd;
	private String updBy;
	private Integer version;
	private String isEmailGen;
	private String reregReason;
	private Integer reregCount;
	private String operatingAccountNo;
	private String operatingAccountCurrency;
	private String isSmsAlertEnabled;
	private String isServicesEnabled;
	private String isEmailAlertEnabled;
	private String emailGenerationType;
	private String isHandsetLost;
	private Date handsetLostDate;
	private String mobileOperatorCode;
	private String mobileNetworkId;
	private String defaultAccountNo;
	private String defaultAccountCurrency;
	private String statusCd;
	
	
	public Integer getuUser() {
		return uUser;
	}
	public void setuUser(Integer uUser) {
		this.uUser = uUser;
	}
	public String getCtryCd() {
		return ctryCd;
	}
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	public String getCustGroupId() {
		return custGroupId;
	}
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	public String getCustIdType() {
		return custIdType;
	}
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustName1() {
		return custName1;
	}
	public void setCustName1(String custName1) {
		this.custName1 = custName1;
	}
	public String getCustName2() {
		return custName2;
	}
	public void setCustName2(String custName2) {
		this.custName2 = custName2;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getArmCd() {
		return armCd;
	}
	public void setArmCd(String armCd) {
		this.armCd = armCd;
	}
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public Date getDtReg() {
		return dtReg;
	}
	public void setDtReg(Date dtReg) {
		this.dtReg = dtReg;
	}
	public String getRegBy() {
		return regBy;
	}
	public void setRegBy(String regBy) {
		this.regBy = regBy;
	}
	public String getIsRereg() {
		return isRereg;
	}
	public void setIsRereg(String isRereg) {
		this.isRereg = isRereg;
	}
	public String getIsLetterGen() {
		return isLetterGen;
	}
	public void setIsLetterGen(String isLetterGen) {
		this.isLetterGen = isLetterGen;
	}
	public String getIsAct() {
		return isAct;
	}
	public void setIsAct(String isAct) {
		this.isAct = isAct;
	}
	public Date getDtAct() {
		return dtAct;
	}
	public void setDtAct(Date dtAct) {
		this.dtAct = dtAct;
	}
	public Date getDtServStart() {
		return dtServStart;
	}
	public void setDtServStart(Date dtServStart) {
		this.dtServStart = dtServStart;
	}
	public Date getDtServEnd() {
		return dtServEnd;
	}
	public void setDtServEnd(Date dtServEnd) {
		this.dtServEnd = dtServEnd;
	}
	public String getCustAccessKey() {
		return custAccessKey;
	}
	public void setCustAccessKey(String custAccessKey) {
		this.custAccessKey = custAccessKey;
	}
	public Date getDtSuspendStart() {
		return dtSuspendStart;
	}
	public void setDtSuspendStart(Date dtSuspendStart) {
		this.dtSuspendStart = dtSuspendStart;
	}
	public Date getDtSuspendEnd() {
		return dtSuspendEnd;
	}
	public void setDtSuspendEnd(Date dtSuspendEnd) {
		this.dtSuspendEnd = dtSuspendEnd;
	}
	public String getFtlBrowserId() {
		return ftlBrowserId;
	}
	public void setFtlBrowserId(String ftlBrowserId) {
		this.ftlBrowserId = ftlBrowserId;
	}
	public Date getFtlTermsAcceptDate() {
		return ftlTermsAcceptDate;
	}
	public void setFtlTermsAcceptDate(Date ftlTermsAcceptDate) {
		this.ftlTermsAcceptDate = ftlTermsAcceptDate;
	}
	public String getRegMode() {
		return regMode;
	}
	public void setRegMode(String regMode) {
		this.regMode = regMode;
	}
	public String getActvType() {
		return actvType;
	}
	public void setActvType(String actvType) {
		this.actvType = actvType;
	}
	public String getPinMailerSerNo() {
		return pinMailerSerNo;
	}
	public void setPinMailerSerNo(String pinMailerSerNo) {
		this.pinMailerSerNo = pinMailerSerNo;
	}
	public Date getDtPinMailerExp() {
		return dtPinMailerExp;
	}
	public void setDtPinMailerExp(Date dtPinMailerExp) {
		this.dtPinMailerExp = dtPinMailerExp;
	}
	public String getTwoFaTypCd() {
		return twoFaTypCd;
	}
	public void setTwoFaTypCd(String twoFaTypCd) {
		this.twoFaTypCd = twoFaTypCd;
	}
	public String getNotifType() {
		return notifType;
	}
	public void setNotifType(String notifType) {
		this.notifType = notifType;
	}
	public Integer getPinMailerCounter() {
		return pinMailerCounter;
	}
	public void setPinMailerCounter(Integer pinMailerCounter) {
		this.pinMailerCounter = pinMailerCounter;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getMigrateFlag() {
		return migrateFlag;
	}
	public void setMigrateFlag(String migrateFlag) {
		this.migrateFlag = migrateFlag;
	}
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getDtUpd() {
		return dtUpd;
	}
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	public String getUpdBy() {
		return updBy;
	}
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getIsEmailGen() {
		return isEmailGen;
	}
	public void setIsEmailGen(String isEmailGen) {
		this.isEmailGen = isEmailGen;
	}
	public String getReregReason() {
		return reregReason;
	}
	public void setReregReason(String reregReason) {
		this.reregReason = reregReason;
	}
	public Integer getReregCount() {
		return reregCount;
	}
	public void setReregCount(Integer reregCount) {
		this.reregCount = reregCount;
	}
	public String getOperatingAccountNo() {
		return operatingAccountNo;
	}
	public void setOperatingAccountNo(String operatingAccountNo) {
		this.operatingAccountNo = operatingAccountNo;
	}
	public String getOperatingAccountCurrency() {
		return operatingAccountCurrency;
	}
	public void setOperatingAccountCurrency(String operatingAccountCurrency) {
		this.operatingAccountCurrency = operatingAccountCurrency;
	}
	public String getIsSmsAlertEnabled() {
		return isSmsAlertEnabled;
	}
	public void setIsSmsAlertEnabled(String isSmsAlertEnabled) {
		this.isSmsAlertEnabled = isSmsAlertEnabled;
	}
	public String getIsServicesEnabled() {
		return isServicesEnabled;
	}
	public void setIsServicesEnabled(String isServicesEnabled) {
		this.isServicesEnabled = isServicesEnabled;
	}
	public String getIsEmailAlertEnabled() {
		return isEmailAlertEnabled;
	}
	public void setIsEmailAlertEnabled(String isEmailAlertEnabled) {
		this.isEmailAlertEnabled = isEmailAlertEnabled;
	}
	public String getEmailGenerationType() {
		return emailGenerationType;
	}
	public void setEmailGenerationType(String emailGenerationType) {
		this.emailGenerationType = emailGenerationType;
	}
	public String getIsHandsetLost() {
		return isHandsetLost;
	}
	public void setIsHandsetLost(String isHandsetLost) {
		this.isHandsetLost = isHandsetLost;
	}
	public Date getHandsetLostDate() {
		return handsetLostDate;
	}
	public void setHandsetLostDate(Date handsetLostDate) {
		this.handsetLostDate = handsetLostDate;
	}
	public String getMobileOperatorCode() {
		return mobileOperatorCode;
	}
	public void setMobileOperatorCode(String mobileOperatorCode) {
		this.mobileOperatorCode = mobileOperatorCode;
	}
	public String getMobileNetworkId() {
		return mobileNetworkId;
	}
	public void setMobileNetworkId(String mobileNetworkId) {
		this.mobileNetworkId = mobileNetworkId;
	}
	public String getDefaultAccountNo() {
		return defaultAccountNo;
	}
	public void setDefaultAccountNo(String defaultAccountNo) {
		this.defaultAccountNo = defaultAccountNo;
	}
	public String getDefaultAccountCurrency() {
		return defaultAccountCurrency;
	}
	public void setDefaultAccountCurrency(String defaultAccountCurrency) {
		this.defaultAccountCurrency = defaultAccountCurrency;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	
}
