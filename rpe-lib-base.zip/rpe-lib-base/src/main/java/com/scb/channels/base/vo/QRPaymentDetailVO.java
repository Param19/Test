package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

// TODO: Auto-generated Javadoc
/**
 * The Class QRPaymentDetailVO.
 */
public class QRPaymentDetailVO implements Serializable, Cloneable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7822834393797575509L;

	/** The qr payload version. */
	private String qrPayloadVersion;
	
	/** The merchant category code. */
	private String merchantCategoryCode;
	
	/** The txn currency code. */
	private String txnCurrencyCode;
	
	/** The txn amount. */
	private BigDecimal txnAmount;
	
	/** The country code. */
	private String countryCode;
	
	/** The merchant name. */
	private String merchantName;
	
	/** The merchant city. */
	private String merchantCity;
	
	/** The postal code. */
	private String merchantPostalCode;
	
	/** The additional field. */
	private String additionalField;
	
	/** The point of initiation. */
	private String pointOfInitiation;
	
	/** The tip or convenience fee. */
	private BigDecimal tipOrConvenienceFee;

	/** The merchant pan. */
	private List<QRMerchantPanTypeVO> merchantPanList = new ArrayList<QRMerchantPanTypeVO>();
	
	/** The fee list. */
	private List<QRFeeTypeVO> feeList = new ArrayList<QRFeeTypeVO>();
	
	/** The additional tag list. */
	private List<QRAdditionalFieldVO> additionalTagList = new ArrayList<QRAdditionalFieldVO>();
	
	
	/** The address1. */
	private String customer_address1;
	
	/** The address2. */
	private String customer_address2;
	
	/** The address3. */
	private String customer_address3;
	
	/** The city. */
	private String customer_city;
	
	/** The state. */
	private String customer_state;
	
	/** The zip code. */
	private String customer_zipCode;
	
	/** The country. */
	private String customer_country;
	
	/** The landmark. */
	private String customer_landmark;

	/** The card number. */
	private String cardNumber;
	
	/** The payment date. */
	private Timestamp paymentDate;
	
	/** The payment originate country. */
	private String paymentOriginateCountry;
	
	/** The account number. */
	private String accountNumber;
	
	/** The account currency. */
	private String accountCurrency;
	
	/** The transaction currency. */
	private String transactionCurrency;
	
	/** The card emboss name. */
	private String cardEmbossName;
	
	/** The source of fund. */
	private String sourceOfFund;
	
	/** The payment amount. */
	private BigDecimal TotalPaymentAmt;
	
	/** The payment remarks. */
	private String paymentRemarks;
	
	/** The qr payment id. */
	private String qrPaymentId;
	
	/** The client_reference. */
	private String client_reference;
	
	/** The stan. */
	private String stan;
	
	/** The host_reference. */
	private String host_reference;
	
	/** The host_system. */
	private String host_system;
	
	/** The payment_status. */
	private String payment_status;
	
	/** The customer_name. */
	private String customer_full_name;
	
	/** The customer_first_name. */
	private String customer_first_name;
	
	/** The customer_last_name. */
	private String customer_last_name;
	
	/** The customer_dob. */
	private String customer_dob;

	/** The host response code. */
	private String hostResponseCode;
	
	/** The host response desc. */
	private String hostResponseDesc;
	
	/** The host reason code. */
	private String hostReasonCode;
	
	/** The host txn ref no. */
	private String host_txn_Identifier;
	
	/** The txn act status. */
	private String txnActStatus;
	
	/** The txn status cd. */
	private String txnStatusCd;
		
	/** The customer id. */
	private String customerId;
	
	/** The customer type. */
	private String customerType;
	
	/** The payment_narrartion. */
	private String payment_narrartion;
	
	/** The channel. */
	private String channel;
	
	/** The Merchant pan. */
	private String MerchantPan;
	
	/** The card_type. */
	private String card_type;
	
	/** The network. */
	private String network;
	
	/** The network reference number. */
	private String networkReferenceNumber;
	
	/** The transaction identifier. */
	private String transactionIdentifier;
	
	/** The mastercard assign id. */
	private String mastercardAssignID;
	
	/** The card expiry date. */
	private String cardExpiryDate;
	
	private String status_identifier;
	
	public QRCardAuthConstant cardAuthConstant = new QRCardAuthConstant();
	
	public String jvmName;
	
	private String auth_code;
	
	private String agg_stan;
	
	private String maid;
	
	private String purchaseIdentfier;
	
	private String secondaryId;
	
	private String terminalId;
	
	private String relid;
	
	private String ebid;
	
	/** The Acquire Country Code. */
	private String acquireCountryCode;
	
	/** The Debit Account Currency. */
	private String debitAccCurrency;
	
	/** The Debit Amount. */
	private BigDecimal debitAmount;
	
	/** The Debit Amount Fx Rate. */
	private BigDecimal debitAmtFxRate;
	
	/** The Settlement Currency. */
	private String settlementCurrency;
	
	/** The Settlement Amount. */
	private BigDecimal settlementAmount;
	
	/** The Settlement Amount Fx Rate. */
	private BigDecimal settlementAmtFxRate;
	
	/** The Cross Currency . */
	private boolean isCrossCurrency;

	/** The crc Field. */
	private String crcField;
	
	/**
	 * Gets the qr payload version.
	 *
	 * @return the qr payload version
	 */
	public String getQrPayloadVersion() {
		return qrPayloadVersion;
	}

	/**
	 * Sets the qr payload version.
	 *
	 * @param qrPayloadVersion the new qr payload version
	 */
	public void setQrPayloadVersion(String qrPayloadVersion) {
		this.qrPayloadVersion = qrPayloadVersion;
	}

	/**
	 * Gets the merchant category code.
	 *
	 * @return the merchant category code
	 */
	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}

	/**
	 * Sets the merchant category code.
	 *
	 * @param merchantCategoryCode the new merchant category code
	 */
	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}

	/**
	 * Gets the txn currency code.
	 *
	 * @return the txn currency code
	 */
	public String getTxnCurrencyCode() {
		return txnCurrencyCode;
	}

	/**
	 * Sets the txn currency code.
	 *
	 * @param txnCurrencyCode the new txn currency code
	 */
	public void setTxnCurrencyCode(String txnCurrencyCode) {
		this.txnCurrencyCode = txnCurrencyCode;
	}
	
	/**
	 * Gets the txn amount.
	 *
	 * @return the txn amount
	 */
	public BigDecimal getTxnAmount() {
		return txnAmount;
	}

	/**
	 * Sets the txn amount.
	 *
	 * @param txnAmount the new txn amount
	 */
	public void setTxnAmount(BigDecimal txnAmount) {
		this.txnAmount = txnAmount;
	}

	/**
	 * Sets the tip or convenience fee.
	 *
	 * @param tipOrConvenienceFee the new tip or convenience fee
	 */
	public void setTipOrConvenienceFee(BigDecimal tipOrConvenienceFee) {
		this.tipOrConvenienceFee = tipOrConvenienceFee;
	}

	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * Sets the country code.
	 *
	 * @param countryCode the new country code
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * Gets the merchant name.
	 *
	 * @return the merchant name
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * Sets the merchant name.
	 *
	 * @param merchantName the new merchant name
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	/**
	 * Gets the merchant city.
	 *
	 * @return the merchant city
	 */
	public String getMerchantCity() {
		return merchantCity;
	}

	/**
	 * Sets the merchant city.
	 *
	 * @param merchantCity the new merchant city
	 */
	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}

	/**
	 * Gets the merchant postal code.
	 *
	 * @return the merchant postal code
	 */
	public String getMerchantPostalCode() {
		return merchantPostalCode;
	}

	/**
	 * Sets the merchant postal code.
	 *
	 * @param merchantPostalCode the new merchant postal code
	 */
	public void setMerchantPostalCode(String merchantPostalCode) {
		this.merchantPostalCode = merchantPostalCode;
	}

	/**
	 * Gets the additional field.
	 *
	 * @return the additional field
	 */
	public String getAdditionalField() {
		return additionalField;
	}

	/**
	 * Sets the additional field.
	 *
	 * @param additionalField the new additional field
	 */
	public void setAdditionalField(String additionalField) {
		this.additionalField = additionalField;
	}

	/**
	 * Gets the point of initiation.
	 *
	 * @return the point of initiation
	 */
	public String getPointOfInitiation() {
		return pointOfInitiation;
	}

	/**
	 * Sets the point of initiation.
	 *
	 * @param pointOfInitiation the new point of initiation
	 */
	public void setPointOfInitiation(String pointOfInitiation) {
		this.pointOfInitiation = pointOfInitiation;
	}

	/**
	 * Gets the merchant pan list.
	 *
	 * @return the merchant pan list
	 */
	public List<QRMerchantPanTypeVO> getMerchantPanList() {
		return merchantPanList;
	}

	/**
	 * Sets the merchant pan list.
	 *
	 * @param merchantPanList the new merchant pan list
	 */
	public void setMerchantPanList(List<QRMerchantPanTypeVO> merchantPanList) {
		this.merchantPanList = merchantPanList;
	}

	/**
	 * Gets the customer_address1.
	 *
	 * @return the customer_address1
	 */
	public String getCustomer_address1() {
		return customer_address1;
	}

	/**
	 * Sets the customer_address1.
	 *
	 * @param customer_address1 the new customer_address1
	 */
	public void setCustomer_address1(String customer_address1) {
		this.customer_address1 = customer_address1;
	}

	/**
	 * Gets the customer_address2.
	 *
	 * @return the customer_address2
	 */
	public String getCustomer_address2() {
		return customer_address2;
	}

	/**
	 * Sets the customer_address2.
	 *
	 * @param customer_address2 the new customer_address2
	 */
	public void setCustomer_address2(String customer_address2) {
		this.customer_address2 = customer_address2;
	}

	/**
	 * Gets the customer_address3.
	 *
	 * @return the customer_address3
	 */
	public String getCustomer_address3() {
		return customer_address3;
	}

	/**
	 * Sets the customer_address3.
	 *
	 * @param customer_address3 the new customer_address3
	 */
	public void setCustomer_address3(String customer_address3) {
		this.customer_address3 = customer_address3;
	}

	/**
	 * Gets the customer_city.
	 *
	 * @return the customer_city
	 */
	public String getCustomer_city() {
		return customer_city;
	}

	/**
	 * Sets the customer_city.
	 *
	 * @param customer_city the new customer_city
	 */
	public void setCustomer_city(String customer_city) {
		this.customer_city = customer_city;
	}

	/**
	 * Gets the customer_state.
	 *
	 * @return the customer_state
	 */
	public String getCustomer_state() {
		return customer_state;
	}

	/**
	 * Sets the customer_state.
	 *
	 * @param customer_state the new customer_state
	 */
	public void setCustomer_state(String customer_state) {
		this.customer_state = customer_state;
	}

	/**
	 * Gets the customer_zip code.
	 *
	 * @return the customer_zip code
	 */
	public String getCustomer_zipCode() {
		return customer_zipCode;
	}

	/**
	 * Sets the customer_zip code.
	 *
	 * @param customer_zipCode the new customer_zip code
	 */
	public void setCustomer_zipCode(String customer_zipCode) {
		this.customer_zipCode = customer_zipCode;
	}

	/**
	 * Gets the customer_country.
	 *
	 * @return the customer_country
	 */
	public String getCustomer_country() {
		return customer_country;
	}

	/**
	 * Sets the customer_country.
	 *
	 * @param customer_country the new customer_country
	 */
	public void setCustomer_country(String customer_country) {
		this.customer_country = customer_country;
	}

	/**
	 * Gets the customer_landmark.
	 *
	 * @return the customer_landmark
	 */
	public String getCustomer_landmark() {
		return customer_landmark;
	}

	/**
	 * Sets the customer_landmark.
	 *
	 * @param customer_landmark the new customer_landmark
	 */
	public void setCustomer_landmark(String customer_landmark) {
		this.customer_landmark = customer_landmark;
	}

	/**
	 * Gets the card number.
	 *
	 * @return the card number
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * Sets the card number.
	 *
	 * @param cardNumber the new card number
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * Gets the payment date.
	 *
	 * @return the payment date
	 */
	public Timestamp getPaymentDate() {
		return paymentDate;
	}

	/**
	 * Sets the payment date.
	 *
	 * @param paymentDate the new payment date
	 */
	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * Gets the payment originate country.
	 *
	 * @return the payment originate country
	 */
	public String getPaymentOriginateCountry() {
		return paymentOriginateCountry;
	}

	/**
	 * Sets the payment originate country.
	 *
	 * @param paymentOriginateCountry the new payment originate country
	 */
	public void setPaymentOriginateCountry(String paymentOriginateCountry) {
		this.paymentOriginateCountry = paymentOriginateCountry;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the account currency.
	 *
	 * @return the account currency
	 */
	public String getAccountCurrency() {
		return accountCurrency;
	}

	/**
	 * Sets the account currency.
	 *
	 * @param accountCurrency the new account currency
	 */
	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	/**
	 * Gets the transaction currency.
	 *
	 * @return the transaction currency
	 */
	public String getTransactionCurrency() {
		return transactionCurrency;
	}

	/**
	 * Sets the transaction currency.
	 *
	 * @param transactionCurrency the new transaction currency
	 */
	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	/**
	 * Gets the card emboss name.
	 *
	 * @return the card emboss name
	 */
	public String getCardEmbossName() {
		return cardEmbossName;
	}

	/**
	 * Sets the card emboss name.
	 *
	 * @param cardEmbossName the new card emboss name
	 */
	public void setCardEmbossName(String cardEmbossName) {
		this.cardEmbossName = cardEmbossName;
	}

	/**
	 * Gets the source of fund.
	 *
	 * @return the source of fund
	 */
	public String getSourceOfFund() {
		return sourceOfFund;
	}

	/**
	 * Sets the source of fund.
	 *
	 * @param sourceOfFund the new source of fund
	 */
	public void setSourceOfFund(String sourceOfFund) {
		this.sourceOfFund = sourceOfFund;
	}
	
	/**
	 * Gets the total payment amt.
	 *
	 * @return the total payment amt
	 */
	public BigDecimal getTotalPaymentAmt() {
		return TotalPaymentAmt;
	}

	/**
	 * Sets the total payment amt.
	 *
	 * @param totalPaymentAmt the new total payment amt
	 */
	public void setTotalPaymentAmt(BigDecimal totalPaymentAmt) {
		TotalPaymentAmt = totalPaymentAmt;
	}

	/**
	 * Gets the tip or convenience fee.
	 *
	 * @return the tip or convenience fee
	 */
	public BigDecimal getTipOrConvenienceFee() {
		return tipOrConvenienceFee;
	}

	/**
	 * Gets the payment remarks.
	 *
	 * @return the payment remarks
	 */
	public String getPaymentRemarks() {
		return paymentRemarks;
	}

	/**
	 * Sets the payment remarks.
	 *
	 * @param paymentRemarks the new payment remarks
	 */
	public void setPaymentRemarks(String paymentRemarks) {
		this.paymentRemarks = paymentRemarks;
	}

	/**
	 * Gets the qr payment id.
	 *
	 * @return the qr payment id
	 */
	public String getQrPaymentId() {
		return qrPaymentId;
	}

	/**
	 * Sets the qr payment id.
	 *
	 * @param qrPaymentId the new qr payment id
	 */
	public void setQrPaymentId(String qrPaymentId) {
		this.qrPaymentId = qrPaymentId;
	}

	/**
	 * Gets the client_reference.
	 *
	 * @return the client_reference
	 */
	public String getClient_reference() {
		return client_reference;
	}

	/**
	 * Sets the client_reference.
	 *
	 * @param client_reference the new client_reference
	 */
	public void setClient_reference(String client_reference) {
		this.client_reference = client_reference;
	}

	/**
	 * Gets the stan.
	 *
	 * @return the stan
	 */
	public String getStan() {
		return stan;
	}

	/**
	 * Sets the stan.
	 *
	 * @param stan the new stan
	 */
	public void setStan(String stan) {
		this.stan = stan;
	}

	/**
	 * Gets the host_reference.
	 *
	 * @return the host_reference
	 */
	public String getHost_reference() {
		return host_reference;
	}

	/**
	 * Sets the host_reference.
	 *
	 * @param host_reference the new host_reference
	 */
	public void setHost_reference(String host_reference) {
		this.host_reference = host_reference;
	}

	/**
	 * Gets the host_system.
	 *
	 * @return the host_system
	 */
	public String getHost_system() {
		return host_system;
	}

	/**
	 * Sets the host_system.
	 *
	 * @param host_system the new host_system
	 */
	public void setHost_system(String host_system) {
		this.host_system = host_system;
	}

	/**
	 * Gets the payment_status.
	 *
	 * @return the payment_status
	 */
	public String getPayment_status() {
		return payment_status;
	}

	/**
	 * Sets the payment_status.
	 *
	 * @param payment_status the new payment_status
	 */
	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	
	/**
	 * Gets the customer_full_name.
	 *
	 * @return the customer_full_name
	 */
	public String getCustomer_full_name() {
		return customer_full_name;
	}

	/**
	 * Sets the customer_full_name.
	 *
	 * @param customer_full_name the new customer_full_name
	 */
	public void setCustomer_full_name(String customer_full_name) {
		this.customer_full_name = customer_full_name;
	}

	/**
	 * Gets the customer_first_name.
	 *
	 * @return the customer_first_name
	 */
	public String getCustomer_first_name() {
		return customer_first_name;
	}

	/**
	 * Sets the customer_first_name.
	 *
	 * @param customer_first_name the new customer_first_name
	 */
	public void setCustomer_first_name(String customer_first_name) {
		this.customer_first_name = customer_first_name;
	}

	/**
	 * Gets the customer_last_name.
	 *
	 * @return the customer_last_name
	 */
	public String getCustomer_last_name() {
		return customer_last_name;
	}

	/**
	 * Sets the customer_last_name.
	 *
	 * @param customer_last_name the new customer_last_name
	 */
	public void setCustomer_last_name(String customer_last_name) {
		this.customer_last_name = customer_last_name;
	}

	/**
	 * Gets the customer_dob.
	 *
	 * @return the customer_dob
	 */
	public String getCustomer_dob() {
		return customer_dob;
	}

	/**
	 * Sets the customer_dob.
	 *
	 * @param customer_dob the new customer_dob
	 */
	public void setCustomer_dob(String customer_dob) {
		this.customer_dob = customer_dob;
	}

	/**
	 * Gets the host response code.
	 *
	 * @return the host response code
	 */
	public String getHostResponseCode() {
		return hostResponseCode;
	}

	/**
	 * Sets the host response code.
	 *
	 * @param hostResponseCode the new host response code
	 */
	public void setHostResponseCode(String hostResponseCode) {
		this.hostResponseCode = hostResponseCode;
	}

	/**
	 * Gets the host response desc.
	 *
	 * @return the host response desc
	 */
	public String getHostResponseDesc() {
		return hostResponseDesc;
	}

	/**
	 * Sets the host response desc.
	 *
	 * @param hostResponseDesc the new host response desc
	 */
	public void setHostResponseDesc(String hostResponseDesc) {
		if(hostResponseDesc != null && hostResponseDesc.length()>245){
			hostResponseDesc = hostResponseDesc.substring(0, 245);
		}
		this.hostResponseDesc = hostResponseDesc;
	}

	/**
	 * Gets the txn act status.
	 *
	 * @return the txn act status
	 */
	public String getTxnActStatus() {
		return txnActStatus;
	}

	/**
	 * Sets the txn act status.
	 *
	 * @param txnActStatus the new txn act status
	 */
	public void setTxnActStatus(String txnActStatus) {
		this.txnActStatus = txnActStatus;
	}

	/**
	 * Gets the txn status cd.
	 *
	 * @return the txn status cd
	 */
	public String getTxnStatusCd() {
		return txnStatusCd;
	}

	/**
	 * Sets the txn status cd.
	 *
	 * @param txnStatusCd the new txn status cd
	 */
	public void setTxnStatusCd(String txnStatusCd) {
		this.txnStatusCd = txnStatusCd;
	}

	/**
	 * Gets the serialversionuid.
	 *
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * Gets the host_txn_ identifier.
	 *
	 * @return the host_txn_ identifier
	 */
	public String getHost_txn_Identifier() {
		return host_txn_Identifier;
	}

	/**
	 * Sets the host_txn_ identifier.
	 *
	 * @param host_txn_Identifier the new host_txn_ identifier
	 */
	public void setHost_txn_Identifier(String host_txn_Identifier) {
		this.host_txn_Identifier = host_txn_Identifier;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the new customer id
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the customer type.
	 *
	 * @return the customer type
	 */
	public String getCustomerType() {
		return customerType;
	}

	/**
	 * Sets the customer type.
	 *
	 * @param customerType the new customer type
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	/**
	 * Gets the host reason code.
	 *
	 * @return the host reason code
	 */
	public String getHostReasonCode() {
		return hostReasonCode;
	}

	/**
	 * Sets the host reason code.
	 *
	 * @param hostReasonCode the new host reason code
	 */
	public void setHostReasonCode(String hostReasonCode) {
		this.hostReasonCode = hostReasonCode;
	}

	/**
	 * Gets the payment_narrartion.
	 *
	 * @return the payment_narrartion
	 */
	public String getPayment_narrartion() {
		return payment_narrartion;
	}

	/**
	 * Sets the payment_narrartion.
	 *
	 * @param payment_narrartion the new payment_narrartion
	 */
	public void setPayment_narrartion(String payment_narrartion) {
		this.payment_narrartion = payment_narrartion;
	}
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * Sets the channel.
	 *
	 * @param channel the new channel
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * Gets the merchant pan.
	 *
	 * @return the merchant pan
	 */
	public String getMerchantPan() {
		return MerchantPan;
	}

	/**
	 * Sets the merchant pan.
	 *
	 * @param merchantPan the new merchant pan
	 */
	public void setMerchantPan(String merchantPan) {
		MerchantPan = merchantPan;
	}

	/**
	 * Gets the fee list.
	 *
	 * @return the fee list
	 */
	public List<QRFeeTypeVO> getFeeList() {
		return feeList;
	}

	/**
	 * Sets the fee list.
	 *
	 * @param feeList the new fee list
	 */
	public void setFeeList(List<QRFeeTypeVO> feeList) {
		this.feeList = feeList;
	}
	
	/**
	 * Gets the additional tag list.
	 *
	 * @return the additional tag list
	 */
	public List<QRAdditionalFieldVO> getAdditionalTagList() {
		return additionalTagList;
	}

	/**
	 * Sets the additional tag list.
	 *
	 * @param additionalTagList the new additional tag list
	 */
	public void setAdditionalTagList(List<QRAdditionalFieldVO> additionalTagList) {
		this.additionalTagList = additionalTagList;
	}
	

	/**
	 * Gets the card_type.
	 *
	 * @return the card_type
	 */
	public String getCard_type() {
		return card_type;
	}

	/**
	 * Sets the card_type.
	 *
	 * @param card_type the new card_type
	 */
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}

	/**
	 * Gets the network.
	 *
	 * @return the network
	 */
	public String getNetwork() {
		return network;
	}

	/**
	 * Sets the network.
	 *
	 * @param network the new network
	 */
	public void setNetwork(String network) {
		this.network = network;
	}

	/**
	 * Gets the network reference number.
	 *
	 * @return the network reference number
	 */
	public String getNetworkReferenceNumber() {
		return networkReferenceNumber;
	}

	/**
	 * Sets the network reference number.
	 *
	 * @param networkReferenceNumber the new network reference number
	 */
	public void setNetworkReferenceNumber(String networkReferenceNumber) {
		this.networkReferenceNumber = networkReferenceNumber;
	}

	/**
	 * Gets the transaction identifier.
	 *
	 * @return the transaction identifier
	 */
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}

	/**
	 * Sets the transaction identifier.
	 *
	 * @param transactionIdentifier the new transaction identifier
	 */
	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}	

	/**
	 * Gets the mastercard assign id.
	 *
	 * @return the mastercard assign id
	 */
	public String getMastercardAssignID() {
		return mastercardAssignID;
	}

	/**
	 * Sets the mastercard assign id.
	 *
	 * @param mastercardAssignID the new mastercard assign id
	 */
	public void setMastercardAssignID(String mastercardAssignID) {
		this.mastercardAssignID = mastercardAssignID;
	}
	
	
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}

	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	public QRCardAuthConstant getCardAuthConstant() {
		return cardAuthConstant;
	}

	public void setCardAuthConstant(QRCardAuthConstant cardAuthConstant) {
		this.cardAuthConstant = cardAuthConstant;
	}
	
	public String getStatus_identifier() {
		return status_identifier;
	}

	public void setStatus_identifier(String status_identifier) {
		this.status_identifier = status_identifier;
	}
	
	public String getJvmName() {
		return jvmName;
	}

	public void setJvmName(String jvmName) {
		this.jvmName = jvmName;
	}
	
	public String getAuth_code() {
		return auth_code;
	}

	public void setAuth_code(String auth_code) {
		this.auth_code = auth_code;
	}

	
	public String getAgg_stan() {
		return agg_stan;
	}

	public void setAgg_stan(String agg_stan) {
		this.agg_stan = agg_stan;
	}
	
	public String getMaid() {
		return maid;
	}

	public void setMaid(String maid) {
		this.maid = maid;
	}

	public String getPurchaseIdentfier() {
		return purchaseIdentfier;
	}

	public void setPurchaseIdentfier(String purchaseIdentfier) {
		this.purchaseIdentfier = purchaseIdentfier;
	}

	public String getSecondaryId() {
		return secondaryId;
	}

	public void setSecondaryId(String secondaryId) {
		this.secondaryId = secondaryId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getRelid() {
		return relid;
	}

	public void setRelid(String relid) {
		this.relid = relid;
	}

	public String getEbid() {
		return ebid;
	}

	public void setEbid(String ebid) {
		this.ebid = ebid;
	}

	public String getAcquireCountryCode() {
		return acquireCountryCode;
	}

	public void setAcquireCountryCode(String acquireCountryCode) {
		this.acquireCountryCode = acquireCountryCode;
	}

	public String getDebitAccCurrency() {
		return debitAccCurrency;
	}

	public void setDebitAccCurrency(String debitAccCurrency) {
		this.debitAccCurrency = debitAccCurrency;
	}

	public BigDecimal getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(BigDecimal debitAmount) {
		this.debitAmount = debitAmount;
	}

	public BigDecimal getDebitAmtFxRate() {
		return debitAmtFxRate;
	}

	public void setDebitAmtFxRate(BigDecimal debitAmtFxRate) {
		this.debitAmtFxRate = debitAmtFxRate;
	}

	public String getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public BigDecimal getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(BigDecimal settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public BigDecimal getSettlementAmtFxRate() {
		return settlementAmtFxRate;
	}

	public void setSettlementAmtFxRate(BigDecimal settlementAmtFxRate) {
		this.settlementAmtFxRate = settlementAmtFxRate;
	}

	public boolean isCrossCurrency() {
		return isCrossCurrency;
	}

	public void setCrossCurrency(boolean isCrossCurrency) {
		this.isCrossCurrency = isCrossCurrency;
	}

	public String getCrcField() {
		return crcField;
	}

	public void setCrcField(String crcField) {
		this.crcField = crcField;
	}

	@Override
	public String toString() {
		return "QRPaymentDetailVO [qrPayloadVersion=" + qrPayloadVersion
				+ ", merchantCategoryCode=" + merchantCategoryCode
				+ ", txnCurrencyCode=" + txnCurrencyCode + ", txnAmount="
				+ txnAmount + ", countryCode=" + countryCode
				+ ", merchantName=" + merchantName + ", merchantCity="
				+ merchantCity + ", merchantPostalCode=" + merchantPostalCode
				+ ", additionalField=" + additionalField
				+ ", pointOfInitiation=" + pointOfInitiation
				+ ", tipOrConvenienceFee=" + tipOrConvenienceFee
				+ ", merchantPanList=" + merchantPanList + ", feeList="
				+ feeList + ", additionalTagList=" + additionalTagList
				+ ", customer_address1=" + customer_address1
				+ ", customer_address2=" + customer_address2
				+ ", customer_address3=" + customer_address3
				+ ", customer_city=" + customer_city + ", customer_state="
				+ customer_state + ", customer_zipCode=" + customer_zipCode
				+ ", customer_country=" + customer_country
				+ ", customer_landmark=" + customer_landmark + ", cardNumber="
				+ cardNumber + ", paymentDate=" + paymentDate
				+ ", paymentOriginateCountry=" + paymentOriginateCountry
				+ ", accountNumber=" + accountNumber + ", accountCurrency="
				+ accountCurrency + ", transactionCurrency="
				+ transactionCurrency + ", cardEmbossName=" + cardEmbossName
				+ ", sourceOfFund=" + sourceOfFund + ", TotalPaymentAmt="
				+ TotalPaymentAmt + ", paymentRemarks=" + paymentRemarks
				+ ", qrPaymentId=" + qrPaymentId + ", client_reference="
				+ client_reference + ", stan=" + stan + ", host_reference="
				+ host_reference + ", host_system=" + host_system
				+ ", payment_status=" + payment_status
				+ ", customer_full_name=" + customer_full_name
				+ ", customer_first_name=" + customer_first_name
				+ ", customer_last_name=" + customer_last_name
				+ ", customer_dob=" + customer_dob + ", hostResponseCode="
				+ hostResponseCode + ", hostResponseDesc=" + hostResponseDesc
				+ ", hostReasonCode=" + hostReasonCode
				+ ", host_txn_Identifier=" + host_txn_Identifier
				+ ", txnActStatus=" + txnActStatus + ", txnStatusCd="
				+ txnStatusCd + ", customerId=" + customerId
				+ ", customerType=" + customerType + ", payment_narrartion="
				+ payment_narrartion + ", channel=" + channel
				+ ", MerchantPan=" + MerchantPan + ", card_type=" + card_type
				+ ", network=" + network + ", networkReferenceNumber="
				+ networkReferenceNumber + ", transactionIdentifier="
				+ transactionIdentifier + ", mastercardAssignID="
				+ mastercardAssignID + ", cardExpiryDate=" + cardExpiryDate
				+ ", status_identifier=" + status_identifier
				+ ", cardAuthConstant=" + cardAuthConstant + ", jvmName="
				+ jvmName + ", auth_code=" + auth_code + ", agg_stan="
				+ agg_stan + ", maid=" + maid + ", purchaseIdentfier="
				+ purchaseIdentfier + ", secondaryId=" + secondaryId
				+ ", terminalId=" + terminalId + ", relid=" + relid + ", ebid="
				+ ebid + ", acquireCountryCode=" + acquireCountryCode
				+ ", debitAccCurrency=" + debitAccCurrency + ", debitAmount="
				+ debitAmount + ", debitAmtFxRate=" + debitAmtFxRate
				+ ", settlementCurrency=" + settlementCurrency
				+ ", settlementAmount=" + settlementAmount
				+ ", settlementAmtFxRate=" + settlementAmtFxRate
				+ ", isCrossCurrency=" + isCrossCurrency + ", crcField="
				+ crcField + ", getQrPayloadVersion()=" + getQrPayloadVersion()
				+ ", getMerchantCategoryCode()=" + getMerchantCategoryCode()
				+ ", getTxnCurrencyCode()=" + getTxnCurrencyCode()
				+ ", getTxnAmount()=" + getTxnAmount() + ", getCountryCode()="
				+ getCountryCode() + ", getMerchantName()=" + getMerchantName()
				+ ", getMerchantCity()=" + getMerchantCity()
				+ ", getMerchantPostalCode()=" + getMerchantPostalCode()
				+ ", getAdditionalField()=" + getAdditionalField()
				+ ", getPointOfInitiation()=" + getPointOfInitiation()
				+ ", getMerchantPanList()=" + getMerchantPanList()
				+ ", getCustomer_address1()=" + getCustomer_address1()
				+ ", getCustomer_address2()=" + getCustomer_address2()
				+ ", getCustomer_address3()=" + getCustomer_address3()
				+ ", getCustomer_city()=" + getCustomer_city()
				+ ", getCustomer_state()=" + getCustomer_state()
				+ ", getCustomer_zipCode()=" + getCustomer_zipCode()
				+ ", getCustomer_country()=" + getCustomer_country()
				+ ", getCustomer_landmark()=" + getCustomer_landmark()
				+ ", getCardNumber()=" + getCardNumber()
				+ ", getPaymentDate()=" + getPaymentDate()
				+ ", getPaymentOriginateCountry()="
				+ getPaymentOriginateCountry() + ", getAccountNumber()="
				+ getAccountNumber() + ", getAccountCurrency()="
				+ getAccountCurrency() + ", getTransactionCurrency()="
				+ getTransactionCurrency() + ", getCardEmbossName()="
				+ getCardEmbossName() + ", getSourceOfFund()="
				+ getSourceOfFund() + ", getTotalPaymentAmt()="
				+ getTotalPaymentAmt() + ", getTipOrConvenienceFee()="
				+ getTipOrConvenienceFee() + ", getPaymentRemarks()="
				+ getPaymentRemarks() + ", getQrPaymentId()="
				+ getQrPaymentId() + ", getClient_reference()="
				+ getClient_reference() + ", getStan()=" + getStan()
				+ ", getHost_reference()=" + getHost_reference()
				+ ", getHost_system()=" + getHost_system()
				+ ", getPayment_status()=" + getPayment_status()
				+ ", getCustomer_full_name()=" + getCustomer_full_name()
				+ ", getCustomer_first_name()=" + getCustomer_first_name()
				+ ", getCustomer_last_name()=" + getCustomer_last_name()
				+ ", getCustomer_dob()=" + getCustomer_dob()
				+ ", getHostResponseCode()=" + getHostResponseCode()
				+ ", getHostResponseDesc()=" + getHostResponseDesc()
				+ ", getTxnActStatus()=" + getTxnActStatus()
				+ ", getTxnStatusCd()=" + getTxnStatusCd()
				+ ", getHost_txn_Identifier()=" + getHost_txn_Identifier()
				+ ", getCustomerId()=" + getCustomerId()
				+ ", getCustomerType()=" + getCustomerType()
				+ ", getHostReasonCode()=" + getHostReasonCode()
				+ ", getPayment_narrartion()=" + getPayment_narrartion()
				+ ", getChannel()=" + getChannel() + ", getMerchantPan()="
				+ getMerchantPan() + ", getFeeList()=" + getFeeList()
				+ ", getAdditionalTagList()=" + getAdditionalTagList()
				+ ", getCard_type()=" + getCard_type() + ", getNetwork()="
				+ getNetwork() + ", getNetworkReferenceNumber()="
				+ getNetworkReferenceNumber() + ", getTransactionIdentifier()="
				+ getTransactionIdentifier() + ", getMastercardAssignID()="
				+ getMastercardAssignID() + ", getCardExpiryDate()="
				+ getCardExpiryDate() + ", getCardAuthConstant()="
				+ getCardAuthConstant() + ", getStatus_identifier()="
				+ getStatus_identifier() + ", getJvmName()=" + getJvmName()
				+ ", getAuth_code()=" + getAuth_code() + ", getAgg_stan()="
				+ getAgg_stan() + ", getMaid()=" + getMaid()
				+ ", getPurchaseIdentfier()=" + getPurchaseIdentfier()
				+ ", getSecondaryId()=" + getSecondaryId()
				+ ", getTerminalId()=" + getTerminalId() + ", getRelid()="
				+ getRelid() + ", getEbid()=" + getEbid()
				+ ", getAcquireCountryCode()=" + getAcquireCountryCode()
				+ ", getDebitAccCurrency()=" + getDebitAccCurrency()
				+ ", getDebitAmount()=" + getDebitAmount()
				+ ", getDebitAmtFxRate()=" + getDebitAmtFxRate()
				+ ", getSettlementCurrency()=" + getSettlementCurrency()
				+ ", getSettlementAmount()=" + getSettlementAmount()
				+ ", getSettlementAmtFxRate()=" + getSettlementAmtFxRate()
				+ ", isCrossCurrency()=" + isCrossCurrency()
				+ ", getCrcField()=" + getCrcField() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}
