package com.scb.channels.base.vo;


public class StopChequeResponseVO extends BaseVO  {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1936552739128824745L;
	private String applicationType;
	private String statusCd;	
    private String accountNo;
    private String chequeNO;
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
		public String getChequeNO() {
		return chequeNO;
	}
	public void setChequeNO(String chequeNO) {
		this.chequeNO = chequeNO;
	}

}
