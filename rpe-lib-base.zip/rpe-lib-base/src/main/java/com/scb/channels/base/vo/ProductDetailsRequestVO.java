/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ProductDetailsRequestVO.
 *
 * @author 1411807
 */
public class ProductDetailsRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8429104029833295454L;

	private BeneficiaryRequestVO beneficiaryRequestVO;
	
	private BillerListRequestVO billerListRequestVO;
	
	private AccountListRequestVO accountListRequestVO;
	
	private int version;

	/**
	 * @return the beneficiaryRequestVO
	 */
	public BeneficiaryRequestVO getBeneficiaryRequestVO() {
		return beneficiaryRequestVO;
	}

	/**
	 * @param beneficiaryRequestVO the beneficiaryRequestVO to set
	 */
	public void setBeneficiaryRequestVO(BeneficiaryRequestVO beneficiaryRequestVO) {
		this.beneficiaryRequestVO = beneficiaryRequestVO;
	}

	/**
	 * @return the billerListRequestVO
	 */
	public BillerListRequestVO getBillerListRequestVO() {
		return billerListRequestVO;
	}

	/**
	 * @param billerListRequestVO the billerListRequestVO to set
	 */
	public void setBillerListRequestVO(BillerListRequestVO billerListRequestVO) {
		this.billerListRequestVO = billerListRequestVO;
	}

	/**
	 * @return the accountListRequestVO
	 */
	public AccountListRequestVO getAccountListRequestVO() {
		return accountListRequestVO;
	}

	/**
	 * @param accountListRequestVO the accountListRequestVO to set
	 */
	public void setAccountListRequestVO(AccountListRequestVO accountListRequestVO) {
		this.accountListRequestVO = accountListRequestVO;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	

}
