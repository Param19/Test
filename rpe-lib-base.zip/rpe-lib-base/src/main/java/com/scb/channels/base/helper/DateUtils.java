package com.scb.channels.base.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.beans.factory.config.PropertyPlaceHolder;


/**
 * The Class DateUtils.
 */
public class DateUtils extends org.apache.commons.lang.time.DateUtils {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);
	
	/** The Constant DateFormat. */
	public static final String DateFormat = "yyyy-MM-dd'T'HH:mm:ss.sssZ";
	public static final String DateFormat_ddMMYYYY = "dd/MM/YYYY";

  /**
   * Checks if is today.
   *
   * @param date the date
   * @return true, if is today
   */
  public static boolean isToday(Date date)  {
    return isSameDay(getCurrentDate(), date);
  }

  /**
   * Gets the current date.
   *
   * @return the current date
   */
  public static Date getCurrentDate() {
    String country = ApplicationContext.getCountry();
    LOGGER.info("Loading country:::" + country);
    if (StringUtils.isBlank(country) || CommonConstants.ALL.equals(country)) {
       return new Date();
    }
    String countryTimezone = PropertyPlaceHolder.getProperty(CommonConstants.TIMEZONE_PROP_PREFIX + country);

	String staticDateFlag = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_DATE_FLAG);
	boolean isStaticDate = CommonConstants.TRUE.equals(staticDateFlag);
	TimeZone timezone = TimeZone.getTimeZone(countryTimezone);
	Calendar cal = Calendar.getInstance(timezone);
	Calendar cal2 =Calendar.getInstance();
	if(isStaticDate) {
		try{
			String staticDateYear = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_YEAR + country);
			String staticDateMonth = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_MONTH + country);
			String staticDateDay = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_DAY + country);
			if (StringUtils.isNotEmpty(staticDateYear) 
					&& StringUtils.isNotEmpty(staticDateMonth) 
					&& StringUtils.isNotEmpty(staticDateDay)) {
				int year = Integer.parseInt(staticDateYear);
				int month = Integer.parseInt(staticDateMonth);
				int date = Integer.parseInt(staticDateDay);
				cal.set(year, month, date);
				cal2.set(year, month, date);
			}
		} catch (Exception e) {
			// do nothing
		}
	}
    if (StringUtils.isBlank(countryTimezone)) {
       return new Date();
    }
    int countryOffset = timezone.getOffset(cal.getTimeInMillis());
    TimeZone tz = TimeZone.getDefault();
    int utcOffset = tz.getOffset(Calendar.getInstance().getTimeInMillis());
    long theTime = cal.getTimeInMillis() - utcOffset + countryOffset;
    String delay = PropertyPlaceHolder.getProperty(CommonConstants.DELAY_TIME + country);
    LOGGER.debug("Delay time set:::" + delay);
    if (CommonConstants.TRUE.equals(delay)) {
    	Integer timeDiff = Integer.valueOf(PropertyPlaceHolder.getProperty(CommonConstants.DELAY_TIME_VALUE + country));
    	LOGGER.debug("Delay time set for interval, CurrentTime::: {}, {}", new Object[]{timeDiff,new Date(theTime).toString()});
    	theTime = theTime - (timeDiff * 1000);
    	LOGGER.debug("Delay time after set for interval, CurrentTime::: {}, {}", new Object[]{timeDiff,new Date(theTime).toString()});
    }
    return new Date(theTime);
  }
  
  /**
   * Gets the country calendar.
   *
   * @return the country calendar
   */
  public static Calendar getCountryCalendar() {
	    String country = ApplicationContext.getCountry();
	
	    if (StringUtils.isBlank(country) || CommonConstants.ALL.equals(country)) {
	       return Calendar.getInstance();
	    }
	    String countryTimezone = PropertyPlaceHolder.getProperty(CommonConstants.TIMEZONE_PROP_PREFIX + country);
	    String staticDateFlag = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_DATE_FLAG);
	    
	    if (StringUtils.isBlank(countryTimezone)) {
	       return Calendar.getInstance();
	    }
	    
	    TimeZone timezone = TimeZone.getTimeZone(countryTimezone);
	    boolean isStaticDate = CommonConstants.TRUE.equals(staticDateFlag);
	    if(isStaticDate) {
				try{
					Calendar cal = Calendar.getInstance(timezone);
					String staticDateYear = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_YEAR  + country);
					String staticDateMonth = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_MONTH + country);
					String staticDateDay = PropertyPlaceHolder.getProperty(CommonConstants.STATIC_DAY + country);
					if (StringUtils.isNotEmpty(staticDateYear) 
							&& StringUtils.isNotEmpty(staticDateMonth) 
							&& StringUtils.isNotEmpty(staticDateDay)) {
						int year = Integer.parseInt(staticDateYear);
						int month = Integer.parseInt(staticDateMonth);
						int date = Integer.parseInt(staticDateDay);
						cal.set(year, month, date);
						return cal;
					}
				} catch (Exception e) {
					// do nothing
				}
			}
	   
	     String delay = PropertyPlaceHolder.getProperty(CommonConstants.DELAY_TIME + country);
	     if (CommonConstants.TRUE.equals(delay)) {
	     	Integer timeDiff = Integer.valueOf(PropertyPlaceHolder.getProperty(CommonConstants.DELAY_TIME_VALUE + country));
	     	Calendar cal = Calendar.getInstance(timezone);
	     	cal.add(Calendar.SECOND, -(timeDiff));		
	     	return cal;
	     } else {
	    	  return Calendar.getInstance(timezone);
	     }
	  }


  /**
   * Adjust country time zone.
   *
   * @param date the date
   * @return the date
   */
  public static Date adjustCountryTimeZone(Date date)
  {
     if (date == null) {
       return date;
    }
    String country = ApplicationContext.getCountry();

    if (StringUtils.isBlank(country) || CommonConstants.ALL.equals(country)) {
       return date;
    }
    String countryTimezone = PropertyPlaceHolder.getProperty(CommonConstants.TIMEZONE_PROP_PREFIX + country);

   if (StringUtils.isBlank(countryTimezone)) {
       return date;
    }
    TimeZone timezone = TimeZone.getTimeZone(countryTimezone);
    Calendar cal = Calendar.getInstance(timezone);
    int countryOffset = timezone.getOffset(cal.getTimeInMillis());
    TimeZone tz = TimeZone.getDefault();
    int utcOffset = tz.getOffset(Calendar.getInstance().getTimeInMillis());
    long theTime = date.getTime() - utcOffset + countryOffset;
    String delay = PropertyPlaceHolder.getProperty(CommonConstants.DELAY_TIME + country);
    if (CommonConstants.TRUE.equals(delay)) {
    	Integer timeDiff = Integer.valueOf(PropertyPlaceHolder.getProperty(CommonConstants.DELAY_TIME_VALUE + country));
    	theTime = theTime - (timeDiff * 1000);
    }
    return new Date(theTime);
  }
  
  /**
   * Convert to calendar.
   *
   * @param date the date
   * @return the calendar
   */
  public static Calendar convertToCalendar(Date date) {
	  if (date != null) {
		  Calendar cal = DateUtils.getCountryCalendar();
		  cal.setTime(date);
		  return cal;
	  } else {
		  return null;
	  }
  }
  
  /**
   * Gets the xML date string.
   *
   * @param date the date
   * @return the xML date string
   */
  public static String getXMLDateString(Date date) {
	  DateFormat format = new SimpleDateFormat(DateFormat){
			 public StringBuffer format(Date date, StringBuffer toAppendTo, java.text.FieldPosition pos) {
		            StringBuffer toFix = super.format(date, toAppendTo, pos);
		            return toFix.insert(toFix.length()-2, ':');
		        };
		};
	  return format.format(date);
  }
  
//Added for Customer Overall Payment Amount Service
  public static String getDateString(Date date) {
	  DateFormat format = new SimpleDateFormat(DateFormat_ddMMYYYY);
	  return format.format(date);
  }
  //Orange Money Project
  public static String getDateString(Date date, String DateFormat) {
	  DateFormat format = new SimpleDateFormat(DateFormat);
	  return format.format(date);
  }
  
  public static Date getDateWithoutTime(Date date) {
	  	Calendar calendar = Calendar.getInstance();
	  	calendar.setTime(date);
	  	return getDateWithoutTime(calendar);
	}
	public static Date getDateWithoutTime(Calendar calendar) {
		calendar.set(Calendar.MILLISECOND, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.HOUR, 0);
		return calendar.getTime();
	}
	public static Date getDateWithMaxTime(Date date) {
		return new Date(date.getTime() + TimeUnit.DAYS.toMillis(1));
	}
//ends getCustomerTotalPaymentAmount	
}