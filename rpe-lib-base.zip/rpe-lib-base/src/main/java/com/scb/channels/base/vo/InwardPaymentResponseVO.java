package com.scb.channels.base.vo;

/**
 * The Class InwardPaymentResponseVO.
 *
 * @author 1493439
 */
public class InwardPaymentResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5588194702109032932L;
	
	/** The status type vo. */
	private StatusTypeVO statusTypeVO;
	
	private String referenceNumber;

	/** The service name. */
	private String serviceName;
	
	/**
	 * Gets the status type vo.
	 *
	 * @return the statusTypeVO
	 */
	public StatusTypeVO getStatusTypeVO() {
		return statusTypeVO;
	}

	/**
	 * Sets the status type vo.
	 *
	 * @param statusTypeVO the statusTypeVO to set
	 */
	public void setStatusTypeVO(StatusTypeVO statusTypeVO) {
		this.statusTypeVO = statusTypeVO;
	}

	/**
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InwardPaymentResponseVO [statusTypeVO=" + statusTypeVO
				+ ", referenceNumber=" + referenceNumber + ", serviceName="
				+ serviceName + "]";
	}

}
