package com.scb.channels.base.vo;

import java.util.Date;

/**
 * The Class AuditSumTxnVO.
 */
public class AuditSumTxnVO {
	
	/** The ip address. */
	private String ipAddress;
	
	/** The client ip address. */
	private String clientIpAddress;
	
	/** The mobile no. */
	private String mobileNo;
	
	/** The email. */
	private String email;
	
	/** The system type. */
	private String systemType;
	
	/** The environment. */
	private String environment;
	
	/** The channel. */
	private String channel;
	
	/** The session id. */
	private String sessionId;
	
	/** The status cd. */
	private String statusCd; 
	
	/** The error cd. */
	private String errorCd;  
	
	/** The error desc. */
	private String errorDesc;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The func cd. */
	private String funcCd;
	
	/** The user id. */
	private String userId;
	
	/** The cust group id. */
	private String custGroupId;
	
	/** The cust id. */
	private String custId;
	
	/** The cust id type. */
	private String custIdType;
	
	/** The txn id. */
	private String txnId;
	
	/** The txn type. */
	private String txnType;
	
	/** The txn date. */
	private Date txnDate;
	
	/** The txn curr. */
	private String txnCurr;
	
	/** The txn amt. */
	private Double txnAmt;
	
	/** The txt status cd. */
	private String txtStatusCd;
	
	/** The from acct no. */
	private String fromAcctNo;
	
	/** The to acct no. */
	private String toAcctNo;
	
	/** The from acct name. */
	private String fromAcctName;
	
	/** The to acct name. */
	private String toAcctName;
	
	/** The from acc curr cd. */
	private String fromAccCurrCd;
	
	/** The to acc curr cd. */
	private String toAccCurrCd;
	
	/** The audit by. */
	private String auditBy;
	
	/** The version. */
	private Integer version;
	
	/** The custom dec01. */
	private Double customDec01;
	
	/** The custom dec02. */
	private Double customDec02;
	
	/** The custom dec03. */
	private Double customDec03;
	
	/** The custom dec04. */
	private Double customDec04;
	
	/** The custom dec05. */
	private Double customDec05;
	
	/** The custom var01. */
	private String customVar01;
	
	/** The custom var02. */
	private String customVar02;
	
	/** The custom var03. */
	private String customVar03;
	
	/** The custom var04. */
	private String customVar04;
	
	/** The custom var05. */
	private String customVar05;
	
	/** The custom date. */
	private Date customDate;
	
	/** The date created. */
	private Date dateCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The date upd. */
	private Date dateUpd;
	
	/** The dt audit. */
	private Date dtAudit;
	
	/** The email notification. */
	private String emailNotification;
	
	/** The sms notification. */
	private String smsNotification;
	
	/** The inbox notification. */
	private String inboxNotification;
	
	/** The language. */
	private String language;
	
	private String uUser;
	
	private String name;
	

	
     /** The id. */
     private int id;
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the custom dec01.
	 *
	 * @return the customDec01
	 */
	public Double getCustomDec01() {
		return customDec01;
	}
	
	/**
	 * Sets the custom dec01.
	 *
	 * @param customDec01 the customDec01 to set
	 */
	public void setCustomDec01(Double customDec01) {
		this.customDec01 = customDec01;
	}
	
	/**
	 * Gets the custom dec02.
	 *
	 * @return the customDec02
	 */
	public Double getCustomDec02() {
		return customDec02;
	}
	
	/**
	 * Sets the custom dec02.
	 *
	 * @param customDec02 the customDec02 to set
	 */
	public void setCustomDec02(Double customDec02) {
		this.customDec02 = customDec02;
	}
	
	/**
	 * Gets the custom dec03.
	 *
	 * @return the customDec03
	 */
	public Double getCustomDec03() {
		return customDec03;
	}
	
	/**
	 * Sets the custom dec03.
	 *
	 * @param customDec03 the customDec03 to set
	 */
	public void setCustomDec03(Double customDec03) {
		this.customDec03 = customDec03;
	}
	
	/**
	 * Gets the custom dec04.
	 *
	 * @return the customDec04
	 */
	public Double getCustomDec04() {
		return customDec04;
	}
	
	/**
	 * Sets the custom dec04.
	 *
	 * @param customDec04 the customDec04 to set
	 */
	public void setCustomDec04(Double customDec04) {
		this.customDec04 = customDec04;
	}
	
	/**
	 * Gets the custom dec05.
	 *
	 * @return the customDec05
	 */
	public Double getCustomDec05() {
		return customDec05;
	}
	
	/**
	 * Sets the custom dec05.
	 *
	 * @param customDec05 the customDec05 to set
	 */
	public void setCustomDec05(Double customDec05) {
		this.customDec05 = customDec05;
	}
	
	/**
	 * Gets the system type.
	 *
	 * @return the systemType
	 */
	public String getSystemType() {
		return systemType;
	}
	
	/**
	 * Sets the system type.
	 *
	 * @param systemType the systemType to set
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	
	/**
	 * Sets the environment.
	 *
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * Gets the session id.
	 *
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}
	
	/**
	 * Sets the session id.
	 *
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the error cd.
	 *
	 * @return the errorCd
	 */
	public String getErrorCd() {
		return errorCd;
	}
	
	/**
	 * Sets the error cd.
	 *
	 * @param errorCd the errorCd to set
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}
	
	/**
	 * Gets the error desc.
	 *
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}
	
	/**
	 * Sets the error desc.
	 *
	 * @param errorDesc the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		if(errorDesc != null && errorDesc.length() > 490){
			errorDesc = errorDesc.substring(0, 490);
		}
		this.errorDesc = errorDesc;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the func cd.
	 *
	 * @return the func cd
	 */
	public String getFuncCd() {
		return funcCd;
	}
	
	/**
	 * Sets the func cd.
	 *
	 * @param funcCd the funcCd to set
	 */
	public void setFuncCd(String funcCd) {
		this.funcCd = funcCd;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the cust group id.
	 *
	 * @return the custGroupId
	 */
	public String getCustGroupId() {
		return custGroupId;
	}
	
	/**
	 * Sets the cust group id.
	 *
	 * @param custGroupId the custGroupId to set
	 */
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	/**
	 * Gets the cust id type.
	 *
	 * @return the custIdType
	 */
	public String getCustIdType() {
		return custIdType;
	}
	
	/**
	 * Sets the cust id type.
	 *
	 * @param custIdType the custIdType to set
	 */
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}
	
	/**
	 * Gets the txn id.
	 *
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}
	
	/**
	 * Sets the txn id.
	 *
	 * @param txnId the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	
	/**
	 * Gets the txn type.
	 *
	 * @return the txnType
	 */
	public String getTxnType() {
		return txnType;
	}
	
	/**
	 * Sets the txn type.
	 *
	 * @param txnType the txnType to set
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	
	/**
	 * Gets the txn date.
	 *
	 * @return the txnDate
	 */
	public Date getTxnDate() {
		return txnDate;
	}
	
	/**
	 * Sets the txn date.
	 *
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
	
	/**
	 * Gets the txn curr.
	 *
	 * @return the txnCurr
	 */
	public String getTxnCurr() {
		return txnCurr;
	}
	
	/**
	 * Sets the txn curr.
	 *
	 * @param txnCurr the txnCurr to set
	 */
	public void setTxnCurr(String txnCurr) {
		this.txnCurr = txnCurr;
	}
	
	/**
	 * Gets the txn amt.
	 *
	 * @return the txnAmt
	 */
	public Double getTxnAmt() {
		return txnAmt;
	}
	
	/**
	 * Sets the txn amt.
	 *
	 * @param txnAmt the txnAmt to set
	 */
	public void setTxnAmt(Double txnAmt) {
		this.txnAmt = txnAmt;
	}
	
	/**
	 * Gets the txt status cd.
	 *
	 * @return the txtStatusCd
	 */
	public String getTxtStatusCd() {
		return txtStatusCd;
	}
	
	/**
	 * Sets the txt status cd.
	 *
	 * @param txtStatusCd the txtStatusCd to set
	 */
	public void setTxtStatusCd(String txtStatusCd) {
		this.txtStatusCd = txtStatusCd;
	}
	
	/**
	 * Gets the from acct no.
	 *
	 * @return the fromAcctNo
	 */
	public String getFromAcctNo() {
		return fromAcctNo;
	}
	
	/**
	 * Sets the from acct no.
	 *
	 * @param fromAcctNo the fromAcctNo to set
	 */
	public void setFromAcctNo(String fromAcctNo) {
		this.fromAcctNo = fromAcctNo;
	}
	
	/**
	 * Gets the to acct no.
	 *
	 * @return the toAcctNo
	 */
	public String getToAcctNo() {
		return toAcctNo;
	}
	
	/**
	 * Sets the to acct no.
	 *
	 * @param toAcctNo the toAcctNo to set
	 */
	public void setToAcctNo(String toAcctNo) {
		this.toAcctNo = toAcctNo;
	}
	
	/**
	 * Gets the from acct name.
	 *
	 * @return the fromAcctName
	 */
	public String getFromAcctName() {
		return fromAcctName;
	}
	
	/**
	 * Sets the from acct name.
	 *
	 * @param fromAcctName the fromAcctName to set
	 */
	public void setFromAcctName(String fromAcctName) {
		this.fromAcctName = fromAcctName;
	}
	
	/**
	 * Gets the to acct name.
	 *
	 * @return the toAcctName
	 */
	public String getToAcctName() {
		return toAcctName;
	}
	
	/**
	 * Sets the to acct name.
	 *
	 * @param toAcctName the toAcctName to set
	 */
	public void setToAcctName(String toAcctName) {
		this.toAcctName = toAcctName;
	}
	
	/**
	 * Gets the custom var01.
	 *
	 * @return the customVar01
	 */
	public String getCustomVar01() {
		return customVar01;
	}
	
	/**
	 * Sets the custom var01.
	 *
	 * @param customVar01 the customVar01 to set
	 */
	public void setCustomVar01(String customVar01) {
		this.customVar01 = customVar01;
	}
	
	/**
	 * Gets the custom var02.
	 *
	 * @return the customVar02
	 */
	public String getCustomVar02() {
		return customVar02;
	}
	
	/**
	 * Sets the custom var02.
	 *
	 * @param customVar02 the customVar02 to set
	 */
	public void setCustomVar02(String customVar02) {
		this.customVar02 = customVar02;
	}
	
	/**
	 * Gets the custom var03.
	 *
	 * @return the customVar03
	 */
	public String getCustomVar03() {
		return customVar03;
	}
	
	/**
	 * Sets the custom var03.
	 *
	 * @param customVar03 the customVar03 to set
	 */
	public void setCustomVar03(String customVar03) {
		this.customVar03 = customVar03;
	}
	
	/**
	 * Gets the custom var04.
	 *
	 * @return the customVar04
	 */
	public String getCustomVar04() {
		return customVar04;
	}
	
	/**
	 * Sets the custom var04.
	 *
	 * @param customVar04 the customVar04 to set
	 */
	public void setCustomVar04(String customVar04) {
		this.customVar04 = customVar04;
	}
	
	/**
	 * Gets the custom var05.
	 *
	 * @return the customVar05
	 */
	public String getCustomVar05() {
		return customVar05;
	}
	
	/**
	 * Sets the custom var05.
	 *
	 * @param customVar05 the customVar05 to set
	 */
	public void setCustomVar05(String customVar05) {
		this.customVar05 = customVar05;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the audit by.
	 *
	 * @return the auditBy
	 */
	public String getAuditBy() {
		return auditBy;
	}
	
	/**
	 * Sets the audit by.
	 *
	 * @param auditBy the auditBy to set
	 */
	public void setAuditBy(String auditBy) {
		this.auditBy = auditBy;
	}
	
	/**
	 * Gets the dt audit.
	 *
	 * @return the dtAudit
	 */
	public Date getDtAudit() {
		return dtAudit;
	}
	
	/**
	 * Sets the dt audit.
	 *
	 * @param dtAudit the dtAudit to set
	 */
	public void setDtAudit(Date dtAudit) {
		this.dtAudit = dtAudit;
	}
	
	/**
	 * Gets the date upd.
	 *
	 * @return the dateUpd
	 */
	public Date getDateUpd() {
		return dateUpd;
	}
	
	/**
	 * Sets the date upd.
	 *
	 * @param dateUpd the dateUpd to set
	 */
	public void setDateUpd(Date dateUpd) {
		this.dateUpd = dateUpd;
	}
	
	/**
	 * Gets the date created.
	 *
	 * @return the dateCreated
	 */
	public Date getDateCreated() {
		return dateCreated;
	}
	
	/**
	 * Sets the date created.
	 *
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	/**
	 * Gets the mobile no.
	 *
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	
	/**
	 * Sets the mobile no.
	 *
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	/**
	 * Gets the custom date.
	 *
	 * @return the customDate
	 */
	public Date getCustomDate() {
		return customDate;
	}
	
	/**
	 * Sets the custom date.
	 *
	 * @param customDate the customDate to set
	 */
	public void setCustomDate(Date customDate) {
		this.customDate = customDate;
	}
	
	
	/**
	 * Gets the to acc curr cd.
	 *
	 * @return the toAccCurrCd
	 */
	public String getToAccCurrCd() {
		return toAccCurrCd;
	}
	
	/**
	 * Sets the to acc curr cd.
	 *
	 * @param toAccCurrCd the toAccCurrCd to set
	 */
	public void setToAccCurrCd(String toAccCurrCd) {
		this.toAccCurrCd = toAccCurrCd;
	}
	
	/**
	 * Gets the ip address.
	 *
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}
	
	/**
	 * Sets the ip address.
	 *
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	/**
	 * Gets the client ip address.
	 *
	 * @return the clientIpAddress
	 */
	public String getClientIpAddress() {
		return clientIpAddress;
	}
	
	/**
	 * Sets the client ip address.
	 *
	 * @param clientIpAddress the clientIpAddress to set
	 */
	public void setClientIpAddress(String clientIpAddress) {
		this.clientIpAddress = clientIpAddress;
	}
	
	/**
	 * Gets the from acc curr cd.
	 *
	 * @return the fromAccCurrCd
	 */
	public String getFromAccCurrCd() {
		return fromAccCurrCd;
	}
	
	/**
	 * Sets the from acc curr cd.
	 *
	 * @param fromAccCurrCd the fromAccCurrCd to set
	 */
	public void setFromAccCurrCd(String fromAccCurrCd) {
		this.fromAccCurrCd = fromAccCurrCd;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Gets the email notification.
	 *
	 * @return the emailNotification
	 */
	public String getEmailNotification() {
		return emailNotification;
	}
	
	/**
	 * Sets the email notification.
	 *
	 * @param emailNotification the emailNotification to set
	 */
	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}
	
	/**
	 * Gets the sms notification.
	 *
	 * @return the smsNotification
	 */
	public String getSmsNotification() {
		return smsNotification;
	}
	
	/**
	 * Sets the sms notification.
	 *
	 * @param smsNotification the smsNotification to set
	 */
	public void setSmsNotification(String smsNotification) {
		this.smsNotification = smsNotification;
	}
	
	/**
	 * Gets the inbox notification.
	 *
	 * @return the inboxNotification
	 */
	public String getInboxNotification() {
		return inboxNotification;
	}
	
	/**
	 * Sets the inbox notification.
	 *
	 * @param inboxNotification the inboxNotification to set
	 */
	public void setInboxNotification(String inboxNotification) {
		this.inboxNotification = inboxNotification;
	}
	
	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}
	
	/**
	 * Sets the language.
	 *
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	public String getuUser() {
		return uUser;
	}

	public void setuUser(String uUser) {
		this.uUser = uUser;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
