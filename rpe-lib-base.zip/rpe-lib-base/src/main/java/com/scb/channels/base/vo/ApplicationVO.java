package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class ApplicationVO.
 */
public class ApplicationVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4668725343603160754L;
	
	/** The id. */
	private Integer id;
	
	/** The session id. */
	private String sessionId;
	
	/** The status cd. */
	private String statusCd;
	
	/** The customer id. */
	private String customerId;
	
	/** The customer type. */
	private String customerType;
	
	/** The application type. */
	private String applicationType;
	
	/** The custom var01. */
	private String customVar01;
	
	/** The custom var02. */
	private String customVar02;
	
	/** The custom var03. */
	private String customVar03;
	
	/** The custom var04. */
	private String customVar04;
	
	/** The custom var05. */
	private String customVar05;
	
	/** The segment cd. */
	private String segmentCd;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt created. */
	private Date dtCreated;
	private Date customVar07;
	private Date customVar08;
	
	public Date getCustomVar07() {
		return customVar07;
	}

	public void setCustomVar07(Date customVar07) {
		this.customVar07 = customVar07;
	}

	public Date getCustomVar08() {
		return customVar08;
	}

	public void setCustomVar08(Date customVar08) {
		this.customVar08 = customVar08;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the session id.
	 *
	 * @return the session id
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * Sets the session id.
	 *
	 * @param sessionId the new session id
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the new customer id
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the customer type.
	 *
	 * @return the customer type
	 */
	public String getCustomerType() {
		return customerType;
	}

	/**
	 * Sets the customer type.
	 *
	 * @param customerType the new customer type
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	/**
	 * Gets the application type.
	 *
	 * @return the application type
	 */
	public String getApplicationType() {
		return applicationType;
	}

	/**
	 * Sets the application type.
	 *
	 * @param applicationType the new application type
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	/**
	 * Gets the custom var01.
	 *
	 * @return the custom var01
	 */
	public String getCustomVar01() {
		return customVar01;
	}

	/**
	 * Sets the custom var01.
	 *
	 * @param customVar01 the new custom var01
	 */
	public void setCustomVar01(String customVar01) {
		this.customVar01 = customVar01;
	}

	/**
	 * Gets the custom var02.
	 *
	 * @return the custom var02
	 */
	public String getCustomVar02() {
		return customVar02;
	}

	/**
	 * Sets the custom var02.
	 *
	 * @param customVar02 the new custom var02
	 */
	public void setCustomVar02(String customVar02) {
		this.customVar02 = customVar02;
	}

	/**
	 * Gets the custom var03.
	 *
	 * @return the custom var03
	 */
	public String getCustomVar03() {
		return customVar03;
	}

	/**
	 * Sets the custom var03.
	 *
	 * @param customVar03 the new custom var03
	 */
	public void setCustomVar03(String customVar03) {
		this.customVar03 = customVar03;
	}

	/**
	 * Gets the custom var04.
	 *
	 * @return the custom var04
	 */
	public String getCustomVar04() {
		return customVar04;
	}

	/**
	 * Sets the custom var04.
	 *
	 * @param customVar04 the new custom var04
	 */
	public void setCustomVar04(String customVar04) {
		this.customVar04 = customVar04;
	}

	/**
	 * Gets the segment cd.
	 *
	 * @return the segment cd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}

	/**
	 * Sets the segment cd.
	 *
	 * @param segmentCd the new segment cd
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}

	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}

	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}

	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	/**
	 * @return the customVar05
	 */
	public String getCustomVar05() {
		return customVar05;
	}

	/**
	 * @param customVar05 the customVar05 to set
	 */
	public void setCustomVar05(String customVar05) {
		this.customVar05 = customVar05;
	}

	
	

}
