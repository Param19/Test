/**
 * 
 */
package com.scb.channels.base.vo;


/**
 * The Class TransferRequestVO.
 *
 * @author 1464143
 */
public class TransferRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6208992034436132675L;
	
	/** The source account. */
	private AccountVO sourceAccount;
	
	/** The dest account. */
	private AccountVO destAccount;
	
	/** The transation info vo. */
	private TransactionInfoVO transactionInfoVO;
	
	private MphesaDetailsVO mphesaDetailsVO;

	/**
	 * Gets the source account.
	 *
	 * @return the sourceAccount
	 */
	public AccountVO getSourceAccount() {
		return sourceAccount;
	}

	/**
	 * Sets the source account.
	 *
	 * @param sourceAccount the sourceAccount to set
	 */
	public void setSourceAccount(AccountVO sourceAccount) {
		this.sourceAccount = sourceAccount;
	}

	/**
	 * Gets the dest account.
	 *
	 * @return the destAccount
	 */
	public AccountVO getDestAccount() {
		return destAccount;
	}

	/**
	 * Sets the dest account.
	 *
	 * @param destAccount the destAccount to set
	 */
	public void setDestAccount(AccountVO destAccount) {
		this.destAccount = destAccount;
	}

	/**
	 * Gets the transation info vo.
	 *
	 * @return the transationInfoVO
	 */
	public TransactionInfoVO getTransactionInfoVO() {
		return transactionInfoVO;
	}

	/**
	 * Sets the transation info vo.
	 *
	 * @param transationInfoVO the transationInfoVO to set
	 */
	public void setTransactionInfoVO(TransactionInfoVO transactionInfoVO) {
		this.transactionInfoVO = transactionInfoVO;
	}

	/**
	 * @return the mphesaDetailsVO
	 */
	public MphesaDetailsVO getMphesaDetailsVO() {
		return mphesaDetailsVO;
	}

	/**
	 * @param mphesaDetailsVO the mphesaDetailsVO to set
	 */
	public void setMphesaDetailsVO(MphesaDetailsVO mphesaDetailsVO) {
		this.mphesaDetailsVO = mphesaDetailsVO;
	}


}
