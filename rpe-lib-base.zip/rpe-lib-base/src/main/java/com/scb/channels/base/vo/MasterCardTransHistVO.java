package com.scb.channels.base.vo;

import java.io.Serializable;

public class MasterCardTransHistVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5027902557897962501L;
	
	private String tranType;
	private String traceAudit;
	private String netwRefNumber;
	private String settlementDt;
	private String responseCode;
	private String responsedescription;
	private String timestamp;
	
	
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public String getTraceAudit() {
		return traceAudit;
	}
	public void setTraceAudit(String traceAudit) {
		this.traceAudit = traceAudit;
	}
	public String getNetwRefNumber() {
		return netwRefNumber;
	}
	public void setNetwRefNumber(String netwRefNumber) {
		this.netwRefNumber = netwRefNumber;
	}
	public String getSettlementDt() {
		return settlementDt;
	}
	public void setSettlementDt(String settlementDt) {
		this.settlementDt = settlementDt;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponsedescription() {
		return responsedescription;
	}
	public void setResponsedescription(String responsedescription) {
		this.responsedescription = responsedescription;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	
}
