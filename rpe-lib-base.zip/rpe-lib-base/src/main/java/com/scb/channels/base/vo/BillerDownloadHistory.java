package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author 1460693
 * 
 * <p> created for Download History
 *
 */
public class BillerDownloadHistory implements Serializable,Cloneable{
	
	
private static final long serialVersionUID = -2747663972042859186L;

private Integer id;

private String billerCategory;

private String billerCategoryId;

private String billerName;

private String billerId;

private String productName;

private String countryCode;


private String serviceType;

private String otherfield1;

private String description;

private String status;


private Timestamp createdTime;

private Timestamp updateTime;


public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public String getBillerCategory() {
	return billerCategory;
}

public void setBillerCategory(String billerCategory) {
	this.billerCategory = billerCategory;
}

public String getBillerCategoryId() {
	return billerCategoryId;
}

public void setBillerCategoryId(String billerCategoryId) {
	this.billerCategoryId = billerCategoryId;
}

public String getBillerName() {
	return billerName;
}

public void setBillerName(String billerName) {
	this.billerName = billerName;
}

public String getBillerId() {
	return billerId;
}

public void setBillerId(String billerId) {
	this.billerId = billerId;
}

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public String getServiceType() {
	return serviceType;
}

public void setServiceType(String serviceType) {
	this.serviceType = serviceType;
}

public String getOtherfield1() {
	return otherfield1;
}

public void setOtherfield1(String otherfield1) {
	this.otherfield1 = otherfield1;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public Timestamp getCreatedTime() {
	return createdTime;
}

public void setCreatedTime(Timestamp createdTime) {
	this.createdTime = createdTime;
}

public Timestamp getUpdateTime() {
	return updateTime;
}

public void setUpdateTime(Timestamp updateTime) {
	this.updateTime = updateTime;
}

public String getCountryCode() {
	return countryCode;
}

public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
}

@Override
public Object clone(){  
    try{  
        return super.clone();  
    }catch(Exception e){ 
        return null; 
    }
}

}
