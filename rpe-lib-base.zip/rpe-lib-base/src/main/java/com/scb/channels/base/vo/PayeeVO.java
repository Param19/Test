package com.scb.channels.base.vo;

import java.io.Serializable;

public class PayeeVO implements Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 6956895935823585312L;

	private String txnId;
	private String cardNumber;
	private String eligibility;
	private String eligibilityReason;
	private String aquiringBin;
	private String currency;
	private String currencyNum;
	private String country;
	private String countryNumeric;
	private String acceptBrandCode;
	private String productCode;
	private String errorCode;
	private String errorDesc;
	private String recoverable;
	
	//Visa Details
	private String traceAudit;
	private String refNumber;
	private String aquirerCountryCode;
	private String issuerName;
	private String fastFundsInd;
	private String blockInd;
	private String gamblingInd;
	
	private MasterCardErrorVO masterCardErrorVO;
	
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getEligibility() {
		return eligibility;
	}
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	public String getEligibilityReason() {
		return eligibilityReason;
	}
	public void setEligibilityReason(String eligibilityReason) {
		this.eligibilityReason = eligibilityReason;
	}
	public String getAquiringBin() {
		return aquiringBin;
	}
	public void setAquiringBin(String aquiringBin) {
		this.aquiringBin = aquiringBin;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrencyNum() {
		return currencyNum;
	}
	public void setCurrencyNum(String currencyNum) {
		this.currencyNum = currencyNum;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryNumeric() {
		return countryNumeric;
	}
	public void setCountryNumeric(String countryNumeric) {
		this.countryNumeric = countryNumeric;
	}
	public String getAcceptBrandCode() {
		return acceptBrandCode;
	}
	public void setAcceptBrandCode(String acceptBrandCode) {
		this.acceptBrandCode = acceptBrandCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public String getRecoverable() {
		return recoverable;
	}
	public void setRecoverable(String recoverable) {
		this.recoverable = recoverable;
	}
	public String getTraceAudit() {
		return traceAudit;
	}
	public void setTraceAudit(String traceAudit) {
		this.traceAudit = traceAudit;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getAquirerCountryCode() {
		return aquirerCountryCode;
	}
	public void setAquirerCountryCode(String aquirerCountryCode) {
		this.aquirerCountryCode = aquirerCountryCode;
	}
	public String getIssuerName() {
		return issuerName;
	}
	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}
	public String getFastFundsInd() {
		return fastFundsInd;
	}
	public void setFastFundsInd(String fastFundsInd) {
		this.fastFundsInd = fastFundsInd;
	}
	public String getBlockInd() {
		return blockInd;
	}
	public void setBlockInd(String blockInd) {
		this.blockInd = blockInd;
	}
	public String getGamblingInd() {
		return gamblingInd;
	}
	public void setGamblingInd(String gamblingInd) {
		this.gamblingInd = gamblingInd;
	}
	public MasterCardErrorVO getMasterCardErrorVO() {
		return masterCardErrorVO;
	}
	public void setMasterCardErrorVO(MasterCardErrorVO masterCardErrorVO) {
		this.masterCardErrorVO = masterCardErrorVO;
	}
	
	
}
