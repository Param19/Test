/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * @author 1411807
 *
 */
public class LDAPAuthVO extends AuthVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 764265390452052768L;

	private String domainName;
	
	private String LDAPHostName;

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return the lDAPHostName
	 */
	public String getLDAPHostName() {
		return LDAPHostName;
	}

	/**
	 * @param lDAPHostName the lDAPHostName to set
	 */
	public void setLDAPHostName(String lDAPHostName) {
		LDAPHostName = lDAPHostName;
	}
}
