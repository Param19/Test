/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ProductListRequestVO.
 *
 * @author 1411807
 */
public class ProductListRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -14602944236046130L;


}
