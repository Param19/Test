package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;


public class NomineeVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8664779208579736140L;

	private String nomineeName;
	private String contactTelephoneNumber;
	private List<AddressVO> address;
	
	
	public String getNomineeName() {
		return nomineeName;
	}
	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}
	public String getContactTelephoneNumber() {
		return contactTelephoneNumber;
	}
	public void setContactTelephoneNumber(String contactTelephoneNumber) {
		this.contactTelephoneNumber = contactTelephoneNumber;
	}
	public List<AddressVO> getAddress() {
		return address;
	}
	public void setAddress(List<AddressVO> address) {
		this.address = address;
	}
}
