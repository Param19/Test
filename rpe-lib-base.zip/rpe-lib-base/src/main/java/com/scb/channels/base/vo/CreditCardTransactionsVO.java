package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class CreditCardTransactionsVO implements Serializable,Cloneable {

	
	private String transactionCode;
    private String transactiondate;
    private String transactionDesc;
    private String transactionDescription;
    private String transactionAmount;
    private String transactionref1;
    private String transactionref2;
    private String transactionref3;
    private String transactionStore;
	
 	
    public String getTransactionCode() {
		return transactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	public String getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}
	public String getTransactionDesc() {
		return transactionDesc;
	}
	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionref1() {
		return transactionref1;
	}
	public void setTransactionref1(String transactionref1) {
		this.transactionref1 = transactionref1;
	}
	public String getTransactionref2() {
		return transactionref2;
	}
	public void setTransactionref2(String transactionref2) {
		this.transactionref2 = transactionref2;
	}
	public String getTransactionref3() {
		return transactionref3;
	}
	public void setTransactionref3(String transactionref3) {
		this.transactionref3 = transactionref3;
	}
	public String getTransactionStore() {
		return transactionStore;
	}
	public void setTransactionStore(String transactionStore) {
		this.transactionStore = transactionStore;
	}
	
    
	

}
