package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class PaymentFieldDetails implements Serializable, Comparable<PaymentFieldDetails>{
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * id
	 */
	private Integer id;
	/**
	 * paymentId
	 */
	private Integer paymentId;
	/**
	 * fieldId
	 */
	private Integer fieldId;
	/**
	 * fieldValue
	 */
	private String fieldValue;
	/**
	 * fieldLabelName
	 */
	private String fieldLabelName;
	/**
	 * orderSequence
	 */
	private Integer orderSequence;
	/**
	 * caption
	 */
	private String caption;
	/**
	 * remarks
	 */
	private String remarks;
	/**
	 * fieldDataType
	 */
	private String fieldDataType;
	/**
	 * paymentDetailVO
	 */
	private PaymentDetailVO paymentDetailVO;
	/**
	 * billerFieldItems
	 */
	private Set<BillerFieldItemVO> billerFieldItems=new HashSet<BillerFieldItemVO>(0);
	
	/**
	 * 
	 */
	private String fieldType;
	
	
	/**
	 * 
	 */
	private String status;
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the fieldType
	 */
	public String getFieldType() {
		return fieldType;
	}
	/**
	 * @param fieldType the fieldType to set
	 */
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	/**
	 * @return the billerFieldItems
	 */
	public Set<BillerFieldItemVO> getBillerFieldItems() {
		return billerFieldItems;
	}
	/**
	 * @param billerFieldItems the billerFieldItems to set
	 */
	public void setBillerFieldItems(Set<BillerFieldItemVO> billerFieldItems) {
		this.billerFieldItems = billerFieldItems;
	}
	/**
	 * @return the fieldDataType
	 */
	public String getFieldDataType() {
		return fieldDataType;
	}
	/**
	 * @param fieldDataType the fieldDataType to set
	 */
	public void setFieldDataType(String fieldDataType) {
		this.fieldDataType = fieldDataType;
	}
	
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the paymentId
	 */
	public Integer getPaymentId() {
		return paymentId;
	}
	/**
	 * @param paymentId the paymentId to set
	 */
	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}
	/**
	 * @return the fieldId
	 */
	public Integer getFieldId() {
		return fieldId;
	}
	/**
	 * @param fieldId the fieldId to set
	 */
	public void setFieldId(Integer fieldId) {
		this.fieldId = fieldId;
	}
	/**
	 * @return the fieldValue
	 */
	public String getFieldValue() {
		return fieldValue;
	}
	/**
	 * @param fieldValue the fieldValue to set
	 */
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	/**
	 * @return the fieldLabelName
	 */
	public String getFieldLabelName() {
		return fieldLabelName;
	}
	/**
	 * @param fieldLabelName the fieldLabelName to set
	 */
	public void setFieldLabelName(String fieldLabelName) {
		this.fieldLabelName = fieldLabelName;
	}
	/**
	 * @return the orderSequence
	 */
	public Integer getOrderSequence() {
		return orderSequence;
	}
	/**
	 * @param orderSequence the orderSequence to set
	 */
	public void setOrderSequence(Integer orderSequence) {
		this.orderSequence = orderSequence;
	}
	/**
	 * @return the caption
	 */
	public String getCaption() {
		return caption;
	}
	/**
	 * @param caption the caption to set
	 */
	public void setCaption(String caption) {
		this.caption = caption;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
		/**
	 * @return the paymentDetailVO
	 */
	public PaymentDetailVO getPaymentDetailVO() {
		return paymentDetailVO;
	}
	/**
	 * @param paymentDetailVO the paymentDetailVO to set
	 */
	public void setPaymentDetailVO(PaymentDetailVO paymentDetailVO) {
		this.paymentDetailVO = paymentDetailVO;
	}
	@Override
	public int compareTo(PaymentFieldDetails o) {
		int compareOrderSequence = ((PaymentFieldDetails) o).getOrderSequence();
		return this.orderSequence - compareOrderSequence;
	}
}
