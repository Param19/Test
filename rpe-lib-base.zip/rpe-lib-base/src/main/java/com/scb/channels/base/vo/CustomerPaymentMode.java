package com.scb.channels.base.vo;


/**
 * This class contains Processor of CustomerPaymentAmount
 * 
 * @author 1317590
 */
public class CustomerPaymentMode {

	private String paymentType;

	private String paymentOption;

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

}
