package com.scb.channels.base.vo;

import java.util.Calendar;

/**
 * The Class ClientInfoVO.
 *
 * @author 1493439
 */
public class ClientInfoVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5884934448828390109L;

	/** The aggregator. */
	private String aggregator;
	
	/** The service provider. */
	private String serviceProvider;
	
	/** The country. */
	private String country;
	
	/** The date. */
	private Calendar date;

	/**
	 * @return the aggregator
	 */
	public String getAggregator() {
		return aggregator;
	}

	/**
	 * @param aggregator the aggregator to set
	 */
	public void setAggregator(String aggregator) {
		this.aggregator = aggregator;
	}

	/**
	 * @return the serviceProvider
	 */
	public String getServiceProvider() {
		return serviceProvider;
	}

	/**
	 * @param serviceProvider the serviceProvider to set
	 */
	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the date
	 */
	public Calendar getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Calendar date) {
		this.date = date;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ClientInfoVO [aggregator=" + aggregator + ", serviceProvider="
				+ serviceProvider + ", country=" + country + ", date=" + date
				+ "]";
	}
	
}
