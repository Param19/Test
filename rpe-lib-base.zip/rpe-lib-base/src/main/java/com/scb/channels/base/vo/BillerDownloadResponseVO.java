package com.scb.channels.base.vo;

import java.io.Serializable;


/**
 * The Class BillerListResponseVO.
 */
public class BillerDownloadResponseVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1493795083330553217L;
	
	private String responseXML;


	private java.util.List<BillerDetailsVO>  billerDetails;


	/**
	 * @return the billerDetails
	 */
	public java.util.List<BillerDetailsVO> getBillerDetails() {
		return billerDetails;
	}


	/**
	 * @param billerDetails the billerDetails to set
	 */
	public void setBillerDetails(java.util.List<BillerDetailsVO> billerDetails) {
		this.billerDetails = billerDetails;
	}


	/**
	 * @return the responseXML
	 */
	public String getResponseXML() {
		return responseXML;
	}


	/**
	 * @param responseXML the responseXML to set
	 */
	public void setResponseXML(String responseXML) {
		this.responseXML = responseXML;
	}
}
