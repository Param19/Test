/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class CardListResponseVO.
 *
 * @author 1411807
 */
public class CardListResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5917000575308043L;



}
