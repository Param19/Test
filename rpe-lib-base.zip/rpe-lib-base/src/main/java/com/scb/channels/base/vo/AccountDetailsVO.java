package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class AccountDetailsVO.
 */
public class AccountDetailsVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9038218082851056855L;
	
	 	/** The customer master number. */
	 	private String customerMasterNumber;
	    
    	/** The primary relationship flag. */
    	private String primaryRelationshipFlag;
	    
    	/** The customer identification number. */
    	private String customerIdentificationNumber;
	    
    	/** The institution classification code. */
    	private String institutionClassificationCode;
	    
    	/** The operating instructions. */
    	private String operatingInstructions;
	    
    	/** The currency code. */
    	private String currencyCode;
	    
    	/** The account number. */
    	private String accountNumber;
	    
    	/** The product code. */
    	private String productCode;
	    
    	/** The product description. */
    	private String productDescription;
	    
    	/** The branch code. */
    	private String branchCode;
	    
    	/** The branch name. */
    	private String branchName;
	    
    	/** The open date. */
    	private Calendar openDate;
	    
    	/** The category code. */
    	private String categoryCode;
	    
    	/** The current status. */
    	private String currentStatus;
	    
    	/** The close date. */
    	private Calendar closeDate;
	    
    	/** The full name. */
    	private String fullName;
	    
    	/** The multilingual. */
    	private MultilingualVO multilingual;
	    
    	/** The ledger balance. */
    	private String ledgerBalance;
    	
    	/** The with limit. */
	    private String withLimit;
	    
    	/** The without limit. */
	    private String withoutLimit;
	    
    	/** The with intraday limit. */
	    private String withIntradayLimit;
	    
    	/** The limit amount. */
	    private String limitAmount;
	    
    	/** The with drawn on uncleared effects. */
	    private String withDrawnOnUnclearedEffects;
	    
    	/** The with close of day. */
	    private String withCloseOfDay;
	    
    	/** The mortgage loan account number. */
    	private String mortgageLoanAccountNumber;
	    
    	/** The risk details. */
    	private List<RiskVO> riskDetails;
		
	    
	    /**
    	 * Gets the customer master number.
    	 *
    	 * @return the customer master number
    	 */
    	public String getCustomerMasterNumber() {
			return customerMasterNumber;
		}
		
		/**
		 * Sets the customer master number.
		 *
		 * @param customerMasterNumber the new customer master number
		 */
		public void setCustomerMasterNumber(String customerMasterNumber) {
			this.customerMasterNumber = customerMasterNumber;
		}
		
		/**
		 * Gets the primary relationship flag.
		 *
		 * @return the primary relationship flag
		 */
		public String getPrimaryRelationshipFlag() {
			return primaryRelationshipFlag;
		}
		
		/**
		 * Sets the primary relationship flag.
		 *
		 * @param primaryRelationshipFlag the new primary relationship flag
		 */
		public void setPrimaryRelationshipFlag(String primaryRelationshipFlag) {
			this.primaryRelationshipFlag = primaryRelationshipFlag;
		}
		
		/**
		 * Gets the customer identification number.
		 *
		 * @return the customer identification number
		 */
		public String getCustomerIdentificationNumber() {
			return customerIdentificationNumber;
		}
		
		/**
		 * Sets the customer identification number.
		 *
		 * @param customerIdentificationNumber the new customer identification number
		 */
		public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
			this.customerIdentificationNumber = customerIdentificationNumber;
		}
		
		/**
		 * Gets the institution classification code.
		 *
		 * @return the institution classification code
		 */
		public String getInstitutionClassificationCode() {
			return institutionClassificationCode;
		}
		
		/**
		 * Sets the institution classification code.
		 *
		 * @param institutionClassificationCode the new institution classification code
		 */
		public void setInstitutionClassificationCode(
				String institutionClassificationCode) {
			this.institutionClassificationCode = institutionClassificationCode;
		}
		
		/**
		 * Gets the operating instructions.
		 *
		 * @return the operating instructions
		 */
		public String getOperatingInstructions() {
			return operatingInstructions;
		}
		
		/**
		 * Sets the operating instructions.
		 *
		 * @param operatingInstructions the new operating instructions
		 */
		public void setOperatingInstructions(String operatingInstructions) {
			this.operatingInstructions = operatingInstructions;
		}
		
		/**
		 * Gets the currency code.
		 *
		 * @return the currency code
		 */
		public String getCurrencyCode() {
			return currencyCode;
		}
		
		/**
		 * Sets the currency code.
		 *
		 * @param currencyCode the new currency code
		 */
		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}
		
		/**
		 * Gets the account number.
		 *
		 * @return the account number
		 */
		public String getAccountNumber() {
			return accountNumber;
		}
		
		/**
		 * Sets the account number.
		 *
		 * @param accountNumber the new account number
		 */
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		
		/**
		 * Gets the product code.
		 *
		 * @return the product code
		 */
		public String getProductCode() {
			return productCode;
		}
		
		/**
		 * Sets the product code.
		 *
		 * @param productCode the new product code
		 */
		public void setProductCode(String productCode) {
			this.productCode = productCode;
		}
		
		/**
		 * Gets the product description.
		 *
		 * @return the product description
		 */
		public String getProductDescription() {
			return productDescription;
		}
		
		/**
		 * Sets the product description.
		 *
		 * @param productDescription the new product description
		 */
		public void setProductDescription(String productDescription) {
			this.productDescription = productDescription;
		}
		
		/**
		 * Gets the branch code.
		 *
		 * @return the branch code
		 */
		public String getBranchCode() {
			return branchCode;
		}
		
		/**
		 * Sets the branch code.
		 *
		 * @param branchCode the new branch code
		 */
		public void setBranchCode(String branchCode) {
			this.branchCode = branchCode;
		}
		
		/**
		 * Gets the branch name.
		 *
		 * @return the branch name
		 */
		public String getBranchName() {
			return branchName;
		}
		
		/**
		 * Sets the branch name.
		 *
		 * @param branchName the new branch name
		 */
		public void setBranchName(String branchName) {
			this.branchName = branchName;
		}
		
		/**
		 * Gets the open date.
		 *
		 * @return the open date
		 */
		public Calendar getOpenDate() {
			return openDate;
		}
		
		/**
		 * Sets the open date.
		 *
		 * @param openDate the new open date
		 */
		public void setOpenDate(Calendar openDate) {
			this.openDate = openDate;
		}
		
		/**
		 * Gets the category code.
		 *
		 * @return the category code
		 */
		public String getCategoryCode() {
			return categoryCode;
		}
		
		/**
		 * Sets the category code.
		 *
		 * @param categoryCode the new category code
		 */
		public void setCategoryCode(String categoryCode) {
			this.categoryCode = categoryCode;
		}
		
		/**
		 * Gets the current status.
		 *
		 * @return the current status
		 */
		public String getCurrentStatus() {
			return currentStatus;
		}
		
		/**
		 * Sets the current status.
		 *
		 * @param currentStatus the new current status
		 */
		public void setCurrentStatus(String currentStatus) {
			this.currentStatus = currentStatus;
		}
		
		/**
		 * Gets the close date.
		 *
		 * @return the close date
		 */
		public Calendar getCloseDate() {
			return closeDate;
		}
		
		/**
		 * Sets the close date.
		 *
		 * @param closeDate the new close date
		 */
		public void setCloseDate(Calendar closeDate) {
			this.closeDate = closeDate;
		}
		
		/**
		 * Gets the full name.
		 *
		 * @return the full name
		 */
		public String getFullName() {
			return fullName;
		}
		
		/**
		 * Sets the full name.
		 *
		 * @param fullName the new full name
		 */
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		
		/**
		 * Gets the multilingual.
		 *
		 * @return the multilingual
		 */
		public MultilingualVO getMultilingual() {
			return multilingual;
		}
		
		/**
		 * Sets the multilingual.
		 *
		 * @param multilingual the new multilingual
		 */
		public void setMultilingual(MultilingualVO multilingual) {
			this.multilingual = multilingual;
		}
		
		/**
		 * Gets the ledger balance.
		 *
		 * @return the ledger balance
		 */
		public String getLedgerBalance() {
			return ledgerBalance;
		}
		
		/**
		 * Sets the ledger balance.
		 *
		 * @param ledgerBalance the new ledger balance
		 */
		public void setLedgerBalance(String ledgerBalance) {
			this.ledgerBalance = ledgerBalance;
		}
		
		/**
		 * Gets the mortgage loan account number.
		 *
		 * @return the mortgage loan account number
		 */
		public String getMortgageLoanAccountNumber() {
			return mortgageLoanAccountNumber;
		}
		
		/**
		 * Sets the mortgage loan account number.
		 *
		 * @param mortgageLoanAccountNumber the new mortgage loan account number
		 */
		public void setMortgageLoanAccountNumber(String mortgageLoanAccountNumber) {
			this.mortgageLoanAccountNumber = mortgageLoanAccountNumber;
		}
		
		/**
		 * Gets the risk details.
		 *
		 * @return the riskDetails
		 */
		public List<RiskVO> getRiskDetails() {
			return riskDetails;
		}
		
		/**
		 * Sets the risk details.
		 *
		 * @param riskDetails the riskDetails to set
		 */
		public void setRiskDetails(List<RiskVO> riskDetails) {
			this.riskDetails = riskDetails;
		}

		/**
		 * @return the withLimit
		 */
		public String getWithLimit() {
			return withLimit;
		}

		/**
		 * @param withLimit the withLimit to set
		 */
		public void setWithLimit(String withLimit) {
			this.withLimit = withLimit;
		}

		/**
		 * @return the withoutLimit
		 */
		public String getWithoutLimit() {
			return withoutLimit;
		}

		/**
		 * @param withoutLimit the withoutLimit to set
		 */
		public void setWithoutLimit(String withoutLimit) {
			this.withoutLimit = withoutLimit;
		}

		/**
		 * @return the withIntradayLimit
		 */
		public String getWithIntradayLimit() {
			return withIntradayLimit;
		}

		/**
		 * @param withIntradayLimit the withIntradayLimit to set
		 */
		public void setWithIntradayLimit(String withIntradayLimit) {
			this.withIntradayLimit = withIntradayLimit;
		}

		/**
		 * @return the limitAmount
		 */
		public String getLimitAmount() {
			return limitAmount;
		}

		/**
		 * @param limitAmount the limitAmount to set
		 */
		public void setLimitAmount(String limitAmount) {
			this.limitAmount = limitAmount;
		}

		/**
		 * @return the withDrawnOnUnclearedEffects
		 */
		public String getWithDrawnOnUnclearedEffects() {
			return withDrawnOnUnclearedEffects;
		}

		/**
		 * @param withDrawnOnUnclearedEffects the withDrawnOnUnclearedEffects to set
		 */
		public void setWithDrawnOnUnclearedEffects(String withDrawnOnUnclearedEffects) {
			this.withDrawnOnUnclearedEffects = withDrawnOnUnclearedEffects;
		}

		/**
		 * @return the withCloseOfDay
		 */
		public String getWithCloseOfDay() {
			return withCloseOfDay;
		}

		/**
		 * @param withCloseOfDay the withCloseOfDay to set
		 */
		public void setWithCloseOfDay(String withCloseOfDay) {
			this.withCloseOfDay = withCloseOfDay;
		}
	

}
