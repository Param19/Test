package com.scb.channels.base.vo;

import java.io.Serializable;

public class CustomerToAccountLinkVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6148572238751789146L;

	 private String linkedCustomerIdentificationNumber;
	 private String linkedCustomerType;
	
	 
	 public String getLinkedCustomerIdentificationNumber() {
		return linkedCustomerIdentificationNumber;
	}
	public void setLinkedCustomerIdentificationNumber(
			String linkedCustomerIdentificationNumber) {
		this.linkedCustomerIdentificationNumber = linkedCustomerIdentificationNumber;
	}
	public String getLinkedCustomerType() {
		return linkedCustomerType;
	}
	public void setLinkedCustomerType(String linkedCustomerType) {
		this.linkedCustomerType = linkedCustomerType;
	}
}
