package com.scb.channels.base.interceptor;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.cxf.binding.soap.interceptor.SoapPreProtocolOutInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

/**
 * The Class MassageMessageInInterceptor.
 */
public class MassageMessageInInterceptor extends AbstractPhaseInterceptor<Message> {


	  private static final String FOR_MODIFY_SINGLEQUOTE = "forModify=''";
	public static final String FOR_MODIFY = "forModify=\"\"";
	public static final String SPACE = "";
	public static final String UTF_8 = "UTF-8";

	/**
  	 * Instantiates a new massage message in interceptor.
  	 */
  	public MassageMessageInInterceptor() {
		  super(Phase.PRE_STREAM);
		  addBefore(SoapPreProtocolOutInterceptor.class.getName());
	  }

	  /* (non-Javadoc)
  	 * @see org.apache.cxf.interceptor.Interceptor#handleMessage(org.apache.cxf.message.Message)
  	 */
  	public void handleMessage(Message message) throws Fault {
		  boolean isOutbound = false;
	        isOutbound = message == message.getExchange().getOutMessage()
	                || message == message.getExchange().getOutFaultMessage();

	        if (isOutbound) {
	            OutputStream os = message.getContent(OutputStream.class);

	            CachedStream cs = new CachedStream();
	            message.setContent(OutputStream.class, cs);

	            message.getInterceptorChain().doIntercept(message);

	            try {
	                cs.flush();
	                IOUtils.closeQuietly(cs);
	                CachedOutputStream csnew = (CachedOutputStream) message.getContent(OutputStream.class);

	                String currentEnvelopeMessage = IOUtils.toString(csnew.getInputStream(), UTF_8);
	                currentEnvelopeMessage = currentEnvelopeMessage.replace(FOR_MODIFY, SPACE);
	                currentEnvelopeMessage = currentEnvelopeMessage.replace(FOR_MODIFY_SINGLEQUOTE, SPACE);
	                csnew.flush();
	                IOUtils.closeQuietly(csnew);
	                InputStream replaceInStream = IOUtils.toInputStream(currentEnvelopeMessage, UTF_8);

	                IOUtils.copy(replaceInStream, os);
	                replaceInStream.close();
	                IOUtils.closeQuietly(replaceInStream);

	                os.flush();
	                message.setContent(OutputStream.class, os);
	                IOUtils.closeQuietly(os);

	            } catch (IOException ioe) {
	                throw new Fault(ioe);
	            }
	        } else {
	            try {
	                InputStream is = message.getContent(InputStream.class);
	                String currentEnvelopeMessage = IOUtils.toString(is, UTF_8);
	                IOUtils.closeQuietly(is);
	                is = IOUtils.toInputStream(currentEnvelopeMessage, UTF_8);
	                message.setContent(InputStream.class, is);
	                IOUtils.closeQuietly(is);
	            } catch (IOException ioe) {
	                throw new Fault(ioe);
	            }
	        }
	    }

	    /* (non-Javadoc)
    	 * @see org.apache.cxf.phase.AbstractPhaseInterceptor#handleFault(org.apache.cxf.message.Message)
    	 */
    	public void handleFault(Message message) {
	    }

	    /**
    	 * The Class CachedStream.
    	 */
    	private class CachedStream extends CachedOutputStream {
	        
        	/**
        	 * Instantiates a new cached stream.
        	 */
        	public CachedStream() {
	            super();
	        }

	        /* (non-Javadoc)
        	 * @see org.apache.cxf.io.CachedOutputStream#doFlush()
        	 */
        	protected void doFlush() throws IOException {
	            currentStream.flush();
	        }

	        /* (non-Javadoc)
        	 * @see org.apache.cxf.io.CachedOutputStream#doClose()
        	 */
        	protected void doClose() throws IOException {
	        }

	        /* (non-Javadoc)
        	 * @see org.apache.cxf.io.CachedOutputStream#onWrite()
        	 */
        	protected void onWrite() throws IOException {
	        }
	    }
}
