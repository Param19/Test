package com.scb.channels.base.vo;

import java.io.Serializable;

public class MultilingualVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 192468977724126954L;
	
	private String accountFullName;
    private String branchName;
    private String productDescription;
	
    
    public String getAccountFullName() {
		return accountFullName;
	}
	public void setAccountFullName(String accountFullName) {
		this.accountFullName = accountFullName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

}
