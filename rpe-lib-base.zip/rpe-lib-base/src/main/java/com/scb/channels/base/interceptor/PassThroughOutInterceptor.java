package com.scb.channels.base.interceptor;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

public class PassThroughOutInterceptor extends AbstractPhaseInterceptor<Message> {


	  public PassThroughOutInterceptor() {
	    super(Phase.SETUP);
	  }

	  public void handleMessage(Message message) throws Fault {
	    //Do nothing pass through interceptor used for jboss purpose
	  }

	
}
