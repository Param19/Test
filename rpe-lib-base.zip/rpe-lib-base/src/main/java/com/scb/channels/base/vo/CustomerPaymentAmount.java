package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * This class contains Processor of CustomerPaymentAmount
 *
 * @author 1317590
 */
public class CustomerPaymentAmount implements Serializable, Cloneable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1646444884023515426L;
	
	private double totalPaymentAmount;

	public double getTotalPaymentAmount() {
		return totalPaymentAmount;
	}

	public void setTotalPaymentAmount(double totalPaymentAmount) {
		this.totalPaymentAmount = totalPaymentAmount;
	}
	

}
