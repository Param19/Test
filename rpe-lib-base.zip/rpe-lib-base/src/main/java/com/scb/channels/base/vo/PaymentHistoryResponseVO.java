
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * @author 1470817
 *
 */
public class PaymentHistoryResponseVO extends BaseVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private List<PaymentDetailVO> paymentHistList;

	/**
	 * @return the paymentHistList
	 */
	public List<PaymentDetailVO> getPaymentHistList() {
		return paymentHistList;
	}

	/**
	 * @param paymentHistList the paymentHistList to set
	 */
	public void setPaymentHistList(List<PaymentDetailVO> paymentHistList) {
		this.paymentHistList = paymentHistList;
	}

	
	

}
