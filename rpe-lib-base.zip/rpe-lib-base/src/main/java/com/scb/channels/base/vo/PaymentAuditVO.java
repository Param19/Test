package com.scb.channels.base.vo;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AUDIT_PYMT_DETAILS")
public class PaymentAuditVO {

	@Id
	@GeneratedValue
	private String id;
	@Column(name="TXN_ID")
	private String requestCode;
	@Column(name="REQUEST_ID")
	private String requestId;
	@Column(name="CONSUMER_NO")
	private String consumerNo;
	@Column(name="BILLER_CD")
	private String billerCd;
	@Column(name="SRC_ACCT_NO")
	private String accountNumber;
	@Column(name="SRC_ACCT_TYPE")
	private String accountType;
	@Column(name="PMT_SOURCE")
	private String debitAcctSrcType;
	@Column(name="SRC_ACCT_CURRENCY_CD")
	private String srcCurrencyCd;
	@Column(name="SRC_ACC_NAME")
	private String srcAccountName;
	@Column(name="DEST_ACCT_NO")
	private String destAccNo;
	@Column(name="DEST_ACCT_TYPE")
	private String destAccType;
	@Column(name="DEST_ACCT_CURRENCY_CD")
	private String destAccCurrCd;
	
	@Column(name="DEST_ACC_NAME")
	private String destAccName;
	
	@Column(name="SERVICE_TYPE")
	private String serviceName;
	@Column(name="PMT_AMT")
	private double txnAmount;
	@Column(name="DEBIT_AMT")
	private double debitAmount;
	@Column(name="DEST_TXN_AMT")
	private double destTxnAmt;
	@Column(name="TXN_CURRENCY_CD")
	private String currency;
	@Column(name="EXCHG_RATE")
	private double exchgRate;
	@Column(name="CUST_RATE")
	private double custRate;
	@Column(name="COST_RATE")
	private double costRate;
	@Column(name="PMT_REF")
	private String payRef;
	@Column(name="PROCESSING_MODE")
	private int processingMode;
	@Column(name="DT_PMT")
	private Date dtTransfer;
	@Column(name="IS_REG_BILLER")
	private String isRegBiller;
	
	private String txnCurrency;
	@Column(name="TXN_ACTVITY")
	private String txnActivity;
	@Column(name="TXN_ACTV_STATUS")
	private String txnActStatus;

	
	@Column(name="TXN_MODE")
	private String txnMode;
	@Column(name="TXN_STATUS_CD")
	private String txnStatusCd;
	@Column(name="TXN_TYPE_CD")
	private String txnTypeCd;
	@Column(name="HOST_TXN_REF_NO")
	private String hostTxnRefNo;
	@Column(name="HOST_RESP_CD")
	private String hostRespCd;
	@Column(name="HOST_RESP_DESC")
	private String hostRespDesc;
	@Column(name="CLIENT_REF_NO")
	private String clientRefNo;
	@Column(name="DT_PROCESSED")
	private Date dtProcessed;
	@Column(name="DT_CREATED")
	private Date dtCreated;
	@Column(name="CREATED_BY")
	private String createdBy;
	@Column(name="DT_UPD")
	private Date dtUpd;
	@Column(name="UPD_BY")
	private String updBy;
	@Column(name="VERSION")
	private int version;
	@Column(name="RECURRENCE_INTERVAL")
	private String recurrenceInterval;
	@Column(name="RECURRENCE_START_DT")
	private Date dtRecurrenceStart;
	@Column(name="RECURRENCE_END_DT")
	private Date dtRecurrenceEnd;
	@Column(name="DT_NEXT_EXEC")
	private Date dtRecurrenceNextExec;
	@Column(name="CUSTOMER_ID")
	private String customerId;
	@Column(name="CTRY_CD")
	private String country;
	@Column(name="CHANNEL_ID")
	private String channelId;
	@Column(name="LOG_EVENT")
	private String logEven;
	@Column(name="LOG_EXCEPTION")
	private String logException;
	@Column(name="LOG_TIMESTAMP")
	private String logTimeStamp;
	@Column(name="USE_CASE")
	private String useCase;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRequestCode() {
		return requestCode;
	}
	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getBillerCd() {
		return billerCd;
	}
	public void setBillerCd(String billerCd) {
		this.billerCd = billerCd;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getDebitAcctSrcType() {
		return debitAcctSrcType;
	}
	public void setDebitAcctSrcType(String debitAcctSrcType) {
		this.debitAcctSrcType = debitAcctSrcType;
	}
	public String getSrcCurrencyCd() {
		return srcCurrencyCd;
	}
	public void setSrcCurrencyCd(String srcCurrencyCd) {
		this.srcCurrencyCd = srcCurrencyCd;
	}
	public String getSrcAccountName() {
		return srcAccountName;
	}
	public void setSrcAccountName(String srcAccountName) {
		this.srcAccountName = srcAccountName;
	}
	public String getDestAccNo() {
		return destAccNo;
	}
	public void setDestAccNo(String destAccNo) {
		this.destAccNo = destAccNo;
	}
	public String getDestAccType() {
		return destAccType;
	}
	public void setDestAccType(String destAccType) {
		this.destAccType = destAccType;
	}
	public String getDestAccCurrCd() {
		return destAccCurrCd;
	}
	public void setDestAccCurrCd(String destAccCurrCd) {
		this.destAccCurrCd = destAccCurrCd;
	}
	public String getDestAccName() {
		return destAccName;
	}
	public void setDestAccName(String destAccName) {
		this.destAccName = destAccName;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public double getTxnAmount() {
		return txnAmount;
	}
	public void setTxnAmount(double txnAmount) {
		this.txnAmount = txnAmount;
	}
	public double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public double getDestTxnAmt() {
		return destTxnAmt;
	}
	public void setDestTxnAmt(double destTxnAmt) {
		this.destTxnAmt = destTxnAmt;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public double getExchgRate() {
		return exchgRate;
	}
	public void setExchgRate(double exchgRate) {
		this.exchgRate = exchgRate;
	}
	public double getCustRate() {
		return custRate;
	}
	public void setCustRate(double custRate) {
		this.custRate = custRate;
	}
	public double getCostRate() {
		return costRate;
	}
	public void setCostRate(double costRate) {
		this.costRate = costRate;
	}
	public String getPayRef() {
		return payRef;
	}
	public void setPayRef(String payRef) {
		this.payRef = payRef;
	}
	public int getProcessingMode() {
		return processingMode;
	}
	public void setProcessingMode(int processingMode) {
		this.processingMode = processingMode;
	}
	public Date getDtTransfer() {
		return dtTransfer;
	}
	public void setDtTransfer(Date dtTransfer) {
		this.dtTransfer = dtTransfer;
	}
	public String getIsRegBiller() {
		return isRegBiller;
	}
	public void setIsRegBiller(String isRegBiller) {
		this.isRegBiller = isRegBiller;
	}
	public String getTxnCurrency() {
		return txnCurrency;
	}
	public void setTxnCurrency(String txnCurrency) {
		this.txnCurrency = txnCurrency;
	}
	public String getTxnActivity() {
		return txnActivity;
	}
	public void setTxnActivity(String txnActivity) {
		this.txnActivity = txnActivity;
	}
	public String getTxnActStatus() {
		return txnActStatus;
	}
	public void setTxnActStatus(String txnActStatus) {
		this.txnActStatus = txnActStatus;
	}
	public String getTxnMode() {
		return txnMode;
	}
	public void setTxnMode(String txnMode) {
		this.txnMode = txnMode;
	}
	public String getTxnStatusCd() {
		return txnStatusCd;
	}
	public void setTxnStatusCd(String txnStatusCd) {
		this.txnStatusCd = txnStatusCd;
	}
	public String getTxnTypeCd() {
		return txnTypeCd;
	}
	public void setTxnTypeCd(String txnTypeCd) {
		this.txnTypeCd = txnTypeCd;
	}
	public String getHostTxnRefNo() {
		return hostTxnRefNo;
	}
	public void setHostTxnRefNo(String hostTxnRefNo) {
		this.hostTxnRefNo = hostTxnRefNo;
	}
	public String getHostRespCd() {
		return hostRespCd;
	}
	public void setHostRespCd(String hostRespCd) {
		this.hostRespCd = hostRespCd;
	}
	public String getHostRespDesc() {
		return hostRespDesc;
	}
	public void setHostRespDesc(String hostRespDesc) {
		this.hostRespDesc = hostRespDesc;
	}
	public String getClientRefNo() {
		return clientRefNo;
	}
	public void setClientRefNo(String clientRefNo) {
		this.clientRefNo = clientRefNo;
	}
	public Date getDtProcessed() {
		return dtProcessed;
	}
	public void setDtProcessed(Date dtProcessed) {
		this.dtProcessed = dtProcessed;
	}
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getDtUpd() {
		return dtUpd;
	}
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	public String getUpdBy() {
		return updBy;
	}
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	public String getRecurrenceInterval() {
		return recurrenceInterval;
	}
	public void setRecurrenceInterval(String recurrenceInterval) {
		this.recurrenceInterval = recurrenceInterval;
	}
	public Date getDtRecurrenceStart() {
		return dtRecurrenceStart;
	}
	public void setDtRecurrenceStart(Date dtRecurrenceStart) {
		this.dtRecurrenceStart = dtRecurrenceStart;
	}
	public Date getDtRecurrenceEnd() {
		return dtRecurrenceEnd;
	}
	public void setDtRecurrenceEnd(Date dtRecurrenceEnd) {
		this.dtRecurrenceEnd = dtRecurrenceEnd;
	}
	public Date getDtRecurrenceNextExec() {
		return dtRecurrenceNextExec;
	}
	public void setDtRecurrenceNextExec(Date dtRecurrenceNextExec) {
		this.dtRecurrenceNextExec = dtRecurrenceNextExec;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getLogEven() {
		return logEven;
	}
	public void setLogEven(String logEven) {
		this.logEven = logEven;
	}
	public String getLogException() {
		return logException;
	}
	public void setLogException(String logException) {
		this.logException = logException;
	}
	public String getLogTimeStamp() {
		return logTimeStamp;
	}
	public void setLogTimeStamp(String logTimeStamp) {
		this.logTimeStamp = logTimeStamp;
	}
	public String getUseCase() {
		return useCase;
	}
	public void setUseCase(String useCase) {
		this.useCase = useCase;
	}
}
