package com.scb.channels.base.vo;

import java.sql.Timestamp;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 * The Class InwardPaymentRequestVO.
 * 
 * @author 1493439
 *
 */
public class InwardPaymentRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6882842151183399344L;

	/** The inward transaction info vo. */
	private InwardTransactionInfoVO inwardTransactionInfoVO;

	/** The security info vo. */
	private SecurityInfoVO securityInfoVO;

	/** The sender info vo. */
	private SenderInfoVO senderInfoVO;

	/** The client info vo. */
	private ClientInfoVO clientInfoVO;

	/** The reference number. */
	private String referenceNumber;

	/** The rel id. */
	private String relId;

	/** The host reference number. */
	private String hostReferenceNumber;

	/** The payment date. */
	private XMLGregorianCalendar paymentDate;

	/** The payment status. */
	private String paymentStatus;

	/** The payment description. */
	private String paymentDescription;

	/** The host status code. */
	private String hostStatusCode;

	/** The host status description. */
	private String hostStatusDescription;

	/** The Aggregator. */
	private String Aggregator;

	/** The created time. */
	private Timestamp createdTime;

	/** The created by. */
	private String createdBy;

	/** The updated time. */
	private Timestamp updatedTime;

	/** The updated by. */
	private String updatedBy;

	/** The version. */
	private Integer version;
	
	/** The retry count. */
	private String retryCount;

	private List<NarrationVO> debitNarrationVOs;
	
	private List<NarrationVO> creditNarrationVOs;
	
	/** The service name. */
	private String serviceName;
	
	/** Orange Money **/
	public Long payeeId;
	
	public Long getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}

	
	/**
	 * Gets the inward transaction info vo.
	 *
	 * @return the inwardTransactionInfoVO
	 */
	public InwardTransactionInfoVO getInwardTransactionInfoVO() {
		return inwardTransactionInfoVO;
	}

	/**
	 * Sets the inward transaction info vo.
	 *
	 * @param inwardTransactionInfoVO
	 *            the inwardTransactionInfoVO to set
	 */
	public void setInwardTransactionInfoVO(
			InwardTransactionInfoVO inwardTransactionInfoVO) {
		this.inwardTransactionInfoVO = inwardTransactionInfoVO;
	}

	/**
	 * Gets the security info vo.
	 *
	 * @return the securityInfoVO
	 */
	public SecurityInfoVO getSecurityInfoVO() {
		return securityInfoVO;
	}

	/**
	 * Sets the security info vo.
	 *
	 * @param securityInfoVO
	 *            the securityInfoVO to set
	 */
	public void setSecurityInfoVO(SecurityInfoVO securityInfoVO) {
		this.securityInfoVO = securityInfoVO;
	}

	/**
	 * Gets the sender info vo.
	 *
	 * @return the senderInfoVO
	 */
	public SenderInfoVO getSenderInfoVO() {
		return senderInfoVO;
	}

	/**
	 * Sets the sender info vo.
	 *
	 * @param senderInfoVO
	 *            the senderInfoVO to set
	 */
	public void setSenderInfoVO(SenderInfoVO senderInfoVO) {
		this.senderInfoVO = senderInfoVO;
	}

	/**
	 * Gets the client info vo.
	 *
	 * @return the clientInfoVO
	 */
	public ClientInfoVO getClientInfoVO() {
		return clientInfoVO;
	}

	/**
	 * Sets the client info vo.
	 *
	 * @param clientInfoVO
	 *            the clientInfoVO to set
	 */
	public void setClientInfoVO(ClientInfoVO clientInfoVO) {
		this.clientInfoVO = clientInfoVO;
	}

	/**
	 * Gets the reference number.
	 *
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * Sets the reference number.
	 *
	 * @param referenceNumber
	 *            the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * Gets the rel id.
	 *
	 * @return the relId
	 */
	public String getRelId() {
		return relId;
	}

	/**
	 * Sets the rel id.
	 *
	 * @param relId
	 *            the relId to set
	 */
	public void setRelId(String relId) {
		this.relId = relId;
	}

	/**
	 * Gets the host reference number.
	 *
	 * @return the hostReferenceNumber
	 */
	public String getHostReferenceNumber() {
		return hostReferenceNumber;
	}

	/**
	 * Sets the host reference number.
	 *
	 * @param hostReferenceNumber
	 *            the hostReferenceNumber to set
	 */
	public void setHostReferenceNumber(String hostReferenceNumber) {
		this.hostReferenceNumber = hostReferenceNumber;
	}

	/**
	 * @return the paymentDate
	 */
	public XMLGregorianCalendar getPaymentDate() {
		return paymentDate;
	}

	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(XMLGregorianCalendar paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * Gets the payment status.
	 *
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * Sets the payment status.
	 *
	 * @param paymentStatus
	 *            the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * Gets the payment description.
	 *
	 * @return the paymentDescription
	 */
	public String getPaymentDescription() {
		return paymentDescription;
	}

	/**
	 * Sets the payment description.
	 *
	 * @param paymentDescription            the paymentDescription to set
	 */
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	/**
	 * Gets the host status code.
	 *
	 * @return the hostStatusCode
	 */
	public String getHostStatusCode() {
		return hostStatusCode;
	}

	/**
	 * Sets the host status code.
	 *
	 * @param hostStatusCode            the hostStatusCode to set
	 */
	public void setHostStatusCode(String hostStatusCode) {
		this.hostStatusCode = hostStatusCode;
	}

	/**
	 * Gets the host status description.
	 *
	 * @return the hostStatusDescription
	 */
	public String getHostStatusDescription() {
		return hostStatusDescription;
	}

	/**
	 * Sets the host status description.
	 *
	 * @param hostStatusDescription            the hostStatusDescription to set
	 */
	public void setHostStatusDescription(String hostStatusDescription) {
		this.hostStatusDescription = hostStatusDescription;
	}

	/**
	 * Gets the aggregator.
	 *
	 * @return the aggregator
	 */
	public String getAggregator() {
		return Aggregator;
	}

	/**
	 * Sets the aggregator.
	 *
	 * @param aggregator            the aggregator to set
	 */
	public void setAggregator(String aggregator) {
		Aggregator = aggregator;
	}

	/**
	 * @return the createdTime
	 */
	public Timestamp getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedTime
	 */
	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * @return the retryCount
	 */
	public String getRetryCount() {
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(String retryCount) {
		this.retryCount = retryCount;
	}

	/**
	 * @return the debitNarrationVOs
	 */
	public List<NarrationVO> getDebitNarrationVOs() {
		return debitNarrationVOs;
	}

	/**
	 * @param debitNarrationVOs the debitNarrationVOs to set
	 */
	public void setDebitNarrationVOs(List<NarrationVO> debitNarrationVOs) {
		this.debitNarrationVOs = debitNarrationVOs;
	}

	/**
	 * @return the creditNarrationVOs
	 */
	public List<NarrationVO> getCreditNarrationVOs() {
		return creditNarrationVOs;
	}

	/**
	 * @param creditNarrationVOs the creditNarrationVOs to set
	 */
	public void setCreditNarrationVOs(List<NarrationVO> creditNarrationVOs) {
		this.creditNarrationVOs = creditNarrationVOs;
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InwardPaymentRequestVO [inwardTransactionInfoVO="
				+ inwardTransactionInfoVO + ", securityInfoVO="
				+ securityInfoVO + ", senderInfoVO=" + senderInfoVO
				+ ", clientInfoVO=" + clientInfoVO + ", referenceNumber="
				+ referenceNumber + ", relId=" + relId
				+ ", hostReferenceNumber=" + hostReferenceNumber
				+ ", paymentDate=" + paymentDate + ", paymentStatus="
				+ paymentStatus + ", paymentDescription=" + paymentDescription
				+ ", hostStatusCode=" + hostStatusCode
				+ ", hostStatusDescription=" + hostStatusDescription
				+ ", Aggregator=" + Aggregator + ", createdTime=" + createdTime
				+ ", createdBy=" + createdBy + ", updatedTime=" + updatedTime
				+ ", updatedBy=" + updatedBy + ", version=" + version
				+ ", retryCount=" + retryCount + ", debitNarrationVOs="
				+ debitNarrationVOs + ", creditNarrationVOs="
				+ creditNarrationVOs + ", serviceName=" + serviceName + "]";
	}

}
