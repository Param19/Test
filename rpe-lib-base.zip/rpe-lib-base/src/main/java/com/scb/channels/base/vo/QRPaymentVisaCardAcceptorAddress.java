package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentVisaCardAcceptorAddress implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3641776140450357572L;
	private String city;
	private String country;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "QRPaymentVisaCardAcceptorAddress [city=" + city + ", country="
				+ country + "]";
	}
	
	
}
