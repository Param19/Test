package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class DealDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6537180979020459231L;
	
	private String depositAccountNumber;
    private String depositAccountCurrencyCode;
    private String depositBranchCode;
    private String depositAmount;
    private Calendar depositTransactionEffectiveDate;
    private Calendar depositMaturityDate;
    private String rolloverIndicator;
    private String fundsAccountNumber;
    private String depositProductCode;
    private String accountProductDescription;
    private String accountProductFlag;
	
    
    public String getDepositAccountNumber() {
		return depositAccountNumber;
	}
	public void setDepositAccountNumber(String depositAccountNumber) {
		this.depositAccountNumber = depositAccountNumber;
	}
	public String getDepositAccountCurrencyCode() {
		return depositAccountCurrencyCode;
	}
	public void setDepositAccountCurrencyCode(String depositAccountCurrencyCode) {
		this.depositAccountCurrencyCode = depositAccountCurrencyCode;
	}
	public String getDepositBranchCode() {
		return depositBranchCode;
	}
	public void setDepositBranchCode(String depositBranchCode) {
		this.depositBranchCode = depositBranchCode;
	}
	public String getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	public Calendar getDepositTransactionEffectiveDate() {
		return depositTransactionEffectiveDate;
	}
	public void setDepositTransactionEffectiveDate(
			Calendar depositTransactionEffectiveDate) {
		this.depositTransactionEffectiveDate = depositTransactionEffectiveDate;
	}
	public Calendar getDepositMaturityDate() {
		return depositMaturityDate;
	}
	public void setDepositMaturityDate(Calendar depositMaturityDate) {
		this.depositMaturityDate = depositMaturityDate;
	}
	public String getRolloverIndicator() {
		return rolloverIndicator;
	}
	public void setRolloverIndicator(String rolloverIndicator) {
		this.rolloverIndicator = rolloverIndicator;
	}
	public String getFundsAccountNumber() {
		return fundsAccountNumber;
	}
	public void setFundsAccountNumber(String fundsAccountNumber) {
		this.fundsAccountNumber = fundsAccountNumber;
	}
	public String getDepositProductCode() {
		return depositProductCode;
	}
	public void setDepositProductCode(String depositProductCode) {
		this.depositProductCode = depositProductCode;
	}
	public String getAccountProductDescription() {
		return accountProductDescription;
	}
	public void setAccountProductDescription(String accountProductDescription) {
		this.accountProductDescription = accountProductDescription;
	}
	public String getAccountProductFlag() {
		return accountProductFlag;
	}
	public void setAccountProductFlag(String accountProductFlag) {
		this.accountProductFlag = accountProductFlag;
	}

}
