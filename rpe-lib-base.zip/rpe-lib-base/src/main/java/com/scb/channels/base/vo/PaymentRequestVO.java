package com.scb.channels.base.vo;

import java.io.Serializable;

public class PaymentRequestVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7683864660547612191L;
	
	private PaymentDetailVO paymentVO;

	public PaymentDetailVO getPaymentVO() {
		return paymentVO;
	}

	public void setPaymentVO(PaymentDetailVO paymentVO) {
		this.paymentVO = paymentVO;
	}
}
