package com.scb.channels.base.vo;
/**
 * The Class ServiceRequestVO.
 * @author 1272868
 */

public class ServiceRequestVO extends BaseVO {
	private static final long serialVersionUID = 6303731108081505857L;
	private String statusCd;
	private String serviceRequestType;
	private int version=0;

	private String applicationType;
	
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	public String getServiceRequestType() {
		return serviceRequestType;
	}
	public void setServiceRequestType(String serviceRequestType) {
		this.serviceRequestType = serviceRequestType;
	}
	/** The application type. */
}
