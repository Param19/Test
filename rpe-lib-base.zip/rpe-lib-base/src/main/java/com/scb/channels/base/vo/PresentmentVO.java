package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class PresentmentVO.
 */
/**
 * @author 1464157
 *
 */
/**
 * @author 1305778
 *
 */
/**
 * @author 1305778
 *
 */
public class PresentmentVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -471918614623560348L;

	/** The due date. */
	private String dueDate;
	
	/** The min amt. */
	private Double minAmt;
	
	/** The amt. */
	private double amt;
	
	/** The min amt aft due dt. */
	private Double minAmtAftDueDt;
	
	/** The amt aft due dt. */
	private double amtAftDueDt;
	
	/** The txn days bfr due dt. */
	private Integer txnDaysBfrDueDt;
					
	/** The txn days aft due dt. */
	private Integer txnDaysAftDueDt;
	
	private String invoiceNo;
	
	private String consumerNo;
	
	private String paymentDesc;
	
	private String contactTelephoneNumber;
	
	private String serviceIndicator;
	
	private String txnCurrencyCode;
	
	private String txnCount;
	
	private String txnStatusCode;
	
	private String txnStatusDesc;
	
	private String accountNo;
	private String billType;
	private String status;
	/**
	 * Gets the due date.
	 *
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}
	
	/**
	 * Sets the due date.
	 *
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	/**
	 * Gets the min amt.
	 *
	 * @return the minAmt
	 */
	public Double getMinAmt() {
		return minAmt;
	}
	
	/**
	 * Sets the min amt.
	 *
	 * @param minAmt the minAmt to set
	 */
	public void setMinAmt(Double minAmt) {
		this.minAmt = minAmt;
	}
	
	/**
	 * Gets the amt.
	 *
	 * @return the amt
	 */
	public double getAmt() {
		return amt;
	}
	
	/**
	 * Sets the amt.
	 *
	 * @param amt the amt to set
	 */
	public void setAmt(double amt) {
		this.amt = amt;
	}
	
	/**
	 * Gets the min amt aft due dt.
	 *
	 * @return the minAmtAftDueDt
	 */
	public Double getMinAmtAftDueDt() {
		return minAmtAftDueDt;
	}
	
	/**
	 * Sets the min amt aft due dt.
	 *
	 * @param minAmtAftDueDt the minAmtAftDueDt to set
	 */
	public void setMinAmtAftDueDt(Double minAmtAftDueDt) {
		this.minAmtAftDueDt = minAmtAftDueDt;
	}
	
	/**
	 * Gets the amt aft due dt.
	 *
	 * @return the amtAftDueDt
	 */
	public double getAmtAftDueDt() {
		return amtAftDueDt;
	}
	
	/**
	 * Sets the amt aft due dt.
	 *
	 * @param amtAftDueDt the amtAftDueDt to set
	 */
	public void setAmtAftDueDt(double amtAftDueDt) {
		this.amtAftDueDt = amtAftDueDt;
	}
	
	/**
	 * Gets the txn days bfr due dt.
	 *
	 * @return the txnDaysBfrDueDt
	 */
	public Integer getTxnDaysBfrDueDt() {
		return txnDaysBfrDueDt;
	}
	
	/**
	 * Sets the txn days bfr due dt.
	 *
	 * @param txnDaysBfrDueDt the txnDaysBfrDueDt to set
	 */
	public void setTxnDaysBfrDueDt(Integer txnDaysBfrDueDt) {
		this.txnDaysBfrDueDt = txnDaysBfrDueDt;
	}
	
	/**
	 * Gets the txn days aft due dt.
	 *
	 * @return the txnDaysAftDueDt
	 */
	public Integer getTxnDaysAftDueDt() {
		return txnDaysAftDueDt;
	}
	
	/**
	 * Sets the txn days aft due dt.
	 *
	 * @param txnDaysAftDueDt the txnDaysAftDueDt to set
	 */
	public void setTxnDaysAftDueDt(Integer txnDaysAftDueDt) {
		this.txnDaysAftDueDt = txnDaysAftDueDt;
	}

	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}

	/**
	 * @param invoiceNo the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	/**
	 * @return the accountNo
	 */
	public String getConsumerNo() {
		return consumerNo;
	}

	/**
	 * @param accountNo the accountNo to set
	 */
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}

	/**
	 * @return the paymentDesc
	 */
	public String getPaymentDesc() {
		return paymentDesc;
	}

	/**
	 * @param paymentDesc the paymentDesc to set
	 */
	public void setPaymentDesc(String paymentDesc) {
		this.paymentDesc = paymentDesc;
	}

	/**
	 * @return the contactTelephoneNumber
	 */
	public String getContactTelephoneNumber() {
		return contactTelephoneNumber;
	}

	/**
	 * @param contactTelephoneNumber the contactTelephoneNumber to set
	 */
	public void setContactTelephoneNumber(String contactTelephoneNumber) {
		this.contactTelephoneNumber = contactTelephoneNumber;
	}

	/**
	 * @return the serviceIndicator
	 */
	public String getServiceIndicator() {
		return serviceIndicator;
	}

	/**
	 * @param serviceIndicator the serviceIndicator to set
	 */
	public void setServiceIndicator(String serviceIndicator) {
		this.serviceIndicator = serviceIndicator;
	}

	/**
	 * @return the txnCurrencyCode
	 */
	public String getTxnCurrencyCode() {
		return txnCurrencyCode;
	}

	/**
	 * @param txnCurrencyCode the txnCurrencyCode to set
	 */
	public void setTxnCurrencyCode(String txnCurrencyCode) {
		this.txnCurrencyCode = txnCurrencyCode;
	}

	/**
	 * @return the txnCount
	 */
	public String getTxnCount() {
		return txnCount;
	}

	/**
	 * @param txnCount the txnCount to set
	 */
	public void setTxnCount(String txnCount) {
		this.txnCount = txnCount;
	}

	/**
	 * @return the txnStatusCode
	 */
	public String getTxnStatusCode() {
		return txnStatusCode;
	}

	/**
	 * @param txnStatusCode the txnStatusCode to set
	 */
	public void setTxnStatusCode(String txnStatusCode) {
		this.txnStatusCode = txnStatusCode;
	}

	/**
	 * @return the txnStatusDesc
	 */
	public String getTxnStatusDesc() {
		return txnStatusDesc;
	}

	/**
	 * @param txnStatusDesc the txnStatusDesc to set
	 */
	public void setTxnStatusDesc(String txnStatusDesc) {
		this.txnStatusDesc = txnStatusDesc;
	}

	/**
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * @return billType
	 */
	public String getBillType() {
		return billType;
	}

	
	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}
	
	/**
	 * @return status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}
