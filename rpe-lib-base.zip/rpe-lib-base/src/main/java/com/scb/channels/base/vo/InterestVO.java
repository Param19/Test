package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class InterestVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3768890112685473889L;
	
	private String interestEligibilityFlag;
    private String interestCode;
    private String interestForfeitureReason;
    private String interestCreditToSuspenseAccountFlag;
    private String interestStatementApplicablityFlag;
    private String lastConditionalInterestAppliedDate;
    private String lastExcessInterestAppliedRate;
    private String overdraftInterestCode;
    private String overdraftInterestProductCode;
    private String accountProductCode;
    private List<InterestBandVO> interestBand;
    private List<AccountCreditDebitInterestVO> accountCreditDebitInterest;
    private List<AccountInterestBandVO> accountInterestBand;
    private List<GlobalInterestBandVO> globalInterestBand;
    
    //BaseInterestRate
    private String creditInterestRate;
    private String debitInterestRate;
    private String currencyCode;
    private Calendar effectiveDate;
    private String productCode;
    private String excessInterestRate;
	
    
    public String getInterestEligibilityFlag() {
		return interestEligibilityFlag;
	}
	public void setInterestEligibilityFlag(String interestEligibilityFlag) {
		this.interestEligibilityFlag = interestEligibilityFlag;
	}
	public String getInterestCode() {
		return interestCode;
	}
	public void setInterestCode(String interestCode) {
		this.interestCode = interestCode;
	}
	public String getInterestForfeitureReason() {
		return interestForfeitureReason;
	}
	public void setInterestForfeitureReason(String interestForfeitureReason) {
		this.interestForfeitureReason = interestForfeitureReason;
	}
	public String getInterestCreditToSuspenseAccountFlag() {
		return interestCreditToSuspenseAccountFlag;
	}
	public void setInterestCreditToSuspenseAccountFlag(
			String interestCreditToSuspenseAccountFlag) {
		this.interestCreditToSuspenseAccountFlag = interestCreditToSuspenseAccountFlag;
	}
	public String getInterestStatementApplicablityFlag() {
		return interestStatementApplicablityFlag;
	}
	public void setInterestStatementApplicablityFlag(
			String interestStatementApplicablityFlag) {
		this.interestStatementApplicablityFlag = interestStatementApplicablityFlag;
	}
	public String getLastConditionalInterestAppliedDate() {
		return lastConditionalInterestAppliedDate;
	}
	public void setLastConditionalInterestAppliedDate(
			String lastConditionalInterestAppliedDate) {
		this.lastConditionalInterestAppliedDate = lastConditionalInterestAppliedDate;
	}
	public String getLastExcessInterestAppliedRate() {
		return lastExcessInterestAppliedRate;
	}
	public void setLastExcessInterestAppliedRate(
			String lastExcessInterestAppliedRate) {
		this.lastExcessInterestAppliedRate = lastExcessInterestAppliedRate;
	}
	public String getOverdraftInterestCode() {
		return overdraftInterestCode;
	}
	public void setOverdraftInterestCode(String overdraftInterestCode) {
		this.overdraftInterestCode = overdraftInterestCode;
	}
	public String getOverdraftInterestProductCode() {
		return overdraftInterestProductCode;
	}
	public void setOverdraftInterestProductCode(String overdraftInterestProductCode) {
		this.overdraftInterestProductCode = overdraftInterestProductCode;
	}
	public String getAccountProductCode() {
		return accountProductCode;
	}
	public void setAccountProductCode(String accountProductCode) {
		this.accountProductCode = accountProductCode;
	}
	public List<InterestBandVO> getInterestBand() {
		return interestBand;
	}
	public void setInterestBand(List<InterestBandVO> interestBand) {
		this.interestBand = interestBand;
	}
	public List<AccountCreditDebitInterestVO> getAccountCreditDebitInterest() {
		return accountCreditDebitInterest;
	}
	public void setAccountCreditDebitInterest(
			List<AccountCreditDebitInterestVO> accountCreditDebitInterest) {
		this.accountCreditDebitInterest = accountCreditDebitInterest;
	}
	public List<AccountInterestBandVO> getAccountInterestBand() {
		return accountInterestBand;
	}
	public void setAccountInterestBand(
			List<AccountInterestBandVO> accountInterestBand) {
		this.accountInterestBand = accountInterestBand;
	}
	public List<GlobalInterestBandVO> getGlobalInterestBand() {
		return globalInterestBand;
	}
	public void setGlobalInterestBand(List<GlobalInterestBandVO> globalInterestBand) {
		this.globalInterestBand = globalInterestBand;
	}
	public String getCreditInterestRate() {
		return creditInterestRate;
	}
	public void setCreditInterestRate(String creditInterestRate) {
		this.creditInterestRate = creditInterestRate;
	}
	public String getDebitInterestRate() {
		return debitInterestRate;
	}
	public void setDebitInterestRate(String debitInterestRate) {
		this.debitInterestRate = debitInterestRate;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public Calendar getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Calendar effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getExcessInterestRate() {
		return excessInterestRate;
	}
	public void setExcessInterestRate(String excessInterestRate) {
		this.excessInterestRate = excessInterestRate;
	}

}
