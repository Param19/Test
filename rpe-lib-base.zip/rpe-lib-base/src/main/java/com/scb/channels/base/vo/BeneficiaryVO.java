/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class BeneficiaryVO.
 *
 * @author 1464141
 */
public class BeneficiaryVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9180502743910655879L;
	
	
	/** The benfcry id. */
	private Integer benfcryId;
	
	/** The bene id. */
	private String beneId;
	
	/** The name. */
	private String name;;
	
	/** The nick name. */
	private String nickName;
	
	/** The bene type. */
	private String beneType;
	
	/** The bene status cd. */
	private String beneStatusCd;
	
	/** The address1. */
	private String address1;
	
	/** The address2. */
	private String address2;
	
	/** The address3. */
	private String address3;
	
	/** The city. */
	private String city;
	
	/** The state. */
	private String state;
	
	/** The zip code. */
	private String zipCode;
	
	/** The country. */
	private String country;
	
	/** The bank address1. */
	private String bankAddress1;
	
	/** The bank address2. */
	private String bankAddress2;
	
	/** The bank address3. */
	private String bankAddress3;
	
	/** The bank city. */
	private String bankCity;
	
	/** The bank state. */
	private String bankState;
	
	/** The bank zip code. */
	private String bankZipCode;
	
	/** The bank country. */
	private String bankCountry;
	
	/** The account number. */
	private String accountNumber;
	
	/** The universal acc number. */
	private String universalAccNumber;
	
	/** The product code. */
	private String productCode;
	
	/** The currency. */
	private String currency;
	
	/** The bank name. */
	private String bankName;
	
	/** The branch name. */
	private String branchName;
	
	/** The bank code. */
	private String bankCode;
	
	/** The branch code. */
	private String branchCode;
	
	/** The routing code. */
	private String routingCode;
	
	/** The routing type. */
	private String routingType;
	
	/** The acc type. */
	private String accType;
	
	/** The rounting info. */
	private List<RountingInfoVO> rountingInfo;
	
	/** The memo. */
	private String memo;
	
	/** The bene phone. */
	private String benePhone;
	
	/** The bene email. */
	private String beneEmail;
	private String  cardNumber;
	private String rateDeviationOverriddenFlag;
	private String approveInSufficientFundsFlag = "N";
	private String forcePostFlag = "N";
	private String suspectedTransactionFlag = "N";
	private String uniqueReferenceIdentifier;
	
	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getRateDeviationOverriddenFlag() {
		return rateDeviationOverriddenFlag;
	}

	public void setRateDeviationOverriddenFlag(String rateDeviationOverriddenFlag) {
		this.rateDeviationOverriddenFlag = rateDeviationOverriddenFlag;
	}

	public String getApproveInSufficientFundsFlag() {
		return approveInSufficientFundsFlag;
	}

	public void setApproveInSufficientFundsFlag(String approveInSufficientFundsFlag) {
		this.approveInSufficientFundsFlag = approveInSufficientFundsFlag;
	}

	public String getForcePostFlag() {
		return forcePostFlag;
	}

	public void setForcePostFlag(String forcePostFlag) {
		this.forcePostFlag = forcePostFlag;
	}

	public String getUniqueReferenceIdentifier() {
		return uniqueReferenceIdentifier;
	}

	public void setUniqueReferenceIdentifier(String uniqueReferenceIdentifier) {
		this.uniqueReferenceIdentifier = uniqueReferenceIdentifier;
	}

	/**
	 * Gets the bene id.
	 *
	 * @return the beneId
	 */
	public String getBeneId() {
		return beneId;
	}

	/**
	 * Sets the bene id.
	 *
	 * @param beneId the beneId to set
	 */
	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the nick name.
	 *
	 * @return the nickName
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * Sets the nick name.
	 *
	 * @param nickName the nickName to set
	 */
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/**
	 * Gets the bene type.
	 *
	 * @return the beneType
	 */
	public String getBeneType() {
		return beneType;
	}

	/**
	 * Sets the bene type.
	 *
	 * @param beneType the beneType to set
	 */
	public void setBeneType(String beneType) {
		this.beneType = beneType;
	}

	/**
	 * Gets the bene status cd.
	 *
	 * @return the beneStatusCd
	 */
	public String getBeneStatusCd() {
		return beneStatusCd;
	}

	/**
	 * Sets the bene status cd.
	 *
	 * @param beneStatusCd the beneStatusCd to set
	 */
	public void setBeneStatusCd(String beneStatusCd) {
		this.beneStatusCd = beneStatusCd;
	}

	/**
	 * Gets the address1.
	 *
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * Sets the address1.
	 *
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * Gets the address2.
	 *
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * Sets the address2.
	 *
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * Gets the address3.
	 *
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}

	/**
	 * Sets the address3.
	 *
	 * @param address3 the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the zip code.
	 *
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * Sets the zip code.
	 *
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the universal acc number.
	 *
	 * @return the universalAccNumber
	 */
	public String getUniversalAccNumber() {
		return universalAccNumber;
	}

	/**
	 * Sets the universal acc number.
	 *
	 * @param universalAccNumber the universalAccNumber to set
	 */
	public void setUniversalAccNumber(String universalAccNumber) {
		this.universalAccNumber = universalAccNumber;
	}

	/**
	 * Gets the product code.
	 *
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * Sets the product code.
	 *
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the bank name.
	 *
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * Sets the bank name.
	 *
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Gets the branch name.
	 *
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}

	/**
	 * Sets the branch name.
	 *
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	/**
	 * Gets the bank code.
	 *
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * Sets the bank code.
	 *
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * Gets the branch code.
	 *
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * Sets the branch code.
	 *
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * Gets the routing code.
	 *
	 * @return the routingCode
	 */
	public String getRoutingCode() {
		return routingCode;
	}

	/**
	 * Sets the routing code.
	 *
	 * @param routingCode the routingCode to set
	 */
	public void setRoutingCode(String routingCode) {
		this.routingCode = routingCode;
	}

	/**
	 * Gets the routing type.
	 *
	 * @return the routingType
	 */
	public String getRoutingType() {
		return routingType;
	}

	/**
	 * Sets the routing type.
	 *
	 * @param routingType the routingType to set
	 */
	public void setRoutingType(String routingType) {
		this.routingType = routingType;
	}

	/**
	 * Gets the acc type.
	 *
	 * @return the accType
	 */
	public String getAccType() {
		return accType;
	}

	/**
	 * Sets the acc type.
	 *
	 * @param accType the accType to set
	 */
	public void setAccType(String accType) {
		this.accType = accType;
	}

	/**
	 * Gets the memo.
	 *
	 * @return the memo
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * Sets the memo.
	 *
	 * @param memo the memo to set
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

	/**
	 * Gets the bank address1.
	 *
	 * @return the bankAddress1
	 */
	public String getBankAddress1() {
		return bankAddress1;
	}

	/**
	 * Sets the bank address1.
	 *
	 * @param bankAddress1 the bankAddress1 to set
	 */
	public void setBankAddress1(String bankAddress1) {
		this.bankAddress1 = bankAddress1;
	}

	/**
	 * Gets the bank address2.
	 *
	 * @return the bankAddress2
	 */
	public String getBankAddress2() {
		return bankAddress2;
	}

	/**
	 * Sets the bank address2.
	 *
	 * @param bankAddress2 the bankAddress2 to set
	 */
	public void setBankAddress2(String bankAddress2) {
		this.bankAddress2 = bankAddress2;
	}

	/**
	 * Gets the bank address3.
	 *
	 * @return the bankAddress3
	 */
	public String getBankAddress3() {
		return bankAddress3;
	}

	/**
	 * Sets the bank address3.
	 *
	 * @param bankAddress3 the bankAddress3 to set
	 */
	public void setBankAddress3(String bankAddress3) {
		this.bankAddress3 = bankAddress3;
	}

	/**
	 * Gets the bank city.
	 *
	 * @return the bankCity
	 */
	public String getBankCity() {
		return bankCity;
	}

	/**
	 * Sets the bank city.
	 *
	 * @param bankCity the bankCity to set
	 */
	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}

	/**
	 * Gets the bank state.
	 *
	 * @return the bankState
	 */
	public String getBankState() {
		return bankState;
	}

	/**
	 * Sets the bank state.
	 *
	 * @param bankState the bankState to set
	 */
	public void setBankState(String bankState) {
		this.bankState = bankState;
	}

	/**
	 * Gets the bank zip code.
	 *
	 * @return the bankZipCode
	 */
	public String getBankZipCode() {
		return bankZipCode;
	}

	/**
	 * Sets the bank zip code.
	 *
	 * @param bankZipCode the bankZipCode to set
	 */
	public void setBankZipCode(String bankZipCode) {
		this.bankZipCode = bankZipCode;
	}

	/**
	 * Gets the bank country.
	 *
	 * @return the bankCountry
	 */
	public String getBankCountry() {
		return bankCountry;
	}

	/**
	 * Sets the bank country.
	 *
	 * @param bankCountry the bankCountry to set
	 */
	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}

	/**
	 * Gets the rounting info.
	 *
	 * @return the rountingInfo
	 */
	public List<RountingInfoVO> getRountingInfo() {
		return rountingInfo;
	}

	/**
	 * Sets the rounting info.
	 *
	 * @param rountingInfo the rountingInfo to set
	 */
	public void setRountingInfo(List<RountingInfoVO> rountingInfo) {
		this.rountingInfo = rountingInfo;
	}

	/**
	 * Gets the benfcry id.
	 *
	 * @return the benfcryId
	 */
	public Integer getBenfcryId() {
		return benfcryId;
	}

	/**
	 * Sets the benfcry id.
	 *
	 * @param benfcryId the benfcryId to set
	 */
	public void setBenfcryId(Integer benfcryId) {
		this.benfcryId = benfcryId;
	}

	/**
	 * Gets the bene phone.
	 *
	 * @return the benePhone
	 */
	public String getBenePhone() {
		return benePhone;
	}

	/**
	 * Sets the bene phone.
	 *
	 * @param benePhone the benePhone to set
	 */
	public void setBenePhone(String benePhone) {
		this.benePhone = benePhone;
	}

	/**
	 * Gets the bene email.
	 *
	 * @return the beneEmail
	 */
	public String getBeneEmail() {
		return beneEmail;
	}

	/**
	 * Sets the bene email.
	 *
	 * @param beneEmail the beneEmail to set
	 */
	public void setBeneEmail(String beneEmail) {
		this.beneEmail = beneEmail;
	}

	/**
	 * @return the suspectedTransactionFlag
	 */
	public String getSuspectedTransactionFlag() {
		return suspectedTransactionFlag;
	}

	/**
	 * @param suspectedTransactionFlag the suspectedTransactionFlag to set
	 */
	public void setSuspectedTransactionFlag(String suspectedTransactionFlag) {
		this.suspectedTransactionFlag = suspectedTransactionFlag;
	}
	
	

}
