package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerListRequestVO.
 */
public class BillerListRequestVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4434006636186262503L;
	
	/** The biller cd. */
	private String billerCd;
	
	/** The biller desc. */
	private String billerDesc;
	
	/** The utility cd. */
	private String utilityCd;
	
	/** The utillty type desc. */
	private String utilltyTypeDesc;
	
	/** The consumer no. */
	private String consumerNo;
	
	/** The consumer desc. */
	private String consumerDesc;
	
	/**
	 * Gets the biller cd.
	 *
	 * @return the billerCd
	 */
	public String getBillerCd() {
		return billerCd;
	}
	
	/**
	 * Sets the biller cd.
	 *
	 * @param billerCd the billerCd to set
	 */
	public void setBillerCd(String billerCd) {
		this.billerCd = billerCd;
	}
	
	/**
	 * Gets the biller desc.
	 *
	 * @return the billerDesc
	 */
	public String getBillerDesc() {
		return billerDesc;
	}
	
	/**
	 * Sets the biller desc.
	 *
	 * @param billerDesc the billerDesc to set
	 */
	public void setBillerDesc(String billerDesc) {
		this.billerDesc = billerDesc;
	}
	
	/**
	 * Gets the utility cd.
	 *
	 * @return the utilityCd
	 */
	public String getUtilityCd() {
		return utilityCd;
	}
	
	/**
	 * Sets the utility cd.
	 *
	 * @param utilityCd the utilityCd to set
	 */
	public void setUtilityCd(String utilityCd) {
		this.utilityCd = utilityCd;
	}
	
	/**
	 * Gets the utillty type desc.
	 *
	 * @return the utilltyTypeDesc
	 */
	public String getUtilltyTypeDesc() {
		return utilltyTypeDesc;
	}
	
	/**
	 * Sets the utillty type desc.
	 *
	 * @param utilltyTypeDesc the utilltyTypeDesc to set
	 */
	public void setUtilltyTypeDesc(String utilltyTypeDesc) {
		this.utilltyTypeDesc = utilltyTypeDesc;
	}
	
	/**
	 * Gets the consumer no.
	 *
	 * @return the consumerNo
	 */
	public String getConsumerNo() {
		return consumerNo;
	}
	
	/**
	 * Sets the consumer no.
	 *
	 * @param consumerNo the consumerNo to set
	 */
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}
	
	/**
	 * Gets the consumer desc.
	 *
	 * @return the consumerDesc
	 */
	public String getConsumerDesc() {
		return consumerDesc;
	}
	
	/**
	 * Sets the consumer desc.
	 *
	 * @param consumerDesc the consumerDesc to set
	 */
	public void setConsumerDesc(String consumerDesc) {
		this.consumerDesc = consumerDesc;
	}

}
 