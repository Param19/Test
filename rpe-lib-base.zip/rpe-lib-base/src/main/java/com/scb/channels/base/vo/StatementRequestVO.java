/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Date;

/**
 * @author 1464143
 *
 */
public class StatementRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3016562681373796041L;

	private String applicationType;
	private String deliveryMode;
	private String statusCd;
	private String accountNo;
	private Date fromDate;
	private Date toDate;
	
	/** The version. */
	private int version=0;
	
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getDeliveryMode() {
		return deliveryMode;
	}
	public void setDeliveryMode(String deliveryMode) {
		this.deliveryMode = deliveryMode;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
}
