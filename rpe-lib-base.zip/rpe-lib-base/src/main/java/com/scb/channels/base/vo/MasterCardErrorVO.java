package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

public class MasterCardErrorVO implements Serializable{

		private static final long serialVersionUID = 6956895935823585312L;
	 	private String transactionId;
	    private String source;
	    private String reasonCode;
	    private String description;
	    private String recoverable;
	    private List<MasterCardErrorDetailsVO> details;
	    
	
		public String getSource() {
			return source;
		}
		public void setSource(String source) {
			this.source = source;
		}
		public String getReasonCode() {
			return reasonCode;
		}
		public void setReasonCode(String reasonCode) {
			this.reasonCode = reasonCode;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getRecoverable() {
			return recoverable;
		}
		public void setRecoverable(String recoverable) {
			this.recoverable = recoverable;
		}
		public List<MasterCardErrorDetailsVO> getDetails() {
			return details;
		}
		public void setDetails(List<MasterCardErrorDetailsVO> details) {
			this.details = details;
		}
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
}
