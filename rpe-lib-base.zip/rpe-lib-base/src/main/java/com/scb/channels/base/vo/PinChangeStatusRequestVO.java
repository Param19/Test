package com.scb.channels.base.vo;

import java.util.Date;

public class PinChangeStatusRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1773106398630222359L;
	
	/** The auth. */
	private String auth;
	
	/** The auth vo. */
	private AuthVO authVO;
	
	/** The status cd. */
	private String statusCd;
	
	/** The date login. */
	private Date dateLogin;
	
	/** The created by. */
	private String createdBy;
	
	/** The version. */
	private int version;

	
	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public AuthVO getAuthVO() {
		return authVO;
	}

	public void setAuthVO(AuthVO authVO) {
		this.authVO = authVO;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public Date getDateLogin() {
		return dateLogin;
	}

	public void setDateLogin(Date dateLogin) {
		this.dateLogin = dateLogin;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}
