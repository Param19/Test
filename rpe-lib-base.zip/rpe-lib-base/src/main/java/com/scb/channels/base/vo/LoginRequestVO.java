/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Date;

/**
 * The Class LoginRequestVO.
 *
 * @author 1411807
 */
public class LoginRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7361092921466801613L;

	/** The auth. */
	private String auth;
	
	/** The auth vo. */
	private AuthVO authVO;
	
	/** The mobile operator code. */
	private String mobileOperatorCode;
	
	/** The mobile network id. */
	private String mobileNetworkId;

	/** The handset lost. */
	private String handsetLost;
	
	/** The status cd. */
	private String statusCd;
	
	/** The date login. */
	private Date dateLogin;
	
	/** The created by. */
	private String createdBy;
	
	/** The version. */
	private int version;
	
	/**
	 * Gets the auth.
	 *
	 * @return the auth
	 */
	public String getAuth() {
		return auth;
	}

	/**
	 * Sets the auth.
	 *
	 * @param auth the auth to set
	 */
	public void setAuth(String auth) {
		this.auth = auth;
	}

	/**
	 * Gets the auth vo.
	 *
	 * @return the authVO
	 */
	public AuthVO getAuthVO() {
		return authVO;
	}

	/**
	 * Sets the auth vo.
	 *
	 * @param authVO the authVO to set
	 */
	public void setAuthVO(AuthVO authVO) {
		this.authVO = authVO;
	}

	/**
	 * Gets the mobile operator code.
	 *
	 * @return the mobileOperatorCode
	 */
	public String getMobileOperatorCode() {
		return mobileOperatorCode;
	}

	/**
	 * Sets the mobile operator code.
	 *
	 * @param mobileOperatorCode the mobileOperatorCode to set
	 */
	public void setMobileOperatorCode(String mobileOperatorCode) {
		this.mobileOperatorCode = mobileOperatorCode;
	}

	/**
	 * Gets the mobile network id.
	 *
	 * @return the mobileNetworkId
	 */
	public String getMobileNetworkId() {
		return mobileNetworkId;
	}

	/**
	 * Sets the mobile network id.
	 *
	 * @param mobileNetworkId the mobileNetworkId to set
	 */
	public void setMobileNetworkId(String mobileNetworkId) {
		this.mobileNetworkId = mobileNetworkId;
	}

	/**
	 * Gets the handset lost.
	 *
	 * @return the handsetLost
	 */
	public String getHandsetLost() {
		return handsetLost;
	}

	/**
	 * Sets the handset lost.
	 *
	 * @param handsetLost the handsetLost to set
	 */
	public void setHandsetLost(String handsetLost) {
		this.handsetLost = handsetLost;
	}

	/**
	 * Gets the status cd.
	 *
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}


	/**
	 * Gets the date login.
	 *
	 * @return the dateLogin
	 */
	public Date getDateLogin() {
		return dateLogin;
	}

	/**
	 * Sets the date login.
	 *
	 * @param dateLogin the dateLogin to set
	 */
	public void setDateLogin(Date dateLogin) {
		this.dateLogin = dateLogin;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	
}
