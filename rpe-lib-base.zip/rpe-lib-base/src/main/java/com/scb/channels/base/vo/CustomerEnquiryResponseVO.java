/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class CustomerEnquiryResponseVO.
 *
 * @author 1411807
 */
public class CustomerEnquiryResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8852716746644447393L;

	CustomerDetailsVO customerDetailsVO;
	
	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;

	public CustomerDetailsVO getCustomerDetailsVO() {
		return customerDetailsVO;
	}

	public void setCustomerDetailsVO(CustomerDetailsVO customerDetailsVO) {
		this.customerDetailsVO = customerDetailsVO;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}
