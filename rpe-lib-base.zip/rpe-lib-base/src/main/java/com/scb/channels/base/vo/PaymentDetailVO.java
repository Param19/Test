package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Set;
 
/**
 * The Class PaymentDetailVO.
 */
public class PaymentDetailVO implements Serializable,Cloneable{
	
	/**
	 *** The Constant serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;
	
	public Long id ;  
	public Long payeeId;
	public PayeeDetailVO payee;
	public String countryCode; 
	public String channel; 
	public String referenceNumber; 
	public String currency; 
	public BigDecimal paymentAmount ;    
	public BigDecimal fees; 
	public BigDecimal totalAmount;   
	public Timestamp paymentDate;   
	public String paymentType;     
	public String paymentStatus;    
	public String paymentDescription;   
	public Timestamp processedDate;   
	public String   hostReferenceNumber;   
	public String hostStatusCode;    
	public String hostStatusDescription;   
	public Timestamp settlementDate;   
	public String reasonCode ;  
	public Timestamp createdTime ;   
	public String createdBy;   
	public Timestamp updatedTime;   
	public String updatedBy;   
	public Integer version;     
	public String toAccountNumber;   
	public String sourceAccountNumber ;   
	public String customerId;
	private String paymentOption;
	private String staffFlag;
	private String aggregatorReference;
	private  Set<PaymentFieldDetails> paymentFieldDetails;
	private String authCode; // added for CR659
	private String stan; //added for CR659
	private String retrievalReferenceNumber;// added for CR659
	private String paymentSubType; // added for CR659
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}
	public PayeeDetailVO getPayee() {
		return payee;
	}
	public void setPayee(PayeeDetailVO payee) {
		this.payee = payee;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Timestamp getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getPaymentDescription() {
		return paymentDescription;
	}
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}
	public Timestamp getProcessedDate() {
		return processedDate;
	}
	public void setProcessedDate(Timestamp processedDate) {
		this.processedDate = processedDate;
	}
	public String getHostReferenceNumber() {
		return hostReferenceNumber;
	}
	public void setHostReferenceNumber(String hostReferenceNumber) {
		this.hostReferenceNumber = hostReferenceNumber;
	}
	public String getHostStatusCode() {
		return hostStatusCode;
	}
	public void setHostStatusCode(String hostStatusCode) {
		this.hostStatusCode = hostStatusCode;
	}
	public String getHostStatusDescription() {
		return hostStatusDescription;
	}
	public void setHostStatusDescription(String hostStatusDescription) {
		if(hostStatusDescription != null && hostStatusDescription.length() > 245){
			hostStatusDescription = hostStatusDescription.substring(0, 245);
		}
		this.hostStatusDescription = hostStatusDescription;
	}
	public Timestamp getSettlementDate() {
		return settlementDate;
	}
	public void setSettlementDate(Timestamp settlementDate) {
		this.settlementDate = settlementDate;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public Timestamp getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getUpdatedTime() {
		return updatedTime;
	}
	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getToAccountNumber() {
		return toAccountNumber;
	}
	public void setToAccountNumber(String toAccountNumber) {
		this.toAccountNumber = toAccountNumber;
	}
	public String getSourceAccountNumber() {
		return sourceAccountNumber;
	}
	public void setSourceAccountNumber(String sourceAccountNumber) {
		this.sourceAccountNumber = sourceAccountNumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getPaymentOption() {
		return paymentOption;
	}
	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public BigDecimal getFees() {
		return fees;
	}
	public void setFees(BigDecimal fees) {
		this.fees = fees;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getStaffFlag() {
		return staffFlag;
	}
	public void setStaffFlag(String staffFlag) {
		this.staffFlag = staffFlag;
	}
	public String getAggregatorReference() {
		return aggregatorReference;
	}
	public void setAggregatorReference(String aggregatorReference) {
		this.aggregatorReference = aggregatorReference;
	}
	/**
	 * @return the paymentFieldDetails
	 */
	public Set<PaymentFieldDetails> getPaymentFieldDetails() {
		return paymentFieldDetails;
	}
	/**
	 * @param paymentFieldDetails the paymentFieldDetails to set
	 */
	public void setPaymentFieldDetails(Set<PaymentFieldDetails> paymentFieldDetails) {
		this.paymentFieldDetails = paymentFieldDetails;
	}
	
	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public String getStan() {
		return stan;
	}
	public void setStan(String stan) {
		this.stan = stan;
	}
	public String getRetrievalReferenceNumber() {
		return retrievalReferenceNumber;
	}
	public void setRetrievalReferenceNumber(String retrievalReferenceNumber) {
		this.retrievalReferenceNumber = retrievalReferenceNumber;
	}
	public String getPaymentSubType() {
		return paymentSubType;
	}
	public void setPaymentSubType(String paymentSubType) {
		this.paymentSubType = paymentSubType;
	}
	/*@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PaymentDetailVO [id=");
		builder.append(id);
		builder.append(", payeeId=");
		builder.append(payeeId);
		builder.append(", payee=");
		builder.append(payee);
		builder.append(", countryCode=");
		builder.append(countryCode);
		builder.append(", channel=");
		builder.append(channel);
		builder.append(", referenceNumber=");
		builder.append(referenceNumber);
		builder.append(", currency=");
		builder.append(currency);
		builder.append(", paymentAmount=");
		builder.append(paymentAmount);
		builder.append(", fees=");
		builder.append(fees);
		builder.append(", totalAmount=");
		builder.append(totalAmount);
		builder.append(", paymentDate=");
		builder.append(paymentDate);
		builder.append(", paymentType=");
		builder.append(paymentType);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", paymentDescription=");
		builder.append(paymentDescription);
		builder.append(", processedDate=");
		builder.append(processedDate);
		builder.append(", hostReferenceNumber=");
		builder.append(hostReferenceNumber);
		builder.append(", hostStatusCode=");
		builder.append(hostStatusCode);
		builder.append(", hostStatusDescription=");
		builder.append(hostStatusDescription);
		builder.append(", settlementDate=");
		builder.append(settlementDate);
		builder.append(", reasonCode=");
		builder.append(reasonCode);
		builder.append(", createdTime=");
		builder.append(createdTime);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", updatedTime=");
		builder.append(updatedTime);
		builder.append(", updatedBy=");
		builder.append(updatedBy);
		builder.append(", version=");
		builder.append(version);
		builder.append(", toAccountNumber=");
		builder.append(toAccountNumber);
		builder.append(", sourceAccountNumber=");
		builder.append(sourceAccountNumber);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", paymentOption=");
		builder.append(paymentOption);
		builder.append(", staffFlag=");
		builder.append(staffFlag);
		builder.append(", aggregatorReference=");
		builder.append(aggregatorReference);
		builder.append(", paymentFieldDetails=");
		builder.append(paymentFieldDetails);
		builder.append(", authCode=");
		builder.append(authCode);
		builder.append(", stan=");
		builder.append(stan);
		builder.append(", retrievalReferenceNumber=");
		builder.append(retrievalReferenceNumber);
		builder.append(", paymentSubType=");
		builder.append(paymentSubType);
		builder.append("]");
		return builder.toString();
	}*/
	
	
}
