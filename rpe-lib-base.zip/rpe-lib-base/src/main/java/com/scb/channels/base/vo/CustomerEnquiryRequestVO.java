/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class CustomerEnquiryRequestVO.
 *
 * @author 1411807
 */
public class CustomerEnquiryRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3979707107615251220L;



}
