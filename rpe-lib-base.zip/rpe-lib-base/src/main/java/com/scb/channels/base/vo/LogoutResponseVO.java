/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Calendar;
import java.util.List;

/**
 * The Class LogoutResponseVO.
 *
 * @author 1411807
 */
public class LogoutResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7063747890527412796L;
	
	/** The login time. */
	private Calendar loginTime;

	/** The logout time. */
	private Calendar logoutTime;
	
	/** The status cd. */
	private String statusCd;
	
	/** The value code. */
	private String valueCode;

	/** The user nav history. */
	private List<UserNavigationHistoryVO> userNavHistory;

	/** The user txn history. */
	private List<UserTxnHistoryVO> userTxnHistory;

	/**
	 * Gets the login time.
	 *
	 * @return the loginTime
	 */
	public Calendar getLoginTime() {
		return loginTime;
	}

	/**
	 * Sets the login time.
	 *
	 * @param loginTime the loginTime to set
	 */
	public void setLoginTime(Calendar loginTime) {
		this.loginTime = loginTime;
	}

	/**
	 * Gets the logout time.
	 *
	 * @return the logoutTime
	 */
	public Calendar getLogoutTime() {
		return logoutTime;
	}

	/**
	 * Sets the logout time.
	 *
	 * @param logoutTime the logoutTime to set
	 */
	public void setLogoutTime(Calendar logoutTime) {
		this.logoutTime = logoutTime;
	}

	/**
	 * Gets the user nav history.
	 *
	 * @return the userNavHistory
	 */
	public List<UserNavigationHistoryVO> getUserNavHistory() {
		return userNavHistory;
	}

	/**
	 * Sets the user nav history.
	 *
	 * @param userNavHistory the userNavHistory to set
	 */
	public void setUserNavHistory(List<UserNavigationHistoryVO> userNavHistory) {
		this.userNavHistory = userNavHistory;
	}

	/**
	 * Gets the user txn history.
	 *
	 * @return the userTxnHistory
	 */
	public List<UserTxnHistoryVO> getUserTxnHistory() {
		return userTxnHistory;
	}

	/**
	 * Sets the user txn history.
	 *
	 * @param userTxnHistory the userTxnHistory to set
	 */
	public void setUserTxnHistory(List<UserTxnHistoryVO> userTxnHistory) {
		this.userTxnHistory = userTxnHistory;
	}

	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	/**
	 * Gets the value code.
	 *
	 * @return the value code
	 */
	public String getValueCode() {
		return valueCode;
	}

	/**
	 * Sets the value code.
	 *
	 * @param valueCode the new value code
	 */
	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}
    
	
}
