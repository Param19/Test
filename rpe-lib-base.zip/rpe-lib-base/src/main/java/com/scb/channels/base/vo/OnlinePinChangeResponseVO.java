/**
 * 
 */
package com.scb.channels.base.vo;


/**
 * @author 1411807
 *
 */
public class OnlinePinChangeResponseVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1054048227139719592L;
	
}
