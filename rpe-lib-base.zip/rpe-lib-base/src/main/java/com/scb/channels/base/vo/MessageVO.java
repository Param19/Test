package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class MessageVO.
 */
public class MessageVO implements Serializable,Cloneable {
	
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1674044322494800945L;
	
	/** The req id. */
	private String reqID;
	
	/** The request code. */
	private String requestCode;
	
	/** The request type. */
	private String requestType;
	
	/** The correlation id. */
	private String correlationId;
	
	/** The request in time. */
	private Date requestInTime;
	
	/** The request out time. */
	private Date requestOutTime;
	
	/**
	 * Gets the req id.
	 *
	 * @return the reqID
	 */
	public String getReqID() {
		return reqID;
	}
	
	/**
	 * Sets the req id.
	 *
	 * @param reqID the reqID to set
	 */
	public void setReqID(String reqID) {
		this.reqID = reqID;
	}
	
	/**
	 * Gets the request code.
	 *
	 * @return the requestCode
	 */
	public String getRequestCode() {
		return requestCode;
	}
	
	/**
	 * Sets the request code.
	 *
	 * @param requestCode the requestCode to set
	 */
	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}
	
	/**
	 * Gets the request type.
	 *
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	/**
	 * Gets the correlation id.
	 *
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}
	
	/**
	 * Sets the correlation id.
	 *
	 * @param correlationId the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/**
	 * Gets the request in time.
	 *
	 * @return the requestInTime
	 */
	public Date getRequestInTime() {
		return requestInTime;
	}

	/**
	 * Sets the request in time.
	 *
	 * @param requestInTime the requestInTime to set
	 */
	public void setRequestInTime(Date requestInTime) {
		this.requestInTime = requestInTime;
	}

	/**
	 * Gets the request out time.
	 *
	 * @return the requestOutTime
	 */
	public Date getRequestOutTime() {
		return requestOutTime;
	}

	/**
	 * Sets the request out time.
	 *
	 * @param requestOutTime the requestOutTime to set
	 */
	public void setRequestOutTime(Date requestOutTime) {
		this.requestOutTime = requestOutTime;
	}

}
