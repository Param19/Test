package com.scb.channels.base.vo;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class QRPaymentInfoVO.
 */
public class QRPaymentInfoVO implements Serializable, Cloneable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3794577077395666738L;
	
	/** The card number. */
	private String cardNumber;
	
	/** The payment date. */
	private String paymentDate;
	
	/** The payment originate country. */
	private String paymentOriginateCountry;
	
	/** The account number. */
	private String accountNumber;
	
	/** The account currency. */
	private String accountCurrency;
	
	/** The transaction currency. */
	private String transactionCurrency;
	
	/** The card emboss name. */
	private String cardEmbossName;
	
	/** The source of fund. */
	private String sourceOfFund;
	
	/** The payment amount. */
	private String paymentAmount;
	
	/** The payment remarks. */
	private String paymentRemarks;
	
	/** The transaction reference number. */
	private String transactionReferenceNumber;
	
		
	/**
	 * Gets the card number.
	 *
	 * @return the card number
	 */
	public String getCardNumber() {
		return cardNumber;
	}


	/**
	 * Sets the card number.
	 *
	 * @param cardNumber the new card number
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}


	/**
	 * Gets the payment date.
	 *
	 * @return the payment date
	 */
	public String getPaymentDate() {
		return paymentDate;
	}


	/**
	 * Sets the payment date.
	 *
	 * @param paymentDate the new payment date
	 */
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}


	/**
	 * Gets the payment originate country.
	 *
	 * @return the payment originate country
	 */
	public String getPaymentOriginateCountry() {
		return paymentOriginateCountry;
	}


	/**
	 * Sets the payment originate country.
	 *
	 * @param paymentOriginateCountry the new payment originate country
	 */
	public void setPaymentOriginateCountry(String paymentOriginateCountry) {
		this.paymentOriginateCountry = paymentOriginateCountry;
	}


	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}


	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	/**
	 * Gets the account currency.
	 *
	 * @return the account currency
	 */
	public String getAccountCurrency() {
		return accountCurrency;
	}


	/**
	 * Sets the account currency.
	 *
	 * @param accountCurrency the new account currency
	 */
	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}


	/**
	 * Gets the transaction currency.
	 *
	 * @return the transaction currency
	 */
	public String getTransactionCurrency() {
		return transactionCurrency;
	}


	/**
	 * Sets the transaction currency.
	 *
	 * @param transactionCurrency the new transaction currency
	 */
	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}


	/**
	 * Gets the card emboss name.
	 *
	 * @return the card emboss name
	 */
	public String getCardEmbossName() {
		return cardEmbossName;
	}


	/**
	 * Sets the card emboss name.
	 *
	 * @param cardEmbossName the new card emboss name
	 */
	public void setCardEmbossName(String cardEmbossName) {
		this.cardEmbossName = cardEmbossName;
	}


	/**
	 * Gets the source of fund.
	 *
	 * @return the source of fund
	 */
	public String getSourceOfFund() {
		return sourceOfFund;
	}


	/**
	 * Sets the source of fund.
	 *
	 * @param sourceOfFund the new source of fund
	 */
	public void setSourceOfFund(String sourceOfFund) {
		this.sourceOfFund = sourceOfFund;
	}


	/**
	 * Gets the payment amount.
	 *
	 * @return the payment amount
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}


	/**
	 * Sets the payment amount.
	 *
	 * @param paymentAmount the new payment amount
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}


	/**
	 * Gets the payment remarks.
	 *
	 * @return the payment remarks
	 */
	public String getPaymentRemarks() {
		return paymentRemarks;
	}


	/**
	 * Sets the payment remarks.
	 *
	 * @param paymentRemarks the new payment remarks
	 */
	public void setPaymentRemarks(String paymentRemarks) {
		this.paymentRemarks = paymentRemarks;
	}


	/**
	 * Gets the transaction reference number.
	 *
	 * @return the transaction reference number
	 */
	public String getTransactionReferenceNumber() {
		return transactionReferenceNumber;
	}


	/**
	 * Sets the transaction reference number.
	 *
	 * @param transactionReferenceNumber the new transaction reference number
	 */
	public void setTransactionReferenceNumber(String transactionReferenceNumber) {
		this.transactionReferenceNumber = transactionReferenceNumber;
	}


	@Override
	public String toString() {
		return "QRPaymentInfoVO [cardNumber=" + cardNumber + ", paymentDate="
				+ paymentDate + ", paymentOriginateCountry="
				+ paymentOriginateCountry + ", accountNumber=" + accountNumber
				+ ", accountCurrency=" + accountCurrency
				+ ", transactionCurrency=" + transactionCurrency
				+ ", cardEmbossName=" + cardEmbossName + ", sourceOfFund="
				+ sourceOfFund + ", paymentAmount=" + paymentAmount
				+ ", paymentRemarks=" + paymentRemarks
				+ ", transactionReferenceNumber=" + transactionReferenceNumber
				+ "]";
	}


	
}
