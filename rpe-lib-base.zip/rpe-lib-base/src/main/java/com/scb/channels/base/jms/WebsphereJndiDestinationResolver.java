package com.scb.channels.base.jms;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Session;

import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.JndiDestinationResolver;

import com.ibm.mq.jms.JMSC;
import com.ibm.mq.jms.MQDestination;

public class WebsphereJndiDestinationResolver extends JndiDestinationResolver implements DestinationResolver {

	public static final String TARGET_CLIENT_1 = "?targetClient=1";
	public static final String QUEUE = "queue:///";
	
	private int ccsid = 819;
    private int encoding = JMSC.MQJMS_ENCODING_INTEGER_NORMAL;
    private int failIfQuiesce = JMSC.MQJMS_FIQ_YES;
    private int targetClient = JMSC.MQJMS_CLIENT_NONJMS_MQ;

	@Override
	public Destination resolveDestinationName(Session session,
			String destinationName, boolean pubSubDomain) throws JMSException {
		 Destination destination = super.resolveDestinationName( session, destinationName, pubSubDomain );
	        if ( destination instanceof MQDestination )
	        {
	            MQDestination mqDestination = (MQDestination) destination;
	            mqDestination.setCCSID( getCcsid() );
	            mqDestination.setEncoding( JMSC.MQJMS_ENCODING_INTEGER_NORMAL );
	            mqDestination.setFailIfQuiesce( getFailIfQuiesce() );
	            mqDestination.setTargetClient( JMSC.MQJMS_CLIENT_NONJMS_MQ );
	        }
	        
	        return destination;
	}

	/**
	 * @return the ccsid
	 */
	public int getCcsid() {
		return ccsid;
	}

	/**
	 * @param ccsid the ccsid to set
	 */
	public void setCcsid(int ccsid) {
		this.ccsid = ccsid;
	}

	/**
	 * @return the encoding
	 */
	public int getEncoding() {
		return encoding;
	}

	/**
	 * @param encoding the encoding to set
	 */
	public void setEncoding(int encoding) {
		this.encoding = encoding;
	}

	/**
	 * @return the failIfQuiesce
	 */
	public int getFailIfQuiesce() {
		return failIfQuiesce;
	}

	/**
	 * @param failIfQuiesce the failIfQuiesce to set
	 */
	public void setFailIfQuiesce(int failIfQuiesce) {
		this.failIfQuiesce = failIfQuiesce;
	}

	/**
	 * @return the targetClient
	 */
	public int getTargetClient() {
		return targetClient;
	}

	/**
	 * @param targetClient the targetClient to set
	 */
	public void setTargetClient(int targetClient) {
		this.targetClient = targetClient;
	}

}
