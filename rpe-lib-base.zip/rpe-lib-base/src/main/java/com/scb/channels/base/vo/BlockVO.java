package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class BlockVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5027902557897962501L;
	private boolean defaultForModify=false;
	private String blockNumber;
    private Calendar blockSetDate;
    private String blockType;
    private String blockRelease;
    private String accountChargeCode;
    private String actualDebitAmount;
    private String debitAmountReleasedFromBlock;
    private Calendar accountBlockExpiryDate;
    private String blockAmountInstructionNumber;
    private String limitMasterNumber;
    private String limitNumber;
    private String accountLimitBlockIndicator;
    private String makerID;
    private Calendar makerDate;
    private String checkerID;
    private Calendar checkerDate;
    private String deleteBlockOnExpiry;
    private Calendar blockEffectiveExecutionDate;
    private Calendar blockBatchEntryDate;
    private String blockBatchNumber;
    private String blockEntryChannelNumber;
    private String blockEntryTransactionBranch;
    private String blockStatusFlag;
    private String sweepBlockReferenceNumber;
    private String blockAmountPendingForRelease;
    
    //CreditAccount
    private String creditCurrencyCode;
    private String creditAccountNumber;
    
    //DebitAccount
    private String debitCurrencyCode;
    private String debitAccountNumber;
    
    private List<CreditNarrativeVO> creditNarrative;
    private List<DebitNarrativeVO> debitNarrative;
	private String creditTransactionCode;
	private String debitTransactionCode;
	private String operationMode;
	private String productCode;
	private String blockPartialFlag;
	private String externalSystemID;
	private String externalSystemReferenceNumber;
	private String blockActionOnExpiryFlag;
	private String blockAmount;
    
    public String getBlockNumber() {
		return blockNumber;
	}
	public void setBlockNumber(String blockNumber) {
		this.blockNumber = blockNumber;
	}
	public Calendar getBlockSetDate() {
		return blockSetDate;
	}
	public void setBlockSetDate(Calendar blockSetDate) {
		this.blockSetDate = blockSetDate;
	}
	public String getBlockType() {
		return blockType;
	}
	public void setBlockType(String blockType) {
		this.blockType = blockType;
	}
	public String getBlockRelease() {
		return blockRelease;
	}
	public void setBlockRelease(String blockRelease) {
		this.blockRelease = blockRelease;
	}
	public String getAccountChargeCode() {
		return accountChargeCode;
	}
	public void setAccountChargeCode(String accountChargeCode) {
		this.accountChargeCode = accountChargeCode;
	}
	public String getActualDebitAmount() {
		return actualDebitAmount;
	}
	public void setActualDebitAmount(String actualDebitAmount) {
		this.actualDebitAmount = actualDebitAmount;
	}
	public String getDebitAmountReleasedFromBlock() {
		return debitAmountReleasedFromBlock;
	}
	public void setDebitAmountReleasedFromBlock(String debitAmountReleasedFromBlock) {
		this.debitAmountReleasedFromBlock = debitAmountReleasedFromBlock;
	}
	public Calendar getAccountBlockExpiryDate() {
		return accountBlockExpiryDate;
	}
	public void setAccountBlockExpiryDate(Calendar accountBlockExpiryDate) {
		this.accountBlockExpiryDate = accountBlockExpiryDate;
	}
	public String getBlockAmountInstructionNumber() {
		return blockAmountInstructionNumber;
	}
	public void setBlockAmountInstructionNumber(String blockAmountInstructionNumber) {
		this.blockAmountInstructionNumber = blockAmountInstructionNumber;
	}
	public String getLimitMasterNumber() {
		return limitMasterNumber;
	}
	public void setLimitMasterNumber(String limitMasterNumber) {
		this.limitMasterNumber = limitMasterNumber;
	}
	public String getLimitNumber() {
		return limitNumber;
	}
	public void setLimitNumber(String limitNumber) {
		this.limitNumber = limitNumber;
	}
	public String getAccountLimitBlockIndicator() {
		return accountLimitBlockIndicator;
	}
	public void setAccountLimitBlockIndicator(String accountLimitBlockIndicator) {
		this.accountLimitBlockIndicator = accountLimitBlockIndicator;
	}
	public String getMakerID() {
		return makerID;
	}
	public void setMakerID(String makerID) {
		this.makerID = makerID;
	}
	public Calendar getMakerDate() {
		return makerDate;
	}
	public void setMakerDate(Calendar makerDate) {
		this.makerDate = makerDate;
	}
	public String getCheckerID() {
		return checkerID;
	}
	public void setCheckerID(String checkerID) {
		this.checkerID = checkerID;
	}
	public Calendar getCheckerDate() {
		return checkerDate;
	}
	public void setCheckerDate(Calendar checkerDate) {
		this.checkerDate = checkerDate;
	}
	public String getDeleteBlockOnExpiry() {
		return deleteBlockOnExpiry;
	}
	public void setDeleteBlockOnExpiry(String deleteBlockOnExpiry) {
		this.deleteBlockOnExpiry = deleteBlockOnExpiry;
	}
	public Calendar getBlockEffectiveExecutionDate() {
		return blockEffectiveExecutionDate;
	}
	public void setBlockEffectiveExecutionDate(Calendar blockEffectiveExecutionDate) {
		this.blockEffectiveExecutionDate = blockEffectiveExecutionDate;
	}
	public Calendar getBlockBatchEntryDate() {
		return blockBatchEntryDate;
	}
	public void setBlockBatchEntryDate(Calendar blockBatchEntryDate) {
		this.blockBatchEntryDate = blockBatchEntryDate;
	}
	public String getBlockBatchNumber() {
		return blockBatchNumber;
	}
	public void setBlockBatchNumber(String blockBatchNumber) {
		this.blockBatchNumber = blockBatchNumber;
	}
	public String getBlockEntryChannelNumber() {
		return blockEntryChannelNumber;
	}
	public void setBlockEntryChannelNumber(String blockEntryChannelNumber) {
		this.blockEntryChannelNumber = blockEntryChannelNumber;
	}
	public String getBlockEntryTransactionBranch() {
		return blockEntryTransactionBranch;
	}
	public void setBlockEntryTransactionBranch(String blockEntryTransactionBranch) {
		this.blockEntryTransactionBranch = blockEntryTransactionBranch;
	}
	public String getBlockStatusFlag() {
		return blockStatusFlag;
	}
	public void setBlockStatusFlag(String blockStatusFlag) {
		this.blockStatusFlag = blockStatusFlag;
	}
	public String getSweepBlockReferenceNumber() {
		return sweepBlockReferenceNumber;
	}
	public void setSweepBlockReferenceNumber(String sweepBlockReferenceNumber) {
		this.sweepBlockReferenceNumber = sweepBlockReferenceNumber;
	}
	public String getBlockAmountPendingForRelease() {
		return blockAmountPendingForRelease;
	}
	public void setBlockAmountPendingForRelease(String blockAmountPendingForRelease) {
		this.blockAmountPendingForRelease = blockAmountPendingForRelease;
	}
	public String getCreditCurrencyCode() {
		return creditCurrencyCode;
	}
	public void setCreditCurrencyCode(String creditCurrencyCode) {
		this.creditCurrencyCode = creditCurrencyCode;
	}
	public String getCreditAccountNumber() {
		return creditAccountNumber;
	}
	public void setCreditAccountNumber(String creditAccountNumber) {
		this.creditAccountNumber = creditAccountNumber;
	}
	public String getDebitCurrencyCode() {
		return debitCurrencyCode;
	}
	public void setDebitCurrencyCode(String debitCurrencyCode) {
		this.debitCurrencyCode = debitCurrencyCode;
	}
	public String getDebitAccountNumber() {
		return debitAccountNumber;
	}
	public void setDebitAccountNumber(String debitAccountNumber) {
		this.debitAccountNumber = debitAccountNumber;
	}
	public List<CreditNarrativeVO> getCreditNarrative() {
		return creditNarrative;
	}
	public void setCreditNarrative(List<CreditNarrativeVO> creditNarrative) {
		this.creditNarrative = creditNarrative;
	}
	public List<DebitNarrativeVO> getDebitNarrative() {
		return debitNarrative;
	}
	public void setDebitNarrative(List<DebitNarrativeVO> debitNarrative) {
		this.debitNarrative = debitNarrative;
	}
	public String getCreditTransactionCode() {
		return creditTransactionCode;
	}
	public void setCreditTransactionCode(String creditTransactionCode) {
		this.creditTransactionCode = creditTransactionCode;
	}
	public String getDebitTransactionCode() {
		return debitTransactionCode;
	}
	public void setDebitTransactionCode(String debitTransactionCode) {
		this.debitTransactionCode = debitTransactionCode;
	}
	public String getOperationMode() {
		return operationMode;
	}
	public void setOperationMode(String operationMode) {
		this.operationMode = operationMode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getBlockPartialFlag() {
		return blockPartialFlag;
	}
	public void setBlockPartialFlag(String blockPartialFlag) {
		this.blockPartialFlag = blockPartialFlag;
	}
	public String getExternalSystemID() {
		return externalSystemID;
	}
	public void setExternalSystemID(String externalSystemID) {
		this.externalSystemID = externalSystemID;
	}
	public String getExternalSystemReferenceNumber() {
		return externalSystemReferenceNumber;
	}
	public void setExternalSystemReferenceNumber(
			String externalSystemReferenceNumber) {
		this.externalSystemReferenceNumber = externalSystemReferenceNumber;
	}
	public String getBlockActionOnExpiryFlag() {
		return blockActionOnExpiryFlag;
	}
	public void setBlockActionOnExpiryFlag(String blockActionOnExpiryFlag) {
		this.blockActionOnExpiryFlag = blockActionOnExpiryFlag;
	}
	public String getBlockAmount() {
		return blockAmount;
	}
	public void setBlockAmount(String blockAmount) {
		this.blockAmount = blockAmount;
	}
	/**
	 * @return the defaultForModify
	 */
	public boolean isDefaultForModify() {
		return defaultForModify;
	}
	/**
	 * @param defaultForModify the defaultForModify to set
	 */
	public void setDefaultForModify(boolean defaultForModify) {
		this.defaultForModify = defaultForModify;
	}
}
