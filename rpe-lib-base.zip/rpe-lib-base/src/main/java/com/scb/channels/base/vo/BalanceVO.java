package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class BalanceVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3159720114973905046L;
	
	private String accountLienOrLimitAmount;
    private String limitOrLienIndicator;
    private Calendar reagingDate;
    private String customerInterestBalance;
    private String earmarkedCreditBalance;
    private String earmarkedDebitBalance;
    private String forwardCreditAmount;
    private String forwardDebitAmount;
    private String ledgerBalance;
    private String availableBalanceAtCloseOfBusiness;
    private String availableBalanceWithLimit;
    private String availableBalanceWithoutLimit;
    private String availableBalanceWithIntradayLimit;
    private String availableLimitAmount;
    private String availableBalanceWithDrawnOnUnclearedEffects;
    private String availableBalanceWithCloseOfDay;
    private String totalUnclearedAmount;
	
    
    public String getAccountLienOrLimitAmount() {
		return accountLienOrLimitAmount;
	}
	public void setAccountLienOrLimitAmount(String accountLienOrLimitAmount) {
		this.accountLienOrLimitAmount = accountLienOrLimitAmount;
	}
	public String getLimitOrLienIndicator() {
		return limitOrLienIndicator;
	}
	public void setLimitOrLienIndicator(String limitOrLienIndicator) {
		this.limitOrLienIndicator = limitOrLienIndicator;
	}
	public Calendar getReagingDate() {
		return reagingDate;
	}
	public void setReagingDate(Calendar reagingDate) {
		this.reagingDate = reagingDate;
	}
	public String getCustomerInterestBalance() {
		return customerInterestBalance;
	}
	public void setCustomerInterestBalance(String customerInterestBalance) {
		this.customerInterestBalance = customerInterestBalance;
	}
	public String getEarmarkedCreditBalance() {
		return earmarkedCreditBalance;
	}
	public void setEarmarkedCreditBalance(String earmarkedCreditBalance) {
		this.earmarkedCreditBalance = earmarkedCreditBalance;
	}
	public String getEarmarkedDebitBalance() {
		return earmarkedDebitBalance;
	}
	public void setEarmarkedDebitBalance(String earmarkedDebitBalance) {
		this.earmarkedDebitBalance = earmarkedDebitBalance;
	}
	public String getForwardCreditAmount() {
		return forwardCreditAmount;
	}
	public void setForwardCreditAmount(String forwardCreditAmount) {
		this.forwardCreditAmount = forwardCreditAmount;
	}
	public String getForwardDebitAmount() {
		return forwardDebitAmount;
	}
	public void setForwardDebitAmount(String forwardDebitAmount) {
		this.forwardDebitAmount = forwardDebitAmount;
	}
	public String getLedgerBalance() {
		return ledgerBalance;
	}
	public void setLedgerBalance(String ledgerBalance) {
		this.ledgerBalance = ledgerBalance;
	}
	public String getAvailableBalanceAtCloseOfBusiness() {
		return availableBalanceAtCloseOfBusiness;
	}
	public void setAvailableBalanceAtCloseOfBusiness(
			String availableBalanceAtCloseOfBusiness) {
		this.availableBalanceAtCloseOfBusiness = availableBalanceAtCloseOfBusiness;
	}
	public String getAvailableBalanceWithLimit() {
		return availableBalanceWithLimit;
	}
	public void setAvailableBalanceWithLimit(String availableBalanceWithLimit) {
		this.availableBalanceWithLimit = availableBalanceWithLimit;
	}
	public String getAvailableBalanceWithoutLimit() {
		return availableBalanceWithoutLimit;
	}
	public void setAvailableBalanceWithoutLimit(String availableBalanceWithoutLimit) {
		this.availableBalanceWithoutLimit = availableBalanceWithoutLimit;
	}
	public String getAvailableBalanceWithIntradayLimit() {
		return availableBalanceWithIntradayLimit;
	}
	public void setAvailableBalanceWithIntradayLimit(
			String availableBalanceWithIntradayLimit) {
		this.availableBalanceWithIntradayLimit = availableBalanceWithIntradayLimit;
	}
	public String getAvailableLimitAmount() {
		return availableLimitAmount;
	}
	public void setAvailableLimitAmount(String availableLimitAmount) {
		this.availableLimitAmount = availableLimitAmount;
	}
	public String getAvailableBalanceWithDrawnOnUnclearedEffects() {
		return availableBalanceWithDrawnOnUnclearedEffects;
	}
	public void setAvailableBalanceWithDrawnOnUnclearedEffects(
			String availableBalanceWithDrawnOnUnclearedEffects) {
		this.availableBalanceWithDrawnOnUnclearedEffects = availableBalanceWithDrawnOnUnclearedEffects;
	}
	public String getAvailableBalanceWithCloseOfDay() {
		return availableBalanceWithCloseOfDay;
	}
	public void setAvailableBalanceWithCloseOfDay(
			String availableBalanceWithCloseOfDay) {
		this.availableBalanceWithCloseOfDay = availableBalanceWithCloseOfDay;
	}
	public String getTotalUnclearedAmount() {
		return totalUnclearedAmount;
	}
	public void setTotalUnclearedAmount(String totalUnclearedAmount) {
		this.totalUnclearedAmount = totalUnclearedAmount;
	}

}
