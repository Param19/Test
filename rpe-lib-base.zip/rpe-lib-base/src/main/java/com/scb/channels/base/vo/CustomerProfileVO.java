/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class CustomerProfileVO.
 *
 * @author 1411807
 */
public class CustomerProfileVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5154809310276089005L;
	
	/** The id. */
	private Integer id;
	
	/** The user id. */
	private String userId;
	
	/** The system type. */
	private String systemType;
	
	/** The status cd. */
	private String statusCd;
	
	/** The role cd. */
	private String roleCd;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The cust group id. */
	private String custGroupId;
	
	/** The cust id type. */
	private String custIdType;
	
	/** The cust id. */
	private String custId;
	
	/** The cust name1. */
	private String custName1;
	
	/** The cust name2. */
	private String custName2;
	
	/** The nickname. */
	private String nickname;
	
	/** The email. */
	private String email;
	
	/** The mobile phone. */
	private String mobilePhone;
	
	/** The segment cd. */
	private String segmentCd;
	
	/** The dt reg. */
	private Date dtReg;
	
	/** The reg by. */
	private String regBy;
	
	/** The re reg. */
	private String reReg;
	
	/** The letter gen. */
	private String letterGen;
	
	/** The act. */
	private String act;
	
	/** The reg mode. */
	private String regMode;
	
	/** The notif type. */
	private String notifType;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The email gen. */
	private String emailGen;
	
	/** The handset lost. */
	private String handsetLost;
	
	/** The operating account currency. */
	private String operatingAccountCurrency;
	
	/** The operating account no. */
	private String operatingAccountNo;
	
	/** The sms alert enabled. */
	private String smsAlertEnabled;
	
	/** The services enabled. */
	private String servicesEnabled;
	
	/** The email alert enabled. */
	private String emailAlertEnabled;
	
	/** The email generation type. */
	private String emailGenerationType;
	
	/** The mobile operator code. */
	private String mobileOperatorCode;
	
	/** The mobile network id. */
	private String mobileNetworkId;
	
	/** The migrate flag. */
	private String migrateFlag;
	
	/** The login invalid count. */
	private Integer loginInvalidCount;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the system type.
	 *
	 * @return the systemType
	 */
	public String getSystemType() {
		return systemType;
	}
	
	/**
	 * Sets the system type.
	 *
	 * @param systemType the systemType to set
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the role cd.
	 *
	 * @return the roleCd
	 */
	public String getRoleCd() {
		return roleCd;
	}
	
	/**
	 * Sets the role cd.
	 *
	 * @param roleCd the roleCd to set
	 */
	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the cust group id.
	 *
	 * @return the custGroupId
	 */
	public String getCustGroupId() {
		return custGroupId;
	}
	
	/**
	 * Sets the cust group id.
	 *
	 * @param custGroupId the custGroupId to set
	 */
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	
	/**
	 * Gets the cust id type.
	 *
	 * @return the custIdType
	 */
	public String getCustIdType() {
		return custIdType;
	}
	
	/**
	 * Sets the cust id type.
	 *
	 * @param custIdType the custIdType to set
	 */
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	/**
	 * Gets the cust name1.
	 *
	 * @return the custName1
	 */
	public String getCustName1() {
		return custName1;
	}
	
	/**
	 * Sets the cust name1.
	 *
	 * @param custName1 the custName1 to set
	 */
	public void setCustName1(String custName1) {
		this.custName1 = custName1;
	}
	
	/**
	 * Gets the cust name2.
	 *
	 * @return the custName2
	 */
	public String getCustName2() {
		return custName2;
	}
	
	/**
	 * Sets the cust name2.
	 *
	 * @param custName2 the custName2 to set
	 */
	public void setCustName2(String custName2) {
		this.custName2 = custName2;
	}
	
	/**
	 * Gets the nickname.
	 *
	 * @return the nickname
	 */
	public String getNickname() {
		return nickname;
	}
	
	/**
	 * Sets the nickname.
	 *
	 * @param nickname the nickname to set
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Gets the mobile phone.
	 *
	 * @return the mobilePhone
	 */
	public String getMobilePhone() {
		return mobilePhone;
	}
	
	/**
	 * Sets the mobile phone.
	 *
	 * @param mobilePhone the mobilePhone to set
	 */
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	
	/**
	 * Gets the segment cd.
	 *
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	
	/**
	 * Sets the segment cd.
	 *
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	
	/**
	 * Gets the dt reg.
	 *
	 * @return the dtReg
	 */
	public Date getDtReg() {
		return dtReg;
	}
	
	/**
	 * Sets the dt reg.
	 *
	 * @param dtReg the dtReg to set
	 */
	public void setDtReg(Date dtReg) {
		this.dtReg = dtReg;
	}
	
	/**
	 * Gets the reg by.
	 *
	 * @return the regBy
	 */
	public String getRegBy() {
		return regBy;
	}
	
	/**
	 * Sets the reg by.
	 *
	 * @param regBy the regBy to set
	 */
	public void setRegBy(String regBy) {
		this.regBy = regBy;
	}
	
	/**
	 * Gets the re reg.
	 *
	 * @return the reReg
	 */
	public String getReReg() {
		return reReg;
	}
	
	/**
	 * Sets the re reg.
	 *
	 * @param reReg the reReg to set
	 */
	public void setReReg(String reReg) {
		this.reReg = reReg;
	}
	
	/**
	 * Gets the letter gen.
	 *
	 * @return the letterGen
	 */
	public String getLetterGen() {
		return letterGen;
	}
	
	/**
	 * Sets the letter gen.
	 *
	 * @param letterGen the letterGen to set
	 */
	public void setLetterGen(String letterGen) {
		this.letterGen = letterGen;
	}
	
	/**
	 * Gets the act.
	 *
	 * @return the act
	 */
	public String getAct() {
		return act;
	}
	
	/**
	 * Sets the act.
	 *
	 * @param act the act to set
	 */
	public void setAct(String act) {
		this.act = act;
	}
	
	/**
	 * Gets the reg mode.
	 *
	 * @return the regMode
	 */
	public String getRegMode() {
		return regMode;
	}
	
	/**
	 * Sets the reg mode.
	 *
	 * @param regMode the regMode to set
	 */
	public void setRegMode(String regMode) {
		this.regMode = regMode;
	}
	
	/**
	 * Gets the notif type.
	 *
	 * @return the notifType
	 */
	public String getNotifType() {
		return notifType;
	}
	
	/**
	 * Sets the notif type.
	 *
	 * @param notifType the notifType to set
	 */
	public void setNotifType(String notifType) {
		this.notifType = notifType;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dtCreated
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the dtCreated to set
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dtUpd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the dtUpd to set
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the updBy
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the updBy to set
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the email gen.
	 *
	 * @return the emailGen
	 */
	public String getEmailGen() {
		return emailGen;
	}
	
	/**
	 * Sets the email gen.
	 *
	 * @param emailGen the emailGen to set
	 */
	public void setEmailGen(String emailGen) {
		this.emailGen = emailGen;
	}
	
	/**
	 * Gets the handset lost.
	 *
	 * @return the handsetLost
	 */
	public String getHandsetLost() {
		return handsetLost;
	}
	
	/**
	 * Sets the handset lost.
	 *
	 * @param handsetLost the handsetLost to set
	 */
	public void setHandsetLost(String handsetLost) {
		this.handsetLost = handsetLost;
	}
	
	/**
	 * Gets the operating account currency.
	 *
	 * @return the operatingAccountCurrency
	 */
	public String getOperatingAccountCurrency() {
		return operatingAccountCurrency;
	}
	
	/**
	 * Sets the operating account currency.
	 *
	 * @param operatingAccountCurrency the operatingAccountCurrency to set
	 */
	public void setOperatingAccountCurrency(String operatingAccountCurrency) {
		this.operatingAccountCurrency = operatingAccountCurrency;
	}
	
	/**
	 * Gets the operating account no.
	 *
	 * @return the operatingAccountNo
	 */
	public String getOperatingAccountNo() {
		return operatingAccountNo;
	}
	
	/**
	 * Sets the operating account no.
	 *
	 * @param operatingAccountNo the operatingAccountNo to set
	 */
	public void setOperatingAccountNo(String operatingAccountNo) {
		this.operatingAccountNo = operatingAccountNo;
	}
	
	/**
	 * Gets the sms alert enabled.
	 *
	 * @return the smsAlertEnabled
	 */
	public String getSmsAlertEnabled() {
		return smsAlertEnabled;
	}
	
	/**
	 * Sets the sms alert enabled.
	 *
	 * @param smsAlertEnabled the smsAlertEnabled to set
	 */
	public void setSmsAlertEnabled(String smsAlertEnabled) {
		this.smsAlertEnabled = smsAlertEnabled;
	}
	
	/**
	 * Gets the services enabled.
	 *
	 * @return the servicesEnabled
	 */
	public String getServicesEnabled() {
		return servicesEnabled;
	}
	
	/**
	 * Sets the services enabled.
	 *
	 * @param servicesEnabled the servicesEnabled to set
	 */
	public void setServicesEnabled(String servicesEnabled) {
		this.servicesEnabled = servicesEnabled;
	}
	
	/**
	 * Gets the email alert enabled.
	 *
	 * @return the emailAlertEnabled
	 */
	public String getEmailAlertEnabled() {
		return emailAlertEnabled;
	}
	
	/**
	 * Sets the email alert enabled.
	 *
	 * @param emailAlertEnabled the emailAlertEnabled to set
	 */
	public void setEmailAlertEnabled(String emailAlertEnabled) {
		this.emailAlertEnabled = emailAlertEnabled;
	}
	
	/**
	 * Gets the email generation type.
	 *
	 * @return the emailGenerationType
	 */
	public String getEmailGenerationType() {
		return emailGenerationType;
	}
	
	/**
	 * Sets the email generation type.
	 *
	 * @param emailGenerationType the emailGenerationType to set
	 */
	public void setEmailGenerationType(String emailGenerationType) {
		this.emailGenerationType = emailGenerationType;
	}
	
	/**
	 * Gets the mobile operator code.
	 *
	 * @return the mobileOperatorCode
	 */
	public String getMobileOperatorCode() {
		return mobileOperatorCode;
	}
	
	/**
	 * Sets the mobile operator code.
	 *
	 * @param mobileOperatorCode the mobileOperatorCode to set
	 */
	public void setMobileOperatorCode(String mobileOperatorCode) {
		this.mobileOperatorCode = mobileOperatorCode;
	}
	
	/**
	 * Gets the mobile network id.
	 *
	 * @return the mobileNetworkId
	 */
	public String getMobileNetworkId() {
		return mobileNetworkId;
	}
	
	/**
	 * Sets the mobile network id.
	 *
	 * @param mobileNetworkId the mobileNetworkId to set
	 */
	public void setMobileNetworkId(String mobileNetworkId) {
		this.mobileNetworkId = mobileNetworkId;
	}

	/**
	 * Gets the migrate flag.
	 *
	 * @return the migrateFlag
	 */
	public String getMigrateFlag() {
		return migrateFlag;
	}

	/**
	 * Sets the migrate flag.
	 *
	 * @param migrateFlag the migrateFlag to set
	 */
	public void setMigrateFlag(String migrateFlag) {
		this.migrateFlag = migrateFlag;
	}
	
	/**
	 * Gets the Login Invalid count
	 * @return loginInvalidCount
	 */
	public Integer getLoginInvalidCount() {
		return loginInvalidCount;
	}

	/**
	 * sets the login invalid count
	 * @param loginInvalidCount
	 */
	public void setLoginInvalidCount(Integer loginInvalidCount) {
		this.loginInvalidCount = loginInvalidCount;
	}
	

}
