package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class HostResponseTypeVO.
 *
 * @author 1493439
 */
public class HostResponseApiVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 000111L;
	
	/** The code. */
	private String code;
	
	/** The desc. */
	private String desc;
	
	/** The host name. */
	private String hostName;
	
	/** The host reference. */
	private String hostReference;

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * @param hostName the hostName to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * @return the hostReference
	 */
	public String getHostReference() {
		return hostReference;
	}

	/**
	 * @param hostReference the hostReference to set
	 */
	public void setHostReference(String hostReference) {
		this.hostReference = hostReference;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HostResponseApiVO [code=" + code + ", desc=" + desc
				+ ", hostName=" + hostName + ", hostReference=" + hostReference
				+ "]";
	}

}
