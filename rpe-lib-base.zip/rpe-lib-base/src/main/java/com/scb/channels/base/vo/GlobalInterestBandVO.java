package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class GlobalInterestBandVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7093840132967099189L;

	private Calendar effectiveDate;
    private String bandRateApplicablePeriod;
    private String bandOffset;
    private String creditDebitExcessFlag;
    private String productCode;
    private String bandRateTerm;
	
    
    public Calendar getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Calendar effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getBandRateApplicablePeriod() {
		return bandRateApplicablePeriod;
	}
	public void setBandRateApplicablePeriod(String bandRateApplicablePeriod) {
		this.bandRateApplicablePeriod = bandRateApplicablePeriod;
	}
	public String getBandOffset() {
		return bandOffset;
	}
	public void setBandOffset(String bandOffset) {
		this.bandOffset = bandOffset;
	}
	public String getCreditDebitExcessFlag() {
		return creditDebitExcessFlag;
	}
	public void setCreditDebitExcessFlag(String creditDebitExcessFlag) {
		this.creditDebitExcessFlag = creditDebitExcessFlag;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getBandRateTerm() {
		return bandRateTerm;
	}
	public void setBandRateTerm(String bandRateTerm) {
		this.bandRateTerm = bandRateTerm;
	}
}
