package com.scb.channels.base.vo;

import java.io.Serializable;

public class AddressDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2043533713003593131L;
	
	private String addressLanguageIndicator;
    private String addressLanguageCode;
    private String addressTypeCode;
    private String addressLine1;
    private String addressLine2;
    private String additionalAddressLine1;
    private String additionalAddressLine2;
    private String additionalAddressLine3;
    private String additionalAddressLine4;
    private String cityName;
    private String cityCode;
    private String postBox;
    private String mailingAddressIndicator;
    private String postalCode;
    private String locationCode;
    private String stateofResidence;
    private String countryCode;
    private String attentionParty;
    private String whereaboutsUnknownFlag;
	
    
    public String getAddressLanguageIndicator() {
		return addressLanguageIndicator;
	}
	public void setAddressLanguageIndicator(String addressLanguageIndicator) {
		this.addressLanguageIndicator = addressLanguageIndicator;
	}
	public String getAddressLanguageCode() {
		return addressLanguageCode;
	}
	public void setAddressLanguageCode(String addressLanguageCode) {
		this.addressLanguageCode = addressLanguageCode;
	}
	public String getAddressTypeCode() {
		return addressTypeCode;
	}
	public void setAddressTypeCode(String addressTypeCode) {
		this.addressTypeCode = addressTypeCode;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAdditionalAddressLine1() {
		return additionalAddressLine1;
	}
	public void setAdditionalAddressLine1(String additionalAddressLine1) {
		this.additionalAddressLine1 = additionalAddressLine1;
	}
	public String getAdditionalAddressLine2() {
		return additionalAddressLine2;
	}
	public void setAdditionalAddressLine2(String additionalAddressLine2) {
		this.additionalAddressLine2 = additionalAddressLine2;
	}
	public String getAdditionalAddressLine3() {
		return additionalAddressLine3;
	}
	public void setAdditionalAddressLine3(String additionalAddressLine3) {
		this.additionalAddressLine3 = additionalAddressLine3;
	}
	public String getAdditionalAddressLine4() {
		return additionalAddressLine4;
	}
	public void setAdditionalAddressLine4(String additionalAddressLine4) {
		this.additionalAddressLine4 = additionalAddressLine4;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getPostBox() {
		return postBox;
	}
	public void setPostBox(String postBox) {
		this.postBox = postBox;
	}
	public String getMailingAddressIndicator() {
		return mailingAddressIndicator;
	}
	public void setMailingAddressIndicator(String mailingAddressIndicator) {
		this.mailingAddressIndicator = mailingAddressIndicator;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getStateofResidence() {
		return stateofResidence;
	}
	public void setStateofResidence(String stateofResidence) {
		this.stateofResidence = stateofResidence;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAttentionParty() {
		return attentionParty;
	}
	public void setAttentionParty(String attentionParty) {
		this.attentionParty = attentionParty;
	}
	public String getWhereaboutsUnknownFlag() {
		return whereaboutsUnknownFlag;
	}
	public void setWhereaboutsUnknownFlag(String whereaboutsUnknownFlag) {
		this.whereaboutsUnknownFlag = whereaboutsUnknownFlag;
	}

}
