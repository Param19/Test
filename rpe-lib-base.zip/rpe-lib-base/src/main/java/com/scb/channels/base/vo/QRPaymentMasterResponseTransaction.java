package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterResponseTransaction {
	
	private String Type;
	
	private String SystemTraceAuditNumber;
	
	private String NetworkReferenceNumber;
	
	private String SettlementDate;
	
	private QRPaymentMasterResponseField Response; 
	
	private String SubmitDateTime;

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getSystemTraceAuditNumber() {
		return SystemTraceAuditNumber;
	}

	public void setSystemTraceAuditNumber(String systemTraceAuditNumber) {
		SystemTraceAuditNumber = systemTraceAuditNumber;
	}

	public String getNetworkReferenceNumber() {
		return NetworkReferenceNumber;
	}

	public void setNetworkReferenceNumber(String networkReferenceNumber) {
		NetworkReferenceNumber = networkReferenceNumber;
	}

	public String getSettlementDate() {
		return SettlementDate;
	}

	public void setSettlementDate(String settlementDate) {
		SettlementDate = settlementDate;
	}

	public QRPaymentMasterResponseField getResponse() {
		return Response;
	}

	public void setResponse(QRPaymentMasterResponseField response) {
		Response = response;
	}

	public String getSubmitDateTime() {
		return SubmitDateTime;
	}

	public void setSubmitDateTime(String submitDateTime) {
		SubmitDateTime = submitDateTime;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterResponseTransaction [Type=" + Type
				+ ", SystemTraceAuditNumber=" + SystemTraceAuditNumber
				+ ", NetworkReferenceNumber=" + NetworkReferenceNumber
				+ ", SettlementDate=" + SettlementDate + ", Response="
				+ Response + ", SubmitDateTime=" + SubmitDateTime + "]";
	}
	
	

}
