package com.scb.channels.base.vo;



/**
 * The Class StopChequeRequestVO.
 */
public class StopChequeRequestVO extends BaseVO 
{
	
	public static final String _007 = "007";

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3847390963058083213L;
	
	/** The application type. */
	private String applicationType;
	
	/** The status cd. */
	private String statusCd;	
    
    /** The account no. */
    private String accountNo;
    
    /** The cheque no. */
    private String chequeNO;
    
    private String currency;
    
    private String amount;
    
    private String reasonCode = _007;
    
    private String reasonDescription;
    
    private int version;
    
	/**
	 * Gets the application type.
	 *
	 * @return the application type
	 */
	public String getApplicationType() {
		return applicationType;
	}
	
	/**
	 * Sets the application type.
	 *
	 * @param applicationType the new application type
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the account no.
	 *
	 * @return the account no
	 */
	public String getAccountNo() {
		return accountNo;
	}
	
	/**
	 * Sets the account no.
	 *
	 * @param accountNo the new account no
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	/**
	 * Gets the cheque no.
	 *
	 * @return the cheque no
	 */
	public String getChequeNO() {
		return chequeNO;
	}
	
	/**
	 * Sets the cheque no.
	 *
	 * @param chequeNO the new cheque no
	 */
	public void setChequeNO(String chequeNO) {
		this.chequeNO = chequeNO;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the reasonCode
	 */
	public String getReasonCode() {
		return reasonCode;
	}

	/**
	 * @param reasonCode the reasonCode to set
	 */
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	/**
	 * @return the reasonDescription
	 */
	public String getReasonDescription() {
		return reasonDescription;
	}

	/**
	 * @param reasonDescription the reasonDescription to set
	 */
	public void setReasonDescription(String reasonDescription) {
		this.reasonDescription = reasonDescription;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
    
}
