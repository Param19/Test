package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class BillerPayResponseVO.
 */
public class ViewPayeeResponseVO extends BaseVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * 
	 */
	List<PayeeDetailVO> listPayeeDetailVO;
	
	/**
	 * 
	 */
	List<ViewPayeeVO> listViewPayeeVO;

	/**
	 * @return the listPayeeDetailVO
	 */
	public List<PayeeDetailVO> getListPayeeDetailVO() {
		return listPayeeDetailVO;
	}

	/**
	 * @param listPayeeDetailVO the listPayeeDetailVO to set
	 */
	public void setListPayeeDetailVO(List<PayeeDetailVO> listPayeeDetailVO) {
		this.listPayeeDetailVO = listPayeeDetailVO;
	}

	/**
	 * @return the listViewPayeeVO
	 */
	public List<ViewPayeeVO> getListViewPayeeVO() {
		return listViewPayeeVO;
	}

	/**
	 * @param listViewPayeeVO the listViewPayeeVO to set
	 */
	public void setListViewPayeeVO(List<ViewPayeeVO> listViewPayeeVO) {
		this.listViewPayeeVO = listViewPayeeVO;
	}
	/**
	 * 
	 */
	List<ViewPayeeHKVO> listViewPayeeHKVO;


	/**
	 * @return the listViewPayeeHKVO
	 */
	public List<ViewPayeeHKVO> getListViewPayeeHKVO() {
		return listViewPayeeHKVO;
	}

	/**
	 * @param listViewPayeeHKVO the listViewPayeeHKVO to set
	 */
	public void setListViewPayeeHKVO(List<ViewPayeeHKVO> listViewPayeeHKVO) {
		this.listViewPayeeHKVO = listViewPayeeHKVO;
	}


		
}
