package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class QRDataVO.
 */
public class QRDataVO implements Serializable, Cloneable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3495137028432077650L;
	
	/** The qr payload version. */
	private String qrPayloadVersion;
	
	/** The merchant category code. */
	private String merchantCategoryCode;
	
	/** The txn currency code. */
	private String txnCurrencyCode;
	
	/** The txn amount. */
	private String txnAmount;
	
	/** The country code. */
	private String countryCode;
	
	/** The merchant name. */
	private String merchantName;
	
	/** The merchant city. */
	private String merchantCity;
	
	/** The postal code. */
	private String postalCode;
	
	/** The additional field. */
	private String additionalField;
	
	/** The point of initiation. */
	private String pointOfInitiation;
	
	/** The tip or convenience fee. */
	private String tipOrConvenienceFee;

	/** The merchant pan. */
	private List<QRMerchantPanTypeVO> merchantPan = new ArrayList<QRMerchantPanTypeVO>();

	/**
	 * Gets the qr payload version.
	 *
	 * @return the qr payload version
	 */
	public String getQrPayloadVersion() {
		return qrPayloadVersion;
	}

	/**
	 * Sets the qr payload version.
	 *
	 * @param qrPayloadVersion the new qr payload version
	 */
	public void setQrPayloadVersion(String qrPayloadVersion) {
		this.qrPayloadVersion = qrPayloadVersion;
	}

	/**
	 * Gets the merchant category code.
	 *
	 * @return the merchant category code
	 */
	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}

	/**
	 * Sets the merchant category code.
	 *
	 * @param merchantCategoryCode the new merchant category code
	 */
	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}

	/**
	 * Gets the txn currency code.
	 *
	 * @return the txn currency code
	 */
	public String getTxnCurrencyCode() {
		return txnCurrencyCode;
	}

	/**
	 * Sets the txn currency code.
	 *
	 * @param txnCurrencyCode the new txn currency code
	 */
	public void setTxnCurrencyCode(String txnCurrencyCode) {
		this.txnCurrencyCode = txnCurrencyCode;
	}

	/**
	 * Gets the txn amount.
	 *
	 * @return the txn amount
	 */
	public String getTxnAmount() {
		return txnAmount;
	}

	/**
	 * Sets the txn amount.
	 *
	 * @param txnAmount the new txn amount
	 */
	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}

	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * Sets the country code.
	 *
	 * @param countryCode the new country code
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * Gets the merchant name.
	 *
	 * @return the merchant name
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * Sets the merchant name.
	 *
	 * @param merchantName the new merchant name
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	/**
	 * Gets the merchant city.
	 *
	 * @return the merchant city
	 */
	public String getMerchantCity() {
		return merchantCity;
	}

	/**
	 * Sets the merchant city.
	 *
	 * @param merchantCity the new merchant city
	 */
	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}

	/**
	 * Gets the postal code.
	 *
	 * @return the postal code
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code.
	 *
	 * @param postalCode the new postal code
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the additional field.
	 *
	 * @return the additional field
	 */
	public String getAdditionalField() {
		return additionalField;
	}

	/**
	 * Sets the additional field.
	 *
	 * @param additionalField the new additional field
	 */
	public void setAdditionalField(String additionalField) {
		this.additionalField = additionalField;
	}

	/**
	 * Gets the point of initiation.
	 *
	 * @return the point of initiation
	 */
	public String getPointOfInitiation() {
		return pointOfInitiation;
	}

	/**
	 * Sets the point of initiation.
	 *
	 * @param pointOfInitiation the new point of initiation
	 */
	public void setPointOfInitiation(String pointOfInitiation) {
		this.pointOfInitiation = pointOfInitiation;
	}

	/**
	 * Gets the tip or convenience fee.
	 *
	 * @return the tip or convenience fee
	 */
	public String getTipOrConvenienceFee() {
		return tipOrConvenienceFee;
	}

	/**
	 * Sets the tip or convenience fee.
	 *
	 * @param tipOrConvenienceFee the new tip or convenience fee
	 */
	public void setTipOrConvenienceFee(String tipOrConvenienceFee) {
		this.tipOrConvenienceFee = tipOrConvenienceFee;
	}

	public List<QRMerchantPanTypeVO> getMerchantPan() {
		return merchantPan;
	}

	public void setMerchantPan(List<QRMerchantPanTypeVO> merchantPan) {
		this.merchantPan = merchantPan;
	}

	@Override
	public String toString() {
		return "QRDataVO [qrPayloadVersion=" + qrPayloadVersion
				+ ", merchantCategoryCode=" + merchantCategoryCode
				+ ", txnCurrencyCode=" + txnCurrencyCode + ", txnAmount="
				+ txnAmount + ", countryCode=" + countryCode
				+ ", merchantName=" + merchantName + ", merchantCity="
				+ merchantCity + ", postalCode=" + postalCode
				+ ", additionalField=" + additionalField
				+ ", pointOfInitiation=" + pointOfInitiation
				+ ", tipOrConvenienceFee=" + tipOrConvenienceFee
				+ ", merchantPan=" + merchantPan + "]";
	}

	
	

}
