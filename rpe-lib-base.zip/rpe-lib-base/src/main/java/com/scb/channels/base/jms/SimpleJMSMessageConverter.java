/**
 * 
 */
package com.scb.channels.base.jms;

import java.io.Serializable;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.util.ObjectUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class SimpleJMSMessageConverter.
 *
 * @author 1411807
 */
public class SimpleJMSMessageConverter extends SimpleMessageConverter {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(SimpleJMSMessageConverter.class);
	
	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.SimpleMessageConverter#toMessage(java.lang.Object, javax.jms.Session)
	 */
	public Message toMessage(Object object, Session session) throws JMSException, MessageConversionException {
		
		try {
			return createMessageForSerializable(((Serializable) object), session);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e.getCause());
		}
		
		if (object instanceof Message) {
			return (Message) object;
		}
		else if (object instanceof String) {
			return createMessageForString((String) object, session);
		}
		else if (object instanceof byte[]) {
			return createMessageForByteArray((byte[]) object, session);
		}
		else if (object instanceof Map) {
			return createMessageForMap((Map) object, session);
		}
		else if (object instanceof Serializable) {
			return createMessageForSerializable(((Serializable) object), session);
		}
		else {
			throw new MessageConversionException("Cannot convert object of type [" +
					ObjectUtils.nullSafeClassName(object) + "] to JMS message. Supported message " +
					"payloads are: String, byte array, Map<String,?>, Serializable object.");
		}
	}
}
