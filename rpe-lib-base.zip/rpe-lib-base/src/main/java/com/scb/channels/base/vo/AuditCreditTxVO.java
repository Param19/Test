package com.scb.channels.base.vo;

import java.sql.Timestamp;

/**
 * The Class AuditCreditTxVO.
 *
 * @author 1493439
 */
public class AuditCreditTxVO {
	
	/** The id. */
	private int id;
	
	/** The mobile no. */
	private String mobileNo;
	
	/** The system type. */
	private String systemType = "EBBS";
	
	/** The channel. */
	private String channel;
	
	/** The Status cd. */
	private String StatusCd;
	
	/** The error cd. */
	private String errorCd;
	
	/** The error desc. */
	private String errorDesc; 
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The service name. */
	private String serviceName;
	
	/** The cust id. */
	private String custId;
	
	/** The reference number. */
	private String referenceNumber;
	
	/** The txn date. */
	private Timestamp txnDate;
	
	/** The txn curr. */
	private String txnCurr;
	
	/** The txn amt. */
	private double txnAmt;
	
	/** The audit by. */
	private String auditBy;
	
	/** The created by. */
	private String createdBy;
	
	/** The version. */
	private int version;

	//Orange Money 
	/** Payment Type - Credit/Debit**/
	private String paymentType;
	
	private String updatedBy;

	
	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the systemType
	 */
	public String getSystemType() {
		return systemType;
	}

	/**
	 * @param systemType the systemType to set
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return StatusCd;
	}

	/**
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		StatusCd = statusCd;
	}

	/**
	 * @return the errorCd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * @param errorCd the errorCd to set
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}

	/**
	 * @param errorDesc the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	/**
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}

	/**
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}

	/**
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}

	/**
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * @return the txnDate
	 */
	public Timestamp getTxnDate() {
		return txnDate;
	}

	/**
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(Timestamp txnDate) {
		this.txnDate = txnDate;
	}

	/**
	 * @return the txnCurr
	 */
	public String getTxnCurr() {
		return txnCurr;
	}

	/**
	 * @param txnCurr the txnCurr to set
	 */
	public void setTxnCurr(String txnCurr) {
		this.txnCurr = txnCurr;
	}

	/**
	 * @return the txnAmt
	 */
	public double getTxnAmt() {
		return txnAmt;
	}

	/**
	 * @param txnAmt the txnAmt to set
	 */
	public void setTxnAmt(double txnAmt) {
		this.txnAmt = txnAmt;
	}

	/**
	 * @return the auditBy
	 */
	public String getAuditBy() {
		return auditBy;
	}

	/**
	 * @param auditBy the auditBy to set
	 */
	public void setAuditBy(String auditBy) {
		this.auditBy = auditBy;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AuditCreditTxVO [id=" + id + ", mobileNo=" + mobileNo
				+ ", systemType=" + systemType + ", channel=" + channel
				+ ", StatusCd=" + StatusCd + ", errorCd=" + errorCd
				+ ", errorDesc=" + errorDesc + ", ctryCd=" + ctryCd
				+ ", serviceName=" + serviceName + ", custId=" + custId
				+ ", referenceNumber=" + referenceNumber + ", txnDate="
				+ txnDate + ", txnCurr=" + txnCurr + ", txnAmt=" + txnAmt
				+ ", auditBy=" + auditBy + ", createdBy=" + createdBy
				+ ", version=" + version + "]";
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
