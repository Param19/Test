package com.scb.channels.base.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class InwardInquiryResponseVO.
 *
 * @author 1493439
 */
public class InwardInquiryResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7679468286524391407L;
	
	/** The status type vo. */
	private StatusTypeVO statusTypeVO;
	
	/** The result. */
	private String result;
	
	/**
	 * List of inward Payments
	 */
	private List<InwardPaymentDetailVO> inwardPayments = new ArrayList<InwardPaymentDetailVO>();
	
	/**
	 * @return the inwardPayments
	 */
	public List<InwardPaymentDetailVO> getInwardPayments() {
		return inwardPayments;
	}

	/**
	 * @param inwardPayments the inwardPayments to set
	 */
	public void setInwardPayments(List<InwardPaymentDetailVO> inwardPayments) {
		this.inwardPayments = inwardPayments;
	}

	/**
	 * Gets the status type vo.
	 *
	 * @return the statusTypeVO
	 */
	public StatusTypeVO getStatusTypeVO() {
		return statusTypeVO;
	}

	/**
	 * Sets the status type vo.
	 *
	 * @param statusTypeVO the statusTypeVO to set
	 */
	public void setStatusTypeVO(StatusTypeVO statusTypeVO) {
		this.statusTypeVO = statusTypeVO;
	}

	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InwardInquiryResponseVO [statusTypeVO=" + statusTypeVO
				+ ", result=" + result + ", inwardPayments=" + inwardPayments
				+ "]";
	}

}
