package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * The Class CardVO.
 */
public class CardVO implements Serializable, Cloneable {

	public static final int SIX = 6;

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3695969684792267498L;

	/** The card number. */
	private String cardNumber;
	
	/** The currency. */
	private String currency;
	
	/** The amount. */
	private BigDecimal amount;
	
	/** The card type. */
	private String cardType;
	
	/** The bank info. */
	private BankInfoVO bankInfo;

	/**
	 * Gets the card number.
	 *
	 * @return the cardNumber
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * Sets the card number.
	 *
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * Gets the card type.
	 *
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * Sets the card type.
	 *
	 * @param cardType the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 * Gets the bank info.
	 *
	 * @return the bankInfo
	 */
	public BankInfoVO getBankInfo() {
		return bankInfo;
	}

	/**
	 * Sets the bank info.
	 *
	 * @param bankInfo the bankInfo to set
	 */
	public void setBankInfo(BankInfoVO bankInfo) {
		this.bankInfo = bankInfo;
	}

	/**
	 * Gets the card bin.
	 *
	 * @return the cardBin
	 */
	public String getCardBin() {
		return (cardNumber!=null) ? (cardNumber.substring(0,SIX)): null;
	}
}
