package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

public class MasterCardPaymentDetailsVO extends VMPaymentDetailsVO implements Serializable{

	private static final long serialVersionUID = -2539195184914012795L;
	
	
	private Long id;
	private String senderCountryCode;
	private String senderName;
	private String senderAddress1;
	private String senderAddress2;
	private String senderCity;
	private String senderState;
	private String sourceCountryCode;
	private String senderPostalCode;
	private String senderAcctNo;
	private String cardAcceptorName;
	
/*	private String cardAcceptorTermID;
	private String cardAcceptorIDCode;*/
	private String cardAcceptorState;
	private String cardAcceptorCity;
	private String cardAcceptorPostalCode;
	private String cardAccpetorCountry;
	private String subscriberID;
	private String subscriberType;
	private String subscriberAlias;
	private String routeTxnNo;
	private String processorID;
	
	private String txnDesc;
	private String txnMasterID;
	private String masterRespCd;
	private String masterRespDesc;
	private String errorCode;
	private String errorDesc;
	private String referenceNo; // Ibanking transaction reference no without '-'
	private String ibnkRefNo;
	private String txnDate;
	private String txnNewRefNo; // Master Card generate no in response (TransactionId)
	private String mcTxnNewRefID;
	private String txnType;
	private String acquiringBin;
	private String settlementDate;
	private String recoverableIndicator;
	private String reversalReason;
	private String merchantID;
	private String currencyNumeric;
	private String networkRefNumber;
	private String traceAudit;
	private String txnIdOrig;
	private List<MasterCardTransHistVO> transHistVO;
	private MasterCardErrorVO masterCardErrorVO;
	private String count;
	
	public String getSenderCountryCode() {
		return senderCountryCode;
	}
	public void setSenderCountryCode(String senderCountryCode) {
		this.senderCountryCode = senderCountryCode;
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public String getSenderAddress1() {
		return senderAddress1;
	}
	public void setSenderAddress1(String senderAddress1) {
		this.senderAddress1 = senderAddress1;
	}
	public String getSenderAddress2() {
		return senderAddress2;
	}
	public void setSenderAddress2(String senderAddress2) {
		this.senderAddress2 = senderAddress2;
	}
	public String getSenderCity() {
		return senderCity;
	}
	public void setSenderCity(String senderCity) {
		this.senderCity = senderCity;
	}
	public String getSenderState() {
		return senderState;
	}
	public void setSenderState(String senderState) {
		this.senderState = senderState;
	}
	public String getSourceCountryCode() {
		return sourceCountryCode;
	}
	public void setSourceCountryCode(String sourceCountryCode) {
		this.sourceCountryCode = sourceCountryCode;
	}
	public String getSenderAcctNo() {
		return senderAcctNo;
	}
	public void setSenderAcctNo(String senderAcctNo) {
		this.senderAcctNo = senderAcctNo;
	}
	public String getCardAcceptorName() {
		return cardAcceptorName;
	}
	public void setCardAcceptorName(String cardAcceptorName) {
		this.cardAcceptorName = cardAcceptorName;
	}
/*	public String getCardAcceptorTermID() {
		return cardAcceptorTermID;
	}
	public void setCardAcceptorTermID(String cardAcceptorTermID) {
		this.cardAcceptorTermID = cardAcceptorTermID;
	}
	public String getCardAcceptorIDCode() {
		return cardAcceptorIDCode;
	}
	public void setCardAcceptorIDCode(String cardAcceptorIDCode) {
		this.cardAcceptorIDCode = cardAcceptorIDCode;
	}*/
	public String getCardAcceptorState() {
		return cardAcceptorState;
	}
	public void setCardAcceptorState(String cardAcceptorState) {
		this.cardAcceptorState = cardAcceptorState;
	}
	public String getCardAcceptorCity() {
		return cardAcceptorCity;
	}
	public void setCardAcceptorCity(String cardAcceptorCity) {
		this.cardAcceptorCity = cardAcceptorCity;
	}
	public String getCardAcceptorPostalCode() {
		return cardAcceptorPostalCode;
	}
	public void setCardAcceptorPostalCode(String cardAcceptorPostalCode) {
		this.cardAcceptorPostalCode = cardAcceptorPostalCode;
	}
	public String getCardAccpetorCountry() {
		return cardAccpetorCountry;
	}
	public void setCardAccpetorCountry(String cardAccpetorCountry) {
		this.cardAccpetorCountry = cardAccpetorCountry;
	}
	public String getSubscriberID() {
		return subscriberID;
	}
	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}
	public String getSubscriberType() {
		return subscriberType;
	}
	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	public String getSubscriberAlias() {
		return subscriberAlias;
	}
	public void setSubscriberAlias(String subscriberAlias) {
		this.subscriberAlias = subscriberAlias;
	}
	public String getRouteTxnNo() {
		return routeTxnNo;
	}
	public void setRouteTxnNo(String routeTxnNo) {
		this.routeTxnNo = routeTxnNo;
	}
	public String getProcessorID() {
		return processorID;
	}
	public void setProcessorID(String processorID) {
		this.processorID = processorID;
	}
	public String getTxnDesc() {
		return txnDesc;
	}
	public void setTxnDesc(String txnDesc) {
		this.txnDesc = txnDesc;
	}
	public String getTxnMasterID() {
		return txnMasterID;
	}
	public void setTxnMasterID(String txnMasterID) {
		this.txnMasterID = txnMasterID;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public String getTxnNewRefNo() {
		return txnNewRefNo;
	}
	public void setTxnNewRefNo(String txnNewRefNo) {
		this.txnNewRefNo = txnNewRefNo;
	}
	public String getMcTxnNewRefID() {
		return mcTxnNewRefID;
	}
	public void setMcTxnNewRefID(String mcTxnNewRefID) {
		this.mcTxnNewRefID = mcTxnNewRefID;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	
/*	public String getSettlementDate() {
		return settlementDate;
	}
	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}*/
	public String getRecoverableIndicator() {
		return recoverableIndicator;
	}
	public void setRecoverableIndicator(String recoverableIndicator) {
		this.recoverableIndicator = recoverableIndicator;
	}
	public String getReversalReason() {
		return reversalReason;
	}
	public void setReversalReason(String reversalReason) {
		this.reversalReason = reversalReason;
	}
	public String getSenderPostalCode() {
		return senderPostalCode;
	}
	public void setSenderPostalCode(String senderPostalCode) {
		this.senderPostalCode = senderPostalCode;
	}
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	public String getIbnkRefNo() {
		return ibnkRefNo;
	}
	public void setIbnkRefNo(String ibnkRefNo) {
		this.ibnkRefNo = ibnkRefNo;
	}
	public String getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}
	public String getAcquiringBin() {
		return acquiringBin;
	}
	public void setAcquiringBin(String acquiringBin) {
		this.acquiringBin = acquiringBin;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMerchantID() {
		return merchantID;
	}
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public String getCurrencyNumeric() {
		return currencyNumeric;
	}
	public void setCurrencyNumeric(String currencyNumeric) {
		this.currencyNumeric = currencyNumeric;
	}
	public String getNetworkRefNumber() {
		return networkRefNumber;
	}
	public void setNetworkRefNumber(String networkRefNumber) {
		this.networkRefNumber = networkRefNumber;
	}
	public String getTraceAudit() {
		return traceAudit;
	}
	public void setTraceAudit(String traceAudit) {
		this.traceAudit = traceAudit;
	}
	
	public List<MasterCardTransHistVO> getTransHistVO() {
		return transHistVO;
	}
	public void setTransHistVO(List<MasterCardTransHistVO> transHistVO) {
		this.transHistVO = transHistVO;
	}
	
	public MasterCardErrorVO getMasterCardErrorVO() {
		return masterCardErrorVO;
	}
	public void setMasterCardErrorVO(MasterCardErrorVO masterCardErrorVO) {
		this.masterCardErrorVO = masterCardErrorVO;
	}
	public String getTxnIdOrig() {
		return txnIdOrig;
	}
	public void setTxnIdOrig(String txnIdOrig) {
		this.txnIdOrig = txnIdOrig;
	}
	public String getMasterRespCd() {
		return masterRespCd;
	}
	public void setMasterRespCd(String masterRespCd) {
		this.masterRespCd = masterRespCd;
	}
	public String getMasterRespDesc() {
		return masterRespDesc;
	}
	public void setMasterRespDesc(String masterRespDesc) {
		this.masterRespDesc = masterRespDesc;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	
	
}
