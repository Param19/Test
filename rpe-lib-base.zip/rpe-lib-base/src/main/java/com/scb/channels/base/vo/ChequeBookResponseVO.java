/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ChequeBookResponseVO.
 *
 * @author 1411807
 */
public class ChequeBookResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1469525769262182812L;



}
