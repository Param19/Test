package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

public class NarrationVO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -399771804955659043L;
	
	private String narration;
	private int id;
	private String countryCode;
	private String componentName;
	private String billerId;
	private String categoryId;
	private String serviceName;
	private String channel;
	private String creditNarration1;
	private String creditNarration2;
	private String creditNarration3;
	private String creditNarration4;
	private String creditNarration5;
	private String creditNarration6;
	private String debitNarration1;
	private String debitNarration2;
	private String debitNarration3;
	private String debitNarration4;
	private String debitNarration5;
	private String debitNarration6;
	private String createdBy;
	private String updatedBy;
	private Date dateCreated;
	private Date dateUpdated;
	private int version;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public String getBillerId() {
		return billerId;
	}

	public void setBillerId(String billerId) {
		this.billerId = billerId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCreditNarration1() {
		return creditNarration1;
	}

	public void setCreditNarration1(String creditNarration1) {
		this.creditNarration1 = creditNarration1;
	}

	public String getCreditNarration2() {
		return creditNarration2;
	}

	public void setCreditNarration2(String creditNarration2) {
		this.creditNarration2 = creditNarration2;
	}

	public String getCreditNarration3() {
		return creditNarration3;
	}

	public void setCreditNarration3(String creditNarration3) {
		this.creditNarration3 = creditNarration3;
	}

	public String getCreditNarration4() {
		return creditNarration4;
	}

	public void setCreditNarration4(String creditNarration4) {
		this.creditNarration4 = creditNarration4;
	}

	public String getCreditNarration5() {
		return creditNarration5;
	}

	public void setCreditNarration5(String creditNarration5) {
		this.creditNarration5 = creditNarration5;
	}

	public String getCreditNarration6() {
		return creditNarration6;
	}

	public void setCreditNarration6(String creditNarration6) {
		this.creditNarration6 = creditNarration6;
	}

	public String getDebitNarration1() {
		return debitNarration1;
	}

	public void setDebitNarration1(String debitNarration1) {
		this.debitNarration1 = debitNarration1;
	}

	public String getDebitNarration2() {
		return debitNarration2;
	}

	public void setDebitNarration2(String debitNarration2) {
		this.debitNarration2 = debitNarration2;
	}

	public String getDebitNarration3() {
		return debitNarration3;
	}

	public void setDebitNarration3(String debitNarration3) {
		this.debitNarration3 = debitNarration3;
	}

	public String getDebitNarration4() {
		return debitNarration4;
	}

	public void setDebitNarration4(String debitNarration4) {
		this.debitNarration4 = debitNarration4;
	}

	public String getDebitNarration5() {
		return debitNarration5;
	}

	public void setDebitNarration5(String debitNarration5) {
		this.debitNarration5 = debitNarration5;
	}

	public String getDebitNarration6() {
		return debitNarration6;
	}

	public void setDebitNarration6(String debitNarration6) {
		this.debitNarration6 = debitNarration6;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NarrationVO [narration=" + narration + ", id=" + id
				+ ", countryCode=" + countryCode + ", componentName="
				+ componentName + ", billerId=" + billerId + ", categoryId="
				+ categoryId + ", serviceName=" + serviceName + ", channel="
				+ channel + ", creditNarration1=" + creditNarration1
				+ ", creditNarration2=" + creditNarration2
				+ ", creditNarration3=" + creditNarration3
				+ ", creditNarration4=" + creditNarration4
				+ ", creditNarration5=" + creditNarration5
				+ ", creditNarration6=" + creditNarration6
				+ ", debitNarration1=" + debitNarration1 + ", debitNarration2="
				+ debitNarration2 + ", debitNarration3=" + debitNarration3
				+ ", debitNarration4=" + debitNarration4 + ", debitNarration5="
				+ debitNarration5 + ", debitNarration6=" + debitNarration6
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ ", dateCreated=" + dateCreated + ", dateUpdated="
				+ dateUpdated + ", version=" + version + "]";
	}
	
}
