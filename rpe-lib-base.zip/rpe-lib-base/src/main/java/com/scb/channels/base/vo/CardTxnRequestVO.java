/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class CardTxnRequestVO.
 *
 * @author 1411807
 */
public class CardTxnRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4598575725406935790L;



}
