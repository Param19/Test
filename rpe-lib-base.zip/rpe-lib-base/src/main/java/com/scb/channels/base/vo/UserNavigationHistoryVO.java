package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class UserNavigationHistoryVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5237245060887774932L;
	
	protected Calendar actionTime;

	protected String actionType;

	protected String description;

	/**
	 * @return the actionTime
	 */
	public Calendar getActionTime() {
		return actionTime;
	}

	/**
	 * @param actionTime the actionTime to set
	 */
	public void setActionTime(Calendar actionTime) {
		this.actionTime = actionTime;
	}

	/**
	 * @return the actionType
	 */
	public String getActionType() {
		return actionType;
	}

	/**
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

}
