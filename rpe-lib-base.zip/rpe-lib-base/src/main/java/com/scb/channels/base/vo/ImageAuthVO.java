/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * @author 1411807
 *
 */
public class ImageAuthVO extends AuthVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5193436889348393264L;

	private Object imageCredentials;

	/**
	 * @return the imageCredentials
	 */
	public Object getImageCredentials() {
		return imageCredentials;
	}

	/**
	 * @param imageCredentials the imageCredentials to set
	 */
	public void setImageCredentials(Object imageCredentials) {
		this.imageCredentials = imageCredentials;
	}
}
