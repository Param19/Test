package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentVisaPurchaseIdentifier implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5879582290549717226L;
	private String type;
	private String referenceNumber;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	@Override
	public String toString() {
		return "QRPaymentVisaPurchaseIdentifier [type=" + type
				+ ", referenceNumber=" + referenceNumber + "]";
	}
	
}
