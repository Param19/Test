/**
 * 
 */
package com.scb.channels.base.vo;




/**
 * This class holder request Information.
 *
 * @author 1411807
 */
public class BeneficiaryRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7580475855693479528L;
	
	
}
