package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class StatisticalHistoryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2649736031807988702L;
	
	    private String dailyAvailableBalance;
	    private String dailyLedgerBalance;
	    private Calendar accountBalanceLastUpdatedDate;
	    private List<StatisticalBalanceVO> statisticalBalance;
	    private List<CurrentBalanceVO> currentBalance;
		
	    
	    public String getDailyAvailableBalance() {
			return dailyAvailableBalance;
		}
		public void setDailyAvailableBalance(String dailyAvailableBalance) {
			this.dailyAvailableBalance = dailyAvailableBalance;
		}
		public String getDailyLedgerBalance() {
			return dailyLedgerBalance;
		}
		public void setDailyLedgerBalance(String dailyLedgerBalance) {
			this.dailyLedgerBalance = dailyLedgerBalance;
		}
		public Calendar getAccountBalanceLastUpdatedDate() {
			return accountBalanceLastUpdatedDate;
		}
		public void setAccountBalanceLastUpdatedDate(
				Calendar accountBalanceLastUpdatedDate) {
			this.accountBalanceLastUpdatedDate = accountBalanceLastUpdatedDate;
		}
		public List<StatisticalBalanceVO> getStatisticalBalance() {
			return statisticalBalance;
		}
		public void setStatisticalBalance(List<StatisticalBalanceVO> statisticalBalance) {
			this.statisticalBalance = statisticalBalance;
		}
		public List<CurrentBalanceVO> getCurrentBalance() {
			return currentBalance;
		}
		public void setCurrentBalance(List<CurrentBalanceVO> currentBalance) {
			this.currentBalance = currentBalance;
		}

}
