package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class AccountCreditDebitInterestVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4888852312736034677L;
	
	private String interestTypeIndicator;
    private Calendar actualInterestPayDate;
    private String accountCurrencyCode;
    private String accountNumber;
    private String interestAccruedAmount;
    private String interestAdjustedAmount;
    private String compoundInterest;
    private String accruedPeriodForInterest;
    private String interestAccrueIndicator;
    private String interestProductCode;
    private String interestLastAccruedAdjustmentAmount;
    private Calendar interestLastAccrualDate;
    private Calendar interestLastPaymentDate;
    private String interestManualAdjustedAmount;
    private Calendar interestNextPaymentDate;
    private String interestPromotionCode;
    private String specialInterestAccruedAmount;
    private String specialInterestAdjustedAmoun;
    private Calendar lastInterestComputedDate;
    private String lastInterestAccrualRate;
    private Calendar nextInterestChargeDate;
    private Calendar nextInterestComputeDate;
    private String prppaInterestAccruedAmount;
    private String prppaInterestAdjustmentAmount;
    private String prppaInterestManualAdjustmentAmount;
    private String promotionalInterestCode;
    private String promotionalInterestProductCode;
    private String specialInterestProductCode;
    private String interestAccrualType;
    private String interestPaymentFrequency;
    private String mimimumInterestAmount;
    private Calendar interestEffectiveDate;
    private Calendar interestPaidDate;
    private String interestAmountPaid;
	
    
    public String getInterestTypeIndicator() {
		return interestTypeIndicator;
	}
	public void setInterestTypeIndicator(String interestTypeIndicator) {
		this.interestTypeIndicator = interestTypeIndicator;
	}
	public Calendar getActualInterestPayDate() {
		return actualInterestPayDate;
	}
	public void setActualInterestPayDate(Calendar actualInterestPayDate) {
		this.actualInterestPayDate = actualInterestPayDate;
	}
	public String getAccountCurrencyCode() {
		return accountCurrencyCode;
	}
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getInterestAccruedAmount() {
		return interestAccruedAmount;
	}
	public void setInterestAccruedAmount(String interestAccruedAmount) {
		this.interestAccruedAmount = interestAccruedAmount;
	}
	public String getInterestAdjustedAmount() {
		return interestAdjustedAmount;
	}
	public void setInterestAdjustedAmount(String interestAdjustedAmount) {
		this.interestAdjustedAmount = interestAdjustedAmount;
	}
	public String getCompoundInterest() {
		return compoundInterest;
	}
	public void setCompoundInterest(String compoundInterest) {
		this.compoundInterest = compoundInterest;
	}
	public String getAccruedPeriodForInterest() {
		return accruedPeriodForInterest;
	}
	public void setAccruedPeriodForInterest(String accruedPeriodForInterest) {
		this.accruedPeriodForInterest = accruedPeriodForInterest;
	}
	public String getInterestAccrueIndicator() {
		return interestAccrueIndicator;
	}
	public void setInterestAccrueIndicator(String interestAccrueIndicator) {
		this.interestAccrueIndicator = interestAccrueIndicator;
	}
	public String getInterestProductCode() {
		return interestProductCode;
	}
	public void setInterestProductCode(String interestProductCode) {
		this.interestProductCode = interestProductCode;
	}
	public String getInterestLastAccruedAdjustmentAmount() {
		return interestLastAccruedAdjustmentAmount;
	}
	public void setInterestLastAccruedAdjustmentAmount(
			String interestLastAccruedAdjustmentAmount) {
		this.interestLastAccruedAdjustmentAmount = interestLastAccruedAdjustmentAmount;
	}
	public Calendar getInterestLastAccrualDate() {
		return interestLastAccrualDate;
	}
	public void setInterestLastAccrualDate(Calendar interestLastAccrualDate) {
		this.interestLastAccrualDate = interestLastAccrualDate;
	}
	public Calendar getInterestLastPaymentDate() {
		return interestLastPaymentDate;
	}
	public void setInterestLastPaymentDate(Calendar interestLastPaymentDate) {
		this.interestLastPaymentDate = interestLastPaymentDate;
	}
	public String getInterestManualAdjustedAmount() {
		return interestManualAdjustedAmount;
	}
	public void setInterestManualAdjustedAmount(String interestManualAdjustedAmount) {
		this.interestManualAdjustedAmount = interestManualAdjustedAmount;
	}
	public Calendar getInterestNextPaymentDate() {
		return interestNextPaymentDate;
	}
	public void setInterestNextPaymentDate(Calendar interestNextPaymentDate) {
		this.interestNextPaymentDate = interestNextPaymentDate;
	}
	public String getInterestPromotionCode() {
		return interestPromotionCode;
	}
	public void setInterestPromotionCode(String interestPromotionCode) {
		this.interestPromotionCode = interestPromotionCode;
	}
	public String getSpecialInterestAccruedAmount() {
		return specialInterestAccruedAmount;
	}
	public void setSpecialInterestAccruedAmount(String specialInterestAccruedAmount) {
		this.specialInterestAccruedAmount = specialInterestAccruedAmount;
	}
	public String getSpecialInterestAdjustedAmoun() {
		return specialInterestAdjustedAmoun;
	}
	public void setSpecialInterestAdjustedAmoun(String specialInterestAdjustedAmoun) {
		this.specialInterestAdjustedAmoun = specialInterestAdjustedAmoun;
	}
	public Calendar getLastInterestComputedDate() {
		return lastInterestComputedDate;
	}
	public void setLastInterestComputedDate(Calendar lastInterestComputedDate) {
		this.lastInterestComputedDate = lastInterestComputedDate;
	}
	public String getLastInterestAccrualRate() {
		return lastInterestAccrualRate;
	}
	public void setLastInterestAccrualRate(String lastInterestAccrualRate) {
		this.lastInterestAccrualRate = lastInterestAccrualRate;
	}
	public Calendar getNextInterestChargeDate() {
		return nextInterestChargeDate;
	}
	public void setNextInterestChargeDate(Calendar nextInterestChargeDate) {
		this.nextInterestChargeDate = nextInterestChargeDate;
	}
	public Calendar getNextInterestComputeDate() {
		return nextInterestComputeDate;
	}
	public void setNextInterestComputeDate(Calendar nextInterestComputeDate) {
		this.nextInterestComputeDate = nextInterestComputeDate;
	}
	public String getPrppaInterestAccruedAmount() {
		return prppaInterestAccruedAmount;
	}
	public void setPrppaInterestAccruedAmount(String prppaInterestAccruedAmount) {
		this.prppaInterestAccruedAmount = prppaInterestAccruedAmount;
	}
	public String getPrppaInterestAdjustmentAmount() {
		return prppaInterestAdjustmentAmount;
	}
	public void setPrppaInterestAdjustmentAmount(
			String prppaInterestAdjustmentAmount) {
		this.prppaInterestAdjustmentAmount = prppaInterestAdjustmentAmount;
	}
	public String getPrppaInterestManualAdjustmentAmount() {
		return prppaInterestManualAdjustmentAmount;
	}
	public void setPrppaInterestManualAdjustmentAmount(
			String prppaInterestManualAdjustmentAmount) {
		this.prppaInterestManualAdjustmentAmount = prppaInterestManualAdjustmentAmount;
	}
	public String getPromotionalInterestCode() {
		return promotionalInterestCode;
	}
	public void setPromotionalInterestCode(String promotionalInterestCode) {
		this.promotionalInterestCode = promotionalInterestCode;
	}
	public String getPromotionalInterestProductCode() {
		return promotionalInterestProductCode;
	}
	public void setPromotionalInterestProductCode(
			String promotionalInterestProductCode) {
		this.promotionalInterestProductCode = promotionalInterestProductCode;
	}
	public String getSpecialInterestProductCode() {
		return specialInterestProductCode;
	}
	public void setSpecialInterestProductCode(String specialInterestProductCode) {
		this.specialInterestProductCode = specialInterestProductCode;
	}
	public String getInterestAccrualType() {
		return interestAccrualType;
	}
	public void setInterestAccrualType(String interestAccrualType) {
		this.interestAccrualType = interestAccrualType;
	}
	public String getInterestPaymentFrequency() {
		return interestPaymentFrequency;
	}
	public void setInterestPaymentFrequency(String interestPaymentFrequency) {
		this.interestPaymentFrequency = interestPaymentFrequency;
	}
	public String getMimimumInterestAmount() {
		return mimimumInterestAmount;
	}
	public void setMimimumInterestAmount(String mimimumInterestAmount) {
		this.mimimumInterestAmount = mimimumInterestAmount;
	}
	public Calendar getInterestEffectiveDate() {
		return interestEffectiveDate;
	}
	public void setInterestEffectiveDate(Calendar interestEffectiveDate) {
		this.interestEffectiveDate = interestEffectiveDate;
	}
	public Calendar getInterestPaidDate() {
		return interestPaidDate;
	}
	public void setInterestPaidDate(Calendar interestPaidDate) {
		this.interestPaidDate = interestPaidDate;
	}
	public String getInterestAmountPaid() {
		return interestAmountPaid;
	}
	public void setInterestAmountPaid(String interestAmountPaid) {
		this.interestAmountPaid = interestAmountPaid;
	}

}
