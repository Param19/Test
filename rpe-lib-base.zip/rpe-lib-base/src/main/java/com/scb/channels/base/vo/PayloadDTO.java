/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



/**
 * The Class PayloadDTO.
 *
 * @author 1411807
 */
public class PayloadDTO implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1602777335488577385L;

	/** The request vo. */
	private BaseVO requestVO;
	
	/** The response vo. */
	private BaseVO responseVO;
	
	/** The current state. */
	private String currentState;
	
	/** The trace path. */
	private List<ExchangeInfo> tracePath = new ArrayList<ExchangeInfo>();

	/**
	 * Gets the request vo.
	 *
	 * @return the requestVO
	 */
	public BaseVO getRequestVO() {
		return requestVO;
	}

	/**
	 * Sets the request vo.
	 *
	 * @param requestVO the requestVO to set
	 */
	public void setRequestVO(BaseVO requestVO) {
		this.requestVO = requestVO;
	}

	/**
	 * Gets the response vo.
	 *
	 * @return the responseVO
	 */
	public BaseVO getResponseVO() {
		return responseVO;
	}

	/**
	 * Sets the response vo.
	 *
	 * @param responseVO the responseVO to set
	 */
	public void setResponseVO(BaseVO responseVO) {
		this.responseVO = responseVO;
	}

	/**
	 * Gets the current state.
	 *
	 * @return the currentState
	 */
	public String getCurrentState() {
		return currentState;
	}

	/**
	 * Sets the current state.
	 *
	 * @param currentState the currentState to set
	 */
	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}


	/**
	 * Gets the trace path.
	 *
	 * @return the tracePath
	 */
	public List<ExchangeInfo> getTracePath() {
		return tracePath;
	}

	/**
	 * Adds the trace path.
	 *
	 * @param path the path
	 */
	public void addTracePath(ExchangeInfo path) {
		tracePath.add(path);
	}

}
