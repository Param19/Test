package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CreditCardVO implements Serializable,Cloneable {

	 
	private static final long serialVersionUID = 73138157787228555L;
	
	//Card related Information
	private String relno;
	private String country;
	private String cardNumber;
    private String cardHolderName;
    private String cardType;
    private String cardStatus;
    private String cardIssuer;	
    private String paymentdate;
    private String cardOutstandingBalance;
    private String Saadiqproductidentifier;
    private String cardcurrencyCode;
    private String currentStatus;
    //balance related 
    private String totalCardLimit;
    private String outstandingBalance;
    private String totalCreditLimit;
    private String totalCashLimit;
    private String totalUnbilledDebitTransactions;
    private String totalUnbilledCreditTransactions;
    private String availableCreditLimit;
    private String availableCashLimit;
    private String minimumAmountDue;
    private String segmentCode;
    private String minimumAmountDueDate;
    private String cardExpiryDate; 
    private String cardValidFrom;
    private String referenceNo;
    private String Blockcode;
    private String cardsReqcode;
   	private String errorCode;
    private String errorDescription;
    private String relationshipManagerCode;
    private String relationshipManagerName;
    private String customerSegmentCode;
    private String description;
    private String chequeRequestFlag;
    private String category;
    private String RewardbalanceLastStmt;
    private String Rewardbalancecurrent;
    private List<CreditCardTransactionsVO> trasactions;
    private String productCode;
    private String transactionStartDate;
    private String transactionEndDate;
    private String serviceCode;
    private String chnlCode;
    private String requestId;
    private String statementDate;
    private String  statementBalance;
    
	public String getRelno() {
		return relno;
	}
	public void setRelno(String relno) {
		this.relno = relno;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	public String getCardIssuer() {
		return cardIssuer;
	}
	public void setCardIssuer(String cardIssuer) {
		this.cardIssuer = cardIssuer;
	}
	public String getPaymentdate() {
		return paymentdate;
	}
	public void setPaymentdate(String paymentdate) {
		this.paymentdate = paymentdate;
	}
	public String getCardOutstandingBalance() {
		return cardOutstandingBalance;
	}
	public void setCardOutstandingBalance(String cardOutstandingBalance) {
		this.cardOutstandingBalance = cardOutstandingBalance;
	}
	public String getSaadiqproductidentifier() {
		return Saadiqproductidentifier;
	}
	public void setSaadiqproductidentifier(String saadiqproductidentifier) {
		Saadiqproductidentifier = saadiqproductidentifier;
	}
	public String getCardcurrencyCode() {
		return cardcurrencyCode;
	}
	public void setCardcurrencyCode(String cardcurrencyCode) {
		this.cardcurrencyCode = cardcurrencyCode;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getTotalCardLimit() {
		return totalCardLimit;
	}
	public void setTotalCardLimit(String totalCardLimit) {
		this.totalCardLimit = totalCardLimit;
	}
	public String getOutstandingBalance() {
		return outstandingBalance;
	}
	public void setOutstandingBalance(String outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}
	public String getTotalCreditLimit() {
		return totalCreditLimit;
	}
	public void setTotalCreditLimit(String totalCreditLimit) {
		this.totalCreditLimit = totalCreditLimit;
	}
	public String getTotalCashLimit() {
		return totalCashLimit;
	}
	public void setTotalCashLimit(String totalCashLimit) {
		this.totalCashLimit = totalCashLimit;
	}
	public String getTotalUnbilledDebitTransactions() {
		return totalUnbilledDebitTransactions;
	}
	public void setTotalUnbilledDebitTransactions(
			String totalUnbilledDebitTransactions) {
		this.totalUnbilledDebitTransactions = totalUnbilledDebitTransactions;
	}
	public String getTotalUnbilledCreditTransactions() {
		return totalUnbilledCreditTransactions;
	}
	public void setTotalUnbilledCreditTransactions(
			String totalUnbilledCreditTransactions) {
		this.totalUnbilledCreditTransactions = totalUnbilledCreditTransactions;
	}
	public String getAvailableCreditLimit() {
		return availableCreditLimit;
	}
	public void setAvailableCreditLimit(String availableCreditLimit) {
		this.availableCreditLimit = availableCreditLimit;
	}
	public String getAvailableCashLimit() {
		return availableCashLimit;
	}
	public void setAvailableCashLimit(String availableCashLimit) {
		this.availableCashLimit = availableCashLimit;
	}
	public String getMinimumAmountDue() {
		return minimumAmountDue;
	}
	public void setMinimumAmountDue(String minimumAmountDue) {
		this.minimumAmountDue = minimumAmountDue;
	}
	public String getSegmentCode() {
		return segmentCode;
	}
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	public String getMinimumAmountDueDate() {
		return minimumAmountDueDate;
	}
	public void setMinimumAmountDueDate(String minimumAmountDueDate) {
		this.minimumAmountDueDate = minimumAmountDueDate;
	}
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}
	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	public String getCardValidFrom() {
		return cardValidFrom;
	}
	public void setCardValidFrom(String cardValidFrom) {
		this.cardValidFrom = cardValidFrom;
	}
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	public String getBlockcode() {
		return Blockcode;
	}
	public void setBlockcode(String blockcode) {
		Blockcode = blockcode;
	}
	public String getCardsReqcode() {
		return cardsReqcode;
	}
	public void setCardsReqcode(String cardsReqcode) {
		this.cardsReqcode = cardsReqcode;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String getRelationshipManagerCode() {
		return relationshipManagerCode;
	}
	public void setRelationshipManagerCode(String relationshipManagerCode) {
		this.relationshipManagerCode = relationshipManagerCode;
	}
	public String getRelationshipManagerName() {
		return relationshipManagerName;
	}
	public void setRelationshipManagerName(String relationshipManagerName) {
		this.relationshipManagerName = relationshipManagerName;
	}
	public String getCustomerSegmentCode() {
		return customerSegmentCode;
	}
	public void setCustomerSegmentCode(String customerSegmentCode) {
		this.customerSegmentCode = customerSegmentCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getChequeRequestFlag() {
		return chequeRequestFlag;
	}
	public void setChequeRequestFlag(String chequeRequestFlag) {
		this.chequeRequestFlag = chequeRequestFlag;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRewardbalanceLastStmt() {
		return RewardbalanceLastStmt;
	}
	public void setRewardbalanceLastStmt(String rewardbalanceLastStmt) {
		RewardbalanceLastStmt = rewardbalanceLastStmt;
	}
	public String getRewardbalancecurrent() {
		return Rewardbalancecurrent;
	}
	public void setRewardbalancecurrent(String rewardbalancecurrent) {
		Rewardbalancecurrent = rewardbalancecurrent;
	}
	public List<CreditCardTransactionsVO> getTrasactions() {
		return trasactions;
	}
	public void setTrasactions(List<CreditCardTransactionsVO> trasactions) {
		this.trasactions = trasactions;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getTransactionStartDate() {
		return transactionStartDate;
	}
	public void setTransactionStartDate(String transactionStartDate) {
		this.transactionStartDate = transactionStartDate;
	}
	public String getTransactionEndDate() {
		return transactionEndDate;
	}
	public void setTransactionEndDate(String transactionEndDate) {
		this.transactionEndDate = transactionEndDate;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getChnlCode() {
		return chnlCode;
	}
	public void setChnlCode(String chnlCode) {
		this.chnlCode = chnlCode;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getStatementDate() {
		return statementDate;
	}
	public void setStatementDate(String statementDate) {
		this.statementDate = statementDate;
	}
	public String getStatementBalance() {
		return statementBalance;
	}
	public void setStatementBalance(String statementBalance) {
		this.statementBalance = statementBalance;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
    
    
	}
