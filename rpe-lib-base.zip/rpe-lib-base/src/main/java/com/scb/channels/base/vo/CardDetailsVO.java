package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class CardDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3105312696075806056L;
	
		private String cardNumber;
	    private String cardName;
	    private String cardStatus;
	    private String cardType;
	    private String cardAccountCurrencyCode;
	    private String cardAccountNumber;
	    private String cardInterchangeMemberIndicator;
	    private Calendar cardIssueDate;
	    private Calendar cardExpiryDate;
	    private Calendar cardActivationDate;
	    private String cardActivationTime;
	    private String cardActivationChannelID;
	    private String customerIdentificationNumber;
	    private String cardAddressTypeCode;
	    private String makerID;
	    private Calendar makerDate;
	    private List<OverseasCardDetailsVO> overseasCardDetailsVO;
		
	    
	    public String getCardNumber() {
			return cardNumber;
		}
		public void setCardNumber(String cardNumber) {
			this.cardNumber = cardNumber;
		}
		public String getCardName() {
			return cardName;
		}
		public void setCardName(String cardName) {
			this.cardName = cardName;
		}
		public String getCardStatus() {
			return cardStatus;
		}
		public void setCardStatus(String cardStatus) {
			this.cardStatus = cardStatus;
		}
		public String getCardType() {
			return cardType;
		}
		public void setCardType(String cardType) {
			this.cardType = cardType;
		}
		public String getCardAccountCurrencyCode() {
			return cardAccountCurrencyCode;
		}
		public void setCardAccountCurrencyCode(String cardAccountCurrencyCode) {
			this.cardAccountCurrencyCode = cardAccountCurrencyCode;
		}
		public String getCardAccountNumber() {
			return cardAccountNumber;
		}
		public void setCardAccountNumber(String cardAccountNumber) {
			this.cardAccountNumber = cardAccountNumber;
		}
		public String getCardInterchangeMemberIndicator() {
			return cardInterchangeMemberIndicator;
		}
		public void setCardInterchangeMemberIndicator(
				String cardInterchangeMemberIndicator) {
			this.cardInterchangeMemberIndicator = cardInterchangeMemberIndicator;
		}
		public Calendar getCardIssueDate() {
			return cardIssueDate;
		}
		public void setCardIssueDate(Calendar cardIssueDate) {
			this.cardIssueDate = cardIssueDate;
		}
		public Calendar getCardExpiryDate() {
			return cardExpiryDate;
		}
		public void setCardExpiryDate(Calendar cardExpiryDate) {
			this.cardExpiryDate = cardExpiryDate;
		}
		public Calendar getCardActivationDate() {
			return cardActivationDate;
		}
		public void setCardActivationDate(Calendar cardActivationDate) {
			this.cardActivationDate = cardActivationDate;
		}
		public String getCardActivationTime() {
			return cardActivationTime;
		}
		public void setCardActivationTime(String cardActivationTime) {
			this.cardActivationTime = cardActivationTime;
		}
		public String getCardActivationChannelID() {
			return cardActivationChannelID;
		}
		public void setCardActivationChannelID(String cardActivationChannelID) {
			this.cardActivationChannelID = cardActivationChannelID;
		}
		public String getCustomerIdentificationNumber() {
			return customerIdentificationNumber;
		}
		public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
			this.customerIdentificationNumber = customerIdentificationNumber;
		}
		public String getCardAddressTypeCode() {
			return cardAddressTypeCode;
		}
		public void setCardAddressTypeCode(String cardAddressTypeCode) {
			this.cardAddressTypeCode = cardAddressTypeCode;
		}
		public String getMakerID() {
			return makerID;
		}
		public void setMakerID(String makerID) {
			this.makerID = makerID;
		}
		public Calendar getMakerDate() {
			return makerDate;
		}
		public void setMakerDate(Calendar makerDate) {
			this.makerDate = makerDate;
		}
		public List<OverseasCardDetailsVO> getOverseasCardDetailsVO() {
			return overseasCardDetailsVO;
		}
		public void setOverseasCardDetailsVO(
				List<OverseasCardDetailsVO> overseasCardDetailsVO) {
			this.overseasCardDetailsVO = overseasCardDetailsVO;
		}
	    

}
