package com.scb.channels.base.helper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectMapperImpl extends ObjectMapper {
	
	  private static final long serialVersionUID = 1L;

	  public ObjectMapperImpl()
	  {
	    this._serializationConfig = getSerializationConfig().withSerializationInclusion(JsonInclude.Include.NON_NULL);
	  }

}
