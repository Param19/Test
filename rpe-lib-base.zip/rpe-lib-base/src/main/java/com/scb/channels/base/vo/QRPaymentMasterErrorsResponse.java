package com.scb.channels.base.vo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterErrorsResponse {
	
	
	//private QRPaymentMasterErrorResponse exception ;
	private LinkedHashMap<String, QRPaymentMasterErrorResponse>  exception;
	private List<LinkedHashMap<String, QRPaymentMasterErrorResponse>> exceptions = new ArrayList<LinkedHashMap<String, QRPaymentMasterErrorResponse>>();
	
	private QRPaymentMasterErrorResponse error;
	
	public void setError(Object error) {
		if(error != null) {
			if(error instanceof List) {
				exceptions = (List<LinkedHashMap<String, QRPaymentMasterErrorResponse>>)error;
			} else {
				//exception = (QRPaymentMasterErrorResponse) error;
				 exception =(LinkedHashMap<String, QRPaymentMasterErrorResponse>) error;
			}
		}
	}

	public LinkedHashMap<String, QRPaymentMasterErrorResponse> getException() {
		return exception;
	}

	public List<LinkedHashMap<String, QRPaymentMasterErrorResponse>> getExceptions() {
		return exceptions;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterErrorsResponse [exception=" + exception
				+ ", exceptions=" + exceptions + ", error=" + error + "]";
	}
	

}
