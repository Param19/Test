package com.scb.channels.base.helper;

import java.io.Serializable;

public class CreditCardConstants implements Serializable{
	
	private static final long serialVersionUID = 1L;

	//mandatory fields
	public static final String TRANS_TYPE = "010000"; //processing code 
	
	public static final String WITQ = "WITQ"; 
	
	public static final String DEFAULT = "Default";
	
	public static final String EXCHANGE_ID="000";
	
	public static final String XXX="XXX"; //base currency
	
	public static final String AUTQ="AUTQ"; 
	
	public static final String CRDP = "CRDP"; 
	
	public static final String REVQ = "REVQ"; 
	
	public static final String MGTQ = "MGTQ"; 
	
	public static final String COFF ="COFF"; 

	public static final String PHYS = "PHYS";
	
	public static final String FNCQ = "FNCQ"; 
	
	public static final String WITK = "WITK"; 
}
