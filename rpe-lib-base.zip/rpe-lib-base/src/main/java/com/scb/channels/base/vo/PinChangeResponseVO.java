/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class PinChangeResponseVO.
 *
 * @author 1411807
 */
public class PinChangeResponseVO extends BaseVO {


	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7453483967800071437L;

	/** The pin change response. */
	private String pinChangeResponse;
	
	/** The pin change status. */
	private String pinChangeStatus;

	/**
	 * Gets the pin change response.
	 *
	 * @return the pinChangeResponse
	 */
	public String getPinChangeResponse() {
		return pinChangeResponse;
	}

	/**
	 * Sets the pin change response.
	 *
	 * @param pinChangeResponse the pinChangeResponse to set
	 */
	public void setPinChangeResponse(String pinChangeResponse) {
		this.pinChangeResponse = pinChangeResponse;
	}

	/**
	 * Gets the pin change status.
	 *
	 * @return the pinChangeStatus
	 */
	public String getPinChangeStatus() {
		return pinChangeStatus;
	}

	/**
	 * Sets the pin change status.
	 *
	 * @param pinChangeStatus the pinChangeStatus to set
	 */
	public void setPinChangeStatus(String pinChangeStatus) {
		this.pinChangeStatus = pinChangeStatus;
	}

}
