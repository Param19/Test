package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.scb.channels.base.helper.CreditCardConstants;

/**
 * The Class BillerPayDetailsVO.
 */
public class BillerPayDetailsVO implements Serializable, Cloneable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5124029138908261100L;
	
	
	private String paymentType;
	
	private String customerId;
	
	private String countryCode;
	
	private String channel;
	
	private String payeeId;
	
	private String billerName;
	
	private String transactionType;
	
	// For C400 Constants mapping
	private CreditCardConstants cardConstants = new CreditCardConstants();
	
	/** The id. */
	private Long id;
	
	int uniqueId;
	
	/** The billerCategory  cd. */
	private String billerCategoryCd;
	

	/** The biller cd. */
	private String billerCategoryDesc;

	/** The biller cd. */
	private String billerCd;
	
	/** The biller desc. */
	private String billerDesc;
	
	/** The utility cd. */
	private String utilityCd;
	
	/** The utillty type desc. */
	private String utilltyTypeDesc;
	
	/** The consumer no. */
	private String consumerNo;
	
	/** The consumer desc. */
	private String consumerDesc;
	
	/** The consumer Name. */
	private String custName;
	
	/** The biller nick name. */
	private String billerNickName;
	
	/** The debit acct src type. */
	private String debitAcctSrcType;
	
	/** The pay ref. */
	private String payRef;
	
	/** The bill payment type. */
	private String billPaymentType;
	
	/** The post payment allowed. */
	private String postPaymentAllowed;
	
	/** Destination account name*. */
	private String destAccName;
	
	/** The src account name. */
	private String srcAccountName;
	
	/** The txn currency. */
	private String txnCurrency;
	
	/** The txn activity. */
	private String txnActivity;
	
	/** The txn act status. */
	private String txnActStatus;
	
	/** The dest txn amount. */
	private double destTxnAmount;
	//VisaPymtDetailsVO visaDetailsVO;
	/** The payment details vo. */
	PaymentDetailVO paymentDetailsVO;
	//MasterCardPaymentDetailsVO masterDetailsVO;
	
	private String authCode; //added for CR659 
	
	private String stan; //added for CR659 
	
	private String retrievalReferenceNumber; //added for CR659 
	
	private String cardUtilityCode ; // added for CR659
	
	private String paymentSubType; // added for CR659
	
	/** The fields. */
	private FieldVO field;
	
	private String aggId;
	
	/** updated date */
	private Date updatedDate;
	
	
	/** The dest nextExcTime. */
	private Date nextExcTime;
	
	private String presentMentType;
	
	private String ApplicationUserID;
	private String ApplicationUserKey;
	

	private List<TransactionsPostingVO> transactionsPosting;

	
	public String getApplicationUserID() {
		return ApplicationUserID;
	}

	public void setApplicationUserID(String applicationUserID) {
		ApplicationUserID = applicationUserID;
	}

	public String getApplicationUserKey() {
		return ApplicationUserKey;
	}

	public void setApplicationUserKey(String applicationUserKey) {
		ApplicationUserKey = applicationUserKey;
	}

	
	
	
	/**
	 * @return the uniqueId
	 */
	public int getUniqueId() {
		return uniqueId;
	}

	/**
	 * @param uniqueId the uniqueId to set
	 */
	public void setUniqueId(int uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getPresentMentType() {
		return presentMentType;
	}

	public void setPresentMentType(String presentMentType) {
		this.presentMentType = presentMentType;
	}

	private List<BillerCategoryVO> billerCategoryVO= new ArrayList<BillerCategoryVO>();

	 
	public List<BillerCategoryVO> getBillerCategoryVO() {
		return billerCategoryVO;
	}

	public void setBillerCategoryVO(List<BillerCategoryVO> billerCategoryVO) {
		this.billerCategoryVO = billerCategoryVO;
	}

	 
	

	public String getBillerCategoryCd() {
		return billerCategoryCd;
	}

	public void setBillerCategoryCd(String billerCategoryCd) {
		this.billerCategoryCd = billerCategoryCd;
	}

	public String getBillerCategoryDesc() {
		return billerCategoryDesc;
	}

	public void setBillerCategoryDesc(String billerCategoryDesc) {
		this.billerCategoryDesc = billerCategoryDesc;
	}	
	
	/**
	 * Gets the merchant code.
	 *
	 * @return the merchant code
	 */
	public String getMerchantCode() {
		return merchantCode;
	}

	/**
	 * Sets the merchant code.
	 *
	 * @param merchantCode the new merchant code
	 */
	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	/** The is auth req. */
	private String isAuthReq;
	
	/** The is for sme. */
	private String isForSme;
	
	/** The pay mthd. */
	private String payMthd;
	
	/** The dt eff from. */
	private Date dtEffFrom;
	
	/** The biller address. */
	private AddressVO billerAddress;
	
	/** The bank info vo. */
	private BankInfoVO bankInfoVO;
	
	/** The presentment vo. */
	private PresentmentVO presentmentVO;
	
	/** The transation info vo. */
	private TransactionInfoVO transactionInfoVO;
	
	
	/** The biller fields. */
	private List<BillerField> billerFields;
	
	/** The biller min pmt. */
	private Double billerMinPmt;
	
	/** The biller max pmt. */
	private Double billerMaxPmt;
	
	/** The value. */
	private List<String> value;
	
	/** The std ins src flag. */
	private String stdInsSrcFlag;
	
	/** The ref info. */
	private List<RefInfoTypeVO> refInfo;
	
	/** The is reg biller. */
	private char isRegBiller;
	
	/** The merchant code. */
	private String merchantCode;
	
	/** The conversion rate. */
	private String conversionRate;

	
	/** Airtime topup details. */
	private String provider;
	
	/** The topup mobile no. */
	private String topupMobileNo;
	
	/** The topup debit account. */
	private String topupDebitAccount;
	
	/** The topup amount. */
	private String topupAmount;
	
	private String hostReference;
	
	private String hostName;
	
	private String mobileNumber;
	
	private String emailId;
	
	private String staffFlag;
	
	/** The biller fields. */
	private List<BillerField> fieldsFromDB;
	
	/**
	 * @return the fieldsFromDB
	 */
	public List<BillerField> getFieldsFromDB() {
		return fieldsFromDB;
	}

	/**
	 * @param fieldsFromDB the fieldsFromDB to set
	 */
	public void setFieldsFromDB(List<BillerField> fieldsFromDB) {
		this.fieldsFromDB = fieldsFromDB;
	}

	public String getStaffFlag() {
		return staffFlag;
	}

	public void setStaffFlag(String staffFlag) {
		this.staffFlag = staffFlag;
	}

	/**
	 * Gets updated date.
	 *
	 * @return the updatedDate  
	 */
	
	public Date getUpdatedDate() {
		return updatedDate;
	}

	
	/**
	 * Sets the updatedDate .
	 *
	 * @param updatedDate 
	 */
	
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
	/**
	 * Gets the conversion rate.
	 *
	 * @return the conversion rate
	 */
	public String getConversionRate() {
		return conversionRate;
	}

	/**
	 * Sets the conversion rate.
	 *
	 * @param conversionRate the new conversion rate
	 */
	public void setConversionRate(String conversionRate) {
		this.conversionRate = conversionRate;
	}

	/**
	 * Gets the checks if is reg biller.
	 *
	 * @return the checks if is reg biller
	 */
	public char getIsRegBiller() {
		return isRegBiller;
	}

	
	
	/**
	 * Sets the checks if is reg biller.
	 *
	 * @param isRegBiller the new checks if is reg biller
	 */
	public void setIsRegBiller(char isRegBiller) {
		this.isRegBiller = isRegBiller;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
/*	public int getId() {
		return id;
	}

	*//**
	 * Sets the id.
	 *
	 * @param id the new id
	 *//*
	public void setId(int id) {
		this.id = id;
	}*/
	
	/**
	 * Gets the biller cd.
	 *
	 * @return the billerCd
	 */
	public String getBillerCd() {
		return billerCd;
	}

	/**
	 * Sets the biller cd.
	 *
	 * @param billerCd the billerCd to set
	 */
	public void setBillerCd(String billerCd) {
		this.billerCd = billerCd;
	}

	/**
	 * Gets the biller desc.
	 *
	 * @return the billerDesc
	 */
	public String getBillerDesc() {
		return billerDesc;
	}

	/**
	 * Sets the biller desc.
	 *
	 * @param billerDesc the billerDesc to set
	 */
	public void setBillerDesc(String billerDesc) {
		this.billerDesc = billerDesc;
	}

	/**
	 * Gets the utility cd.
	 *
	 * @return the utilityCd
	 */
	public String getUtilityCd() {
		return utilityCd;
	}

	/**
	 * Sets the utility cd.
	 *
	 * @param utilityCd the utilityCd to set
	 */
	public void setUtilityCd(String utilityCd) {
		this.utilityCd = utilityCd;
	}

	/**
	 * Gets the utillty type desc.
	 *
	 * @return the utilltyTypeDesc
	 */
	public String getUtilltyTypeDesc() {
		return utilltyTypeDesc;
	}

	/**
	 * Sets the utillty type desc.
	 *
	 * @param utilltyTypeDesc the utilltyTypeDesc to set
	 */
	public void setUtilltyTypeDesc(String utilltyTypeDesc) {
		this.utilltyTypeDesc = utilltyTypeDesc;
	}

	/**
	 * Gets the consumer no.
	 *
	 * @return the consumerNo
	 */
	public String getConsumerNo() {
		return consumerNo;
	}

	/**
	 * Sets the consumer no.
	 *
	 * @param consumerNo the consumerNo to set
	 */
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}

	/**
	 * Gets the consumer desc.
	 *
	 * @return the consumerDesc
	 */
	public String getConsumerDesc() {
		return consumerDesc;
	}

	/**
	 * Sets the consumer desc.
	 *
	 * @param consumerDesc the consumerDesc to set
	 */
	public void setConsumerDesc(String consumerDesc) {
		this.consumerDesc = consumerDesc;
	}

	/**
	 * Gets the biller nick name.
	 *
	 * @return the billerNickName
	 */
	public String getBillerNickName() {
		return billerNickName;
	}

	/**
	 * Sets the biller nick name.
	 *
	 * @param billerNickName the billerNickName to set
	 */
	public void setBillerNickName(String billerNickName) {
		this.billerNickName = billerNickName;
	}

	/**
	 * Gets the debit acct src type.
	 *
	 * @return the debitAcctSrcType
	 */
	public String getDebitAcctSrcType() {
		return debitAcctSrcType;
	}

	/**
	 * Sets the debit acct src type.
	 *
	 * @param debitAcctSrcType the debitAcctSrcType to set
	 */
	public void setDebitAcctSrcType(String debitAcctSrcType) {
		this.debitAcctSrcType = debitAcctSrcType;
	}

	/**
	 * Gets the pay ref.
	 *
	 * @return the payRef
	 */
	public String getPayRef() {
		return payRef;
	}

	/**
	 * Sets the pay ref.
	 *
	 * @param payRef the payRef to set
	 */
	public void setPayRef(String payRef) {
		this.payRef = payRef;
	}

	/**
	 * Gets the checks if is auth req.
	 *
	 * @return the isAuthReq
	 */
	public String getIsAuthReq() {
		return isAuthReq;
	}

	/**
	 * Sets the checks if is auth req.
	 *
	 * @param isAuthReq the isAuthReq to set
	 */
	public void setIsAuthReq(String isAuthReq) {
		this.isAuthReq = isAuthReq;
	}

	/**
	 * Gets the checks if is for sme.
	 *
	 * @return the isForSme
	 */
	public String getIsForSme() {
		return isForSme;
	}

	/**
	 * Sets the checks if is for sme.
	 *
	 * @param isForSme the isForSme to set
	 */
	public void setIsForSme(String isForSme) {
		this.isForSme = isForSme;
	}

	/**
	 * Gets the pay mthd.
	 *
	 * @return the payMthd
	 */
	public String getPayMthd() {
		return payMthd;
	}

	/**
	 * Sets the pay mthd.
	 *
	 * @param payMthd the payMthd to set
	 */
	public void setPayMthd(String payMthd) {
		this.payMthd = payMthd;
	}

	/**
	 * Gets the dt eff from.
	 *
	 * @return the dtEffFrom
	 */
	public Date getDtEffFrom() {
		return dtEffFrom;
	}

	/**
	 * Sets the dt eff from.
	 *
	 * @param dtEffFrom the dtEffFrom to set
	 */
	public void setDtEffFrom(Date dtEffFrom) {
		this.dtEffFrom = dtEffFrom;
	}

	/**
	 * Gets the biller fields.
	 *
	 * @return the billerFields
	 */
	public List<BillerField> getBillerFields() {
		return billerFields;
	}

	/**
	 * Sets the biller fields.
	 *
	 * @param billerFields the billerFields to set
	 */
	public void setBillerFields(List<BillerField> billerFields) {
		this.billerFields = billerFields;
	}


	/**
	 * Gets the biller min pmt.
	 *
	 * @return the billerMinPmt
	 */
	public Double getBillerMinPmt() {
		return billerMinPmt;
	}

	/**
	 * Sets the biller min pmt.
	 *
	 * @param billerMinPmt the billerMinPmt to set
	 */
	public void setBillerMinPmt(Double billerMinPmt) {
		this.billerMinPmt = billerMinPmt;
	}

	/**
	 * Gets the biller max pmt.
	 *
	 * @return the billerMaxPmt
	 */
	public Double getBillerMaxPmt() {
		return billerMaxPmt;
	}

	/**
	 * Sets the biller max pmt.
	 *
	 * @param billerMaxPmt the billerMaxPmt to set
	 */
	public void setBillerMaxPmt(Double billerMaxPmt) {
		this.billerMaxPmt = billerMaxPmt;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public List<String> getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value the value to set
	 */
	public void setValue(List<String> value) {
		this.value = value;
	}

	/**
	 * Gets the ref info.
	 *
	 * @return the refInfo
	 */
	public List<RefInfoTypeVO> getRefInfo() {
		return refInfo;
	}

	/**
	 * Sets the ref info.
	 *
	 * @param refInfo the refInfo to set
	 */
	public void setRefInfo(List<RefInfoTypeVO> refInfo) {
		this.refInfo = refInfo;
	}

	/**
	 * Gets the bank info vo.
	 *
	 * @return the bankInfoVO
	 */
	public BankInfoVO getBankInfoVO() {
		return bankInfoVO;
	}

	/**
	 * Sets the bank info vo.
	 *
	 * @param bankInfoVO the bankInfoVO to set
	 */
	public void setBankInfoVO(BankInfoVO bankInfoVO) {
		this.bankInfoVO = bankInfoVO;
	}

	/**
	 * Gets the biller address.
	 *
	 * @return the billerAddress
	 */
	public AddressVO getBillerAddress() {
		return billerAddress;
	}

	/**
	 * Sets the biller address.
	 *
	 * @param billerAddress the billerAddress to set
	 */
	public void setBillerAddress(AddressVO billerAddress) {
		this.billerAddress = billerAddress;
	}

	/**
	 * Gets the std ins src flag.
	 *
	 * @return the stdInsSrcFlag
	 */
	public String getStdInsSrcFlag() {
		return stdInsSrcFlag;
	}

	/**
	 * Sets the std ins src flag.
	 *
	 * @param stdInsSrcFlag the stdInsSrcFlag to set
	 */
	public void setStdInsSrcFlag(String stdInsSrcFlag) {
		this.stdInsSrcFlag = stdInsSrcFlag;
	}

	/**
	 * Gets the presentment vo.
	 *
	 * @return the presentmentVO
	 */
	public PresentmentVO getPresentmentVO() {
		return presentmentVO;
	}

	/**
	 * Sets the presentment vo.
	 *
	 * @param presentmentVO the presentmentVO to set
	 */
	public void setPresentmentVO(PresentmentVO presentmentVO) {
		this.presentmentVO = presentmentVO;
	}

	/**
	 * Gets the transation info vo.
	 *
	 * @return the transationInfoVO
	 */
	public TransactionInfoVO getTransactionInfoVO() {
		return transactionInfoVO;
	}

	/**
	 * Sets the transation info vo.
	 *
	 * @param transactionInfoVO the new transaction info vo
	 */
	public void setTransactionInfoVO(TransactionInfoVO transactionInfoVO) {
		this.transactionInfoVO = transactionInfoVO;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	/**
	 * Gets the bill payment type.
	 *
	 * @return the billPaymentType
	 */
	public String getBillPaymentType() {
		return billPaymentType;
	}

	/**
	 * Sets the bill payment type.
	 *
	 * @param billPaymentType the billPaymentType to set
	 */
	public void setBillPaymentType(String billPaymentType) {
		this.billPaymentType = billPaymentType;
	}

	/**
	 * Gets the provider.
	 *
	 * @return the provider
	 */
	public String getProvider() {
		return provider;
	}

	/**
	 * Sets the provider.
	 *
	 * @param provider the provider to set
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}

	/**
	 * Gets the topup mobile no.
	 *
	 * @return the topupMobileNo
	 */
	public String getTopupMobileNo() {
		return topupMobileNo;
	}

	/**
	 * Sets the topup mobile no.
	 *
	 * @param topupMobileNo the topupMobileNo to set
	 */
	public void setTopupMobileNo(String topupMobileNo) {
		this.topupMobileNo = topupMobileNo;
	}

	/**
	 * Gets the topup debit account.
	 *
	 * @return the topupDebitAccount
	 */
	public String getTopupDebitAccount() {
		return topupDebitAccount;
	}

	/**
	 * Sets the topup debit account.
	 *
	 * @param topupDebitAccount the topupDebitAccount to set
	 */
	public void setTopupDebitAccount(String topupDebitAccount) {
		this.topupDebitAccount = topupDebitAccount;
	}

	/**
	 * Gets the topup amount.
	 *
	 * @return the topupAmount
	 */
	public String getTopupAmount() {
		return topupAmount;
	}

	/**
	 * Sets the topup amount.
	 *
	 * @param topupAmount the topupAmount to set
	 */
	public void setTopupAmount(String topupAmount) {
		this.topupAmount = topupAmount;
	}

	/**
	 * Gets the post payment allowed.
	 *
	 * @return the postPaymentAllowed
	 */
	public String getPostPaymentAllowed() {
		return postPaymentAllowed;
	}

	/**
	 * Sets the post payment allowed.
	 *
	 * @param postPaymentAllowed the postPaymentAllowed to set
	 */
	public void setPostPaymentAllowed(String postPaymentAllowed) {
		this.postPaymentAllowed = postPaymentAllowed;
	}
	
	/**
	 * Gets the dest acc name.
	 *
	 * @return the dest acc name
	 */
	public String getDestAccName() {
		return destAccName;
	}

	/**
	 * Sets the dest acc name.
	 *
	 * @param destAccName the new dest acc name
	 */
	public void setDestAccName(String destAccName) {
		this.destAccName = destAccName;
	}

	/**
	 * Gets the src account name.
	 *
	 * @return the src account name
	 */
	public String getSrcAccountName() {
		return srcAccountName;
	}

	/**
	 * Sets the src account name.
	 *
	 * @param srcAccountName the new src account name
	 */
	public void setSrcAccountName(String srcAccountName) {
		this.srcAccountName = srcAccountName;
	}

	/**
	 * Gets the txn currency.
	 *
	 * @return the txn currency
	 */
	public String getTxnCurrency() {
		return txnCurrency;
	}

	/**
	 * Sets the txn currency.
	 *
	 * @param txnCurrency the new txn currency
	 */
	public void setTxnCurrency(String txnCurrency) {
		this.txnCurrency = txnCurrency;
	}

	/**
	 * Gets the txn activity.
	 *
	 * @return the txn activity
	 */
	public String getTxnActivity() {
		return txnActivity;
	}

	/**
	 * Sets the txn activity.
	 *
	 * @param txnActivity the new txn activity
	 */
	public void setTxnActivity(String txnActivity) {
		this.txnActivity = txnActivity;
	}

	/**
	 * Gets the txn act status.
	 *
	 * @return the txn act status
	 */
	public String getTxnActStatus() {
		return txnActStatus;
	}

	/**
	 * Sets the txn act status.
	 *
	 * @param txnActStatus the new txn act status
	 */
	public void setTxnActStatus(String txnActStatus) {
		this.txnActStatus = txnActStatus;
	}

	/**
	 * Gets the dest txn amount.
	 *
	 * @return the dest txn amount
	 */
	public double getDestTxnAmount() {
		return destTxnAmount;
	}

	/**
	 * Sets the dest txn amount.
	 *
	 * @param destTxnAmount the new dest txn amount
	 */
	public void setDestTxnAmount(double destTxnAmount) {
		this.destTxnAmount = destTxnAmount;
	}

	/**
	 * Gets the payment details vo.
	 *
	 * @return the payment details vo
	 */
	public PaymentDetailVO getPaymentDetailsVO() {
		return paymentDetailsVO;
	}

	/**
	 * Sets the payment details vo.
	 *
	 * @param paymentDetailsVO the new payment details vo
	 */
	public void setPaymentDetailsVO(PaymentDetailVO paymentDetailsVO) {
		this.paymentDetailsVO = paymentDetailsVO;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the field
	 */
	public FieldVO getField() {
		return field;
	}

	/**
	 * @param field the field to set
	 */
	public void setField(FieldVO field) {
		this.field = field;
	}

	/**
	 * @return the aggId
	 */
	public String getAggId() {
		return aggId;
	}

	/**
	 * @param aggId the aggId to set
	 */
	public void setAggId(String aggId) {
		this.aggId = aggId;
	}

	public Date getNextExcTime() {
		return nextExcTime;
	}

	public void setNextExcTime(Date nextExcTime) {
		this.nextExcTime = nextExcTime;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(String payeeId) {
		this.payeeId = payeeId;
	}

	public String getBillerName() {
		return billerName;
	}

	public void setBillerName(String billerName) {
		this.billerName = billerName;
	}

	/**
	 * @return the hostReference
	 */
	public String getHostReference() {
		return hostReference;
	}

	/**
	 * @param hostReference the hostReference to set
	 */
	public void setHostReference(String hostReference) {
		this.hostReference = hostReference;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * @param hostName the hostName to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public List<TransactionsPostingVO> getTransactionsPosting() {
		return transactionsPosting;
	}

	public void setTransactionsPosting(
			List<TransactionsPostingVO> transactionsPosting) {
		this.transactionsPosting = transactionsPosting;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public CreditCardConstants getCardConstants() {
		return cardConstants;
	}

	public void setCardConstants(CreditCardConstants cardConstants) {
		this.cardConstants = cardConstants;
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public String getStan() {
		return stan;
	}

	public void setStan(String stan) {
		this.stan = stan;
	}

	public String getRetrievalReferenceNumber() {
		return retrievalReferenceNumber;
	}

	public void setRetrievalReferenceNumber(String retrievalReferenceNumber) {
		this.retrievalReferenceNumber = retrievalReferenceNumber;
	}

	public String getCardUtilityCode() {
		return cardUtilityCode;
	}

	public void setCardUtilityCode(String cardUtilityCode) {
		this.cardUtilityCode = cardUtilityCode;
	}

	public String getPaymentSubType() {
		return paymentSubType;
	}

	public void setPaymentSubType(String paymentSubType) {
		this.paymentSubType = paymentSubType;
	}

	/*@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillerPayDetailsVO [paymentType=");
		builder.append(paymentType);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", countryCode=");
		builder.append(countryCode);
		builder.append(", channel=");
		builder.append(channel);
		builder.append(", payeeId=");
		builder.append(payeeId);
		builder.append(", billerName=");
		builder.append(billerName);
		builder.append(", transactionType=");
		builder.append(transactionType);
		builder.append(", cardConstants=");
		builder.append(cardConstants);
		builder.append(", id=");
		builder.append(id);
		builder.append(", uniqueId=");
		builder.append(uniqueId);
		builder.append(", billerCategoryCd=");
		builder.append(billerCategoryCd);
		builder.append(", billerCategoryDesc=");
		builder.append(billerCategoryDesc);
		builder.append(", billerCd=");
		builder.append(billerCd);
		builder.append(", billerDesc=");
		builder.append(billerDesc);
		builder.append(", utilityCd=");
		builder.append(utilityCd);
		builder.append(", utilltyTypeDesc=");
		builder.append(utilltyTypeDesc);
		builder.append(", consumerNo=");
		builder.append(consumerNo);
		builder.append(", consumerDesc=");
		builder.append(consumerDesc);
		builder.append(", custName=");
		builder.append(custName);
		builder.append(", billerNickName=");
		builder.append(billerNickName);
		builder.append(", debitAcctSrcType=");
		builder.append(debitAcctSrcType);
		builder.append(", payRef=");
		builder.append(payRef);
		builder.append(", billPaymentType=");
		builder.append(billPaymentType);
		builder.append(", postPaymentAllowed=");
		builder.append(postPaymentAllowed);
		builder.append(", destAccName=");
		builder.append(destAccName);
		builder.append(", srcAccountName=");
		builder.append(srcAccountName);
		builder.append(", txnCurrency=");
		builder.append(txnCurrency);
		builder.append(", txnActivity=");
		builder.append(txnActivity);
		builder.append(", txnActStatus=");
		builder.append(txnActStatus);
		builder.append(", destTxnAmount=");
		builder.append(destTxnAmount);
		builder.append(", paymentDetailsVO=");
		builder.append(paymentDetailsVO);
		builder.append(", authCode=");
		builder.append(authCode);
		builder.append(", stan=");
		builder.append(stan);
		builder.append(", retrievalReferenceNumber=");
		builder.append(retrievalReferenceNumber);
		builder.append(", cardUtilityCode=");
		builder.append(cardUtilityCode);
		builder.append(", paymentSubType=");
		builder.append(paymentSubType);
		builder.append(", field=");
		builder.append(field);
		builder.append(", aggId=");
		builder.append(aggId);
		builder.append(", updatedDate=");
		builder.append(updatedDate);
		builder.append(", nextExcTime=");
		builder.append(nextExcTime);
		builder.append(", presentMentType=");
		builder.append(presentMentType);
		builder.append(", ApplicationUserID=");
		builder.append(ApplicationUserID);
		builder.append(", ApplicationUserKey=");
		builder.append(ApplicationUserKey);
		builder.append(", transactionsPosting=");
		builder.append(transactionsPosting);
		builder.append(", billerCategoryVO=");
		builder.append(billerCategoryVO);
		builder.append(", isAuthReq=");
		builder.append(isAuthReq);
		builder.append(", isForSme=");
		builder.append(isForSme);
		builder.append(", payMthd=");
		builder.append(payMthd);
		builder.append(", dtEffFrom=");
		builder.append(dtEffFrom);
		builder.append(", billerAddress=");
		builder.append(billerAddress);
		builder.append(", bankInfoVO=");
		builder.append(bankInfoVO);
		builder.append(", presentmentVO=");
		builder.append(presentmentVO);
		builder.append(", transactionInfoVO=");
		builder.append(transactionInfoVO);
		builder.append(", billerFields=");
		builder.append(billerFields);
		builder.append(", billerMinPmt=");
		builder.append(billerMinPmt);
		builder.append(", billerMaxPmt=");
		builder.append(billerMaxPmt);
		builder.append(", value=");
		builder.append(value);
		builder.append(", stdInsSrcFlag=");
		builder.append(stdInsSrcFlag);
		builder.append(", refInfo=");
		builder.append(refInfo);
		builder.append(", isRegBiller=");
		builder.append(isRegBiller);
		builder.append(", merchantCode=");
		builder.append(merchantCode);
		builder.append(", conversionRate=");
		builder.append(conversionRate);
		builder.append(", provider=");
		builder.append(provider);
		builder.append(", topupMobileNo=");
		builder.append(topupMobileNo);
		builder.append(", topupDebitAccount=");
		builder.append(topupDebitAccount);
		builder.append(", topupAmount=");
		builder.append(topupAmount);
		builder.append(", hostReference=");
		builder.append(hostReference);
		builder.append(", hostName=");
		builder.append(hostName);
		builder.append(", mobileNumber=");
		builder.append(mobileNumber);
		builder.append(", emailId=");
		builder.append(emailId);
		builder.append(", staffFlag=");
		builder.append(staffFlag);
		builder.append(", fieldsFromDB=");
		builder.append(fieldsFromDB);
		builder.append("]");
		return builder.toString();
	}*/


	
	 }
