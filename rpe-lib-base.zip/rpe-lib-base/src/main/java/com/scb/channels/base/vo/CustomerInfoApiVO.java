package com.scb.channels.base.vo;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerInfoApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;	

	private NameTypeApiVO name;
	private String dateOfBirth;
	private AddressTypeApiVO address;	

	public NameTypeApiVO getName() {
		return name;
	}
	public void setName(NameTypeApiVO name) {
		this.name = name;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public AddressTypeApiVO getAddress() {
		return address;
	}
	public void setAddress(AddressTypeApiVO address) {
		this.address = address;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "CustomerInfoApiVO [name=" + name + ", dateOfBirth="
				+ dateOfBirth + ", address=" + address + "]";
	}

}
