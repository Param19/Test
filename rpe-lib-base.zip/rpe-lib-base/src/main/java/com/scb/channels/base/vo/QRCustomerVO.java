package com.scb.channels.base.vo;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class QRCustomerVO.
 */
public class QRCustomerVO implements Serializable, Cloneable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -892047849129278899L;
	
	/** The customer id. */
	private String customerId;
	
	/** The customer type. */
	private String customerType;
	
	/** The name. */
	private String name;
	
	/** The date of birth. */
	private String dateOfBirth;
	
	/** The address. */
	private QRAddressVO address;

	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the new customer id
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the customer type.
	 *
	 * @return the customer type
	 */
	public String getCustomerType() {
		return customerType;
	}

	/**
	 * Sets the customer type.
	 *
	 * @param customerType the new customer type
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the date of birth.
	 *
	 * @return the date of birth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * Sets the date of birth.
	 *
	 * @param dateOfBirth the new date of birth
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public QRAddressVO getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(QRAddressVO address) {
		this.address = address;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "QRCustomerVO [customerId=" + customerId + ", customerType="
				+ customerType + ", name=" + name + ", dateOfBirth="
				+ dateOfBirth + ", address=" + address + "]";
	}

	
}
