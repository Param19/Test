/**
 * 
 */
package com.scb.channels.base.vo;


/**
 * The Class AccountListResponseVO.
 *
 * @author 1411807
 */
public class AccountListResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4824393718006501843L;
	
	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;
	
	private AccountListDetailsVO accountListDetails;

	public AccountListDetailsVO getAccountListDetails() {
		return accountListDetails;
	}

	public void setAccountListDetails(AccountListDetailsVO accountListDetails) {
		this.accountListDetails = accountListDetails;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}


}
