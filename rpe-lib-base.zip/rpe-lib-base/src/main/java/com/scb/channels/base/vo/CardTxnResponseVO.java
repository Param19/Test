/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class CardTxnResponseVO.
 *
 * @author 1411807
 */
public class CardTxnResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6651214067227345490L;

	

}
