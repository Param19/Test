package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;


public class QRPaymentMasterCardAcceptor implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2608109783886619089L;

	private String Name;
	
	private String City;
	
	private String State;
	
	private String PostalCode;
	
	private String Country;

	public String getName() {
		return Name;
	}
	@JsonSetter("Name")
	public void setName(String name) {
		Name = name;
	}

	public String getCity() {
		return City;
	}
	@JsonSetter("City")
	public void setCity(String city) {
		City = city;
	}

	public String getState() {
		return State;
	}
	@JsonSetter("State")
	public void setState(String state) {
		State = state;
	}

	public String getPostalCode() {
		return PostalCode;
	}
	@JsonSetter("PostalCode")
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}

	public String getCountry() {
		return Country;
	}
	@JsonSetter("Country")
	public void setCountry(String country) {
		Country = country;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterCardAcceptor [Name=" + Name + ", City=" + City
				+ ", State=" + State + ", PostalCode=" + PostalCode
				+ ", Country=" + Country + "]";
	}


	

}
