package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * The Class PaginationReqVO.
 */
public class PaginationRespVO implements Serializable, Cloneable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7842913387703396477L;

	private BigInteger totRec;

	private BigInteger startIdx;

	private BigInteger endIdx;

	/**
	 * @return the totRec
	 */
	public BigInteger getTotRec() {
		return totRec;
	}

	/**
	 * @param totRec the totRec to set
	 */
	public void setTotRec(BigInteger totRec) {
		this.totRec = totRec;
	}

	/**
	 * @return the startIdx
	 */
	public BigInteger getStartIdx() {
		return startIdx;
	}

	/**
	 * @param startIdx the startIdx to set
	 */
	public void setStartIdx(BigInteger startIdx) {
		this.startIdx = startIdx;
	}

	/**
	 * @return the endIdx
	 */
	public BigInteger getEndIdx() {
		return endIdx;
	}

	/**
	 * @param endIdx the endIdx to set
	 */
	public void setEndIdx(BigInteger endIdx) {
		this.endIdx = endIdx;
	}

	

}
