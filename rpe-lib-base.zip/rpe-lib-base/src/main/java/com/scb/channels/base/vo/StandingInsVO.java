package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * The Class StandingInsVO.
 */
public class StandingInsVO implements Serializable  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7200924271212953009L;
	
	/** The recurrence interval. */
	private String recurrenceInterval;
	
	/** The dt recurrence start. */
	private Date dtRecurrenceStart;
	
	/** The dt recurrence end. */
	private Date dtRecurrenceEnd;
	
	/** The dt recurrence next exec. */
	private Date dtRecurrenceNextExec;
	
	/** The instruction no. */
	private String instructionNo;
	
	/** The recurring. */
	private boolean recurring;
	
	/** The first exec date. */
	private Calendar firstExecDate;
	
	/** The next exec date. */
	private Calendar nextExecDate;
	
	/** The frequency. */
	private String frequency;
	
	/**
	 * Gets the recurrence interval.
	 *
	 * @return the recurrenceInterval
	 */
	public String getRecurrenceInterval() {
		return recurrenceInterval;
	}
	
	/**
	 * Sets the recurrence interval.
	 *
	 * @param recurrenceInterval the recurrenceInterval to set
	 */
	public void setRecurrenceInterval(String recurrenceInterval) {
		this.recurrenceInterval = recurrenceInterval;
	}
	
	/**
	 * Gets the dt recurrence start.
	 *
	 * @return the dtRecurrenceStart
	 */
	public Date getDtRecurrenceStart() {
		return dtRecurrenceStart;
	}
	
	/**
	 * Sets the dt recurrence start.
	 *
	 * @param dtRecurrenceStart the dtRecurrenceStart to set
	 */
	public void setDtRecurrenceStart(Date dtRecurrenceStart) {
		this.dtRecurrenceStart = dtRecurrenceStart;
	}
	
	/**
	 * Gets the dt recurrence end.
	 *
	 * @return the dtRecurrenceEnd
	 */
	public Date getDtRecurrenceEnd() {
		return dtRecurrenceEnd;
	}
	
	/**
	 * Sets the dt recurrence end.
	 *
	 * @param dtRecurrenceEnd the dtRecurrenceEnd to set
	 */
	public void setDtRecurrenceEnd(Date dtRecurrenceEnd) {
		this.dtRecurrenceEnd = dtRecurrenceEnd;
	}
	
	/**
	 * Gets the dt recurrence next exec.
	 *
	 * @return the dtRecurrenceNextExec
	 */
	public Date getDtRecurrenceNextExec() {
		return dtRecurrenceNextExec;
	}
	
	/**
	 * Sets the dt recurrence next exec.
	 *
	 * @param dtRecurrenceNextExec the dtRecurrenceNextExec to set
	 */
	public void setDtRecurrenceNextExec(Date dtRecurrenceNextExec) {
		this.dtRecurrenceNextExec = dtRecurrenceNextExec;
	}
	
	/**
	 * Gets the instruction no.
	 *
	 * @return the instructionNo
	 */
	public String getInstructionNo() {
		return instructionNo;
	}
	
	/**
	 * Sets the instruction no.
	 *
	 * @param instructionNo the instructionNo to set
	 */
	public void setInstructionNo(String instructionNo) {
		this.instructionNo = instructionNo;
	}
	
	/**
	 * Checks if is recurring.
	 *
	 * @return the recurring
	 */
	public boolean isRecurring() {
		return recurring;
	}
	
	/**
	 * Sets the recurring.
	 *
	 * @param recurring the recurring to set
	 */
	public void setRecurring(boolean recurring) {
		this.recurring = recurring;
	}
	
	/**
	 * Gets the first exec date.
	 *
	 * @return the firstExecDate
	 */
	public Calendar getFirstExecDate() {
		return firstExecDate;
	}
	
	/**
	 * Sets the first exec date.
	 *
	 * @param firstExecDate the firstExecDate to set
	 */
	public void setFirstExecDate(Calendar firstExecDate) {
		this.firstExecDate = firstExecDate;
	}
	
	/**
	 * Gets the next exec date.
	 *
	 * @return the nextExecDate
	 */
	public Calendar getNextExecDate() {
		return nextExecDate;
	}
	
	/**
	 * Sets the next exec date.
	 *
	 * @param nextExecDate the nextExecDate to set
	 */
	public void setNextExecDate(Calendar nextExecDate) {
		this.nextExecDate = nextExecDate;
	}
	
	/**
	 * Gets the frequency.
	 *
	 * @return the frequency
	 */
	public String getFrequency() {
		return frequency;
	}
	
	/**
	 * Sets the frequency.
	 *
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	
	


}
