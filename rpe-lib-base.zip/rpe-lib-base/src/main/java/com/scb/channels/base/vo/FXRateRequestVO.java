/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ChequeBookRequestVO.
 *
 * @author 1411807
 */
public class FXRateRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6912254585635401769L;
	
	/** The Currency cd. */
	private String ccyCd;
	
	/** The version. */
	private int version=0;

	

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getCcyCd() {
		return ccyCd;
	}

	public void setCcyCd(String ccyCd) {
		this.ccyCd = ccyCd;
	}	
	
	
	
}
