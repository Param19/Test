package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * Jetco Payment Response
 * 
 * @author 1552545
 * 
 */
public class JetcoPayResponseVO extends BaseVO implements Serializable {

	private static final long serialVersionUID = -5393393857007305625L;
	
	private String bankCode;
	private String bankMessageId;
	private String bankMessageCreationDateTime;
	private String bankTransactionId;
	private String bankTransactionCreationDateTime;
	private String maskedReceiverAccountName;
	private String receiverMobileNumber;
	private String senderAccountNumber;
	private String senderAccountType;
	private String paymentDescription;
	private Double paymentAmount;
	private String paymentCurrency;
	private String transactionCurrency;
	private String senderAccountCurrency;
	private String fxRate;
	private String senderCustomerReferenceId;
	private String senderP2PId;
	private String walletIdentifier;
	private String paymentType;
	private String txnActStatus;
	private String referenceNumber;
	private String hostName;

	private TransactionInfoVO transactionInfo;

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankMessageId() {
		return bankMessageId;
	}

	public void setBankMessageId(String bankMessageId) {
		this.bankMessageId = bankMessageId;
	}

	public String getBankMessageCreationDateTime() {
		return bankMessageCreationDateTime;
	}

	public void setBankMessageCreationDateTime(String bankMessageCreationDateTime) {
		this.bankMessageCreationDateTime = bankMessageCreationDateTime;
	}

	public String getBankTransactionId() {
		return bankTransactionId;
	}

	public void setBankTransactionId(String bankTransactionId) {
		this.bankTransactionId = bankTransactionId;
	}

	public String getBankTransactionCreationDateTime() {
		return bankTransactionCreationDateTime;
	}

	public void setBankTransactionCreationDateTime(String bankTransactionCreationDateTime) {
		this.bankTransactionCreationDateTime = bankTransactionCreationDateTime;
	}

	public String getMaskedReceiverAccountName() {
		return maskedReceiverAccountName;
	}

	public void setMaskedReceiverAccountName(String maskedReceiverAccountName) {
		this.maskedReceiverAccountName = maskedReceiverAccountName;
	}

	public String getReceiverMobileNumber() {
		return receiverMobileNumber;
	}

	public void setReceiverMobileNumber(String receiverMobileNumber) {
		this.receiverMobileNumber = receiverMobileNumber;
	}

	public String getSenderAccountNumber() {
		return senderAccountNumber;
	}

	public void setSenderAccountNumber(String senderAccountNumber) {
		this.senderAccountNumber = senderAccountNumber;
	}

	public String getSenderAccountType() {
		return senderAccountType;
	}

	public void setSenderAccountType(String senderAccountType) {
		this.senderAccountType = senderAccountType;
	}

	public String getPaymentDescription() {
		return paymentDescription;
	}

	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentCurrency() {
		return paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public String getTransactionCurrency() {
		return transactionCurrency;
	}

	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	public String getSenderAccountCurrency() {
		return senderAccountCurrency;
	}

	public void setSenderAccountCurrency(String senderAccountCurrency) {
		this.senderAccountCurrency = senderAccountCurrency;
	}

	public String getFxRate() {
		return fxRate;
	}

	public void setFxRate(String fxRate) {
		this.fxRate = fxRate;
	}

	public String getSenderCustomerReferenceId() {
		return senderCustomerReferenceId;
	}

	public void setSenderCustomerReferenceId(String senderCustomerReferenceId) {
		this.senderCustomerReferenceId = senderCustomerReferenceId;
	}

	public String getSenderP2PId() {
		return senderP2PId;
	}

	public void setSenderP2PId(String senderP2PId) {
		this.senderP2PId = senderP2PId;
	}

	public String getWalletIdentifier() {
		return walletIdentifier;
	}

	public void setWalletIdentifier(String walletIdentifier) {
		this.walletIdentifier = walletIdentifier;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public TransactionInfoVO getTransactionInfo() {
		return transactionInfo;
	}

	public void setTransactionInfo(TransactionInfoVO transactionInfo) {
		this.transactionInfo = transactionInfo;
	}

	public String getTxnActStatus() {
		return txnActStatus;
	}

	public void setTxnActStatus(String txnActStatus) {
		this.txnActStatus = txnActStatus;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

}
