package com.scb.channels.base.vo;

import java.io.Serializable;

public class QRPaymentApiRequestVO implements Serializable {		
	
	private static final long serialVersionUID = 000111L;
	
	private UserContextApiVO userContext;	
	private ClientContextApiVO clientContext;	
	private QRDataApiVO qrData;	
	private QRPaymentInfoApiVO qrPaymentInfo;	
	private CustomerInfoApiVO customerInfo;	
	private MessageContextApiVO messageContext;	
	private ServiceContextApiVO serviceContext;
	
	public UserContextApiVO getUserContext() {
		return userContext;
	}
	public void setUserContext(UserContextApiVO userContext) {
		this.userContext = userContext;
	}
	public ClientContextApiVO getClientContext() {
		return clientContext;
	}
	public void setClientContext(ClientContextApiVO clientContext) {
		this.clientContext = clientContext;
	}
	public QRDataApiVO getQrData() {
		return qrData;
	}
	public void setQrData(QRDataApiVO qrData) {
		this.qrData = qrData;
	}
	public QRPaymentInfoApiVO getQrPaymentInfo() {
		return qrPaymentInfo;
	}
	public void setQrPaymentInfo(QRPaymentInfoApiVO qrPaymentInfo) {
		this.qrPaymentInfo = qrPaymentInfo;
	}
	public CustomerInfoApiVO getCustomerInfo() {
		return customerInfo;
	}
	public void setCustomerInfo(CustomerInfoApiVO customerInfo) {
		this.customerInfo = customerInfo;
	}
	public MessageContextApiVO getMessageContext() {
		return messageContext;
	}
	public void setMessageContext(MessageContextApiVO messageContext) {
		this.messageContext = messageContext;
	}
	public ServiceContextApiVO getServiceContext() {
		return serviceContext;
	}
	public void setServiceContext(ServiceContextApiVO serviceContext) {
		this.serviceContext = serviceContext;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "QRPaymentApiRequestVO [userContext=" + userContext
				+ ", clientContext=" + clientContext + ", qrData=" + qrData
				+ ", qrPaymentInfo=" + qrPaymentInfo + ", customerInfo="
				+ customerInfo + ", messageContext=" + messageContext
				+ ", serviceContext=" + serviceContext + "]";
	}
	
}
