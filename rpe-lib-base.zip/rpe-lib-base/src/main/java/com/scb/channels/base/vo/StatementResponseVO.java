/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * @author 1411807
 *
 */
public class StatementResponseVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2564499042609419459L;

	

}
