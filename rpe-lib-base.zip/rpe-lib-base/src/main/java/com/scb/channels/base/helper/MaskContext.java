/**
 * 
 */
package com.scb.channels.base.helper;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class MaskContext.
 *
 * @author 1411807
 */
public class MaskContext {
	
	/** The maskers list. */
	List<Masker> maskersList = new ArrayList<Masker>();

	/**
	 * Gets the maskers list.
	 *
	 * @return the maskers list
	 */
	public List<Masker> getMaskersList() {
	    return this.maskersList;
	}

	/**
	 * Instantiates a new mask context.
	 *
	 * @param configManager the config manager
	 * @param maskGroup the mask group
	 */
	public MaskContext(List<Masker> maskers) {
	    this.maskersList.addAll(maskers);
    }
}
