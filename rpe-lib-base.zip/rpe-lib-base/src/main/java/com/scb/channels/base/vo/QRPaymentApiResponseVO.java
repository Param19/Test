package com.scb.channels.base.vo;

import java.io.Serializable;

public class QRPaymentApiResponseVO implements Serializable {		
	
	private static final long serialVersionUID = 000111L;	
		
	private String transactionReferenceNo;
	private ServiceContextApiVO serviceContext;
	private MessageContextApiVO messageContext;		
	private StatusTypeApiVO status;	
	private QRAcquirerInfoApiVO acquirer;
	private String authCode;	
	
	public String getTransactionReferenceNo() {
		return transactionReferenceNo;
	}
	public void setTransactionReferenceNo(String transactionReferenceNo) {
		this.transactionReferenceNo = transactionReferenceNo;
	}
	public ServiceContextApiVO getServiceContext() {
		return serviceContext;
	}
	public void setServiceContext(ServiceContextApiVO serviceContext) {
		this.serviceContext = serviceContext;
	}
	public MessageContextApiVO getMessageContext() {
		return messageContext;
	}
	public void setMessageContext(MessageContextApiVO messageContext) {
		this.messageContext = messageContext;
	}
	public StatusTypeApiVO getStatus() {
		return status;
	}
	public void setStatus(StatusTypeApiVO status) {
		this.status = status;
	}
	public QRAcquirerInfoApiVO getAcquirer() {
		return acquirer;
	}
	public void setAcquirer(QRAcquirerInfoApiVO acquirer) {
		this.acquirer = acquirer;
	}
	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "QRPaymentApiResponseVO [transactionReferenceNo="
				+ transactionReferenceNo + ", serviceContext=" + serviceContext
				+ ", messageContext=" + messageContext + ", status=" + status
				+ ", acquirer=" + acquirer + ", authCode=" + authCode + "]";
	}
}
