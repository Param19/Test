/**
 * 
 */
package com.scb.channels.base.vo;


/**
 * The Class ChequeBookResponseVO.
 *
 * @author 1411807
 */
public class FXRateResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1469525769262182812L;
	
	FXRateVO fXRateVO ;

	public FXRateVO getfXRateVO() {
		return fXRateVO;
	}

	public void setfXRateVO(FXRateVO fXRateVO) {
		this.fXRateVO = fXRateVO;
	}

	
	



}
