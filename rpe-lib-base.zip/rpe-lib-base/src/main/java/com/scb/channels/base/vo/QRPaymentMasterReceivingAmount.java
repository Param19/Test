package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentMasterReceivingAmount implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7161155543829484814L;

	private String Value;
	
	private String Currency;

	public String getValue() {
		return Value;
	}
	@JsonSetter("Value")
	public void setValue(String value) {
		Value = value;
	}

	public String getCurrency() {
		return Currency;
	}
	@JsonSetter("Currency")
	public void setCurrency(String currency) {
		Currency = currency;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterReceivingAmount [Value=" + Value + ", Currency="
				+ Currency + "]";
	}
	

}
