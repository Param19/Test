package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

/**
 * The Class ClientVO.
 */
public class ClientVO implements Serializable,Cloneable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5821414739650080487L;
	
	/** The date. */
	private Calendar date;
	
	/** The channel. */
	private String channel;
	
	/** The country. */
	private String country;
	
	/** The language. */
	private String language;
	
	/** The app name. */
	private String appName;
	
	/** The org. */
	private String org;
	
	/** The version. */
	private String version;
	
	/** The session id. */
	private String sessionId;
	
	/** The session id. */
	private String scbSessionId;
	
	/** The environment. */
	private String environment;
	
	/** The client id. */
	private String clientId;
	
	/** The channel type. */
	private String channelType;
	
	/** The ip address. */
	private String ipAddress;
	
	/** The client ip address. */
	private String clientIpAddress;
	
	private String partnerName;
	
	private String partnerType;
	
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	
	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	
	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}
	
	/**
	 * Sets the language.
	 *
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	
	/**
	 * Gets the app name.
	 *
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}
	
	/**
	 * Sets the app name.
	 *
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	/**
	 * Gets the org.
	 *
	 * @return the org
	 */
	public String getOrg() {
		return org;
	}
	
	/**
	 * Sets the org.
	 *
	 * @param org the org to set
	 */
	public void setOrg(String org) {
		this.org = org;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
	/**
	 * Gets the session id.
	 *
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}
	
	/**
	 * Sets the session id.
	 *
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	
	/**
	 * Sets the environment.
	 *
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
	/**
	 * Gets the client id.
	 *
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	
	/**
	 * Sets the client id.
	 *
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public Calendar getDate() {
		return date;
	}
	
	/**
	 * Sets the date.
	 *
	 * @param date the date to set
	 */
	public void setDate(Calendar date) {
		this.date = date;
	}
	
	/**
	 * Gets the channel type.
	 *
	 * @return the channelType
	 */
	public String getChannelType() {
		return channelType;
	}
	
	/**
	 * Sets the channel type.
	 *
	 * @param channelType the channelType to set
	 */
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}
	
	/**
	 * Gets the ip address.
	 *
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}
	
	/**
	 * Sets the ip address.
	 *
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	/**
	 * Gets the client ip address.
	 *
	 * @return the clientIpAddress
	 */
	public String getClientIpAddress() {
		return clientIpAddress;
	}
	
	/**
	 * Sets the client ip address.
	 *
	 * @param clientIpAddress the clientIpAddress to set
	 */
	public void setClientIpAddress(String clientIpAddress) {
		this.clientIpAddress = clientIpAddress;
	}

	/**
	 * @return the scbSessionId
	 */
	public String getScbSessionId() {
		return scbSessionId;
	}

	/**
	 * @param scbSessionId the scbSessionId to set
	 */
	public void setScbSessionId(String scbSessionId) {
		this.scbSessionId = scbSessionId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}
	
	
	
}
