/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author 1470817
 *
 */
public class ApplicationMessageVO implements Serializable {

	/**
	 * constant serial version Id
	 */
	private static final long serialVersionUID = -4334991143099155466L;

	private Long id;

	private String countryCode;
	
	private String channel;
	
	private String componentName;
	private String srmErrorCode;
	private String srmErrorDesc;
	private String compErrorCode;
	private String compErrorDesc;
	private String status;

	private String createdBy;

	private String updatedBy;

	private Timestamp dtCreated;

	private Timestamp dtUpdated;

	public Integer version;
	public String moduleName;
	
	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}

	/**
	 * @param componentName the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	/**
	 * @return the srmErrorCode
	 */
	public String getSrmErrorCode() {
		return srmErrorCode;
	}

	/**
	 * @param srmErrorCode the srmErrorCode to set
	 */
	public void setSrmErrorCode(String srmErrorCode) {
		this.srmErrorCode = srmErrorCode;
	}

	/**
	 * @return the srmErrorDesc
	 */
	public String getSrmErrorDesc() {
		return srmErrorDesc;
	}

	/**
	 * @param srmErrorDesc the srmErrorDesc to set
	 */
	public void setSrmErrorDesc(String srmErrorDesc) {
		this.srmErrorDesc = srmErrorDesc;
	}

	/**
	 * @return the compErrorCode
	 */
	public String getCompErrorCode() {
		return compErrorCode;
	}

	/**
	 * @param compErrorCode the compErrorCode to set
	 */
	public void setCompErrorCode(String compErrorCode) {
		this.compErrorCode = compErrorCode;
	}

	/**
	 * @return the compErrorDesc
	 */
	public String getCompErrorDesc() {
		return compErrorDesc;
	}

	/**
	 * @param compErrorDesc the compErrorDesc to set
	 */
	public void setCompErrorDesc(String compErrorDesc) {
		this.compErrorDesc = compErrorDesc;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the dtCreated
	 */
	public Timestamp getDtCreated() {
		return dtCreated;
	}

	/**
	 * @param dtCreated the dtCreated to set
	 */
	public void setDtCreated(Timestamp dtCreated) {
		this.dtCreated = dtCreated;
	}

	/**
	 * @return the dtUpdated
	 */
	public Timestamp getDtUpdated() {
		return dtUpdated;
	}

	/**
	 * @param dtUpdated the dtUpdated to set
	 */
	public void setDtUpdated(Timestamp dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}     
	
	
	
}
