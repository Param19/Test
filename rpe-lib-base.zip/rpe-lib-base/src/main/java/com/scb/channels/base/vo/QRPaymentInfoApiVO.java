package com.scb.channels.base.vo;

import java.io.Serializable;
import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentInfoApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	private String cardNumber;
	private String paymentDate;
	private XMLGregorianCalendar paymentDateTS;
	private String paymentOriginateCountry;
	private String accountNumber;	
	private String transactionCurrency;
	private String cardEmbossName;
	private String sourceOfFund;	
	private String totalPaymentAmt;
	private String paymentRemarks;
	private String transactionReferenceNumber;
	private String cardProductDesc;
	private String cardExpiryDate;
	private String cardType;
	private String debitAccCurrency;
	private String debitAmount;
	private String debitAmtFxRate;
	private String settlementCurrency;
	private String settlementAmount;
	private String settlementAmtFxRate;
	
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentOriginateCountry() {
		return paymentOriginateCountry;
	}
	public void setPaymentOriginateCountry(String paymentOriginateCountry) {
		this.paymentOriginateCountry = paymentOriginateCountry;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTransactionCurrency() {
		return transactionCurrency;
	}
	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}
	public String getCardEmbossName() {
		return cardEmbossName;
	}
	public void setCardEmbossName(String cardEmbossName) {
		this.cardEmbossName = cardEmbossName;
	}
	public String getSourceOfFund() {
		return sourceOfFund;
	}
	public void setSourceOfFund(String sourceOfFund) {
		this.sourceOfFund = sourceOfFund;
	}
	public String getTotalPaymentAmt() {
		return totalPaymentAmt;
	}
	public void setTotalPaymentAmt(String totalPaymentAmt) {
		this.totalPaymentAmt = totalPaymentAmt;
	}
	public String getPaymentRemarks() {
		return paymentRemarks;
	}
	public void setPaymentRemarks(String paymentRemarks) {
		this.paymentRemarks = paymentRemarks;
	}
	public String getTransactionReferenceNumber() {
		return transactionReferenceNumber;
	}
	public void setTransactionReferenceNumber(String transactionReferenceNumber) {
		this.transactionReferenceNumber = transactionReferenceNumber;
	}
	public String getCardProductDesc() {
		return cardProductDesc;
	}
	public void setCardProductDesc(String cardProductDesc) {
		this.cardProductDesc = cardProductDesc;
	}
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}
	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getDebitAccCurrency() {
		return debitAccCurrency;
	}
	public void setDebitAccCurrency(String debitAccCurrency) {
		this.debitAccCurrency = debitAccCurrency;
	}
	public String getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(String debitAmount) {
		this.debitAmount = debitAmount;
	}
	public String getDebitAmtFxRate() {
		return debitAmtFxRate;
	}
	public void setDebitAmtFxRate(String debitAmtFxRate) {
		this.debitAmtFxRate = debitAmtFxRate;
	}
	public String getSettlementCurrency() {
		return settlementCurrency;
	}
	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}
	public String getSettlementAmount() {
		return settlementAmount;
	}
	public void setSettlementAmount(String settlementAmount) {
		this.settlementAmount = settlementAmount;
	}
	public String getSettlementAmtFxRate() {
		return settlementAmtFxRate;
	}
	public void setSettlementAmtFxRate(String settlementAmtFxRate) {
		this.settlementAmtFxRate = settlementAmtFxRate;
	}
	public XMLGregorianCalendar getPaymentDateTS() {
		return paymentDateTS;
	}
	public void setPaymentDateTS(XMLGregorianCalendar paymentDateTS) {
		this.paymentDateTS = paymentDateTS;
	}
	
	@Override
	public String toString() {
		return "QRPaymentInfoApiVO [cardNumber=" + cardNumber
				+ ", paymentDate=" + paymentDate + ", paymentDateTS="
				+ paymentDateTS + ", paymentOriginateCountry="
				+ paymentOriginateCountry + ", accountNumber=" + accountNumber
				+ ", transactionCurrency=" + transactionCurrency
				+ ", cardEmbossName=" + cardEmbossName + ", sourceOfFund="
				+ sourceOfFund + ", totalPaymentAmt=" + totalPaymentAmt
				+ ", paymentRemarks=" + paymentRemarks
				+ ", transactionReferenceNumber=" + transactionReferenceNumber
				+ ", cardProductDesc=" + cardProductDesc + ", cardExpiryDate="
				+ cardExpiryDate + ", cardType=" + cardType
				+ ", debitAccCurrency=" + debitAccCurrency + ", debitAmount="
				+ debitAmount + ", debitAmtFxRate=" + debitAmtFxRate
				+ ", settlementCurrency=" + settlementCurrency
				+ ", settlementAmount=" + settlementAmount
				+ ", settlementAmtFxRate=" + settlementAmtFxRate + "]";
	}
	
}
