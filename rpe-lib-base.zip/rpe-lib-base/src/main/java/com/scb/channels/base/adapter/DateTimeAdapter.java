/**
 * 
 */
package com.scb.channels.base.adapter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.scb.channels.base.exception.BaseException;

/**
 * @author 1411807
 *
 */
public class DateTimeAdapter extends XmlAdapter<String, XMLGregorianCalendar> {

	private static final String YYYY_MM_DD_T_HH_MM_SS_SSS_Z = "yyyy-MM-dd'T'HH:mm:ss.sssZ";

	@Override
	public String  marshal(XMLGregorianCalendar v) throws BaseException {
		if (v != null) {
			DateFormat df = new SimpleDateFormat(YYYY_MM_DD_T_HH_MM_SS_SSS_Z){
				 public StringBuffer format(Date date, StringBuffer toAppendTo, java.text.FieldPosition pos) {
			            StringBuffer toFix = super.format(date, toAppendTo, pos);
			            return toFix.insert(toFix.length()-2, ':');
			        };
			};
			return df.format(v.toGregorianCalendar().getTime());
		}
		return null;
	}

	@Override
	public XMLGregorianCalendar unmarshal(String v) throws DatatypeConfigurationException  {
		if (v !=null) {
			GregorianCalendar c = new GregorianCalendar();
			try{
				DateFormat df = new SimpleDateFormat(YYYY_MM_DD_T_HH_MM_SS_SSS_Z);
				c.setTime(df.parse(v));
			} catch (Exception e) {
				c.setTime(DatatypeConverter.parseDateTime(v).getTime());
			}
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		}
		return null;
	}
	
	/*public static void main(String[] args) throws DatatypeConfigurationException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssZ"){
			 public StringBuffer format(Date date, StringBuffer toAppendTo, java.text.FieldPosition pos) {
		            StringBuffer toFix = super.format(date, toAppendTo, pos);
		            return toFix.insert(toFix.length()-2, ':');
		        };
		};
	}
*/
}
