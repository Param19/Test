package com.scb.channels.base.vo;

import java.util.Calendar;

public class PinChangeStatusResponseVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7843059156814412067L;
	
	/** The login time. */
	private Calendar loginTime;

	/** The last login time. */
	private Calendar lastLoginTime;
	
	/** The user status. */
	private String userStatus;

	/** The login session id. */
	private String loginSessionId;

	/** The value code. */
	private String valueCode;

	/** The status cd. */
	private String statusCd;
	

	public Calendar getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Calendar loginTime) {
		this.loginTime = loginTime;
	}

	public Calendar getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Calendar lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getLoginSessionId() {
		return loginSessionId;
	}

	public void setLoginSessionId(String loginSessionId) {
		this.loginSessionId = loginSessionId;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}
