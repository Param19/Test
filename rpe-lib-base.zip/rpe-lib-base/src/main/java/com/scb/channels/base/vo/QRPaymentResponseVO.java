package com.scb.channels.base.vo;

import java.io.Serializable;

public class QRPaymentResponseVO extends BaseVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -611218699245134345L;

	private QRPaymentDetailVO qrPaymentDetailVO;

	public QRPaymentDetailVO getQrPaymentDetailVO() {
		return qrPaymentDetailVO;
	}

	public void setQrPaymentDetailVO(QRPaymentDetailVO qrPaymentDetailVO) {
		this.qrPaymentDetailVO = qrPaymentDetailVO;
	}

	@Override
	public String toString() {
		return "QRPaymentResponseVO [qrPaymentDetailVO=" + qrPaymentDetailVO
				+ "]";
	}

	
	
	
}
