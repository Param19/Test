/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.List;


/**
 * This class holder request Information.
 *
 * @author 1411807
 */
public class BeneficiaryResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7580475855693479528L;
	
	/** The exception message. */
	private String exceptionMessage;
	
	/** The beneficiary list. */
	private List<BeneficiaryVO> beneficiaryList;

	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;
	
	
	/**
	 * Gets the exception message.
	 *
	 * @return the exception message
	 */
	public String getExceptionMessage() {
		return exceptionMessage;
	}


	/**
	 * Gets the beneficiary list.
	 *
	 * @return the beneficiaryList
	 */
	public List<BeneficiaryVO> getBeneficiaryList() {
		return beneficiaryList;
	}


	/**
	 * Sets the beneficiary list.
	 *
	 * @param beneficiaryList the beneficiaryList to set
	 */
	public void setBeneficiaryList(List<BeneficiaryVO> beneficiaryList) {
		this.beneficiaryList = beneficiaryList;
	}


	/**
	 * Sets the exception message.
	 *
	 * @param exceptionMessage the exceptionMessage to set
	 */
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String getValueCode() {
		return valueCode;
	}


	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}


	public String getStatusCd() {
		return statusCd;
	}


	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}




}
