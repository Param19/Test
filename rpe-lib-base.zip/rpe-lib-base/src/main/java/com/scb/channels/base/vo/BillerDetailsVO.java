package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * The Class BillerDetailsVO.
 */
public class BillerDetailsVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1589109947509291826L;

	/** The biller cd. */
	private String billerCd;
	
	/** The nickname. */
	private String nickname;
	
	private String billerName;
	
	private String billerRegionalName;
	
	private String website;
	
	private String email;
	
	private String phone;
	
	private String category;
	
	private String stmtBankCode;
	
	private List<ServiceTypeVO> serviceTypeList;
	
	/** The biller desc. */
	private String billerDesc;
	
	/** The utility cd. */
	private String utilityCd;
	
	/** The utillty type desc. */
	private String utilltyTypeDesc;
	
	/** The consumer no. */
	private String consumerNo;
	
	/** The consumer desc. */
	private String consumerDesc;
	
	/** The biller nick name. */
	private String billerNickName;
	
	/** The debit acct src type. */
	private String debitAcctSrcType;
	
	/** The pay ref. */
	private String payRef;
	
	/** The is auth req. */
	private String isAuthReq;
	
	/** The is for sme. */
	private String isForSme;
	
	/** The pay mthd. */
	private Integer payMthd;
	
	/** The dt eff from. */
	private Date dtEffFrom;
	
	
	/** The address1. */
	private String address1;
	
	/** The address2. */
	private String address2;
	
	/** The address3. */
	private String address3;
	
	/** The city. */
	private String city;
	
	/** The state. */
	private String state;
	
	/** The zip code. */
	private String zipCode;
	
	/** The country. */
	private String country;
	
	/** The account number. */
	private String accountNumber;
	
	/** The universal acc number. */
	private String universalAccNumber;
	
	/** The product code. */
	private String productCode;
	
	/** The acc type. */
	private String accType;
	
	/** The currency. */
	private String currency;
	
	/** The memo. */
	private String memo;
	
	/** The bank name. */
	private String bankName;
	
	/** The branch name. */
	private String branchName;
	
	/** The bank address1. */
	private String bankAddress1;
	
	/** The bank address2. */
	private String bankAddress2;
	
	/** The bank address3. */
	private String bankAddress3;
	
	/** The bank city. */
	private String bankCity;
	
	/** The bank state. */
	private String bankState;
	
	/** The bank zip code. */
	private String bankZipCode;
	
	/** The bank country. */
	private String bankCountry;
	
	/** The rounting info type. */
	private List<RountingInfoVO> rountingInfoType;
	
	/** The biller fields. */
	private List<BillerField> billerFields;
	
	/** The txn type cd. */
	private String txnTypeCd;
	
	/** The biller min pmt. */
	private Double billerMinPmt;
	
	/** The biller max pmt. */
	private Double billerMaxPmt;
	
	/** The value. */
	private List<String> value;
	
	/** The due dt. */
	private Date dueDt;
	
	/** The min amt. */
	private Double minAmt;
	
	/** The amt. */
	private double amt;
	
	/** The min amt aft due dt. */
	private Double minAmtAftDueDt;
	
	/** The amt aft due dt. */
	private double amtAftDueDt;
	
	/** The txn days bfr due dt. */
	private Integer txnDaysBfrDueDt;
	
	/** The txn days aft due dt. */
	private Integer txnDaysAftDueDt;
	
	/** The presentment avl. */
	private String presentmentAvl;
	
	/** The post avl. */
	private String postAvl;
	
	/** The service indicator. */
	private Integer serviceIndicator;
	
	/**
	 * Gets the nickname.
	 *
	 * @return the nickname
	 */
	public String getNickname() {
		return nickname;
	}

	/**
	 * Sets the nickname.
	 *
	 * @param nickname the new nickname
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	
	/**
	 * Gets the biller cd.
	 *
	 * @return the billerCd
	 */
	public String getBillerCd() {
		return billerCd;
	}
	
	/**
	 * Sets the biller cd.
	 *
	 * @param billerCd the billerCd to set
	 */
	public void setBillerCd(String billerCd) {
		this.billerCd = billerCd;
	}
	
	/**
	 * Gets the biller desc.
	 *
	 * @return the billerDesc
	 */
	public String getBillerDesc() {
		return billerDesc;
	}
	
	/**
	 * Sets the biller desc.
	 *
	 * @param billerDesc the billerDesc to set
	 */
	public void setBillerDesc(String billerDesc) {
		this.billerDesc = billerDesc;
	}
	
	/**
	 * Gets the utility cd.
	 *
	 * @return the utilityCd
	 */
	public String getUtilityCd() {
		return utilityCd;
	}
	
	/**
	 * Sets the utility cd.
	 *
	 * @param utilityCd the utilityCd to set
	 */
	public void setUtilityCd(String utilityCd) {
		this.utilityCd = utilityCd;
	}
	
	/**
	 * Gets the utillty type desc.
	 *
	 * @return the utilltyTypeDesc
	 */
	public String getUtilltyTypeDesc() {
		return utilltyTypeDesc;
	}
	
	/**
	 * Sets the utillty type desc.
	 *
	 * @param utilltyTypeDesc the utilltyTypeDesc to set
	 */
	public void setUtilltyTypeDesc(String utilltyTypeDesc) {
		this.utilltyTypeDesc = utilltyTypeDesc;
	}
	
	/**
	 * Gets the consumer no.
	 *
	 * @return the consumerNo
	 */
	public String getConsumerNo() {
		return consumerNo;
	}
	
	/**
	 * Sets the consumer no.
	 *
	 * @param consumerNo the consumerNo to set
	 */
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}
	
	/**
	 * Gets the consumer desc.
	 *
	 * @return the consumerDesc
	 */
	public String getConsumerDesc() {
		return consumerDesc;
	}
	
	/**
	 * Sets the consumer desc.
	 *
	 * @param consumerDesc the consumerDesc to set
	 */
	public void setConsumerDesc(String consumerDesc) {
		this.consumerDesc = consumerDesc;
	}
	
	/**
	 * Gets the biller nick name.
	 *
	 * @return the billerNickName
	 */
	public String getBillerNickName() {
		return billerNickName;
	}
	
	/**
	 * Sets the biller nick name.
	 *
	 * @param billerNickName the billerNickName to set
	 */
	public void setBillerNickName(String billerNickName) {
		this.billerNickName = billerNickName;
	}
	
	/**
	 * Gets the pay ref.
	 *
	 * @return the payRef
	 */
	public String getPayRef() {
		return payRef;
	}
	
	/**
	 * Sets the pay ref.
	 *
	 * @param payRef the payRef to set
	 */
	public void setPayRef(String payRef) {
		this.payRef = payRef;
	}
	
	/**
	 * Gets the checks if is auth req.
	 *
	 * @return the isAuthReq
	 */
	public String getIsAuthReq() {
		return isAuthReq;
	}
	
	/**
	 * Sets the checks if is auth req.
	 *
	 * @param isAuthReq the isAuthReq to set
	 */
	public void setIsAuthReq(String isAuthReq) {
		this.isAuthReq = isAuthReq;
	}
	
	/**
	 * Gets the checks if is for sme.
	 *
	 * @return the isForSme
	 */
	public String getIsForSme() {
		return isForSme;
	}
	
	/**
	 * Sets the checks if is for sme.
	 *
	 * @param isForSme the isForSme to set
	 */
	public void setIsForSme(String isForSme) {
		this.isForSme = isForSme;
	}
	
	/**
	 * Gets the pay mthd.
	 *
	 * @return the payMthd
	 */
	public Integer getPayMthd() {
		return payMthd;
	}
	
	/**
	 * Sets the pay mthd.
	 *
	 * @param payMthd the payMthd to set
	 */
	public void setPayMthd(Integer payMthd) {
		this.payMthd = payMthd;
	}
	
	/**
	 * Gets the dt eff from.
	 *
	 * @return the dtEffFrom
	 */
	public Date getDtEffFrom() {
		return dtEffFrom;
	}
	
	/**
	 * Sets the dt eff from.
	 *
	 * @param dtEffFrom the dtEffFrom to set
	 */
	public void setDtEffFrom(Date dtEffFrom) {
		this.dtEffFrom = dtEffFrom;
	}
	
	/**
	 * Gets the address1.
	 *
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}
	
	/**
	 * Sets the address1.
	 *
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	
	/**
	 * Gets the address2.
	 *
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}
	
	/**
	 * Sets the address2.
	 *
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	
	/**
	 * Gets the address3.
	 *
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}
	
	/**
	 * Sets the address3.
	 *
	 * @param address3 the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	
	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * Sets the city.
	 *
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	
	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	
	/**
	 * Sets the state.
	 *
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * Gets the zip code.
	 *
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}
	
	/**
	 * Sets the zip code.
	 *
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	
	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	
	/**
	 * Gets the account number.
	 *
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	
	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	/**
	 * Gets the universal acc number.
	 *
	 * @return the universalAccNumber
	 */
	public String getUniversalAccNumber() {
		return universalAccNumber;
	}
	
	/**
	 * Sets the universal acc number.
	 *
	 * @param universalAccNumber the universalAccNumber to set
	 */
	public void setUniversalAccNumber(String universalAccNumber) {
		this.universalAccNumber = universalAccNumber;
	}
	
	/**
	 * Gets the product code.
	 *
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}
	
	/**
	 * Sets the product code.
	 *
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	/**
	 * Gets the acc type.
	 *
	 * @return the accType
	 */
	public String getAccType() {
		return accType;
	}
	
	/**
	 * Sets the acc type.
	 *
	 * @param accType the accType to set
	 */
	public void setAccType(String accType) {
		this.accType = accType;
	}
	
	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	
	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	/**
	 * Gets the memo.
	 *
	 * @return the memo
	 */
	public String getMemo() {
		return memo;
	}
	
	/**
	 * Sets the memo.
	 *
	 * @param memo the memo to set
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}
	
	/**
	 * Gets the bank name.
	 *
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}
	
	/**
	 * Sets the bank name.
	 *
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	/**
	 * Gets the branch name.
	 *
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}
	
	/**
	 * Gets the rounting info type.
	 *
	 * @return the rounting info type
	 */
	public List<RountingInfoVO> getRountingInfoType() {
		return rountingInfoType;
	}

	/**
	 * Sets the rounting info type.
	 *
	 * @param rountingInfoType the new rounting info type
	 */
	public void setRountingInfoType(List<RountingInfoVO> rountingInfoType) {
		this.rountingInfoType = rountingInfoType;
	}

	/**
	 * Sets the branch name.
	 *
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	/**
	 * Gets the bank address1.
	 *
	 * @return the bankAddress1
	 */
	public String getBankAddress1() {
		return bankAddress1;
	}
	
	/**
	 * Sets the bank address1.
	 *
	 * @param bankAddress1 the bankAddress1 to set
	 */
	public void setBankAddress1(String bankAddress1) {
		this.bankAddress1 = bankAddress1;
	}
	
	/**
	 * Gets the bank address2.
	 *
	 * @return the bankAddress2
	 */
	public String getBankAddress2() {
		return bankAddress2;
	}
	
	/**
	 * Sets the bank address2.
	 *
	 * @param bankAddress2 the bankAddress2 to set
	 */
	public void setBankAddress2(String bankAddress2) {
		this.bankAddress2 = bankAddress2;
	}
	
	/**
	 * Gets the bank address3.
	 *
	 * @return the bankAddress3
	 */
	public String getBankAddress3() {
		return bankAddress3;
	}
	
	/**
	 * Sets the bank address3.
	 *
	 * @param bankAddress3 the bankAddress3 to set
	 */
	public void setBankAddress3(String bankAddress3) {
		this.bankAddress3 = bankAddress3;
	}
	
	/**
	 * Gets the bank city.
	 *
	 * @return the bankCity
	 */
	public String getBankCity() {
		return bankCity;
	}
	
	/**
	 * Sets the bank city.
	 *
	 * @param bankCity the bankCity to set
	 */
	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}
	
	/**
	 * Gets the bank state.
	 *
	 * @return the bankState
	 */
	public String getBankState() {
		return bankState;
	}
	
	/**
	 * Sets the bank state.
	 *
	 * @param bankState the bankState to set
	 */
	public void setBankState(String bankState) {
		this.bankState = bankState;
	}
	
	/**
	 * Gets the bank zip code.
	 *
	 * @return the bankZipCode
	 */
	public String getBankZipCode() {
		return bankZipCode;
	}
	
	/**
	 * Sets the bank zip code.
	 *
	 * @param bankZipCode the bankZipCode to set
	 */
	public void setBankZipCode(String bankZipCode) {
		this.bankZipCode = bankZipCode;
	}
	
	/**
	 * Gets the bank country.
	 *
	 * @return the bankCountry
	 */
	public String getBankCountry() {
		return bankCountry;
	}
	
	/**
	 * Sets the bank country.
	 *
	 * @param bankCountry the bankCountry to set
	 */
	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}
	
	
	/**
	 * Gets the biller fields.
	 *
	 * @return the billerFields
	 */
	public List<BillerField> getBillerFields() {
		return billerFields;
	}
	
	/**
	 * Sets the biller fields.
	 *
	 * @param billerFields the billerFields to set
	 */
	public void setBillerFields(List<BillerField> billerFields) {
		this.billerFields = billerFields;
	}
	
	/**
	 * Gets the txn type cd.
	 *
	 * @return the txnTypeCd
	 */
	public String getTxnTypeCd() {
		return txnTypeCd;
	}
	
	/**
	 * Sets the txn type cd.
	 *
	 * @param txnTypeCd the txnTypeCd to set
	 */
	public void setTxnTypeCd(String txnTypeCd) {
		this.txnTypeCd = txnTypeCd;
	}
	
	/**
	 * Gets the biller min pmt.
	 *
	 * @return the billerMinPmt
	 */
	public Double getBillerMinPmt() {
		return billerMinPmt;
	}
	
	/**
	 * Sets the biller min pmt.
	 *
	 * @param billerMinPmt the billerMinPmt to set
	 */
	public void setBillerMinPmt(Double billerMinPmt) {
		this.billerMinPmt = billerMinPmt;
	}
	
	/**
	 * Gets the biller max pmt.
	 *
	 * @return the billerMaxPmt
	 */
	public Double getBillerMaxPmt() {
		return billerMaxPmt;
	}
	
	/**
	 * Sets the biller max pmt.
	 *
	 * @param billerMaxPmt the billerMaxPmt to set
	 */
	public void setBillerMaxPmt(Double billerMaxPmt) {
		this.billerMaxPmt = billerMaxPmt;
	}
	
	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public List<String> getValue() {
		return value;
	}
	
	/**
	 * Sets the value.
	 *
	 * @param value the value to set
	 */
	public void setValue(List<String> value) {
		this.value = value;
	}
	
	/**
	 * Gets the debit acct src type.
	 *
	 * @return the debitAcctSrcType
	 */
	public String getDebitAcctSrcType() {
		return debitAcctSrcType;
	}
	
	/**
	 * Sets the debit acct src type.
	 *
	 * @param debitAcctSrcType the debitAcctSrcType to set
	 */
	public void setDebitAcctSrcType(String debitAcctSrcType) {
		this.debitAcctSrcType = debitAcctSrcType;
	}
	
	/**
	 * Gets the due dt.
	 *
	 * @return the dueDt
	 */
	public Date getDueDt() {
		return dueDt;
	}
	
	/**
	 * Sets the due dt.
	 *
	 * @param dueDt the dueDt to set
	 */
	public void setDueDt(Date dueDt) {
		this.dueDt = dueDt;
	}
	
	/**
	 * Gets the min amt.
	 *
	 * @return the minAmt
	 */
	public Double getMinAmt() {
		return minAmt;
	}
	
	/**
	 * Sets the min amt.
	 *
	 * @param minAmt the minAmt to set
	 */
	public void setMinAmt(Double minAmt) {
		this.minAmt = minAmt;
	}
	
	/**
	 * Gets the amt.
	 *
	 * @return the amt
	 */
	public double getAmt() {
		return amt;
	}
	
	/**
	 * Sets the amt.
	 *
	 * @param amt the amt to set
	 */
	public void setAmt(double amt) {
		this.amt = amt;
	}
	
	/**
	 * Gets the min amt aft due dt.
	 *
	 * @return the minAmtAftDueDt
	 */
	public Double getMinAmtAftDueDt() {
		return minAmtAftDueDt;
	}
	
	/**
	 * Sets the min amt aft due dt.
	 *
	 * @param minAmtAftDueDt the minAmtAftDueDt to set
	 */
	public void setMinAmtAftDueDt(Double minAmtAftDueDt) {
		this.minAmtAftDueDt = minAmtAftDueDt;
	}
	
	/**
	 * Gets the amt aft due dt.
	 *
	 * @return the amtAftDueDt
	 */
	public double getAmtAftDueDt() {
		return amtAftDueDt;
	}
	
	/**
	 * Sets the amt aft due dt.
	 *
	 * @param amtAftDueDt the amtAftDueDt to set
	 */
	public void setAmtAftDueDt(double amtAftDueDt) {
		this.amtAftDueDt = amtAftDueDt;
	}
	
	/**
	 * Gets the txn days bfr due dt.
	 *
	 * @return the txnDaysBfrDueDt
	 */
	public Integer getTxnDaysBfrDueDt() {
		return txnDaysBfrDueDt;
	}
	
	/**
	 * Sets the txn days bfr due dt.
	 *
	 * @param txnDaysBfrDueDt the txnDaysBfrDueDt to set
	 */
	public void setTxnDaysBfrDueDt(Integer txnDaysBfrDueDt) {
		this.txnDaysBfrDueDt = txnDaysBfrDueDt;
	}
	
	/**
	 * Gets the txn days aft due dt.
	 *
	 * @return the txnDaysAftDueDt
	 */
	public Integer getTxnDaysAftDueDt() {
		return txnDaysAftDueDt;
	}
	
	/**
	 * Sets the txn days aft due dt.
	 *
	 * @param txnDaysAftDueDt the txnDaysAftDueDt to set
	 */
	public void setTxnDaysAftDueDt(Integer txnDaysAftDueDt) {
		this.txnDaysAftDueDt = txnDaysAftDueDt;
	}

	/**
	 * Gets the presentment avl.
	 *
	 * @return the presentmentAvl
	 */
	public String getPresentmentAvl() {
		return presentmentAvl;
	}

	/**
	 * Sets the presentment avl.
	 *
	 * @param presentmentAvl the presentmentAvl to set
	 */
	public void setPresentmentAvl(String presentmentAvl) {
		this.presentmentAvl = presentmentAvl;
	}

	/**
	 * Gets the post avl.
	 *
	 * @return the postAvl
	 */
	public String getPostAvl() {
		return postAvl;
	}

	/**
	 * Sets the post avl.
	 *
	 * @param postAvl the postAvl to set
	 */
	public void setPostAvl(String postAvl) {
		this.postAvl = postAvl;
	}

	/**
	 * Gets the service indicator.
	 *
	 * @return the serviceIndicator
	 */
	public Integer getServiceIndicator() {
		return serviceIndicator;
	}

	/**
	 * Sets the service indicator.
	 *
	 * @param serviceIndicator the serviceIndicator to set
	 */
	public void setServiceIndicator(Integer serviceIndicator) {
		this.serviceIndicator = serviceIndicator;
	}

	/**
	 * @return the billerName
	 */
	public String getBillerName() {
		return billerName;
	}

	/**
	 * @param billerName the billerName to set
	 */
	public void setBillerName(String billerName) {
		this.billerName = billerName;
	}

	/**
	 * @return the billerRegionalName
	 */
	public String getBillerRegionalName() {
		return billerRegionalName;
	}

	/**
	 * @param billerRegionalName the billerRegionalName to set
	 */
	public void setBillerRegionalName(String billerRegionalName) {
		this.billerRegionalName = billerRegionalName;
	}

	/**
	 * @return the website
	 */
	public String getWebsite() {
		return website;
	}

	/**
	 * @param website the website to set
	 */
	public void setWebsite(String website) {
		this.website = website;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the stmtBankCode
	 */
	public String getStmtBankCode() {
		return stmtBankCode;
	}

	/**
	 * @param stmtBankCode the stmtBankCode to set
	 */
	public void setStmtBankCode(String stmtBankCode) {
		this.stmtBankCode = stmtBankCode;
	}

	/**
	 * @return the serviceTypeList
	 */
	public List<ServiceTypeVO> getServiceTypeList() {
		return serviceTypeList;
	}

	/**
	 * @param serviceTypeList the serviceTypeList to set
	 */
	public void setServiceTypeList(List<ServiceTypeVO> serviceTypeList) {
		this.serviceTypeList = serviceTypeList;
	}
	
	
	
}
