package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class BillerCategoryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 540747127491259210L;
	
	private Integer id;
	
	private String categoryId;
	private String categoryName;	
	private String statusCode;
	private String countryCode;	
	private String createdBy;
	private String updatedBy;
	
	private Timestamp dateCreated;
	private Timestamp dateUpdated;
	
	private String channel ;
	private int version;
	
	/** private BillerVO billerVO;*/

	private Set<BillerVO> billers = 	new HashSet<BillerVO>(0);
		
	
	public Set<BillerVO> getBillers() {
		return billers;
	}
	public void setBillers(Set<BillerVO> billers) {
		this.billers = billers;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
 	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Timestamp dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Timestamp getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(Timestamp dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	 
	
	/*public BillerVO getBillerVO() {
		return billerVO;
	}
	public void setBillerVO(BillerVO billerVO) {
		this.billerVO = billerVO;
	}*/
	
	

}
