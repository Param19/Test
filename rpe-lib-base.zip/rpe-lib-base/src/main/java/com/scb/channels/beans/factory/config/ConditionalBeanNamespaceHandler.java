package com.scb.channels.beans.factory.config;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

public class ConditionalBeanNamespaceHandler extends NamespaceHandlerSupport {

	@Override
	public void init() {
		super.registerBeanDefinitionParser("cond", new ConditionalBeanDefinitionParser());
	}

}
