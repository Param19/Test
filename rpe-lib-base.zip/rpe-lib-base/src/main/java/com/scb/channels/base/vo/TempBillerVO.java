package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.scb.channels.base.helper.CommonConstants;

/**
 * @author 1460693
 *<p> temporary Biller List table Vo
 */
public class TempBillerVO implements Serializable,Cloneable {
	 
	private static final long serialVersionUID = 3316301894688982259L;
	
	private int tempBillerId;
	/** Biller id **/
	private String billerUniqueId="";
	/**   billerTypeCd one to many reference **/
	
	private String billerTypeCode="";
	
	/**  ctryCd **/
	private String countryCode="";	
	
	/**  channelId **/
	
	private String channel="";
	
	/** BilerCd **/
	private String billerId="";
	
	/** billerDesc  * */
	private String billerDesc="";
	
	/** billerName  * */
	private String billerShortName="";
	
	

	/** statusCd  * */
	private String statusCode="";
	
	/** paymentType  * */
	
	private String paymentType="";
	
	/** aggregatePaymentCode  * */
	private String aggregatePaymentCode="";
	
	/** currency  * */
	private String currency="";
	
	/** defaultAmount  * */
	private Double defaultAmount;
	
	/** minAmount  * */
	private Double minimumAmount;
	
	/** maxAmount  * */
	private Double maximumAmount;
	
	/** billPresentmentType  * */
	private String billPresentmentType;
	
 	private String billerProductName;
	/** createdBy  * */
	private String createdBy=CommonConstants.SYSTEM;
	
	/** updBy  * */
	private String updatedBy=CommonConstants.SYSTEM;
 	
	 
	/** dateCreated  * */
	private Timestamp dateCreated=new Timestamp(System.currentTimeMillis());
	
	/** dateUpdated  * */
	private Timestamp dateUpdated=new Timestamp(System.currentTimeMillis());


	private int version=1;
	
	
	
	public TempBillerCategoryVO categorytype;
	
	private Set<TempBillerField> billerFields =new HashSet<TempBillerField>(0);
	/**
	 * aggFetchFailedBillers
	 */
	private Set<String> aggFetchFailedBillers=new HashSet<String>();
	
	private String isOnline;
	
		/**
	 * @return the isOnline
	 */
	public String getIsOnline() {
		return isOnline;
	}

	/**
	 * @param isOnline the isOnline to set
	 */
	public void setIsOnline(String isOnline) {
		this.isOnline = isOnline;
	}

		/**
	 * @return the aggFetchFailedBillers
	 */
	public Set<String> getAggFetchFailedBillers() {
		return aggFetchFailedBillers;
	}

	/**
	 * @param aggFetchFailedBillers the aggFetchFailedBillers to set
	 */
	public void setAggFetchFailedBillers(Set<String> aggFetchFailedBillers) {
		this.aggFetchFailedBillers = aggFetchFailedBillers;
	}

		public String getBillerProductName() {
		return billerProductName;
	}

	public void setBillerProductName(String billerProductName) {
		this.billerProductName = billerProductName;
	}

	
	
	 
	 

	

	public Set<TempBillerField> getBillerFields() {
		return billerFields;
	}

	public void setBillerFields(Set<TempBillerField> billerFields) {
		this.billerFields = billerFields;
	}

	 

	public TempBillerCategoryVO getCategorytype() {
		return categorytype;
	}

	public void setCategorytype(TempBillerCategoryVO categorytype) {
		this.categorytype = categorytype;
	}

	 

	public int getTempBillerId() {
		return tempBillerId;
	}

	public void setTempBillerId(int tempBillerId) {
		this.tempBillerId = tempBillerId;
	}

	public String getBillerUniqueId() {
		return billerUniqueId;
	}

	public void setBillerUniqueId(String billerUniqueId) {
		this.billerUniqueId = billerUniqueId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getBillerDesc() {
		return billerDesc;
	}

	public void setBillerDesc(String billerDesc) {
		this.billerDesc = billerDesc;
	}

	public String getBillerShortName() {
		return billerShortName;
	}

	public void setBillerShortName(String billerShortName) {
		this.billerShortName = billerShortName;
	}
	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getAggregatePaymentCode() {
		return aggregatePaymentCode;
	}

	public void setAggregatePaymentCode(String aggregatePaymentCode) {
		this.aggregatePaymentCode = aggregatePaymentCode;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getDefaultAmount() {
		return defaultAmount;
	}

	public void setDefaultAmount(Double defaultAmount) {
		this.defaultAmount = defaultAmount;
	}

	public String getBillPresentmentType() {
		return billPresentmentType;
	}

	public void setBillPresentmentType(String billPresentmentType) {
		this.billPresentmentType = billPresentmentType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

 

	public String getBillerTypeCode() {
		return billerTypeCode;
	}

	public void setBillerTypeCode(String billerTypeCode) {
		this.billerTypeCode = billerTypeCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getBillerId() {
		return billerId;
	}

	public void setBillerId(String billerId) {
		this.billerId = billerId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public Double getMinimumAmount() {
		return minimumAmount;
	}

	public void setMinimumAmount(Double minimumAmount) {
		this.minimumAmount = minimumAmount;
	}

	public Double getMaximumAmount() {
		return maximumAmount;
	}

	public void setMaximumAmount(Double maximumAmount) {
		this.maximumAmount = maximumAmount;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	 	
	public Timestamp getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Timestamp dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Timestamp getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(Timestamp dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	
	@Override
	public Object clone(){  
	    try{  
	        return super.clone();  
	    }catch(Exception e){ 
	        return null; 
	    }
	}
}
