package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class ChargesTypeVO.
 */
public class ChargesTypeVO implements Serializable {

	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6407961073602177762L;

	/** The chrg debit acct. */
	private String chrgDebitAcct;
	
	/** The charges opt. */
	private String chargesOpt;
	
	/** The chrg remit acct. */
	private String chrgRemitAcct;
	
	/** The charge type. */
	private String chargeType;
	
	/** The amount. */
	private double amount;
	
	/** The currency. */
	private String currency;
	
	/** The charge on. */
	private String chargeOn;
	
	/** The charge account number. */
	private String chargeAccountNumber;
	 
	/** The charge universal acc number. */
	private String chargeUniversalAccNumber;
	 
	/** The charge product code. */
	private String chargeProductCode;
	 
	/** The charge currency. */
	private String chargeCurrency;
	 
	/** The charge memo. */
	private String chargeMemo;
	
	/** The charge bank name. */
	private String chargeBankName;
	 
	/** The charge branch name. */
	private String chargeBranchName;
	 
	/** The charge bank address1. */
	private String chargeBankAddress1;
		
	/** The charge bank address2. */
	private String chargeBankAddress2;
			
	/** The charge bank address3. */
	private String chargeBankAddress3;
			
	/** The charge bank city. */
	private String chargeBankCity;
			
	/** The charge bank state. */
	private String chargeBankState;
			
	/** The charge bank zip code. */
	private String chargeBankZipCode;
			
	/** The charge bank country. */
	private String chargeBankCountry;
	
	/** The charge acc type. */
	private String chargeAccType;
	 
	/** The charge rounting info. */
	private List<RountingInfoVO> chargeRountingInfo;
	
	/**
	 * Gets the chrg debit acct.
	 *
	 * @return the chrgDebitAcct
	 */
	public String getChrgDebitAcct() {
		return chrgDebitAcct;
	}
	
	/**
	 * Sets the chrg debit acct.
	 *
	 * @param chrgDebitAcct the chrgDebitAcct to set
	 */
	public void setChrgDebitAcct(String chrgDebitAcct) {
		this.chrgDebitAcct = chrgDebitAcct;
	}
	
	/**
	 * Gets the charges opt.
	 *
	 * @return the chargesOpt
	 */
	public String getChargesOpt() {
		return chargesOpt;
	}
	
	/**
	 * Sets the charges opt.
	 *
	 * @param chargesOpt the chargesOpt to set
	 */
	public void setChargesOpt(String chargesOpt) {
		this.chargesOpt = chargesOpt;
	}
	
	/**
	 * Gets the chrg remit acct.
	 *
	 * @return the chrgRemitAcct
	 */
	public String getChrgRemitAcct() {
		return chrgRemitAcct;
	}
	
	/**
	 * Sets the chrg remit acct.
	 *
	 * @param chrgRemitAcct the chrgRemitAcct to set
	 */
	public void setChrgRemitAcct(String chrgRemitAcct) {
		this.chrgRemitAcct = chrgRemitAcct;
	}
	
	/**
	 * Gets the charge type.
	 *
	 * @return the chargeType
	 */
	public String getChargeType() {
		return chargeType;
	}
	
	/**
	 * Sets the charge type.
	 *
	 * @param chargeType the chargeType to set
	 */
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	
	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}
	
	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	
	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	/**
	 * Gets the charge on.
	 *
	 * @return the chargeOn
	 */
	public String getChargeOn() {
		return chargeOn;
	}
	
	/**
	 * Sets the charge on.
	 *
	 * @param chargeOn the chargeOn to set
	 */
	public void setChargeOn(String chargeOn) {
		this.chargeOn = chargeOn;
	}
	
	/**
	 * Gets the charge account number.
	 *
	 * @return the chargeAccountNumber
	 */
	public String getChargeAccountNumber() {
		return chargeAccountNumber;
	}
	
	/**
	 * Sets the charge account number.
	 *
	 * @param chargeAccountNumber the chargeAccountNumber to set
	 */
	public void setChargeAccountNumber(String chargeAccountNumber) {
		this.chargeAccountNumber = chargeAccountNumber;
	}
	
	/**
	 * Gets the charge universal acc number.
	 *
	 * @return the chargeUniversalAccNumber
	 */
	public String getChargeUniversalAccNumber() {
		return chargeUniversalAccNumber;
	}
	
	/**
	 * Sets the charge universal acc number.
	 *
	 * @param chargeUniversalAccNumber the chargeUniversalAccNumber to set
	 */
	public void setChargeUniversalAccNumber(String chargeUniversalAccNumber) {
		this.chargeUniversalAccNumber = chargeUniversalAccNumber;
	}
	
	/**
	 * Gets the charge product code.
	 *
	 * @return the chargeProductCode
	 */
	public String getChargeProductCode() {
		return chargeProductCode;
	}
	
	/**
	 * Sets the charge product code.
	 *
	 * @param chargeProductCode the chargeProductCode to set
	 */
	public void setChargeProductCode(String chargeProductCode) {
		this.chargeProductCode = chargeProductCode;
	}
	
	/**
	 * Gets the charge currency.
	 *
	 * @return the chargeCurrency
	 */
	public String getChargeCurrency() {
		return chargeCurrency;
	}
	
	/**
	 * Sets the charge currency.
	 *
	 * @param chargeCurrency the chargeCurrency to set
	 */
	public void setChargeCurrency(String chargeCurrency) {
		this.chargeCurrency = chargeCurrency;
	}
	
	/**
	 * Gets the charge memo.
	 *
	 * @return the chargeMemo
	 */
	public String getChargeMemo() {
		return chargeMemo;
	}
	
	/**
	 * Sets the charge memo.
	 *
	 * @param chargeMemo the chargeMemo to set
	 */
	public void setChargeMemo(String chargeMemo) {
		this.chargeMemo = chargeMemo;
	}
	
	/**
	 * Gets the charge bank name.
	 *
	 * @return the chargeBankName
	 */
	public String getChargeBankName() {
		return chargeBankName;
	}
	
	/**
	 * Sets the charge bank name.
	 *
	 * @param chargeBankName the chargeBankName to set
	 */
	public void setChargeBankName(String chargeBankName) {
		this.chargeBankName = chargeBankName;
	}
	
	/**
	 * Gets the charge branch name.
	 *
	 * @return the chargeBranchName
	 */
	public String getChargeBranchName() {
		return chargeBranchName;
	}
	
	/**
	 * Sets the charge branch name.
	 *
	 * @param chargeBranchName the chargeBranchName to set
	 */
	public void setChargeBranchName(String chargeBranchName) {
		this.chargeBranchName = chargeBranchName;
	}
	
	/**
	 * Gets the charge bank address1.
	 *
	 * @return the chargeBankAddress1
	 */
	public String getChargeBankAddress1() {
		return chargeBankAddress1;
	}
	
	/**
	 * Sets the charge bank address1.
	 *
	 * @param chargeBankAddress1 the chargeBankAddress1 to set
	 */
	public void setChargeBankAddress1(String chargeBankAddress1) {
		this.chargeBankAddress1 = chargeBankAddress1;
	}
	
	/**
	 * Gets the charge bank address2.
	 *
	 * @return the chargeBankAddress2
	 */
	public String getChargeBankAddress2() {
		return chargeBankAddress2;
	}
	
	/**
	 * Sets the charge bank address2.
	 *
	 * @param chargeBankAddress2 the chargeBankAddress2 to set
	 */
	public void setChargeBankAddress2(String chargeBankAddress2) {
		this.chargeBankAddress2 = chargeBankAddress2;
	}
	
	/**
	 * Gets the charge bank address3.
	 *
	 * @return the chargeBankAddress3
	 */
	public String getChargeBankAddress3() {
		return chargeBankAddress3;
	}
	
	/**
	 * Sets the charge bank address3.
	 *
	 * @param chargeBankAddress3 the chargeBankAddress3 to set
	 */
	public void setChargeBankAddress3(String chargeBankAddress3) {
		this.chargeBankAddress3 = chargeBankAddress3;
	}
	
	/**
	 * Gets the charge bank city.
	 *
	 * @return the chargeBankCity
	 */
	public String getChargeBankCity() {
		return chargeBankCity;
	}
	
	/**
	 * Sets the charge bank city.
	 *
	 * @param chargeBankCity the chargeBankCity to set
	 */
	public void setChargeBankCity(String chargeBankCity) {
		this.chargeBankCity = chargeBankCity;
	}
	
	/**
	 * Gets the charge bank state.
	 *
	 * @return the chargeBankState
	 */
	public String getChargeBankState() {
		return chargeBankState;
	}
	
	/**
	 * Sets the charge bank state.
	 *
	 * @param chargeBankState the chargeBankState to set
	 */
	public void setChargeBankState(String chargeBankState) {
		this.chargeBankState = chargeBankState;
	}
	
	/**
	 * Gets the charge bank zip code.
	 *
	 * @return the chargeBankZipCode
	 */
	public String getChargeBankZipCode() {
		return chargeBankZipCode;
	}
	
	/**
	 * Sets the charge bank zip code.
	 *
	 * @param chargeBankZipCode the chargeBankZipCode to set
	 */
	public void setChargeBankZipCode(String chargeBankZipCode) {
		this.chargeBankZipCode = chargeBankZipCode;
	}
	
	/**
	 * Gets the charge bank country.
	 *
	 * @return the chargeBankCountry
	 */
	public String getChargeBankCountry() {
		return chargeBankCountry;
	}
	
	/**
	 * Sets the charge bank country.
	 *
	 * @param chargeBankCountry the chargeBankCountry to set
	 */
	public void setChargeBankCountry(String chargeBankCountry) {
		this.chargeBankCountry = chargeBankCountry;
	}
	
	/**
	 * Gets the charge rounting info.
	 *
	 * @return the chargeRountingInfo
	 */
	public List<RountingInfoVO> getChargeRountingInfo() {
		return chargeRountingInfo;
	}
	
	/**
	 * Sets the charge rounting info.
	 *
	 * @param chargeRountingInfo the chargeRountingInfo to set
	 */
	public void setChargeRountingInfo(List<RountingInfoVO> chargeRountingInfo) {
		this.chargeRountingInfo = chargeRountingInfo;
	}
	
	/**
	 * Gets the charge acc type.
	 *
	 * @return the chargeAccType
	 */
	public String getChargeAccType() {
		return chargeAccType;
	}
	
	/**
	 * Sets the charge acc type.
	 *
	 * @param chargeAccType the chargeAccType to set
	 */
	public void setChargeAccType(String chargeAccType) {
		this.chargeAccType = chargeAccType;
	}
	
}
