package com.scb.channels.base.vo;


/**
 * The Class CustomerPaymentAmountRequestVO.
 * 
 * @author 1317590
 */
public class CustomerPaymentAmountRequestVO extends BaseVO  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3652866025224532764L;

	private PaymentMode paymentMode;
	
	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}


}
