package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentReceivingCard implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4379567930428703228L;
	
	private String AccountNumber;

	public String getAccountNumber() {
		return AccountNumber;
	}
	@JsonSetter("AccountNumber")
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "QRPaymentReceivingCard [AccountNumber=" + AccountNumber + "]";
	}
	
	
	
	

}
