/**
 * 
 */
package com.scb.channels.base.helper;

import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class HibernateHelper.
 *
 * @author 1411807
 */
public final class HibernateHelper {
	
	
	
	/** The Constant CHANNEL_ID. */
	public static final String CHANNEL_ID = "channelId";
	
	/** The Constant COUNTRY. */
	public static final String COUNTRY = "country";
	
	/** The Constant CUST_ID. */
	public static final String CUST_ID = "custId";
	
	/** The Constant DEST_CURRENCY. */
	public static final String DEST_CURRENCY = "destCurrency";
	
	/** The Constant SRC_CURRENCY. */
	public static final String SRC_CURRENCY = "srcCurrency";
	
	/** The Constant TXN_TYPE_CD. */
	public static final String TXN_TYPE_CD = "txnTypeCd";
	
	/** The Constant LIMIT_SEG_CODE. */
	public static final String LIMIT_SEG_CODE = "limitSegmentCode";
	
	/** The Constant NA. */
	public static final String NA = "NA";
	
	/** The Constant CTRY_CD. */
	public static final String CTRY_CD = "ctryCode";

	/** The Constant RETAIL_SEG_NO. */
	public static final String RETAIL_SEG_NO = "retailSegCode";
	
	/** The Constant SALARY. */
	public static final String SALARY = "SALARY";
	
	/** The Constant STAFF. */
	public static final String STAFF = "STAFF";
	
	/** The Constant RESIDENT. */
	public static final String RESIDENT = "RESIDENT";
	
	/** The Constant SEGMENT_CRITERIA_VALUE. */
	public static final String SEGMENT_CRITERIA_VALUE = "segmentCriteriaValue";
	
	/** The Constant SEGMENT_CRITERIA_TYPE. */
	public static final String SEGMENT_CRITERIA_TYPE = "segmentCriteriaType";
	
	/** The Constant TXN_ID. */
	public static final String TXN_ID = "txnId";
	
	/** The Constant AUD_TXN_ID. */
	public static final String AUD_TXN_ID ="txnId";
	
	/** The Constant TXN_STATUS. */
	public static final String TXN_STATUS = "txnStatusCd";
	
	/** The Constant DATE_UPDATE. */
	public static final String DATE_UPDATE = "dtUpd";
	
	/** The Constant UPDATE_BY. */
	public static final String UPDATE_BY = "updBy";
	
	/** The Constant IS_ALLOWED. */
	public static final String IS_ALLOWED ="isAllowed";
	
	/** The Constant STATUS_CD. */
	public static final String STATUS_CD ="statusCD";
	public static final String STATUS_CODE ="statusCode";
	
	/** The Constant TRANSATION_INFO_VO_TXN_ID. */
	public static final String TRANSATION_INFO_VO_TXN_ID = "transactionInfoVO.messageVO.requestCode";
	
	public static final String ID = "id";

	public static final String REF_CD ="refCode";
	public static final String REF_VALUE ="refValue";
	
	public static final String ACC_NUM = "acctNo";
	
	public static final String TYPE ="type";
	public static final String AGGREGATOR="aggregator";

	public static final String CATEGORY = "category";
	public static final String VALUE = "value";
	
	public static final String AUD_CUST_ID ="custId";
	public static final String CUST_GRP_ID = "custGroupId";
	
	public static final String ACC_NO = "accountNumber";
	public static final String ACCT_NO = "acctNo";
	
	public static final String CCY_CD="ccyCd";
	public static final String CTRYCD="ctryCd";

	public static final String NIKCNAME = "nickname";
	public static final String BILLER_DESC = "billerDesc";

	public static final String SEGMENT_CODE = "segmentCode";
	
	public static final String LMT_TYP_CODE = "limitType";
	
	public static final String MDTL = "MDTL";
	
	public static final String NDTL = "NDTL";
	
	public static final String PTL = "PTL";

	public static final String USER_ID = "userId";

	public static final String CHANNEL = "channel";
	public static final String DT_TRANSFER = "dtTransfer";
	
	public static final String CONSUMER_NO= "consumerNo";
	
	public static final String PRESENTMENT_AVL= "presentmentAvl";
	
	public static final String BILLER_CD = "billerCd";
	
	public static final String BILLER_VAL_FIELD = "billerField";

	public static final String ROWNUM = "ROWNUM";

	public static final String TXN_STATUS_CD= "transactionInfoVO.txnStatusCd";

	//VPP changes
	public static final String TXN_ACTIVITY = "txnActivity";
	public static final String TXN_ACTIVITY_STATUS = "txnActStatus";
	public static final String NEXT_EXEC_TIME = "nextExcTime";
	
	public static final String CLIENT_REF_NO = "clientRefNo";
	
	//Added for Customer Overall Payment Amount Service
	
	/** The Constant COUNTRY_CODE. */
	public static final String COUNTRY_CODE = "countryCode";
	
	/** The Constant COUNTRY_CODE. */
	public static final String CUSTOMER_ID = "customerId";
	
	public static final String PAYMENT_DATE = "paymentDate";
	
	public static final String PAYMENT_TOTAL_AMOUT = "totalAmount";
	
	public static final String PAYMENT_STATUS = "paymentStatus";
	
	public static final String PAYMENT_TYPE = "paymentType";
	
	public static final String PAYMENT_AMOUNT = "paymentAmount";
	
	public static final String PAYMENT_OPTION = "paymentOption";
	
	//ends Customer Overall Payment Amount	
	public static final String PAY_REF = "payRef";
	
	public static final String STATUS = "status";
	
	public static final String BILLER_UNIQUE_ID = "billerUniqueId";
	
	public static final String BILLER_NAME = "billerName";
	
	public static final String REG_PAYEE = "payeeType";
	
	public static final String API_Version ="api_version";
	
	public static final String PAYEE_ID = "payeeId";
	
	public static final String IS_UPATE_REQUIRED = "isUpdateRequired";
	
	//Added for orange money
	public static final String CONSUMER_DETAIL = "consumerDetail";
	
	//Added for orange money
	public static final String CONSUMER_NUMBER = "consumerNumber";

	/**
	 * Instantiates a new hibernate helper.
	 */
	private HibernateHelper() {
	}

}
