package com.scb.channels.base.vo;

/**
 * The Class SenderInfoVO.
 *
 * @author 1493439
 */
public class SenderInfoVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7657521561177089009L;

	/** The mobile number. */
	private String mobileNumber;
	
	/** The name. */
	private String name;
	
	/** The address. */
	private String address;
	
	/** The email id. */
	private String emailId;

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SenderInfoVO [mobileNumber=" + mobileNumber + ", name=" + name
				+ ", address=" + address + ", emailId=" + emailId + "]";
	}
	
}
