package com.scb.channels.base.vo;

import java.io.Serializable;

public class AccountLinkVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2099196588329233289L;
	
	private String linkedAccountCurrency;
	private String linkedAccountNumber;
	private String linkedAccountType;
	
	
	public String getLinkedAccountCurrency() {
		return linkedAccountCurrency;
	}
	public void setLinkedAccountCurrency(String linkedAccountCurrency) {
		this.linkedAccountCurrency = linkedAccountCurrency;
	}
	public String getLinkedAccountNumber() {
		return linkedAccountNumber;
	}
	public void setLinkedAccountNumber(String linkedAccountNumber) {
		this.linkedAccountNumber = linkedAccountNumber;
	}
	public String getLinkedAccountType() {
		return linkedAccountType;
	}
	public void setLinkedAccountType(String linkedAccountType) {
		this.linkedAccountType = linkedAccountType;
	}

}
