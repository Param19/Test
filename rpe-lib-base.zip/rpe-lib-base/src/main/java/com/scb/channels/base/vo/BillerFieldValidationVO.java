package com.scb.channels.base.vo;

import java.io.Serializable;


public class BillerFieldValidationVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4721180687847563960L;
	
	private int id;
	private String billerCd;
	private String billerField;
	private int minLen;
	private int maxLen;	
	private String ctryCd;
	private String regExp;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the billerCd
	 */
	public String getBillerCd() {
		return billerCd;
	}
	/**
	 * @param billerCd the billerCd to set
	 */
	public void setBillerCd(String billerCd) {
		this.billerCd = billerCd;
	}
	/**
	 * @return the billerField
	 */
	public String getBillerField() {
		return billerField;
	}
	/**
	 * @param billerField the billerField to set
	 */
	public void setBillerField(String billerField) {
		this.billerField = billerField;
	}
	/**
	 * @return the minLen
	 */
	public int getMinLen() {
		return minLen;
	}
	/**
	 * @param minLen the minLen to set
	 */
	public void setMinLen(int minLen) {
		this.minLen = minLen;
	}
	/**
	 * @return the maxLen
	 */
	public int getMaxLen() {
		return maxLen;
	}
	/**
	 * @param maxLen the maxLen to set
	 */
	public void setMaxLen(int maxLen) {
		this.maxLen = maxLen;
	}
	/**
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	/**
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	/**
	 * @return the regExp
	 */
	public String getRegExp() {
		return regExp;
	}
	/**
	 * @param regExp the regExp to set
	 */
	public void setRegExp(String regExp) {
		this.regExp = regExp;
	}
	
}
