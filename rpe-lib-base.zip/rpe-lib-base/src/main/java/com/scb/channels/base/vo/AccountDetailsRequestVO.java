/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Date;

/**
 * The Class AccountDetailsRequestVO.
 *
 * @author 1411807
 */
public class AccountDetailsRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8168791536130314343L;
	
	/** The accountNumber*/
	private String accountNumber;
	
	/** The currencyCode*/
	private String currencyCode;
	
	/** The fromDate*/
	private Date fromDate;
	
	/** The toDate*/
	private Date toDate;
	
	/** The operationType*/
	private String operationType;
	
	/**The dateLogin */
	private Date dateLogin;
	
	/** The version. */
	private int version;

	public Date getDateLogin() {
		return dateLogin;
	}

	public void setDateLogin(Date dateLogin) {
		this.dateLogin = dateLogin;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}



}
