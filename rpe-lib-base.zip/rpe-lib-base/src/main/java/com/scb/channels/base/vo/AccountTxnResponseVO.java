/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class AccountTxnResponseVO.
 *
 * @author 1411807
 */
public class AccountTxnResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5218566365275347592L;



}
