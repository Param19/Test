package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class BackupMasterBillerCategoryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 540747127491259210L;
	
	private Integer id;
	
	private String categoryId;
	private String categoryName;	
	private String statusCode;
	private String countryCode;	
	private String createdBy;
	private String updatedBy;
	
	private Date dateCreated;
	private Date dateUpdated;
	
	private String channel ;
	private int version;
	
	/** private BillerVO billerVO;*/

	private Set<BackupMasterBillerVO> billers=	new HashSet<BackupMasterBillerVO>(0); ;
		
	 
	public Set<BackupMasterBillerVO> getBillers() {
		return billers;
	}
	public void setBillers(Set<BackupMasterBillerVO> billers) {
		this.billers = billers;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	
	/*public BillerVO getBillerVO() {
		return billerVO;
	}
	public void setBillerVO(BillerVO billerVO) {
		this.billerVO = billerVO;
	}*/
	
	

}
