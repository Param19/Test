/**
 * 
 */
package com.scb.channels.base.helper;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.TransformerException;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.scb.channels.base.vo.AccountChangeRequestVO;
import com.scb.channels.base.vo.AccountChangeResponseVO;
import com.scb.channels.base.vo.AccountDetailsRequestVO;
import com.scb.channels.base.vo.AccountDetailsResponseVO;
import com.scb.channels.base.vo.AccountListRequestVO;
import com.scb.channels.base.vo.AccountListResponseVO;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.BeneficiaryRequestVO;
import com.scb.channels.base.vo.BeneficiaryResponseVO;
import com.scb.channels.base.vo.BillPresentmentRequestVO;
import com.scb.channels.base.vo.BillPresentmentResponseVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.CardListRequestVO;
import com.scb.channels.base.vo.CardListResponseVO;
import com.scb.channels.base.vo.CardTxnRequestVO;
import com.scb.channels.base.vo.CardTxnResponseVO;
import com.scb.channels.base.vo.ChequeBookRequestVO;
import com.scb.channels.base.vo.ChequeBookResponseVO;
import com.scb.channels.base.vo.CustomerEnquiryRequestVO;
import com.scb.channels.base.vo.CustomerEnquiryResponseVO;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.FXRateRequestVO;
import com.scb.channels.base.vo.FXRateResponseVO;
import com.scb.channels.base.vo.GetRegistrationDetailsRequestVO;
import com.scb.channels.base.vo.GetRegistrationDetailsResponseVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.LoginRequestVO;
import com.scb.channels.base.vo.LoginResponseVO;
import com.scb.channels.base.vo.LogoutRequestVO;
import com.scb.channels.base.vo.LogoutResponseVO;
import com.scb.channels.base.vo.OnlinePinChangeRequestVO;
import com.scb.channels.base.vo.OnlinePinChangeResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PinChangeRequestVO;
import com.scb.channels.base.vo.PinChangeResponseVO;
import com.scb.channels.base.vo.ProductDetailsRequestVO;
import com.scb.channels.base.vo.ProductDetailsResponseVO;
import com.scb.channels.base.vo.ProductListRequestVO;
import com.scb.channels.base.vo.ProductListResponseVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.RegisterCustomerRequestVO;
import com.scb.channels.base.vo.RegisterCustomerResponseVO;
import com.scb.channels.base.vo.StatementRequestVO;
import com.scb.channels.base.vo.StatementResponseVO;
import com.scb.channels.base.vo.StopChequeRequestVO;
import com.scb.channels.base.vo.StopChequeResponseVO;
import com.scb.channels.base.vo.TransferRequestVO;
import com.scb.channels.base.vo.TransferResponseVO;
import com.scb.channels.base.vo.ValidateBeneficiaryRequestVO;
import com.scb.channels.base.vo.ValidateBeneficiaryResponseVO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;

/**
 * @author 1411807
 *
 */
public final class CommonHelper {
	private static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(CommonHelper.class);
	
	
	/**
	 * Instantiates a new common helper.
	 */
	private CommonHelper() {
	}
	
	/**
	 * Gets the un marshaller.
	 * 
	 * @param c
	 *            the c
	 * @return the un marshaller
	 * @throws JAXBException
	 *             the jAXB exception
	 */
	public static Unmarshaller getUnMarshaller(Class<?> c) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(c);
		return (Unmarshaller) jaxbContext.createUnmarshaller();
	}
	
	/**
	 * Gets the un marshaller.
	 * 
	 * @param c
	 *            the c
	 * @return the un marshaller
	 * @throws JAXBException
	 *             the jAXB exception
	 */
	public static Marshaller getMarshaller(Class<?> c) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(c);
		return (Marshaller) jaxbContext.createMarshaller();
	}

	/**
	 * Gets the parser.
	 * 
	 * @param responseXML
	 *            the response xml
	 * @return the parser
	 * @throws SAXException
	 *             the sAX exception
	 */
	public static SAXSource getParser(String responseXML) throws SAXException {
		InputStream inputs=IOUtils.toInputStream(responseXML);
		XMLReader reader = XMLReaderFactory.createXMLReader();
		return new SAXSource(reader, new InputSource(inputs));
	}
	
	public static Object unMarshall(String paymentRequestXML, 
			Class<?> clazz) throws TransformerException  {
		
		Object object = null;
		try {
			Unmarshaller unmarshaller =  CommonHelper.getUnMarshaller(clazz);			
			SAXSource ss = CommonHelper.getParser(paymentRequestXML);
			LOGGER.info("Topic response:{}",new Object[]{paymentRequestXML});
			
			JAXBElement<?> root = unmarshaller.unmarshal(ss, clazz);
			object = root.getValue();
			
		} catch (JAXBException e) {
			LOGGER.error(e.getMessage());
			throw new TransformerException(e.getMessage(), e.getCause());
		} catch (SAXException e) {
			LOGGER.error(e.getMessage());
			throw new TransformerException(e.getMessage(), e.getCause());
		}
		return object;
	}
	
	public static String getXML(Object object, Class<?> clazz, String rootTag) {
		String xml = null;
		try {
			Marshaller marshaller = CommonHelper
					.getMarshaller(clazz);
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			marshaller.marshal(new JAXBElement(new QName(
					rootTag), clazz, object), stream);
			
			xml = new String(stream.toByteArray());
			LOGGER.debug("XML for object : {} ----- {}", new Object[] {clazz.getSimpleName(),  xml });
		} catch (JAXBException e) {
			LOGGER.error(e.getMessage());
		}
		return xml;
	}
	
	/**
	 * Gets the response instance.
	 *
	 * @param beanNew the bean new
	 * @return the response instance
	 */
	public static PayloadDTO getResponseInstance(PayloadDTO beanNew) {
		if (beanNew == null) {
			 beanNew = new PayloadDTO();
			 BaseVO responseVO = new BaseVO();
			 beanNew.setResponseVO(responseVO);
		}else{
			if(beanNew.getRequestVO() instanceof AccountChangeRequestVO){
				AccountChangeResponseVO accountChangeResponseVO = new AccountChangeResponseVO();
				beanNew.setResponseVO(accountChangeResponseVO);
			}else if(beanNew.getRequestVO() instanceof AccountDetailsRequestVO){
				AccountDetailsResponseVO accountDetailsResponseVO = new AccountDetailsResponseVO();
				beanNew.setResponseVO(accountDetailsResponseVO);
			}else if(beanNew.getRequestVO() instanceof AccountListRequestVO){
				AccountListResponseVO accountListResponseVO = new AccountListResponseVO();
				beanNew.setResponseVO(accountListResponseVO);
			}else if(beanNew.getRequestVO() instanceof BeneficiaryRequestVO){
				BeneficiaryResponseVO beneficiaryResponseVO = new BeneficiaryResponseVO();
				beanNew.setResponseVO(beneficiaryResponseVO);
			}else if(beanNew.getRequestVO() instanceof BillerPayRequestVO){
				BillerPayResponseVO  billerPayResponseVO = new BillerPayResponseVO();
				beanNew.setResponseVO(billerPayResponseVO);
			}else if(beanNew.getRequestVO() instanceof CardListRequestVO){
				CardListResponseVO  cardListResponseVO = new CardListResponseVO();
				beanNew.setResponseVO(cardListResponseVO);
			}else if(beanNew.getRequestVO() instanceof CardTxnRequestVO){
				CardTxnResponseVO  cardTxnResponseVO = new CardTxnResponseVO();
				beanNew.setResponseVO(cardTxnResponseVO);
			}else if(beanNew.getRequestVO() instanceof ChequeBookRequestVO){
				ChequeBookResponseVO  chequeBookResponseVO = new ChequeBookResponseVO();
				beanNew.setResponseVO(chequeBookResponseVO);
			}else if(beanNew.getRequestVO() instanceof CustomerEnquiryRequestVO){
				CustomerEnquiryResponseVO  customerEnquiryResponseVO = new CustomerEnquiryResponseVO();
				beanNew.setResponseVO(customerEnquiryResponseVO);
			}else if(beanNew.getRequestVO() instanceof FXRateRequestVO){
				FXRateResponseVO  fXRateResponseVO = new FXRateResponseVO();
				beanNew.setResponseVO(fXRateResponseVO);
			}else if(beanNew.getRequestVO() instanceof LoginRequestVO){
				LoginResponseVO  loginResponseVO = new LoginResponseVO();
				beanNew.setResponseVO(loginResponseVO);
			}else if(beanNew.getRequestVO() instanceof LogoutRequestVO){
				LogoutResponseVO  logoutResponseVO = new LogoutResponseVO();
				beanNew.setResponseVO(logoutResponseVO);
			}else if(beanNew.getRequestVO() instanceof PinChangeRequestVO){
				PinChangeResponseVO  pinChangeResponseVO = new PinChangeResponseVO();
				beanNew.setResponseVO(pinChangeResponseVO);
			}else if(beanNew.getRequestVO() instanceof ProductDetailsRequestVO){
				ProductDetailsResponseVO  productDetailsResponseVO = new ProductDetailsResponseVO();
				beanNew.setResponseVO(productDetailsResponseVO);
			}else if(beanNew.getRequestVO() instanceof ProductListRequestVO){
				ProductListResponseVO  productListResponseVO = new ProductListResponseVO();
				beanNew.setResponseVO(productListResponseVO);
			}else if(beanNew.getRequestVO() instanceof StatementRequestVO){
				StatementResponseVO  statementResponseVO = new StatementResponseVO();
				beanNew.setResponseVO(statementResponseVO);
			}else if(beanNew.getRequestVO() instanceof StopChequeRequestVO){
				StopChequeResponseVO  stopChequeResponseVO = new StopChequeResponseVO();
				beanNew.setResponseVO(stopChequeResponseVO);
			}else if(beanNew.getRequestVO() instanceof TransferRequestVO){
				TransferResponseVO  transferResponseVO = new TransferResponseVO();
				beanNew.setResponseVO(transferResponseVO);
			}else if(beanNew.getRequestVO() instanceof ValidateBeneficiaryRequestVO){
				ValidateBeneficiaryResponseVO  validateBeneficiaryResponseVO = new ValidateBeneficiaryResponseVO();
				beanNew.setResponseVO(validateBeneficiaryResponseVO);
			}else if(beanNew.getRequestVO() instanceof BillPresentmentRequestVO){
				BillPresentmentResponseVO  billPresentmentResponseVO = new BillPresentmentResponseVO();
				beanNew.setResponseVO(billPresentmentResponseVO);
			} else if(beanNew.getRequestVO() instanceof OnlinePinChangeRequestVO){
				OnlinePinChangeResponseVO  onlinePinChangeResponseVO = new OnlinePinChangeResponseVO();
				beanNew.setResponseVO(onlinePinChangeResponseVO);
			} else if(beanNew.getRequestVO() instanceof RegisterCustomerRequestVO){
				 RegisterCustomerResponseVO  registerCustomerResponseVO = new  RegisterCustomerResponseVO();
				beanNew.setResponseVO(registerCustomerResponseVO);
			} else if(beanNew.getRequestVO() instanceof GetRegistrationDetailsRequestVO){
				GetRegistrationDetailsResponseVO  getRegistrationDetailsResponseVO = new GetRegistrationDetailsResponseVO();
				beanNew.setResponseVO(getRegistrationDetailsResponseVO);
			}else if(beanNew.getRequestVO() instanceof CustomerPaymentAmountRequestVO){
				CustomerPaymentAmountRequestVO  amountRequestVO = new CustomerPaymentAmountRequestVO();
				beanNew.setResponseVO(amountRequestVO);
			}
			else if(beanNew.getRequestVO() instanceof ViewPayeeRequestVO){
				ViewPayeeRequestVO  viewPayeeRequestVO = new ViewPayeeRequestVO();
				beanNew.setResponseVO(viewPayeeRequestVO);
			}
			else if(beanNew.getRequestVO() instanceof InwardPaymentRequestVO) {
				InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
				beanNew.setResponseVO(inwardPaymentResponseVO);
			}else if(beanNew.getRequestVO() instanceof QRPaymentRequestVO){
				QRPaymentResponseVO qrPaymentResponseVO = new QRPaymentResponseVO();
				beanNew.setResponseVO(qrPaymentResponseVO);
			}
		}
		return beanNew;
	}
	
	public static String getJVMName() {
		String jvmName="";
		try {
		if(StringUtils.isNotBlank(System.getProperty(CommonConstants.was_server_name))){
			jvmName=InetAddress.getLocalHost().getHostName()+CommonConstants.HYPHEN+System.getProperty(CommonConstants.was_server_name);
		}else{
				jvmName=InetAddress.getLocalHost().getHostName();
			
		}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jvmName;
	}
	
}
