package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class BillerPayResponseVO.
 */
public class BillerPayResponseVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3054532474676266411L;
	
	/** The biller pay details vo. */
	private BillerPayDetailsVO billerPayDetailsVO;
	
	
	private String respSeverity;
	
	private String serviceRespCode;
	
	private String serviceRespDesc;
	
	private String serviceRespSeverity;
	
	private  List<BillerPayDetailsVO> billerPayDetailsVOList= new ArrayList<BillerPayDetailsVO>();
	
	private  List<PaymentStatusVO> listPaymentStatusVO= new ArrayList<PaymentStatusVO>();
	
	private String authCode;//For CR659
	
	private String stan; // For CR659
	
	private String retrievalReferenceNumber; // added for CR659 
	
	private String paymentSubType; // added for CR659
	
	/**
	 * Gets the biller pay details vo.
	 *
	 * @return the billerPayDetailsVO
	 */
	public BillerPayDetailsVO getBillerPayDetailsVO() {
		return billerPayDetailsVO;
	}

	/**
	 * Sets the biller pay details vo.
	 *
	 * @param billerPayDetailsVO the billerPayDetailsVO to set
	 */
	public void setBillerPayDetailsVO(BillerPayDetailsVO billerPayDetailsVO) {
		this.billerPayDetailsVO = billerPayDetailsVO;
	}

	 

	/**
	 * @return the respSeverity
	 */
	public String getRespSeverity() {
		return respSeverity;
	}

	/**
	 * @param respSeverity the respSeverity to set
	 */
	public void setRespSeverity(String respSeverity) {
		this.respSeverity = respSeverity;
	}

	/**
	 * @return the serviceRespCode
	 */
	public String getServiceRespCode() {
		return serviceRespCode;
	}

	/**
	 * @param serviceRespCode the serviceRespCode to set
	 */
	public void setServiceRespCode(String serviceRespCode) {
		this.serviceRespCode = serviceRespCode;
	}

	/**
	 * @return the serviceRespDesc
	 */
	public String getServiceRespDesc() {
		return serviceRespDesc;
	}

	/**
	 * @param serviceRespDesc the serviceRespDesc to set
	 */
	public void setServiceRespDesc(String serviceRespDesc) {
		this.serviceRespDesc = serviceRespDesc;
	}

	/**
	 * @return the serviceRespSeverity
	 */
	public String getServiceRespSeverity() {
		return serviceRespSeverity;
	}

	/**
	 * @param serviceRespSeverity the serviceRespSeverity to set
	 */
	public void setServiceRespSeverity(String serviceRespSeverity) {
		this.serviceRespSeverity = serviceRespSeverity;
	}

	public List<BillerPayDetailsVO> getBillerPayDetailsVOList() {
		return billerPayDetailsVOList;
	}

	public void setBillerPayDetailsVOList(
			List<BillerPayDetailsVO> billerPayDetailsVOList) {
		this.billerPayDetailsVOList = billerPayDetailsVOList;
	}

	/**
	 * @return the listPaymentStatusVO
	 */
	public List<PaymentStatusVO> getListPaymentStatusVO() {
		return listPaymentStatusVO;
	}

	/**
	 * @param listPaymentStatusVO the listPaymentStatusVO to set
	 */
	public void setListPaymentStatusVO(List<PaymentStatusVO> listPaymentStatusVO) {
		this.listPaymentStatusVO = listPaymentStatusVO;
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public String getStan() {
		return stan;
	}

	public String getRetrievalReferenceNumber() {
		return retrievalReferenceNumber;
	}

	public void setRetrievalReferenceNumber(String retrievalReferenceNumber) {
		this.retrievalReferenceNumber = retrievalReferenceNumber;
	}

	public void setStan(String stan) {
		this.stan = stan;
	}


	public String getPaymentSubType() {
		return paymentSubType;
	}

	public void setPaymentSubType(String paymentSubType) {
		this.paymentSubType = paymentSubType;
	}

	/*@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillerPayResponseVO [billerPayDetailsVO=");
		builder.append(billerPayDetailsVO);
		builder.append(", respSeverity=");
		builder.append(respSeverity);
		builder.append(", serviceRespCode=");
		builder.append(serviceRespCode);
		builder.append(", serviceRespDesc=");
		builder.append(serviceRespDesc);
		builder.append(", serviceRespSeverity=");
		builder.append(serviceRespSeverity);
		builder.append(", billerPayDetailsVOList=");
		builder.append(billerPayDetailsVOList);
		builder.append(", listPaymentStatusVO=");
		builder.append(listPaymentStatusVO);
		builder.append(", authCode=");
		builder.append(authCode);
		builder.append(", stan=");
		builder.append(stan);
		builder.append(", retrievalReferenceNumber=");
		builder.append(retrievalReferenceNumber);
		builder.append(", paymentSubType=");
		builder.append(paymentSubType);
		builder.append("]");
		return builder.toString();
	}*/
    
}
