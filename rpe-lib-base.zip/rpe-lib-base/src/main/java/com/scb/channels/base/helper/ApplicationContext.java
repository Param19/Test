package com.scb.channels.base.helper;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;

/**
 * The class ApplicationContext.
 *
 * @author 1411807
 */
public final class ApplicationContext {
	
	/** The Constant DEVICE. */
	public static final String DEVICE = "DEVICE";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationContext.class);
	 
	 /** The Constant CONTEXT_THREAD. */
 	private static final ThreadLocal<UserVO> CONTEXT_THREAD = new ThreadLocal<UserVO>();

     /** The Constant MAPPED_CNTXT_THREAD. */
     private static final ThreadLocal<Map<String, String>> MAPPED_CNTXT_THREAD = new ThreadLocal<Map<String, String>>();

     /** The Constant deviceMap. */
     private static final Map<String, String> deviceMap = new HashMap<String, String>();
     /**
		 * Instantiates a new application context.
		 */
     private ApplicationContext() {
	}
     
     /**
      * Initialiaze user context.
      *
      * @param userContext UserVO
      * @param clientVO the client vo
      * @param serviceVO the service vo
      */
     @SuppressWarnings("unchecked")
	public static void initializeContext(UserVO userContext, ClientVO clientVO, ServiceVO serviceVO) {
       if (deviceMap.size() == 0) {
    	   deviceMap.put( CommonConstants.ONE, CommonConstants.USSD);
    	   deviceMap.put(CommonConstants.TWO, CommonConstants.BLACKBERRY);
    	   deviceMap.put(CommonConstants.THREE_STR, CommonConstants.IPHONE);
    	   deviceMap.put(CommonConstants.FOUR, CommonConstants.ANDROID);
    	   deviceMap.put(CommonConstants.FIVE, CommonConstants.BROWSER);
       }
       CONTEXT_THREAD.set(userContext);
       try {
    	 Map<String, String> currentMap = MDC.getCopyOfContextMap();
    	   Map<String, String> ctxMap = PropertyUtils.describe(userContext);
    	   ctxMap.remove(CommonConstants.CLASS);
    	   if (currentMap != null) {
    		   currentMap.putAll(ctxMap);
    	   }else {
    		   currentMap = ctxMap;
    	   }
    	   Map<String, String> ctxClientMap = PropertyUtils.describe(clientVO);
    	   ctxClientMap.put(DEVICE, StringUtils.defaultIfEmpty(deviceMap.get(clientVO.getClientId()), CommonConstants.ALL));
    	   ctxClientMap.remove(CommonConstants.CLASS);
    	   currentMap.putAll(ctxClientMap);
    	   
    	   Map<String, String> ctxServiceMap = PropertyUtils.describe(serviceVO);
    	   ctxServiceMap.remove(CommonConstants.CLASS);
    	   currentMap.putAll(ctxServiceMap);
    	   
    	   MDC.setContextMap(currentMap);
    	   MDC.put(CommonConstants.APP_NAME, CommonConstants.CPG);
    	 
    	   if(userContext != null && userContext.getChannelId() != null && userContext.getChannelId().contains(CommonConstants.BILLER_DOWNLOAD)){
    		  MDC.put(CommonConstants.LOCATION, CommonConstants.BILLER_DOWNLOAD);
    	   }else{
    		   MDC.put(CommonConstants.LOCATION, StringUtils.defaultIfEmpty(userContext.getCountry(), CommonConstants.ALL));   
    	   }
    	   
       } catch (Exception e) {
         LOGGER.error("[ApplicationContext initializeContext Failed]", e);
       }
     }

    /**
	 * Gets the context.
	 * 
	 * @return UserVO
	 */
    public static UserVO getContext() {
    	UserVO userContext = (UserVO)CONTEXT_THREAD.get();
    	if (userContext == null) {
    		userContext = new UserVO();
    		CONTEXT_THREAD.set(userContext);
    	}
       return userContext;
     }

    /**
	 * Remove the contexts.
	 */
     public static void remove()  {
       CONTEXT_THREAD.remove();
       MAPPED_CNTXT_THREAD.remove();
       MDC.clear();
     }

     /**
		 * Returns the user id.
		 * 
		 * @return String
		 */
     public static String getUserId() {
       return getContext().getUserId();
     }

     /**
		 * Gets the phone number.
		 * 
		 * @return the Phone number
		 */
     public static String getPhoneNumber() {
       return getContext().getPhone();
     }
     
     /**
		 * Gets the email.
		 * 
		 * @return the email
		 */
     public static String getEmail() {
       return getContext().getEmailId();
     }

     /**
		 * Gets the service id.
		 * 
		 * @return the service id
		 */
     public static String getServiceId() {
       return getContext().getServiceId();
     }

     /**
		 * Gets the country.
		 * 
		 * @return the country
		 */
     public static String getCountry() {
       return StringUtils.defaultIfEmpty(getContext().getCountry(), CommonConstants.ALL);
     }
     
     /**
      * Gets the service name.
      *
      * @return the service name
      */
     public static String getServiceName(){
    	 return StringUtils.defaultIfEmpty(MDC.get(CommonConstants.SERVICE_NAME_KEY), CommonConstants.ALL);
     }
     /**
		 * Gets the location.
		 * 
		 * @return the country
		 */
     public static String getLocation(){
       return MDC.get(CommonConstants.LOCATION) == null ? getContext().getChannelId() 
    		   + CommonConstants.HYPHEN + getContext().getCountry()
    		   : MDC.get(CommonConstants.LOCATION);
     }

     /**
		 * Gets the channel.
		 * 
		 * @return the channel id
		 */
     public static String getChannel() {
       return getContext().getChannelId();
     }

     /**
		 * Gets the customer id.
		 * 
		 * @return the customer id
		 */
     public static String getCustomerId() {
       return getContext().getCustomerId();
     }

     /**
		 * Gets the request id.
		 * 
		 * @return the request
		 */
     public static String getRequestId()  {
       return getContext().getRequestId();
     }

     /**
		 * Gets the language.
		 * 
		 * @return the language
		 */
     public static String getLanguage()  {
       return getContext().getLanguage();
     }

     /**
		 * Set Mapped Property.
		 * 
		 * @param key
		 *            String
		 * @param value
		 *            String
		 */
     public static void setMappedProperty(String key, String value) {
       getMappedContext().put(key, value);
       MDC.put(key, value);
     }

     /**
		 * Returns the mapped property.
		 * 
		 * @param key
		 *            String
		 * @return String
		 */
     public static String getMappedProperty(String key)  {
       return (String)getMappedContext().get(key);
     }

     /**
		 * Gets the mapped context.
		 * 
		 * @return the Mapped Context
		 */
	public static Map<String, String> getMappedContext() {
       Map<String, String> map = (Map<String, String>)MAPPED_CNTXT_THREAD.get();
       if (map == null) {
         map = new HashMap<String, String>();
         MAPPED_CNTXT_THREAD.set(map);
       }
       return map;
     }

     /**
		 * Sets the mapped context.
		 * 
		 * @param map
		 *            Map
		 */
     @SuppressWarnings("unchecked")
	public static void setMappedContext(Map<String, String> map) {
       MAPPED_CNTXT_THREAD.set(map);
       Map<String, String> currentMap = MDC.getCopyOfContextMap();
       if (currentMap != null) {
         currentMap.putAll(map);
       } else {
         currentMap = map;
       }
       MDC.setContextMap(currentMap);
     }
}
