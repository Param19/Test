package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * This class holder User information.
 *
 * @author 1411807
 */
public class UserVO implements Serializable, Cloneable {

	/** The Constant serialVersionUID. */
	private static final long LONG = 6784165212700428023L;
	
	/** The customer id. */
	private String customerId;
	
	/** The password. */
	private String password;
	
	/** The login id. */
	private String loginId;
	
	/** The customer type. */
	private String customerType;
	
	/** The segment code. */
	private String segmentCode;
	
	/** The limit segment code. */
	private String limitSegmentCode;
	
	/** The cust name. */
	private String custName;
	
	/** The customer group id. */
	private String customerGroupId;
	
	/** The customer id type. */
	private String customerIdType;
	
	/** The role. */
	private String role;
	
	/** The email id. */
	private String emailId;
	
	/** The channel id. */
	private String channelId;
	
	/** The environment. */
	private String environment;
	
	/** The country. */
	private String country;
	
	/** The language. */
	private String language;
	
	/** The request id. */
	private String requestId;
	
	/** The service id. */
	private String serviceId; 
	
	/** The user id. */
	private String userId;
	
	/** The master number. */
	private List<String> masterNumber;
	
	/** The phone. */
	private String phone;
	
	/** The resident. */
	private String resident;
	
	/** The staff. */
	private String staff;
	
	/** The salary. */
	private String salary;
	
	/** The email notification. */
	private Boolean emailNotification;

	/** The inbox notification. */
	private Boolean inboxNotification;
	
	/** The sms notification. */
	private Boolean smsNotification;
	
	/** The migrated. */
	private String migrated;
	
	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the customer type.
	 *
	 * @return the customerType
	 */
	public String getCustomerType() {
		return customerType;
	}

	/**
	 * Sets the customer type.
	 *
	 * @param customerType the customerType to set
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	/**
	 * Gets the segment code.
	 *
	 * @return the segmentCode
	 */
	public String getSegmentCode() {
		return segmentCode;
	}

	/**
	 * Sets the segment code.
	 *
	 * @param segmentCode the segmentCode to set
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the login id.
	 *
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * Sets the login id.
	 *
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	/**
	 * Gets the cust name.
	 *
	 * @return the custName
	 */
	public String getCustName() {
		return custName;
	}

	/**
	 * Sets the cust name.
	 *
	 * @param custName the custName to set
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}

	/**
	 * Gets the customer group id.
	 *
	 * @return the customerGroupId
	 */
	public String getCustomerGroupId() {
		return customerGroupId;
	}

	/**
	 * Sets the customer group id.
	 *
	 * @param customerGroupId the customerGroupId to set
	 */
	public void setCustomerGroupId(String customerGroupId) {
		this.customerGroupId = customerGroupId;
	}

	/**
	 * Gets the customer id type.
	 *
	 * @return the customerIdType
	 */
	public String getCustomerIdType() {
		return customerIdType;
	}

	/**
	 * Sets the customer id type.
	 *
	 * @param customerIdType the customerIdType to set
	 */
	public void setCustomerIdType(String customerIdType) {
		this.customerIdType = customerIdType;
	}

	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * Sets the role.
	 *
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the channel id.
	 *
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * Sets the channel id.
	 *
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * Sets the environment.
	 *
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Sets the language.
	 *
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * Gets the request id.
	 *
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * Sets the request id.
	 *
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * Gets the service id.
	 *
	 * @return the serviceId
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * Sets the service id.
	 *
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * Gets the master number.
	 *
	 * @return the masterNumber
	 */
	public List<String> getMasterNumber() {
		return masterNumber;
	}

	/**
	 * Sets the master number.
	 *
	 * @param masterNumber the masterNumber to set
	 */
	public void setMasterNumber(List<String> masterNumber) {
		this.masterNumber = masterNumber;
	}

	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Sets the phone.
	 *
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Gets the limit segment code.
	 *
	 * @return the limitSegmentCode
	 */
	public String getLimitSegmentCode() {
		return limitSegmentCode;
	}

	/**
	 * Sets the limit segment code.
	 *
	 * @param limitSegmentCode the limitSegmentCode to set
	 */
	public void setLimitSegmentCode(String limitSegmentCode) {
		this.limitSegmentCode = limitSegmentCode;
	}

	/**
	 * Gets the resident.
	 *
	 * @return the resident
	 */
	public String getResident() {
		return resident;
	}

	/**
	 * Sets the resident.
	 *
	 * @param resident the resident to set
	 */
	public void setResident(String resident) {
		this.resident = resident;
	}

	/**
	 * Gets the staff.
	 *
	 * @return the staff
	 */
	public String getStaff() {
		return staff;
	}

	/**
	 * Sets the staff.
	 *
	 * @param staff the staff to set
	 */
	public void setStaff(String staff) {
		this.staff = staff;
	}

	/**
	 * Gets the salary.
	 *
	 * @return the salary
	 */
	public String getSalary() {
		return salary;
	}

	/**
	 * Sets the salary.
	 *
	 * @param salary the salary to set
	 */
	public void setSalary(String salary) {
		this.salary = salary;
	}

	/**
	 * Checks if is email notification.
	 *
	 * @return the emailNotification
	 */
	public Boolean isEmailNotification() {
		return emailNotification;
	}

	/**
	 * Sets the email notification.
	 *
	 * @param emailNotification the emailNotification to set
	 */
	public void setEmailNotification(Boolean emailNotification) {
		this.emailNotification = emailNotification;
	}

	/**
	 * Checks if is inbox notification.
	 *
	 * @return the inboxNotification
	 */
	public Boolean isInboxNotification() {
		return inboxNotification;
	}

	/**
	 * Sets the inbox notification.
	 *
	 * @param inboxNotification the inboxNotification to set
	 */
	public void setInboxNotification(Boolean inboxNotification) {
		this.inboxNotification = inboxNotification;
	}

	/**
	 * Checks if is sms notification.
	 *
	 * @return the smsNotification
	 */
	public Boolean isSmsNotification() {
		return smsNotification;
	}

	/**
	 * Sets the sms notification.
	 *
	 * @param smsNotification the smsNotification to set
	 */
	public void setSmsNotification(Boolean smsNotification) {
		this.smsNotification = smsNotification;
	}

	/**
	 * Gets the email notification.
	 *
	 * @return the emailNotification
	 */
	public Boolean getEmailNotification() {
		return emailNotification;
	}

	/**
	 * Gets the inbox notification.
	 *
	 * @return the inboxNotification
	 */
	public Boolean getInboxNotification() {
		return inboxNotification;
	}

	/**
	 * Gets the sms notification.
	 *
	 * @return the smsNotification
	 */
	public Boolean getSmsNotification() {
		return smsNotification;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the migrated
	 */
	public String getMigrated() {
		return migrated;
	}

	/**
	 * @param migrated the migrated to set
	 */
	public void setMigrated(String migrated) {
		this.migrated = migrated;
	}


}
