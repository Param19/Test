package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterResponse {


	private QRPaymentMasterResponseTransfer transfer;

	private QRPaymentMasterErrorsResponse errors;
	
	
	public QRPaymentMasterResponseTransfer getTransfer() {
		return transfer;
	}

	public void setTransfer(QRPaymentMasterResponseTransfer transfer) {
		this.transfer = transfer;
	}

	public Object getErrors() {
		return errors;
	}

	
	@Override
	public String toString() {
		return "QRPaymentMasterResponse [transfer=" + transfer + ", errors="
				+ errors + "]";
	}

	
}
