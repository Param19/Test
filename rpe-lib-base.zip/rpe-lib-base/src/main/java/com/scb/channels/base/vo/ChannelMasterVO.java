package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import com.scb.channels.base.helper.CommonConstants;

/**
 * The Class ChannelMasterVO.
 */
public class ChannelMasterVO implements Serializable, Cloneable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 613916443624154352L;
	
	/** The login id. */
	private String loginId;
	
	/** The date. */
	private Date date;
	
	/** The customer type. */
	private String customerType;
	
	/** The customer id. */
	private String customerId;
	
	/** The customer group id. */
	private String customerGroupId;
	
	/** The customer name1. */
	private String customerName1;
	
	/** The customer name2. */
	private String customerName2;
	
	/** The role. */
	private String role;
	
	/** The channel. */
	private String channel;
	
	/** The language. */
	private String language;
	
	/** The app name. */
	private String appName;
	
	/** The org. */
	private String org;
	
	/** The environment. */
	private String environment;
	
	/** The segment code. */
	private String segmentCode;
	
	/** The cust name. */
	private String custName;
	
	/** The version. */
	private String version;
	
	/** The request type. */
	private String requestType;
	
	/** The service name. */
	private String serviceName;
	
	/** The host env. */
	private String hostEnv;
	
	/** The req id. */
	private String reqId;
	
	/** The req type. */
	private String reqType;
	
	/** The session id. */
	private String sessionId;
	
	/** The captcha. */
	private String captcha;
	
	/** The status code. */
	private String statusCode;
	
	/** The status desc. */
	private String statusDesc;
	
	/** The login time. */
	private Calendar loginTime;
	
	/** The last login time. */
	private Calendar lastLoginTime;
	
	/** The logout time. */
	private Calendar logoutTime;
	
	/** The user status. */
	private String userStatus;
	
	/** The value code. */
	private String valueCode;
	
	/** The email. */
	private String email;
	
	/** The phone. */
	private String phone;
	
	/** The notif type. */
	private String notifType;
	
	/** The handset lost. */
	private String handsetLost;
	
	/** The is email enabled. */
	private String isEmailEnabled;
	
	/** The is sms enabled. */
	private String isSMSEnabled;
	
	/** The is service enabled. */
	private String isServiceEnabled;
	
	/** The operating account currency. */
	private String operatingAccountCurrency;
	
	/** The operating account no. */
	private String operatingAccountNo;
	
	/** The mobile operator code. */
	private String mobileOperatorCode;
	
	/** The mobile network id. */
	private String mobileNetworkId;
	
	/** The status cd. */
	private String statusCd;
	
	/** The menu request params. */
	private MenuRequestParams  menuRequestParams;
	
	/** The menu response params. */
	private MenuResponseParams menuResponseParams;
	
	/** The bank name. */
	private String bankName;
	
	/** The branch code. */
	private String branchCode;
	
	/** The account no. */
	private String accountNo;
	
	/** The beneficiary first name. */
	private String beneficiaryFirstName;
	
	/** The beneficiary last name. */
	private String beneficiaryLastName;
	
	/** The transaction amount. */
	private double transactionAmount;
	
	/** The currency code. */
	private String currencyCode;
	
	/** The transaction id. */
	private long transactionID;
	
	/** The transaction time stamp. */
	private XMLGregorianCalendar transactionTimeStamp; 
	
	/** The country code. */
	private String countryCode;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The edf1. */
	private String edf1;
	
	/** The edf2. */
	private String edf2;
	
	/** The device id. */
	private String deviceID;
	
	/** The migrated. */
	private String migrateFlag;

	/**
	 * Gets the service name.
	 *
	 * @return the service name
	 */
	public String getServiceName() {
		return serviceName;
	}
	
	/**
	 * Sets the service name.
	 *
	 * @param serviceName the new service name
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	/**
	 * Gets the host env.
	 *
	 * @return the host env
	 */
	public String getHostEnv() {
		return hostEnv;
	}
	
	/**
	 * Sets the host env.
	 *
	 * @param hostEnv the new host env
	 */
	public void setHostEnv(String hostEnv) {
		this.hostEnv = hostEnv;
	}
	
	/**
	 * Gets the req id.
	 *
	 * @return the req id
	 */
	public String getReqId() {
		return reqId;
	}
	
	/**
	 * Sets the req id.
	 *
	 * @param reqId the new req id
	 */
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	
	/**
	 * Gets the req type.
	 *
	 * @return the req type
	 */
	public String getReqType() {
		return reqType;
	}
	
	/**
	 * Sets the req type.
	 *
	 * @param reqType the new req type
	 */
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	
	/**
	 * Gets the menu request params.
	 *
	 * @return the menu request params
	 */
	public MenuRequestParams getMenuRequestParams() {
		return menuRequestParams;
	}
	
	/**
	 * Sets the menu request params.
	 *
	 * @param menuRequestParams the new menu request params
	 */
	public void setMenuRequestParams(MenuRequestParams menuRequestParams) {
		this.menuRequestParams = menuRequestParams;
	}
	
	/**
	 * Gets the customer type.
	 *
	 * @return the customer type
	 */
	public String getCustomerType() {
		return customerType;
	}
	
	/**
	 * Sets the customer type.
	 *
	 * @param customerType the new customer type
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	
	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	
	/**
	 * Sets the role.
	 *
	 * @param role the new role
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}
	
	/**
	 * Sets the date.
	 *
	 * @param date the new date
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the new channel
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}
	
	/**
	 * Sets the language.
	 *
	 * @param language the new language
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	
	/**
	 * Gets the app name.
	 *
	 * @return the app name
	 */
	public String getAppName() {
		return appName;
	}
	
	/**
	 * Sets the app name.
	 *
	 * @param appName the new app name
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	/**
	 * Gets the org.
	 *
	 * @return the org
	 */
	public String getOrg() {
		return org;
	}
	
	/**
	 * Sets the org.
	 *
	 * @param org the new org
	 */
	public void setOrg(String org) {
		this.org = org;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	
	/**
	 * Sets the environment.
	 *
	 * @param environment the new environment
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
	/**
	 * Gets the segment code.
	 *
	 * @return the segment code
	 */
	public String getSegmentCode() {
		return segmentCode;
	}
	
	/**
	 * Sets the segment code.
	 *
	 * @param segmentCode the new segment code
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	
	/**
	 * Gets the cust name.
	 *
	 * @return the cust name
	 */
	public String getCustName() {
		return (custName == null) ? (customerName1 +CommonConstants.SPACE+ (customerName2==null? "" : customerName2) ): custName;
	}
	
	/**
	 * Sets the cust name.
	 *
	 * @param custName the new cust name
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	/**
	 * Gets the request type.
	 *
	 * @return the request type
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the new request type
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	/**
	 * Gets the menu response params.
	 *
	 * @return the menu response params
	 */
	public MenuResponseParams getMenuResponseParams() {
		return menuResponseParams;
	}
	
	/**
	 * Sets the menu response params.
	 *
	 * @param menuResponseParams the new menu response params
	 */
	public void setMenuResponseParams(MenuResponseParams menuResponseParams) {
		this.menuResponseParams = menuResponseParams;
	}
	
	/**
	 * Gets the session id.
	 *
	 * @return the session id
	 */
	public String getSessionId() {
		return sessionId;
	}
	
	/**
	 * Sets the session id.
	 *
	 * @param sessionId the new session id
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	/**
	 * Gets the captcha.
	 *
	 * @return the captcha
	 */
	public String getCaptcha() {
		return captcha;
	}
	
	/**
	 * Sets the captcha.
	 *
	 * @param captcha the new captcha
	 */
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	
	/**
	 * Gets the login id.
	 *
	 * @return the login id
	 */
	public String getLoginId() {
		return loginId;
	}
	
	/**
	 * Sets the login id.
	 *
	 * @param loginId the new login id
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	
	/**
	 * Gets the status code.
	 *
	 * @return the status code
	 */
	public String getStatusCode() {
		return statusCode;
	}
	
	/**
	 * Sets the status code.
	 *
	 * @param statusCode the new status code
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	/**
	 * Gets the status desc.
	 *
	 * @return the status desc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}
	
	/**
	 * Sets the status desc.
	 *
	 * @param statusDesc the new status desc
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	/**
	 * Gets the user status.
	 *
	 * @return the user status
	 */
	public String getUserStatus() {
		return userStatus;
	}
	
	/**
	 * Sets the user status.
	 *
	 * @param userStatus the new user status
	 */
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	
	/**
	 * Gets the login time.
	 *
	 * @return the login time
	 */
	public Calendar getLoginTime() {
		return loginTime;
	}
	
	/**
	 * Sets the login time.
	 *
	 * @param loginTime the new login time
	 */
	public void setLoginTime(Calendar loginTime) {
		this.loginTime = loginTime;
	}
	
	/**
	 * Gets the last login time.
	 *
	 * @return the last login time
	 */
	public Calendar getLastLoginTime() {
		return lastLoginTime;
	}
	
	/**
	 * Sets the last login time.
	 *
	 * @param lastLoginTime the new last login time
	 */
	public void setLastLoginTime(Calendar lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	
	/**
	 * Gets the logout time.
	 *
	 * @return the logout time
	 */
	public Calendar getLogoutTime() {
		return logoutTime;
	}
	
	/**
	 * Sets the logout time.
	 *
	 * @param logoutTime the new logout time
	 */
	public void setLogoutTime(Calendar logoutTime) {
		this.logoutTime = logoutTime;
	}
	
	/**
	 * Gets the value code.
	 *
	 * @return the valueCode
	 */
	public String getValueCode() {
		return valueCode;
	}
	
	/**
	 * Sets the value code.
	 *
	 * @param valueCode the valueCode to set
	 */
	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}
	
	/**
	 * Gets the customer id.
	 *
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	
	/**
	 * Sets the customer id.
	 *
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	/**
	 * Gets the customer group id.
	 *
	 * @return the customerGroupId
	 */
	public String getCustomerGroupId() {
		return customerGroupId;
	}
	
	/**
	 * Sets the customer group id.
	 *
	 * @param customerGroupId the customerGroupId to set
	 */
	public void setCustomerGroupId(String customerGroupId) {
		this.customerGroupId = customerGroupId;
	}
	
	/**
	 * Gets the customer name1.
	 *
	 * @return the customerName1
	 */
	public String getCustomerName1() {
		return customerName1;
	}
	
	/**
	 * Sets the customer name1.
	 *
	 * @param customerName1 the customerName1 to set
	 */
	public void setCustomerName1(String customerName1) {
		this.customerName1 = customerName1;
	}
	
	/**
	 * Gets the customer name2.
	 *
	 * @return the customerName2
	 */
	public String getCustomerName2() {
		return customerName2;
	}
	
	/**
	 * Sets the customer name2.
	 *
	 * @param customerName2 the customerName2 to set
	 */
	public void setCustomerName2(String customerName2) {
		this.customerName2 = customerName2;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	
	/**
	 * Sets the phone.
	 *
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	/**
	 * Gets the checks if is email enabled.
	 *
	 * @return the isEmailEnabled
	 */
	public String getIsEmailEnabled() {
		return isEmailEnabled;
	}
	
	/**
	 * Sets the checks if is email enabled.
	 *
	 * @param isEmailEnabled the isEmailEnabled to set
	 */
	public void setIsEmailEnabled(String isEmailEnabled) {
		this.isEmailEnabled = isEmailEnabled;
	}
	
	/**
	 * Gets the checks if is sms enabled.
	 *
	 * @return the isSMSEnabled
	 */
	public String getIsSMSEnabled() {
		return isSMSEnabled;
	}
	
	/**
	 * Sets the checks if is sms enabled.
	 *
	 * @param isSMSEnabled the isSMSEnabled to set
	 */
	public void setIsSMSEnabled(String isSMSEnabled) {
		this.isSMSEnabled = isSMSEnabled;
	}
	
	/**
	 * Gets the checks if is service enabled.
	 *
	 * @return the isServiceEnabled
	 */
	public String getIsServiceEnabled() {
		return isServiceEnabled;
	}
	
	/**
	 * Sets the checks if is service enabled.
	 *
	 * @param isServiceEnabled the isServiceEnabled to set
	 */
	public void setIsServiceEnabled(String isServiceEnabled) {
		this.isServiceEnabled = isServiceEnabled;
	}
	
	/**
	 * Gets the notif type.
	 *
	 * @return the notifType
	 */
	public String getNotifType() {
		return notifType;
	}
	
	/**
	 * Sets the notif type.
	 *
	 * @param notifType the notifType to set
	 */
	public void setNotifType(String notifType) {
		this.notifType = notifType;
	}
	
	/**
	 * Gets the handset lost.
	 *
	 * @return the handsetLost
	 */
	public String getHandsetLost() {
		return handsetLost;
	}
	
	/**
	 * Sets the handset lost.
	 *
	 * @param handsetLost the handsetLost to set
	 */
	public void setHandsetLost(String handsetLost) {
		this.handsetLost = handsetLost;
	}
	
	/**
	 * Gets the operating account currency.
	 *
	 * @return the operatingAccountCurrency
	 */
	public String getOperatingAccountCurrency() {
		return operatingAccountCurrency;
	}
	
	/**
	 * Sets the operating account currency.
	 *
	 * @param operatingAccountCurrency the operatingAccountCurrency to set
	 */
	public void setOperatingAccountCurrency(String operatingAccountCurrency) {
		this.operatingAccountCurrency = operatingAccountCurrency;
	}
	
	/**
	 * Gets the operating account no.
	 *
	 * @return the operatingAccountNo
	 */
	public String getOperatingAccountNo() {
		return operatingAccountNo;
	}
	
	/**
	 * Sets the operating account no.
	 *
	 * @param operatingAccountNo the operatingAccountNo to set
	 */
	public void setOperatingAccountNo(String operatingAccountNo) {
		this.operatingAccountNo = operatingAccountNo;
	}
	
	/**
	 * Gets the mobile operator code.
	 *
	 * @return the mobileOperatorCode
	 */
	public String getMobileOperatorCode() {
		return mobileOperatorCode;
	}
	
	/**
	 * Sets the mobile operator code.
	 *
	 * @param mobileOperatorCode the mobileOperatorCode to set
	 */
	public void setMobileOperatorCode(String mobileOperatorCode) {
		this.mobileOperatorCode = mobileOperatorCode;
	}
	
	/**
	 * Gets the mobile network id.
	 *
	 * @return the mobileNetworkId
	 */
	public String getMobileNetworkId() {
		return mobileNetworkId;
	}
	
	/**
	 * Sets the mobile network id.
	 *
	 * @param mobileNetworkId the mobileNetworkId to set
	 */
	public void setMobileNetworkId(String mobileNetworkId) {
		this.mobileNetworkId = mobileNetworkId;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	/**
	 * Gets the bank name.
	 *
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * Sets the bank name.
	 *
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Gets the branch code.
	 *
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * Sets the branch code.
	 *
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * Gets the account no.
	 *
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * Sets the account no.
	 *
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * Gets the beneficiary first name.
	 *
	 * @return the beneficiaryFirstName
	 */
	public String getBeneficiaryFirstName() {
		return beneficiaryFirstName;
	}

	/**
	 * Sets the beneficiary first name.
	 *
	 * @param beneficiaryFirstName the beneficiaryFirstName to set
	 */
	public void setBeneficiaryFirstName(String beneficiaryFirstName) {
		this.beneficiaryFirstName = beneficiaryFirstName;
	}

	/**
	 * Gets the beneficiary last name.
	 *
	 * @return the beneficiaryLastName
	 */
	public String getBeneficiaryLastName() {
		return beneficiaryLastName;
	}

	/**
	 * Sets the beneficiary last name.
	 *
	 * @param beneficiaryLastName the beneficiaryLastName to set
	 */
	public void setBeneficiaryLastName(String beneficiaryLastName) {
		this.beneficiaryLastName = beneficiaryLastName;
	}

	/**
	 * Gets the transaction amount.
	 *
	 * @return the transactionAmount
	 */
	public double getTransactionAmount() {
		return transactionAmount;
	}

	/**
	 * Sets the transaction amount.
	 *
	 * @param transactionAmount the transactionAmount to set
	 */
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Gets the transaction id.
	 *
	 * @return the transactionID
	 */
	public long getTransactionID() {
		return transactionID;
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}

	/**
	 * Gets the transaction time stamp.
	 *
	 * @return the transactionTimeStamp
	 */
	public XMLGregorianCalendar getTransactionTimeStamp() {
		return transactionTimeStamp;
	}

	/**
	 * Sets the transaction time stamp.
	 *
	 * @param transactionTimeStamp the transactionTimeStamp to set
	 */
	public void setTransactionTimeStamp(XMLGregorianCalendar transactionTimeStamp) {
		this.transactionTimeStamp = transactionTimeStamp;
	}

	/**
	 * Gets the country code.
	 *
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * Sets the country code.
	 *
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Gets the edf1.
	 *
	 * @return the edf1
	 */
	public String getEdf1() {
		return edf1;
	}

	/**
	 * Sets the edf1.
	 *
	 * @param edf1 the edf1 to set
	 */
	public void setEdf1(String edf1) {
		this.edf1 = edf1;
	}

	/**
	 * Gets the edf2.
	 *
	 * @return the edf2
	 */
	public String getEdf2() {
		return edf2;
	}

	/**
	 * Sets the edf2.
	 *
	 * @param edf2 the edf2 to set
	 */
	public void setEdf2(String edf2) {
		this.edf2 = edf2;
	}

	/**
	 * Gets the device id.
	 *
	 * @return the deviceID
	 */
	public String getDeviceID() {
		return deviceID;
	}

	/**
	 * Sets the device id.
	 *
	 * @param deviceID the deviceID to set
	 */
	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	/**
	 * @return the migrateFlag
	 */
	public String getMigrateFlag() {
		return migrateFlag;
	}

	/**
	 * @param migrateFlag the migrateFlag to set
	 */
	public void setMigrateFlag(String migrateFlag) {
		this.migrateFlag = migrateFlag;
	}

	
}
