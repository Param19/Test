/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Date;

/**
 * The Class AccountTxnRequestVO.
 *
 * @author 1411807
 */
public class AccountTxnRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4128370957690074397L;
	private Date dateLogin;
	private int version;
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public Date getDateLogin() {
		return dateLogin;
	}
	public void setDateLogin(Date dateLogin) {
		this.dateLogin = dateLogin;
	}



}
