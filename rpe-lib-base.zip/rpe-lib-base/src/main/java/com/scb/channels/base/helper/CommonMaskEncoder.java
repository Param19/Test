package com.scb.channels.base.helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * The class CommonMaskEncoder.
 *
 * @author 1411807
 */
public class CommonMaskEncoder extends PatternLayoutEncoder {
	
	/** The Constant MASK_FLAG. */
	public static final String MASK_FLAG = "mask";
	
	/** The mask context map. */
	private static Map<String, MaskContext> maskContextMap = new HashMap<String, MaskContext>();
	
	/** The masker master. */
	public static Map<String, List<Masker>> maskerMaster = new HashMap<String, List<Masker>>();
	
	static {
		Map<String, List<Masker>> map = new HashMap<String, List<Masker>>();
		List<Masker> value = new ArrayList<Masker>();
		
		Masker m = new Masker("(mPin:)([^<]*)",2,"L6,*");
		//Masker m1 = new Masker("(SourceAccountNumber>)([^<]*)",2,"L6,*");
		Masker m1 = new Masker("(SourceAccountNumber>)([^-\\s]*)",2,"L6,*");
		
		Masker m2 = new Masker("(PAN>)([^-\\s]*)",2,"L6,*");
		Masker m3 = new Masker("(fromAccountNumber>)([^-\\s]*)",2,"L6,*");
		Masker m4 = new Masker("(cardNumber>)([^-\\s]*)",2,"L6,*");
		Masker m5 = new Masker("(cardNumber=)([^-\\s]*)",2,"L6,*");
		Masker m6 = new Masker("(getCardNumber\\(\\)=)([^-\\s]*)",2,"L6,*");
		Masker m7 = new Masker("(senderAccountNumber\":\")([^-\\s]*)",2,"L6,*");
		Masker m8 = new Masker("(card_number=)([^-\\s]*)",2,"L6,*");
		value.add(m);
		value.add(m1);
		value.add(m2);
		value.add(m3);
		value.add(m4);
		value.add(m5);
		value.add(m6);
		value.add(m7);
		value.add(m8);
		map.put("ALL",value);
		map.put("KE", value);
		map.put("CI", value); 
		map.put("IN", value);
		map.put("GH", value);
		map.put("TZ", value);
		map.put("ZW", value);
		map.put("ZM", value);
		map.put("BW", value);
		map.put("NG", value);
		map.put("UG",value);
		map.put("PK",value);
		map.put("HK",value);
		
		CommonMaskEncoder.maskerMaster.putAll(map);
	}

    /**
	 * Gets the location.
	 * 
	 * @return the location
	 */
    public String getLocation() {
        return ApplicationContext.getLocation()==null?"all":ApplicationContext.getLocation();
    }

    /* (non-Javadoc)
     * @see ch.qos.logback.core.encoder.LayoutWrappingEncoder#doEncode(java.lang.Object)
     */
    public void doEncode(ILoggingEvent event) throws IOException {
         String txt = this.layout.doLayout(event);
         txt = maskContent(txt);
         this.outputStream.write(convertToBytes(txt));
         this.outputStream.flush();
    }
    
    /**
     * Convert to bytes.
     *
     * @param s the s
     * @return the byte[]
     */
    private byte[] convertToBytes(String s) {
    	if (getCharset() == null)
    		return s.getBytes();
        try {
           return s.getBytes(getCharset().name());
        } catch (UnsupportedEncodingException e) {
           throw new IllegalStateException("An existing charset cannot possibly be unsupported.");
        }
    }
     
    /**
     * Mask content.
     *
     * @param content the content
     * @return the string
     */
    private String maskContent(String content) {
    	//String key = ApplicationContext.getCountry()+ CommonConstants.HYPHEN + ApplicationContext.getServiceName();
    	String key = ApplicationContext.getCountry();
    	if (key != null) {
    		initMaskIfNecessary();
    		if (null != maskContextMap.get(key)) {
    			content = MaskUtils.mask(content, (MaskContext) maskContextMap.get(key));
    		}
    	}
    	return content;
    }
     
   /**
    * Inits the mask if necessary.
    */
    private void initMaskIfNecessary() {
	   if (maskContextMap.isEmpty())  {
		   MaskContext maskContext;
		   synchronized (maskContextMap) {
			   if (maskContextMap.isEmpty() && 
					   (!maskerMaster.isEmpty())) {
				   for (Entry<String, List<Masker>> entry :maskerMaster.entrySet()) {
					   maskContext = null;
					   maskContext = new MaskContext(entry.getValue());
					   maskContextMap.put(entry.getKey(), maskContext);
				   }
			   }
		   }
	   }
   }
     
    public static void reloadMaskDetails() {
	   MaskContext maskContext;
	   synchronized (maskContextMap) {
		   if (!maskerMaster.isEmpty()) {
			   for (Entry<String, List<Masker>> entry :maskerMaster.entrySet()) {
				   maskContext = null;
				   maskContext = new MaskContext(entry.getValue());
				   maskContextMap.put(entry.getKey(), maskContext);
			   }
		   }
	   }
    }
      
}
