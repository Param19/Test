package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class BillerListResponseVO.
 */
public class BillerListResponseVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1493795083330553217L;

	/** The biller list. */
	private List<BillerDetailsVO> billerList = new ArrayList<BillerDetailsVO>();
	
	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;

	/**
	 * Gets the biller list.
	 *
	 * @return the billerList
	 */
	public List<BillerDetailsVO> getBillerList() {
		return billerList;
	}

	/**
	 * Sets the biller list.
	 *
	 * @param billerList the billerList to set
	 */
	public void setBillerList(List<BillerDetailsVO> billerList) {
		this.billerList = billerList;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
}
