package com.scb.channels.base.vo;

import java.io.Serializable;

public class CurrentBalanceVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -342809899917497602L;
	
	private String balancePeriodIndicator;
    private String averageAvailableBalance;
    private String averageLedgerBalance;
    private String maximumAvailableBalance;
    private String maximumLedgerBalance;
    private String minimumAvailableBalance;
    private String minimumLedgerBalance;
    private String averageCreditAvailableBalance;
    private String averageDebitAvailableBalance;
	
    
    public String getBalancePeriodIndicator() {
		return balancePeriodIndicator;
	}
	public void setBalancePeriodIndicator(String balancePeriodIndicator) {
		this.balancePeriodIndicator = balancePeriodIndicator;
	}
	public String getAverageAvailableBalance() {
		return averageAvailableBalance;
	}
	public void setAverageAvailableBalance(String averageAvailableBalance) {
		this.averageAvailableBalance = averageAvailableBalance;
	}
	public String getAverageLedgerBalance() {
		return averageLedgerBalance;
	}
	public void setAverageLedgerBalance(String averageLedgerBalance) {
		this.averageLedgerBalance = averageLedgerBalance;
	}
	public String getMaximumAvailableBalance() {
		return maximumAvailableBalance;
	}
	public void setMaximumAvailableBalance(String maximumAvailableBalance) {
		this.maximumAvailableBalance = maximumAvailableBalance;
	}
	public String getMaximumLedgerBalance() {
		return maximumLedgerBalance;
	}
	public void setMaximumLedgerBalance(String maximumLedgerBalance) {
		this.maximumLedgerBalance = maximumLedgerBalance;
	}
	public String getMinimumAvailableBalance() {
		return minimumAvailableBalance;
	}
	public void setMinimumAvailableBalance(String minimumAvailableBalance) {
		this.minimumAvailableBalance = minimumAvailableBalance;
	}
	public String getMinimumLedgerBalance() {
		return minimumLedgerBalance;
	}
	public void setMinimumLedgerBalance(String minimumLedgerBalance) {
		this.minimumLedgerBalance = minimumLedgerBalance;
	}
	public String getAverageCreditAvailableBalance() {
		return averageCreditAvailableBalance;
	}
	public void setAverageCreditAvailableBalance(
			String averageCreditAvailableBalance) {
		this.averageCreditAvailableBalance = averageCreditAvailableBalance;
	}
	public String getAverageDebitAvailableBalance() {
		return averageDebitAvailableBalance;
	}
	public void setAverageDebitAvailableBalance(String averageDebitAvailableBalance) {
		this.averageDebitAvailableBalance = averageDebitAvailableBalance;
	}

}
