/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Date;

/**
 * The Class AccountListRequestVO.
 *
 * @author 1411807
 */
public class AccountListRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8522704872830331071L;
	
	private Date dateLogin;
	private int version;

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public Date getDateLogin() {
		return dateLogin;
	}

	public void setDateLogin(Date dateLogin) {
		this.dateLogin = dateLogin;
	}


}
