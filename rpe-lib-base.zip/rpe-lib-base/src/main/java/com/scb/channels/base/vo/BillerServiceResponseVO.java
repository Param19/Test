package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerListResponseVO.
 */
public class BillerServiceResponseVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1493795083330553217L;

	
	
	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;

	private String serviceName;

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	
}
