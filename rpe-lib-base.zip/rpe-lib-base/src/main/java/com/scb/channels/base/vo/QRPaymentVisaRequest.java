package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class QRPaymentVisaRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4137445244663914178L;
	
	private String systemsTraceAuditNumber;
	private String retrievalReferenceNumber;
	private String recipientPrimaryAccountNumber;
	private BigDecimal amount;
	private String localTransactionDateTime;
	private String merchantCategoryCode;
	private String acquirerCountryCode;
	private String acquiringBin;
	private QRPaymentVisaCardAcceptor cardAcceptor;
	private String transactionCurrencyCode;
	private QRPaymentVisaPurchaseIdentifier PurchaseIdentifier;
	private String businessApplicationId;
	private String senderReference;
	private String senderAccountNumber;
	private String senderName;
	private String secondaryId;
	public String getSystemsTraceAuditNumber() {
		return systemsTraceAuditNumber;
	}
	public void setSystemsTraceAuditNumber(String systemsTraceAuditNumber) {
		this.systemsTraceAuditNumber = systemsTraceAuditNumber;
	}
	public String getRetrievalReferenceNumber() {
		return retrievalReferenceNumber;
	}
	public void setRetrievalReferenceNumber(String retrievalReferenceNumber) {
		this.retrievalReferenceNumber = retrievalReferenceNumber;
	}
	public String getRecipientPrimaryAccountNumber() {
		return recipientPrimaryAccountNumber;
	}
	public void setRecipientPrimaryAccountNumber(
			String recipientPrimaryAccountNumber) {
		this.recipientPrimaryAccountNumber = recipientPrimaryAccountNumber;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getLocalTransactionDateTime() {
		return localTransactionDateTime;
	}
	public void setLocalTransactionDateTime(String localTransactionDateTime) {
		this.localTransactionDateTime = localTransactionDateTime;
	}
	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}
	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}
	public String getAcquirerCountryCode() {
		return acquirerCountryCode;
	}
	public void setAcquirerCountryCode(String acquirerCountryCode) {
		this.acquirerCountryCode = acquirerCountryCode;
	}
	public String getAcquiringBin() {
		return acquiringBin;
	}
	public void setAcquiringBin(String acquiringBin) {
		this.acquiringBin = acquiringBin;
	}
	public QRPaymentVisaCardAcceptor getCardAcceptor() {
		return cardAcceptor;
	}
	public void setCardAcceptor(QRPaymentVisaCardAcceptor cardAcceptor) {
		this.cardAcceptor = cardAcceptor;
	}
	public String getTransactionCurrencyCode() {
		return transactionCurrencyCode;
	}
	public void setTransactionCurrencyCode(String transactionCurrencyCode) {
		this.transactionCurrencyCode = transactionCurrencyCode;
	}
	public QRPaymentVisaPurchaseIdentifier getPurchaseIdentifier() {
		return PurchaseIdentifier;
	}
	public void setPurchaseIdentifier(
			QRPaymentVisaPurchaseIdentifier purchaseIdentifier) {
		PurchaseIdentifier = purchaseIdentifier;
	}
	public String getBusinessApplicationId() {
		return businessApplicationId;
	}
	public void setBusinessApplicationId(String businessApplicationId) {
		this.businessApplicationId = businessApplicationId;
	}
	public String getSenderReference() {
		return senderReference;
	}
	public void setSenderReference(String senderReference) {
		this.senderReference = senderReference;
	}
	public String getSenderAccountNumber() {
		return senderAccountNumber;
	}
	public void setSenderAccountNumber(String senderAccountNumber) {
		this.senderAccountNumber = senderAccountNumber;
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public String getSecondaryId() {
		return secondaryId;
	}
	public void setSecondaryId(String secondaryId) {
		this.secondaryId = secondaryId;
	}
	@Override
	public String toString() {
		return "QRPaymentVisaRequest [systemsTraceAuditNumber="
				+ systemsTraceAuditNumber + ", retrievalReferenceNumber="
				+ retrievalReferenceNumber + ", recipientPrimaryAccountNumber="
				+ recipientPrimaryAccountNumber + ", amount=" + amount
				+ ", localTransactionDateTime=" + localTransactionDateTime
				+ ", merchantCategoryCode=" + merchantCategoryCode
				+ ", acquirerCountryCode=" + acquirerCountryCode
				+ ", acquiringBin=" + acquiringBin + ", cardAcceptor="
				+ cardAcceptor + ", transactionCurrencyCode="
				+ transactionCurrencyCode + ", PurchaseIdentifier="
				+ PurchaseIdentifier + ", businessApplicationId="
				+ businessApplicationId + ", senderReference="
				+ senderReference + ", senderAccountNumber="
				+ senderAccountNumber + ", senderName=" + senderName
				+ ", secondaryId=" + secondaryId + "]";
	}
	
	

}
