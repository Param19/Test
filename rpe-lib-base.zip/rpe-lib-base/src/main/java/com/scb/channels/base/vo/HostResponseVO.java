package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class HostResponseVO.
 */
public class HostResponseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8523921481554569692L;

	/** The code. */
	private String code;
	
	/** The desc. */
	private String desc;
	
	/** The host name. */
	private String hostName;
	
	/** The host ref. */
	private List<RefInfoTypeVO> hostRef;
	
	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	
	/**
	 * Sets the code.
	 *
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**
	 * Gets the desc.
	 *
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}
	
	/**
	 * Sets the desc.
	 *
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	/**
	 * Gets the host name.
	 *
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}
	
	/**
	 * Sets the host name.
	 *
	 * @param hostName the hostName to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	
	/**
	 * Gets the host ref.
	 *
	 * @return the hostRef
	 */
	public List<RefInfoTypeVO> getHostRef() {
		return hostRef;
	}
	
	/**
	 * Sets the host ref.
	 *
	 * @param hostRef the hostRef to set
	 */
	public void setHostRef(List<RefInfoTypeVO> hostRef) {
		this.hostRef = hostRef;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((desc == null) ? 0 : desc.hashCode());
		result = prime * result
				+ ((hostName == null) ? 0 : hostName.hashCode());
		result = prime * result + ((hostRef == null) ? 0 : hostRef.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HostResponseVO other = (HostResponseVO) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (desc == null) {
			if (other.desc != null)
				return false;
		} else if (!desc.equals(other.desc))
			return false;
		if (hostName == null) {
			if (other.hostName != null)
				return false;
		} else if (!hostName.equals(other.hostName))
			return false;
		if (hostRef == null) {
			if (other.hostRef != null)
				return false;
		} else if (!hostRef.equals(other.hostRef))
			return false;
		return true;
	}
	
	
}
