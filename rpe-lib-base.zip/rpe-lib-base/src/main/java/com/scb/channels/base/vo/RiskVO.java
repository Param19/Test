package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

/**
 * The Class RiskVO.
 */
public class RiskVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3169533837317571404L;
	
	/** The currency code. */
	private String currencyCode;
	
	/** The account number. */
	private String accountNumber;
	
	/** The risk code. */
	private String riskCode;
	
	/** The department code. */
	private String departmentCode;
	
	/** The start date. */
	private Calendar startDate;
	
	/** The end date. */
	private Calendar endDate;
	
	/** The remarks. */
	private String remarks;
	
	/** The description. */
	private String description;
	
	/** The type. */
	private String type;
	
	/** The action. */
	private String action;
    
    /** The level. */
    private String level;
    
    /** The status. */
    private String status;
    
    /** The master number. */
    private String masterNumber;
    
    /** The customer identification number. */
    private String customerIdentificationNumber;
    
    /** The primary relationship indicator. */
    private String primaryRelationshipIndicator;
    
    /** The maker. */
    private MakerVO maker;
    
    /** The checker. */
    private CheckerVO checker;
	
    
    /**
     * Gets the currency code.
     *
     * @return the currency code
     */
    public String getCurrencyCode() {
		return currencyCode;
	}
	
	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	
	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	
	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	/**
	 * Gets the risk code.
	 *
	 * @return the risk code
	 */
	public String getRiskCode() {
		return riskCode;
	}
	
	/**
	 * Sets the risk code.
	 *
	 * @param riskCode the new risk code
	 */
	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}
	
	/**
	 * Gets the department code.
	 *
	 * @return the department code
	 */
	public String getDepartmentCode() {
		return departmentCode;
	}
	
	/**
	 * Sets the department code.
	 *
	 * @param departmentCode the new department code
	 */
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}
	
	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Calendar getStartDate() {
		return startDate;
	}
	
	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}
	
	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Calendar getEndDate() {
		return endDate;
	}
	
	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}
	
	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	
	/**
	 * Sets the remarks.
	 *
	 * @param remarks the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	
	/**
	 * Sets the action.
	 *
	 * @param action the new action
	 */
	public void setAction(String action) {
		this.action = action;
	}
	
	/**
	 * Gets the level.
	 *
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	
	/**
	 * Sets the level.
	 *
	 * @param level the new level
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the master number.
	 *
	 * @return the master number
	 */
	public String getMasterNumber() {
		return masterNumber;
	}
	
	/**
	 * Sets the master number.
	 *
	 * @param masterNumber the new master number
	 */
	public void setMasterNumber(String masterNumber) {
		this.masterNumber = masterNumber;
	}
	
	/**
	 * Gets the customer identification number.
	 *
	 * @return the customer identification number
	 */
	public String getCustomerIdentificationNumber() {
		return customerIdentificationNumber;
	}
	
	/**
	 * Sets the customer identification number.
	 *
	 * @param customerIdentificationNumber the new customer identification number
	 */
	public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
		this.customerIdentificationNumber = customerIdentificationNumber;
	}
	
	/**
	 * Gets the primary relationship indicator.
	 *
	 * @return the primary relationship indicator
	 */
	public String getPrimaryRelationshipIndicator() {
		return primaryRelationshipIndicator;
	}
	
	/**
	 * Sets the primary relationship indicator.
	 *
	 * @param primaryRelationshipIndicator the new primary relationship indicator
	 */
	public void setPrimaryRelationshipIndicator(String primaryRelationshipIndicator) {
		this.primaryRelationshipIndicator = primaryRelationshipIndicator;
	}
	
	/**
	 * Gets the maker.
	 *
	 * @return the maker
	 */
	public MakerVO getMaker() {
		return maker;
	}
	
	/**
	 * Sets the maker.
	 *
	 * @param maker the new maker
	 */
	public void setMaker(MakerVO maker) {
		this.maker = maker;
	}
	
	/**
	 * Gets the checker.
	 *
	 * @return the checker
	 */
	public CheckerVO getChecker() {
		return checker;
	}
	
	/**
	 * Sets the checker.
	 *
	 * @param checker the new checker
	 */
	public void setChecker(CheckerVO checker) {
		this.checker = checker;
	}

}
