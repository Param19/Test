/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class PinChangeRequestVO.
 *
 * @author 1411807
 */
public class PinChangeRequestVO extends BaseVO {


	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7453483967800071437L;

	/** The new auth vo. */
	private AuthVO newAuthVO;
	
	/** The auth vo. */
	private AuthVO authVO;

	private int version;
	
	/**
	 * Gets the auth vo.
	 *
	 * @return the authVO
	 */
	public AuthVO getAuthVO() {
		return authVO;
	}

	/**
	 * Sets the auth vo.
	 *
	 * @param authVO the authVO to set
	 */
	public void setAuthVO(AuthVO authVO) {
		this.authVO = authVO;
	}

	/**
	 * Gets the new auth vo.
	 *
	 * @return the newAuthVO
	 */
	public AuthVO getNewAuthVO() {
		return newAuthVO;
	}

	/**
	 * Sets the new auth vo.
	 *
	 * @param newAuthVO the newAuthVO to set
	 */
	public void setNewAuthVO(AuthVO newAuthVO) {
		this.newAuthVO = newAuthVO;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

}
