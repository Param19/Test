/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ValidateBeneficiaryRequestVO.
 *
 * @author 1411807
 */
public class ValidateBeneficiaryRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1136668810646467895L;



}
