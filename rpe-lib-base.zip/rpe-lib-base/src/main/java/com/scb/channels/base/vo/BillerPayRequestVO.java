package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerPayRequestVO.
 */
public class BillerPayRequestVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7683864660547612191L;
	
	/** The biller pay details vo. */
	private BillerPayDetailsVO billerPayDetailsVO;
	
	private AccountInquiryVO accountInquiryVO;
	
	/** The bill pay registration vo. */
	private BillPayRegistrationVO billPayRegistrationVO;
	
	private String auditIdentifier;

	/**
	 * @return the auditIdentifier
	 */
	public String getAuditIdentifier() {
		return auditIdentifier;
	}

	/**
	 * @param auditIdentifier the auditIdentifier to set
	 */
	public void setAuditIdentifier(String auditIdentifier) {
		this.auditIdentifier = auditIdentifier;
	}
	
	/*private InvoiceVO invoiceVO;*/

	/**
	 * Gets the biller pay details vo.
	 *
	 * @return the billerPayDetailsVO
	 */
	public BillerPayDetailsVO getBillerPayDetailsVO() {
		return billerPayDetailsVO;
	}

	/**
	 * Sets the biller pay details vo.
	 *
	 * @param billerPayDetailsVO the billerPayDetailsVO to set
	 */
	public void setBillerPayDetailsVO(BillerPayDetailsVO billerPayDetailsVO) {
		this.billerPayDetailsVO = billerPayDetailsVO;
	}

	public AccountInquiryVO getAccountInquiryVO() {
		return accountInquiryVO;
	}

	public void setAccountInquiryVO(AccountInquiryVO accountInquiryVO) {
		this.accountInquiryVO = accountInquiryVO;
	}

	public BillPayRegistrationVO getBillPayRegistrationVO() {
		return billPayRegistrationVO;
	}

	public void setBillPayRegistrationVO(BillPayRegistrationVO billPayRegistrationVO) {
		this.billPayRegistrationVO = billPayRegistrationVO;
	}

}
