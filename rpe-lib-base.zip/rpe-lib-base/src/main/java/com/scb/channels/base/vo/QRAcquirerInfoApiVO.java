package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QRAcquirerInfoApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	private String merchantCategoryCode;
    private String retrievalReferenceNumber;
    private String systemsTraceAuditNumber;
    private String networkReferenceNumber;
    private String transactionIdentifier;
	private String merchantPan;
	private String merchantCity;
	private String merchantName;
	
	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}
	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}
	public String getRetrievalReferenceNumber() {
		return retrievalReferenceNumber;
	}
	public void setRetrievalReferenceNumber(String retrievalReferenceNumber) {
		this.retrievalReferenceNumber = retrievalReferenceNumber;
	}
	public String getSystemsTraceAuditNumber() {
		return systemsTraceAuditNumber;
	}
	public void setSystemsTraceAuditNumber(String systemsTraceAuditNumber) {
		this.systemsTraceAuditNumber = systemsTraceAuditNumber;
	}
	public String getNetworkReferenceNumber() {
		return networkReferenceNumber;
	}
	public void setNetworkReferenceNumber(String networkReferenceNumber) {
		this.networkReferenceNumber = networkReferenceNumber;
	}
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}
	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}
	public String getMerchantPan() {
		return merchantPan;
	}
	public void setMerchantPan(String merchantPan) {
		this.merchantPan = merchantPan;
	}
	public String getMerchantCity() {
		return merchantCity;
	}
	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "QRAcquirerInfoApiVO [merchantCategoryCode="
				+ merchantCategoryCode + ", retrievalReferenceNumber="
				+ retrievalReferenceNumber + ", systemsTraceAuditNumber="
				+ systemsTraceAuditNumber + ", networkReferenceNumber="
				+ networkReferenceNumber + ", transactionIdentifier="
				+ transactionIdentifier + ", merchantPan=" + merchantPan
				+ ", merchantCity=" + merchantCity + ", merchantName="
				+ merchantName + "]";
	}
	
}
