/**
 * 
 */
package com.scb.channels.base.vo;

import java.util.Calendar;

/**
 * The Class LoginResponseVO.
 *
 * @author 1411807
 */
public class LoginResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -946989109970914514L;

	/** The login time. */
	private Calendar loginTime;

	/** The last login time. */
	private Calendar lastLoginTime;

	/** The failed count. */
	private Integer failedCount;

	/** The change password. */
	private Boolean changePassword;

	/** The user status. */
	private String userStatus;

	/** The login session id. */
	private String loginSessionId;

	/** The value code. */
	private String valueCode;

	/** The status cd. */
	private String statusCd;

	/**
	 * Gets the login time.
	 *
	 * @return the loginTime
	 */
	public Calendar getLoginTime() {
		return loginTime;
	}

	/**
	 * Sets the login time.
	 *
	 * @param loginTime the loginTime to set
	 */
	public void setLoginTime(Calendar loginTime) {
		this.loginTime = loginTime;
	}

	/**
	 * Gets the last login time.
	 *
	 * @return the lastLoginTime
	 */
	public Calendar getLastLoginTime() {
		return lastLoginTime;
	}

	/**
	 * Sets the last login time.
	 *
	 * @param lastLoginTime the lastLoginTime to set
	 */
	public void setLastLoginTime(Calendar lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	/**
	 * Gets the failed count.
	 *
	 * @return the failedCount
	 */
	public Integer getFailedCount() {
		return failedCount;
	}

	/**
	 * Sets the failed count.
	 *
	 * @param failedCount the failedCount to set
	 */
	public void setFailedCount(Integer failedCount) {
		this.failedCount = failedCount;
	}

	/**
	 * Gets the change password.
	 *
	 * @return the changePassword
	 */
	public Boolean getChangePassword() {
		return changePassword;
	}

	/**
	 * Sets the change password.
	 *
	 * @param changePassword the changePassword to set
	 */
	public void setChangePassword(Boolean changePassword) {
		this.changePassword = changePassword;
	}

	/**
	 * Gets the user status.
	 *
	 * @return the userStatus
	 */
	public String getUserStatus() {
		return userStatus;
	}

	/**
	 * Sets the user status.
	 *
	 * @param userStatus the userStatus to set
	 */
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	/**
	 * Gets the login session id.
	 *
	 * @return the loginSessionId
	 */
	public String getLoginSessionId() {
		return loginSessionId;
	}

	/**
	 * Sets the login session id.
	 *
	 * @param loginSessionId the loginSessionId to set
	 */
	public void setLoginSessionId(String loginSessionId) {
		this.loginSessionId = loginSessionId;
	}

	/**
	 * Gets the value code.
	 *
	 * @return the valueCode
	 */
	public String getValueCode() {
		return valueCode;
	}

	/**
	 * Sets the value code.
	 *
	 * @param valueCode the valueCode to set
	 */
	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	/**
	 * Gets the status cd.
	 *
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}
