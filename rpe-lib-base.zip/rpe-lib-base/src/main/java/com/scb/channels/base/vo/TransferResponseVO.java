/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class TransferResponseVO.
 *
 * @author 1464143
 */
public class TransferResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6208992034436132675L;

	/** The transation info vo. */
	private TransactionInfoVO transactionInfoVO;
	
	/** The valueCode */
	private String valueCode;
	
	/** The statusCd */
	private String statusCd;

	/**
	 * Gets the transation info vo.
	 *
	 * @return the transationInfoVO
	 */
	public TransactionInfoVO getTransactionInfoVO() {
		return transactionInfoVO;
	}

	/**
	 * Sets the transation info vo.
	 *
	 * @param transationInfoVO the transationInfoVO to set
	 */
	public void setTransactionInfoVO(TransactionInfoVO transationInfoVO) {
		this.transactionInfoVO = transationInfoVO;
	}

	/**Gets the Value Code
	 * 
	 * @return
	 */
	public String getValueCode() {
		return valueCode;
	}

	/**Sets the Value Code
	 * 
	 * @param valueCode
	 */
	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	/**Gets the StatusCd
	 * 
	 * @return
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**Sets the StatusCd
	 * 
	 * @param statusCd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}
