package com.scb.channels.base.exception;

/**
 * The Class DAOException.
 */
public class DAOException extends BaseException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7417789630737976631L;

	/**
	 * Instantiates a new dAO exception.
	 */
	public DAOException() {}
	 
    /**
     * Instantiates a new dAO exception.
     *
     * @param errorCode the error code
     * @param message the message
     * @param parameters the parameters
     * @param cause the cause
     */
    public DAOException(String errorCode, String message, String[] parameters, Throwable cause){
    	super(errorCode, message, parameters, cause);
    }
	 
	/**
	 * Instantiates a new dAO exception.
	 *
	 * @param errorCode the error code
	 * @param message the message
	 * @param parameters the parameters
	 */
	public DAOException(String errorCode, String message, String[] parameters) {
	    super(errorCode, message, parameters);
	}
	 
	/**
	 * Instantiates a new dAO exception.
	 *
	 * @param errorCode the error code
	 * @param message the message
	 * @param cause the cause
	 */
	public DAOException(String errorCode, String message, Throwable cause) {
	    super(errorCode, message, cause);
	}
	 
	/**
	 * Instantiates a new dAO exception.
	 *
	 * @param errorCode the error code
	 * @param message the message
	 */
	public DAOException(String errorCode, String message) {
	    super(errorCode, message);
	}
	 
	/**
	 * Instantiates a new dAO exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 */
	public DAOException(String message, Throwable cause) {
	    super(message, cause);
	}
	 
	/**
	 * Instantiates a new dAO exception.
	 *
	 * @param errorCode the error code
	 */
	public DAOException(String errorCode) {
	    super(errorCode);
	}
	 
	/**
	 * Instantiates a new dAO exception.
	 *
	 * @param cause the cause
	 */
	public DAOException(Throwable cause) {
	    super(cause);
	}
}
