package com.scb.channels.base.interceptor;


import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PerformanceMonitoringInterceptor {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	  private Logger logger;

	  public PerformanceMonitoringInterceptor(String loggerName)
	  {
	    if (StringUtils.isBlank(loggerName))
	      this.logger = LoggerFactory.getLogger(PerformanceMonitoringInterceptor.class);
	    else
	      this.logger = LoggerFactory.getLogger(loggerName);
	  }

	  public Object logDuration(ProceedingJoinPoint call)
	    throws Throwable
	  {
	    long time = System.currentTimeMillis();
	    try {
	      return call.proceed();
	    }
	    finally {
	      if (this.logger.isInfoEnabled()) {
	        StringBuilder loggerBuffer = new StringBuilder(getDateFormatter().format(Calendar.getInstance().getTime()));
	        loggerBuffer.append(",");
	        loggerBuffer.append(ClassUtils.getShortClassName(call.getTarget().getClass()));
	        loggerBuffer.append(",");
	        loggerBuffer.append(getMethodName(call));
	        loggerBuffer.append(",");
	        loggerBuffer.append(System.currentTimeMillis() - time);
	        this.logger.info(loggerBuffer.toString());
	      }
	    }
	  }

	  protected String getMethodName(ProceedingJoinPoint call)
	  {
	    return ((call.getSignature() == null) ? call.toShortString() : call.getSignature().getName());
	  }

	  private static SimpleDateFormat getDateFormatter() {
	    return ((SimpleDateFormat)sdf.clone());
	  }
}
