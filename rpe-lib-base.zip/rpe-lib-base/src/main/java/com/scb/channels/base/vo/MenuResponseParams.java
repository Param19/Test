package com.scb.channels.base.vo;

import org.apache.commons.lang.ArrayUtils;

/**
 * The Class MenuResponseParams.
 */
public class MenuResponseParams {
	
	/** The country code. */
	private String countryCode;   
	//mobile Banking Customer name
	/** The customer name. */
	private String customerName;
    //Valuecode - wheter is it new customer  or existing pin chnaged customer
	/** The val code. */
    private String valCode;
	// session id - it is unique values which is used to track the user request
	/** The sessionid. */
	private String sessionid;  
    //cutomer Mobile Number
	/** The mobile number. */
    private String mobileNumber;
    //Bank Customer Number
	/** The Customer number. */
    private String CustomerNumber;
    // Credit Card Number
	/** The creditcard number. */
    private String creditcardNumber;
    //Credit Card Payment Status
	/** The card payment status. */
    private String cardPaymentStatus;
    // Cheque book Request Response
	/** The cheque book_ response. */
    private String chequeBook_Response;
    //Credit Card outStanding Balance 
	/** The out standing balance. */
    private String outStandingBalance;
    //Credit Card Credit Limit
	/** The credit limit. */
    private String creditLimit;
	// Credit Card LastStatement Balance
	/** The last statement balance. */
	private String lastStatementBalance;
	// Credit Card minimum Payment Due
	/** The minimum payment due. */
	private String minimumPaymentDue;
	//Credit Card dueDate
	/** The due date. */
	private String dueDate;
	//Credit Card Last Five Transactions Details
	/** The last five transactions. */
	private java.util.List<String> lastFiveTransactions;
	// Customer Credit Card Numbers List
	/** The card number list. */
	private java.util.List<String> cardNumberList;
	// Customer Credit Card Type list Example - VISA or MASTER CARD
	/** The card type list. */
	private java.util.List<String> cardTypeList;
	// Customer Bank Account Numbers
	/** The Account numbers. */
	private java.util.List<String> AccountNumbers;
	// Customer Account Balance - (ledger balance ,Book Balance) 
	/** The acct balance. */
	private String acctBalance;
	// Customer Account Numbers
	/** The str casa account deatils. */
	private String[] strCasaAccountDeatils;
	// Customer own Account numbers
	/** The str from account number. */
	private String[] strFromAccountNumber;
	//Customer Credit Card Outstanding Balance List
	/** The out standing balance list. */
	private java.util.List<String> outStandingBalanceList;
	// Customer Funds Transfer Transaction Status
	/** The funds transfer status. */
	private String fundsTransferStatus;
	//Customer Account Mini Statement ( last 5 transactions details)
	/** The accountm mini statement. */
	private String accountmMiniStatement;
	// Customer Pin Change Response 
	/** The pin change response. */
	private String pinChangeResponse;
    // mobile Banking login screen - authentication Response
	/** The cust authen response. */
    private String custAuthenResponse;
	// Customer Account Number
    /** The account number. */
	private String accountNumber;
    
    /** The apps account balance. */
    private String appsAccountBalance;
    
    /** The acct currency code. */
    private String acctCurrencyCode;
    
    /** The casa card flag. */
    private String casaCardFlag;
    
    /** The topup status. */
    private String topupStatus;
    
    /** The topup customer message. */
    private String topupCustomerMessage;
    
    /** The utl biller details. */
    private String[] utlBillerDetails;
    
    /** The pin change status. */
    private String pinChangeStatus;
    
    /** The bill payment status. */
    private String billPaymentStatus;
    
    /** The bill payment customermessage. */
    private String billPaymentCustomermessage;
    
    /** The cc mini statement response. */
    private String ccMiniStatementResponse;
    
    /** The inter bank nominee. */
    private String interBankNominee;
    
    /** The rev status. */
    private String revStatus;
    
    /** The biller category. */
    private String billerCategory;
    
    /** The Inter bank funds transfer status. */
    private String InterBankFundsTransferStatus;
    
    /** The Inter bank name. */
    private String InterBankName;
	
	/** The Inter bank custname. */
	private String InterBankCustname;
	
	/** The Inter bank branch name. */
	private String InterBankBranchName;
	
	/** The Inter bank account no. */
	private String InterBankAccountNo;
    
    /** The Inter bank trn amount. */
    private String InterBankTrnAmount;
    
    /** The Thirdparty cust name. */
    private String ThirdpartyCustName;
	
	/** The Thirdparty bank name. */
	private String ThirdpartyBankName;
	
	/** The Thirdparty acc no. */
	private String ThirdpartyAccNo;
    
    /** The str inter bank nomi details. */
    private String[] strInterBankNomiDetails;
    
    /** The Chqeue book status. */
    private String ChqeueBookStatus;
    
    /** The etran ack status. */
    private String etranAckStatus;
    
    /** The SCB sessionid. */
    private String SCBSessionid;
    
    /** The Biller name. */
    private String BillerName;
    
    /** The Billing amount. */
    private String BillingAmount;
    
    /** The Receipt no. */
    private String ReceiptNo;
    
    /** The SCBFT status. */
    private String SCBFTStatus;
    
    /** The airtime amount. */
    private String airtimeAmount;
    
    /** The mno. */
    private String MNO;
    
    /** The bnk code. */
    private String bnkCode; 
    
    /** The str to account number. */
    private String[] strToAccountNumber;
    
    /** The IBFT status. */
    private String IBFTStatus;
    
    /** The Biller cust number. */
    private String BillerCustNumber;
    
    /** The Statement status. */
    private String StatementStatus;
    
    /** The error msg. */
    private String errorMsg;
    
    private java.lang.String accChangeStatus;
	private java.lang.String accChangeResp;
	
	private String stopChequeStatus;
	private String stopChequeResponse;
	
	private String Last_Logintime;
	
	private String paymentDuedate;
	
	private String paymentDesc;
	
	private String statusCode;
	
	private String statusDesc;
	
    /**
     * Gets the bnk code.
     *
     * @return the bnk code
     */
    public String getBnkCode() {
    	
		return bnkCode;
	}
	
	/**
	 * Sets the bnk code.
	 *
	 * @param bnkCode the new bnk code
	 */
	public void setBnkCode(String bnkCode) {
		this.bnkCode = bnkCode;
	}
	
	/**
	 * Gets the mno.
	 *
	 * @return the mno
	 */
	public String getMNO() {
		return MNO;
	}
	
	/**
	 * Sets the mno.
	 *
	 * @param mNO the new mno
	 */
	public void setMNO(String mNO) {
		MNO = mNO;
	}
	
	/**
	 * Gets the airtime amount.
	 *
	 * @return the airtime amount
	 */
	public String getAirtimeAmount() {
		return airtimeAmount;
	}
	
	/**
	 * Sets the airtime amount.
	 *
	 * @param airtimeAmount the new airtime amount
	 */
	public void setAirtimeAmount(String airtimeAmount) {
		this.airtimeAmount = airtimeAmount;
	}
	
	/**
	 * Gets the sCBFT status.
	 *
	 * @return the sCBFT status
	 */
	public String getSCBFTStatus() {
		return SCBFTStatus;
	}
	
	/**
	 * Sets the sCBFT status.
	 *
	 * @param sCBFTStatus the new sCBFT status
	 */
	public void setSCBFTStatus(String sCBFTStatus) {
		SCBFTStatus = sCBFTStatus;
	}
	
    
    /**
     * Gets the iBFT status.
     *
     * @return the iBFT status
     */
    public String getIBFTStatus() {
		return IBFTStatus;
	}
	
	/**
	 * Sets the iBFT status.
	 *
	 * @param iBFTStatus the new iBFT status
	 */
	public void setIBFTStatus(String iBFTStatus) {
		IBFTStatus = iBFTStatus;
	}
	
	/**
	 * Gets the receipt no.
	 *
	 * @return the receipt no
	 */
	public String getReceiptNo() {
		return ReceiptNo;
	}
	
	/**
	 * Sets the receipt no.
	 *
	 * @param receiptNo the new receipt no
	 */
	public void setReceiptNo(String receiptNo) {
		ReceiptNo = receiptNo;
	}
	
	/**
	 * Gets the billing amount.
	 *
	 * @return the billing amount
	 */
	public String getBillingAmount() {
		return BillingAmount;
	}
	
	/**
	 * Sets the billing amount.
	 *
	 * @param billingAmount the new billing amount
	 */
	public void setBillingAmount(String billingAmount) {
		BillingAmount = billingAmount;
	}
	
	/**
	 * Gets the biller name.
	 *
	 * @return the biller name
	 */
	public String getBillerName() {
		return BillerName;
	}
	
	/**
	 * Sets the biller name.
	 *
	 * @param billerName the new biller name
	 */
	public void setBillerName(String billerName) {
		BillerName = billerName;
	}
	
    
    /**
     * Gets the biller cust number.
     *
     * @return the biller cust number
     */
    public String getBillerCustNumber() {
		return BillerCustNumber;
	}
	
	/**
	 * Sets the biller cust number.
	 *
	 * @param billerCustNumber the new biller cust number
	 */
	public void setBillerCustNumber(String billerCustNumber) {
		BillerCustNumber = billerCustNumber;
	}
	
	/**
	 * Gets the sCB sessionid.
	 *
	 * @return the sCB sessionid
	 */
	public String getSCBSessionid() {
		return SCBSessionid;
	}
	
	/**
	 * Sets the sCB sessionid.
	 *
	 * @param sCBSessionid the new sCB sessionid
	 */
	public void setSCBSessionid(String sCBSessionid) {
		SCBSessionid = sCBSessionid;
	}
	
	/**
	 * Gets the etran ack status.
	 *
	 * @return the etran ack status
	 */
	public String getEtranAckStatus() {
		return etranAckStatus;
	}
	
	/**
	 * Sets the etran ack status.
	 *
	 * @param etranAckStatus the new etran ack status
	 */
	public void setEtranAckStatus(String etranAckStatus) {
		this.etranAckStatus = etranAckStatus;
	}
	
	/**
	 * Gets the chqeue book status.
	 *
	 * @return the chqeue book status
	 */
	public String getChqeueBookStatus() {
		return ChqeueBookStatus;
	}
	
	/**
	 * Sets the chqeue book status.
	 *
	 * @param chqeueBookStatus the new chqeue book status
	 */
	public void setChqeueBookStatus(String chqeueBookStatus) {
		ChqeueBookStatus = chqeueBookStatus;
	}
	
	
	/**
	 * Gets the statement status.
	 *
	 * @return the statement status
	 */
	public String getStatementStatus() {
		return StatementStatus;
	}
	
	/**
	 * Sets the statement status.
	 *
	 * @param statementStatus the new statement status
	 */
	public void setStatementStatus(String statementStatus) {
		StatementStatus = statementStatus;
	}
	
	/**
	 * Gets the str inter bank nomi details.
	 *
	 * @return the str inter bank nomi details
	 */
	public String[] getStrInterBankNomiDetails() {
		return strInterBankNomiDetails;
	}
	
	/**
	 * Sets the str inter bank nomi details.
	 *
	 * @param strInterBankNomiDetails the new str inter bank nomi details
	 */
	public void setStrInterBankNomiDetails(
			String[] strInterBankNomiDetails) {
		 if (strInterBankNomiDetails != null && ArrayUtils.isNotEmpty(strInterBankNomiDetails)) {
			   this.strInterBankNomiDetails = new String[strInterBankNomiDetails.length];
			   ArrayUtils.addAll(this.strInterBankNomiDetails, strInterBankNomiDetails);
		 }
	}
	
	/**
	 * Gets the biller category.
	 *
	 * @return the biller category
	 */
	public String getBillerCategory() {
		return billerCategory;
	}
	
	/**
	 * Sets the biller category.
	 *
	 * @param billerCategory the new biller category
	 */
	public void setBillerCategory(String billerCategory) {
		this.billerCategory = billerCategory;
	}
    
    /**
     * Gets the rev status.
     *
     * @return the rev status
     */
    public String getRevStatus() {
		return revStatus;
	}
	
	/**
	 * Sets the rev status.
	 *
	 * @param revStatus the new rev status
	 */
	public void setRevStatus(String revStatus) {
		this.revStatus = revStatus;
	}
	
	/**
	 * Gets the cc mini statement response.
	 *
	 * @return the cc mini statement response
	 */
	public String getCcMiniStatementResponse() {
		return ccMiniStatementResponse;
	}
	
	/**
	 * Sets the cc mini statement response.
	 *
	 * @param ccMiniStatementResponse the new cc mini statement response
	 */
	public void setCcMiniStatementResponse(String ccMiniStatementResponse) {
		this.ccMiniStatementResponse = ccMiniStatementResponse;
	}
	
	/**
	 * Gets the bill payment customermessage.
	 *
	 * @return the bill payment customermessage
	 */
	public String getBillPaymentCustomermessage() {
		return billPaymentCustomermessage;
	}
	
	/**
	 * Sets the bill payment customermessage.
	 *
	 * @param billPaymentCustomermessage the new bill payment customermessage
	 */
	public void setBillPaymentCustomermessage(
			String billPaymentCustomermessage) {
		this.billPaymentCustomermessage = billPaymentCustomermessage;
	}
	
	/**
	 * Gets the bill payment status.
	 *
	 * @return the bill payment status
	 */
	public String getBillPaymentStatus() {
		return billPaymentStatus;
	}
	
	/**
	 * Sets the bill payment status.
	 *
	 * @param billPaymentStatus the new bill payment status
	 */
	public void setBillPaymentStatus(String billPaymentStatus) {
		this.billPaymentStatus = billPaymentStatus;
	}
	
	/**
	 * Gets the pin change status.
	 *
	 * @return the pin change status
	 */
	public String getPinChangeStatus() {
		return pinChangeStatus;
	}
	
	/**
	 * Sets the pin change status.
	 *
	 * @param pinChangeStatus the new pin change status
	 */
	public void setPinChangeStatus(String pinChangeStatus) {
		this.pinChangeStatus = pinChangeStatus;
	}
	
	/**
	 * Gets the utl biller details.
	 *
	 * @return the utl biller details
	 */
	public String[] getUtlBillerDetails() {
		return utlBillerDetails;
	}
	
	/**
	 * Sets the utl biller details.
	 *
	 * @param utlBillerDetails the new utl biller details
	 */
	public void setUtlBillerDetails(String[] utlBillerDetails) {
		 if (utlBillerDetails != null && ArrayUtils.isNotEmpty(utlBillerDetails)) {
			   this.utlBillerDetails = new String[utlBillerDetails.length];
			   ArrayUtils.addAll(this.utlBillerDetails, utlBillerDetails);
		 }
	}
	
	/**
	 * Gets the topup customer message.
	 *
	 * @return the topup customer message
	 */
	public String getTopupCustomerMessage() {
		return topupCustomerMessage;
	}
	
	/**
	 * Sets the topup customer message.
	 *
	 * @param topupCustomerMessage the new topup customer message
	 */
	public void setTopupCustomerMessage(String topupCustomerMessage) {
		this.topupCustomerMessage = topupCustomerMessage;
	}
	
	/**
	 * Gets the topup status.
	 *
	 * @return the topup status
	 */
	public String getTopupStatus() {
		return topupStatus;
	}
	
	/**
	 * Sets the topup status.
	 *
	 * @param topupStatus the new topup status
	 */
	public void setTopupStatus(String topupStatus) {
		this.topupStatus = topupStatus;
	}
	
	/**
	 * Gets the casa card flag.
	 *
	 * @return the casa card flag
	 */
	public String getCasaCardFlag() {
		return casaCardFlag;
	}
	
	/**
	 * Sets the casa card flag.
	 *
	 * @param casaCardFlag the new casa card flag
	 */
	public void setCasaCardFlag(String casaCardFlag) {
		this.casaCardFlag = casaCardFlag;
	}
	
    
    /**
     * Gets the error msg.
     *
     * @return the error msg
     */
    public String getErrorMsg() {
		return errorMsg;
	}
	
	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	/**
	 * Gets the acct currency code.
	 *
	 * @return the acct currency code
	 */
	public String getAcctCurrencyCode() {
		return acctCurrencyCode;
	}
	
	/**
	 * Sets the acct currency code.
	 *
	 * @param acctCurrencyCode the new acct currency code
	 */
	public void setAcctCurrencyCode(String acctCurrencyCode) {
		this.acctCurrencyCode = acctCurrencyCode;
	}
	
	/**
	 * Gets the apps account balance.
	 *
	 * @return the apps account balance
	 */
	public String getAppsAccountBalance() {
		return appsAccountBalance;
	}
	
	/**
	 * Sets the apps account balance.
	 *
	 * @param appsAccountBalance the new apps account balance
	 */
	public void setAppsAccountBalance(String appsAccountBalance) {
		this.appsAccountBalance = appsAccountBalance;
	}
	
	/**
	 * Gets the str from account number.
	 *
	 * @return the str from account number
	 */
	public String[] getStrFromAccountNumber() {
		return strFromAccountNumber;
	}
	
	/**
	 * Sets the str from account number.
	 *
	 * @param strFromAccountNumber the new str from account number
	 */
	public void setStrFromAccountNumber(String[] strFromAccountNumber) {
		if (strFromAccountNumber != null && ArrayUtils.isNotEmpty(strFromAccountNumber)) {
			   this.strFromAccountNumber = new String[strFromAccountNumber.length];
			   ArrayUtils.addAll(this.strFromAccountNumber, strFromAccountNumber);
		 }
	}
	

	/**
	 * Gets the str to account number.
	 *
	 * @return the str to account number
	 */
	public String[] getStrToAccountNumber() {
		return strToAccountNumber;
	}
	
	/**
	 * Sets the str to account number.
	 *
	 * @param strToAccountNumber the new str to account number
	 */
	public void setStrToAccountNumber(String[] strToAccountNumber) {
		 if (strToAccountNumber != null && ArrayUtils.isNotEmpty(strToAccountNumber)) {
			   this.strToAccountNumber = new String[strToAccountNumber.length];
			   ArrayUtils.addAll(this.strToAccountNumber, strToAccountNumber);
		 }
	}
	
	/**
	 * Gets the str casa account deatils.
	 *
	 * @return the str casa account deatils
	 */
	public String[] getStrCasaAccountDeatils() {
		return strCasaAccountDeatils;
	}
	
	/**
	 * Sets the str casa account deatils.
	 *
	 * @param strCasaAccountDeatils the new str casa account deatils
	 */
	public void setStrCasaAccountDeatils(String[] strCasaAccountDeatils) {
		 if (strCasaAccountDeatils != null && ArrayUtils.isNotEmpty(strCasaAccountDeatils)) {
			   this.strCasaAccountDeatils = new String[strCasaAccountDeatils.length];
			   ArrayUtils.addAll(this.strCasaAccountDeatils, strCasaAccountDeatils);
		 }
	}
	
	/**
	 * Gets the acct balance.
	 *
	 * @return the acct balance
	 */
	public String getAcctBalance() {
		return acctBalance;
	}
	
	/**
	 * Sets the acct balance.
	 *
	 * @param acctBalance the new acct balance
	 */
	public void setAcctBalance(String acctBalance) {
		this.acctBalance = acctBalance;
	}
	
	/**
	 * Gets the account numbers.
	 *
	 * @return the account numbers
	 */
	public java.util.List<String> getAccountNumbers() {
		return this.AccountNumbers;
	}
	
	/**
	 * Sets the account numbers.
	 *
	 * @param accountNumbers the new account numbers
	 */
	public void setAccountNumbers(java.util.List<String> accountNumbers) {
		this.AccountNumbers = accountNumbers;
	}

    /**
     * Gets the account number.
     *
     * @return the account number
     */
    public String getAccountNumber() {
		return accountNumber;
	}
	
	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	/**
	 * Gets the cust authen response.
	 *
	 * @return the cust authen response
	 */
	public String getCustAuthenResponse() {
		return custAuthenResponse;
	}
	
	/**
	 * Sets the cust authen response.
	 *
	 * @param custAuthenResponse the new cust authen response
	 */
	public void setCustAuthenResponse(String custAuthenResponse) {
		this.custAuthenResponse = custAuthenResponse;
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return countryCode;
	}
	
	/**
	 * Sets the country code.
	 *
	 * @param countryCode the new country code
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
	/**
	 * Gets the customer name.
	 *
	 * @return the customer name
	 */
	public String getCustomerName() {
		return customerName;
	}
	
	/**
	 * Sets the customer name.
	 *
	 * @param customerName the new customer name
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	/**
	 * Gets the val code.
	 *
	 * @return the val code
	 */
	public String getValCode() {
		return valCode;
	}
	
	/**
	 * Sets the val code.
	 *
	 * @param valCode the new val code
	 */
	public void setValCode(String valCode) {
		this.valCode = valCode;
	}
	
	/**
	 * Gets the sessionid.
	 *
	 * @return the sessionid
	 */
	public String getSessionid() {
		return sessionid;
	}
	
	/**
	 * Sets the sessionid.
	 *
	 * @param sessionid the new sessionid
	 */
	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}
	
	/**
	 * Gets the mobile number.
	 *
	 * @return the mobile number
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	/**
	 * Sets the mobile number.
	 *
	 * @param mobileNumber the new mobile number
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	/**
	 * Gets the customer number.
	 *
	 * @return the customer number
	 */
	public String getCustomerNumber() {
		return CustomerNumber;
	}
	
	/**
	 * Sets the customer number.
	 *
	 * @param customerNumber the new customer number
	 */
	public void setCustomerNumber(String customerNumber) {
		CustomerNumber = customerNumber;
	}
	
	/**
	 * Gets the creditcard number.
	 *
	 * @return the creditcard number
	 */
	public String getCreditcardNumber() {
		return creditcardNumber;
	}
	
	/**
	 * Sets the creditcard number.
	 *
	 * @param creditcardNumber the new creditcard number
	 */
	public void setCreditcardNumber(String creditcardNumber) {
		this.creditcardNumber = creditcardNumber;
	}
	
	/**
	 * Gets the card payment status.
	 *
	 * @return the card payment status
	 */
	public String getCardPaymentStatus() {
		return cardPaymentStatus;
	}
	
	/**
	 * Sets the card payment status.
	 *
	 * @param cardPaymentStatus the new card payment status
	 */
	public void setCardPaymentStatus(String cardPaymentStatus) {
		this.cardPaymentStatus = cardPaymentStatus;
	}
	
	/**
	 * Gets the cheque book_ response.
	 *
	 * @return the cheque book_ response
	 */
	public String getChequeBook_Response() {
		return chequeBook_Response;
	}
	
	/**
	 * Sets the cheque book_ response.
	 *
	 * @param chequeBook_Response the new cheque book_ response
	 */
	public void setChequeBook_Response(String chequeBook_Response) {
		this.chequeBook_Response = chequeBook_Response;
	}
	
	/**
	 * Gets the out standing balance.
	 *
	 * @return the out standing balance
	 */
	public String getOutStandingBalance() {
		return outStandingBalance;
	}
	
	/**
	 * Sets the out standing balance.
	 *
	 * @param outStandingBalance the new out standing balance
	 */
	public void setOutStandingBalance(String outStandingBalance) {
		this.outStandingBalance = outStandingBalance;
	}
	
	/**
	 * Gets the credit limit.
	 *
	 * @return the credit limit
	 */
	public String getCreditLimit() {
		return creditLimit;
	}
	
	/**
	 * Sets the credit limit.
	 *
	 * @param creditLimit the new credit limit
	 */
	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}
	
	/**
	 * Gets the last statement balance.
	 *
	 * @return the last statement balance
	 */
	public String getLastStatementBalance() {
		return lastStatementBalance;
	}
	
	/**
	 * Sets the last statement balance.
	 *
	 * @param lastStatementBalance the new last statement balance
	 */
	public void setLastStatementBalance(String lastStatementBalance) {
		this.lastStatementBalance = lastStatementBalance;
	}
	
	/**
	 * Gets the minimum payment due.
	 *
	 * @return the minimum payment due
	 */
	public String getMinimumPaymentDue() {
		return minimumPaymentDue;
	}
	
	/**
	 * Sets the minimum payment due.
	 *
	 * @param minimumPaymentDue the new minimum payment due
	 */
	public void setMinimumPaymentDue(String minimumPaymentDue) {
		this.minimumPaymentDue = minimumPaymentDue;
	}
	
	/**
	 * Gets the due date.
	 *
	 * @return the due date
	 */
	public String getDueDate() {
		return dueDate;
	}
	
	/**
	 * Sets the due date.
	 *
	 * @param dueDate the new due date
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	/**
	 * Gets the last five transactions.
	 *
	 * @return the last five transactions
	 */
	public java.util.List<String> getLastFiveTransactions() {
		return this.lastFiveTransactions;
	}
	
	/**
	 * Sets the last five transactions.
	 *
	 * @param lastFiveTransactions the new last five transactions
	 */
	public void setLastFiveTransactions(java.util.List<String> lastFiveTransactions) {
		this.lastFiveTransactions = lastFiveTransactions;
	}
	
	/**
	 * Gets the card number list.
	 *
	 * @return the card number list
	 */
	public java.util.List<String> getCardNumberList() {
		return this.cardNumberList;
	}
	
	/**
	 * Sets the card number list.
	 *
	 * @param cardNumberList the new card number list
	 */
	public void setCardNumberList(java.util.List<String> cardNumberList) {
		this.cardNumberList = cardNumberList;
	}
	
	/**
	 * Gets the card type list.
	 *
	 * @return the card type list
	 */
	public java.util.List<String> getCardTypeList() {
		return cardTypeList;
	}
	
	/**
	 * Sets the card type list.
	 *
	 * @param cardTypeList the new card type list
	 */
	public void setCardTypeList(java.util.List<String> cardTypeList) {
		this.cardTypeList = cardTypeList;
	}
	
	/**
	 * Gets the out standing balance list.
	 *
	 * @return the out standing balance list
	 */
	public java.util.List<String> getOutStandingBalanceList() {
		return outStandingBalanceList;
	}
	
	/**
	 * Sets the out standing balance list.
	 *
	 * @param outStandingBalanceList the new out standing balance list
	 */
	public void setOutStandingBalanceList(java.util.List<String> outStandingBalanceList) {
		this.outStandingBalanceList = outStandingBalanceList;
	}
	
	/**
	 * Gets the funds transfer status.
	 *
	 * @return the funds transfer status
	 */
	public String getFundsTransferStatus() {
		return fundsTransferStatus;
	}
	
	/**
	 * Sets the funds transfer status.
	 *
	 * @param fundsTransferStatus the new funds transfer status
	 */
	public void setFundsTransferStatus(String fundsTransferStatus) {
		this.fundsTransferStatus = fundsTransferStatus;
	}
	
	/**
	 * Gets the accountm mini statement.
	 *
	 * @return the accountm mini statement
	 */
	public String getAccountmMiniStatement() {
		return accountmMiniStatement;
	}
	
	/**
	 * Sets the accountm mini statement.
	 *
	 * @param accountmMiniStatement the new accountm mini statement
	 */
	public void setAccountmMiniStatement(String accountmMiniStatement) {
		this.accountmMiniStatement = accountmMiniStatement;
	}
	
	/**
	 * Gets the pin change response.
	 *
	 * @return the pin change response
	 */
	public String getPinChangeResponse() {
		return pinChangeResponse;
	}
	
	/**
	 * Sets the pin change response.
	 *
	 * @param pinChangeResponse the new pin change response
	 */
	public void setPinChangeResponse(String pinChangeResponse) {
		this.pinChangeResponse = pinChangeResponse;
	}
	
	/**
	 * Gets the inter bank nominee.
	 *
	 * @return the inter bank nominee
	 */
	public String getInterBankNominee() {
	return interBankNominee;
}

/**
 * Sets the inter bank nominee.
 *
 * @param interBankNominee the new inter bank nominee
 */
public void setInterBankNominee(String interBankNominee) {
	this.interBankNominee = interBankNominee;
}

/**
 * Gets the inter bank funds transfer status.
 *
 * @return the inter bank funds transfer status
 */
public String getInterBankFundsTransferStatus() {
	return InterBankFundsTransferStatus;
}

/**
 * Sets the inter bank funds transfer status.
 *
 * @param interBankFundsTransferStatus the new inter bank funds transfer status
 */
public void setInterBankFundsTransferStatus(
		String interBankFundsTransferStatus) {
	InterBankFundsTransferStatus = interBankFundsTransferStatus;
}

/**
 * Gets the inter bank name.
 *
 * @return the inter bank name
 */
public String getInterBankName() {
	return InterBankName;
}

/**
 * Sets the inter bank name.
 *
 * @param interBankName the new inter bank name
 */
public void setInterBankName(String interBankName) {
	InterBankName = interBankName;
}

/**
 * Gets the inter bank custname.
 *
 * @return the inter bank custname
 */
public String getInterBankCustname() {
		return InterBankCustname;
	}
	
	/**
	 * Sets the inter bank custname.
	 *
	 * @param interBankCustname the new inter bank custname
	 */
	public void setInterBankCustname(String interBankCustname) {
		InterBankCustname = interBankCustname;
}

/**
 * Gets the inter bank branch name.
 *
 * @return the inter bank branch name
 */
public String getInterBankBranchName() {
		return InterBankBranchName;
	}
	
	/**
	 * Sets the inter bank branch name.
	 *
	 * @param interBankBranchName the new inter bank branch name
	 */
	public void setInterBankBranchName(String interBankBranchName) {
		InterBankBranchName = interBankBranchName;
}
/**
 * Gets the inter bank account no.
 *
 * @return the inter bank account no
 */
public String getInterBankAccountNo() {
	return InterBankAccountNo;
}

/**
 * Sets the inter bank account no.
 *
 * @param interBankAccountNo the new inter bank account no
 */
public void setInterBankAccountNo(String interBankAccountNo) {
	InterBankAccountNo = interBankAccountNo;
}


	/**
	 * Gets the inter bank trn amount.
	 *
	 * @return the inter bank trn amount
	 */
	public String getInterBankTrnAmount() {
		return InterBankTrnAmount;
	}
	
	/**
	 * Sets the inter bank trn amount.
	 *
	 * @param interBankTrnAmount the new inter bank trn amount
	 */
	public void setInterBankTrnAmount(String interBankTrnAmount) {
		InterBankTrnAmount = interBankTrnAmount;
}
	
	/**
	 * Gets the thirdparty cust name.
	 *
	 * @return the thirdparty cust name
	 */
	public String getThirdpartyCustName() {
		return ThirdpartyCustName;
	}
	
	/**
	 * Sets the thirdparty cust name.
	 *
	 * @param thirdpartyCustName the new thirdparty cust name
	 */
	public void setThirdpartyCustName(String thirdpartyCustName) {
		ThirdpartyCustName = thirdpartyCustName;
	}
	
	/**
	 * Gets the thirdparty bank name.
	 *
	 * @return the thirdparty bank name
	 */
	public String getThirdpartyBankName() {
		return ThirdpartyBankName;
	}
	
	/**
	 * Sets the thirdparty bank name.
	 *
	 * @param thirdpartyBankName the new thirdparty bank name
	 */
	public void setThirdpartyBankName(String thirdpartyBankName) {
		ThirdpartyBankName = thirdpartyBankName;
	}
	
	/**
	 * Gets the thirdparty acc no.
	 *
	 * @return the thirdparty acc no
	 */
	public String getThirdpartyAccNo() {
		return ThirdpartyAccNo;
	}
	
	/**
	 * Sets the thirdparty acc no.
	 *
	 * @param thirdpartyAccNo the new thirdparty acc no
	 */
	public void setThirdpartyAccNo(String thirdpartyAccNo) {
		ThirdpartyAccNo = thirdpartyAccNo;
	}

	public java.lang.String getAccChangeStatus() {
		return accChangeStatus;
	}

	public void setAccChangeStatus(java.lang.String accChangeStatus) {
		this.accChangeStatus = accChangeStatus;
	}

	public java.lang.String getAccChangeResp() {
		return accChangeResp;
	}

	public void setAccChangeResp(java.lang.String accChangeResp) {
		this.accChangeResp = accChangeResp;
	}

	/**
	 * @return the last_Logintime
	 */
	public String getLast_Logintime() {
		return Last_Logintime;
	}

	/**
	 * @param last_Logintime the last_Logintime to set
	 */
	public void setLast_Logintime(String last_Logintime) {
		Last_Logintime = last_Logintime;
	}

	/**
	 * @return the stopChequeStatus
	 */
	public String getStopChequeStatus() {
		return stopChequeStatus;
	}

	/**
	 * @param stopChequeStatus the stopChequeStatus to set
	 */
	public void setStopChequeStatus(String stopChequeStatus) {
		this.stopChequeStatus = stopChequeStatus;
	}

	/**
	 * @return the stopChequeResponse
	 */
	public String getStopChequeResponse() {
		return stopChequeResponse;
	}

	/**
	 * @param stopChequeResponse the stopChequeResponse to set
	 */
	public void setStopChequeResponse(String stopChequeResponse) {
		this.stopChequeResponse = stopChequeResponse;
	}

	/**
	 * @return the paymentDuedate
	 */
	public String getPaymentDuedate() {
		return paymentDuedate;
	}

	/**
	 * @param paymentDuedate the paymentDuedate to set
	 */
	public void setPaymentDuedate(String paymentDuedate) {
		this.paymentDuedate = paymentDuedate;
	}

	/**
	 * @return the paymentDesc
	 */
	public String getPaymentDesc() {
		return paymentDesc;
	}

	/**
	 * @param paymentDesc the paymentDesc to set
	 */
	public void setPaymentDesc(String paymentDesc) {
		this.paymentDesc = paymentDesc;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	
	

}
