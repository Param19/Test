package com.scb.channels.base.vo;

import java.io.Serializable;

public class AccountToCustomerLinkVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 690804725946785401L;
	
	private String linkedRelationshipNumber;
	private String linkedRelationshipTypeCode;
	
	
	public String getLinkedRelationshipNumber() {
		return linkedRelationshipNumber;
	}
	public void setLinkedRelationshipNumber(String linkedRelationshipNumber) {
		this.linkedRelationshipNumber = linkedRelationshipNumber;
	}
	public String getLinkedRelationshipTypeCode() {
		return linkedRelationshipTypeCode;
	}
	public void setLinkedRelationshipTypeCode(String linkedRelationshipTypeCode) {
		this.linkedRelationshipTypeCode = linkedRelationshipTypeCode;
	}

}
