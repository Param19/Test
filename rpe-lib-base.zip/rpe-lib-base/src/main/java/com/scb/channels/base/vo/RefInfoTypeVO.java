package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class RefInfoTypeVO.
 */
public class RefInfoTypeVO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3395432186544577594L;

	/** The ref type. */
	

	private String refType;
	
	/** The ref id. */
	private String refId;

	/**
	 * Gets the ref type.
	 *
	 * @return the refType
	 */
	public String getRefType() {
		return refType;
	}

	/**
	 * Sets the ref type.
	 *
	 * @param refType the refType to set
	 */
	public void setRefType(String refType) {
		this.refType = refType;
	}

	/**
	 * Gets the ref id.
	 *
	 * @return the refId
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Sets the ref id.
	 *
	 * @param refId the refId to set
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}
	
	

	
	
}
