package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

public class FXRateVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5328399209295717271L;
	 private Integer id;
	 private Integer version;
	
	 private String ctryCd;
	 private String ccyCd;
	 private String ccyNm;
	 private String baseCcy;
	 private String createdBy;
	 private String updBy;
	 
	 private Double fxBuyRate;
	 private Double fxSellingRate;
	 private Double midrate;
	 private Double ctrBuyRate;
	 private Double ctrSellRate;
	
	 private Date dtCreated;
	 private Date dtUpd; 
	
	 private Character multiplydivdeflag;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getCtryCd() {
		return ctryCd;
	}

	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	public String getCcyCd() {
		return ccyCd;
	}

	public void setCcyCd(String ccyCd) {
		this.ccyCd = ccyCd;
	}

	public String getCcyNm() {
		return ccyNm;
	}

	public void setCcyNm(String ccyNm) {
		this.ccyNm = ccyNm;
	}

	public String getBaseCcy() {
		return baseCcy;
	}

	public void setBaseCcy(String baseCcy) {
		this.baseCcy = baseCcy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdBy() {
		return updBy;
	}

	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}

	public Double getFxBuyRate() {
		return fxBuyRate;
	}

	public void setFxBuyRate(Double fxBuyRate) {
		this.fxBuyRate = fxBuyRate;
	}

	public Double getFxSellingRate() {
		return fxSellingRate;
	}

	public void setFxSellingRate(Double fxSellingRate) {
		this.fxSellingRate = fxSellingRate;
	}

	public Double getMidrate() {
		return midrate;
	}

	public void setMidrate(Double midrate) {
		this.midrate = midrate;
	}

	public Double getCtrBuyRate() {
		return ctrBuyRate;
	}

	public void setCtrBuyRate(Double ctrBuyRate) {
		this.ctrBuyRate = ctrBuyRate;
	}

	public Double getCtrSellRate() {
		return ctrSellRate;
	}

	public void setCtrSellRate(Double ctrSellRate) {
		this.ctrSellRate = ctrSellRate;
	}
	

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public Date getDtUpd() {
		return dtUpd;
	}

	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}

	public Character getMultiplydivdeflag() {
		return multiplydivdeflag;
	}

	public void setMultiplydivdeflag(Character multiplydivdeflag) {
		this.multiplydivdeflag = multiplydivdeflag;
	}

	 
	 
}
