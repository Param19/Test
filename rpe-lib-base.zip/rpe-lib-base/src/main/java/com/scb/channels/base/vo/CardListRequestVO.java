/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class CardListRequestVO.
 *
 * @author 1411807
 */
public class CardListRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4722027799893304060L;

	

}
