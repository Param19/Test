package com.scb.channels.base.vo;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class MerchantPanTypeVO.
 */
public class QRMerchantPanTypeVO implements Serializable, Cloneable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3840523244251982933L;

	
	/** The ref id. */
	private String refId;
	
	/** The ref value. */
	private String refValue;

	/**
	 * Gets the ref id.
	 *
	 * @return the ref id
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Sets the ref id.
	 *
	 * @param refId the new ref id
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}

	/**
	 * Gets the ref value.
	 *
	 * @return the ref value
	 */
	public String getRefValue() {
		return refValue;
	}

	/**
	 * Sets the ref value.
	 *
	 * @param refValue the new ref value
	 */
	public void setRefValue(String refValue) {
		this.refValue = refValue;
	}

	@Override
	public String toString() {
		return "MerchantPanTypeVO [refId=" + refId + ", refValue=" + refValue
				+ "]";
	}

	
}
