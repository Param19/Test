package com.scb.channels.base.vo;

/**
 * The Class AxwayTokenValidationVO.
 *
 * @author 1493439
 */
public class AxwayTokenValidationVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1866138383093566477L;

	/** The client id. */
	private String clientID;
	
	/** The nonce. */
	private String nonce;
	
	/** The timestamp. */
	private String timestamp;
	
	/** The result. */
	private String result;
	
	/** The account number. */
	private String accountNumber;

	/**
	 * @return the clientID
	 */
	public String getClientID() {
		return clientID;
	}

	/**
	 * @param clientID the clientID to set
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	/**
	 * @return the nonce
	 */
	public String getNonce() {
		return nonce;
	}

	/**
	 * @param nonce the nonce to set
	 */
	public void setNonce(String nonce) {
		this.nonce = nonce;
	}

	/**
	 * @return the timestamp
	 */
	public String getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AxwayTokenValidationVO [clientID=" + clientID + ", nonce="
				+ nonce + ", timestamp=" + timestamp + ", result=" + result
				+ ", accountNumber=" + accountNumber + "]";
	}

}
