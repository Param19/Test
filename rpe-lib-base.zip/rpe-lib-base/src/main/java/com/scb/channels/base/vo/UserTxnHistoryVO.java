/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;


/**
 * @author 1411807
 *
 */
public class UserTxnHistoryVO implements Serializable {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = -3961815319539581543L;

	private Calendar txnTime;

	 private String txnType;

	 private double amount;

	 private String status;

	 private String description;

	/**
	 * @return the txnTime
	 */
	public Calendar getTxnTime() {
		return txnTime;
	}

	/**
	 * @param txnTime the txnTime to set
	 */
	public void setTxnTime(Calendar txnTime) {
		this.txnTime = txnTime;
	}

	/**
	 * @return the txnType
	 */
	public String getTxnType() {
		return txnType;
	}

	/**
	 * @param txnType the txnType to set
	 */
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}


}
