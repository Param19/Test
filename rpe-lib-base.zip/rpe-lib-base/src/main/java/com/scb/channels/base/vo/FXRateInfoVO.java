package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class FXRateInfoVO.
 */
public class FXRateInfoVO implements Serializable  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3422639446294091689L;

	/** The exchg rate. */
	private double exchgRate;
	
	/** The cust rate. */
	private double custRate;
	
	/** The deal no. */
	private String dealNo;
	
	/** The chnl margin. */
	private double chnlMargin;
	
	/** The deal fx rate. */
	private double dealFxRate;
	
	/** The cur rate. */
	private Double curRate;
	
	/** The cur convert rule. */
	private String curConvertRule;
	
	/** The cust deal no. */
	private Integer custDealNo;
	
	/** The cust deal rate. */
	private Double custDealRate;
	
	/** The cust pref rate. */
	private Double custPrefRate;
	
	/** The cost rate. */
	private double costRate;
	
	/** The counter rate. */
	private Double counterRate;
	
	
	/**
	 * Gets the exchg rate.
	 *
	 * @return the exchgRate
	 */
	public double getExchgRate() {
		return exchgRate;
	}
	
	/**
	 * Sets the exchg rate.
	 *
	 * @param exchgRate the exchgRate to set
	 */
	public void setExchgRate(double exchgRate) {
		this.exchgRate = exchgRate;
	}
	
	/**
	 * Gets the cost rate.
	 *
	 * @return the costRate
	 */
	public double getCostRate() {
		return costRate;
	}
	
	/**
	 * Sets the cost rate.
	 *
	 * @param costRate the costRate to set
	 */
	public void setCostRate(double costRate) {
		this.costRate = costRate;
	}
	
	/**
	 * Gets the cust rate.
	 *
	 * @return the custRate
	 */
	public double getCustRate() {
		return custRate;
	}
	
	/**
	 * Sets the cust rate.
	 *
	 * @param custRate the custRate to set
	 */
	public void setCustRate(double custRate) {
		this.custRate = custRate;
	}
	
	/**
	 * Gets the chnl margin.
	 *
	 * @return the chnlMargin
	 */
	public double getChnlMargin() {
		return chnlMargin;
	}
	
	/**
	 * Sets the chnl margin.
	 *
	 * @param chnlMargin the chnlMargin to set
	 */
	public void setChnlMargin(double chnlMargin) {
		this.chnlMargin = chnlMargin;
	}
	
	/**
	 * Gets the deal fx rate.
	 *
	 * @return the dealFxRate
	 */
	public double getDealFxRate() {
		return dealFxRate;
	}
	
	/**
	 * Sets the deal fx rate.
	 *
	 * @param dealFxRate the dealFxRate to set
	 */
	public void setDealFxRate(double dealFxRate) {
		this.dealFxRate = dealFxRate;
	}
	
	/**
	 * Gets the deal no.
	 *
	 * @return the dealNo
	 */
	public String getDealNo() {
		return dealNo;
	}
	
	/**
	 * Sets the deal no.
	 *
	 * @param dealNo the dealNo to set
	 */
	public void setDealNo(String dealNo) {
		this.dealNo = dealNo;
	}
	
	/**
	 * Gets the cur rate.
	 *
	 * @return the curRate
	 */
	public Double getCurRate() {
		return curRate;
	}
	
	/**
	 * Sets the cur rate.
	 *
	 * @param curRate the curRate to set
	 */
	public void setCurRate(Double curRate) {
		this.curRate = curRate;
	}
	
	/**
	 * Gets the cur convert rule.
	 *
	 * @return the curConvertRule
	 */
	public String getCurConvertRule() {
		return curConvertRule;
	}
	
	/**
	 * Sets the cur convert rule.
	 *
	 * @param curConvertRule the curConvertRule to set
	 */
	public void setCurConvertRule(String curConvertRule) {
		this.curConvertRule = curConvertRule;
	}
	
	/**
	 * Gets the cust deal no.
	 *
	 * @return the custDealNo
	 */
	public Integer getCustDealNo() {
		return custDealNo;
	}
	
	/**
	 * Sets the cust deal no.
	 *
	 * @param custDealNo the custDealNo to set
	 */
	public void setCustDealNo(Integer custDealNo) {
		this.custDealNo = custDealNo;
	}
	
	/**
	 * Gets the cust deal rate.
	 *
	 * @return the custDealRate
	 */
	public Double getCustDealRate() {
		return custDealRate;
	}
	
	/**
	 * Sets the cust deal rate.
	 *
	 * @param custDealRate the custDealRate to set
	 */
	public void setCustDealRate(Double custDealRate) {
		this.custDealRate = custDealRate;
	}
	
	/**
	 * Gets the cust pref rate.
	 *
	 * @return the custPrefRate
	 */
	public Double getCustPrefRate() {
		return custPrefRate;
	}
	
	/**
	 * Sets the cust pref rate.
	 *
	 * @param custPrefRate the custPrefRate to set
	 */
	public void setCustPrefRate(Double custPrefRate) {
		this.custPrefRate = custPrefRate;
	}
	
	/**
	 * Gets the counter rate.
	 *
	 * @return the counterRate
	 */
	public Double getCounterRate() {
		return counterRate;
	}
	
	/**
	 * Sets the counter rate.
	 *
	 * @param counterRate the counterRate to set
	 */
	public void setCounterRate(Double counterRate) {
		this.counterRate = counterRate;
	}

    
}
