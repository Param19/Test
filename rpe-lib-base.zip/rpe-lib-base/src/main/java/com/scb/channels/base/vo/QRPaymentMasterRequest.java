package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentMasterRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5558910125077194586L;
	
	private QRPaymentMasterRequestV3 PaymentRequestV3;

	public QRPaymentMasterRequestV3 getPaymentRequestV3() {
		return PaymentRequestV3;
	}
	@JsonSetter("PaymentRequestV3")
	public void setPaymentRequestV3(QRPaymentMasterRequestV3 paymentRequestV3) {
		PaymentRequestV3 = paymentRequestV3;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterRequest [PaymentRequestV3=" + PaymentRequestV3
				+ "]";
	}
	
	

}
