package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class TransactionsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2566860503839660648L;
	
	private String transactionIndicator;
    private String transactionCode;
    private Calendar transactionBatchEntryDate;
    private String transactionBatchNumber;
    private String transactionChannelID;
    private String chequeNumber;
    private String creditDebitTransactionIndicator;
    private String transactionAmount;
    private String transactionBranch;
    private Calendar transactionEffectiveDate;
    private String transactionApprovalSequenceNumber;
    private String transactionSequenceNumber;
    private String transactionAmountConversionRate;
    private String transactionReversalFlag;
    private String transactionCodeReferenceFlag;
    private String interestBearingTransactionIndicator;
    private String financialTransactionIndicator;
    private String chequeClearingHouseCode;
    private String transactionUnclearReleaseFlag;
    private String interestUnclearReleaseFlag;
    private Calendar interestEffectiveDate;
    private String chequeRejectedAmount;
    private String transactionEntryAndEffectiveVariance;
    private String runningBalance;
    private String clearedBalance;
    private String forwardCreditAmountOfParticularDate;
    private MakerVO transactionMaker;
    private CheckerVO transactionChecker;
    private CheckerVO transactionApprover;
    private List<NarrationVO> narration;
    private List<NarrationVO> extendedNarration;
    
	
    
    public String getTransactionIndicator() {
		return transactionIndicator;
	}
	public void setTransactionIndicator(String transactionIndicator) {
		this.transactionIndicator = transactionIndicator;
	}
	public String getTransactionCode() {
		return transactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	public Calendar getTransactionBatchEntryDate() {
		return transactionBatchEntryDate;
	}
	public void setTransactionBatchEntryDate(Calendar transactionBatchEntryDate) {
		this.transactionBatchEntryDate = transactionBatchEntryDate;
	}
	public String getTransactionBatchNumber() {
		return transactionBatchNumber;
	}
	public void setTransactionBatchNumber(String transactionBatchNumber) {
		this.transactionBatchNumber = transactionBatchNumber;
	}
	public String getTransactionChannelID() {
		return transactionChannelID;
	}
	public void setTransactionChannelID(String transactionChannelID) {
		this.transactionChannelID = transactionChannelID;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getCreditDebitTransactionIndicator() {
		return creditDebitTransactionIndicator;
	}
	public void setCreditDebitTransactionIndicator(
			String creditDebitTransactionIndicator) {
		this.creditDebitTransactionIndicator = creditDebitTransactionIndicator;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionBranch() {
		return transactionBranch;
	}
	public void setTransactionBranch(String transactionBranch) {
		this.transactionBranch = transactionBranch;
	}
	
	public Calendar getTransactionEffectiveDate() {
		return transactionEffectiveDate;
	}
	public void setTransactionEffectiveDate(Calendar transactionEffectiveDate) {
		this.transactionEffectiveDate = transactionEffectiveDate;
	}
	public String getTransactionApprovalSequenceNumber() {
		return transactionApprovalSequenceNumber;
	}
	public void setTransactionApprovalSequenceNumber(
			String transactionApprovalSequenceNumber) {
		this.transactionApprovalSequenceNumber = transactionApprovalSequenceNumber;
	}
	public String getTransactionSequenceNumber() {
		return transactionSequenceNumber;
	}
	public void setTransactionSequenceNumber(String transactionSequenceNumber) {
		this.transactionSequenceNumber = transactionSequenceNumber;
	}
	public String getTransactionAmountConversionRate() {
		return transactionAmountConversionRate;
	}
	public void setTransactionAmountConversionRate(
			String transactionAmountConversionRate) {
		this.transactionAmountConversionRate = transactionAmountConversionRate;
	}
	public String getTransactionReversalFlag() {
		return transactionReversalFlag;
	}
	public void setTransactionReversalFlag(String transactionReversalFlag) {
		this.transactionReversalFlag = transactionReversalFlag;
	}
	public String getTransactionCodeReferenceFlag() {
		return transactionCodeReferenceFlag;
	}
	public void setTransactionCodeReferenceFlag(String transactionCodeReferenceFlag) {
		this.transactionCodeReferenceFlag = transactionCodeReferenceFlag;
	}
	public String getInterestBearingTransactionIndicator() {
		return interestBearingTransactionIndicator;
	}
	public void setInterestBearingTransactionIndicator(
			String interestBearingTransactionIndicator) {
		this.interestBearingTransactionIndicator = interestBearingTransactionIndicator;
	}
	public String getFinancialTransactionIndicator() {
		return financialTransactionIndicator;
	}
	public void setFinancialTransactionIndicator(
			String financialTransactionIndicator) {
		this.financialTransactionIndicator = financialTransactionIndicator;
	}
	public String getChequeClearingHouseCode() {
		return chequeClearingHouseCode;
	}
	public void setChequeClearingHouseCode(String chequeClearingHouseCode) {
		this.chequeClearingHouseCode = chequeClearingHouseCode;
	}
	public String getTransactionUnclearReleaseFlag() {
		return transactionUnclearReleaseFlag;
	}
	public void setTransactionUnclearReleaseFlag(
			String transactionUnclearReleaseFlag) {
		this.transactionUnclearReleaseFlag = transactionUnclearReleaseFlag;
	}
	public String getInterestUnclearReleaseFlag() {
		return interestUnclearReleaseFlag;
	}
	public void setInterestUnclearReleaseFlag(String interestUnclearReleaseFlag) {
		this.interestUnclearReleaseFlag = interestUnclearReleaseFlag;
	}
	public Calendar getInterestEffectiveDate() {
		return interestEffectiveDate;
	}
	public void setInterestEffectiveDate(Calendar interestEffectiveDate) {
		this.interestEffectiveDate = interestEffectiveDate;
	}
	public String getChequeRejectedAmount() {
		return chequeRejectedAmount;
	}
	public void setChequeRejectedAmount(String chequeRejectedAmount) {
		this.chequeRejectedAmount = chequeRejectedAmount;
	}
	public String getTransactionEntryAndEffectiveVariance() {
		return transactionEntryAndEffectiveVariance;
	}
	public void setTransactionEntryAndEffectiveVariance(
			String transactionEntryAndEffectiveVariance) {
		this.transactionEntryAndEffectiveVariance = transactionEntryAndEffectiveVariance;
	}
	public String getRunningBalance() {
		return runningBalance;
	}
	public void setRunningBalance(String runningBalance) {
		this.runningBalance = runningBalance;
	}
	public String getClearedBalance() {
		return clearedBalance;
	}
	public void setClearedBalance(String clearedBalance) {
		this.clearedBalance = clearedBalance;
	}
	public String getForwardCreditAmountOfParticularDate() {
		return forwardCreditAmountOfParticularDate;
	}
	public void setForwardCreditAmountOfParticularDate(
			String forwardCreditAmountOfParticularDate) {
		this.forwardCreditAmountOfParticularDate = forwardCreditAmountOfParticularDate;
	}
	public MakerVO getTransactionMaker() {
		return transactionMaker;
	}
	public void setTransactionMaker(MakerVO transactionMaker) {
		this.transactionMaker = transactionMaker;
	}
	public CheckerVO getTransactionChecker() {
		return transactionChecker;
	}
	public void setTransactionChecker(CheckerVO transactionChecker) {
		this.transactionChecker = transactionChecker;
	}
	public CheckerVO getTransactionApprover() {
		return transactionApprover;
	}
	public void setTransactionApprover(CheckerVO transactionApprover) {
		this.transactionApprover = transactionApprover;
	}
	public List<NarrationVO> getNarration() {
		return narration;
	}
	public void setNarration(List<NarrationVO> narration) {
		this.narration = narration;
	}
	public List<NarrationVO> getExtendedNarration() {
		return extendedNarration;
	}
	public void setExtendedNarration(List<NarrationVO> extendedNarration) {
		this.extendedNarration = extendedNarration;
	}
	

}
