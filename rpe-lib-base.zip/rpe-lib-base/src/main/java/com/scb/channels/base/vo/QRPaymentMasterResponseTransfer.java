package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentMasterResponseTransfer {
	

	private String RequestId;
	
	private String TransactionReference;
	
	private QRPaymentMasterResponseTransactionHistory TransactionHistory;
	
	private String SanctionScore;

	public String getRequestId() {
		return RequestId;
	}

	public void setRequestId(String requestId) {
		RequestId = requestId;
	}

	public String getTransactionReference() {
		return TransactionReference;
	}

	public void setTransactionReference(String transactionReference) {
		TransactionReference = transactionReference;
	}

	public QRPaymentMasterResponseTransactionHistory getTransactionHistory() {
		return TransactionHistory;
	}

	public void setTransactionHistory(
			QRPaymentMasterResponseTransactionHistory transactionHistory) {
		TransactionHistory = transactionHistory;
	}

	public String getSanctionScore() {
		return SanctionScore;
	}

	public void setSanctionScore(String sanctionScore) {
		SanctionScore = sanctionScore;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterResponseTransfer [RequestId=" + RequestId
				+ ", TransactionReference=" + TransactionReference
				+ ", TransactionHistory=" + TransactionHistory
				+ ", SanctionScore=" + SanctionScore + "]";
	}
	
	

}
