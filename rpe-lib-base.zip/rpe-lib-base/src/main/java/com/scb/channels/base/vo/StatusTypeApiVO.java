package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusTypeApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	private String statusCode;
	private String statusDesc;
	private String referenceNumber;
	private List<HostResponseApiVO> hostResponse = new ArrayList<HostResponseApiVO>();
	
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public List<HostResponseApiVO> getHostResponse() {
		return hostResponse;
	}
	public void setHostResponse(List<HostResponseApiVO> hostResponse) {
		this.hostResponse = hostResponse;
	}
	
	@Override
	public String toString() {
		return "StatusTypeApiVO [statusCode=" + statusCode + ", statusDesc="
				+ statusDesc + ", referenceNumber=" + referenceNumber
				+ ", hostResponse=" + hostResponse + "]";
	}
	
}
