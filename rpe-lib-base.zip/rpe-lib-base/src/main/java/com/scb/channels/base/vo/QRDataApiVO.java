package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QRDataApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	/** The qr payload version. */
	private String qrPayloadVersion;
	
	/** The merchant category code. */
	private String merchantCategoryCode;
	
	/** The txn currency code. */
	private String txnCurrencyCode;
	
	/** The txn amount. */
	private String txnAmount;
	
	/** The country code. */
	private String countryCode;
	
	/** The merchant name. */
	private String merchantName;
	
	/** The merchant city. */
	private String merchantCity;
	
	/** The postal code. */
	private String postalCode;
	
	private String additionalField;
	
	private String acquirerCountry;
	
	/** The point of initiation. */
	private String pointOfInitiation;
	
	/** The crc Field. */
	private String crcField;	
	
	/** The tip or convenience fee. */
	private List<QRFeeTypeVO> tipOrConvenienceFee = new ArrayList<QRFeeTypeVO>();

	/** The merchant pan. */
	private List<QRMerchantPanTypeVO> merchantPan = new ArrayList<QRMerchantPanTypeVO>();
	
	/** The additional field. */
	private List<QRAdditionalTagTypeVO> additionalTag = new ArrayList<QRAdditionalTagTypeVO>();	


	public String getQrPayloadVersion() {
		return qrPayloadVersion;
	}

	public void setQrPayloadVersion(String qrPayloadVersion) {
		this.qrPayloadVersion = qrPayloadVersion;
	}

	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}

	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}

	public String getTxnCurrencyCode() {
		return txnCurrencyCode;
	}

	public void setTxnCurrencyCode(String txnCurrencyCode) {
		this.txnCurrencyCode = txnCurrencyCode;
	}

	public String getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantCity() {
		return merchantCity;
	}

	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPointOfInitiation() {
		return pointOfInitiation;
	}

	public void setPointOfInitiation(String pointOfInitiation) {
		this.pointOfInitiation = pointOfInitiation;
	}

	public List<QRFeeTypeVO> getTipOrConvenienceFee() {
		return tipOrConvenienceFee;
	}

	public void setTipOrConvenienceFee(List<QRFeeTypeVO> tipOrConvenienceFee) {
		this.tipOrConvenienceFee = tipOrConvenienceFee;
	}

	public List<QRMerchantPanTypeVO> getMerchantPan() {
		return merchantPan;
	}

	public void setMerchantPan(List<QRMerchantPanTypeVO> merchantPan) {
		this.merchantPan = merchantPan;
	}

	public List<QRAdditionalTagTypeVO> getAdditionalTag() {
		return additionalTag;
	}

	public void setAdditionalTag(List<QRAdditionalTagTypeVO> additionalTag) {
		this.additionalTag = additionalTag;
	}

	public String getAdditionalField() {
		return additionalField;
	}

	public void setAdditionalField(String additionalField) {
		this.additionalField = additionalField;
	}	

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getAcquirerCountry() {
		return acquirerCountry;
	}

	public void setAcquirerCountry(String acquirerCountry) {
		this.acquirerCountry = acquirerCountry;
	}

	public String getCrcField() {
		return crcField;
	}

	public void setCrcField(String crcField) {
		this.crcField = crcField;
	}

	@Override
	public String toString() {
		return "QRDataApiVO [qrPayloadVersion=" + qrPayloadVersion
				+ ", merchantCategoryCode=" + merchantCategoryCode
				+ ", txnCurrencyCode=" + txnCurrencyCode + ", txnAmount="
				+ txnAmount + ", countryCode=" + countryCode
				+ ", merchantName=" + merchantName + ", merchantCity="
				+ merchantCity + ", postalCode=" + postalCode
				+ ", additionalField=" + additionalField + ", acquirerCountry="
				+ acquirerCountry + ", pointOfInitiation=" + pointOfInitiation
				+ ", crcField=" + crcField + ", tipOrConvenienceFee="
				+ tipOrConvenienceFee + ", merchantPan=" + merchantPan
				+ ", additionalTag=" + additionalTag + "]";
	}
	
}
