/*
 * 
 */
package com.scb.channels.base.helper;

import org.dozer.DozerConverter;

/**
 * 
 * @author 1411807
 *
 */
public class BooleanToCharConvertor extends DozerConverter<Boolean, String> {

	/**
	 * Instantiates a new boolean to char convertor.
	 */
	public BooleanToCharConvertor() {
		super(Boolean.class,String.class);
	}

	/**
	 * Convert from.
	 * 
	 * @param source
	 *            the source
	 * @param destination
	 *            the destination
	 * @return the boolean
	 * @see org.dozer.DozerConverter#convertFrom(java.lang.Object,
	 *      java.lang.Object)
	 */
	@Override
	public Boolean convertFrom(String source, Boolean destination) {
		if (source == null) {
		  return Boolean.FALSE;
		} else if ("Y".equals(source)) {
	      return Boolean.TRUE;
	    } else if ("N".equals(source)) {
	      return Boolean.FALSE;
	    }
	    throw new IllegalStateException("Unknown value!");
	}
	
	/**
	 * Convert to.
	 * 
	 * @param source
	 *            the source
	 * @param destination
	 *            the destination
	 * @return the string
	 * @see org.dozer.DozerConverter#convertTo(java.lang.Object,
	 *      java.lang.Object)
	 */
	@Override
	public String convertTo(Boolean source, String destination) {
		 if (source == null) { 
			 return "N"; 
		 } else  if (Boolean.TRUE.equals(source)) {
		     return "Y";
	    } else if (Boolean.FALSE.equals(source)) {
	    	 return "N";
	    }
		throw new IllegalStateException("Unknown value!");
	}
}
