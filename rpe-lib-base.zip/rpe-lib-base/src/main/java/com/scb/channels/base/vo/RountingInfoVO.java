/*
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class RountingInfoVO.
 */
public class RountingInfoVO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6424428083589443646L;

	/** The bank code. */
	private String bankCode;
	
	/** The branch code. */
	private String branchCode;
	
	/** The routing code. */
	private String routingCode;
	
	/** The routing type. */
	private String routingType;

	/**
	 * Gets the bank code.
	 *
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * Sets the bank code.
	 *
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * Gets the branch code.
	 *
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * Sets the branch code.
	 *
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * Gets the routing code.
	 *
	 * @return the routingCode
	 */
	public String getRoutingCode() {
		return routingCode;
	}

	/**
	 * Sets the routing code.
	 *
	 * @param routingCode the routingCode to set
	 */
	public void setRoutingCode(String routingCode) {
		this.routingCode = routingCode;
	}

	/**
	 * Gets the routing type.
	 *
	 * @return the routingType
	 */
	public String getRoutingType() {
		return routingType;
	}

	/**
	 * Sets the routing type.
	 *
	 * @param routingType the routingType to set
	 */
	public void setRoutingType(String routingType) {
		this.routingType = routingType;
	}
	
}
