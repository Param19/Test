package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerPayRequestVO.
 */
public class ViewPayeeRequestVO extends BaseVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7683864660547612191L;
	
	
}
