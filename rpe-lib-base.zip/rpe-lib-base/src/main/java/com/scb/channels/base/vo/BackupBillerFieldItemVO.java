package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

import com.scb.channels.base.helper.CommonConstants;

public class BackupBillerFieldItemVO implements Serializable{

	/** The Constant serialVersionUID. * */
	private static final long serialVersionUID = -117108338235768117L;
	
	/** Id  *  */
	private Integer itemId;
	
	/** fieldId * */
	private Integer fieldId;
	
	/** productId * */
	private String id;
	
	/** description * */
	private String description;
	
	/**remarks  *  */
	private String remarks;
	
	/**status * */
	private String status;
	
	/** createdBy  * */
	private String createdBy=CommonConstants.SYSTEM;
	
	/** updBy  * */
 	private String updatedBy=CommonConstants.SYSTEM;
 	
 	/** dateCreated  * */
	private Date dateCreated=new Date();
	
	/** dateUpdated  * */
	private Date dateUpdated=new Date();	
	
	/** version  **/
	private int version;
	
	
	private BackupMasterBillerField billerField;


	/**
	 * @return the itemId
	 */
	public Integer getItemId() {
		return itemId;
	}


	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	/**
	 * @return the fieldId
	 */
	public Integer getFieldId() {
		return fieldId;
	}


	/**
	 * @param fieldId the fieldId to set
	 */
	public void setFieldId(Integer fieldId) {
		this.fieldId = fieldId;
	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}


	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}


	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}


	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}


	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}


	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}


	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	/**
	 * @return the dateCreated
	 */
	public Date getDateCreated() {
		return dateCreated;
	}


	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}


	/**
	 * @return the dateUpdated
	 */
	public Date getDateUpdated() {
		return dateUpdated;
	}


	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}


	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}


	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}


	/**
	 * @return the billerField
	 */
	public BackupMasterBillerField getBillerField() {
		return billerField;
	}


	/**
	 * @param billerField the billerField to set
	 */
	public void setBillerField(BackupMasterBillerField billerField) {
		this.billerField = billerField;
	}

	
}
