package com.scb.channels.base.vo;

import java.util.Date;


// TODO: Auto-generated Javadoc
/**
 * The Class InwardInquiryRequestVO.
 * 
 * @author 1493439
 *
 */
public class InwardInquiryRequestVO extends BaseVO{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3313091526045481286L;

	/** The client info. */
	private ClientInfoVO clientInfoVO;
	
	/** The reference number. */
	private String referenceNumber;
	
	/** The security info vo. */
	private SecurityInfoVO securityInfoVO;
	
	/** The host reference number. */
	private String hostReferenceNumber;

	/** The payment status. */
	private String paymentStatus;
	
	/** The payment description. */
	private String paymentDescription;
	
	/** The date from which the credit history is expected. */
	private Date fromDate;
	
	/** The date to which the credit history is expected. */
	private Date toDate;
	
	/** The service name. */
	private String serviceName;
	
	/** The retry count. */
	private Integer retryCount;
	//Added for OM
	/** The host status code. */
	private String hostStatusCode;

	/** The host status description. */
	private String hostStatusDescription;
	
	
	public String getHostStatusCode() {
		return hostStatusCode;
	}

	public void setHostStatusCode(String hostStatusCode) {
		this.hostStatusCode = hostStatusCode;
	}

	public String getHostStatusDescription() {
		return hostStatusDescription;
	}

	public void setHostStatusDescription(String hostStatusDescription) {
		this.hostStatusDescription = hostStatusDescription;
	}

	/**
	 * Gets the from date.
	 *
	 * @return the fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Gets the to date.
	 *
	 * @return the toDate
	 */
	public Date getToDate() {
		return toDate;
	}

	/**
	 * Sets the to date.
	 *
	 * @param toDate the toDate to set
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	/**
	 * Gets the client info vo.
	 *
	 * @return the clientInfoVO
	 */
	public ClientInfoVO getClientInfoVO() {
		return clientInfoVO;
	}

	/**
	 * Sets the client info vo.
	 *
	 * @param clientInfoVO the clientInfoVO to set
	 */
	public void setClientInfoVO(ClientInfoVO clientInfoVO) {
		this.clientInfoVO = clientInfoVO;
	}

	/**
	 * Gets the reference number.
	 *
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * Sets the reference number.
	 *
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * Gets the security info vo.
	 *
	 * @return the securityInfoVO
	 */
	public SecurityInfoVO getSecurityInfoVO() {
		return securityInfoVO;
	}

	/**
	 * Sets the security info vo.
	 *
	 * @param securityInfoVO the securityInfoVO to set
	 */
	public void setSecurityInfoVO(SecurityInfoVO securityInfoVO) {
		this.securityInfoVO = securityInfoVO;
	}

	/**
	 * Gets the host reference number.
	 *
	 * @return the hostReferenceNumber
	 */
	public String getHostReferenceNumber() {
		return hostReferenceNumber;
	}

	/**
	 * Sets the host reference number.
	 *
	 * @param hostReferenceNumber the hostReferenceNumber to set
	 */
	public void setHostReferenceNumber(String hostReferenceNumber) {
		this.hostReferenceNumber = hostReferenceNumber;
	}

	/**
	 * Gets the payment status.
	 *
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * Sets the payment status.
	 *
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * Gets the payment description.
	 *
	 * @return the paymentDescription
	 */
	public String getPaymentDescription() {
		return paymentDescription;
	}

	/**
	 * Sets the payment description.
	 *
	 * @param paymentDescription the paymentDescription to set
	 */
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	/**
	 * Gets the service name.
	 *
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * Sets the service name.
	 *
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InwardInquiryRequestVO [clientInfoVO=" + clientInfoVO
				+ ", referenceNumber=" + referenceNumber + ", securityInfoVO="
				+ securityInfoVO + ", hostReferenceNumber="
				+ hostReferenceNumber + ", paymentStatus=" + paymentStatus
				+ ", paymentDescription=" + paymentDescription + ", fromDate="
				+ fromDate + ", toDate=" + toDate + ", serviceName="
				+ serviceName + ", retryCount=" + retryCount + "]";
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}
}
