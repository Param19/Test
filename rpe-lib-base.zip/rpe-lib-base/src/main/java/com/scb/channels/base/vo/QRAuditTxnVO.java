package com.scb.channels.base.vo;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class QRAuditTxnVO {

	
	private int id;
	
	private String systemType;
	
	private String environment;
	
	private String channel;
	
	private String statusCd;
	
	private String errorCd;
	
	private String errorDesc;
	
	private String ctryCd;
	
	private String custId;
	
	private String paymentType;
	
	private String cardType;
	
	private String paymentOriginCountry;
	
	private String txnId;
	
	private String txnType;
	
	private Timestamp txnDate;
	
	private String txnCurr;
	
	private BigDecimal txnAmt;
	
	private String txtStatusCd;
	
	private String customerCardNo;
	
	private String merchantPanNo;
	
	private Timestamp dateCreated;

	private String createdBy;
	
	private String updatedBy;
	
	private Timestamp dateUpd;
	
	private String authCode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSystemType() {
		return systemType;
	}

	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getErrorCd() {
		return errorCd;
	}

	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		if(errorDesc != null && errorDesc.length()>245){
			errorDesc = errorDesc.substring(0, 245);
		}
		this.errorDesc = errorDesc;
	}

	public String getCtryCd() {
		return ctryCd;
	}

	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getPaymentOriginCountry() {
		return paymentOriginCountry;
	}

	public void setPaymentOriginCountry(String paymentOriginCountry) {
		this.paymentOriginCountry = paymentOriginCountry;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Timestamp getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(Timestamp txnDate) {
		this.txnDate = txnDate;
	}

	public String getTxnCurr() {
		return txnCurr;
	}

	public void setTxnCurr(String txnCurr) {
		this.txnCurr = txnCurr;
	}

	public BigDecimal getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(BigDecimal txnAmt) {
		this.txnAmt = txnAmt;
	}

	public String getTxtStatusCd() {
		return txtStatusCd;
	}

	public void setTxtStatusCd(String txtStatusCd) {
		this.txtStatusCd = txtStatusCd;
	}

	public String getCustomerCardNo() {
		return customerCardNo;
	}

	public void setCustomerCardNo(String customerCardNo) {
		this.customerCardNo = customerCardNo;
	}

	public String getMerchantPanNo() {
		return merchantPanNo;
	}

	public void setMerchantPanNo(String merchantPanNo) {
		this.merchantPanNo = merchantPanNo;
	}

	public Timestamp getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Timestamp dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getDateUpd() {
		return dateUpd;
	}

	public void setDateUpd(Timestamp dateUpd) {
		this.dateUpd = dateUpd;
	}


	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	
	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	
}
