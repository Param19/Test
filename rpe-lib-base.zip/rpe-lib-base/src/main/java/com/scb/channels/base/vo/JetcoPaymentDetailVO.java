package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
 
/**
 * The Class PaymentDetailVO.
 */
public class JetcoPaymentDetailVO implements Serializable,Cloneable{
	
	/**
	 *** The Constant serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String customerId;
	private String customerIdType;
	private String bankMessageId;
	private String bankMessageCreationDateTime;
	private String bankTransactionId;
	private String bankTransactionCreationDateTime;
	private String jetcoLookupMessageId;
	private String maskedReceiverAccountName;
	private String receiverMobileNumber;
	private String senderAccountNumber;
	private String senderAccountType;
	private String paymentDescription;
	private String senderAccountCurrency;
	private String senderCustomerReferenceId;
	private String senderP2PId;
	private String paymentType;
	private String paymentStatus;
	private String reasonCode;
	private String channel;
	private BigDecimal transactionAmount;
	private Timestamp reconDate;
	private Timestamp paymentDate;
	private Timestamp createdDate;
	private String createdBy;
	private Timestamp updatedDate;
	private String updatedBy;
	private String P2PTransactionId;
	private String referenceNumber;
	private String hostStatusCode;
	private String hostStatusDesc;
	private String jetcoMessageId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerIdType() {
		return customerIdType;
	}

	public void setCustomerIdType(String customerIdType) {
		this.customerIdType = customerIdType;
	}

	public String getBankMessageId() {
		return bankMessageId;
	}

	public void setBankMessageId(String bankMessageId) {
		this.bankMessageId = bankMessageId;
	}

	public String getBankTransactionId() {
		return bankTransactionId;
	}

	public void setBankTransactionId(String bankTransactionId) {
		this.bankTransactionId = bankTransactionId;
	}

	public String getJetcoLookupMessageId() {
		return jetcoLookupMessageId;
	}

	public void setJetcoLookupMessageId(String jetcoLookupMessageId) {
		this.jetcoLookupMessageId = jetcoLookupMessageId;
	}

	public String getMaskedReceiverAccountName() {
		return maskedReceiverAccountName;
	}

	public void setMaskedReceiverAccountName(String maskedReceiverAccountName) {
		this.maskedReceiverAccountName = maskedReceiverAccountName;
	}

	public String getReceiverMobileNumber() {
		return receiverMobileNumber;
	}

	public void setReceiverMobileNumber(String receiverMobileNumber) {
		this.receiverMobileNumber = receiverMobileNumber;
	}

	public String getSenderAccountNumber() {
		return senderAccountNumber;
	}

	public void setSenderAccountNumber(String senderAccountNumber) {
		this.senderAccountNumber = senderAccountNumber;
	}

	public String getSenderAccountType() {
		return senderAccountType;
	}

	public void setSenderAccountType(String senderAccountType) {
		this.senderAccountType = senderAccountType;
	}

	public String getPaymentDescription() {
		return paymentDescription;
	}

	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	public String getSenderAccountCurrency() {
		return senderAccountCurrency;
	}

	public void setSenderAccountCurrency(String senderAccountCurrency) {
		this.senderAccountCurrency = senderAccountCurrency;
	}

	public String getSenderCustomerReferenceId() {
		return senderCustomerReferenceId;
	}

	public void setSenderCustomerReferenceId(String senderCustomerReferenceId) {
		this.senderCustomerReferenceId = senderCustomerReferenceId;
	}

	public String getSenderP2PId() {
		return senderP2PId;
	}

	public void setSenderP2PId(String senderP2PId) {
		this.senderP2PId = senderP2PId;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public BigDecimal getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Timestamp getReconDate() {
		return reconDate;
	}

	public void setReconDate(Timestamp reconDate) {
		this.reconDate = reconDate;
	}

	public Timestamp getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getP2PTransactionId() {
		return P2PTransactionId;
	}

	public void setP2PTransactionId(String p2pTransactionId) {
		P2PTransactionId = p2pTransactionId;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getHostStatusCode() {
		return hostStatusCode;
	}

	public void setHostStatusCode(String hostStatusCode) {
		this.hostStatusCode = hostStatusCode;
	}

	public String getHostStatusDesc() {
		return hostStatusDesc;
	}

	public void setHostStatusDesc(String hostStatusDesc) {
		this.hostStatusDesc = hostStatusDesc;
	}

	public String getBankMessageCreationDateTime() {
		return bankMessageCreationDateTime;
	}

	public void setBankMessageCreationDateTime(String bankMessageCreationDateTime) {
		this.bankMessageCreationDateTime = bankMessageCreationDateTime;
	}

	public String getBankTransactionCreationDateTime() {
		return bankTransactionCreationDateTime;
	}

	public void setBankTransactionCreationDateTime(String bankTransactionCreationDateTime) {
		this.bankTransactionCreationDateTime = bankTransactionCreationDateTime;
	}

	public String getJetcoMessageId() {
		return jetcoMessageId;
	}

	public void setJetcoMessageId(String jetcoMessageId) {
		this.jetcoMessageId = jetcoMessageId;
	}

}
