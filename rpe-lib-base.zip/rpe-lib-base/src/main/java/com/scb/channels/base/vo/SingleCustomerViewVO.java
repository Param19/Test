package com.scb.channels.base.vo;

import java.io.Serializable;

public class SingleCustomerViewVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4941269584987331511L;
	
	private String accountNumber;
    private String accountCurrencyCode;
    private String accountProductCode;
    private String accountProductDescription;
    private String availableBalance;
    private String totalOutstanding;
    private String customerFirstName;
    private String customerLastName;
	
    
    public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountCurrencyCode() {
		return accountCurrencyCode;
	}
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}
	public String getAccountProductCode() {
		return accountProductCode;
	}
	public void setAccountProductCode(String accountProductCode) {
		this.accountProductCode = accountProductCode;
	}
	public String getAccountProductDescription() {
		return accountProductDescription;
	}
	public void setAccountProductDescription(String accountProductDescription) {
		this.accountProductDescription = accountProductDescription;
	}
	public String getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}
	public String getTotalOutstanding() {
		return totalOutstanding;
	}
	public void setTotalOutstanding(String totalOutstanding) {
		this.totalOutstanding = totalOutstanding;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

}
