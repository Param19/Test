package com.scb.channels.base.vo;

import java.io.Serializable;

public class MasterCardErrorDetailsVO implements Serializable{

	private static final long serialVersionUID = 6956895935823585312L;
	  private String name;
	  private String value;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
