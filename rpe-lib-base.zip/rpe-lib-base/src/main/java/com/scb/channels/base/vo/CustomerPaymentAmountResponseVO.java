package com.scb.channels.base.vo;


/**
 * The Class BillerPayRequestVO.
 */
public class CustomerPaymentAmountResponseVO extends BaseVO  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2386599332804954456L;

	private CustomerPaymentAmount paymentAmount;
	
	public CustomerPaymentAmount getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(CustomerPaymentAmount paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	@Override
	public String toString() {
		return "CustomerTotalPaymentAmountResponseVO [paymentAmount=" + paymentAmount + ", getPaymentAmount()=" + getPaymentAmount() + ", getUser()="
				+ getUser() + ", getStatus()=" + getStatus() + ", getDateCreated()=" + getDateCreated() + ", getDateUpdated()=" + getDateUpdated()
				+ ", getCreatedBy()=" + getCreatedBy() + ", getClientVO()=" + getClientVO() + ", getServiceVO()=" + getServiceVO() + ", getMessageVO()="
				+ getMessageVO() + ", getStatusDesc()=" + getStatusDesc() + ", getPaginationReqVO()=" + getPaginationReqVO() + ", getErrorCD()=" + getErrorCD()
				+ ", getErrorDesc()=" + getErrorDesc() + ", getPaginationRespVO()=" + getPaginationRespVO() + ", getProcessingMode()=" + getProcessingMode()
				+ ", getSeverity()=" + getSeverity() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	
}
