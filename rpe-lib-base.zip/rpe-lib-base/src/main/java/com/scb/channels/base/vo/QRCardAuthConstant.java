package com.scb.channels.base.vo;

import java.io.Serializable;

public class QRCardAuthConstant implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2561409179598320929L;

	public static final String MessageFunctionCode  =	"AUTQ";
	
	public static final String Default	=	"Default";
	
	public static final String Exchange_Id = "000";
	
	public static final String Accptr_Id =	"200008000009";
	
	public static final String Algorithm7Code = "ERSA";
	
	public static final String Algorithm13Code = "EA2C";
	
	public static final String ContentType2Code =	"AUTH";
	
	public static final String AuthenticationMethod5Code = "TOKP";
	
	public static final String PINFormat3Code = "ISO0";
	
	public static final String CardDataReading2Code =	"UNKW";
	
	public static final String CardPaymentServiceType7Code =	"CRDP";
	
	public static final String PayloadFormat = "XML";
	
	public static final String PayloadVersion = "1.0";
	
	public static final String Service_Req =	"IBK";
	
	public static final String Input_Id = "05";
	
	public static final String Reverse_FunctionCode = "REVQ";
	
	public static final String PanEntryMode ="01";
	
	public static final String PinEntryMode ="0";
	
	public static final String ConditionCode = "05";
	
	public static final String cardAcceptorTerminalIdentification = "scb12345";
	
	public static final String cardAcceptorIdentificationCode = "scb123456789023";
	
	public static final String cardAcceptorName= "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXIN";
	
	public static final String transaction_type = "QR";

	public static final String Service_Req_RPE ="RPE";
	
	public static final String SETTLEMENT_AMOUNT ="SettlementAmount";
	
	public static final String PayloadVersion_V2 = "2.0";
	
	public static final String CardTransactionType ="LOAD";
	
	public static final String TWO ="2";
	
	public static final byte[] ZERO_BYTE = {0};

	public static final String FIIdentificationCode ="00000000000";
	
	public static final String SPARROW = "Sparrow";
	
	public static final String ACQ_INST_ID = "ACQ_INST_ID";
	
	public static final String LOCAL_TRANS_FX_RATE = "61000000";
	
}
