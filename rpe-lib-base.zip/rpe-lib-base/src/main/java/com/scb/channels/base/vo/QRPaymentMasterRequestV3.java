package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentMasterRequestV3 implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2473349972005372077L;

	private String LocalTime;
	
	private String LocalDate;
	
	private String TransactionReference;
	
	private String FundingSource;
	
	private String AdditionalMessage;
	
	private String ParticipationID;
	
	private String LanguageIdentification;
	
	private String LanguageData;
	
	private String ReceiverPhone;
	
	private String ReceiverDateOfBirth;
	
	private String SenderPhone;
	
	private String SenderDateOfBirth;
	
	private String Channel;
	
	private String ICA;
	
	private String ProcessorId;
	
	private String RoutingAndTransitNumber;
	
	private String TransactionDesc;
	
	private String MerchantId;
	
	private QRPaymentMasterSenderName SenderName;
	
	private QRPaymentMasterSenderAddress SenderAddress;
	
	//private QRPaymentMasterFundingMapped FundingMapped;
	
	private QRPaymentMasterFundingCard FundingCard;
	
	private QRPaymentMasterReceiverName ReceiverName;
	
	private QRPaymentMasterReceiverAddress ReceiverAddress;
	
	//private QRPaymentMasterReceivingMapped ReceivingMapped;
	
	private QRPaymentMasterReceivingAmount ReceivingAmount;
	
	private QRPaymentMasterCardAcceptor CardAcceptor;
	
	private QRPaymentReceivingCard ReceivingCard;

	public String getLocalTime() {
		return LocalTime;
	}
	@JsonSetter("LocalTime")
	public void setLocalTime(String localTime) {
		LocalTime = localTime;
	}

	public String getTransactionReference() {
		return TransactionReference;
	}
	@JsonSetter("TransactionReference")
	public void setTransactionReference(String transactionReference) {
		TransactionReference = transactionReference;
	}

	public String getFundingSource() {
		return FundingSource;
	}
	@JsonSetter("FundingSource")
	public void setFundingSource(String fundingSource) {
		FundingSource = fundingSource;
	}

	public String getAdditionalMessage() {
		return AdditionalMessage;
	}
	@JsonSetter("AdditionalMessage")
	public void setAdditionalMessage(String additionalMessage) {
		AdditionalMessage = additionalMessage;
	}

	public String getParticipationID() {
		return ParticipationID;
	}
	@JsonSetter("ParticipationID")
	public void setParticipationID(String participationID) {
		ParticipationID = participationID;
	}

	public String getLanguageIdentification() {
		return LanguageIdentification;
	}
	@JsonSetter("LanguageIdentification")
	public void setLanguageIdentification(String languageIdentification) {
		LanguageIdentification = languageIdentification;
	}

	public String getLanguageData() {
		return LanguageData;
	}
	@JsonSetter("LanguageData")
	public void setLanguageData(String languageData) {
		LanguageData = languageData;
	}

	public String getReceiverPhone() {
		return ReceiverPhone;
	}
	@JsonSetter("ReceiverPhone")
	public void setReceiverPhone(String receiverPhone) {
		ReceiverPhone = receiverPhone;
	}

	public String getReceiverDateOfBirth() {
		return ReceiverDateOfBirth;
	}
	@JsonSetter("ReceiverDateOfBirth")
	public void setReceiverDateOfBirth(String receiverDateOfBirth) {
		ReceiverDateOfBirth = receiverDateOfBirth;
	}

	public String getSenderPhone() {
		return SenderPhone;
	}
	@JsonSetter("SenderPhone")
	public void setSenderPhone(String senderPhone) {
		SenderPhone = senderPhone;
	}

	public String getSenderDateOfBirth() {
		return SenderDateOfBirth;
	}
	@JsonSetter("SenderDateOfBirth")
	public void setSenderDateOfBirth(String senderDateOfBirth) {
		SenderDateOfBirth = senderDateOfBirth;
	}

	public String getChannel() {
		return Channel;
	}
	@JsonSetter("Channel")
	public void setChannel(String channel) {
		Channel = channel;
	}

	public String getICA() {
		return ICA;
	}
	@JsonSetter("ICA")
	public void setICA(String iCA) {
		ICA = iCA;
	}

	public String getProcessorId() {
		return ProcessorId;
	}
	@JsonSetter("ProcessorId")
	public void setProcessorId(String processorId) {
		ProcessorId = processorId;
	}

	public String getRoutingAndTransitNumber() {
		return RoutingAndTransitNumber;
	}
	@JsonSetter("RoutingAndTransitNumber")
	public void setRoutingAndTransitNumber(String routingAndTransitNumber) {
		RoutingAndTransitNumber = routingAndTransitNumber;
	}

	public String getTransactionDesc() {
		return TransactionDesc;
	}
	@JsonSetter("TransactionDesc")
	public void setTransactionDesc(String transactionDesc) {
		TransactionDesc = transactionDesc;
	}

	public String getMerchantId() {
		return MerchantId;
	}
	@JsonSetter("MerchantId")
	public void setMerchantId(String merchantId) {
		MerchantId = merchantId;
	}

	public QRPaymentMasterSenderName getSenderName() {
		return SenderName;
	}
	@JsonSetter("SenderName")
	public void setSenderName(QRPaymentMasterSenderName senderName) {
		SenderName = senderName;
	}

	public QRPaymentMasterSenderAddress getSenderAddress() {
		return SenderAddress;
	}
	@JsonSetter("SenderAddress")
	public void setSenderAddress(QRPaymentMasterSenderAddress senderAddress) {
		SenderAddress = senderAddress;
	}

	public QRPaymentMasterFundingCard getFundingCard() {
		return FundingCard;
	}
	@JsonSetter("FundingCard")
	public void setFundingCard(QRPaymentMasterFundingCard fundingCard) {
		FundingCard = fundingCard;
	}

	public QRPaymentMasterReceiverName getReceiverName() {
		return ReceiverName;
	}
	@JsonSetter("ReceiverName")
	public void setReceiverName(QRPaymentMasterReceiverName receiverName) {
		ReceiverName = receiverName;
	}

	public QRPaymentMasterReceiverAddress getReceiverAddress() {
		return ReceiverAddress;
	}
	@JsonSetter("ReceiverAddress")
	public void setReceiverAddress(QRPaymentMasterReceiverAddress receiverAddress) {
		ReceiverAddress = receiverAddress;
	}

	public QRPaymentMasterReceivingAmount getReceivingAmount() {
		return ReceivingAmount;
	}
	@JsonSetter("ReceivingAmount")
	public void setReceivingAmount(QRPaymentMasterReceivingAmount receivingAmount) {
		ReceivingAmount = receivingAmount;
	}

	public QRPaymentMasterCardAcceptor getCardAcceptor() {
		return CardAcceptor;
	}
	@JsonSetter("CardAcceptor")
	public void setCardAcceptor(QRPaymentMasterCardAcceptor cardAcceptor) {
		CardAcceptor = cardAcceptor;
	}

	public QRPaymentReceivingCard getReceivingCard() {
		return ReceivingCard;
	}
	@JsonSetter("ReceivingCard")
	public void setReceivingCard(QRPaymentReceivingCard receivingCard) {
		ReceivingCard = receivingCard;
	}
	
	public String getLocalDate() {
		return LocalDate;
	}
	@JsonSetter("LocalDate")
	public void setLocalDate(String localDate) {
		LocalDate = localDate;
	}
	@Override
	public String toString() {
		return "QRPaymentMasterRequestV3 [LocalTime=" + LocalTime
				+ ", LocalDate=" + LocalDate + ", TransactionReference="
				+ TransactionReference + ", FundingSource=" + FundingSource
				+ ", AdditionalMessage=" + AdditionalMessage
				+ ", ParticipationID=" + ParticipationID
				+ ", LanguageIdentification=" + LanguageIdentification
				+ ", LanguageData=" + LanguageData + ", ReceiverPhone="
				+ ReceiverPhone + ", ReceiverDateOfBirth="
				+ ReceiverDateOfBirth + ", SenderPhone=" + SenderPhone
				+ ", SenderDateOfBirth=" + SenderDateOfBirth + ", Channel="
				+ Channel + ", ICA=" + ICA + ", ProcessorId=" + ProcessorId
				+ ", RoutingAndTransitNumber=" + RoutingAndTransitNumber
				+ ", TransactionDesc=" + TransactionDesc + ", MerchantId="
				+ MerchantId + ", SenderName=" + SenderName
				+ ", SenderAddress=" + SenderAddress + ", FundingCard="
				+ FundingCard + ", ReceiverName=" + ReceiverName
				+ ", ReceiverAddress=" + ReceiverAddress + ", ReceivingAmount="
				+ ReceivingAmount + ", CardAcceptor=" + CardAcceptor
				+ ", ReceivingCard=" + ReceivingCard + "]";
	}
	

	
}
