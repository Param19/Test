/**
 * 
 */
package com.scb.channels.base.vo;


/**
 * @author 1411807
 *
 */
public class GetRegistrationDetailsResponseVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1054048227139719592L;
	
	private String emailAlertType;
	
	private String mobileOperator;

	/**
	 * @return the emailAlertType
	 */
	public String getEmailAlertType() {
		return emailAlertType;
	}

	/**
	 * @param emailAlertType the emailAlertType to set
	 */
	public void setEmailAlertType(String emailAlertType) {
		this.emailAlertType = emailAlertType;
	}

	/**
	 * @return the mobileOperator
	 */
	public String getMobileOperator() {
		return mobileOperator;
	}

	/**
	 * @param mobileOperator the mobileOperator to set
	 */
	public void setMobileOperator(String mobileOperator) {
		this.mobileOperator = mobileOperator;
	}

}
