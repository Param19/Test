package com.scb.channels.base.vo;

import java.io.Serializable;


public class PaymentResponseVO extends BaseVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3054532474676266411L;
	
	private PaymentDetailVO paymentVO;

	public PaymentDetailVO getPaymentVO() {
		return paymentVO;
	}

	public void setPaymentVO(PaymentDetailVO paymentVO) {
		this.paymentVO = paymentVO;
	}
	
	
}
