package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;

public class OverdraftVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6158664571082401832L;

	private String accountCACSDownReason;
    private String accountCACSIndicator;
    private String accountChargeOffFlag;
    private Calendar accountImpairmentFlag;
    private String accountInterestCode;
    private String accountProductCode;
    private String provisionAdjustmentAmount;
    private String accountProvisionStatus;
    private String suspendChargeOffFlag;
    private String suspendImpairmentFlag;
    private String suspendProvisionForAmount;
    private String limitOrLienIndicator;
    private String accountLienOrLimitAmount;
    private Calendar accountLimitExpiryDate;
    private String accountInterestLimit;
    private Calendar accountActualPaymentDate;
    private Calendar accountChargeOffDate;
    private String accountCurrentCyclePayment;
    private String accountCurrentDaysPastDue;
    private String accountCurrentMonthPayment;
    private String accountCurrentOutstandingAmount;
    private String accountCurrentRepaymentCycle;
    private String accountCurrentRepaymentStatus;
    private String accountExcessAmount;
    private Calendar accountExcessDaysPastDueDate;
    private String accountLastStatementAmount;
    private String accountMinimumAmountDue;
    private Calendar accountAmountDuePaidDate;
    private Calendar accountAmountPaymentDueDate;
    private String accountPreviousOutstandingAmount;
    private String accountProvisionProductCode;
    private Calendar accountReageingDate;
    private String accountTotalInterestAmount;
    private String accountTotalMinimumAmountDue;
    private Calendar accountLastStatementDate;
    private String minimumRepaymentAmountDue;
    private String accountCreditAmount;
    private String accountDebitAmount;
    private Calendar accountExcessShortStartDate;
    private String accountOverallExcessAmount;
    private Calendar accountLastCycleDate;
    private Calendar accountNextCycleDate;
    private String accountFullOutstandingInstallmentFlag;
    private String provisionStatus;
	
    
    public String getAccountCACSDownReason() {
		return accountCACSDownReason;
	}
	public void setAccountCACSDownReason(String accountCACSDownReason) {
		this.accountCACSDownReason = accountCACSDownReason;
	}
	public String getAccountCACSIndicator() {
		return accountCACSIndicator;
	}
	public void setAccountCACSIndicator(String accountCACSIndicator) {
		this.accountCACSIndicator = accountCACSIndicator;
	}
	public String getAccountChargeOffFlag() {
		return accountChargeOffFlag;
	}
	public void setAccountChargeOffFlag(String accountChargeOffFlag) {
		this.accountChargeOffFlag = accountChargeOffFlag;
	}
	public Calendar getAccountImpairmentFlag() {
		return accountImpairmentFlag;
	}
	public void setAccountImpairmentFlag(Calendar accountImpairmentFlag) {
		this.accountImpairmentFlag = accountImpairmentFlag;
	}
	public String getAccountInterestCode() {
		return accountInterestCode;
	}
	public void setAccountInterestCode(String accountInterestCode) {
		this.accountInterestCode = accountInterestCode;
	}
	public String getAccountProductCode() {
		return accountProductCode;
	}
	public void setAccountProductCode(String accountProductCode) {
		this.accountProductCode = accountProductCode;
	}
	public String getProvisionAdjustmentAmount() {
		return provisionAdjustmentAmount;
	}
	public void setProvisionAdjustmentAmount(String provisionAdjustmentAmount) {
		this.provisionAdjustmentAmount = provisionAdjustmentAmount;
	}
	public String getAccountProvisionStatus() {
		return accountProvisionStatus;
	}
	public void setAccountProvisionStatus(String accountProvisionStatus) {
		this.accountProvisionStatus = accountProvisionStatus;
	}
	public String getSuspendChargeOffFlag() {
		return suspendChargeOffFlag;
	}
	public void setSuspendChargeOffFlag(String suspendChargeOffFlag) {
		this.suspendChargeOffFlag = suspendChargeOffFlag;
	}
	public String getSuspendImpairmentFlag() {
		return suspendImpairmentFlag;
	}
	public void setSuspendImpairmentFlag(String suspendImpairmentFlag) {
		this.suspendImpairmentFlag = suspendImpairmentFlag;
	}
	public String getSuspendProvisionForAmount() {
		return suspendProvisionForAmount;
	}
	public void setSuspendProvisionForAmount(String suspendProvisionForAmount) {
		this.suspendProvisionForAmount = suspendProvisionForAmount;
	}
	public String getLimitOrLienIndicator() {
		return limitOrLienIndicator;
	}
	public void setLimitOrLienIndicator(String limitOrLienIndicator) {
		this.limitOrLienIndicator = limitOrLienIndicator;
	}
	public String getAccountLienOrLimitAmount() {
		return accountLienOrLimitAmount;
	}
	public void setAccountLienOrLimitAmount(String accountLienOrLimitAmount) {
		this.accountLienOrLimitAmount = accountLienOrLimitAmount;
	}
	public Calendar getAccountLimitExpiryDate() {
		return accountLimitExpiryDate;
	}
	public void setAccountLimitExpiryDate(Calendar accountLimitExpiryDate) {
		this.accountLimitExpiryDate = accountLimitExpiryDate;
	}
	public String getAccountInterestLimit() {
		return accountInterestLimit;
	}
	public void setAccountInterestLimit(String accountInterestLimit) {
		this.accountInterestLimit = accountInterestLimit;
	}
	public Calendar getAccountActualPaymentDate() {
		return accountActualPaymentDate;
	}
	public void setAccountActualPaymentDate(Calendar accountActualPaymentDate) {
		this.accountActualPaymentDate = accountActualPaymentDate;
	}
	public Calendar getAccountChargeOffDate() {
		return accountChargeOffDate;
	}
	public void setAccountChargeOffDate(Calendar accountChargeOffDate) {
		this.accountChargeOffDate = accountChargeOffDate;
	}
	public String getAccountCurrentCyclePayment() {
		return accountCurrentCyclePayment;
	}
	public void setAccountCurrentCyclePayment(String accountCurrentCyclePayment) {
		this.accountCurrentCyclePayment = accountCurrentCyclePayment;
	}
	public String getAccountCurrentDaysPastDue() {
		return accountCurrentDaysPastDue;
	}
	public void setAccountCurrentDaysPastDue(String accountCurrentDaysPastDue) {
		this.accountCurrentDaysPastDue = accountCurrentDaysPastDue;
	}
	public String getAccountCurrentMonthPayment() {
		return accountCurrentMonthPayment;
	}
	public void setAccountCurrentMonthPayment(String accountCurrentMonthPayment) {
		this.accountCurrentMonthPayment = accountCurrentMonthPayment;
	}
	public String getAccountCurrentOutstandingAmount() {
		return accountCurrentOutstandingAmount;
	}
	public void setAccountCurrentOutstandingAmount(
			String accountCurrentOutstandingAmount) {
		this.accountCurrentOutstandingAmount = accountCurrentOutstandingAmount;
	}
	public String getAccountCurrentRepaymentCycle() {
		return accountCurrentRepaymentCycle;
	}
	public void setAccountCurrentRepaymentCycle(String accountCurrentRepaymentCycle) {
		this.accountCurrentRepaymentCycle = accountCurrentRepaymentCycle;
	}
	public String getAccountCurrentRepaymentStatus() {
		return accountCurrentRepaymentStatus;
	}
	public void setAccountCurrentRepaymentStatus(
			String accountCurrentRepaymentStatus) {
		this.accountCurrentRepaymentStatus = accountCurrentRepaymentStatus;
	}
	public String getAccountExcessAmount() {
		return accountExcessAmount;
	}
	public void setAccountExcessAmount(String accountExcessAmount) {
		this.accountExcessAmount = accountExcessAmount;
	}
	public Calendar getAccountExcessDaysPastDueDate() {
		return accountExcessDaysPastDueDate;
	}
	public void setAccountExcessDaysPastDueDate(
			Calendar accountExcessDaysPastDueDate) {
		this.accountExcessDaysPastDueDate = accountExcessDaysPastDueDate;
	}
	public String getAccountLastStatementAmount() {
		return accountLastStatementAmount;
	}
	public void setAccountLastStatementAmount(String accountLastStatementAmount) {
		this.accountLastStatementAmount = accountLastStatementAmount;
	}
	public String getAccountMinimumAmountDue() {
		return accountMinimumAmountDue;
	}
	public void setAccountMinimumAmountDue(String accountMinimumAmountDue) {
		this.accountMinimumAmountDue = accountMinimumAmountDue;
	}
	public Calendar getAccountAmountDuePaidDate() {
		return accountAmountDuePaidDate;
	}
	public void setAccountAmountDuePaidDate(Calendar accountAmountDuePaidDate) {
		this.accountAmountDuePaidDate = accountAmountDuePaidDate;
	}
	public Calendar getAccountAmountPaymentDueDate() {
		return accountAmountPaymentDueDate;
	}
	public void setAccountAmountPaymentDueDate(Calendar accountAmountPaymentDueDate) {
		this.accountAmountPaymentDueDate = accountAmountPaymentDueDate;
	}
	public String getAccountPreviousOutstandingAmount() {
		return accountPreviousOutstandingAmount;
	}
	public void setAccountPreviousOutstandingAmount(
			String accountPreviousOutstandingAmount) {
		this.accountPreviousOutstandingAmount = accountPreviousOutstandingAmount;
	}
	public String getAccountProvisionProductCode() {
		return accountProvisionProductCode;
	}
	public void setAccountProvisionProductCode(String accountProvisionProductCode) {
		this.accountProvisionProductCode = accountProvisionProductCode;
	}
	public Calendar getAccountReageingDate() {
		return accountReageingDate;
	}
	public void setAccountReageingDate(Calendar accountReageingDate) {
		this.accountReageingDate = accountReageingDate;
	}
	public String getAccountTotalInterestAmount() {
		return accountTotalInterestAmount;
	}
	public void setAccountTotalInterestAmount(String accountTotalInterestAmount) {
		this.accountTotalInterestAmount = accountTotalInterestAmount;
	}
	public String getAccountTotalMinimumAmountDue() {
		return accountTotalMinimumAmountDue;
	}
	public void setAccountTotalMinimumAmountDue(String accountTotalMinimumAmountDue) {
		this.accountTotalMinimumAmountDue = accountTotalMinimumAmountDue;
	}
	public Calendar getAccountLastStatementDate() {
		return accountLastStatementDate;
	}
	public void setAccountLastStatementDate(Calendar accountLastStatementDate) {
		this.accountLastStatementDate = accountLastStatementDate;
	}
	public String getMinimumRepaymentAmountDue() {
		return minimumRepaymentAmountDue;
	}
	public void setMinimumRepaymentAmountDue(String minimumRepaymentAmountDue) {
		this.minimumRepaymentAmountDue = minimumRepaymentAmountDue;
	}
	public String getAccountCreditAmount() {
		return accountCreditAmount;
	}
	public void setAccountCreditAmount(String accountCreditAmount) {
		this.accountCreditAmount = accountCreditAmount;
	}
	public String getAccountDebitAmount() {
		return accountDebitAmount;
	}
	public void setAccountDebitAmount(String accountDebitAmount) {
		this.accountDebitAmount = accountDebitAmount;
	}
	public Calendar getAccountExcessShortStartDate() {
		return accountExcessShortStartDate;
	}
	public void setAccountExcessShortStartDate(Calendar accountExcessShortStartDate) {
		this.accountExcessShortStartDate = accountExcessShortStartDate;
	}
	public String getAccountOverallExcessAmount() {
		return accountOverallExcessAmount;
	}
	public void setAccountOverallExcessAmount(String accountOverallExcessAmount) {
		this.accountOverallExcessAmount = accountOverallExcessAmount;
	}
	public Calendar getAccountLastCycleDate() {
		return accountLastCycleDate;
	}
	public void setAccountLastCycleDate(Calendar accountLastCycleDate) {
		this.accountLastCycleDate = accountLastCycleDate;
	}
	public Calendar getAccountNextCycleDate() {
		return accountNextCycleDate;
	}
	public void setAccountNextCycleDate(Calendar accountNextCycleDate) {
		this.accountNextCycleDate = accountNextCycleDate;
	}
	public String getAccountFullOutstandingInstallmentFlag() {
		return accountFullOutstandingInstallmentFlag;
	}
	public void setAccountFullOutstandingInstallmentFlag(
			String accountFullOutstandingInstallmentFlag) {
		this.accountFullOutstandingInstallmentFlag = accountFullOutstandingInstallmentFlag;
	}
	public String getProvisionStatus() {
		return provisionStatus;
	}
	public void setProvisionStatus(String provisionStatus) {
		this.provisionStatus = provisionStatus;
	}
}
