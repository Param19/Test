/*
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillPayRegistrationVO.
 */
public class BillPayRegistrationVO implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	
	/** The identity number of the customer. */
	private String customerId;
	
	/** The id Type of the customer (passport / nationalId). */
	private String customerIdType;
    
	/** The nationality. */
	private String nationality;
	
	/** The risk check required for the customer. */
	private String riskCheck;

	/** The account number of the user. */
	private String accountNumber;
	
	/** The currency code. */
	private String currencyCode;
	
	/** The country. */
	private String bankCustomerId;
	
	
	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the new customer id
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the customer id type.
	 *
	 * @return the customer id type
	 */
	public String getCustomerIdType() {
		return customerIdType;
	}

	/**
	 * Sets the customer id type.
	 *
	 * @param customerIdType the new customer id type
	 */
	public void setCustomerIdType(String customerIdType) {
		this.customerIdType = customerIdType;
	}

	/**
	 * Gets the nationality.
	 *
	 * @return the nationality
	 */
	public String getNationality() {
		return nationality;
	}

	/**
	 * Sets the nationality.
	 *
	 * @param nationality the new nationality
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 * Gets the risk check.
	 *
	 * @return the risk check
	 */
	public String getRiskCheck() {
		return riskCheck;
	}

	/**
	 * Sets the risk check.
	 *
	 * @param riskCheck the new risk check
	 */
	public void setRiskCheck(String riskCheck) {
		this.riskCheck = riskCheck;
	}

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the bankCustomerId
	 */
	public String getBankCustomerId() {
		return bankCustomerId;
	}

	/**
	 * @param bankCustomerId the bankCustomerId to set
	 */
	public void setBankCustomerId(String bankCustomerId) {
		this.bankCustomerId = bankCustomerId;
	}
	
}
