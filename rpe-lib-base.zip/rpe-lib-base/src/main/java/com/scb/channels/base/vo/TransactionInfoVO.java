package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.scb.channels.base.helper.CommonConstants;

/**
 * The Class TransationInfoVO.
 */
public class TransactionInfoVO implements Serializable, Cloneable {
	
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3891912421312657910L;

	/** The id. */
	private int id;		
	
	/** The txn id. */
	private String txnId;
	
	/** The card auth code. */
	private String cardAuthCode;
	
	/** The isccsof. */
	private String isccsof;
	
	/** The transfer amt. */
	private double transferAmt;
	
	/** The transfer currency cd. */
	private String transferCurrencyCd;
	
	/** The dt transfer. */
	private Date dtTransfer;
	
	/** The dt processed. */
	private Date dtProcessed;
	
	/** The txn purpose. */
	private String txnPurpose;
	
	/** The txn ref1. */
	private String txnRef1;
	
	/** The txn ref2. */
	private String txnRef2;
	
	/** The txn ref3. */
	private String txnRef3;
	
	/** The txn ref4. */
	private String txnRef4;
	
	/** The otp ref no. */
	private String otpRefNo;
	
	/** The txn mode. */
	private String txnMode;
	
	/** The txn type cd. */
	private String txnTypeCd;
	
	/** The processing mode. */
	private int processingMode = CommonConstants.PROCESSING_MODE_POST;
	
	/** The transfer mode. */
	private String transferMode;
	
	/** The txn hash. */
	private String txnHash;
	
	/** The txn force flag. */
	private char txnForceFlag = 'N';
	
	/** The host txn ref no. */
	private String hostTxnRefNo;
	
	/** The host resp cd. */
	private String hostRespCd;
	
	/** The host resp desc. */
	private String hostRespDesc;
	
	/** The maker id. */
	private String makerId;
	
	/** The maker time. */
	private Date makerTime;
	
	/** The checker id. */
	private String checkerId;
	
	/** The checker time. */
	private Date checkerTime;
	
	
	/** The account vo. */
	private AccountVO accountVO;
	
	/** The src account vo. */
	private AccountVO srcAccountVO;
	
	/** The dest account vo. */
	private AccountVO destAccountVO;
	
	/** The inter account vo. */
	private AccountVO interAccountVO;
	
	/** The message vo. */
	private MessageVO messageVO;
	
	/** The client vo. */
	private ClientVO clientVO;
	
	/** The beneficiary vo. */
	private BeneficiaryVO beneficiaryVO;
	
	/** The rounting info vo. */
	private RountingInfoVO rountingInfoVO;
    
    /** The charges type vo. */
    private ChargesTypeVO chargesTypeVO;
    
    /** The standing ins vo. */
    private StandingInsVO standingInsVO;
    
    /** The x rate info vo. */
    private FXRateInfoVO  fXRateInfoVO;
    
    /** The user vo. */
    private UserVO  userVO;
    
    /** The service vo. */
    private ServiceVO serviceVO;
    
    
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private int version;
	
	/** The txn status cd. */
	private String txnStatusCd;
	
	/** The txn force flg. */
	private boolean txnForceFlg;
	
	/** The txn time. */
	private Date txnTime;
	
	/** The due date. */
	private Date dueDate;
	
	/** The txn currency. */
	private String txnCurrency;
	
	/** The txn amount. */
	private double txnAmount;
	
	/** The debit currency. */
	private String debitCurrency;
	
	/** The debit amount. */
	private double debitAmount;
	
	/** The credit currency. */
	private String creditCurrency;
	
	/** The credit amount. */
	private double creditAmount;
	
	/** The txn auth id. */
	private String txnAuthId;
	
	/** The txn auth dtl. */
	private String txnAuthDtl;
	
	/** The rglatory rpt. */
	private String rglatoryRpt;
	
	/** The ref info. */
	private List<RefInfoTypeVO> refInfo;
	
	/** The client ref no. */
	private String clientRefNo;
	
	/**The debit Narration */
	private List<NarrationVO> debitNarration;
	
	/**The  extended Debit Narrative*/
	private List<NarrationVO> extendedDebitNarrative;
	
	/**The debit Narration In Local Currency */
	private List<NarrationVO> debitNarrationInLocalCurrency;
	
	/**The  credit Narration*/
	private List<NarrationVO> creditNarration;
	
	/**The  extended Credit Narrative*/
	private List<NarrationVO> extendedCreditNarrative;
	
	/**The  credit Narration In Local Currency*/
	private List<NarrationVO> creditNarrationInLocalCurrency;
	
	 private MakerVO maker;
	 private CheckerVO checker;
	 private String sourceSystemName;
	 private String suspectedTransactionFlag;
	 private String advisedTransactionFlag;	 
	 private String transactionBranch;
	 private String transactionType;
	 private String provider;
	 private String txnSubType;
	 
	public String getSourceSystemName() {
		return sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

	/**
	 * Gets the client ref no.
	 *
	 * @return the client ref no
	 */
	public String getClientRefNo() {
		return clientRefNo;
	}
	
	/**
	 * Sets the client ref no.
	 *
	 * @param clientRefNo the new client ref no
	 */
	public void setClientRefNo(String clientRefNo) {
		this.clientRefNo = clientRefNo;
	}
	
	/**
	 * Gets the txn id.
	 *
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}
	
	/**
	 * Sets the txn id.
	 *
	 * @param txnId the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	
	/**
	 * Gets the card auth code.
	 *
	 * @return the cardAuthCode
	 */
	public String getCardAuthCode() {
		return cardAuthCode;
	}
	
	/**
	 * Sets the card auth code.
	 *
	 * @param cardAuthCode the cardAuthCode to set
	 */
	public void setCardAuthCode(String cardAuthCode) {
		this.cardAuthCode = cardAuthCode;
	}
	
	/**
	 * Gets the isccsof.
	 *
	 * @return the isccsof
	 */
	public String getIsccsof() {
		return isccsof;
	}
	
	/**
	 * Sets the isccsof.
	 *
	 * @param isccsof the isccsof to set
	 */
	public void setIsccsof(String isccsof) {
		this.isccsof = isccsof;
	}
	
	/**
	 * Gets the transfer amt.
	 *
	 * @return the transferAmt
	 */
	public double getTransferAmt() {
		return transferAmt;
	}
	
	/**
	 * Sets the transfer amt.
	 *
	 * @param transferAmt the transferAmt to set
	 */
	public void setTransferAmt(double transferAmt) {
		this.transferAmt = transferAmt;
	}
	
	/**
	 * Gets the transfer currency cd.
	 *
	 * @return the transferCurrencyCd
	 */
	public String getTransferCurrencyCd() {
		return transferCurrencyCd;
	}
	
	/**
	 * Sets the transfer currency cd.
	 *
	 * @param transferCurrencyCd the transferCurrencyCd to set
	 */
	public void setTransferCurrencyCd(String transferCurrencyCd) {
		this.transferCurrencyCd = transferCurrencyCd;
	}
	
	/**
	 * Gets the dt transfer.
	 *
	 * @return the dtTransfer
	 */
	public Date getDtTransfer() {
		return dtTransfer;
	}
	
	/**
	 * Sets the dt transfer.
	 *
	 * @param dtTransfer the dtTransfer to set
	 */
	public void setDtTransfer(Date dtTransfer) {
		this.dtTransfer = dtTransfer;
	}
	
	/**
	 * Gets the dt processed.
	 *
	 * @return the dtProcessed
	 */
	public Date getDtProcessed() {
		return dtProcessed;
	}
	
	/**
	 * Sets the dt processed.
	 *
	 * @param dtProcessed the dtProcessed to set
	 */
	public void setDtProcessed(Date dtProcessed) {
		this.dtProcessed = dtProcessed;
	}
	
	/**
	 * Gets the txn purpose.
	 *
	 * @return the txnPurpose
	 */
	public String getTxnPurpose() {
		return txnPurpose;
	}
	
	/**
	 * Sets the txn purpose.
	 *
	 * @param txnPurpose the txnPurpose to set
	 */
	public void setTxnPurpose(String txnPurpose) {
		this.txnPurpose = txnPurpose;
	}
	
	/**
	 * Gets the txn ref1.
	 *
	 * @return the txnRef1
	 */
	public String getTxnRef1() {
		return txnRef1;
	}
	
	/**
	 * Sets the txn ref1.
	 *
	 * @param txnRef1 the txnRef1 to set
	 */
	public void setTxnRef1(String txnRef1) {
		this.txnRef1 = txnRef1;
	}
	
	/**
	 * Gets the txn ref2.
	 *
	 * @return the txnRef2
	 */
	public String getTxnRef2() {
		return txnRef2;
	}
	
	/**
	 * Sets the txn ref2.
	 *
	 * @param txnRef2 the txnRef2 to set
	 */
	public void setTxnRef2(String txnRef2) {
		this.txnRef2 = txnRef2;
	}
	
	/**
	 * Gets the txn ref3.
	 *
	 * @return the txnRef3
	 */
	public String getTxnRef3() {
		return txnRef3;
	}
	
	/**
	 * Sets the txn ref3.
	 *
	 * @param txnRef3 the txnRef3 to set
	 */
	public void setTxnRef3(String txnRef3) {
		this.txnRef3 = txnRef3;
	}
	
	/**
	 * Gets the txn ref4.
	 *
	 * @return the txnRef4
	 */
	public String getTxnRef4() {
		return txnRef4;
	}
	
	/**
	 * Sets the txn ref4.
	 *
	 * @param txnRef4 the txnRef4 to set
	 */
	public void setTxnRef4(String txnRef4) {
		this.txnRef4 = txnRef4;
	}
	
	/**
	 * Gets the otp ref no.
	 *
	 * @return the otpRefNo
	 */
	public String getOtpRefNo() {
		return otpRefNo;
	}
	
	/**
	 * Sets the otp ref no.
	 *
	 * @param otpRefNo the otpRefNo to set
	 */
	public void setOtpRefNo(String otpRefNo) {
		this.otpRefNo = otpRefNo;
	}
	
	/**
	 * Gets the txn mode.
	 *
	 * @return the txnMode
	 */
	public String getTxnMode() {
		return txnMode;
	}
	
	/**
	 * Sets the txn mode.
	 *
	 * @param txnMode the txnMode to set
	 */
	public void setTxnMode(String txnMode) {
		this.txnMode = txnMode;
	}
	
	/**
	 * Gets the txn type cd.
	 *
	 * @return the txnTypeCd
	 */
	public String getTxnTypeCd() {
		return txnTypeCd;
	}
	
	/**
	 * Sets the txn type cd.
	 *
	 * @param txnTypeCd the txnTypeCd to set
	 */
	public void setTxnTypeCd(String txnTypeCd) {
		this.txnTypeCd = txnTypeCd;
	}
	
	/**
	 * Gets the processing mode.
	 *
	 * @return the processingMode
	 */
	public int getProcessingMode() {
		return processingMode;
	}
	
	/**
	 * Sets the processing mode.
	 *
	 * @param processingMode the processingMode to set
	 */
	public void setProcessingMode(int processingMode) {
		this.processingMode = processingMode;
	}
	
	/**
	 * Gets the transfer mode.
	 *
	 * @return the transferMode
	 */
	public String getTransferMode() {
		return transferMode;
	}
	
	/**
	 * Sets the transfer mode.
	 *
	 * @param transferMode the transferMode to set
	 */
	public void setTransferMode(String transferMode) {
		this.transferMode = transferMode;
	}
	
	/**
	 * Gets the txn hash.
	 *
	 * @return the txnHash
	 */
	public String getTxnHash() {
		final int prime = 31;
		int result = 1;
		result = prime* result
				+ ((txnId == null) ? 0 : txnId.hashCode())
						+ ((dtTransfer==null)?Calendar.getInstance().getTime().hashCode():dtTransfer.hashCode()) +((transferMode == null) ? "A".hashCode() :  transferMode.hashCode())
						+ String.valueOf(txnAmount).hashCode()
						+ String.valueOf(txnCurrency).hashCode();
		result = prime* result
				+ ((userVO == null) ? 0 : (userVO.getChannelId() != null ? userVO.getChannelId().hashCode(): 0)
						+ (userVO.getCountry() != null ? userVO.getCountry().hashCode() : 0));
		this.txnHash = String.valueOf(result);
		return txnHash;
	}
	
	/**
	 * Gets the txn force flag.
	 *
	 * @return the txnForceFlag
	 */
	public char getTxnForceFlag() {
		return txnForceFlag;
	}
	
	/**
	 * Sets the txn force flag.
	 *
	 * @param txnForceFlag the txnForceFlag to set
	 */
	public void setTxnForceFlag(char txnForceFlag) {
		this.txnForceFlag = txnForceFlag;
	}
	
	/**
	 * Gets the host txn ref no.
	 *
	 * @return the hostTxnRefNo
	 */
	public String getHostTxnRefNo() {
		return hostTxnRefNo;
	}
	
	/**
	 * Sets the host txn ref no.
	 *
	 * @param hostTxnRefNo the hostTxnRefNo to set
	 */
	public void setHostTxnRefNo(String hostTxnRefNo) {
		this.hostTxnRefNo = hostTxnRefNo;
	}
	
	/**
	 * Gets the host resp cd.
	 *
	 * @return the hostRespCd
	 */
	public String getHostRespCd() {
		return hostRespCd;
	}
	
	/**
	 * Sets the host resp cd.
	 *
	 * @param hostRespCd the hostRespCd to set
	 */
	public void setHostRespCd(String hostRespCd) {
		this.hostRespCd = hostRespCd;
	}
	
	/**
	 * Gets the host resp desc.
	 *
	 * @return the hostRespDesc
	 */
	public String getHostRespDesc() {
		if(hostRespDesc != null && hostRespDesc.length() > 100){
			hostRespDesc = hostRespDesc.substring(0, 100);
		}
		return hostRespDesc;
	}
	
	/**
	 * Sets the host resp desc.
	 *
	 * @param hostRespDesc the hostRespDesc to set
	 */
	public void setHostRespDesc(String hostRespDesc) {
		if(hostRespDesc != null && hostRespDesc.length() > 100){
			hostRespDesc = hostRespDesc.substring(0, 100);
		}
		this.hostRespDesc = hostRespDesc;
	}
	
	/**
	 * Gets the maker id.
	 *
	 * @return the makerId
	 */
	public String getMakerId() {
		return makerId;
	}
	
	/**
	 * Sets the maker id.
	 *
	 * @param makerId the makerId to set
	 */
	public void setMakerId(String makerId) {
		this.makerId = makerId;
	}
	
	/**
	 * Gets the maker time.
	 *
	 * @return the makerTime
	 */
	public Date getMakerTime() {
		return makerTime;
	}
	
	/**
	 * Sets the maker time.
	 *
	 * @param makerTime the makerTime to set
	 */
	public void setMakerTime(Date makerTime) {
		this.makerTime = makerTime;
	}
	
	/**
	 * Gets the checker id.
	 *
	 * @return the checkerId
	 */
	public String getCheckerId() {
		return checkerId;
	}
	
	/**
	 * Sets the checker id.
	 *
	 * @param checkerId the checkerId to set
	 */
	public void setCheckerId(String checkerId) {
		this.checkerId = checkerId;
	}
	
	/**
	 * Gets the checker time.
	 *
	 * @return the checkerTime
	 */
	public Date getCheckerTime() {
		return checkerTime;
	}
	
	/**
	 * Sets the checker time.
	 *
	 * @param checkerTime the checkerTime to set
	 */
	public void setCheckerTime(Date checkerTime) {
		this.checkerTime = checkerTime;
	}
	
	/**
	 * Gets the account vo.
	 *
	 * @return the accountVO
	 */
	public AccountVO getAccountVO() {
		return accountVO;
	}
	
	/**
	 * Sets the account vo.
	 *
	 * @param accountVO the accountVO to set
	 */
	public void setAccountVO(AccountVO accountVO) {
		this.accountVO = accountVO;
	}
	
	/**
	 * Gets the message vo.
	 *
	 * @return the messageVO
	 */
	public MessageVO getMessageVO() {
		return messageVO;
	}
	
	/**
	 * Sets the message vo.
	 *
	 * @param messageVO the messageVO to set
	 */
	public void setMessageVO(MessageVO messageVO) {
		this.messageVO = messageVO;
	}
	
	/**
	 * Gets the client vo.
	 *
	 * @return the clientVO
	 */
	public ClientVO getClientVO() {
		return clientVO;
	}
	
	/**
	 * Sets the client vo.
	 *
	 * @param clientVO the clientVO to set
	 */
	public void setClientVO(ClientVO clientVO) {
		this.clientVO = clientVO;
	}
	
	/**
	 * Gets the beneficiary vo.
	 *
	 * @return the beneficiaryVO
	 */
	public BeneficiaryVO getBeneficiaryVO() {
		return beneficiaryVO;
	}
	
	/**
	 * Sets the beneficiary vo.
	 *
	 * @param beneficiaryVO the beneficiaryVO to set
	 */
	public void setBeneficiaryVO(BeneficiaryVO beneficiaryVO) {
		this.beneficiaryVO = beneficiaryVO;
	}
	
	/**
	 * Gets the rounting info vo.
	 *
	 * @return the rountingInfoVO
	 */
	public RountingInfoVO getRountingInfoVO() {
		return rountingInfoVO;
	}
	
	/**
	 * Sets the rounting info vo.
	 *
	 * @param rountingInfoVO the rountingInfoVO to set
	 */
	public void setRountingInfoVO(RountingInfoVO rountingInfoVO) {
		this.rountingInfoVO = rountingInfoVO;
	}
	
	/**
	 * Gets the charges type vo.
	 *
	 * @return the chargesTypeVO
	 */
	public ChargesTypeVO getChargesTypeVO() {
		return chargesTypeVO;
	}
	
	/**
	 * Sets the charges type vo.
	 *
	 * @param chargesTypeVO the chargesTypeVO to set
	 */
	public void setChargesTypeVO(ChargesTypeVO chargesTypeVO) {
		this.chargesTypeVO = chargesTypeVO;
	}
	
	/**
	 * Gets the standing ins vo.
	 *
	 * @return the standingInsVO
	 */
	public StandingInsVO getStandingInsVO() {
		return standingInsVO;
	}
	
	/**
	 * Sets the standing ins vo.
	 *
	 * @param standingInsVO the standingInsVO to set
	 */
	public void setStandingInsVO(StandingInsVO standingInsVO) {
		this.standingInsVO = standingInsVO;
	}
	
	/**
	 * Gets the f x rate info vo.
	 *
	 * @return the fXRateInfoVO
	 */
	public FXRateInfoVO getfXRateInfoVO() {
		return fXRateInfoVO;
	}
	
	/**
	 * Sets the f x rate info vo.
	 *
	 * @param fXRateInfoVO the fXRateInfoVO to set
	 */
	public void setfXRateInfoVO(FXRateInfoVO fXRateInfoVO) {
		this.fXRateInfoVO = fXRateInfoVO;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dtCreated
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the dtCreated to set
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dtUpd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the dtUpd to set
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the updBy
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the updBy to set
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	
	/**
	 * Gets the txn status cd.
	 *
	 * @return the txnStatusCd
	 */
	public String getTxnStatusCd() {
		return txnStatusCd;
	}
	
	/**
	 * Sets the txn status cd.
	 *
	 * @param txnStatusCd the txnStatusCd to set
	 */
	public void setTxnStatusCd(String txnStatusCd) {
		this.txnStatusCd = txnStatusCd;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Gets the user vo.
	 *
	 * @return the userVO
	 */
	public UserVO getUserVO() {
		return userVO;
	}
	
	/**
	 * Sets the user vo.
	 *
	 * @param userVO the userVO to set
	 */
	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}
	
	/**
	 * Gets the src account vo.
	 *
	 * @return the srcAccountVO
	 */
	public AccountVO getSrcAccountVO() {
		return srcAccountVO;
	}
	
	/**
	 * Sets the src account vo.
	 *
	 * @param srcAccountVO the srcAccountVO to set
	 */
	public void setSrcAccountVO(AccountVO srcAccountVO) {
		this.srcAccountVO = srcAccountVO;
	}
	
	/**
	 * Gets the dest account vo.
	 *
	 * @return the destAccountVO
	 */
	public AccountVO getDestAccountVO() {
		return destAccountVO;
	}
	
	/**
	 * Sets the dest account vo.
	 *
	 * @param destAccountVO the destAccountVO to set
	 */
	public void setDestAccountVO(AccountVO destAccountVO) {
		this.destAccountVO = destAccountVO;
	}
	
	/**
	 * Gets the inter account vo.
	 *
	 * @return the interAccountVO
	 */
	public AccountVO getInterAccountVO() {
		return interAccountVO;
	}
	
	/**
	 * Sets the inter account vo.
	 *
	 * @param interAccountVO the interAccountVO to set
	 */
	public void setInterAccountVO(AccountVO interAccountVO) {
		this.interAccountVO = interAccountVO;
	}

	/**
	 * Checks if is txn force flg.
	 *
	 * @return the txnForceFlg
	 */
	public boolean isTxnForceFlg() {
		return txnForceFlg;
	}
	
	/**
	 * Sets the txn force flg.
	 *
	 * @param txnForceFlg the txnForceFlg to set
	 */
	public void setTxnForceFlg(boolean txnForceFlg) {
		this.txnForceFlg = txnForceFlg;
	}
	
	/**
	 * Gets the txn time.
	 *
	 * @return the txnTime
	 */
	public Date getTxnTime() {
		return txnTime;
	}
	
	/**
	 * Sets the txn time.
	 *
	 * @param txnTime the txnTime to set
	 */
	public void setTxnTime(Date txnTime) {
		this.txnTime = txnTime;
	}
	
	/**
	 * Gets the due date.
	 *
	 * @return the dueDate
	 */
	public Date getDueDate() {
		return dueDate;
	}
	
	/**
	 * Sets the due date.
	 *
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	
	/**
	 * Gets the txn currency.
	 *
	 * @return the txnCurrency
	 */
	public String getTxnCurrency() {
		return txnCurrency;
	}
	
	/**
	 * Sets the txn currency.
	 *
	 * @param txnCurrency the txnCurrency to set
	 */
	public void setTxnCurrency(String txnCurrency) {
		this.txnCurrency = txnCurrency;
	}
	
	/**
	 * Gets the txn amount.
	 *
	 * @return the txnAmount
	 */
	public double getTxnAmount() {
		return txnAmount;
	}
	
	/**
	 * Sets the txn amount.
	 *
	 * @param txnAmount the txnAmount to set
	 */
	public void setTxnAmount(double txnAmount) {
		this.txnAmount = txnAmount;
	}
	
	/**
	 * Gets the debit currency.
	 *
	 * @return the debitCurrency
	 */
	public String getDebitCurrency() {
		return debitCurrency;
	}
	
	/**
	 * Sets the debit currency.
	 *
	 * @param debitCurrency the debitCurrency to set
	 */
	public void setDebitCurrency(String debitCurrency) {
		this.debitCurrency = debitCurrency;
	}
	
	/**
	 * Gets the debit amount.
	 *
	 * @return the debitAmount
	 */
	public double getDebitAmount() {
		return debitAmount;
	}
	
	/**
	 * Sets the debit amount.
	 *
	 * @param debitAmount the debitAmount to set
	 */
	public void setDebitAmount(double debitAmount) {
		this.debitAmount = debitAmount;
	}
	
	/**
	 * Gets the credit currency.
	 *
	 * @return the creditCurrency
	 */
	public String getCreditCurrency() {
		return creditCurrency;
	}
	
	/**
	 * Sets the credit currency.
	 *
	 * @param creditCurrency the creditCurrency to set
	 */
	public void setCreditCurrency(String creditCurrency) {
		this.creditCurrency = creditCurrency;
	}
	
	/**
	 * Gets the credit amount.
	 *
	 * @return the creditAmount
	 */
	public double getCreditAmount() {
		return creditAmount;
	}
	
	/**
	 * Sets the credit amount.
	 *
	 * @param creditAmount the creditAmount to set
	 */
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	
	/**
	 * Gets the txn auth id.
	 *
	 * @return the txnAuthId
	 */
	public String getTxnAuthId() {
		return txnAuthId;
	}
	
	/**
	 * Sets the txn auth id.
	 *
	 * @param txnAuthId the txnAuthId to set
	 */
	public void setTxnAuthId(String txnAuthId) {
		this.txnAuthId = txnAuthId;
	}
	
	/**
	 * Gets the txn auth dtl.
	 *
	 * @return the txnAuthDtl
	 */
	public String getTxnAuthDtl() {
		return txnAuthDtl;
	}
	
	/**
	 * Sets the txn auth dtl.
	 *
	 * @param txnAuthDtl the txnAuthDtl to set
	 */
	public void setTxnAuthDtl(String txnAuthDtl) {
		this.txnAuthDtl = txnAuthDtl;
	}
	
	/**
	 * Gets the rglatory rpt.
	 *
	 * @return the rglatoryRpt
	 */
	public String getRglatoryRpt() {
		return rglatoryRpt;
	}
	
	/**
	 * Sets the rglatory rpt.
	 *
	 * @param rglatoryRpt the rglatoryRpt to set
	 */
	public void setRglatoryRpt(String rglatoryRpt) {
		this.rglatoryRpt = rglatoryRpt;
	}
	
	/**
	 * Gets the ref info.
	 *
	 * @return the refInfo
	 */
	public List<RefInfoTypeVO> getRefInfo() {
		return refInfo;
	}
	
	/**
	 * Sets the ref info.
	 *
	 * @param refInfo the refInfo to set
	 */
	public void setRefInfo(List<RefInfoTypeVO> refInfo) {
		this.refInfo = refInfo;
	}
	
	/**
	 * Gets the service vo.
	 *
	 * @return the serviceVO
	 */
	public ServiceVO getServiceVO() {
		return serviceVO;
	}
	
	/**
	 * Sets the service vo.
	 *
	 * @param serviceVO the serviceVO to set
	 */
	public void setServiceVO(ServiceVO serviceVO) {
		this.serviceVO = serviceVO;
	}
	
	/**
	 * Sets the txn hash.
	 *
	 * @param txnHash the txnHash to set
	 */
	public void setTxnHash(String txnHash) {
		this.txnHash = txnHash;
	}
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	public List<NarrationVO> getDebitNarration() {
		return debitNarration;
	}

	public void setDebitNarration(List<NarrationVO> debitNarration) {
		this.debitNarration = debitNarration;
	}

	public List<NarrationVO> getExtendedDebitNarrative() {
		return extendedDebitNarrative;
	}

	public void setExtendedDebitNarrative(List<NarrationVO> extendedDebitNarrative) {
		this.extendedDebitNarrative = extendedDebitNarrative;
	}

	public List<NarrationVO> getDebitNarrationInLocalCurrency() {
		return debitNarrationInLocalCurrency;
	}

	public void setDebitNarrationInLocalCurrency(
			List<NarrationVO> debitNarrationInLocalCurrency) {
		this.debitNarrationInLocalCurrency = debitNarrationInLocalCurrency;
	}

	public List<NarrationVO> getCreditNarration() {
		return creditNarration;
	}

	public void setCreditNarration(List<NarrationVO> creditNarration) {
		this.creditNarration = creditNarration;
	}

	public List<NarrationVO> getExtendedCreditNarrative() {
		return extendedCreditNarrative;
	}

	public void setExtendedCreditNarrative(List<NarrationVO> extendedCreditNarrative) {
		this.extendedCreditNarrative = extendedCreditNarrative;
	}

	public List<NarrationVO> getCreditNarrationInLocalCurrency() {
		return creditNarrationInLocalCurrency;
	}

	public void setCreditNarrationInLocalCurrency(
			List<NarrationVO> creditNarrationInLocalCurrency) {
		this.creditNarrationInLocalCurrency = creditNarrationInLocalCurrency;
	}

	public MakerVO getMaker() {
		return maker;
	}

	public void setMaker(MakerVO maker) {
		this.maker = maker;
	}

	public CheckerVO getChecker() {
		return checker;
	}

	public void setChecker(CheckerVO checker) {
		this.checker = checker;
	}

	public String getSuspectedTransactionFlag() {
		return suspectedTransactionFlag;
	}

	public void setSuspectedTransactionFlag(String suspectedTransactionFlag) {
		this.suspectedTransactionFlag = suspectedTransactionFlag;
	}

	public String getAdvisedTransactionFlag() {
		return advisedTransactionFlag;
	}

	public void setAdvisedTransactionFlag(String advisedTransactionFlag) {
		this.advisedTransactionFlag = advisedTransactionFlag;
	}

	public String getTransactionBranch() {
		return transactionBranch;
	}

	public void setTransactionBranch(String transactionBranch) {
		this.transactionBranch = transactionBranch;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getTxnSubType() {
		return txnSubType;
	}

	public void setTxnSubType(String txnSubType) {
		this.txnSubType = txnSubType;
	}
	
}
