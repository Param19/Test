/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * This class contains channel Information.
 *
 * @author 1411807
 */
public class ChannelVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1363563939157251654L;
	
	/** The channel id. */
	private String channelId;
	
	/** The channel name. */
	private String channelName;

	/**
	 * Gets the channel id.
	 *
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * Sets the channel id.
	 *
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * Gets the channel name.
	 *
	 * @return the channelName
	 */
	public String getChannelName() {
		return channelName;
	}

	/**
	 * Sets the channel name.
	 *
	 * @param channelName the channelName to set
	 */
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

}
