package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

 
/**
 * @author 1521723
 *
 */
public class PayeeFieldDetailsView implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	private Integer payeeFieldId;
	/**
	 * fieldLabelName
	 */
	private String fieldLabelName;
	/**
	 * fieldType
	 */
	private String fieldType;
	/**
	 * fieldDefaultValues
	 */
	private String fieldDefaultValues;
	/**
	 * fieldMinLength
	 */
	private String fieldMinLength;
	/**
	 * fieldMaxLength
	 */
	private String fieldMaxLength;
	/**
	 * fieldDataType
	 */
	private String fieldDataType;
	/**
	 * isfieldRequired
	 */
	private String isfieldRequired;
	/**
	 * orderSequence
	 */
	private Integer orderSequence;
	/**
	 * caption
	 */
	private String caption;
	
	/**
	 * fieldValue
	 */
	private String fieldValue;
	
	/**
	 * fieldValue
	 */
	private Integer payeeId;
	
	/**
	 * payeeFieldItems
	 */
	private Set<BillerFieldItemVO> payeeFieldItems=new HashSet<BillerFieldItemVO>(0);
	
	/**
	 * fieldId
	 */
	private Integer fieldId;
	/**
	 * remarks
	 */
	private String remarks;
	/**
	 * createdBy
	 */
	private String createdBy;
	/**
	 * updatedBy
	 */
	private String updatedBy;
	/**
	 * dateCreated
	 */
	private Date dateCreated;
	/**
	 * dateUpdated
	 */
	private Date dateUpdated;
	
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the dateCreated
	 */
	public Date getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return the dateUpdated
	 */
	public Date getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the fieldId
	 */
	public Integer getFieldId() {
		return fieldId;
	}

	/**
	 * @param fieldId the fieldId to set
	 */
	public void setFieldId(Integer fieldId) {
		this.fieldId = fieldId;
	}

	/**
	 * @return the payeeId
	 */
	public Integer getPayeeId() {
		return payeeId;
	}

	/**
	 * @param payeeId the payeeId to set
	 */
	public void setPayeeId(Integer payeeId) {
		this.payeeId = payeeId;
	}
	/**
	 * @return the payeeFieldItems
	 */
	public Set<BillerFieldItemVO> getPayeeFieldItems() {
		return payeeFieldItems;
	}

	/**
	 * @param payeeFieldItems the payeeFieldItems to set
	 */
	public void setPayeeFieldItems(Set<BillerFieldItemVO> payeeFieldItems) {
		this.payeeFieldItems = payeeFieldItems;
	}

	/**
	 * @return the id
	 */
	public Integer getPayeeFieldId() {
		return payeeFieldId;
	}

	/**
	 * @param id the id to set
	 */
	public void setPayeeFieldId(Integer payeeFieldId) {
		this.payeeFieldId = payeeFieldId;
	}

	/**
	 * @return the fieldLabelName
	 */
	public String getFieldLabelName() {
		return fieldLabelName;
	}

	/**
	 * @param fieldLabelName the fieldLabelName to set
	 */
	public void setFieldLabelName(String fieldLabelName) {
		this.fieldLabelName = fieldLabelName;
	}

	/**
	 * @return the fieldType
	 */
	public String getFieldType() {
		return fieldType;
	}

	/**
	 * @param fieldType the fieldType to set
	 */
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	/**
	 * @return the fieldDefaultValues
	 */
	public String getFieldDefaultValues() {
		return fieldDefaultValues;
	}

	/**
	 * @param fieldDefaultValues the fieldDefaultValues to set
	 */
	public void setFieldDefaultValues(String fieldDefaultValues) {
		this.fieldDefaultValues = fieldDefaultValues;
	}

	/**
	 * @return the fieldMinLength
	 */
	public String getFieldMinLength() {
		return fieldMinLength;
	}

	/**
	 * @param fieldMinLength the fieldMinLength to set
	 */
	public void setFieldMinLength(String fieldMinLength) {
		this.fieldMinLength = fieldMinLength;
	}

	/**
	 * @return the fieldMaxLength
	 */
	public String getFieldMaxLength() {
		return fieldMaxLength;
	}

	/**
	 * @param fieldMaxLength the fieldMaxLength to set
	 */
	public void setFieldMaxLength(String fieldMaxLength) {
		this.fieldMaxLength = fieldMaxLength;
	}

	/**
	 * @return the fieldDataType
	 */
	public String getFieldDataType() {
		return fieldDataType;
	}

	/**
	 * @param fieldDataType the fieldDataType to set
	 */
	public void setFieldDataType(String fieldDataType) {
		this.fieldDataType = fieldDataType;
	}

	/**
	 * @return the isfieldRequired
	 */
	public String getIsfieldRequired() {
		return isfieldRequired;
	}

	/**
	 * @param isfieldRequired the isfieldRequired to set
	 */
	public void setIsfieldRequired(String isfieldRequired) {
		this.isfieldRequired = isfieldRequired;
	}

	/**
	 * @return the orderSequence
	 */
	public Integer getOrderSequence() {
		return orderSequence;
	}

	/**
	 * @param orderSequence the orderSequence to set
	 */
	public void setOrderSequence(Integer orderSequence) {
		this.orderSequence = orderSequence;
	}

	/**
	 * @return the caption
	 */
	public String getCaption() {
		return caption;
	}

	/**
	 * @param caption the caption to set
	 */
	public void setCaption(String caption) {
		this.caption = caption;
	}

	/**
	 * @return the fieldValue
	 */
	public String getFieldValue() {
		return fieldValue;
	}

	/**
	 * @param fieldValue the fieldValue to set
	 */
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}


}
	