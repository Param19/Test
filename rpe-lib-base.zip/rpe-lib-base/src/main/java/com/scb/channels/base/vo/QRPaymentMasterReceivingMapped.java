package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentMasterReceivingMapped implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3873180005234418580L;

	private String SubscriberId;
	
	private String SubscriberType;
	
	private String SubscriberAlias;

	public String getSubscriberId() {
		return SubscriberId;
	}
	@JsonSetter("SubscriberId")
	public void setSubscriberId(String subscriberId) {
		SubscriberId = subscriberId;
	}

	public String getSubscriberType() {
		return SubscriberType;
	}
	@JsonSetter("SubscriberType")
	public void setSubscriberType(String subscriberType) {
		SubscriberType = subscriberType;
	}

	public String getSubscriberAlias() {
		return SubscriberAlias;
	}
	@JsonSetter("SubscriberAlias")
	public void setSubscriberAlias(String subscriberAlias) {
		SubscriberAlias = subscriberAlias;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterReceivingMapped [SubscriberId=" + SubscriberId
				+ ", SubscriberType=" + SubscriberType + ", SubscriberAlias="
				+ SubscriberAlias + "]";
	}
	
	

}
