package com.scb.channels.base.helper;

/**
 * The Enum Messages.
 */
public enum Messages {

	_000("0:Transaction Successfully completed:000"),
	_001("0:Valid Customer:0"), 
	_002("0:mPIN changed successfully. Login again with newly changed mPIN:0"),
	_003("0:Your Logout Completed  Successfully:0"),
	_004("0:Cheque stopped Successfully:0"),
	_006("0: Bill payment completed successfully using CARD:006"),
	_007("0: Bill payment completed successfully using CASA:007"),
	_200("0:Transaction Successfully completed:0"), 
	_500("0:Transaction Submitted for processing:500"),
	_700("0:Valid ToAccount Number:700"),
	_011("0:First Time Login:011"),
	_012("-1:Already pin changed:012"),
	_300("0:valid login .You can do the pin change:300"),
	_301("-1:Invalid login .Count is reached to maximum:301"),
	_302("0:Successfully updated the latest pin:302"),
	_303("0:Successfully Registered a customer:303"),
	_304("0: Biller Added Sucessfully:304"),
	_305("0: Biller Deleted Sucessfully:305"),
	_306("0: Payees retrived Sucessfully:306"),
	_307("307: No active Payees :307"),
	_222("0:Transaction Submitted for processing:222"),
	_308("308: Payee exists already.:308"),
	_309("309: Biller not deleted.:309"),
	_310("310: Payee Nick name exists already.:310"),
	_311("311: Consumer Number invalid.:311"),
	_312("312: Payee Nick name is invalid.:312"),
	_313("313: Payee ID should not be blank.:313"),
	_315("315: Consumer number should not be blank.:315"),
	_150("150:Payment History SuccessFully Retrived:150"),
	_180("0:Billers Available:180"),
	_190("-1:Billers Not Available:190"),
	_314("-1:Biller Code Not exists:314"),
	_0("0:Request Processed Successfully:0"), 
	_1("-1:Request Processing Failed:-1"),
	_11("1:Request InProgress:1"),
	_350("350:Valid Wallet Detail:350"),
	_351("351:Validation Success:351"), 
	_352("352:Biller fields not found:352"),
	_151("-1:Unable to retrieve Payment History:151"),
	
	_353("0: Wallet Added Sucessfully:353"),
	_354("0: Wallet Deleted Sucessfully:354"),
	_355("0: Wallet retrived Sucessfully:355"),
	_356("356: No active Wallets:356"),
	_357("357: Selected account is already linked with a wallet of same mobile money:357"),
	_358("358: Wallet Nick name exists already:358"),
	_359("359: Wallets DeActivated Sucessfully:359"),
	_360("360: Wallets Activated Sucessfully:360"),
	_361("361: No deactive Wallets:361");

	/** The value. */
	private String value;

	/**
	 * Instantiates a new messages.
	 * 
	 * @param value
	 *            the value
	 */
	private Messages(String value) {
		this.value = value;
	}

	/**
	 * Gets the message.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return (value.contains(CommonConstants.COLON) ? value.split(CommonConstants.COLON)[1] : value);
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return (value.contains(CommonConstants.COLON) ? value.split(CommonConstants.COLON)[0] : value);
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getResponseCode() {
		return (value.contains(CommonConstants.COLON) ? value.split(CommonConstants.COLON)[2] : value);
	}
}
