/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ProductDetailsResponseVO.
 *
 * @author 1411807
 */
public class ProductDetailsResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -484497054668672500L;

	private BeneficiaryResponseVO beneficiaryResponseVO;
	
	private BillerListResponseVO billerListResponseVO;
	
	private AccountListResponseVO accountListResponseVO;

	/**
	 * @return the beneficiaryResponseVO
	 */
	public BeneficiaryResponseVO getBeneficiaryResponseVO() {
		return beneficiaryResponseVO;
	}

	/**
	 * @param beneficiaryResponseVO the beneficiaryResponseVO to set
	 */
	public void setBeneficiaryResponseVO(BeneficiaryResponseVO beneficiaryResponseVO) {
		this.beneficiaryResponseVO = beneficiaryResponseVO;
	}

	/**
	 * @return the billerListResponseVO
	 */
	public BillerListResponseVO getBillerListResponseVO() {
		return billerListResponseVO;
	}

	/**
	 * @param billerListResponseVO the billerListResponseVO to set
	 */
	public void setBillerListResponseVO(BillerListResponseVO billerListResponseVO) {
		this.billerListResponseVO = billerListResponseVO;
	}

	/**
	 * @return the accountListResponseVO
	 */
	public AccountListResponseVO getAccountListResponseVO() {
		return accountListResponseVO;
	}

	/**
	 * @param accountListResponseVO the accountListResponseVO to set
	 */
	public void setAccountListResponseVO(AccountListResponseVO accountListResponseVO) {
		this.accountListResponseVO = accountListResponseVO;
	}
}
