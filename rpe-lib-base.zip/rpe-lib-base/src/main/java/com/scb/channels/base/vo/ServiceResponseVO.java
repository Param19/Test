package com.scb.channels.base.vo;

public class ServiceResponseVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2160401119228196033L;

}
