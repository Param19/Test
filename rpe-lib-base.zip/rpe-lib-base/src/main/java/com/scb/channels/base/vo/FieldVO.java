/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * @author 1411807
 *
 */
public class FieldVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2856542631928420701L;

	private String fieldID;
	
	private String fieldName;
	
	private String fieldValue;

	public String getFieldID() {
		return fieldID;
	}

	public void setFieldID(String fieldID) {
		this.fieldID = fieldID;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
}
