/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class ExchangeInfo.
 *
 * @author 1411807
 */
public class ExchangeInfo implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5723031551761440278L;
	
	/** The path. */
	private String path;
	
	/** The exception list. */
	private List<Exception> exceptionList = new ArrayList<Exception>();
	
	/** The request object. */
	private Class<?> requestObject;
	
	/** The response object. */
	private Class<?> responseObject;
	
	/** The key response. */
	private Map<String, Object> keyResponse = new HashMap<String, Object>();;

	/**
	 * Gets the path.
	 *
	 * @return the path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Sets the path.
	 *
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * Gets the exception list.
	 *
	 * @return the exceptionList
	 */
	public List<Exception> getExceptionList() {
		return exceptionList;
	}

	/**
	 * Adds the exception list.
	 *
	 * @param exception the exception
	 */
	public void addExceptionList(Exception exception) {
		this.exceptionList.add(exception);
	}

	/**
	 * Gets the request object.
	 *
	 * @return the requestObject
	 */
	public Class<?> getRequestObject() {
		return requestObject;
	}

	/**
	 * Sets the request object.
	 *
	 * @param requestObject the requestObject to set
	 */
	public void setRequestObject(Class<?> requestObject) {
		this.requestObject = requestObject;
	}

	/**
	 * Gets the response object.
	 *
	 * @return the responseObject
	 */
	public Class<?> getResponseObject() {
		return responseObject;
	}

	/**
	 * Sets the response object.
	 *
	 * @param responseObject the responseObject to set
	 */
	public void setResponseObject(Class<?> responseObject) {
		this.responseObject = responseObject;
	}

	/**
	 * Gets the key response.
	 *
	 * @return the keyResponse
	 */
	public Map<String, Object> getKeyResponse() {
		return keyResponse;
	}

	/**
	 * Sets the key response.
	 *
	 * @param key the key
	 * @param value the value
	 */
	public void setKeyResponse(String key, Object value) {
		this.keyResponse.put(key, value);
	}

}
