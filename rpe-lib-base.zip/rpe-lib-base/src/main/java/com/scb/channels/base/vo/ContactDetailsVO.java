package com.scb.channels.base.vo;

import java.io.Serializable;

public class ContactDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6605236947678685069L;
	
	private String contactLanguageIndicator;
    private String contactLanguageCode;
    private String contactTelephoneNumber;
    private String contactType;
    private String contactTypeDescription;
    private String contactTypeClassification;
    private String contactEMailAddress;
    private String primaryContactFlag;
    private String attentionParty;
    private String contactSequenceNumber;
	
    
    public String getContactLanguageIndicator() {
		return contactLanguageIndicator;
	}
	public void setContactLanguageIndicator(String contactLanguageIndicator) {
		this.contactLanguageIndicator = contactLanguageIndicator;
	}
	public String getContactLanguageCode() {
		return contactLanguageCode;
	}
	public void setContactLanguageCode(String contactLanguageCode) {
		this.contactLanguageCode = contactLanguageCode;
	}
	public String getContactTelephoneNumber() {
		return contactTelephoneNumber;
	}
	public void setContactTelephoneNumber(String contactTelephoneNumber) {
		this.contactTelephoneNumber = contactTelephoneNumber;
	}
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	public String getContactTypeDescription() {
		return contactTypeDescription;
	}
	public void setContactTypeDescription(String contactTypeDescription) {
		this.contactTypeDescription = contactTypeDescription;
	}
	public String getContactTypeClassification() {
		return contactTypeClassification;
	}
	public void setContactTypeClassification(String contactTypeClassification) {
		this.contactTypeClassification = contactTypeClassification;
	}
	public String getContactEMailAddress() {
		return contactEMailAddress;
	}
	public void setContactEMailAddress(String contactEMailAddress) {
		this.contactEMailAddress = contactEMailAddress;
	}
	public String getPrimaryContactFlag() {
		return primaryContactFlag;
	}
	public void setPrimaryContactFlag(String primaryContactFlag) {
		this.primaryContactFlag = primaryContactFlag;
	}
	public String getAttentionParty() {
		return attentionParty;
	}
	public void setAttentionParty(String attentionParty) {
		this.attentionParty = attentionParty;
	}
	public String getContactSequenceNumber() {
		return contactSequenceNumber;
	}
	public void setContactSequenceNumber(String contactSequenceNumber) {
		this.contactSequenceNumber = contactSequenceNumber;
	}

}
