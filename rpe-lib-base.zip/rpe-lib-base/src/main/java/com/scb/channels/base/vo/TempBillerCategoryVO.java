package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.scb.channels.base.helper.CommonConstants;

/**
 * @author 1460693
 * 
 * <p> temporary BillerCatgegory VO file 
 *
 */
public class TempBillerCategoryVO implements Serializable,Cloneable {

	 
	
	private Integer tempCategoryId;
	private String categoryId=" ";
	private String categoryName=" ";	
	private String statusCode=" ";
	private String countryCode=" " ;	
	/** createdBy  * */
	private String createdBy=CommonConstants.SYSTEM;
	
	/** updBy  * */
	private String updatedBy=CommonConstants.SYSTEM;
 	
	/** dateCreated  * */
	private Timestamp dateCreated=new Timestamp(System.currentTimeMillis());
	
	/** dateUpdated  * */
	private Timestamp dateUpdated=new Timestamp(System.currentTimeMillis());


	
	private String channel =CommonConstants.IBANK;
	private int version=1;
	
	/** private BillerVO billerVO;*/

	public  Set<TempBillerVO> billers =new HashSet<TempBillerVO>(0) ;
		
	 
	 
	public Set<TempBillerVO> getBillers() {
		return billers;
	}
	public void setBillers(Set<TempBillerVO> billers) {
		this.billers = billers;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	 
	
	 
 
	public Integer getTempCategoryId() {
		return tempCategoryId;
	}
	public void setTempCategoryId(Integer tempCategoryId) {
		this.tempCategoryId = tempCategoryId;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
 
	 	
	public Timestamp getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Timestamp dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Timestamp getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(Timestamp dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	
	@Override
	public Object clone(){  
	    try{  
	        return super.clone();  
	    }catch(Exception e){ 
	        return null; 
	    }
	}	

}
