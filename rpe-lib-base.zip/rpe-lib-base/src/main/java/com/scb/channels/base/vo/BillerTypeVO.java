package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class BillerTypeVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 540747127491259210L;
	
	private Integer id;
	
	private String billerTypeCd;
	private String billerTypeDesc;	
	private String statusCd;
	private String ctryCd;	
	private String createdBy;
	private String updBy;
	
	private Date dtCreated;
	private Date dtUpd;
	
	private String channel ;
	private int version;
	
	/** private BillerVO billerVO;*/

	private Set<BillerVO> billers = 	new HashSet<BillerVO>(0);
		
	
	public Set<BillerVO> getBillers() {
		return billers;
	}
	public void setBillers(Set<BillerVO> billers) {
		this.billers = billers;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getBillerTypeCd() {
		return billerTypeCd;
	}
	public void setBillerTypeCd(String billerTypeCd) {
		this.billerTypeCd = billerTypeCd;
	}
	public String getBillerTypeDesc() {
		return billerTypeDesc;
	}
	public void setBillerTypeDesc(String billerTypeDesc) {
		this.billerTypeDesc = billerTypeDesc;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	public String getCtryCd() {
		return ctryCd;
	}
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdBy() {
		return updBy;
	}
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	public Date getDtUpd() {
		return dtUpd;
	}
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	/*public BillerVO getBillerVO() {
		return billerVO;
	}
	public void setBillerVO(BillerVO billerVO) {
		this.billerVO = billerVO;
	}*/
	
	

}
