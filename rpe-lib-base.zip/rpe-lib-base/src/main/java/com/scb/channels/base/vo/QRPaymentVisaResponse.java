package com.scb.channels.base.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentVisaResponse {
	
	private String transactionIdentifier;
	private String actionCode;
	private String approvalCode;
	private String responseCode;
	private String transmissionDateTime;
	private String retrievalReferenceNumber;
	private String merchantCategoryCode;
	private QRPaymentVisaCardAcceptor cardAcceptor;
	private String merchantVerificationValue;
	private String errorMessage;
	private QRPaymentVisaErrorStatus responseStatus;
	private String statusIdentifier;
	private QRPaymentVisaPurchaseIdentifier purchaseIdentifier;
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}
	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getApprovalCode() {
		return approvalCode;
	}
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getTransmissionDateTime() {
		return transmissionDateTime;
	}
	public void setTransmissionDateTime(String transmissionDateTime) {
		this.transmissionDateTime = transmissionDateTime;
	}
	public String getRetrievalReferenceNumber() {
		return retrievalReferenceNumber;
	}
	public void setRetrievalReferenceNumber(String retrievalReferenceNumber) {
		this.retrievalReferenceNumber = retrievalReferenceNumber;
	}
	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}
	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}
	public QRPaymentVisaCardAcceptor getCardAcceptor() {
		return cardAcceptor;
	}
	public void setCardAcceptor(QRPaymentVisaCardAcceptor cardAcceptor) {
		this.cardAcceptor = cardAcceptor;
	}
	public String getMerchantVerificationValue() {
		return merchantVerificationValue;
	}
	public void setMerchantVerificationValue(String merchantVerificationValue) {
		this.merchantVerificationValue = merchantVerificationValue;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public QRPaymentVisaErrorStatus getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(QRPaymentVisaErrorStatus responseStatus) {
		this.responseStatus = responseStatus;
	}
	public String getStatusIdentifier() {
		return statusIdentifier;
	}
	public void setStatusIdentifier(String statusIdentifier) {
		this.statusIdentifier = statusIdentifier;
	}
	public QRPaymentVisaPurchaseIdentifier getPurchaseIdentifier() {
		return purchaseIdentifier;
	}
	public void setPurchaseIdentifier(
			QRPaymentVisaPurchaseIdentifier purchaseIdentifier) {
		this.purchaseIdentifier = purchaseIdentifier;
	}
	@Override
	public String toString() {
		return "QRPaymentVisaResponse [transactionIdentifier="
				+ transactionIdentifier + ", actionCode=" + actionCode
				+ ", approvalCode=" + approvalCode + ", responseCode="
				+ responseCode + ", transmissionDateTime="
				+ transmissionDateTime + ", retrievalReferenceNumber="
				+ retrievalReferenceNumber + ", merchantCategoryCode="
				+ merchantCategoryCode + ", cardAcceptor=" + cardAcceptor
				+ ", merchantVerificationValue=" + merchantVerificationValue
				+ ", errorMessage=" + errorMessage + ", responseStatus="
				+ responseStatus + ", statusIdentifier=" + statusIdentifier
				+ ", purchaseIdentifier=" + purchaseIdentifier + "]";
	}
	
}
