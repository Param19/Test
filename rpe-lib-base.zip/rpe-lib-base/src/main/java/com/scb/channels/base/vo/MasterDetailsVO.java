package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class MasterDetailsVO.
 */
public class MasterDetailsVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2539195184914012795L;
	
	/** The customer master number. */
	private String customerMasterNumber;
    
    /** The primary relationship indicator. */
    private String primaryRelationshipIndicator;
  /*  private String customerTypeCode;
    private String customerShortName;
    private Calendar customerMasterOpenDate;
    private Calendar customerMasterCloseDate;
    private String customerAccountType;*/
    /** The operating instructions. */
  private String operatingInstructions;
    /*private String institutionClassificationCode;
    private String scbGroupCode;
    private String groupCategoryCode;
    private String masterCostCentreIndicator;
    private String uniqueAffiliatedCode;
    private String customerBusinessClassificationCode;
    private String customerSCIReferenceNumber;
    private String customerBorrowingTypeCode;
    private String centralBankCustomerClassificationCode;
    private String expatOwnershipIndicator;
    private String internalMasterReferenceCode;
    private String customerInterestSharePercentage;
    private String uniqueMasterReferenceNumber;
    private Calendar customerLastContactedDate;
    private Calendar limitExpiryDate;
    private Calendar limitLoadIntructionExpiryDate;
    private Calendar customerAccountLimitReviewDate;
    private Calendar customerAccountLimitExtendedReviewDate;
    private String masterSetupStatusFlag;
    
    //country
    private String customerResidenceCountryCode;
    private String countryOfOrigin;
    private String residentStatus;*/
    
    //Segment
    /** The customer segment category code. */
    private String customerSegmentCategoryCode;
    
    /** The customer segment code. */
    private String customerSegmentCode;
    
    //CreditDetails
    /*private String customerCreditRiskGradeIndicator;
    private String centralBankCreditGradeCode;
    private Calendar customerCreditRiskGradeEffectiveDate;
    private String creditRiskGradeSubstandardCode;
    
    //TaxDetails
    private String vatRegistrationFlag;
    private String vatRegistrationNumber;
    private String taxRegistrationFlag;
    private String taxRegistrationNumber;
    
    //Relationship2
    private String customerRelationshipManagerID;
    private String customerRelationshipManagerName;
    
    //Branch
    private String customerBranchCode;
    private String customerBranchName;
	*/
    
    private List<MasterRelationshipDetailsVO> masterRelationshipDetails;
    
    /**
     * Gets the customer master number.
     *
     * @return the customer master number
     */
    public String getCustomerMasterNumber() {
		return customerMasterNumber;
	}
	
	/**
	 * Sets the customer master number.
	 *
	 * @param customerMasterNumber the new customer master number
	 */
	public void setCustomerMasterNumber(String customerMasterNumber) {
		this.customerMasterNumber = customerMasterNumber;
	}
	
	/**
	 * Gets the primary relationship indicator.
	 *
	 * @return the primary relationship indicator
	 */
	public String getPrimaryRelationshipIndicator() {
		return primaryRelationshipIndicator;
	}
	
	/**
	 * Sets the primary relationship indicator.
	 *
	 * @param primaryRelationshipIndicator the new primary relationship indicator
	 */
	public void setPrimaryRelationshipIndicator(String primaryRelationshipIndicator) {
		this.primaryRelationshipIndicator = primaryRelationshipIndicator;
	}
	/*public String getCustomerTypeCode() {
		return customerTypeCode;
	}
	public void setCustomerTypeCode(String customerTypeCode) {
		this.customerTypeCode = customerTypeCode;
	}
	public String getCustomerShortName() {
		return customerShortName;
	}
	public void setCustomerShortName(String customerShortName) {
		this.customerShortName = customerShortName;
	}
	public Calendar getCustomerMasterOpenDate() {
		return customerMasterOpenDate;
	}
	public void setCustomerMasterOpenDate(Calendar customerMasterOpenDate) {
		this.customerMasterOpenDate = customerMasterOpenDate;
	}
	public Calendar getCustomerMasterCloseDate() {
		return customerMasterCloseDate;
	}
	public void setCustomerMasterCloseDate(Calendar customerMasterCloseDate) {
		this.customerMasterCloseDate = customerMasterCloseDate;
	}
	public String getCustomerAccountType() {
		return customerAccountType;
	}
	public void setCustomerAccountType(String customerAccountType) {
		this.customerAccountType = customerAccountType;
	}*/
	/**
	 * Gets the operating instructions.
	 *
	 * @return the operating instructions
	 */
	public String getOperatingInstructions() {
		return operatingInstructions;
	}
	
	/**
	 * Sets the operating instructions.
	 *
	 * @param operatingInstructions the new operating instructions
	 */
	public void setOperatingInstructions(String operatingInstructions) {
		this.operatingInstructions = operatingInstructions;
	}
	/*public String getInstitutionClassificationCode() {
		return institutionClassificationCode;
	}
	public void setInstitutionClassificationCode(
			String institutionClassificationCode) {
		this.institutionClassificationCode = institutionClassificationCode;
	}
	public String getScbGroupCode() {
		return scbGroupCode;
	}
	public void setScbGroupCode(String scbGroupCode) {
		this.scbGroupCode = scbGroupCode;
	}
	public String getGroupCategoryCode() {
		return groupCategoryCode;
	}
	public void setGroupCategoryCode(String groupCategoryCode) {
		this.groupCategoryCode = groupCategoryCode;
	}
	public String getMasterCostCentreIndicator() {
		return masterCostCentreIndicator;
	}
	public void setMasterCostCentreIndicator(String masterCostCentreIndicator) {
		this.masterCostCentreIndicator = masterCostCentreIndicator;
	}
	public String getUniqueAffiliatedCode() {
		return uniqueAffiliatedCode;
	}
	public void setUniqueAffiliatedCode(String uniqueAffiliatedCode) {
		this.uniqueAffiliatedCode = uniqueAffiliatedCode;
	}
	public String getCustomerBusinessClassificationCode() {
		return customerBusinessClassificationCode;
	}
	public void setCustomerBusinessClassificationCode(
			String customerBusinessClassificationCode) {
		this.customerBusinessClassificationCode = customerBusinessClassificationCode;
	}
	public String getCustomerSCIReferenceNumber() {
		return customerSCIReferenceNumber;
	}
	public void setCustomerSCIReferenceNumber(String customerSCIReferenceNumber) {
		this.customerSCIReferenceNumber = customerSCIReferenceNumber;
	}
	public String getCustomerBorrowingTypeCode() {
		return customerBorrowingTypeCode;
	}
	public void setCustomerBorrowingTypeCode(String customerBorrowingTypeCode) {
		this.customerBorrowingTypeCode = customerBorrowingTypeCode;
	}
	public String getCentralBankCustomerClassificationCode() {
		return centralBankCustomerClassificationCode;
	}
	public void setCentralBankCustomerClassificationCode(
			String centralBankCustomerClassificationCode) {
		this.centralBankCustomerClassificationCode = centralBankCustomerClassificationCode;
	}
	public String getExpatOwnershipIndicator() {
		return expatOwnershipIndicator;
	}
	public void setExpatOwnershipIndicator(String expatOwnershipIndicator) {
		this.expatOwnershipIndicator = expatOwnershipIndicator;
	}
	public String getInternalMasterReferenceCode() {
		return internalMasterReferenceCode;
	}
	public void setInternalMasterReferenceCode(String internalMasterReferenceCode) {
		this.internalMasterReferenceCode = internalMasterReferenceCode;
	}
	public String getCustomerInterestSharePercentage() {
		return customerInterestSharePercentage;
	}
	public void setCustomerInterestSharePercentage(
			String customerInterestSharePercentage) {
		this.customerInterestSharePercentage = customerInterestSharePercentage;
	}
	public String getUniqueMasterReferenceNumber() {
		return uniqueMasterReferenceNumber;
	}
	public void setUniqueMasterReferenceNumber(String uniqueMasterReferenceNumber) {
		this.uniqueMasterReferenceNumber = uniqueMasterReferenceNumber;
	}
	public Calendar getCustomerLastContactedDate() {
		return customerLastContactedDate;
	}
	public void setCustomerLastContactedDate(Calendar customerLastContactedDate) {
		this.customerLastContactedDate = customerLastContactedDate;
	}
	public Calendar getLimitExpiryDate() {
		return limitExpiryDate;
	}
	public void setLimitExpiryDate(Calendar limitExpiryDate) {
		this.limitExpiryDate = limitExpiryDate;
	}
	public Calendar getLimitLoadIntructionExpiryDate() {
		return limitLoadIntructionExpiryDate;
	}
	public void setLimitLoadIntructionExpiryDate(
			Calendar limitLoadIntructionExpiryDate) {
		this.limitLoadIntructionExpiryDate = limitLoadIntructionExpiryDate;
	}
	public Calendar getCustomerAccountLimitReviewDate() {
		return customerAccountLimitReviewDate;
	}
	public void setCustomerAccountLimitReviewDate(
			Calendar customerAccountLimitReviewDate) {
		this.customerAccountLimitReviewDate = customerAccountLimitReviewDate;
	}
	public Calendar getCustomerAccountLimitExtendedReviewDate() {
		return customerAccountLimitExtendedReviewDate;
	}
	public void setCustomerAccountLimitExtendedReviewDate(
			Calendar customerAccountLimitExtendedReviewDate) {
		this.customerAccountLimitExtendedReviewDate = customerAccountLimitExtendedReviewDate;
	}
	public String getMasterSetupStatusFlag() {
		return masterSetupStatusFlag;
	}
	public void setMasterSetupStatusFlag(String masterSetupStatusFlag) {
		this.masterSetupStatusFlag = masterSetupStatusFlag;
	}
	public String getCustomerResidenceCountryCode() {
		return customerResidenceCountryCode;
	}
	public void setCustomerResidenceCountryCode(String customerResidenceCountryCode) {
		this.customerResidenceCountryCode = customerResidenceCountryCode;
	}
	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}
	public String getResidentStatus() {
		return residentStatus;
	}
	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}*/
	/**
	 * Gets the customer segment category code.
	 *
	 * @return the customer segment category code
	 */
	public String getCustomerSegmentCategoryCode() {
		return customerSegmentCategoryCode;
	}
	
	/**
	 * Sets the customer segment category code.
	 *
	 * @param customerSegmentCategoryCode the new customer segment category code
	 */
	public void setCustomerSegmentCategoryCode(String customerSegmentCategoryCode) {
		this.customerSegmentCategoryCode = customerSegmentCategoryCode;
	}
	
	/**
	 * Gets the customer segment code.
	 *
	 * @return the customer segment code
	 */
	public String getCustomerSegmentCode() {
		return customerSegmentCode;
	}
	
	/**
	 * Sets the customer segment code.
	 *
	 * @param customerSegmentCode the new customer segment code
	 */
	public void setCustomerSegmentCode(String customerSegmentCode) {
		this.customerSegmentCode = customerSegmentCode;
	}
	/*public String getCustomerCreditRiskGradeIndicator() {
		return customerCreditRiskGradeIndicator;
	}
	public void setCustomerCreditRiskGradeIndicator(
			String customerCreditRiskGradeIndicator) {
		this.customerCreditRiskGradeIndicator = customerCreditRiskGradeIndicator;
	}
	public String getCentralBankCreditGradeCode() {
		return centralBankCreditGradeCode;
	}
	public void setCentralBankCreditGradeCode(String centralBankCreditGradeCode) {
		this.centralBankCreditGradeCode = centralBankCreditGradeCode;
	}
	public Calendar getCustomerCreditRiskGradeEffectiveDate() {
		return customerCreditRiskGradeEffectiveDate;
	}
	public void setCustomerCreditRiskGradeEffectiveDate(
			Calendar customerCreditRiskGradeEffectiveDate) {
		this.customerCreditRiskGradeEffectiveDate = customerCreditRiskGradeEffectiveDate;
	}
	public String getCreditRiskGradeSubstandardCode() {
		return creditRiskGradeSubstandardCode;
	}
	public void setCreditRiskGradeSubstandardCode(
			String creditRiskGradeSubstandardCode) {
		this.creditRiskGradeSubstandardCode = creditRiskGradeSubstandardCode;
	}
	public String getVatRegistrationFlag() {
		return vatRegistrationFlag;
	}
	public void setVatRegistrationFlag(String vatRegistrationFlag) {
		this.vatRegistrationFlag = vatRegistrationFlag;
	}
	public String getVatRegistrationNumber() {
		return vatRegistrationNumber;
	}
	public void setVatRegistrationNumber(String vatRegistrationNumber) {
		this.vatRegistrationNumber = vatRegistrationNumber;
	}
	public String getTaxRegistrationFlag() {
		return taxRegistrationFlag;
	}
	public void setTaxRegistrationFlag(String taxRegistrationFlag) {
		this.taxRegistrationFlag = taxRegistrationFlag;
	}
	public String getTaxRegistrationNumber() {
		return taxRegistrationNumber;
	}
	public void setTaxRegistrationNumber(String taxRegistrationNumber) {
		this.taxRegistrationNumber = taxRegistrationNumber;
	}
	public String getCustomerRelationshipManagerID() {
		return customerRelationshipManagerID;
	}
	public void setCustomerRelationshipManagerID(
			String customerRelationshipManagerID) {
		this.customerRelationshipManagerID = customerRelationshipManagerID;
	}
	public String getCustomerRelationshipManagerName() {
		return customerRelationshipManagerName;
	}
	public void setCustomerRelationshipManagerName(
			String customerRelationshipManagerName) {
		this.customerRelationshipManagerName = customerRelationshipManagerName;
	}
	public String getCustomerBranchCode() {
		return customerBranchCode;
	}
	public void setCustomerBranchCode(String customerBranchCode) {
		this.customerBranchCode = customerBranchCode;
	}
	public String getCustomerBranchName() {
		return customerBranchName;
	}
	public void setCustomerBranchName(String customerBranchName) {
		this.customerBranchName = customerBranchName;
	}
*/

	/**
	 * @return the masterRelationshipDetails
	 */
	public List<MasterRelationshipDetailsVO> getMasterRelationshipDetails() {
		return masterRelationshipDetails;
	}

	/**
	 * @param masterRelationshipDetails the masterRelationshipDetails to set
	 */
	public void setMasterRelationshipDetails(
			List<MasterRelationshipDetailsVO> masterRelationshipDetails) {
		this.masterRelationshipDetails = masterRelationshipDetails;
	}
}
