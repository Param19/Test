package com.scb.channels.base.vo;

import java.io.Serializable;

public class SubsidiaryAccountMasterRelationshipVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2796275813980507369L;
	
	 	private String holderRelationshipNumber;
	 	private String primaryRelationshipFlag;
	 	private String relationshipHolderFullName;
	 	private String relationshipHolderProfessionCode;
	 	private String relationshipHolderCountryCode;
	 	private String relationshipHolderCompanyConstitutionCode;
		
	 	
	 	public String getHolderRelationshipNumber() {
			return holderRelationshipNumber;
		}
		public void setHolderRelationshipNumber(String holderRelationshipNumber) {
			this.holderRelationshipNumber = holderRelationshipNumber;
		}
		public String getPrimaryRelationshipFlag() {
			return primaryRelationshipFlag;
		}
		public void setPrimaryRelationshipFlag(String primaryRelationshipFlag) {
			this.primaryRelationshipFlag = primaryRelationshipFlag;
		}
		public String getRelationshipHolderFullName() {
			return relationshipHolderFullName;
		}
		public void setRelationshipHolderFullName(String relationshipHolderFullName) {
			this.relationshipHolderFullName = relationshipHolderFullName;
		}
		public String getRelationshipHolderProfessionCode() {
			return relationshipHolderProfessionCode;
		}
		public void setRelationshipHolderProfessionCode(
				String relationshipHolderProfessionCode) {
			this.relationshipHolderProfessionCode = relationshipHolderProfessionCode;
		}
		public String getRelationshipHolderCountryCode() {
			return relationshipHolderCountryCode;
		}
		public void setRelationshipHolderCountryCode(
				String relationshipHolderCountryCode) {
			this.relationshipHolderCountryCode = relationshipHolderCountryCode;
		}
		public String getRelationshipHolderCompanyConstitutionCode() {
			return relationshipHolderCompanyConstitutionCode;
		}
		public void setRelationshipHolderCompanyConstitutionCode(
				String relationshipHolderCompanyConstitutionCode) {
			this.relationshipHolderCompanyConstitutionCode = relationshipHolderCompanyConstitutionCode;
		}

}
