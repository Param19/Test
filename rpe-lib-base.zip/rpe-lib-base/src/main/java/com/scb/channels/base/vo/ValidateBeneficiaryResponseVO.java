/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ValidateBeneficiaryResponseVO.
 *
 * @author 1411807
 */
public class ValidateBeneficiaryResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5561524356922424417L;


}
