/**
 * 
 */
package com.scb.channels.base.vo;

import java.math.BigInteger;


/**
 * @author 1411807
 *
 */
public class OnlinePinChangeRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1054048227139719592L;
	
	private BigInteger encrypted;

	public BigInteger getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(BigInteger encrypted) {
		this.encrypted = encrypted;
	}
	
}
