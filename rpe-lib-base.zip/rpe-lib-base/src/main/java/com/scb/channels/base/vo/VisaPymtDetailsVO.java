package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;


public class VisaPymtDetailsVO extends VMPaymentDetailsVO implements Serializable{
	
	private static final long serialVersionUID = -2545195184914012795L;
	private Long id;
	private String txnId;
	private String ibnkRefNo;
	private String senderCountryCode;
	private String senderName;
	private String senderAddress1;
	private String senderAddress2;
	private String senderCity;
	private String senderState;
	private String cardAcceptorName;
	private String cardAcceptorNameID;
	private String cardAcceptorIDCode;
	private String cardAcceptorState;
	private String cardAcceptorCity;
	private String cardAccpetorCounty;
	private String cardAcceptorPostalCode;
	private String cardAccpetorCountry;
	private String senderRefNo;
	private String transRefNo;
	private String traceAuditNo;
	private String sourceFund;
	private String businessAppID;
	private String transIdentifier;
	private String senderAcctNo;
	private String feePrgIndicator;
	private String merchantCategory;
	private String actionCode;
	private String actionCodeDesc;
	private String approvalCode;
	private String timeStamp;
	private String aquiringBin;
	private String aquirerCountryCd;
	private String sourceCoutnryCd;
	private String locationURI;
	private List<String> country;
	private List<String> county;
	private String count;
	
	public String getSenderCountryCode() {
		return senderCountryCode;
	}
	public void setSenderCountryCode(String senderCountryCode) {
		this.senderCountryCode = senderCountryCode;
	}

	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public String getSenderAddress1() {
		return senderAddress1;
	}
	public void setSenderAddress1(String senderAddress1) {
		this.senderAddress1 = senderAddress1;
	}
	public String getSenderAddress2() {
		return senderAddress2;
	}
	public void setSenderAddress2(String senderAddress2) {
		this.senderAddress2 = senderAddress2;
	}
	public String getSenderCity() {
		return senderCity;
	}
	public void setSenderCity(String senderCity) {
		this.senderCity = senderCity;
	}
	public String getSenderState() {
		return senderState;
	}
	public void setSenderState(String senderState) {
		this.senderState = senderState;
	}
	public String getCardAcceptorName() {
		return cardAcceptorName;
	}
	public void setCardAcceptorName(String cardAcceptorName) {
		this.cardAcceptorName = cardAcceptorName;
	}
	public String getCardAcceptorNameID() {
		return cardAcceptorNameID;
	}
	public void setCardAcceptorNameID(String cardAcceptorNameID) {
		this.cardAcceptorNameID = cardAcceptorNameID;
	}
	public String getCardAcceptorIDCode() {
		return cardAcceptorIDCode;
	}
	public void setCardAcceptorIDCode(String cardAcceptorIDCode) {
		this.cardAcceptorIDCode = cardAcceptorIDCode;
	}
	public String getCardAcceptorState() {
		return cardAcceptorState;
	}
	public void setCardAcceptorState(String cardAcceptorState) {
		this.cardAcceptorState = cardAcceptorState;
	}
	public String getCardAcceptorCity() {
		return cardAcceptorCity;
	}
	public void setCardAcceptorCity(String cardAcceptorCity) {
		this.cardAcceptorCity = cardAcceptorCity;
	}
	public String getCardAccpetorCounty() {
		return cardAccpetorCounty;
	}
	public void setCardAccpetorCounty(String cardAccpetorCounty) {
		this.cardAccpetorCounty = cardAccpetorCounty;
	}
	public String getCardAcceptorPostalCode() {
		return cardAcceptorPostalCode;
	}
	public void setCardAcceptorPostalCode(String cardAcceptorPostalCode) {
		this.cardAcceptorPostalCode = cardAcceptorPostalCode;
	}
	public String getCardAccpetorCountry() {
		return cardAccpetorCountry;
	}
	public void setCardAccpetorCountry(String cardAccpetorCountry) {
		this.cardAccpetorCountry = cardAccpetorCountry;
	}
	public String getSenderRefNo() {
		return senderRefNo;
	}
	public void setSenderRefNo(String senderRefNo) {
		this.senderRefNo = senderRefNo;
	}
	public String getTransRefNo() {
		return transRefNo;
	}
	public void setTransRefNo(String transRefNo) {
		this.transRefNo = transRefNo;
	}
	public String getTraceAuditNo() {
		return traceAuditNo;
	}
	public void setTraceAuditNo(String traceAuditNo) {
		this.traceAuditNo = traceAuditNo;
	}
	public String getSourceFund() {
		return sourceFund;
	}
	public void setSourceFund(String sourceFund) {
		this.sourceFund = sourceFund;
	}
	public String getBusinessAppID() {
		return businessAppID;
	}
	public void setBusinessAppID(String businessAppID) {
		this.businessAppID = businessAppID;
	}
	public String getTransIdentifier() {
		return transIdentifier;
	}
	public void setTransIdentifier(String transIdentifier) {
		this.transIdentifier = transIdentifier;
	}
	public String getSenderAcctNo() {
		return senderAcctNo;
	}
	public void setSenderAcctNo(String senderAcctNo) {
		this.senderAcctNo = senderAcctNo;
	}
	public String getFeePrgIndicator() {
		return feePrgIndicator;
	}
	public void setFeePrgIndicator(String feePrgIndicator) {
		this.feePrgIndicator = feePrgIndicator;
	}
	public String getMerchantCategory() {
		return merchantCategory;
	}
	public void setMerchantCategory(String merchantCategory) {
		this.merchantCategory = merchantCategory;
	}
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getActionCodeDesc() {
		return actionCodeDesc;
	}
	
	public void setActionCodeDesc(String actionCodeDesc) {
		this.actionCodeDesc = actionCodeDesc;
	}
	
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getAquiringBin() {
		return aquiringBin;
	}
	public void setAquiringBin(String aquiringBin) {
		this.aquiringBin = aquiringBin;
	}
	public String getAquirerCountryCd() {
		return aquirerCountryCd;
	}
	public void setAquirerCountryCd(String aquirerCountryCd) {
		this.aquirerCountryCd = aquirerCountryCd;
	}
	public String getSourceCoutnryCd() {
		return sourceCoutnryCd;
	}
	public void setSourceCoutnryCd(String sourceCoutnryCd) {
		this.sourceCoutnryCd = sourceCoutnryCd;
	}
	public String getApprovalCode() {
		return approvalCode;
	}
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
	public String getLocationURI() {
		return locationURI;
	}
	public void setLocationURI(String locationURI) {
		this.locationURI = locationURI;
	}
	public String getIbnkRefNo() {
		return ibnkRefNo;
	}
	public void setIbnkRefNo(String ibnkRefNo) {
		this.ibnkRefNo = ibnkRefNo;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public List<String> getCountry() {
		return country;
	}
	public void setCountry(List<String> country) {
		this.country = country;
	}
	public List<String> getCounty() {
		return county;
	}
	public void setCounty(List<String> county) {
		this.county = county;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}

	
}
