package com.scb.channels.base.vo;

import java.io.Serializable;

public class CreditNarrativeVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7271610651918651084L;
	
	private String creditNarrative;

	public String getCreditNarrative() {
		return creditNarrative;
	}

	public void setCreditNarrative(String creditNarrative) {
		this.creditNarrative = creditNarrative;
	}

}
