package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class AccountInquiryVO.
 */
public class AccountInquiryVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7671956151869652587L;
	
	/** The count. */
	private Integer count;
	
	/** The joebppsno. */
	private String joebppsno;
	
	/** The customer id. */
	private String customerId;
	
	/** The customer type. */
	private String  customerType;
	
	/** The nation. */
	private String nation;
	
	/** The recieve code. */
	private Integer recieveCode;
	
	/** The guid. */
	private String guid;
	
	/**
	 * Gets the recieve code.
	 *
	 * @return the recieve code
	 */
	public Integer getRecieveCode() {
		return recieveCode;
	}
	
	/**
	 * Sets the recieve code.
	 *
	 * @param recieveCode the new recieve code
	 */
	public void setRecieveCode(Integer recieveCode) {
		this.recieveCode = recieveCode;
	}
	
	/**
	 * Gets the count.
	 *
	 * @return the count
	 */
	public Integer getCount() {
		return count;
	}
	
	/**
	 * Sets the count.
	 *
	 * @param count the new count
	 */
	public void setCount(Integer count) {
		this.count = count;
	}
	
	
	
	public String getJoebppsno() {
		return joebppsno;
	}

	public void setJoebppsno(String joebppsno) {
		this.joebppsno = joebppsno;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public String getCustomerId() {
		return customerId;
	}
	
	/**
	 * Sets the customer id.
	 *
	 * @param customerId the new customer id
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	/**
	 * Gets the customer type.
	 *
	 * @return the customer type
	 */
	public String getCustomerType() {
		return customerType;
	}
	
	/**
	 * Sets the customer type.
	 *
	 * @param customerType the new customer type
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	
	/**
	 * Gets the nation.
	 *
	 * @return the nation
	 */
	public String getNation() {
		return nation;
	}
	
	/**
	 * Sets the nation.
	 *
	 * @param nation the new nation
	 */
	public void setNation(String nation) {
		this.nation = nation;
	}

	/**
	 * Gets the guid.
	 *
	 * @return the guid
	 */
	public String getGuid() {
		return guid;
	}

	/**
	 * Sets the guid.
	 *
	 * @param guid the guid to set
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}
	
	
	

}
