/**
 * 
 */
package com.scb.channels.base.vo;

import java.math.BigDecimal;
import java.util.List;

/**
 * This class contains Account Information.
 *
 * @author 1411807
 */
public class AccountVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7137299257982746185L;
	
	/** The account number. */
	private String accountNumber;
	
	/** The account number iban. */
	private String accountNumberIBAN;
	
	/** The currency. */
	private String currency;
	
	/** The amount. */
	private BigDecimal amount;
	
	/** The ctry cd. */
	private String ctryCD;
	
	/** The account type. */
	private String accountType;
	
	/** The bank info. */
	private BankInfoVO bankInfo;
	
	/** The product code. */
	private String productCode;
	
	/** The universal acc number. */
	private String universalAccNumber;
	
	/** The memo. */
	private String memo;
	
	private String operatingIns;
	
	private List<String> riskCode;
	
	/**
	 * Gets the account number.
	 *
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the account number iban.
	 *
	 * @return the accountNumberIBAN
	 */
	public String getAccountNumberIBAN() {
		return accountNumberIBAN;
	}

	/**
	 * Sets the account number iban.
	 *
	 * @param accountNumberIBAN the accountNumberIBAN to set
	 */
	public void setAccountNumberIBAN(String accountNumberIBAN) {
		this.accountNumberIBAN = accountNumberIBAN;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * Gets the account type.
	 *
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * Sets the account type.
	 *
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * Gets the bank info.
	 *
	 * @return the bankInfo
	 */
	public BankInfoVO getBankInfo() {
		return bankInfo;
	}

	/**
	 * Sets the bank info.
	 *
	 * @param bankInfo the bankInfo to set
	 */
	public void setBankInfo(BankInfoVO bankInfo) {
		this.bankInfo = bankInfo;
	}
	

	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctryCD
	 */
	public String getCtryCD() {
		return ctryCD;
	}

	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCD the ctryCD to set
	 */
	public void setCtryCD(String ctryCD) {
		this.ctryCD = ctryCD;
	}

	/**
	 * Gets the product code.
	 *
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * Sets the product code.
	 *
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * Gets the universal acc number.
	 *
	 * @return the universalAccNumber
	 */
	public String getUniversalAccNumber() {
		return universalAccNumber;
	}

	/**
	 * Sets the universal acc number.
	 *
	 * @param universalAccNumber the universalAccNumber to set
	 */
	public void setUniversalAccNumber(String universalAccNumber) {
		this.universalAccNumber = universalAccNumber;
	}

	/**
	 * Gets the memo.
	 *
	 * @return the memo
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * Sets the memo.
	 *
	 * @param memo the memo to set
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getOperatingIns() {
		return operatingIns;
	}

	public void setOperatingIns(String operatingIns) {
		this.operatingIns = operatingIns;
	}

	/**
	 * @return the riskCode
	 */
	public List<String> getRiskCode() {
		return riskCode;
	}

	/**
	 * @param riskCode the riskCode to set
	 */
	public void setRiskCode(List<String> riskCode) {
		this.riskCode = riskCode;
	}
	

}
