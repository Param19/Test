/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class ProductListResponseVO.
 *
 * @author 1411807
 */
public class ProductListResponseVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6246550538572640843L;


}
