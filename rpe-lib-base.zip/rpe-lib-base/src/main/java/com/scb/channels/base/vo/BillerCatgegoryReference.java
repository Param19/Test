package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Date;

public class BillerCatgegoryReference implements Serializable {

	 
	
	/** serialVersionUID   **/
	private static final long serialVersionUID = 2610043878795934026L;

	private Integer refId;
	private String categoryId;
	private String categoryName;	
	private String statusCode;
	private String countryCode;	
	private String paymentTransactionCode;
	private String paymentTransactionType;
	private String remarks;
	private String  fetchType;
	private String lastUpdatedBy;
	private Date dateCreated;
	private Date dateUpdated;
	private String cardUtilityCode; // added for CR659
	private String corebankingCardTranType; // added for CR659
	private String corebankingCardUtilityCode; // added for CR659
 	
	 
	public Integer getRefId() {
		return refId;
	}
	public void setRefId(Integer refId) {
		this.refId = refId;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPaymentTransactionCode() {
		return paymentTransactionCode;
	}
	public void setPaymentTransactionCode(String paymentTransactionCode) {
		this.paymentTransactionCode = paymentTransactionCode;
	}
	public String getPaymentTransactionType() {
		return paymentTransactionType;
	}
	public void setPaymentTransactionType(String paymentTransactionType) {
		this.paymentTransactionType = paymentTransactionType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	public String getFetchType() {
		return fetchType;
	}
	public void setFetchType(String fetchType) {
		this.fetchType = fetchType;
	}
	public String getCardUtilityCode() {
		return cardUtilityCode;
	}
	public void setCardUtilityCode(String cardUtilityCode) {
		this.cardUtilityCode = cardUtilityCode;
	}
	public String getCorebankingCardTranType() {
		return corebankingCardTranType;
	}
	public void setCorebankingCardTranType(String corebankingCardTranType) {
		this.corebankingCardTranType = corebankingCardTranType;
	}
	public String getCorebankingCardUtilityCode() {
		return corebankingCardUtilityCode;
	}
	public void setCorebankingCardUtilityCode(String corebankingCardUtilityCode) {
		this.corebankingCardUtilityCode = corebankingCardUtilityCode;
	}
	/*@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillerCatgegoryReference [refId=");
		builder.append(refId);
		builder.append(", categoryId=");
		builder.append(categoryId);
		builder.append(", categoryName=");
		builder.append(categoryName);
		builder.append(", statusCode=");
		builder.append(statusCode);
		builder.append(", countryCode=");
		builder.append(countryCode);
		builder.append(", paymentTransactionCode=");
		builder.append(paymentTransactionCode);
		builder.append(", paymentTransactionType=");
		builder.append(paymentTransactionType);
		builder.append(", remarks=");
		builder.append(remarks);
		builder.append(", fetchType=");
		builder.append(fetchType);
		builder.append(", lastUpdatedBy=");
		builder.append(lastUpdatedBy);
		builder.append(", dateCreated=");
		builder.append(dateCreated);
		builder.append(", dateUpdated=");
		builder.append(dateUpdated);
		builder.append(", cardUtilityCode=");
		builder.append(cardUtilityCode);
		builder.append(", corebankingCardTranType=");
		builder.append(corebankingCardTranType);
		builder.append(", corebankingCardUtilityCode=");
		builder.append(corebankingCardUtilityCode);
		builder.append("]");
		return builder.toString();
	}*/
}
