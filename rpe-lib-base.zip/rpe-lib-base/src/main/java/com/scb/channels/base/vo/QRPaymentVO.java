package com.scb.channels.base.vo;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class QRPaymentVO.
 */
public class QRPaymentVO {

	/** The qrpayment_id. */
	private Long qrpayment_id;
	
	/** The merchant_seq_id. */
	private Long merchant_seq_id;
	
	/** The country_code. */
	private String country_code;
	
	/** The customer_id. */
	private String customer_id;
	
	/** The customer_type. */
	private String customer_type;
	
	/** The card_number. */
	private String card_number;
	
	/** The client_reference. */
	private String client_reference;
	
	/** The host_reference. */
	private String host_reference;
	
	/** The system_trace_audit_number. */
	private String system_trace_audit_number;
	
	/** The txn_currency_code. */
	private String txn_currency_code;
	
	/** The payment_amount. */
	private BigDecimal payment_amount;
	
	/** The fee_amount. */
	private BigDecimal fee_amount;
	
	/** The total_amount. */
	private BigDecimal total_amount;
	
	/** The payment_date. */
	private Timestamp payment_date;
	
	/** The payment_type. */
	private String payment_type;
	
	/** The payment_status. */
	private String payment_status;
	
	/** The payment_narrartion. */
	//private String payment_narrartion;
	
	/** The payment_orginate_country. */
	private String payment_orginate_country;
	
	/** The payment_remark. */
	//private String payment_remark;
	
	/** The host_system. */
	//private String host_system;
	
	/** The host_status_cd. */
	private String host_status_cd;
	
	/** The host_status_desc. */
	private String host_status_desc;
	
	/** The host_reason_code. */
	//private String host_reason_code;
	
	/** The created_by. */
	private String created_by;
	
	/** The updated_by. */
	private String updated_by;
	
	/** The updated_timestamp. */
	private Timestamp updated_timestamp;
	
	/** The host_ txn_ identifier. */
	//private String host_Txn_Identifier;
	
	/** The txn act status. */
	private String txnActStatus;
	
	/** The txn status cd. */
	private String txnStatusCd;
	
	/** The card_type. */
	private String card_type;
	
	private Integer version;
	
	private String jvmName;
	
	private String auth_code;
	
	private String networkReferenceNo;
	
	private String transactionIdentifier;
	
	private String statusIdentifier;
	
	private String agg_stan;
	
	private String merchant_city;
	
	private String merchant_name;
	
	private String merchant_category_code;
	
	private String merchant_postcode;
	
	private String merchant_pan;
	
	private List<QRMerchantPanTypeVO> merchantPanList = new ArrayList<QRMerchantPanTypeVO>();
	
	private String cardExpiryDate;

	/** The Transaction Currency. */
	private String transactionCurrency;
	
	/** The Acquire Country Code. */
	private String acquireCountryCode;
	
	/** The Debit Account Currency. */
	private String debitAccCurrency;
	
	/** The Debit Amount. */
	private BigDecimal debitAmount;
	
	/** The Debit Amount Fx Rate. */
	private BigDecimal debitAmtFxRate;
	
	/** The Settlement Currency. */
	private String settlementCurrency;
	
	/** The Settlement Amount. */
	private BigDecimal settlementAmount;
	
	/** The Settlement Amount Fx Rate. */
	private BigDecimal settlementAmtFxRate;
	
	/**
	 * Gets the qrpayment_id.
	 *
	 * @return the qrpayment_id
	 */
	public Long getQrpayment_id() {
		return qrpayment_id;
	}
	
	/**
	 * Sets the qrpayment_id.
	 *
	 * @param qrpayment_id the new qrpayment_id
	 */
	public void setQrpayment_id(Long qrpayment_id) {
		this.qrpayment_id = qrpayment_id;
	}
	
	/**
	 * Gets the merchant_seq_id.
	 *
	 * @return the merchant_seq_id
	 */
	public Long getMerchant_seq_id() {
		return merchant_seq_id;
	}
	
	/**
	 * Sets the merchant_seq_id.
	 *
	 * @param merchant_seq_id the new merchant_seq_id
	 */
	public void setMerchant_seq_id(Long merchant_seq_id) {
		this.merchant_seq_id = merchant_seq_id;
	}
	
	/**
	 * Gets the country_code.
	 *
	 * @return the country_code
	 */
	public String getCountry_code() {
		return country_code;
	}
	
	/**
	 * Sets the country_code.
	 *
	 * @param country_code the new country_code
	 */
	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}
	
	/**
	 * Gets the customer_id.
	 *
	 * @return the customer_id
	 */
	public String getCustomer_id() {
		return customer_id;
	}
	
	/**
	 * Sets the customer_id.
	 *
	 * @param customer_id the new customer_id
	 */
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	
	/**
	 * Gets the customer_type.
	 *
	 * @return the customer_type
	 */
	public String getCustomer_type() {
		return customer_type;
	}
	
	/**
	 * Sets the customer_type.
	 *
	 * @param customer_type the new customer_type
	 */
	public void setCustomer_type(String customer_type) {
		this.customer_type = customer_type;
	}
	
	/**
	 * Gets the card_number.
	 *
	 * @return the card_number
	 */
	public String getCard_number() {
		return card_number;
	}
	
	/**
	 * Sets the card_number.
	 *
	 * @param card_number the new card_number
	 */
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	
	/**
	 * Gets the client_reference.
	 *
	 * @return the client_reference
	 */
	public String getClient_reference() {
		return client_reference;
	}
	
	/**
	 * Sets the client_reference.
	 *
	 * @param client_reference the new client_reference
	 */
	public void setClient_reference(String client_reference) {
		this.client_reference = client_reference;
	}
	
	/**
	 * Gets the host_reference.
	 *
	 * @return the host_reference
	 */
	public String getHost_reference() {
		return host_reference;
	}
	
	/**
	 * Sets the host_reference.
	 *
	 * @param host_reference the new host_reference
	 */
	public void setHost_reference(String host_reference) {
		this.host_reference = host_reference;
	}
	
	/**
	 * Gets the system_trace_audit_number.
	 *
	 * @return the system_trace_audit_number
	 */
	public String getSystem_trace_audit_number() {
		return system_trace_audit_number;
	}
	
	/**
	 * Sets the system_trace_audit_number.
	 *
	 * @param system_trace_audit_number the new system_trace_audit_number
	 */
	public void setSystem_trace_audit_number(String system_trace_audit_number) {
		this.system_trace_audit_number = system_trace_audit_number;
	}
	
	/**
	 * Gets the txn_currency_code.
	 *
	 * @return the txn_currency_code
	 */
	public String getTxn_currency_code() {
		return txn_currency_code;
	}
	
	/**
	 * Sets the txn_currency_code.
	 *
	 * @param txn_currency_code the new txn_currency_code
	 */
	public void setTxn_currency_code(String txn_currency_code) {
		this.txn_currency_code = txn_currency_code;
	}
	
	/**
	 * Gets the payment_amount.
	 *
	 * @return the payment_amount
	 */
	public BigDecimal getPayment_amount() {
		return payment_amount;
	}
	
	/**
	 * Sets the payment_amount.
	 *
	 * @param payment_amount the new payment_amount
	 */
	public void setPayment_amount(BigDecimal payment_amount) {
		this.payment_amount = payment_amount;
	}
	
	/**
	 * Gets the fee_amount.
	 *
	 * @return the fee_amount
	 */
	public BigDecimal getFee_amount() {
		return fee_amount;
	}
	
	/**
	 * Sets the fee_amount.
	 *
	 * @param fee_amount the new fee_amount
	 */
	public void setFee_amount(BigDecimal fee_amount) {
		this.fee_amount = fee_amount;
	}
	
	/**
	 * Gets the total_amount.
	 *
	 * @return the total_amount
	 */
	public BigDecimal getTotal_amount() {
		return total_amount;
	}
	
	/**
	 * Sets the total_amount.
	 *
	 * @param total_amount the new total_amount
	 */
	public void setTotal_amount(BigDecimal total_amount) {
		this.total_amount = total_amount;
	}
	
	/**
	 * Gets the payment_date.
	 *
	 * @return the payment_date
	 */
	public Timestamp getPayment_date() {
		return payment_date;
	}
	
	/**
	 * Sets the payment_date.
	 *
	 * @param payment_date the new payment_date
	 */
	public void setPayment_date(Timestamp payment_date) {
		this.payment_date = payment_date;
	}
	
	/**
	 * Gets the payment_type.
	 *
	 * @return the payment_type
	 */
	public String getPayment_type() {
		return payment_type;
	}
	
	/**
	 * Sets the payment_type.
	 *
	 * @param payment_type the new payment_type
	 */
	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}
	
	/**
	 * Gets the payment_status.
	 *
	 * @return the payment_status
	 */
	public String getPayment_status() {
		return payment_status;
	}
	
	/**
	 * Sets the payment_status.
	 *
	 * @param payment_status the new payment_status
	 */
	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}
		
	/**
	 * Gets the payment_orginate_country.
	 *
	 * @return the payment_orginate_country
	 */
	public String getPayment_orginate_country() {
		return payment_orginate_country;
	}
	
	/**
	 * Sets the payment_orginate_country.
	 *
	 * @param payment_orginate_country the new payment_orginate_country
	 */
	public void setPayment_orginate_country(String payment_orginate_country) {
		this.payment_orginate_country = payment_orginate_country;
	}
			
	/**
	 * Gets the host_status_cd.
	 *
	 * @return the host_status_cd
	 */
	public String getHost_status_cd() {
		return host_status_cd;
	}
	
	/**
	 * Sets the host_status_cd.
	 *
	 * @param host_status_cd the new host_status_cd
	 */
	public void setHost_status_cd(String host_status_cd) {
		this.host_status_cd = host_status_cd;
	}
	
	/**
	 * Gets the host_status_desc.
	 *
	 * @return the host_status_desc
	 */
	public String getHost_status_desc() {
		return host_status_desc;
	}
	
	/**
	 * Sets the host_status_desc.
	 *
	 * @param host_status_desc the new host_status_desc
	 */
	public void setHost_status_desc(String host_status_desc) {
		this.host_status_desc = host_status_desc;
	}
	
	/**
	 * Gets the created_by.
	 *
	 * @return the created_by
	 */
	public String getCreated_by() {
		return created_by;
	}
	
	/**
	 * Sets the created_by.
	 *
	 * @param created_by the new created_by
	 */
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	
	/**
	 * Gets the updated_by.
	 *
	 * @return the updated_by
	 */
	public String getUpdated_by() {
		return updated_by;
	}
	
	/**
	 * Sets the updated_by.
	 *
	 * @param updated_by the new updated_by
	 */
	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	
	/**
	 * Gets the updated_timestamp.
	 *
	 * @return the updated_timestamp
	 */
	public Timestamp getUpdated_timestamp() {
		return updated_timestamp;
	}
	
	/**
	 * Sets the updated_timestamp.
	 *
	 * @param updated_timestamp the new updated_timestamp
	 */
	public void setUpdated_timestamp(Timestamp updated_timestamp) {
		this.updated_timestamp = updated_timestamp;
	}
	/**
	 * Gets the txn act status.
	 *
	 * @return the txn act status
	 */
	public String getTxnActStatus() {
		return txnActStatus;
	}
	
	/**
	 * Sets the txn act status.
	 *
	 * @param txnActStatus the new txn act status
	 */
	public void setTxnActStatus(String txnActStatus) {
		this.txnActStatus = txnActStatus;
	}
	
	/**
	 * Gets the txn status cd.
	 *
	 * @return the txn status cd
	 */
	public String getTxnStatusCd() {
		return txnStatusCd;
	}
	
	/**
	 * Sets the txn status cd.
	 *
	 * @param txnStatusCd the new txn status cd
	 */
	public void setTxnStatusCd(String txnStatusCd) {
		this.txnStatusCd = txnStatusCd;
	}

	/**
	 * Gets the card_type.
	 *
	 * @return the card_type
	 */
	public String getCard_type() {
		return card_type;
	}

	/**
	 * Sets the card_type.
	 *
	 * @param card_type the new card_type
	 */
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}

	public String getJvmName() {
		return jvmName;
	}

	public void setJvmName(String jvmName) {
		this.jvmName = jvmName;
	}
	
	public String getAuth_code() {
		return auth_code;
	}

	public void setAuth_code(String auth_code) {
		this.auth_code = auth_code;
	}

	public String getNetworkReferenceNo() {
		return networkReferenceNo;
	}

	public void setNetworkReferenceNo(String networkReferenceNo) {
		this.networkReferenceNo = networkReferenceNo;
	}
	
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}

	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}

	
	public String getStatusIdentifier() {
		return statusIdentifier;
	}

	public void setStatusIdentifier(String statusIdentifier) {
		this.statusIdentifier = statusIdentifier;
	}

	public String getMerchant_pan() {
		return merchant_pan;
	}

	public void setMerchant_pan(String merchant_pan) {
		this.merchant_pan = merchant_pan;
	}

	public String getMerchant_city() {
		return merchant_city;
	}

	public void setMerchant_city(String merchant_city) {
		this.merchant_city = merchant_city;
	}

	public String getMerchant_name() {
		return merchant_name;
	}

	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}

	public String getMerchant_category_code() {
		return merchant_category_code;
	}

	public void setMerchant_category_code(String merchant_category_code) {
		this.merchant_category_code = merchant_category_code;
	}

	public String getMerchant_postcode() {
		return merchant_postcode;
	}

	public void setMerchant_postcode(String merchant_postcode) {
		this.merchant_postcode = merchant_postcode;
	}

	public List<QRMerchantPanTypeVO> getMerchantPanList() {
		return merchantPanList;
	}

	public void setMerchantPanList(List<QRMerchantPanTypeVO> merchantPanList) {
		this.merchantPanList = merchantPanList;
	}

	public String getAgg_stan() {
		return agg_stan;
	}

	public void setAgg_stan(String agg_stan) {
		this.agg_stan = agg_stan;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getCardExpiryDate() {
		return cardExpiryDate;
	}

	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	public String getTransactionCurrency() {
		return transactionCurrency;
	}

	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}
	
	public String getAcquireCountryCode() {
		return acquireCountryCode;
	}

	public void setAcquireCountryCode(String acquireCountryCode) {
		this.acquireCountryCode = acquireCountryCode;
	}

	public String getDebitAccCurrency() {
		return debitAccCurrency;
	}

	public void setDebitAccCurrency(String debitAccCurrency) {
		this.debitAccCurrency = debitAccCurrency;
	}

	public BigDecimal getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(BigDecimal debitAmount) {
		this.debitAmount = debitAmount;
	}

	public BigDecimal getDebitAmtFxRate() {
		return debitAmtFxRate;
	}

	public void setDebitAmtFxRate(BigDecimal debitAmtFxRate) {
		this.debitAmtFxRate = debitAmtFxRate;
	}

	public String getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public BigDecimal getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(BigDecimal settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public BigDecimal getSettlementAmtFxRate() {
		return settlementAmtFxRate;
	}

	public void setSettlementAmtFxRate(BigDecimal settlementAmtFxRate) {
		this.settlementAmtFxRate = settlementAmtFxRate;
	}

	@Override
	public String toString() {
		return "QRPaymentVO [qrpayment_id=" + qrpayment_id
				+ ", merchant_seq_id=" + merchant_seq_id + ", country_code="
				+ country_code + ", customer_id=" + customer_id
				+ ", customer_type=" + customer_type + ", card_number="
				+ card_number + ", client_reference=" + client_reference
				+ ", host_reference=" + host_reference
				+ ", system_trace_audit_number=" + system_trace_audit_number
				+ ", txn_currency_code=" + txn_currency_code
				+ ", payment_amount=" + payment_amount + ", fee_amount="
				+ fee_amount + ", total_amount=" + total_amount
				+ ", payment_date=" + payment_date + ", payment_type="
				+ payment_type + ", payment_status=" + payment_status
				+ ", payment_orginate_country=" + payment_orginate_country
				+ ", host_status_cd=" + host_status_cd + ", host_status_desc="
				+ host_status_desc + ", created_by=" + created_by
				+ ", updated_by=" + updated_by + ", updated_timestamp="
				+ updated_timestamp + ", txnActStatus=" + txnActStatus
				+ ", txnStatusCd=" + txnStatusCd + ", card_type=" + card_type
				+ ", version=" + version + ", jvmName=" + jvmName
				+ ", auth_code=" + auth_code + ", networkReferenceNo="
				+ networkReferenceNo + ", transactionIdentifier="
				+ transactionIdentifier + ", statusIdentifier="
				+ statusIdentifier + ", agg_stan=" + agg_stan
				+ ", merchant_city=" + merchant_city + ", merchant_name="
				+ merchant_name + ", merchant_category_code="
				+ merchant_category_code + ", merchant_postcode="
				+ merchant_postcode + ", merchant_pan=" + merchant_pan
				+ ", merchantPanList=" + merchantPanList + ", cardExpiryDate="
				+ cardExpiryDate + ", transactionCurrency="
				+ transactionCurrency + ", acquireCountryCode="
				+ acquireCountryCode + ", debitAccCurrency=" + debitAccCurrency
				+ ", debitAmount=" + debitAmount + ", debitAmtFxRate="
				+ debitAmtFxRate + ", settlementCurrency=" + settlementCurrency
				+ ", settlementAmount=" + settlementAmount
				+ ", settlementAmtFxRate=" + settlementAmtFxRate + "]";
	}
	
}
