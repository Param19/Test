package com.scb.channels.base.vo;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MessageContextApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	private String reqID;

	public String getReqID() {
		return reqID;
	}

	public void setReqID(String reqID) {
		this.reqID = reqID;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "MessageContextApiVO [reqID=" + reqID + "]";
	}
	
}
