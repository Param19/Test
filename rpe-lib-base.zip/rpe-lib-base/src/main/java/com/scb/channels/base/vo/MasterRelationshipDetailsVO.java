/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * @author 1411807
 *
 */
public class MasterRelationshipDetailsVO implements Serializable {

	 /**
	 * 
	 */
	private static final long serialVersionUID = 7249426877303085470L;
	
	public String operationMode;
	public String primaryRelationshipIndicator;
	public String customerIdentificationNumber;
	
	/**
	 * @return the operationMode
	 */
	public String getOperationMode() {
		return operationMode;
	}
	/**
	 * @param operationMode the operationMode to set
	 */
	public void setOperationMode(String operationMode) {
		this.operationMode = operationMode;
	}
	/**
	 * @return the primaryRelationshipIndicator
	 */
	public String getPrimaryRelationshipIndicator() {
		return primaryRelationshipIndicator;
	}
	/**
	 * @param primaryRelationshipIndicator the primaryRelationshipIndicator to set
	 */
	public void setPrimaryRelationshipIndicator(String primaryRelationshipIndicator) {
		this.primaryRelationshipIndicator = primaryRelationshipIndicator;
	}
	/**
	 * @return the customerIdentificationNumber
	 */
	public String getCustomerIdentificationNumber() {
		return customerIdentificationNumber;
	}
	/**
	 * @param customerIdentificationNumber the customerIdentificationNumber to set
	 */
	public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
		this.customerIdentificationNumber = customerIdentificationNumber;
	}
}
