package com.scb.channels.base.vo;

import java.io.Serializable;

public class QRAdditionalFieldVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7355304768095067319L;

	private String refId;
	
	private String refValue;

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getRefValue() {
		return refValue;
	}

	public void setRefValue(String refValue) {
		this.refValue = refValue;
	}

	@Override
	public String toString() {
		return "QRAdditionalFieldVO [refId=" + refId + ", refValue=" + refValue
				+ "]";
	}
	
	

}
