package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

/**
 * @author 1460693
 *
 */
 
/**
 * @author 1460693
 *
 */
public class PayeeDetailVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer payeeId;
	private String customerId;
	private String countryCode;
	private String channelId;
 	private String billerCode;
	private String billerCategoryCode;
	private String referenceNumber;
	private String payeeName;
	private String payeeShortName;
	private String status;
	private Timestamp createdTime;
	private String createdBy;
	private Timestamp  updateTime;
	private String  updatedBy;
	private Integer version;
	private Set<PaymentDetailVO>  paymentDetails;
 
	private String consumerNumber;
	
	private String consumerDetail;
	
	private BillerVO billerVO;
	 
	private BillerCategoryVO billerTypeVO;
	
	private String payeeType;
	
	/**
	 * 
	 */
	private String remarks;
	/**
	 * payeeFieldDetails
	 */
	private  Set<PayeeFieldDetailsVO> payeeFieldDetails;
	/**
	 * isUpdateRequired
	 */
	private String isUpdateRequired;
	
	/**
	 * @return the isUpdateRequired
	 */
	public String getIsUpdateRequired() {
		return isUpdateRequired;
	}
	/**
	 * @param isUpdateRequired the isUpdateRequired to set
	 */
	public void setIsUpdateRequired(String isUpdateRequired) {
		this.isUpdateRequired = isUpdateRequired;
	}
	/**
	 * @return the payeeFieldDetailsVO
	 */
	public Set<PayeeFieldDetailsVO> getPayeeFieldDetails() {
		return payeeFieldDetails;
	}
	/**
	 * @param payeeFieldDetailsVO the payeeFieldDetailsVO to set
	 */
	public void setPayeeFieldDetails(Set<PayeeFieldDetailsVO> payeeFieldDetails) {
		this.payeeFieldDetails = payeeFieldDetails;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getPayeeType() {
		return payeeType;
	}
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}
	public Set<PaymentDetailVO> getPaymentDetails() {
		return paymentDetails;
	}
	public void setPaymentDetails(Set<PaymentDetailVO> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	
	
	
	public BillerVO getBillerVO() {
		return billerVO;
	}
	public void setBillerVO(BillerVO billerVO) {
		this.billerVO = billerVO;
	}
	public BillerCategoryVO getBillerTypeVO() {
		return billerTypeVO;
	}
	public void setBillerTypeVO(BillerCategoryVO billerTypeVO) {
		this.billerTypeVO = billerTypeVO;
	}

	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getBillerCode() {
		return billerCode;
	}
	public void setBillerCode(String billerCode) {
		this.billerCode = billerCode;
	}
	public String getBillerCategoryCode() {
		return billerCategoryCode;
	}
	public void setBillerCategoryCode(String billerCategoryCode) {
		this.billerCategoryCode = billerCategoryCode;
	}

	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getPayeeShortName() {
		return payeeShortName;
	}
	public void setPayeeShortName(String payeeShortName) {
		this.payeeShortName = payeeShortName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public Integer getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(Integer payeeId) {
		this.payeeId = payeeId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getConsumerNumber() {
		return consumerNumber;
	}
	public void setConsumerNumber(String consumerNumber) {
		this.consumerNumber = consumerNumber;
	}
	public String getConsumerDetail() {
		return consumerDetail;
	}
	public void setConsumerDetail(String consumerDetail) {
		this.consumerDetail = consumerDetail;
	}

}
