package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class PaginationReqVO.
 */
public class PaginationReqVO implements Serializable,Cloneable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7842913387703396477L;
	
	/** The fetch size. */
	private Integer fetchSize;
	
	/** The start idx. */
	private Integer startIdx;
	
	/**
	 * Gets the fetch size.
	 *
	 * @return the fetchSize
	 */
	public Integer getFetchSize() {
		return fetchSize;
	}
	
	/**
	 * Sets the fetch size.
	 *
	 * @param fetchSize the fetchSize to set
	 */
	public void setFetchSize(Integer fetchSize) {
		this.fetchSize = fetchSize;
	}
	
	/**
	 * Gets the start idx.
	 *
	 * @return the startIdx
	 */
	public Integer getStartIdx() {
		return startIdx;
	}
	
	/**
	 * Sets the start idx.
	 *
	 * @param startIdx the startIdx to set
	 */
	public void setStartIdx(Integer startIdx) {
		this.startIdx = startIdx;
	}

}
