package com.scb.channels.base.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;


/**
 * The Class ReferenceNumberGenerator.
 */
public class ReferenceNumberGenerator  {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(ReferenceNumberGenerator.class);
	
	/** The sequence number. */
	private static int sequenceNumber = 0;
	
	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public static String getDate()  { 
	  String yearMonthDate;
	  String year;
	  String month;
	  String date;
	  	Date sysdate = DateUtils.getCurrentDate();
		int sysYear = sysdate.getYear();
		int sysDate = sysdate.getDate();
		int sysMonth = sysdate.getMonth() + 1;

		if (sysYear < CommonConstants.HUNDRED) {
			year = CommonConstants.EMPTY + sysYear;
		} else if (sysYear % CommonConstants.HUNDRED == 0) {
			year = CommonConstants.DOUBLE_ZERO;
		} else {
			year = CommonConstants.EMPTY + sysYear % CommonConstants.HUNDRED;
		}

		if (sysMonth < CommonConstants.TEN) {
			month = CommonConstants.ZERO + sysMonth;
		} else {
			month = CommonConstants.EMPTY + sysMonth;
		}

		if (sysDate < CommonConstants.TEN) {
			date = CommonConstants.ZERO + sysDate;
		} else {
			date = CommonConstants.EMPTY + sysDate;
		}
		yearMonthDate = year + month + date;
		return yearMonthDate;
	}

	/**
	 * Gets the transaction type code.
	 *
	 * @param transactionType the transaction type
	 * @return the transaction type code
	 */
	public String getTransactionTypeCode(String transactionType)  {
		try {
			return TxnTypeMapper.valueOf(transactionType).getCode();
		}	catch (Exception e) {
			return TxnTypeMapper.DEFAULT.getCode();
		}
	}


	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public static String getTime()  {   
		String hourMinuteSsMillisecond;
		String hour;
		String minute;
		String second;
		String millisecond;
		
	  	Date sysDate = DateUtils.getCurrentDate();
		int sysHour = sysDate.getHours();
		int sysMinute = sysDate.getMinutes();
		int sysSecond = sysDate.getSeconds();
		long sysMilliseconds = System.currentTimeMillis();

		millisecond = CommonConstants.EMPTY + sysMilliseconds;
		millisecond = millisecond.substring(CommonConstants.SEVEN, CommonConstants.TEN);

		if (sysHour < CommonConstants.TEN) {
			hour = CommonConstants.ZERO + sysHour;
		} else {
			hour = CommonConstants.EMPTY + sysHour;
		}
		if (sysMinute < CommonConstants.TEN) {
			minute = CommonConstants.ZERO + sysMinute;
		} else {
			minute = CommonConstants.EMPTY + sysMinute;
		}
		if (sysSecond < CommonConstants.TEN) {
			second = CommonConstants.ZERO + sysSecond;
		} else {
			second = CommonConstants.EMPTY + sysSecond;
		}
		hourMinuteSsMillisecond = hour + minute + second + millisecond;

		return hourMinuteSsMillisecond;

	}

	/**
	 * This method generates  the Transaction Reference Number.
	 *
	 * @param countryCode the country code
	 * @param transactionType the transaction type
	 * @param channelId the channel id
	 * @return String referenceNumber
	 */
	public static String generateReferenceNumber(String countryCode, String transactionType, String channelId) 
	{
		String referenceNumber = null;
		ReferenceNumberGenerator rnGenerator=null;
		try {
			rnGenerator = new ReferenceNumberGenerator();
			referenceNumber = countryCode + CommonConstants.HYPHEN	+ channelId + CommonConstants.HYPHEN	
						+ rnGenerator.getTransactionTypeCode(transactionType) + CommonConstants.HYPHEN
											+ rnGenerator.getDate() + CommonConstants.HYPHEN 
											+ rnGenerator.getTime() + CommonConstants.HYPHEN
											+ RandomStringUtils.randomNumeric(CommonConstants.SIX) + CommonConstants.HYPHEN
											+ rnGenerator.getThreeSequenceNumber();
			Thread.sleep(CommonConstants.THIRTY);
		} catch (InterruptedException e) {
			LOGGER.error(e.getMessage());
		} // to generate generate unique Milliseconds
		return referenceNumber;
	}

	/**
	 * Gets the three sequence number.
	 *
	 * @return the three sequence number
	 */
	public static String getThreeSequenceNumber() {
		String threeSequenceNumber = null;
		Date sysDate = DateUtils.getCurrentDate();
		if (sysDate.getHours() == CommonConstants.ZERO_INT && sysDate.getMinutes() == 0
				&& sysDate.getSeconds() == 0) {
			ReferenceNumberGenerator.sequenceNumber = 1;
			threeSequenceNumber = CommonConstants.DOUBLE_ZERO
					+ ReferenceNumberGenerator.sequenceNumber;
		} else if (ReferenceNumberGenerator.sequenceNumber >=CommonConstants.TRIPLE_NINE)  {
			ReferenceNumberGenerator.sequenceNumber = 1;
			threeSequenceNumber = CommonConstants.DOUBLE_ZERO
					+ ReferenceNumberGenerator.sequenceNumber;
		} else {
			sequenceNumber = sequenceNumber + 1;
			if (sequenceNumber < CommonConstants.TEN) {
				threeSequenceNumber = CommonConstants.DOUBLE_ZERO + sequenceNumber;
			} else if ((sequenceNumber < CommonConstants.HUNDRED)&&(sequenceNumber >=CommonConstants.TEN)){
				threeSequenceNumber = CommonConstants.ZERO + sequenceNumber;
			} else {
				threeSequenceNumber = CommonConstants.EMPTY + sequenceNumber;	
			}
		}
		return threeSequenceNumber;
	}

	/**
	 * The Enum TxnTypeMapper.
	 */
	public enum TxnTypeMapper {
		
		DEFAULT("099"),
		ACC_DTL("003"),
		 LOGIN("001"),
		 BILLER("020"), 
		 LOCAL_BENE_LIST("019"), 
		 GLTT("018"), 
		 CHG_FT("017"), 
		 BILL("016"), 
		 CARD("015"), 
		 TT("014"), 
		 IBFT("013"), 
		 IFT("012"), 
		 OAT("011"),
		 addBiller("021"),
		 deleteBiller("022"),
		 accountInquiry("022"),
		 registerCustomer("023"),
		 makeCardEnquiry("024"),
		 makeBillInsert("025"),
		 downloadBill("026"),
		BILLER_DOWNLOAD("027");
		
		/** The value. */
		private String value;
	    
	    /**
    	 * Instantiates a new txn type mapper.
    	 *
    	 * @param value the value
    	 */
    	private TxnTypeMapper(String value) {
	            this.value = value;
	    }

		/**
		 * Gets the code.
		 *
		 * @return the code
		 */
		public String getCode() {
			return value;
		}
	}
	
	public static synchronized String generateHostReferenceValue(int count, String country, String channel){
		
		String reference = "";
		country = country != null ? country : CommonConstants.EMPTY;
		channel = channel != null ? channel : CommonConstants.EMPTY;
		
		if (country.equalsIgnoreCase("NG")) {
			reference = "1380" + RandomStringUtils.random(8, true, true);
		} else if (country.equalsIgnoreCase("HK")) {
			reference = String.valueOf(RandomStringUtils.randomNumeric(CommonConstants.TRANS_REF_COUNT_7));
		} else {
			reference = country + CommonConstants.HYPHEN + channel
					+ CommonConstants.HYPHEN
					+ RandomStringUtils.random(count, true, true);
		}
		return reference;
	}
	
	public static synchronized String generateQRReferenceNo(int count){
		
		String referenceNo =  String.valueOf(RandomStringUtils.randomNumeric(count));
		if(count ==6 && referenceNo.startsWith("1")){
			referenceNo = referenceNo+100000;
		}
		return referenceNo;
	}
	
	public static int generateJulianDate(){

	    int resultJulian = 0;
	    DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHH");
	    //Date date = new Date();
	    Date date = DateUtils.getCurrentDate();
	    String inputDate = dateFormat.format(date);
	    if(inputDate.length() > 0)
	    {
	     /*Days of month*/
	     int[] monthValues = {31,28,31,30,31,30,31,31,30,31,30,31};

	     String dayS, monthS, yearS, hourS;
	     dayS = inputDate.substring(0,2);
	     monthS = inputDate.substring(2, 4);
	     yearS = inputDate.substring(4, 8);
	     hourS = inputDate.substring(8, 10);
	     /*Convert to Integer*/
	     int day = Integer.valueOf(dayS);
	     int month = Integer.valueOf(monthS);
	     int year = Integer.valueOf(yearS); 
	         //Leap year check
	         if(year % 4 == 0)
	         {
	          monthValues[1] = 29;    
	         }
	         //Start building Julian date
	         String julianDate = "";
	         //last two digit of year: 2012 ==> 12
	         julianDate += yearS.substring(3,4);

	         int julianDays = 0;
	         for (int i=0; i < month-1; i++)
	         {
	          julianDays += monthValues[i];
	         }
	         julianDays += day;

	         if(String.valueOf(julianDays).length() < 2){
	              julianDate += "00";
	         }else if(String.valueOf(julianDays).length() < 3){
	              julianDate += "0";
	         }
	             julianDate += String.valueOf(julianDays)+hourS;
	             resultJulian =  Integer.valueOf(julianDate); 
	    	}
	    	return resultJulian;
		}
	// Added for Orange Money - start
	
	
	public static String generateReferenceNumber() 
	{
		String referenceNumber = null;
		ReferenceNumberGenerator rnGenerator=null;
		try {
			rnGenerator = new ReferenceNumberGenerator();
			//referenceNumber =  rnGenerator.getDate() + CommonConstants.ZERO + rnGenerator.getThreeSequenceNumber();
			referenceNumber =  rnGenerator.getCurrentDate();
			Thread.sleep(CommonConstants.THIRTY);
			LOGGER.info("generateReferenceNumber: Value is : "+ referenceNumber);
		} catch (InterruptedException e) {
			LOGGER.error("Exception occured while generation reference number",e);
		} // to generate generate unique Milliseconds
		return referenceNumber;
	}
	
	public String getCurrentDate()  { 
		  String yearMonth;
		  String year;
		  String month;
		  String date;
		  	Date sysdate = DateUtils.getCurrentDate();
			int sysYear = sysdate.getYear();
			int sysDate = sysdate.getDate();
			int sysMonth = sysdate.getMonth() + 1;

			if (sysYear < CommonConstants.HUNDRED) {
				year = CommonConstants.EMPTY + sysYear;
			} else if (sysYear % CommonConstants.HUNDRED == 0) {
				year = CommonConstants.DOUBLE_ZERO;
			} else {
				year = CommonConstants.EMPTY + sysYear % CommonConstants.HUNDRED;
			}

			if (sysMonth < CommonConstants.TEN) {
				month = CommonConstants.ZERO + sysMonth;
			} else {
				month = CommonConstants.EMPTY + sysMonth;
			}
			if (sysDate < CommonConstants.TEN) {
				date = CommonConstants.ZERO + sysDate;
			} else {
				date = CommonConstants.EMPTY + sysDate;
			}

			yearMonth = year + month + date;
			return yearMonth;
		}
}
