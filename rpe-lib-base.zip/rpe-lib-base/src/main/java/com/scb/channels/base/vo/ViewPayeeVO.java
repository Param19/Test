package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

 
/**
 * @author 1521723
 *
 */
public class ViewPayeeVO implements Serializable {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * billerCategoryId
	 */
	private Integer billerCategoryId;
	/**
	 * billerCategoryName
	 */
	private String billerCategoryName;
	/**
	 * billerName
	 */
	private String billerName;
	/**
	 * defaultAmount
	 */
	private Double defaultAmount ;
	/**
	 * billPresentmentType
	 */
	private String billPresentmentType;
	
	/**
	 * billerUniqueId
	 */
	private String billerUniqueId;
	
	/**
	 * payeeId
	 */
	private Integer payeeId;
	
	/**
	 * payeeName
	 */
	private String payeeName;
	/**
	 * payeeShortName
	 */
	private String payeeShortName;
	/**
	 * status
	 */
	private String status;
	
	/**
	 * countryCode
	 */
	private String countryCode;
	
	/**
	 * customerId
	 */
	private String customerId;
	
	/**
	 * payeeType
	 */
	private String payeeType;
	
	/**
	 * consumerNumber
	 */
	private String consumerNumber;
	
	/**
	 * remarks
	 */
	private String remarks;
	
	/**
	 * registrationTime
	 */
	private String referenceNumber;
	
	
	/**
	 * registrationTime
	 */
	public Timestamp registrationTime;  
	
	/**
	 * payeeFieldDetails
	 */
	public Timestamp terminationTime;
	/**
	 * isUpdateRequired
	 */
	private String isUpdateRequired;
	/**
	 * payeeFieldDetails
	 */
	private Set<PayeeFieldDetailsView> payeeFieldDetails=new HashSet<PayeeFieldDetailsView>(0);

	/**
	 * @return the isUpdateRequired
	 */
	public String getIsUpdateRequired() {
		return isUpdateRequired;
	}

	/**
	 * @param isUpdateRequired the isUpdateRequired to set
	 */
	public void setIsUpdateRequired(String isUpdateRequired) {
		this.isUpdateRequired = isUpdateRequired;
	}

	/**
	 * @return the payeeFieldDetails
	 */
	public Set<PayeeFieldDetailsView> getPayeeFieldDetails() {
		return payeeFieldDetails;
	}

	/**
	 * @param payeeFieldDetails the payeeFieldDetails to set
	 */
	public void setPayeeFieldDetails(Set<PayeeFieldDetailsView> payeeFieldDetails) {
		this.payeeFieldDetails = payeeFieldDetails;
	}

	/**
	 * @return the terminationTime
	 */
	public Timestamp getTerminationTime() {
		return terminationTime;
	}

	/**
	 * @param terminationTime the terminationTime to set
	 */
	public void setTerminationTime(Timestamp terminationTime) {
		this.terminationTime = terminationTime;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * @return the consumerNumber
	 */
	public String getConsumerNumber() {
		return consumerNumber;
	}

	/**
	 * @param consumerNumber the consumerNumber to set
	 */
	public void setConsumerNumber(String consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	/**
	 * @return the billerCategoryId
	 */
	public Integer getBillerCategoryId() {
		return billerCategoryId;
	}

	/**
	 * @param billerCategoryId the billerCategoryId to set
	 */
	public void setBillerCategoryId(Integer billerCategoryId) {
		this.billerCategoryId = billerCategoryId;
	}

	/**
	 * @return the billerCategoryName
	 */
	public String getBillerCategoryName() {
		return billerCategoryName;
	}

	/**
	 * @param billerCategoryName the billerCategoryName to set
	 */
	public void setBillerCategoryName(String billerCategoryName) {
		this.billerCategoryName = billerCategoryName;
	}

	/**
	 * @return the billerName
	 */
	public String getBillerName() {
		return billerName;
	}

	/**
	 * @param billerName the billerName to set
	 */
	public void setBillerName(String billerName) {
		this.billerName = billerName;
	}

	/**
	 * @return the defaultAmount
	 */
	public Double getDefaultAmount() {
		return defaultAmount;
	}

	/**
	 * @param defaultAmount the defaultAmount to set
	 */
	public void setDefaultAmount(Double defaultAmount) {
		this.defaultAmount = defaultAmount;
	}

	/**
	 * @return the billPresentmentType
	 */
	public String getBillPresentmentType() {
		return billPresentmentType;
	}

	/**
	 * @param billPresentmentType the billPresentmentType to set
	 */
	public void setBillPresentmentType(String billPresentmentType) {
		this.billPresentmentType = billPresentmentType;
	}

	/**
	 * @return the billerUniqueId
	 */
	public String getBillerUniqueId() {
		return billerUniqueId;
	}

	/**
	 * @param billerUniqueId the billerUniqueId to set
	 */
	public void setBillerUniqueId(String billerUniqueId) {
		this.billerUniqueId = billerUniqueId;
	}

	/**
	 * @return the payeeId
	 */
	public Integer getPayeeId() {
		return payeeId;
	}

	/**
	 * @param payeeId the payeeId to set
	 */
	public void setPayeeId(Integer payeeId) {
		this.payeeId = payeeId;
	}

	/**
	 * @return the payeeName
	 */
	public String getPayeeName() {
		return payeeName;
	}

	/**
	 * @param payeeName the payeeName to set
	 */
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	/**
	 * @return the payeeShortName
	 */
	public String getPayeeShortName() {
		return payeeShortName;
	}

	/**
	 * @param payeeShortName the payeeShortName to set
	 */
	public void setPayeeShortName(String payeeShortName) {
		this.payeeShortName = payeeShortName;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the payeeType
	 */
	public String getPayeeType() {
		return payeeType;
	}

	/**
	 * @param payeeType the payeeType to set
	 */
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public Timestamp getRegistrationTime() {
		return registrationTime;
	}

	public void setRegistrationTime(Timestamp registrationTime) {
		this.registrationTime = registrationTime;
	}

	
	
 	
}
