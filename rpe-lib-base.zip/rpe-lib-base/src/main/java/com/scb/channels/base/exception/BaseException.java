package com.scb.channels.base.exception;

import org.apache.commons.lang.ArrayUtils;
 
/**
  * The Class BaseException.
  */
 public class BaseException extends Exception {
	 
   /** The Constant serialVersionUID. */
   private static final long serialVersionUID = -5779213920169960614L;
   
   /** The error code. */
   protected String errorCode = "GENERAL_EXCEPTION";
   
   /** The parameters. */
   protected String[] parameters;
 
   /**
    * Instantiates a new base exception.
    */
   public BaseException() {}
 
   /**
    * Instantiates a new base exception.
    *
    * @param errorCode the error code
    */
   public BaseException(String errorCode) {
	   this.errorCode = errorCode;
   }
 
   /**
    * Instantiates a new base exception.
    *
    * @param errorCode the error code
    * @param message the message
    */
   public BaseException(String errorCode, String message) {
	   super(message);
	   this.errorCode = errorCode;
   }
 
   /**
    * Instantiates a new base exception.
    *
    * @param errorCode the error code
    * @param message the message
    * @param parameters the parameters
    */
   public BaseException(String errorCode, String message, String[] parameters) {
	   super(message);
	   this.errorCode = errorCode;
	   if (parameters != null && ArrayUtils.isNotEmpty(parameters)) {
		   this.parameters = new String[parameters.length];
		   ArrayUtils.addAll(this.parameters, parameters);
	   }
   }
 
   /**
    * Instantiates a new base exception.
    *
    * @param errorCode the error code
    * @param message the message
    * @param cause the cause
    */
   public BaseException(String errorCode, String message, Throwable cause) {
	   super(message, cause);
	   this.errorCode = errorCode;
   }
 
   /**
    * Instantiates a new base exception.
    *
    * @param errorCode the error code
    * @param message the message
    * @param parameters the parameters
    * @param cause the cause
    */
   public BaseException(String errorCode, String message, String[] parameters, Throwable cause) {
	   super(message, cause);
	   this.errorCode = errorCode;
	   if (parameters != null && ArrayUtils.isNotEmpty(parameters)) {
		   this.parameters = new String[parameters.length];
		   ArrayUtils.addAll(this.parameters, parameters);
	   }
   }
 
   /**
    * Instantiates a new base exception.
    *
    * @param cause the cause
    */
   public BaseException(Throwable cause) {
	   super(cause);
	   populateDetail(cause);
   }
 
   /**
    * Instantiates a new base exception.
    *
    * @param message the message
    * @param cause the cause
    */
   public BaseException(String message, Throwable cause) {
	   super(message, cause);
	   populateDetail(cause);
   }
 
   /**
    * Gets the error code.
    *
    * @return the error code
    */
   public String getErrorCode() {
	   return this.errorCode;
   }
 
   /**
    * Sets the error code.
    *
    * @param errorCode the new error code
    */
   public void setErrorCode(String errorCode) {
	   this.errorCode = errorCode;
   }
 
   /**
    * Gets the parameters.
    *
    * @return the parameters
    */
   public String[] getParameters()  {
	   return this.parameters;
   }
 
   /**
    * Sets the parameters.
    *
    * @param parameters the new parameters
    */
   public void setParameters(String[] parameters) {
	   if (parameters != null && ArrayUtils.isNotEmpty(parameters)) {
		   this.parameters = new String[parameters.length];
		   ArrayUtils.addAll(this.parameters, parameters);
	   }
   }
 
   /**
    * Populate detail.
    *
    * @param cause the cause
    */
   private void populateDetail(Throwable cause) {
	   if (cause instanceof BaseException) {
		   BaseException ex = (BaseException)cause;
		   setErrorCode(ex.getErrorCode());
		   setParameters(ex.getParameters());
	   }
   }
 
   /* (non-Javadoc)
    * @see java.lang.Throwable#toString()
    */
   public String toString() {
	   String s = super.getClass().getName();
	   String message = getLocalizedMessage();
 
	   if (this.errorCode != null) {
		   if (message == null)
			   message = "[" + this.errorCode + "]";
		   else {
			   message = "[" + this.errorCode + "] - " + message;
		   }
	   }
	   return ((message != null) ? s + ": " + message : s);
   }
 }

