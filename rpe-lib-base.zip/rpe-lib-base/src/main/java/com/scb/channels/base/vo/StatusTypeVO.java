package com.scb.channels.base.vo;

/**
 * The Class StatusTypeVO.
 * 
 * @author 1493439
 *
 */
public class StatusTypeVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5460464239217670637L;

	/** The status code. */
	private String statusCode;
	
	/** The status desc. */
	private String statusDesc;
	
	/** The refrence number. */
	private String referenceNumber;

	private HostResponseTypeVO hostResponseTypeVO;
	
	/**
	 * Gets the status code.
	 *
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * Sets the status code.
	 *
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Gets the status desc.
	 *
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * Sets the status desc.
	 *
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}


	/**
	 * @return the hostResponseTypeVO
	 */
	public HostResponseTypeVO getHostResponseTypeVO() {
		return hostResponseTypeVO;
	}

	/**
	 * @param hostResponseTypeVO the hostResponseTypeVO to set
	 */
	public void setHostResponseTypeVO(HostResponseTypeVO hostResponseTypeVO) {
		this.hostResponseTypeVO = hostResponseTypeVO;
	}

	
	/**
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "StatusTypeVO [statusCode=" + statusCode + ", statusDesc="
				+ statusDesc + ", refrenceNumber=" + referenceNumber
				+ ", hostResponseTypeVO=" + hostResponseTypeVO + "]";
	}

}
