package com.scb.channels.base.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * The Class InwardPaymentDetail.
 *
 * @author 1493439
 */
public class InwardPaymentDetailVO implements Serializable, Cloneable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6921481397447849509L;
	
	/** The id. */
	private Long id ;  
	
	/** The account number. */
	private String accountNumber;
	
	/** The mobile number. */
	private String mobileNumber;
	
	/** The country code. */
	private String countryCode; 
	
	/** The reference number. */
	private String referenceNumber; 
	
	/** The currency. */
	private String currency; 
	
	/** The payment amount. */
	private BigDecimal paymentAmount ;    
	
	/** The payment date. */
	private Timestamp paymentDate;   
	
	/** The payment type. */
	private String paymentType;     
	
	/** The payment status. */
	private String paymentStatus;    
	
	/** The payment description. */
	private String paymentDescription;
	
	/** The host system. */
	private String hostSystem;
	
	/** The host reference number. */
	private String hostReferenceNumber;   
	
	/** The host status code. */
	private String hostStatusCode;    
	
	/** The host status description. */
	private String hostStatusDescription;   
	
	/** The created time. */
	private Timestamp createdTime ;   
	
	/** The created by. */
	private String createdBy;   
	
	/** The updated time. */
	private Timestamp updatedTime;   
	
	/** The updated by. */
	private String updatedBy;   
	
	/** The version. */
	private Integer version;     
	
	/** The customer id. */
	private String customerId;
	
	/** The aggregator. */
	private String aggregator;
	
	/** The aggregator reference. */
	private String aggregatorReference;
	
	/** The retry count. */
	//private String retryCount;
	
	private Integer retryCount; // 1571157 modified type 
	
	/** The service provider. */
	private String serviceProvider;
	
	/** The name. */
	private String name;
	
	/** The email id. */
	private String emailId;
	
	/** The address. */
	private String address;
	
	/** The remarks. */
	private String remarks;
	
	/** The flag. */
	private String flag;
	
/** The payee Id**/ //Orange Money Project
	
	public PayeeDetailVO payee;
	
	public String walletID;
	
	
	public String getWalletID() {
		return walletID;
	}

	public void setWalletID(String walletID) {
		this.walletID = walletID;
	}

	public PayeeDetailVO getPayee() {
		return payee;
	}

	public void setPayee(PayeeDetailVO payee) {
		this.payee = payee;
	}

	public Long payeeId;
	
	public Long getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the mobile number.
	 *
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Sets the mobile number.
	 *
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * Gets the country code.
	 *
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * Sets the country code.
	 *
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * Gets the reference number.
	 *
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * Sets the reference number.
	 *
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the payment amount.
	 *
	 * @return the paymentAmount
	 */
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * Sets the payment amount.
	 *
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	/**
	 * Gets the payment date.
	 *
	 * @return the paymentDate
	 */
	public Timestamp getPaymentDate() {
		return paymentDate;
	}

	/**
	 * Sets the payment date.
	 *
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * Gets the payment type.
	 *
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * Sets the payment type.
	 *
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * Gets the payment status.
	 *
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * Sets the payment status.
	 *
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * Gets the payment description.
	 *
	 * @return the paymentDescription
	 */
	public String getPaymentDescription() {
		return paymentDescription;
	}

	/**
	 * Sets the payment description.
	 *
	 * @param paymentDescription the paymentDescription to set
	 */
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	/**
	 * Gets the host system.
	 *
	 * @return the hostSystem
	 */
	public String getHostSystem() {
		return hostSystem;
	}

	/**
	 * Sets the host system.
	 *
	 * @param hostSystem the hostSystem to set
	 */
	public void setHostSystem(String hostSystem) {
		this.hostSystem = hostSystem;
	}

	/**
	 * Gets the host reference number.
	 *
	 * @return the hostReferenceNumber
	 */
	public String getHostReferenceNumber() {
		return hostReferenceNumber;
	}

	/**
	 * Sets the host reference number.
	 *
	 * @param hostReferenceNumber the hostReferenceNumber to set
	 */
	public void setHostReferenceNumber(String hostReferenceNumber) {
		this.hostReferenceNumber = hostReferenceNumber;
	}

	/**
	 * Gets the host status code.
	 *
	 * @return the hostStatusCode
	 */
	public String getHostStatusCode() {
		return hostStatusCode;
	}

	/**
	 * Sets the host status code.
	 *
	 * @param hostStatusCode the hostStatusCode to set
	 */
	public void setHostStatusCode(String hostStatusCode) {
		this.hostStatusCode = hostStatusCode;
	}

	/**
	 * Gets the host status description.
	 *
	 * @return the hostStatusDescription
	 */
	public String getHostStatusDescription() {
		return hostStatusDescription;
	}

	/**
	 * Sets the host status description.
	 *
	 * @param hostStatusDescription the hostStatusDescription to set
	 */
	public void setHostStatusDescription(String hostStatusDescription) {
		
		if(hostStatusDescription != null && hostStatusDescription.length() > 245){
			hostStatusDescription = hostStatusDescription.substring(0, 245);
		}
		this.hostStatusDescription = hostStatusDescription;
	}

	/**
	 * Gets the created time.
	 *
	 * @return the createdTime
	 */
	public Timestamp getCreatedTime() {
		return createdTime;
	}

	/**
	 * Sets the created time.
	 *
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the updated time.
	 *
	 * @return the updatedTime
	 */
	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * Sets the updated time.
	 *
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	/**
	 * Gets the updated by.
	 *
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * Sets the updated by.
	 *
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the aggregator.
	 *
	 * @return the aggregator
	 */
	public String getAggregator() {
		return aggregator;
	}

	/**
	 * Sets the aggregator.
	 *
	 * @param aggregator the aggregator to set
	 */
	public void setAggregator(String aggregator) {
		this.aggregator = aggregator;
	}

	/**
	 * Gets the aggregator reference.
	 *
	 * @return the aggregatorReference
	 */
	public String getAggregatorReference() {
		return aggregatorReference;
	}

	/**
	 * Sets the aggregator reference.
	 *
	 * @param aggregatorReference the aggregatorReference to set
	 */
	public void setAggregatorReference(String aggregatorReference) {
		this.aggregatorReference = aggregatorReference;
	}

	/**
	 * @return the serviceProvider
	 */
	public String getServiceProvider() {
		return serviceProvider;
	}

	/**
	 * @param serviceProvider the serviceProvider to set
	 */
	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the flag
	 */
	public String getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("InwardPaymentDetailVO [id=");
		builder.append(id);
		builder.append(", accountNumber=");
		builder.append(accountNumber);
		builder.append(", mobileNumber=");
		builder.append(mobileNumber);
		builder.append(", countryCode=");
		builder.append(countryCode);
		builder.append(", referenceNumber=");
		builder.append(referenceNumber);
		builder.append(", currency=");
		builder.append(currency);
		builder.append(", paymentAmount=");
		builder.append(paymentAmount);
		builder.append(", paymentDate=");
		builder.append(paymentDate);
		builder.append(", paymentType=");
		builder.append(paymentType);
		builder.append(", paymentStatus=");
		builder.append(paymentStatus);
		builder.append(", paymentDescription=");
		builder.append(paymentDescription);
		builder.append(", hostSystem=");
		builder.append(hostSystem);
		builder.append(", hostReferenceNumber=");
		builder.append(hostReferenceNumber);
		builder.append(", hostStatusCode=");
		builder.append(hostStatusCode);
		builder.append(", hostStatusDescription=");
		builder.append(hostStatusDescription);
		builder.append(", createdTime=");
		builder.append(createdTime);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", updatedTime=");
		builder.append(updatedTime);
		builder.append(", updatedBy=");
		builder.append(updatedBy);
		builder.append(", version=");
		builder.append(version);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", aggregator=");
		builder.append(aggregator);
		builder.append(", aggregatorReference=");
		builder.append(aggregatorReference);
		builder.append(", retryCount=");
		builder.append(retryCount);
		builder.append(", serviceProvider=");
		builder.append(serviceProvider);
		builder.append(", name=");
		builder.append(name);
		builder.append(", emailId=");
		builder.append(emailId);
		builder.append(", address=");
		builder.append(address);
		builder.append(", remarks=");
		builder.append(remarks);
		builder.append(", flag=");
		builder.append(flag);
		builder.append(", payee=");
		builder.append(payee);
		builder.append(", walletID=");
		builder.append(walletID);
		builder.append(", payeeId=");
		builder.append(payeeId);
		builder.append("]");
		return builder.toString();
	}

}
