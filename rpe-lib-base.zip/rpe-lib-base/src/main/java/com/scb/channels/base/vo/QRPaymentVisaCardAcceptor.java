package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentVisaCardAcceptor implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5790984924003934904L;
	private String idCode;
	private String name;
	private String terminalId;
	private QRPaymentVisaCardAcceptorAddress address;
	public String getIdCode() {
		return idCode;
	}
	public void setIdCode(String idCode) {
		this.idCode = idCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public QRPaymentVisaCardAcceptorAddress getAddress() {
		return address;
	}
	public void setAddress(QRPaymentVisaCardAcceptorAddress address) {
		this.address = address;
	}
	
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	@Override
	public String toString() {
		return "QRPaymentVisaCardAcceptor [idCode=" + idCode + ", name=" + name
				+ ", terminalId=" + terminalId + ", address=" + address + "]";
	}
	
	
}
