package com.scb.channels.base.vo;

import java.io.Serializable;

public class DebitNarrativeVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2376683551536502106L;

	 private String debitNarrative;

	public String getDebitNarrative() {
		return debitNarrative;
	}

	public void setDebitNarrative(String debitNarrative) {
		this.debitNarrative = debitNarrative;
	}
}
