package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class ServiceVO.
 */
public class ServiceVO implements Serializable,Cloneable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7478466195300001603L;
	
	/** The service name. */
	private String serviceName;
	
	/** The host system. */
	private String hostSystem;
	
	/** The host env. */
	private String hostEnv;
	
	/** The service txn type. */
	private String serviceTxnType;
	
	/**
	 * Gets the service name.
	 *
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}
	
	/**
	 * Sets the service name.
	 *
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	/**
	 * Gets the host system.
	 *
	 * @return the hostSystem
	 */
	public String getHostSystem() {
		return hostSystem;
	}
	
	/**
	 * Sets the host system.
	 *
	 * @param hostSystem the hostSystem to set
	 */
	public void setHostSystem(String hostSystem) {
		this.hostSystem = hostSystem;
	}
	
	/**
	 * Gets the host env.
	 *
	 * @return the hostEnv
	 */
	public String getHostEnv() {
		return hostEnv;
	}
	
	/**
	 * Sets the host env.
	 *
	 * @param hostEnv the hostEnv to set
	 */
	public void setHostEnv(String hostEnv) {
		this.hostEnv = hostEnv;
	}
		
	/**
	 * Gets the service txn type.
	 *
	 * @return the serviceTxnType
	 */
	public String getServiceTxnType() {
		return serviceTxnType;
	}
	
	/**
	 * Sets the service txn type.
	 *
	 * @param serviceTxnType the serviceTxnType to set
	 */
	public void setServiceTxnType(String serviceTxnType) {
		this.serviceTxnType = serviceTxnType;
	}
	
	
}
