package com.scb.channels.base.vo;

/**
 * The Class ISOCODESVO.
 * 
 * @author 1493439
 *
 */
public class ISOCODESVO {
	
	/** The id. */
	private int id;
	
	/** The country_desc. */
	private String country_desc;
	
	/** The countrycode. */
	private String countrycode;
	
	/** The countrycode_char. */
	private String countrycode_char;
	
	/** The countrycode_numeric. */
	private int countrycode_numeric;
	
	/** The currencycode_char. */
	private String currencycode_char;
	
	/** The currencycode_numeric. */
	private int currencycode_numeric;
	
	/** The currency_code. */
	private int currency_code;
	
	/** The currency_precision. */
	private int currency_precision;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the country_desc.
	 *
	 * @return the country_desc
	 */
	public String getCountry_desc() {
		return country_desc;
	}

	/**
	 * Sets the country_desc.
	 *
	 * @param country_desc the new country_desc
	 */
	public void setCountry_desc(String country_desc) {
		this.country_desc = country_desc;
	}

	/**
	 * Gets the countrycode.
	 *
	 * @return the countrycode
	 */
	public String getCountrycode() {
		return countrycode;
	}

	/**
	 * Sets the countrycode.
	 *
	 * @param countrycode the new countrycode
	 */
	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	/**
	 * Gets the countrycode_char.
	 *
	 * @return the countrycode_char
	 */
	public String getCountrycode_char() {
		return countrycode_char;
	}

	/**
	 * Sets the countrycode_char.
	 *
	 * @param countrycode_char the new countrycode_char
	 */
	public void setCountrycode_char(String countrycode_char) {
		this.countrycode_char = countrycode_char;
	}

	/**
	 * Gets the countrycode_numeric.
	 *
	 * @return the countrycode_numeric
	 */
	public int getCountrycode_numeric() {
		return countrycode_numeric;
	}

	/**
	 * Sets the countrycode_numeric.
	 *
	 * @param countrycode_numeric the new countrycode_numeric
	 */
	public void setCountrycode_numeric(int countrycode_numeric) {
		this.countrycode_numeric = countrycode_numeric;
	}

	/**
	 * Gets the currencycode_char.
	 *
	 * @return the currencycode_char
	 */
	public String getCurrencycode_char() {
		return currencycode_char;
	}

	/**
	 * Sets the currencycode_char.
	 *
	 * @param currencycode_char the new currencycode_char
	 */
	public void setCurrencycode_char(String currencycode_char) {
		this.currencycode_char = currencycode_char;
	}

	/**
	 * Gets the currencycode_numeric.
	 *
	 * @return the currencycode_numeric
	 */
	public int getCurrencycode_numeric() {
		return currencycode_numeric;
	}

	/**
	 * Sets the currencycode_numeric.
	 *
	 * @param currencycode_numeric the new currencycode_numeric
	 */
	public void setCurrencycode_numeric(int currencycode_numeric) {
		this.currencycode_numeric = currencycode_numeric;
	}

	/**
	 * Gets the currency_code.
	 *
	 * @return the currency_code
	 */
	public int getCurrency_code() {
		return currency_code;
	}

	/**
	 * Sets the currency_code.
	 *
	 * @param currency_code the new currency_code
	 */
	public void setCurrency_code(int currency_code) {
		this.currency_code = currency_code;
	}

	/**
	 * Gets the currency precision.
	 *
	 * @return the currency precision
	 */
	public int getCurrency_precision() {
		return currency_precision;
	}

	/**
	 * Sets the currency precision.
	 *
	 * @param currency precision the new currency precision
	 */
	public void setCurrency_precision(int currency_precision) {
		this.currency_precision = currency_precision;
	}
	
}
