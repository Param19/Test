/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * The Class LogoutRequestVO.
 *
 * @author 1411807
 */
public class LogoutRequestVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8694698785255371392L;
	/** The version. */
	private int version;
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}


}
