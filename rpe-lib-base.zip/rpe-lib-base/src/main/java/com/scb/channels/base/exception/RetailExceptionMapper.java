package com.scb.channels.base.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.scb.channels.base.vo.HostResponseApiVO;

public class RetailExceptionMapper implements ExceptionMapper<Exception> {
	
	private final Logger logger = LoggerFactory.getLogger(RetailExceptionMapper.class);
	
	public RetailExceptionMapper(){
	}	

	@Override
	public Response toResponse(Exception exception) {		
		logger.info("Inside RetailExceptionMapper :::: "+exception.getMessage());
		Status res = null;
		if(exception instanceof JsonMappingException){
			res = Response.Status.BAD_REQUEST;
		}else{
			res = Response.Status.FORBIDDEN;
		}
		HostResponseApiVO  baseResponse = new HostResponseApiVO ();
		baseResponse.setCode("FAIL");
		baseResponse.setDesc("BAD_REQUEST==>"+exception.getMessage());
		return Response.status(res).entity(baseResponse).type("application/json").build();
	}
	
}
