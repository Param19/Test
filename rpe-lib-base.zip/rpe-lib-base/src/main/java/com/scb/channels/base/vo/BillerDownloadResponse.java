package com.scb.channels.base.vo;

import java.util.ArrayList;
import java.util.List;

public class BillerDownloadResponse extends BaseVO {
	
	List<BillerCategoryVO> billerCategory=new ArrayList(0);
	List<BackupMasterBillerCategoryVO> backupBillerCategory=new ArrayList(0);
	List<TempBillerCategoryVO> tempBillerCategory=new ArrayList(0);
	List<BillerDownloadHistory> billerDownloadHistory=new ArrayList(0);
	
	/**
	 * aggFetchFailedCategories
	 */
	String[] aggFetchFailedCategories=new String[]{};
	/**
	 * aggFetchFailedBillers
	 */
	String[] aggFetchFailedBillers=new String[]{};

	
	/**
	 * @return the aggFetchFailedBillers
	 */
	public String[] getAggFetchFailedBillers() {
		return aggFetchFailedBillers;
	}
	/**
	 * @param aggFetchFailedBillers the aggFetchFailedBillers to set
	 */
	public void setAggFetchFailedBillers(String[] aggFetchFailedBillers) {
		this.aggFetchFailedBillers = aggFetchFailedBillers;
	}
	/**
	 * @return the aggFetchFailedCategories
	 */
	public String[] getAggFetchFailedCategories() {
		return aggFetchFailedCategories;
	}
	/**
	 * @param aggFetchFailedCategories the aggFetchFailedCategories to set
	 */
	public void setAggFetchFailedCategories(String[] aggFetchFailedCategories) {
		this.aggFetchFailedCategories = aggFetchFailedCategories;
	}
	public List<BillerDownloadHistory> getBillerDownloadHistory() {
		return billerDownloadHistory;
	}
	public void setBillerDownloadHistory(
			List<BillerDownloadHistory> billerDownloadHistory) {
		this.billerDownloadHistory = billerDownloadHistory;
	}
	public List<BillerCategoryVO> getBillerCategory() {
		return billerCategory;
	}
	public void setBillerCategory(List<BillerCategoryVO> billerCategory) {
		this.billerCategory = billerCategory;
	}
	public List<BackupMasterBillerCategoryVO> getBackupBillerCategory() {
		return backupBillerCategory;
	}
	public void setBackupBillerCategory(
			List<BackupMasterBillerCategoryVO> backupBillerCategory) {
		this.backupBillerCategory = backupBillerCategory;
	}
	public List<TempBillerCategoryVO> getTempBillerCategory() {
		return tempBillerCategory;
	}
	public void setTempBillerCategory(List<TempBillerCategoryVO> tempBillerCategory) {
		this.tempBillerCategory = tempBillerCategory;
	}

}
