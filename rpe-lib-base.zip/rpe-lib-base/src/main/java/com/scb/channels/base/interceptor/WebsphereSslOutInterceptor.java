package com.scb.channels.base.interceptor;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLSocketFactory;


import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.Conduit;
import org.apache.cxf.transport.http.HTTPConduit;

import com.ibm.websphere.ssl.JSSEHelper;

public class WebsphereSslOutInterceptor extends AbstractPhaseInterceptor<Message> {

	  private String sslAlias = null;

	  public WebsphereSslOutInterceptor() {
	    super(Phase.SETUP);
	  }

	  public void handleMessage(Message message) throws Fault {
	    Conduit conduit = message.getExchange().getConduit(message);
	    if (conduit instanceof HTTPConduit) {
	      HTTPConduit httpConduit = (HTTPConduit)conduit;
	      String endpoint = (String) message.get(Message.ENDPOINT_ADDRESS);
	      if (endpoint != null) {
	        try {
	          URL endpointUrl = new URL(endpoint);
	          Map<String, String> connectionInfo = new HashMap<String, String>();

	          connectionInfo.put(JSSEHelper.CONNECTION_INFO_REMOTE_HOST, endpointUrl.getHost());
	          connectionInfo.put(JSSEHelper.CONNECTION_INFO_REMOTE_PORT, Integer.toString(endpointUrl.getPort()));
	          connectionInfo.put(JSSEHelper.CONNECTION_INFO_DIRECTION,   JSSEHelper.DIRECTION_OUTBOUND);
	          SSLSocketFactory factory = JSSEHelper.getInstance().getSSLSocketFactory(sslAlias, connectionInfo, null);

	          TLSClientParameters tlsClientParameters = httpConduit.getTlsClientParameters();
	          if (tlsClientParameters != null) {
	            tlsClientParameters.setSSLSocketFactory(factory);
	          }
	        } catch (MalformedURLException e) {
	          throw new Fault(e);
	        } catch (com.ibm.websphere.ssl.SSLException e) {
				e.printStackTrace();
			}
	      }
	    }
	  }

	  public void setSslAlias(String sslAlias) {
	    this.sslAlias = sslAlias;
	  }
	}
