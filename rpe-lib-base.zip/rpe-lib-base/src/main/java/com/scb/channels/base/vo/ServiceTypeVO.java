package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class ServiceTypeVO.
 */
public class ServiceTypeVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The service type. */
	private String serviceType;

	/** The prepaid cats. */
	private List<PrepaidCatsVO> prepaidCats;

	/**
	 * Gets the service type.
	 *
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * Sets the service type.
	 *
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * Gets the prepaid cats.
	 *
	 * @return the prepaidCats
	 */
	public List<PrepaidCatsVO> getPrepaidCats() {
		return prepaidCats;
	}

	/**
	 * Sets the prepaid cats.
	 *
	 * @param prepaidCats the prepaidCats to set
	 */
	public void setPrepaidCats(List<PrepaidCatsVO> prepaidCats) {
		this.prepaidCats = prepaidCats;
	}

	
}
