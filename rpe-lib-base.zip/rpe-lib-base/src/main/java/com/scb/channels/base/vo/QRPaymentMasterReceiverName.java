package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSetter;

public class QRPaymentMasterReceiverName implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8525504953327303889L;
	
	private String First;
	
	private String Middle;
	
	private String Last;

	public String getFirst() {
		return First;
	}
	@JsonSetter("First")
	public void setFirst(String first) {
		First = first;
	}

	public String getMiddle() {
		return Middle;
	}
	@JsonSetter("Middle")
	public void setMiddle(String middle) {
		Middle = middle;
	}

	public String getLast() {
		return Last;
	}
	@JsonSetter("Last")
	public void setLast(String last) {
		Last = last;
	}

	@Override
	public String toString() {
		return "QRPaymentMasterReceiverName [First=" + First + ", Middle="
				+ Middle + ", Last=" + Last + "]";
	}
	
	
}
