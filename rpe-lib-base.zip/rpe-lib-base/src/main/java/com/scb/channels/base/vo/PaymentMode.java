package com.scb.channels.base.vo;

import java.io.Serializable;


/**
 * This class contains Processor of CustomerPaymentAmount
 * 
 * @author 1317590
 */
public class PaymentMode implements Serializable, Cloneable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1642715131390232966L;

	private String paymentType;

	private String paymentOption;

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

}
