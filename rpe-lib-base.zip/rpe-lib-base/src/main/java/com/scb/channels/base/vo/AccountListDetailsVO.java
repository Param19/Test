package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.List;

public class AccountListDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8583871514947800490L;
	
	private List<AccountDetailsVO> accountDetails;
	private List<DealDetailsVO> dealDetails;
	private List<SingleCustomerViewVO> singleCustomerView;

	public List<AccountDetailsVO> getAccountDetails() {
		return accountDetails;
	}

	public void setAccountDetails(List<AccountDetailsVO> accountDetails) {
		this.accountDetails = accountDetails;
	}

	public List<DealDetailsVO> getDealDetails() {
		return dealDetails;
	}

	public void setDealDetails(List<DealDetailsVO> dealDetails) {
		this.dealDetails = dealDetails;
	}

	public List<SingleCustomerViewVO> getSingleCustomerView() {
		return singleCustomerView;
	}

	public void setSingleCustomerView(List<SingleCustomerViewVO> singleCustomerView) {
		this.singleCustomerView = singleCustomerView;
	}

}
