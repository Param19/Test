/**
 * 
 */
package com.scb.channels.base.vo;


/**
 * The Class AccountDetailsResponseVO.
 *
 * @author 1411807
 */
public class AccountDetailsResponseVO extends BaseVO {

	/**
	 * 
	 */
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7960577173028555500L;

	/** The casaVO*/
	private CASAVO casaVO;
	
	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;

	
	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public CASAVO getCasaVO() {
		return casaVO;
	}

	public void setCasaVO(CASAVO casaVO) {
		this.casaVO = casaVO;
	}


}
