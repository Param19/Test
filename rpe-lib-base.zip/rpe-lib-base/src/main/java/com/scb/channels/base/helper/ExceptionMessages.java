package com.scb.channels.base.helper;

/**
 * The Enum ExceptionMessages.
 */
public enum ExceptionMessages {

			_100("100:Null Pointer exception:100"), _101("101:Object is empty:101"),
			_103("103:Response Object is empty:103"), _104("104:Empty list Response:104"),
			_105("105:Internal System exception:105"), _106("106:Host Response is null:106"), 
			_107("107: User context is null:107"), _108("108: Limit Exceeded:108"), 
			_109("109: Response timed out:109"),_110("110: Session timed out:110"),
			_111("111: Invalid session:111"),_112("112:User/password is invalid:112"),
			//,_113("113:Username/mPin is invalid:1"),_114("114:Session is Timeout:114")
			_113("113:Invalid credentials or locked account. Please call  Customer Call Center for assistance.:113"),
			_114("114:Session is Timeout:114"),
			//,_115("113:PIN Number Locked. Pls Call Customer Contact Center for assistance.:0"),
			_115("115:Invalid credentials or locked account. Please call  Customer Call Center for assistance.:115"),
			_116("116:Device is not supported at this moment:1000"),
			_117("117:Pin Change Failed:100"),
			_118("118:Cheque stop request failed:100"),
			_119("119:You do not have any valid accounts. Please contact customer care.:100"),
			_120("120:This facility is not available for the selected 'From Account':100"), 
			_121("121:Unable to fetch beneficiary account details:100"),
			_122("122:Failed to post the transfer:100"),
			_123("123:Existing pin and new Pin cant be same: 100"),
			_124("124:Transaction failed :100"),
			_125("125:Validation failed:100"),
			_126("126:Invalid source/destination accounts:100"),
			_127("127:No such biller found:100"),_128("100:Invalid mobile number:100"),
			_129("129:Failed to post Aggregator:100"),
			_130("130:Your Fund Transfer Request has been failed. Please call customer care for further details.:100"),
			_131("131:You have exceeded your per transaction limit. Please enter amount between 1 to :100"),
			_132("132:You have exceeded your Daily Fund Transfer limit. Please try again tomorrow.:100"),
			_133("133:You have exceeded your per transaction limit.:100"),
			_134("134:Get Registration details failed.:134"),
			_135("135:Register customer failed.:135"),
			_136("136:Online pin change failed.:136"),
			_137("137:Invalid login .Count is reached to maximum.:137"),
			_138("138:valid login .You can do the pin change:138"),
			//_139("139:Invalid authentication. Pls Call Customer Contact Center for assistance.:100"),
			_139("139:Invalid credentials or locked account. Please call  Customer Call Center for assistance:139"),
			_140("140:Invalid Account Number.:140"),
			_141("141:We are unable to get bill details. Please enter your payment amount manually:14"),
			_142("142:This facility is available for SafariCom numbers only. Please check your mobile number and try again later:142"),
			_143("143:MobileNumber or User Id Mismatch:143"),
			_144("144:Biller Addition failed:144"), _145("145:No route host found exception:145"),
			_146("146:Biller Deletion failed:146"),
			 _147("147:Failed to post the bill payment:147"),
			 _148("148:Bill payment failed :148"),
			_149("149:Transaction Timeout :149"),
			_150("150:CardsDetails SuccessFully Retrived:150"),
          	_151("150:Biller details not retrived:151"),
          	_152("152:No data for Customer Payment History:152"),
			_181("181:No BillerCategories Available from the Aggregator:181"),
			_182("180: NO Biller List Available from the Aggregator:180"),	
			_109_1("-1: Response timed out:109"),
			_160("160: Invalid biller details:160"),
			_161("161:Failed to Archive:161"),
			_162("162:Number of payee Limit Exceeded :162"),
			_163("163:Number of payee Per Day Limit Exceeded :163"),
			_164("164:Response time out or Payee Validation Failed(Technical failures):164"),
           _165("165:Biller Fields not found:165"),
	        _166("166:Biller primary field not found:166"),
			_000("000:TRANSACTION SUCCESS:000"),
			_201("201:TRANSACTION FAILED:201"),
			_202("202:TRANSACTION SUBMITTED:202"),
			_204("204:TRANSACTION NOT FOUND:204"),
			_400("400:INVALID REQUEST:400"),
			_401("401:INVALID TOKEN:401"),
			_409("409:DUPLICATE REMITTANCE NUMBER:409"),
			_451("451:CONTACT BENEFICIARY BANK:451"),
			_452("452:INVALID REGISTERED MOBILE NUMBER:452"),
			_453("453:INVALID AMOUNT FORMAT:453"),
			_454("454:INVALID CURRENCY:454"),
			_455("455:INVALID SERVICE PROVIDER:455"),
			_456("456:INVALID COUNTRY:456"),
			_457("457:PLEASE TRY AGAIN LATER:457"),
			_458("458:PLEASE CONTACT SERVICE PROVIDER:458"),
			_503("503:SERVICE UNAVAILABLE:503"),		
			_203("203:QR Source of Fund is Null :203"),
			_205("205:QR Customer Credit Card Number is Null :205"),
			_206("206:QR Merchant PAN is Null :206"),
			_207("207:Customer Selected Card and Merchant PAN not belong to Same Network :207"),
			_208("208:Customer Selected Card and Merchant PAN not belong to MASTER Network :208"),
			_209("209:QR Merchant PAN is Null :209"),
			_210("210:QR Merchant PAN is Null :210"),
			_211("211:QR Merchant Category Code not available"),
			_212("212:QR Transaction Currency Code not available"),
			_213("213:QR Transaction Amount not available"),
			_214("214:QR Country Code not available"),
			_215("215:QR Merchant Name not available"),
			_216("216:QR Merchant City not available"),
			_217("217:QR Merchant Postal Code not available"),
			_218("218:QR Additional Field not available"),
			_219("219:QR Additional Field Ref Id not available"),
			_220("220:QR Additional Field Ref Value not available"),
			_221("221:QR Payment Date Value not available"),
			_222("222:QR Payment Originate Country not available"),
			_223("223:QR Payment Txn Currency Code not available"),
			_224("224:QR Payment Total Amount not available"),
			_225("225:QR Transaction Reference not available"),
			_226("226:Customer ID not available"),
			_227("227:Customer Type not available"),
			_228("228:Customer First Name not available"),
			_229("229:Customer Last Name not available"),
			_230("230:Customer Address 1 not available"),
			_231("231:Customer City not available"),
			_232("232:Customer zipcode not available"),
			_233("233:Customer Country not available"),
			_234("234:QR Payload Version not available"),
			_235("235:QR Merchant Pan Ref Id & Ref Value are mandatory"),
			_236("236:QRData is Null :236"),
			_237("202:QR Customer CardType is Null :237"),
			_238("238:Invalid Data in QR Payment Request to VISA/MASTER :238"),
			_239("239:QR Merchant PAN is Null :239"),
			_240("240:Invalid Currency :240"),
			_241("241:Customer Full Name not available"),
			_600("600:QR Debit Account Currency is Null:600"),
			_601("601:QR Debit Amount is Null:601"),
			_602("602:QR Debit Amount FX Rate is Null:602"),
			_603("603:QR Settlement Currency is Null:603"),
			_604("604:QR Settlement Amount is Null:604"),
			_605("605:QR Settlement Amount FX Rate is Null:605"),
			_606("606:QR Additional Field is Null:606"),
			_607("607:QR Transaction Currency is Null:607"),
			_608("608:QR Card Expiry Date is Null:608"),
			_609("609:QR RelID is Null:609"),
			_610("610:QR EBID is Null:610"),
			_611("611:QR Channel is Null:611"),
			_612("612:Invalid QR Transaction Currency Code:612"),
			_613("613:Merchant PAN is Null:613"),
			_242("242:Invalid Alias Name in Wallet Request"),
			_243("243:Invalid Transfer Option Wallet Request"),
			_244("244:Wallet Not available:244"),
			_245("245:Wallet Fields not found:245"),
		    _246("246:Wallet primary field not found:246"),
		    _247("247:Wallet details not retrived:247"),
		    _248("248:The wallet exceeds allowed number of accounts to be linked :248"),
		    _249("249:No data for Wallet Transfer history :249"),
			_250("250:Debit Limit Exceeded :250"),
			_251("251:MOBILE NUMBER IS EMPTY:251"),
            _252("252:CURRENCY IS EMPTY:252"),
            _253("253:AMOUNT IS EMPTY:253"),
            _254("254:ACCOUNT NUMBER IS EMPTY:254"),
            _255("255:COUNTRY IS EMPTY:255"),
            _256("256:REFERENCE NUMBER IS EMPTY:256");
			

	/** The value. */
	private String value;

	/**
	 * Instantiates a new exception messages.
	 * 
	 * @param value
	 *            the value
	 */
	private ExceptionMessages(String value) {
		this.value = value;
	}

	/**
	 * Gets the message.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return (value.contains(CommonConstants.COLON) ? value.split(CommonConstants.COLON)[1] : value);
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return (value.contains(CommonConstants.COLON) ? value.split(CommonConstants.COLON)[0] : value);
	}
	
	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getErrorCode() {
		return (value.contains(CommonConstants.COLON) ? value.split(CommonConstants.COLON)[0] : value);
	}

}
