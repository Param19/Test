package com.scb.channels.base.vo;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

public class JobsVO implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 1968392921060609864L;
	private int jobId;
	private String countryCode;
	private String jobName;
	private String jobDescription ;
	private String jvmName;
	private String status;
	private Timestamp jobLastUpdated;
	
	
	 
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	 
	public String getJobDescription() {
		return jobDescription;
	}
	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	public String getJvmName() {
		return jvmName;
	}
	public void setJvmName(String jvmName) {
		this.jvmName = jvmName;
	}
	 
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getJobLastUpdated() {
		return jobLastUpdated;
	}
	public void setJobLastUpdated(Timestamp jobLastUpdated) {
		this.jobLastUpdated = jobLastUpdated;
	}
 
	 
	 
	
	
	
}
