package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.scb.channels.base.helper.CommonConstants;

/**
 * The Class TransactionsPosting.
 */
public class TransactionsPostingVO implements Serializable, Cloneable {
	
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	 private String accountNumber;
	    private String accountCurrencyCode;
	    private String transactionAmount;
	    private String creditDebitIndicator;
	    private String loanReferenceNumber;
	    private String numberOfTransactions;
	    private String buyCurrencyCode;
	    private String sellCurrencyCode;
	    private String customerRateForTransaction;
	    private String costRateForTransaction;
	    private String productCode;
	    private String masterAccountNumber;
	    private String glDepartmentIdentifier;
	    private String plAccountFlag;
	    private String fromBankCode;
	    private String routingNumber;
	    private String chargeCode;
	    private String corporateBank;
	    private String customerReferenceNumber;
	    private String draftNumber;
	    private String idFlag;
	    private String opalProductCode;
	    private String paymentDetail;
	    private String relatedReferenceNumber;
	    private String senderReferenceNumber;
	    private String senderReferenceNumber2;
	    private String sendingInstitution;
	    private String sendingInstitutionName;
	    private String sequenceNumber;
	    private String payingBankCode;
	    private String creditorAccountNumber;
	    private String mandateReferenceNumber;
	    private String mandateForcePostFlag;
	    private String transactionCode;
	    private String vatCategoryCode;
	    private String chequeCount;
	    private String taxCode;
	    private String taxAmount;
	    private String taxableAmountinLocalCurrency;
	    private String taxAmountinLocalCurrency;
	    private String miscellaneousInformationCode;
	    private String buyAmount;
	    private String sellAmount;
	    private String indicativeRate;
	    private String localCurrencyEquivalent;
	    private String fbsRebateInformation;
	    private String scbTransactionSubcode;
	    private String scbTransactionReverseindicator;
		public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getAccountCurrencyCode() {
			return accountCurrencyCode;
		}
		public void setAccountCurrencyCode(String accountCurrencyCode) {
			this.accountCurrencyCode = accountCurrencyCode;
		}
		public String getTransactionAmount() {
			return transactionAmount;
		}
		public void setTransactionAmount(String transactionAmount) {
			this.transactionAmount = transactionAmount;
		}
		public String getCreditDebitIndicator() {
			return creditDebitIndicator;
		}
		public void setCreditDebitIndicator(String creditDebitIndicator) {
			this.creditDebitIndicator = creditDebitIndicator;
		}
		public String getLoanReferenceNumber() {
			return loanReferenceNumber;
		}
		public void setLoanReferenceNumber(String loanReferenceNumber) {
			this.loanReferenceNumber = loanReferenceNumber;
		}
		public String getNumberOfTransactions() {
			return numberOfTransactions;
		}
		public void setNumberOfTransactions(String numberOfTransactions) {
			this.numberOfTransactions = numberOfTransactions;
		}
		public String getBuyCurrencyCode() {
			return buyCurrencyCode;
		}
		public void setBuyCurrencyCode(String buyCurrencyCode) {
			this.buyCurrencyCode = buyCurrencyCode;
		}
		public String getSellCurrencyCode() {
			return sellCurrencyCode;
		}
		public void setSellCurrencyCode(String sellCurrencyCode) {
			this.sellCurrencyCode = sellCurrencyCode;
		}
		public String getCustomerRateForTransaction() {
			return customerRateForTransaction;
		}
		public void setCustomerRateForTransaction(String customerRateForTransaction) {
			this.customerRateForTransaction = customerRateForTransaction;
		}
		public String getCostRateForTransaction() {
			return costRateForTransaction;
		}
		public void setCostRateForTransaction(String costRateForTransaction) {
			this.costRateForTransaction = costRateForTransaction;
		}
		public String getProductCode() {
			return productCode;
		}
		public void setProductCode(String productCode) {
			this.productCode = productCode;
		}
		public String getMasterAccountNumber() {
			return masterAccountNumber;
		}
		public void setMasterAccountNumber(String masterAccountNumber) {
			this.masterAccountNumber = masterAccountNumber;
		}
		public String getGlDepartmentIdentifier() {
			return glDepartmentIdentifier;
		}
		public void setGlDepartmentIdentifier(String glDepartmentIdentifier) {
			this.glDepartmentIdentifier = glDepartmentIdentifier;
		}
		public String getPlAccountFlag() {
			return plAccountFlag;
		}
		public void setPlAccountFlag(String plAccountFlag) {
			this.plAccountFlag = plAccountFlag;
		}
		public String getFromBankCode() {
			return fromBankCode;
		}
		public void setFromBankCode(String fromBankCode) {
			this.fromBankCode = fromBankCode;
		}
		public String getRoutingNumber() {
			return routingNumber;
		}
		public void setRoutingNumber(String routingNumber) {
			this.routingNumber = routingNumber;
		}
		public String getChargeCode() {
			return chargeCode;
		}
		public void setChargeCode(String chargeCode) {
			this.chargeCode = chargeCode;
		}
		public String getCorporateBank() {
			return corporateBank;
		}
		public void setCorporateBank(String corporateBank) {
			this.corporateBank = corporateBank;
		}
		public String getCustomerReferenceNumber() {
			return customerReferenceNumber;
		}
		public void setCustomerReferenceNumber(String customerReferenceNumber) {
			this.customerReferenceNumber = customerReferenceNumber;
		}
		public String getDraftNumber() {
			return draftNumber;
		}
		public void setDraftNumber(String draftNumber) {
			this.draftNumber = draftNumber;
		}
		public String getIdFlag() {
			return idFlag;
		}
		public void setIdFlag(String idFlag) {
			this.idFlag = idFlag;
		}
		public String getOpalProductCode() {
			return opalProductCode;
		}
		public void setOpalProductCode(String opalProductCode) {
			this.opalProductCode = opalProductCode;
		}
		public String getPaymentDetail() {
			return paymentDetail;
		}
		public void setPaymentDetail(String paymentDetail) {
			this.paymentDetail = paymentDetail;
		}
		public String getRelatedReferenceNumber() {
			return relatedReferenceNumber;
		}
		public void setRelatedReferenceNumber(String relatedReferenceNumber) {
			this.relatedReferenceNumber = relatedReferenceNumber;
		}
		public String getSenderReferenceNumber() {
			return senderReferenceNumber;
		}
		public void setSenderReferenceNumber(String senderReferenceNumber) {
			this.senderReferenceNumber = senderReferenceNumber;
		}
		public String getSenderReferenceNumber2() {
			return senderReferenceNumber2;
		}
		public void setSenderReferenceNumber2(String senderReferenceNumber2) {
			this.senderReferenceNumber2 = senderReferenceNumber2;
		}
		public String getSendingInstitution() {
			return sendingInstitution;
		}
		public void setSendingInstitution(String sendingInstitution) {
			this.sendingInstitution = sendingInstitution;
		}
		public String getSendingInstitutionName() {
			return sendingInstitutionName;
		}
		public void setSendingInstitutionName(String sendingInstitutionName) {
			this.sendingInstitutionName = sendingInstitutionName;
		}
		public String getSequenceNumber() {
			return sequenceNumber;
		}
		public void setSequenceNumber(String sequenceNumber) {
			this.sequenceNumber = sequenceNumber;
		}
		public String getPayingBankCode() {
			return payingBankCode;
		}
		public void setPayingBankCode(String payingBankCode) {
			this.payingBankCode = payingBankCode;
		}
		public String getCreditorAccountNumber() {
			return creditorAccountNumber;
		}
		public void setCreditorAccountNumber(String creditorAccountNumber) {
			this.creditorAccountNumber = creditorAccountNumber;
		}
		public String getMandateReferenceNumber() {
			return mandateReferenceNumber;
		}
		public void setMandateReferenceNumber(String mandateReferenceNumber) {
			this.mandateReferenceNumber = mandateReferenceNumber;
		}
		public String getMandateForcePostFlag() {
			return mandateForcePostFlag;
		}
		public void setMandateForcePostFlag(String mandateForcePostFlag) {
			this.mandateForcePostFlag = mandateForcePostFlag;
		}
		public String getTransactionCode() {
			return transactionCode;
		}
		public void setTransactionCode(String transactionCode) {
			this.transactionCode = transactionCode;
		}
		public String getVatCategoryCode() {
			return vatCategoryCode;
		}
		public void setVatCategoryCode(String vatCategoryCode) {
			this.vatCategoryCode = vatCategoryCode;
		}
		public String getChequeCount() {
			return chequeCount;
		}
		public void setChequeCount(String chequeCount) {
			this.chequeCount = chequeCount;
		}
		public String getTaxCode() {
			return taxCode;
		}
		public void setTaxCode(String taxCode) {
			this.taxCode = taxCode;
		}
		public String getTaxAmount() {
			return taxAmount;
		}
		public void setTaxAmount(String taxAmount) {
			this.taxAmount = taxAmount;
		}
		public String getTaxableAmountinLocalCurrency() {
			return taxableAmountinLocalCurrency;
		}
		public void setTaxableAmountinLocalCurrency(String taxableAmountinLocalCurrency) {
			this.taxableAmountinLocalCurrency = taxableAmountinLocalCurrency;
		}
		public String getTaxAmountinLocalCurrency() {
			return taxAmountinLocalCurrency;
		}
		public void setTaxAmountinLocalCurrency(String taxAmountinLocalCurrency) {
			this.taxAmountinLocalCurrency = taxAmountinLocalCurrency;
		}
		public String getMiscellaneousInformationCode() {
			return miscellaneousInformationCode;
		}
		public void setMiscellaneousInformationCode(String miscellaneousInformationCode) {
			this.miscellaneousInformationCode = miscellaneousInformationCode;
		}
		public String getBuyAmount() {
			return buyAmount;
		}
		public void setBuyAmount(String buyAmount) {
			this.buyAmount = buyAmount;
		}
		public String getSellAmount() {
			return sellAmount;
		}
		public void setSellAmount(String sellAmount) {
			this.sellAmount = sellAmount;
		}
		public String getIndicativeRate() {
			return indicativeRate;
		}
		public void setIndicativeRate(String indicativeRate) {
			this.indicativeRate = indicativeRate;
		}
		public String getLocalCurrencyEquivalent() {
			return localCurrencyEquivalent;
		}
		public void setLocalCurrencyEquivalent(String localCurrencyEquivalent) {
			this.localCurrencyEquivalent = localCurrencyEquivalent;
		}
		public String getFbsRebateInformation() {
			return fbsRebateInformation;
		}
		public void setFbsRebateInformation(String fbsRebateInformation) {
			this.fbsRebateInformation = fbsRebateInformation;
		}

	public String getSCBTransactionSubcode() {
		return scbTransactionSubcode;
	}

	public void setSCBTransactionSubcode(String value) {
		this.scbTransactionSubcode = value;
	}

	public String getSCBTransactionReverseindicator() {
		return scbTransactionReverseindicator;
	}

	public void setSCBTransactionReverseindicator(String value) {
		this.scbTransactionReverseindicator = value;
	}


	    
	    

  }
