/**
 * 
 */
package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class AuthVO.
 *
 * @author 1411807
 */
public class AuthVO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The user. */
	private String user;
	
	private String custId;
	
	/** The credential. */
	private String credential;
	
	/** The sms otp. */
	private String smsOTP;
	
	/** The email otp. */
	private String emailOTP;
	
	/** The captcha. */
	private String captcha;
	
	/** The encryption. */
	private boolean encryption;

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Gets the credential.
	 *
	 * @return the credential
	 */
	public String getCredential() {
		return credential;
	}

	/**
	 * Sets the credential.
	 *
	 * @param credential the credential to set
	 */
	public void setCredential(String credential) {
		this.credential = credential;
	}

	/**
	 * Gets the sms otp.
	 *
	 * @return the smsOTP
	 */
	public String getSmsOTP() {
		return smsOTP;
	}

	/**
	 * Sets the sms otp.
	 *
	 * @param smsOTP the smsOTP to set
	 */
	public void setSmsOTP(String smsOTP) {
		this.smsOTP = smsOTP;
	}

	/**
	 * Gets the email otp.
	 *
	 * @return the emailOTP
	 */
	public String getEmailOTP() {
		return emailOTP;
	}

	/**
	 * Sets the email otp.
	 *
	 * @param emailOTP the emailOTP to set
	 */
	public void setEmailOTP(String emailOTP) {
		this.emailOTP = emailOTP;
	}

	/**
	 * Gets the captcha.
	 *
	 * @return the captcha
	 */
	public String getCaptcha() {
		return captcha;
	}

	/**
	 * Sets the captcha.
	 *
	 * @param captcha the captcha to set
	 */
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	/**
	 * Checks if is encryption.
	 *
	 * @return the encryption
	 */
	public boolean isEncryption() {
		return encryption;
	}

	/**
	 * Sets the encryption.
	 *
	 * @param encryption the encryption to set
	 */
	public void setEncryption(boolean encryption) {
		this.encryption = encryption;
	}

	/**
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}

	/**
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
}
