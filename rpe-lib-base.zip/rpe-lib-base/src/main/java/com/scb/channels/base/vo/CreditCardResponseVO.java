package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class BillerListResponseVO.
 */
public class CreditCardResponseVO extends BaseVO implements Serializable {

  
	/** The credit card list. */
	private List<CreditCardVO> creditCardList = new ArrayList<CreditCardVO>();
	
	/*credit CardReponseVo*/
	private CreditCardVO cardResponse;
	
	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;
	
	/** status Description**/
	
	private String statusDescription;
	
	public List<CreditCardVO> getCreditCardList() {
		return creditCardList;
	}

	public void setCreditCardList(List<CreditCardVO> creditCardList) {
		this.creditCardList = creditCardList;
	}

	public CreditCardVO getCardresponse() {
		return cardResponse;
	}

	public void setCardresponse(CreditCardVO cardresponse) {
		cardResponse = cardresponse;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
}
