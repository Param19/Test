/**
 * 
 */
package com.scb.channels.base.vo;

/**
 * @author 1411807
 *
 */
public class ThirdPartyAuthVO extends AuthVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4203188277599434494L;

	private String externalSystemType;
	
	private String externalURI;
	
	private String hostname;
	
	private Integer port;
	
	private String protocol;

	/**
	 * @return the externalSystemType
	 */
	public String getExternalSystemType() {
		return externalSystemType;
	}

	/**
	 * @param externalSystemType the externalSystemType to set
	 */
	public void setExternalSystemType(String externalSystemType) {
		this.externalSystemType = externalSystemType;
	}

	/**
	 * @return the externalURI
	 */
	public String getExternalURI() {
		return externalURI;
	}

	/**
	 * @param externalURI the externalURI to set
	 */
	public void setExternalURI(String externalURI) {
		this.externalURI = externalURI;
	}

	/**
	 * @return the hostname
	 */
	public String getHostname() {
		return hostname;
	}

	/**
	 * @param hostname the hostname to set
	 */
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	/**
	 * @return the port
	 */
	public Integer getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(Integer port) {
		this.port = port;
	}

	/**
	 * @return the protocol
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * @param protocol the protocol to set
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
}
