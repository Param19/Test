package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceContextApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	private String serviceName;
	private String serviceTxnType;
	private String hostEnv;
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getServiceTxnType() {
		return serviceTxnType;
	}
	public void setServiceTxnType(String serviceTxnType) {
		this.serviceTxnType = serviceTxnType;
	}
	public String getHostEnv() {
		return hostEnv;
	}
	public void setHostEnv(String hostEnv) {
		this.hostEnv = hostEnv;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "ServiceContextApiVO [serviceName=" + serviceName
				+ ", serviceTxnType=" + serviceTxnType + ", hostEnv=" + hostEnv
				+ "]";
	}	
	
}
