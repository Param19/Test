package com.scb.channels.base.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserContextApiVO implements Serializable{

	private static final long serialVersionUID = 000111L;
	
	private String relid;
	private String ebid;
	private String segmentCode;
	
	public String getRelid() {
		return relid;
	}
	public void setRelid(String relid) {
		this.relid = relid;
	}
	public String getEbid() {
		return ebid;
	}
	public void setEbid(String ebid) {
		this.ebid = ebid;
	}
	public String getSegmentCode() {
		return segmentCode;
	}
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "UserContextApiVO [relid=" + relid + ", ebid=" + ebid
				+ ", segmentCode=" + segmentCode + "]";
	}
	
}
