package com.scb.channels.base.vo;

import java.io.Serializable;

public class PayeeResponseVO extends BaseVO implements Serializable{

	private static final long serialVersionUID = 9042931376651758721L;

	private PayeeVO payeeVO;

	public PayeeVO getPayeeVO() {
		return payeeVO;
	}

	public void setPayeeVO(PayeeVO payeeVO) {
		this.payeeVO = payeeVO;
	}
}
