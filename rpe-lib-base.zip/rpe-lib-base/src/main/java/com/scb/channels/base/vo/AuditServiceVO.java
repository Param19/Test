package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class AuditServiceVO.
 */
public class AuditServiceVO implements Serializable {

	/** Class AuditServiceVO. */
	private static final long serialVersionUID = -6517695553535152578L;
	
	/** The id. */
	private Long id;
	
	/** The mobl no. */
	private String moblNo;
	
	/** The email. */
	private String email;
	
	/** The system type. */
	private String systemType;
	
	/** The environment. */
	private String environment;
	
	/** The channel. */
	private String channel;
	
	/** The session id. */
	private String sessionId;
	
	/** The session group id. */
	private String sessionGroupId;
	
	/** The status cd. */
	private String statusCd;
	
	/** The error cd. */
	private String errorCd;
	
	/** The error desc. */
	private String errorDesc;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The type. */
	private String type;
	
	/** The func cd. */
	private String funcCd;
	
	/** The event cd. */
	private String eventCd;
	
	/** The u user. */
	private String uUser;
	
	/** The user id. */
	private String userId;
	
	/** The cust group id. */
	private String custGroupId;
	
	/** The cust id. */
	private String custId;
	
	/** The cust id type. */
	private String custIdType;
	
	/** The name. */
	private String name;
	
	/** The client id. */
	private String clientId;    	   //customVar01
	
	/** The client ip address. */
	private String clientIpAddress;	   //customVar02
	
	/** The role. */
	private String role;	   		   //customVar03	
	
	/** The custom var04. */
	private String customVar04;
	
	/** The custom var05. */
	private String customVar05;
	
	/** The custom var06. */
	private String customVar06;
	
	/** The custom var07. */
	private String customVar07;

	/** The custom var08. */
	private String customVar08;
	
	/** The custom var09. */
	private String customVar09;

	/** The custom var10. */
	private String customVar10;
	
	
	/** The custom dec01. */
	private Double customDec01;
	
	/** The custom dec02. */
	private Double customDec02;
	
	/** The custom dec03. */
	private Double customDec03;
	
	/** The custom dec04. */
	private Double customDec04;
	
	/** The custom dec05. */
	private Double customDec05;
	
	/** The custom dt. */
	private Date customDt;
	
	/** The dt audit. */
	private Date dtAudit;
	
	/** The audit by. */
	private String auditBy;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The version. */
	private Integer version;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Gets the mobl no.
	 *
	 * @return the mobl no
	 */
	public String getMoblNo() {
		return moblNo;
	}
	
	/**
	 * Sets the mobl no.
	 *
	 * @param moblNo the new mobl no
	 */
	public void setMoblNo(String moblNo) {
		this.moblNo = moblNo;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Gets the system type.
	 *
	 * @return the system type
	 */
	public String getSystemType() {
		return systemType;
	}
	
	/**
	 * Sets the system type.
	 *
	 * @param systemType the new system type
	 */
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	
	/**
	 * Sets the environment.
	 *
	 * @param environment the new environment
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the new channel
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/**
	 * Gets the session id.
	 *
	 * @return the session id
	 */
	public String getSessionId() {
		return sessionId;
	}
	
	/**
	 * Sets the session id.
	 *
	 * @param sessionId the new session id
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	/**
	 * Gets the session group id.
	 *
	 * @return the session group id
	 */
	public String getSessionGroupId() {
		return sessionGroupId;
	}
	
	/**
	 * Sets the session group id.
	 *
	 * @param sessionGroupId the new session group id
	 */
	public void setSessionGroupId(String sessionGroupId) {
		this.sessionGroupId = sessionGroupId;
	}
	
	/**
	 * Gets the status cd.
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	
	/**
	 * Sets the status cd.
	 *
	 * @param statusCd the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	/**
	 * Gets the error cd.
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}
	
	/**
	 * Sets the error cd.
	 *
	 * @param errorCd the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}
	
	/**
	 * Gets the error desc.
	 *
	 * @return the error desc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}
	
	/**
	 * Sets the error desc.
	 *
	 * @param errorDesc the new error desc
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctry cd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the new ctry cd
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * Gets the func cd.
	 *
	 * @return the func cd
	 */
	public String getFuncCd() {
		return funcCd;
	}
	
	/**
	 * Sets the func cd.
	 *
	 * @param funcCd the new func cd
	 */
	public void setFuncCd(String funcCd) {
		this.funcCd = funcCd;
	}
	
	/**
	 * Gets the event cd.
	 *
	 * @return the event cd
	 */
	public String getEventCd() {
		return eventCd;
	}
	
	/**
	 * Sets the event cd.
	 *
	 * @param eventCd the new event cd
	 */
	public void setEventCd(String eventCd) {
		this.eventCd = eventCd;
	}
	
	/**
	 * Gets the u user.
	 *
	 * @return the u user
	 */
	public String getuUser() {
		return uUser;
	}
	
	/**
	 * Sets the u user.
	 *
	 * @param uUser the new u user
	 */
	public void setuUser(String uUser) {
		this.uUser = uUser;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the cust group id.
	 *
	 * @return the cust group id
	 */
	public String getCustGroupId() {
		return custGroupId;
	}
	
	/**
	 * Sets the cust group id.
	 *
	 * @param custGroupId the new cust group id
	 */
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the cust id
	 */
	public String getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the new cust id
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	/**
	 * Gets the cust id type.
	 *
	 * @return the cust id type
	 */
	public String getCustIdType() {
		return custIdType;
	}
	
	/**
	 * Sets the cust id type.
	 *
	 * @param custIdType the new cust id type
	 */
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the custom var04.
	 *
	 * @return the custom var04
	 */
	public String getCustomVar04() {
		return customVar04;
	}
	
	/**
	 * Sets the custom var04.
	 *
	 * @param customVar04 the new custom var04
	 */
	public void setCustomVar04(String customVar04) {
		this.customVar04 = customVar04;
	}
	
	/**
	 * Gets the custom var05.
	 *
	 * @return the custom var05
	 */
	public String getCustomVar05() {
		return customVar05;
	}
	
	/**
	 * Sets the custom var05.
	 *
	 * @param customVar05 the new custom var05
	 */
	public void setCustomVar05(String customVar05) {
		this.customVar05 = customVar05;
	}
	
	/**
	 * Gets the custom dec01.
	 *
	 * @return the custom dec01
	 */
	public Double getCustomDec01() {
		return customDec01;
	}
	
	/**
	 * Sets the custom dec01.
	 *
	 * @param customDec01 the new custom dec01
	 */
	public void setCustomDec01(Double customDec01) {
		this.customDec01 = customDec01;
	}
	
	/**
	 * Gets the custom dec02.
	 *
	 * @return the custom dec02
	 */
	public Double getCustomDec02() {
		return customDec02;
	}
	
	/**
	 * Sets the custom dec02.
	 *
	 * @param customDec02 the new custom dec02
	 */
	public void setCustomDec02(Double customDec02) {
		this.customDec02 = customDec02;
	}
	
	/**
	 * Gets the custom dec03.
	 *
	 * @return the custom dec03
	 */
	public Double getCustomDec03() {
		return customDec03;
	}
	
	/**
	 * Sets the custom dec03.
	 *
	 * @param customDec03 the new custom dec03
	 */
	public void setCustomDec03(Double customDec03) {
		this.customDec03 = customDec03;
	}
	
	/**
	 * Gets the custom dec04.
	 *
	 * @return the custom dec04
	 */
	public Double getCustomDec04() {
		return customDec04;
	}
	
	/**
	 * Sets the custom dec04.
	 *
	 * @param customDec04 the new custom dec04
	 */
	public void setCustomDec04(Double customDec04) {
		this.customDec04 = customDec04;
	}
	
	/**
	 * Gets the custom dec05.
	 *
	 * @return the custom dec05
	 */
	public Double getCustomDec05() {
		return customDec05;
	}
	
	/**
	 * Sets the custom dec05.
	 *
	 * @param customDec05 the new custom dec05
	 */
	public void setCustomDec05(Double customDec05) {
		this.customDec05 = customDec05;
	}
	
	/**
	 * Gets the custom dt.
	 *
	 * @return the custom dt
	 */
	public Date getCustomDt() {
		return customDt;
	}
	
	/**
	 * Sets the custom dt.
	 *
	 * @param customDt the new custom dt
	 */
	public void setCustomDt(Date customDt) {
		this.customDt = customDt;
	}
	
	/**
	 * Gets the dt audit.
	 *
	 * @return the dt audit
	 */
	public Date getDtAudit() {
		return dtAudit;
	}
	
	/**
	 * Sets the dt audit.
	 *
	 * @param dtAudit the new dt audit
	 */
	public void setDtAudit(Date dtAudit) {
		this.dtAudit = dtAudit;
	}
	
	/**
	 * Gets the audit by.
	 *
	 * @return the audit by
	 */
	public String getAuditBy() {
		return auditBy;
	}
	
	/**
	 * Sets the audit by.
	 *
	 * @param auditBy the new audit by
	 */
	public void setAuditBy(String auditBy) {
		this.auditBy = auditBy;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dt created
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the new dt created
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dt upd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the new dt upd
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Gets the client id.
	 *
	 * @return the client id
	 */
	public String getClientId() {
		return clientId;
	}
	
	/**
	 * Sets the client id.
	 *
	 * @param clientId the new client id
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	/**
	 * Gets the client ip address.
	 *
	 * @return the client ip address
	 */
	public String getClientIpAddress() {
		return clientIpAddress;
	}
	
	/**
	 * Sets the client ip address.
	 *
	 * @param clientIpAddress the new client ip address
	 */
	public void setClientIpAddress(String clientIpAddress) {
		this.clientIpAddress = clientIpAddress;
	}
	
	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	
	/**
	 * Sets the role.
	 *
	 * @param role the new role
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * Gets the custom var06.
	 *
	 * @return the customVar06
	 */
	public String getCustomVar06() {
		return customVar06;
	}

	/**
	 * Sets the custom var06.
	 *
	 * @param customVar06 the customVar06 to set
	 */
	public void setCustomVar06(String customVar06) {
		this.customVar06 = customVar06;
	}

	/**
	 * Gets the custom var07.
	 *
	 * @return the customVar07
	 */
	public String getCustomVar07() {
		return customVar07;
	}

	/**
	 * Sets the custom var07.
	 *
	 * @param customVar07 the customVar07 to set
	 */
	public void setCustomVar07(String customVar07) {
		this.customVar07 = customVar07;
	}

	/**
	 * Gets the custom var08.
	 *
	 * @return the customVar08
	 */
	public String getCustomVar08() {
		return customVar08;
	}

	/**
	 * Sets the custom var08.
	 *
	 * @param customVar08 the customVar08 to set
	 */
	public void setCustomVar08(String customVar08) {
		this.customVar08 = customVar08;
	}

	/**
	 * Gets the custom var09.
	 *
	 * @return the customVar09
	 */
	public String getCustomVar09() {
		return customVar09;
	}

	/**
	 * Sets the custom var09.
	 *
	 * @param customVar09 the customVar09 to set
	 */
	public void setCustomVar09(String customVar09) {
		this.customVar09 = customVar09;
	}

	/**
	 * Gets the custom var10.
	 *
	 * @return the customVar10
	 */
	public String getCustomVar10() {
		return customVar10;
	}

	/**
	 * Sets the custom var10.
	 *
	 * @param customVar10 the customVar10 to set
	 */
	public void setCustomVar10(String customVar10) {
		this.customVar10 = customVar10;
	}
	
	

}
