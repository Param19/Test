package com.scb.channels.base.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

public class CASAVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -416768783801254180L;
	
	 	private String accountNumber;
	    private String adviceIndicator;
	    private String autoCloseIndicator;
	    private String categoryCode;
	    private String chargesOffFlag;
	    private String classificationCode;
	    private String closingBalance;
	    private String consolidatedStatementFlag;
	    private String currencyCode;
	    private String currentStatus;
	    private String glDepartmentID;
	    private String interestCode;
	    private String interestDebitSuspenseCreditFlag;
	    private String operatingInstruction;
	    private String poolInclusionIndicator;
	    private String segmentCode;
	    private String staffClassificationFlag;
	    private BalanceVO balance; 
	    private InterestVO interest;   
	    private OverdraftVO overdraft;     
	    private StatisticalHistoryVO statisticalHistory;   
	    private List<AccountLinkVO> accountLink;
	    private List<AccountToCustomerLinkVO> accountToCustomerLink;
	    private List<BlockVO> block;
	    private List<CardListVO> card; 
	    private List<CustomerToAccountLinkVO> customerToAccountLink;
	    private List<MultilingualAccountDetailsVO> multilingualAccountDetails;
	    private List<NomineeVO> nominee;
	    private List<RiskVO> risk;
	    private List<SubsidiaryAccountMasterRelationshipVO> subsidiaryAccountMasterRelationship;
	    private List<TransactionsVO> transactions;
	    private List<UserDefinedFieldsVO> userDefinedFields;
	    
	    //Account Directsales
	    private String closingEmployeeID;
	    private String referralID;
	    private String sourcingEmployeeID;
	    
	    //Date
	    private Calendar openDate;
	    private Calendar closeDate;
	    private Calendar activatedDate;
	    private Calendar maturityDate;
	    
	    //Branch
	    private String branchCode;
	    private String branchName;
	    
	    //CreditInterest
	    private String creditInterestAccountNumber;
	    private String creditInterestAccountCurrencyCode;
	    private String creditInterestAccrualFlag;
	    private String creditInterestProductCode;
	    
	    //DebitInterest
	    private String debitInterestAccountNumber;
	    private String debitInterestAccountCurrencyCode;
	    private String debitInterestAccrualFlag;
	    private String debitInterestProductCode;
	    
	    //International
	    private String bankAccountNumber;
	    private String standardIndustrialClassificationCode;
	    
	    //LastCredit
	    private String creditTransactionAmount;
	    private Calendar  creditTransactionDate;
	    private Calendar  creditTransactionDateExcludingSystemTransaction;
	    
	    //LastDebit
	    private String debitTransactionAmount;
	    private Calendar debitTransactionDate;
	    private Calendar debitTransactionDateExcludingSystemTransaction;
	    
	    //Master
	    private String masterNumber;
	    private String relationshipManagerCode;
	    private String relationshipManagerName;
	    private String customerSegmentCode;
	    private String institutionClassificationCode;
	    
	    //Name
	    private String fullName;
	    private String shortName;
	    
	    //Product
	    private String code;
	    private String description;
	    private String chequeRequestFlag;
	    private String category;
		
	    
	    public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getAdviceIndicator() {
			return adviceIndicator;
		}
		public void setAdviceIndicator(String adviceIndicator) {
			this.adviceIndicator = adviceIndicator;
		}
		public String getAutoCloseIndicator() {
			return autoCloseIndicator;
		}
		public void setAutoCloseIndicator(String autoCloseIndicator) {
			this.autoCloseIndicator = autoCloseIndicator;
		}
		public String getCategoryCode() {
			return categoryCode;
		}
		public void setCategoryCode(String categoryCode) {
			this.categoryCode = categoryCode;
		}
		public String getChargesOffFlag() {
			return chargesOffFlag;
		}
		public void setChargesOffFlag(String chargesOffFlag) {
			this.chargesOffFlag = chargesOffFlag;
		}
		public String getClassificationCode() {
			return classificationCode;
		}
		public void setClassificationCode(String classificationCode) {
			this.classificationCode = classificationCode;
		}
		public String getClosingBalance() {
			return closingBalance;
		}
		public void setClosingBalance(String closingBalance) {
			this.closingBalance = closingBalance;
		}
		public String getConsolidatedStatementFlag() {
			return consolidatedStatementFlag;
		}
		public void setConsolidatedStatementFlag(String consolidatedStatementFlag) {
			this.consolidatedStatementFlag = consolidatedStatementFlag;
		}
		public String getCurrencyCode() {
			return currencyCode;
		}
		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}
		public String getCurrentStatus() {
			return currentStatus;
		}
		public void setCurrentStatus(String currentStatus) {
			this.currentStatus = currentStatus;
		}
		public String getGlDepartmentID() {
			return glDepartmentID;
		}
		public void setGlDepartmentID(String glDepartmentID) {
			this.glDepartmentID = glDepartmentID;
		}
		public String getInterestCode() {
			return interestCode;
		}
		public void setInterestCode(String interestCode) {
			this.interestCode = interestCode;
		}
		public String getInterestDebitSuspenseCreditFlag() {
			return interestDebitSuspenseCreditFlag;
		}
		public void setInterestDebitSuspenseCreditFlag(
				String interestDebitSuspenseCreditFlag) {
			this.interestDebitSuspenseCreditFlag = interestDebitSuspenseCreditFlag;
		}
		public String getOperatingInstruction() {
			return operatingInstruction;
		}
		public void setOperatingInstruction(String operatingInstruction) {
			this.operatingInstruction = operatingInstruction;
		}
		public String getPoolInclusionIndicator() {
			return poolInclusionIndicator;
		}
		public void setPoolInclusionIndicator(String poolInclusionIndicator) {
			this.poolInclusionIndicator = poolInclusionIndicator;
		}
		public String getSegmentCode() {
			return segmentCode;
		}
		public void setSegmentCode(String segmentCode) {
			this.segmentCode = segmentCode;
		}
		public String getStaffClassificationFlag() {
			return staffClassificationFlag;
		}
		public void setStaffClassificationFlag(String staffClassificationFlag) {
			this.staffClassificationFlag = staffClassificationFlag;
		}
		public BalanceVO getBalance() {
			return balance;
		}
		public void setBalance(BalanceVO balance) {
			this.balance = balance;
		}
		public InterestVO getInterest() {
			return interest;
		}
		public void setInterest(InterestVO interest) {
			this.interest = interest;
		}
		public OverdraftVO getOverdraft() {
			return overdraft;
		}
		public void setOverdraft(OverdraftVO overdraft) {
			this.overdraft = overdraft;
		}
		public StatisticalHistoryVO getStatisticalHistory() {
			return statisticalHistory;
		}
		public void setStatisticalHistory(StatisticalHistoryVO statisticalHistory) {
			this.statisticalHistory = statisticalHistory;
		}
		public List<AccountLinkVO> getAccountLink() {
			return accountLink;
		}
		public void setAccountLink(List<AccountLinkVO> accountLink) {
			this.accountLink = accountLink;
		}
		public List<AccountToCustomerLinkVO> getAccountToCustomerLink() {
			return accountToCustomerLink;
		}
		public void setAccountToCustomerLink(
				List<AccountToCustomerLinkVO> accountToCustomerLink) {
			this.accountToCustomerLink = accountToCustomerLink;
		}
		public List<BlockVO> getBlock() {
			return block;
		}
		public void setBlock(List<BlockVO> block) {
			this.block = block;
		}
		public List<CardListVO> getCard() {
			return card;
		}
		public void setCard(List<CardListVO> card) {
			this.card = card;
		}
		public List<CustomerToAccountLinkVO> getCustomerToAccountLink() {
			return customerToAccountLink;
		}
		public void setCustomerToAccountLink(
				List<CustomerToAccountLinkVO> customerToAccountLink) {
			this.customerToAccountLink = customerToAccountLink;
		}
		public List<MultilingualAccountDetailsVO> getMultilingualAccountDetails() {
			return multilingualAccountDetails;
		}
		public void setMultilingualAccountDetails(
				List<MultilingualAccountDetailsVO> multilingualAccountDetails) {
			this.multilingualAccountDetails = multilingualAccountDetails;
		}
		public List<NomineeVO> getNominee() {
			return nominee;
		}
		public void setNominee(List<NomineeVO> nominee) {
			this.nominee = nominee;
		}
		public List<RiskVO> getRisk() {
			return risk;
		}
		public void setRisk(List<RiskVO> risk) {
			this.risk = risk;
		}
		public List<SubsidiaryAccountMasterRelationshipVO> getSubsidiaryAccountMasterRelationship() {
			return subsidiaryAccountMasterRelationship;
		}
		public void setSubsidiaryAccountMasterRelationship(
				List<SubsidiaryAccountMasterRelationshipVO> subsidiaryAccountMasterRelationship) {
			this.subsidiaryAccountMasterRelationship = subsidiaryAccountMasterRelationship;
		}
		public List<TransactionsVO> getTransactions() {
			return transactions;
		}
		public void setTransactions(List<TransactionsVO> transactions) {
			this.transactions = transactions;
		}
		public List<UserDefinedFieldsVO> getUserDefinedFields() {
			return userDefinedFields;
		}
		public void setUserDefinedFields(List<UserDefinedFieldsVO> userDefinedFields) {
			this.userDefinedFields = userDefinedFields;
		}
		public String getClosingEmployeeID() {
			return closingEmployeeID;
		}
		public void setClosingEmployeeID(String closingEmployeeID) {
			this.closingEmployeeID = closingEmployeeID;
		}
		public String getReferralID() {
			return referralID;
		}
		public void setReferralID(String referralID) {
			this.referralID = referralID;
		}
		public String getSourcingEmployeeID() {
			return sourcingEmployeeID;
		}
		public void setSourcingEmployeeID(String sourcingEmployeeID) {
			this.sourcingEmployeeID = sourcingEmployeeID;
		}
		public Calendar getOpenDate() {
			return openDate;
		}
		public void setOpenDate(Calendar openDate) {
			this.openDate = openDate;
		}
		public Calendar getCloseDate() {
			return closeDate;
		}
		public void setCloseDate(Calendar closeDate) {
			this.closeDate = closeDate;
		}
		public Calendar getActivatedDate() {
			return activatedDate;
		}
		public void setActivatedDate(Calendar activatedDate) {
			this.activatedDate = activatedDate;
		}
		public Calendar getMaturityDate() {
			return maturityDate;
		}
		public void setMaturityDate(Calendar maturityDate) {
			this.maturityDate = maturityDate;
		}
		public String getBranchCode() {
			return branchCode;
		}
		public void setBranchCode(String branchCode) {
			this.branchCode = branchCode;
		}
		public String getBranchName() {
			return branchName;
		}
		public void setBranchName(String branchName) {
			this.branchName = branchName;
		}
		public String getCreditInterestAccountNumber() {
			return creditInterestAccountNumber;
		}
		public void setCreditInterestAccountNumber(String creditInterestAccountNumber) {
			this.creditInterestAccountNumber = creditInterestAccountNumber;
		}
		public String getCreditInterestAccountCurrencyCode() {
			return creditInterestAccountCurrencyCode;
		}
		public void setCreditInterestAccountCurrencyCode(
				String creditInterestAccountCurrencyCode) {
			this.creditInterestAccountCurrencyCode = creditInterestAccountCurrencyCode;
		}
		public String getCreditInterestAccrualFlag() {
			return creditInterestAccrualFlag;
		}
		public void setCreditInterestAccrualFlag(String creditInterestAccrualFlag) {
			this.creditInterestAccrualFlag = creditInterestAccrualFlag;
		}
		public String getCreditInterestProductCode() {
			return creditInterestProductCode;
		}
		public void setCreditInterestProductCode(String creditInterestProductCode) {
			this.creditInterestProductCode = creditInterestProductCode;
		}
		public String getBankAccountNumber() {
			return bankAccountNumber;
		}
		public void setBankAccountNumber(String bankAccountNumber) {
			this.bankAccountNumber = bankAccountNumber;
		}
		public String getStandardIndustrialClassificationCode() {
			return standardIndustrialClassificationCode;
		}
		public void setStandardIndustrialClassificationCode(
				String standardIndustrialClassificationCode) {
			this.standardIndustrialClassificationCode = standardIndustrialClassificationCode;
		}
		public String getCreditTransactionAmount() {
			return creditTransactionAmount;
		}
		public void setCreditTransactionAmount(String creditTransactionAmount) {
			this.creditTransactionAmount = creditTransactionAmount;
		}
		public Calendar getCreditTransactionDate() {
			return creditTransactionDate;
		}
		public void setCreditTransactionDate(Calendar creditTransactionDate) {
			this.creditTransactionDate = creditTransactionDate;
		}
		public Calendar getCreditTransactionDateExcludingSystemTransaction() {
			return creditTransactionDateExcludingSystemTransaction;
		}
		public void setCreditTransactionDateExcludingSystemTransaction(
				Calendar creditTransactionDateExcludingSystemTransaction) {
			this.creditTransactionDateExcludingSystemTransaction = creditTransactionDateExcludingSystemTransaction;
		}
		public String getMasterNumber() {
			return masterNumber;
		}
		public void setMasterNumber(String masterNumber) {
			this.masterNumber = masterNumber;
		}
		public String getRelationshipManagerCode() {
			return relationshipManagerCode;
		}
		public void setRelationshipManagerCode(String relationshipManagerCode) {
			this.relationshipManagerCode = relationshipManagerCode;
		}
		public String getRelationshipManagerName() {
			return relationshipManagerName;
		}
		public void setRelationshipManagerName(String relationshipManagerName) {
			this.relationshipManagerName = relationshipManagerName;
		}
		public String getCustomerSegmentCode() {
			return customerSegmentCode;
		}
		public void setCustomerSegmentCode(String customerSegmentCode) {
			this.customerSegmentCode = customerSegmentCode;
		}
		public String getInstitutionClassificationCode() {
			return institutionClassificationCode;
		}
		public void setInstitutionClassificationCode(
				String institutionClassificationCode) {
			this.institutionClassificationCode = institutionClassificationCode;
		}
		public String getFullName() {
			return fullName;
		}
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		public String getShortName() {
			return shortName;
		}
		public void setShortName(String shortName) {
			this.shortName = shortName;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getChequeRequestFlag() {
			return chequeRequestFlag;
		}
		public void setChequeRequestFlag(String chequeRequestFlag) {
			this.chequeRequestFlag = chequeRequestFlag;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getDebitInterestAccountNumber() {
			return debitInterestAccountNumber;
		}
		public void setDebitInterestAccountNumber(String debitInterestAccountNumber) {
			this.debitInterestAccountNumber = debitInterestAccountNumber;
		}
		public String getDebitInterestAccountCurrencyCode() {
			return debitInterestAccountCurrencyCode;
		}
		public void setDebitInterestAccountCurrencyCode(
				String debitInterestAccountCurrencyCode) {
			this.debitInterestAccountCurrencyCode = debitInterestAccountCurrencyCode;
		}
		public String getDebitInterestAccrualFlag() {
			return debitInterestAccrualFlag;
		}
		public void setDebitInterestAccrualFlag(String debitInterestAccrualFlag) {
			this.debitInterestAccrualFlag = debitInterestAccrualFlag;
		}
		public String getDebitInterestProductCode() {
			return debitInterestProductCode;
		}
		public void setDebitInterestProductCode(String debitInterestProductCode) {
			this.debitInterestProductCode = debitInterestProductCode;
		}
		public String getDebitTransactionAmount() {
			return debitTransactionAmount;
		}
		public void setDebitTransactionAmount(String debitTransactionAmount) {
			this.debitTransactionAmount = debitTransactionAmount;
		}
		public Calendar getDebitTransactionDate() {
			return debitTransactionDate;
		}
		public void setDebitTransactionDate(Calendar debitTransactionDate) {
			this.debitTransactionDate = debitTransactionDate;
		}
		public Calendar getDebitTransactionDateExcludingSystemTransaction() {
			return debitTransactionDateExcludingSystemTransaction;
		}
		public void setDebitTransactionDateExcludingSystemTransaction(
				Calendar debitTransactionDateExcludingSystemTransaction) {
			this.debitTransactionDateExcludingSystemTransaction = debitTransactionDateExcludingSystemTransaction;
		}
	    
	    	    
	    

}
