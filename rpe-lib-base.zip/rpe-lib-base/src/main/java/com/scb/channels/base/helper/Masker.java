package com.scb.channels.base.helper;

import java.util.regex.Pattern;

/**
 * The Class Masker.
 */
public class Masker {
	
	/** The pattern. */
	private Pattern pattern;
	  
  	/** The group number. */
  	private int groupNumber;
	  
  	/** The mask rule. */
  	private MaskConfiguaration maskRule;

	  /**
  	 * Gets the pattern.
  	 *
  	 * @return the pattern
  	 */
  	public Pattern getPattern()
	  {
	    return this.pattern;
	  }

	  /**
  	 * Gets the group number.
  	 *
  	 * @return the group number
  	 */
  	public int getGroupNumber() {
	    return this.groupNumber;
	  }

	  /**
  	 * Gets the mask rule.
  	 *
  	 * @return the mask rule
  	 */
  	public MaskConfiguaration getMaskRule() {
	    return this.maskRule;
	  }

	  /**
  	 * Instantiates a new masker.
  	 *
  	 * @param reg the reg
  	 * @param groupNumber the group number
  	 * @param expression the expression
  	 */
  	public Masker(String reg, int groupNumber, String expression) {
	    this.pattern = Pattern.compile(reg);
	    this.groupNumber = groupNumber;
	    this.maskRule = MaskConfiguaration.build(expression);
	  }
}
