package com.scb.channels.base.vo;

import java.io.Serializable;

/**
 * The Class BillerListResponseVO.
 */
public class BillerUtilityResponseVO extends BaseVO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2901895135622295570L;

	/** The valueCode. */
	private String valueCode;

	/** The statusCd. */
	private String statusCd;
	
	private String utilityInfo;

	
	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getUtilityInfo() {
		return utilityInfo;
	}

	public void setUtilityInfo(String utilityInfo) {
		this.utilityInfo = utilityInfo;
	}
	
}
