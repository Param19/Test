package com.scb.channels.payments.processor.impl;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.vo.QRPaymentVisaResponse;

public class QRPaymentVisaResponseParser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String response ="{\"transactionIdentifier\":23423432,\"actionCode\":\"00\",\"approvalCode\":\"21324K\",\"responseCode\":\"5\",\"transmissionDateTime\":\"2017-04-07T09:41:28.000Z\",\"retrievalReferenceNumber\":\"709715100019\",\"merchantCategoryCode\":5812,\"cardAcceptor\":{\"name\":\"mVisa Merchant\",\"terminalId\":\"MER-ID00\",\"idCode\":\"MvisaMerchant-1\",\"address\":{\"city\":\"mVisa City\",\"country\":\"IN\"}},\"merchantVerificationValue\":\"0A45AF98FC\"}";
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		try{
			mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
			QRPaymentVisaResponse qrPaymentVisaResponse = mapper.readValue(response.toString(), QRPaymentVisaResponse.class);
			System.out.println(qrPaymentVisaResponse);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
