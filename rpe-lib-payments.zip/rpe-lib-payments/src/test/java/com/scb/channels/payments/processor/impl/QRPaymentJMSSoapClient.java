package com.scb.channels.payments.processor.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.qrpayments.QrPaymentRequestType;
import com.scb.channels.qrpayments.QrPaymentResponseType;
import com.scb.channels.qrpaymentservice.QrPayments;

public class QRPaymentJMSSoapClient {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(QRPaymentJMSSoapClient.class);
	
	public static void main(String args[]) throws Exception {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[] { "resources/client-applicationContext.xml" });
		QrPaymentRequestType qrPaymentRequestType = null;
		System.out.println("calling server");
		QrPayments customerService = (QrPayments) applicationContext.getBean("qrPaymentClient");
		System.out.println("called server");
		String requestXML = readFile();
		qrPaymentRequestType  = (QrPaymentRequestType)CommonHelper.unMarshall(requestXML, QrPaymentRequestType.class);
		QrPaymentResponseType qrPaymentResponseType= customerService.qrPay(qrPaymentRequestType);
		
		System.out.println("------------------------------------" + qrPaymentResponseType.toString());
		System.exit(0);
	}
	
	private static String readFile(){
		File file = null;
		StringBuffer buffer = new StringBuffer();
		Scanner sc = null;
		try {
			file = new File("C:\\Users\\1224098\\Desktop\\soapOverJmsRequest.xml");
			sc = new Scanner(file);
			while (sc.hasNextLine()) {
				buffer.append(sc.nextLine());
				//System.out.println(sCurrentLine);
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("Exception occurred duirng readFile::: ",e);
		} finally {
		        if(sc != null){
		            sc.close();
		        }
		}
		return buffer.toString();
	}
}
