package com.scb.channels.payments.processor.impl;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.Processor;
import com.scb.channels.payment.helper.TestHelper;

public class NarrationConfigTest {
	
	 @Test	
	  public void testBillPayment() throws BusinessException{
		ApplicationContext appContext = TestHelper.getContext();
		
		System.out.println("-----------------------");
		
		Processor processor = (Processor) 
				appContext.getBean("billerPayProcessor");
		
		PayloadDTO payload = new PayloadDTO();
		
		UserVO userVO = new UserVO();
		userVO.setChannelId("IBNK");	
		userVO.setCustomerId("000143");
		userVO.setCountry("KE");
		
		AccountVO accountVO = new AccountVO();
		accountVO.setAccountNumber("123456789");

		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setSrcAccountVO(accountVO);
		
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);	
		billerPayDetailsVO.setBillerCategoryCd("227");
		 MessageVO m = new MessageVO();
		 m.setRequestCode("1111111111111111111111");
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		billerPayDetailsVO.setCountryCode("KE");
		billerPayDetailsVO.setChannel("IBNK");
		billerPayDetailsVO.setConsumerNo("12345");
		billerPayDetailsVO.setHostReference("Host Reference");
		billerPayDetailsVO.setPayRef("payRef");
		billerPayDetailsVO.setUtilityCd("utilityCd");
		billerPayDetailsVO.setBillerName("BillerName");
		
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		billerPayRequestVO.setMessageVO(m);
		billerPayRequestVO.setUser(userVO);
		payload.setRequestVO(billerPayRequestVO);
			
		try {
			processor.process(payload);
		} catch (FilterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(payload);
	}

}
