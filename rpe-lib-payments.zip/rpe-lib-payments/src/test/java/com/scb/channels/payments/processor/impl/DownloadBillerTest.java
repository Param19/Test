package com.scb.channels.payments.processor.impl;

import static org.junit.Assert.*;

import java.util.UUID;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.payments.service.BillerDownloadCountriesService;
import com.scb.channels.payments.service.BillerDownloadProcessService;
import com.scb.channels.payments.service.BillerDownloadRequestCreateService;
import com.scb.channels.payments.service.BillerManagementService;

public class DownloadBillerTest {

	ApplicationContext context=null;
	
	@Before
	public void IntializeContext(){
		
		//context=new ClassPathXmlApplicationContext("/spring/payment-async-routes-integration.xml","/spring/payment-integration.xml");
		context= new ClassPathXmlApplicationContext("/spring/payment-service-context.xml");
	}
	
	//@Test
	public void CountryLevelBillerDownloadtest(){
		CamelContext camel=context.getBean("paymentCamelConfig",CamelContext.class);
		
		ProducerTemplate  producer= camel.createProducerTemplate();
		producer.sendBody("direct:billerDownloadProcessor", "NG");
	}
	
	
	@Test
	public void CountryloadBillers(){
		BillerManagementService Biller=context.getBean("billerManagementService",BillerManagementService.class);
		BillerPayRequestVO b= new BillerPayRequestVO();
		ClientVO client = new ClientVO();
		client.setCountry("NG");
		b.setClientVO(client);
		BillerPayResponseVO resonse =Biller.getBillerCategories(b);
		System.out.println(resonse);
		BillerPayResponseVO resonse2 =Biller.getBillerCategories(b);
		System.out.println(resonse);
	}
	
	
	//@Test
	public void ServicelevelTestForBillerDownload() {
		 
		PayloadDTO dto= new PayloadDTO();
		
		BillerDownloadRequest request= new BillerDownloadRequest();
		UserVO user= new UserVO();
		user.setCountry("NG");
		user.setChannelId(CommonConstants.IBANK);
		request.setUser(user);
		ClientVO client= new ClientVO();
		client.setCountry("NG");
		client.setVersion("1.0");
		request.setClientVO(client);
		MessageVO message= new MessageVO();
		
		message.setRequestType(CommonConstants.SYNC);
		message.setReqID(getUniqueId());
		request.setMessageVO(message);
		ServiceVO service= new ServiceVO();
		service.setServiceName(CommonConstants.BILLER_DOWNLOAD);
		service.setServiceTxnType(CommonConstants.BILLER_DOWNLOAD);
		request.setServiceVO(service);
		
		request.setCaptureSystem("Interswitch");
		request.setAggregatorName("Interswitch");
		request.setSubDomainType("getBillerCategories");
		request.setTypeName("Invoice");
		request.setMessageSender("IBANK");
		request.setDomainName("Cash");
		request.setPayloadFormat("XML");
		request.setSubTypeName("getBillerCategories");
		request.setMessageSender("IBANK");
		request.setAggregatorTerminalId("3STC0001");
		request.setAggregatorShortCode("IS");
		
		dto.setRequestVO(request);
		
		BillerDownloadProcessService serv=context.getBean("billerDownloadProcessService",BillerDownloadProcessService.class);
		
		serv.getDataFromAggregator(dto);
	}

	
	public static String getUniqueId(){
		String id="";
		try{
			id=UUID.randomUUID().toString();
		}catch(Exception e){
			id=Long.toString(System.currentTimeMillis());
		}
		
		return id;
	}
	
	
	//@Test
		public void CountryLevelServiceTest(){
			BillerDownloadRequestCreateService service=context.getBean("billerDownloadRequestCreator",BillerDownloadRequestCreateService.class);
			
		String shortCode=	service.getVariableValue("NG", CommonConstants.AGGEREGATOR_SHORT_CODE);
		String TerminaleID=	service.getVariableValue("NG", CommonConstants.BILLERDOWNLOAD_TERMINAL_ID);
		String captureSystem =	service.getVariableValue("NG", CommonConstants.CAPTURE_SYSTEM);
		
		
		System.out.println(shortCode);
		System.out.println(TerminaleID);

		System.out.println(captureSystem);

		}
		
	
	@After
public void	destroy(){
	AbstractApplicationContext abstractContext=(AbstractApplicationContext)context;
		//abstractContext.stop();
	}
	
	
	

}
