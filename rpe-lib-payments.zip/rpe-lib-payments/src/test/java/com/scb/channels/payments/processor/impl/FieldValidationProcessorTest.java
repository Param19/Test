package com.scb.channels.payments.processor.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.qrpayments.processor.QRPaymentValidationProcessor;
 
public class FieldValidationProcessorTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(FieldValidationProcessorTest.class);
	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void getfieldValidationList() throws DAOException {			
		QRPaymentValidationProcessor qrPaymentValidationProcessor = (QRPaymentValidationProcessor) context.getBean("qrPaymentValidationProcessor");
		
		try {
			Assert.assertNotNull(qrPaymentValidationProcessor);
			qrPaymentValidationProcessor.process(getRequestPayload());	
			System.out.println("done");
		}catch (Exception e) {			
			e.printStackTrace();
		}
		
	}
	
	
	public static PayloadDTO getRequestPayload() {
		
		PayloadDTO payloadDTO = new PayloadDTO();
		
		QRPaymentRequestVO qrPaymentRequestVO=new QRPaymentRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		
		qrPaymentDetailVO.setMerchantCategoryCode("11");
		qrPaymentDetailVO.setTxnCurrencyCode("356");
		qrPaymentDetailVO.setTxnAmount(new BigDecimal("10.10"));
		qrPaymentDetailVO.setCountryCode("IN");
		qrPaymentDetailVO.setMerchantName("Test");
		qrPaymentDetailVO.setMerchantCity("Chennai");
		qrPaymentDetailVO.setCardNumber("1234567890");
		qrPaymentDetailVO.setPaymentDate(new Timestamp(2,2,2,2,2,2,2));
		qrPaymentDetailVO.setPaymentOriginateCountry("IN");
		qrPaymentDetailVO.setSourceOfFund("source");
		qrPaymentDetailVO.setTotalPaymentAmt(new BigDecimal("100.10"));
		qrPaymentDetailVO.setClient_reference("client");
		qrPaymentDetailVO.setCustomerId("1111"); 
		qrPaymentDetailVO.setCustomerType("type");
		qrPaymentDetailVO.setCustomer_first_name("fname");
		qrPaymentDetailVO.setCustomer_last_name("lname");
		qrPaymentDetailVO.setCustomer_full_name("full name");
		qrPaymentDetailVO.setCustomer_address1("address1");
		qrPaymentDetailVO.setCustomer_city("Chennai");
		qrPaymentDetailVO.setCustomer_country("IN");
		qrPaymentDetailVO.setCard_type("CC");
		
		List<QRMerchantPanTypeVO> merchantPanList=new ArrayList<QRMerchantPanTypeVO>();
		
		QRMerchantPanTypeVO qrMerchantPanTypeVO=new QRMerchantPanTypeVO();
		qrMerchantPanTypeVO.setRefId("111");
		qrMerchantPanTypeVO.setRefValue("1000");
		merchantPanList.add(qrMerchantPanTypeVO);
		
		qrPaymentDetailVO.setMerchantPanList(merchantPanList);
		
		qrPaymentRequestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		
		payloadDTO.setRequestVO(qrPaymentRequestVO);
		
		return payloadDTO;
	}
}
