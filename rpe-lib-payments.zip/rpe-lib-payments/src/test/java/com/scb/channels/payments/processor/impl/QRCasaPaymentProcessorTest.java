package com.scb.channels.payments.processor.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRCardAuthConstant;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.qrpayments.processor.QRCasaPaymentProcessor;

public class QRCasaPaymentProcessorTest {

	private static ApplicationContext context = null;

	private static final Logger LOGGER = LoggerFactory.getLogger(QRCasaPaymentProcessorTest.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void testQRCardAuth() throws FilterException, BusinessException {		
		QRCasaPaymentProcessor qrCasaPaymentProcessor = (QRCasaPaymentProcessor) context.getBean("qrCasaPaymentProcessor");
		PayloadDTO payload = getRequestPayload();
		qrCasaPaymentProcessor.processAuthorization(payload);
		Assert.assertNotNull(qrCasaPaymentProcessor);

	}
	
	//@Test
	public void testQRCardAuthReversal() throws FilterException, BusinessException {			
		QRCasaPaymentProcessor qrCasaPaymentProcessor = (QRCasaPaymentProcessor) context.getBean("qrCasaPaymentProcessor");
		PayloadDTO payload = getRequestPayload();
		qrCasaPaymentProcessor.processAuthorizationReversal(payload);
		Assert.assertNotNull(qrCasaPaymentProcessor);

	}

	public static PayloadDTO getRequestPayload() {
		PayloadDTO payload = new PayloadDTO();

		QRPaymentRequestVO requestVO = new QRPaymentRequestVO();
		QRPaymentResponseVO responseVO = new QRPaymentResponseVO();
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();

		try{
			qrPaymentDetailVO.setCountryCode("JO");
			qrPaymentDetailVO.setStan("100003");
			qrPaymentDetailVO.setHost_reference("201705091111");
			qrPaymentDetailVO.setMerchantPan("5589630000000077");
			qrPaymentDetailVO.setMerchantCategoryCode("1111");
			qrPaymentDetailVO.setSourceOfFund("CASA");
			Date expiryDate = new Date("12/05/2020");
			DateFormat expiryD = new SimpleDateFormat("yyMM");			
			qrPaymentDetailVO.setCardExpiryDate(expiryD.format(expiryDate));
			qrPaymentDetailVO.setTotalPaymentAmt(new BigDecimal("120.00"));
			qrPaymentDetailVO.setCardNumber("5589630000000077");
			qrPaymentDetailVO.setTxnCurrencyCode("400");
			qrPaymentDetailVO.setCustomer_full_name("XXX YY");
			qrPaymentDetailVO.setCard_type("MASTER");
			qrPaymentDetailVO.setTxnActStatus("SAVESUCC");
			qrPaymentDetailVO.setClient_reference("20170506000000000011");
			qrPaymentDetailVO.setPaymentDate(new Timestamp(2017,02,02,02,02,02,02));
			
			QRCardAuthConstant cardAuthConstant = new QRCardAuthConstant();
			qrPaymentDetailVO.setCardAuthConstant(cardAuthConstant);
			
			requestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			UserVO user = new UserVO();
			MessageVO message = new MessageVO();
			user.setUserId("012345678");
			user.setChannelId("IBNK");
			user.setCountry("JO");
			requestVO.setUser(user);
			message.setRequestCode("20170506000000000010");
			requestVO.setMessageVO(message);
			payload.setRequestVO(requestVO);
			payload.setResponseVO(responseVO);

		}catch(Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return payload;



	}



}
