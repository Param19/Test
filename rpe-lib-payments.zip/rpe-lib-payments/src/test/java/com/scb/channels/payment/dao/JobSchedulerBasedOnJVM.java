package com.scb.channels.payment.dao;

import static org.junit.Assert.assertNotNull;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.vo.JobsVO;
import com.scb.channels.payments.dao.BillerDownloadDAO;

public class JobSchedulerBasedOnJVM {

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] jvmList = null;
		String jvmNames = "";
		if(jvmNames != null){
			 jvmList = jvmNames.split(CommonConstants.COMMA);
		}
		if(jvmList != null && jvmList.length >0 && ArrayUtils.contains(jvmList, "JVM3")){
			System.out.println("True");
		}else{
			System.out.println("False");
		}
	}*/
	
	ApplicationContext context =null;
	
	
	@Before
	public void Intialize(){
		System.out.println("starting context");
		context = new ClassPathXmlApplicationContext("classpath:spring/payment-dao-context.xml");
	}
	

	//@Test
	public void schedulerJobtest() {
		BillerDownloadDAO bd=context.getBean("billerDownloadDAO",BillerDownloadDAO.class);
	  //  List l=bd.GetPayment();
		JobsVO job = bd.getJobDetails("ALL", "RETRY_PAYMENTS");
		System.out.println("Value from DB:::::::::"+job.getJobLastUpdated());
	   assertNotNull(job);
	   if(job!= null){
		   
		   SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm");    
		 
		   
			Long jobIdle = job.getJobLastUpdated().getTime();
			
			  Date resultdate = new Date(jobIdle);
			   System.out.println(sdf.format(resultdate));
			   
			    jobIdle = jobIdle+(60*60*1000);
			   
			   resultdate = new Date(jobIdle);
				   System.out.println(sdf.format(resultdate));
				   
			//System.out.println(job.getJobLastUpdated().getTime());
			//System.out.println(jobIdle);
			//System.out.println(System.currentTimeMillis());
			
			Long CurrentTime = System.currentTimeMillis();
			 resultdate = new Date(jobIdle);
			   System.out.println(sdf.format(CurrentTime));
			   
			//if(jobIdle > System.currentTimeMillis()){
			   if(CurrentTime > jobIdle){
				System.out.println("System.currentTimeMillis()"+sdf.format(CurrentTime));
			}
		}
	}
	
	//@Test
	public void jvmTest() {
		
	}

}
