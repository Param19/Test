 package com.scb.channels.payment.dao;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentMode;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.processor.Processor;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.payments.dao.PaymentDAO;

public class PaymentAmountTest { 

 
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentAmountTest.class);
	@Test
	public void getPaymentTotalAmount() {
 
		try {   
		//GetCustomerTotalPaymentAmountProcessor processor = context.getBean("getCustomerTotalPaymentAmountProcessor", GetCustomerTotalPaymentAmountProcessor.class) ;
			
		ApplicationContext context = TestHelper.getProcessorContext();
		Processor processor = (Processor) context.getBean("customerPaymentAmountProcessor") ;
		//ReferenceDAO dao = (ReferenceDAO) context.getBean("referenceDAO") ;
		//dao.get(null);
		PayloadDTO response = processor.process(getRequestPayload());
		 
		Assert.assertNotNull(response);
	    
		CustomerPaymentAmountResponseVO responseVO = (CustomerPaymentAmountResponseVO) response.getResponseVO();
		System.out.println("Result [" +responseVO.getPaymentAmount().getTotalPaymentAmount()+"]");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
				
	}
	
	//@Test
	public void getPaymentDAOTotalAmount(){
		
		
		ApplicationContext context=TestHelper.getDAOContext();
		
		PaymentDAO dao=	context.getBean("PaymentDAO" ,PaymentDAO.class);
		
		PaymentDetailVO VO = new PaymentDetailVO();
		
	//	 dao.getcustomerTotalPaymentAmount(VO);
		
		
	}
	//@Test	//-route
	public void test() throws InterruptedException {
		PayloadDTO bean = getRequestPayload(); 
		//String uri = "nwmq:queue:chnlNotifReqQueue";
		//NotificationCamelHelper.sendObject(bean, uri);
		//Thread.sleep(1000 * 240);
		 
		System.out.println(bean.getRequestVO());
		//String uri = "tmq:queue:CHNL.TRNFR.REQ.QUEUE";
		//String resUri = "tmq:queue:CHNL.NOTIF.REQ.QUEUE";
		
		try{
		CamelContext context = (CamelContext) TestHelper.getContext().getBean("paymentCamelConfig");
		ProducerTemplate template = context.createProducerTemplate();
	 	template.requestBody("direct:paymentOverallAmount", bean);
		//template.requestBody("direct:getCustomerOverallPaymentAmount", bean); 
		
		} catch(Exception e) {
			e.printStackTrace();
		}
		 //PaymentHistoryHelper.sendObject(bean, "direct:paymentTotalAmount");
		
		LOGGER.info("---------------------------------------------------------");
	}
	 

	//@Test //working
	public void getPaymentVOTotalAmount() throws Exception{
		
		
		ApplicationContext context=TestHelper.getDAOContext();
		
		try {
		PaymentDAO dao=	context.getBean("paymentDAO" ,PaymentDAO.class);
		
		CustomerPaymentAmountRequestVO paymentAmountRequestVO = new CustomerPaymentAmountRequestVO();
	
		paymentAmountRequestVO = (CustomerPaymentAmountRequestVO) getRequestPayload().getRequestVO();
		
		/* requestVO.getClientVO().setCountry("KE");
		 requestVO.getUser().setCustomerId("000002002");
		 requestVO.getClientVO().setDate(Calendar.getInstance());
		 requestVO.getPaymentMode().setPaymentType("CASA");
		 requestVO.getPaymentMode().setPaymentOption("I");
		 */
		 /*
		PaymentDetailVO VO = new PaymentDetailVO();
		VO.setCountryCode("KE");
		VO.setCustomerId("000002002");
	*/
		/*SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = dateFormat.parse("02/04/2016");
		VO.setPaymentDate(date);*/
		//Date date = new Date();
		//VO.setPaymentDate(new Timestamp(date.getTime()));
		 //dao.getCustomerOverallPaymentAmount(VO);
		PaymentDetailVO paymentVO = new PaymentDetailVO();
		paymentVO.setCountryCode(paymentAmountRequestVO.getClientVO().getCountry());
		paymentVO.setCustomerId(paymentAmountRequestVO.getUser().getCustomerId());
		//paymentVO.setPaymentDate(DateUtils.getDateWithoutTime(paymentAmountRequestVO.getClientVO().getDate()));
		paymentVO.setPaymentDate(new Timestamp(paymentAmountRequestVO.getClientVO().getDate().getTimeInMillis()));
		PaymentMode paymentMode = paymentAmountRequestVO.getPaymentMode();
	   	paymentVO.setPaymentType(paymentMode.getPaymentType());
		paymentVO.setPaymentOption(paymentMode.getPaymentOption());
		
		
		double result = dao.getCustomerOverallPaymentAmount(paymentVO, "SUBMITTED");
		System.out.println("result" + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		public static PayloadDTO getRequestPayload() {
		Calendar cal= DateUtils.getCountryCalendar();
		/*cal.set(Calendar.DATE, 04);
		cal.set(Calendar.MONTH, Calendar.JUNE);
		cal.set(Calendar.YEAR, 2012);*/
		CustomerPaymentAmountRequestVO request = new CustomerPaymentAmountRequestVO();
		//request request = new request();
		//BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
		//TransactionInfoVO transationInfoVO = new TransactionInfoVO();
		
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_IBNK);
		user.setCountry("KE");
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId("000008971");
		user.setCustomerType(TestHelper.CUSTOMER_TYPE);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setUserId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setPhone("+998877");
		user.setEmailId("test@scb.com");
		user.setEmailNotification(true);
		user.setInboxNotification(true);
		user.setSmsNotification(true);
		request.setUser(user);
		
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel("IBNK");
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment(TestHelper.ENVIRONMENT);
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(TestHelper.SESSION_ID);
		clientVO.setVersion(CommonConstants.VERSION);
		clientVO.setDate(cal);
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		
		request.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName(CommonConstants.CUSTOMER_OVERALL_PAYMENT_AMOUNT);
		serviceVO.setServiceTxnType("GPS");
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		
		request.setServiceVO(serviceVO);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID(ReferenceNumberGenerator.generateReferenceNumber(TestHelper.COUNTRY, "BILL", TestHelper.CHANNEL_ADC));
		messageVO.setRequestType(CommonConstants.BILL_PAYMENT);
		messageVO.setRequestCode(messageVO.getReqID());
		request.setMessageVO(messageVO);	
		
		/*BillerPayDetailsVO billerPayDetailsVO= new BillerPayDetailsVO();
		billerPayDetailsVO.setMerchantCode("TLC");
		billerPayDetailsVO.setPayRef("Y003");
		billerPayDetailsVO.setConversionRate("50.00");
		
		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setTransferCurrencyCd("KES");
		String txnAmount="1";
		transactionInfoVO.setTxnAmount(Double.valueOf(txnAmount));
		transactionInfoVO.setTransactionBranch("00800");
		transactionInfoVO.setTransferCurrencyCd("KES");
		transactionInfoVO.setTransactionType("IFT");
		BeneficiaryVO beneficiaryVO = new BeneficiaryVO();
		beneficiaryVO.setForcePostFlag("N");
		beneficiaryVO.setUniqueReferenceIdentifier(messageVO.getReqID().replaceAll(CommonConstants.HYPHEN, CommonConstants.EMPTY));
		beneficiaryVO.setCurrency("KES");
		AccountVO accountVO = new AccountVO();
		accountVO.setAccountNumber("0102058444000");
		accountVO.setCurrency("KES");*/
		/*InvoiceVO invoiceVO = new InvoiceVO();
		invoiceVO.setFromAccountNumber("7588845148");
		invoiceVO.setTransactionCurrency("SGD");
		invoiceVO.setTransactionAmount("1");
		invoiceVO.setMerchantCode("TLC");
		invoiceVO.setBillReferenceNumber("Y003");
		invoiceVO.setConversionRate("50.00");
		invoiceVO.setForcePostFlag("N");
		invoiceVO.setUniqueReferenceIdentifier("PAYMENT");
		invoiceVO.setTransactionBranch("01001");*/
		Date transactionPostingDate;
		Date date;
        Calendar cal1 = Calendar.getInstance();
        cal1.set(Calendar.MONTH, 8);
        cal1.set(Calendar.DATE, 27);
        cal1.set(Calendar.YEAR, 2013);
       
        transactionPostingDate = cal1.getTime();		
        cal1.set(Calendar.MONTH, 8);
        cal1.set(Calendar.DATE, 27);
        cal1.set(Calendar.YEAR, 2013);
       
        
        date = cal1.getTime();
       /* transactionInfoVO.setDueDate(transactionPostingDate);
        transactionInfoVO.setSourceSystemName("ADC");
        transactionInfoVO.setSuspectedTransactionFlag("N");
        transactionInfoVO.setTransactionType("IFT");
        transactionInfoVO.setTxnTypeCd("BILL");       
        transactionInfoVO.setTransferMode(CommonConstants.IMMD);
        transactionInfoVO.setDtTransfer(DateUtils.getCurrentDate());
        transactionInfoVO.setTxnId(messageVO.getReqID());*/
       // invoiceVO.setTransactionPostingDate(transactionPostingDate);
		//invoiceVO.setSourceSystemName("TEST");
		//invoiceVO.setSuspectedTransactionFlag("N");
		//invoiceVO.setTransactionType("SFC");
		//invoiceVO.setFromCurrencyCode("SGD");
		/*MakerVO maker =new MakerVO();
		maker.setBranch("01001");
		maker.setId("12334");
		maker.setIpAddress("12344");
		maker.setDate(cal);
		maker.setTime("00:00:00.000");
		transactionInfoVO.setMaker(maker );
		CheckerVO checker = new CheckerVO();
		checker.setId("12334");
		checker.setBranch("01001");
		checker.setIpAddress("1223");
		checker.setDate(cal);
		checker.setTime("00:00:00.000");*/
	/*	transactionInfoVO.setSrcAccountVO(accountVO);
		transactionInfoVO.setChecker(checker );
		List<NarrationVO> creditNarration= new ArrayList<NarrationVO>();
		NarrationVO narration= new NarrationVO();
		creditNarration.add(narration);
		transactionInfoVO.setCreditNarration(creditNarration);
		transactionInfoVO.setDebitNarration(creditNarration);
		transactionInfoVO.setBeneficiaryVO(beneficiaryVO);
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		billerPayDetailsVO.setBillerCd("1010");
		billerPayDetailsVO.setConsumerNo("42469533");
		billerPayDetailsVO.setPostPaymentAllowed("N");*/
        
        PaymentMode mode = new PaymentMode();
        mode.setPaymentType("CASA");
        request.setPaymentMode(mode);
		
        PayloadDTO payloadDTO = new PayloadDTO();
		
		payloadDTO.setRequestVO(request);
		return payloadDTO;
	}
	

}
