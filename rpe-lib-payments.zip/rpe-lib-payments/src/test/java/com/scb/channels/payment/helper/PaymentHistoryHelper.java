/**
 * 
 */
package com.scb.channels.payment.helper;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payment.helper.TestHelper;


public class PaymentHistoryHelper {
	
	private PaymentHistoryHelper() {
	}
	
	public static void sendObject(PayloadDTO payloadDTO, String uri){
		try{
		CamelContext context = (CamelContext) TestHelper.getContext().getBean("paymentCamelConfig");
		ProducerTemplate template = context.createProducerTemplate();
		template.sendBody(uri, payloadDTO);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("----------------------");
		}
	}

}
