package com.scb.channels.payment.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RandomNumberGenerator {
	
	/*

	public static void main(String[] args) {
		Random rnd = new Random();
		int n = 99999 + rnd.nextInt(900000);
		//int n = rnd.nextInt();
		System.out.println(n);
		
		System.out.println(RandomStringUtils.randomNumeric(19));
		ReferenceNumberGenerator ref = new ReferenceNumberGenerator();
		System.out.println(ref.getDate());
		System.out.println(ref.getTime());
	}
*/
	public static void main(String a[]) throws ParseException{
		
		//System.out.println(date);
		
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHH");
		//Calendar cal = Calendar.getInstance();
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		
	    String unformattedDate = dateFormat.format(date); 
	    int resultJulian = 0;
	    if(unformattedDate.length() > 0)
	    {
	     /*Days of month*/
	     int[] monthValues = {31,28,31,30,31,30,31,31,30,31,30,31};

	     String dayS, monthS, yearS, hourS;
	     /*dayS = unformattedDate.substring(0,2);
	     monthS = unformattedDate.substring(2, 4);
	     yearS = unformattedDate.substring(4, 8);
	     hourS = unformattedDate.substring(8, 10);
*/
	     
	     dayS = "10";
	     monthS = "01";
	     yearS = "2018";
	     hourS = "11";

	     /*Convert to Integer*/
	     int day = Integer.valueOf(dayS);
	     int month = Integer.valueOf(monthS);
	     int year = Integer.valueOf(yearS); 
	     //int hour = Integer.valueOf(hourS);
	         //Leap year check
	         if(year % 4 == 0)
	         {
	          monthValues[1] = 29;    
	         }
	         //Start building Julian date
	         String julianDate = "";
	         //last two digit of year: 2012 ==> 12
	         julianDate += yearS.substring(3,4);

	         int julianDays = 0;
	         for (int i=0; i < month-1; i++)
	         {
	          julianDays += monthValues[i];
	         }
	         julianDays += day;

	             if(String.valueOf(julianDays).length() < 2)
	             {
	            	 julianDate += "00";
	             }else if(String.valueOf(julianDays).length() < 3){
	                  julianDate += "0";
	             }
	            	 
	             julianDate += String.valueOf(julianDays)+hourS;
	             resultJulian =  Integer.valueOf(julianDate);
	             System.out.println("resultJulian........."+resultJulian);
	 }
	
	}
}
