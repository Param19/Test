package com.scb.channels.payment.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.scb.channels.base.helper.DateUtils;

public class JodaTimeTest {
	
@Test
public void jodaTime(){
    int resultJulian = 0;
    DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHH");
    //Date date = new Date();
    Date date = DateUtils.getCurrentDate();
   
    String inputDate = dateFormat.format(date);
    System.out.println("CurrentDate::::::::::"+inputDate);
    if(inputDate.length() > 0)
    {
     /*Days of month*/
     int[] monthValues = {31,28,31,30,31,30,31,31,30,31,30,31};

     String dayS, monthS, yearS, hourS ;
     dayS = inputDate.substring(0,2);
     monthS = inputDate.substring(2, 4);
     yearS = inputDate.substring(4, 8);
     hourS = inputDate.substring(8, 10);
  
     /*Convert to Integer*/
     int day = Integer.valueOf(dayS);
     int month = Integer.valueOf(monthS);
     int year = Integer.valueOf(yearS); 
         //Leap year check
         if(year % 4 == 0)
         {
          monthValues[1] = 29;    
         }
         //Start building Julian date
         String julianDate = "";
         //last two digit of year: 2012 ==> 12
         julianDate += yearS.substring(3,4);

         int julianDays = 0;
         for (int i=0; i < month-1; i++)
         {
          julianDays += monthValues[i];
         }
         julianDays += day;

         if(String.valueOf(julianDays).length() < 2){
              julianDate += "00";
             }
             if(String.valueOf(julianDays).length() < 3)
             {
              julianDate += "0";
             }
             julianDate += String.valueOf(julianDays)+hourS;
             resultJulian =  Integer.valueOf(julianDate); 
    	}
    	System.out.println(resultJulian);
}

}
