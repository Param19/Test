package com.scb.channels.payment.helper;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.JndiDestinationResolver;

import com.scb.channels.payments.service.TopicPostMessageService;

//import com.scb.channels.base.helper.LocatorService;

public class JmsTopicMessageSenderTest {

	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		System.out.println("Test1 &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		context = TestHelper.getContext();
		System.out.println("Test222222222222 &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
	}
	
	@Test
	public void testMessageSender(){
		//sendMessageToTopic("Test message");
		
		TopicPostMessageService topicService = (TopicPostMessageService) context.getBean("topicPostMessageService");
		//topicService.postMessage("Test Message");
		
		/*Object obj = context.getBean("payTopicInternalJndiJmsConnectionFactory");
		Assert.assertNotNull(obj);*/
	}
	
	private static void sendMessageToTopic(String messageString){

		Connection conn = null;
		Session sess  = null;
		
		try {
			/*TopicConnectionFactory conf = (TopicConnectionFactory) LocatorService.getApplicationContext()
					.getBean("payTopicJndiJmsConnectionFactory");*/
			
			/*Destination dest = (Destination)((Context) LocatorService
			.getApplicationContext().getBean("payTopicJndiJmsConnectionFactory"))
			.lookup("scbCashPaymentMobileInvoicePostPaymentV1ReqT");*/
			
			TopicConnectionFactory conf = (TopicConnectionFactory) context.getBean("payTopicJndiJmsConnectionFactory");
			System.out.println(conf.toString());
			
			DestinationResolver destinationResolver = (JndiDestinationResolver) context.getBean("payTopicJndiJmsDestinationResolver");
			
			
			/*Destination dest = (Destination)((Context) context.getBean("payTopicJndiJmsConnectionFactory"))
					.lookup("scbCashPaymentMobileInvoicePostPaymentV1ReqT");*/
			
			
			
			
			conn = conf.createConnection();
			conn.setClientID("SRM_CLIENT");
			System.out.println(conn.toString());
	
			sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Destination dest = destinationResolver.resolveDestinationName(sess, 
					"scbCashPaymentMobileInvoicePostPaymentV1ReqT", true);
			System.out.println(dest.toString());
			
			TextMessage message = sess.createTextMessage(messageString);
			MessageProducer mp = sess.createProducer(dest);
			mp.send(message);
			
			sess.close();
			conn.close();
		} catch (Exception exception) {
			if(sess != null)
				try {
					sess.close();
				} catch (JMSException e) {
					e.printStackTrace();
				}
				
			if(conn != null)
				try {
					conn.close();
				} catch (JMSException e) {
					e.printStackTrace();
				}
		}
	}
	
	
}
