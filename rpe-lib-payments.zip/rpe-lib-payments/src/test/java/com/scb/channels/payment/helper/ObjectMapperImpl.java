package com.scb.channels.payment.helper;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ObjectMapperImpl extends ObjectMapper {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ObjectMapperImpl(){
		
		_serializationConfig = getSerializationConfig().withSerializationInclusion(Include.NON_NULL);
	}
	
}
