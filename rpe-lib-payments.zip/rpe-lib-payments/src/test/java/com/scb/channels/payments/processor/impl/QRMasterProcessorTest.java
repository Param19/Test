package com.scb.channels.payments.processor.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.regex.Pattern;

import javax.ws.rs.core.HttpHeaders;

import oauth.signpost.OAuth;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.http.HttpParameters;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentMasterCardAcceptor;
import com.scb.channels.base.vo.QRPaymentMasterFundingCard;
import com.scb.channels.base.vo.QRPaymentMasterReceivingAmount;
import com.scb.channels.base.vo.QRPaymentMasterRequest;
import com.scb.channels.base.vo.QRPaymentMasterRequestV3;
import com.scb.channels.base.vo.QRPaymentMasterSenderAddress;
import com.scb.channels.base.vo.QRPaymentMasterSenderName;
import com.scb.channels.base.vo.QRPaymentReceivingCard;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.qrpayments.security.oauth.HttpMethod;
import com.scb.channels.qrpayments.security.oauth.OAuthRequest;
import com.scb.channels.qrpayments.security.oauth.OAuthSignException;
import com.scb.channels.qrpayments.security.oauth.OAuthSigner;

public class QRMasterProcessorTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(QRMasterProcessorTest.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		PayloadDTO payload = getRequestPayload();
		String jsonRequest = buildRequest(payload);
		String header = buildAuthorizationHeader(jsonRequest);
		sign(header,jsonRequest);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception occurred ::: ",e);
		}
		
	}

	public static PayloadDTO getRequestPayload() {
		PayloadDTO payload = new PayloadDTO();
		
		QRPaymentRequestVO requestVO = new QRPaymentRequestVO();
		QRPaymentResponseVO responseVO = new QRPaymentResponseVO();
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		
		try{
		qrPaymentDetailVO.setCountryCode("IN");
		qrPaymentDetailVO.setStan("345678");
		qrPaymentDetailVO.setHost_reference("201802260002");
		qrPaymentDetailVO.setMerchantPan("5299920381212123");
		qrPaymentDetailVO.setSourceOfFund("CARD");
		Date expiryDate = new Date();
		DateFormat expiryD = new SimpleDateFormat("yyMM");
		qrPaymentDetailVO.setCardExpiryDate(expiryD.format(expiryDate));
		/*Date paymentDate = new Date();
		DateFormat paymentD = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}*/
		qrPaymentDetailVO.setPaymentDate(new Timestamp(System.currentTimeMillis()));
		qrPaymentDetailVO.setTotalPaymentAmt(new BigDecimal("120.00"));
		qrPaymentDetailVO.setCardNumber("4940767011788964");
		qrPaymentDetailVO.setTxnCurrencyCode("356");
		qrPaymentDetailVO.setCustomer_first_name("Arasu");
		qrPaymentDetailVO.setCustomer_last_name("G");
		qrPaymentDetailVO.setCustomer_full_name("XXX YY");
		qrPaymentDetailVO.setCustomer_state("TN");
		qrPaymentDetailVO.setCustomer_zipCode("600126");
		qrPaymentDetailVO.setMerchantCity("Pune");
		qrPaymentDetailVO.setMerchantPostalCode("2000001");
		qrPaymentDetailVO.setCard_type("VISA");
		qrPaymentDetailVO.setCustomer_address1("plot no 6");
		qrPaymentDetailVO.setCustomer_city("chennai");
		qrPaymentDetailVO.setMaid("1234");
		qrPaymentDetailVO.setMerchantCategoryCode("5016");
		requestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		payload.setRequestVO(requestVO);
		payload.setResponseVO(responseVO);
		
		}catch(Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return payload;
	}
	
public static String buildRequest(PayloadDTO payload) throws Exception{
		
		QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
		String masterCardRequestJson = null;

		try{
		QRPaymentMasterRequest qrPaymentMasterRequest = new QRPaymentMasterRequest();
		QRPaymentMasterRequestV3 qrPaymentMasterRequestV3 =  new QRPaymentMasterRequestV3();
		QRPaymentMasterCardAcceptor qrPaymentMasterCardAcceptor = new QRPaymentMasterCardAcceptor();
		QRPaymentMasterFundingCard qrPaymentMasterFundingCard = new QRPaymentMasterFundingCard();
		QRPaymentMasterReceivingAmount qrPaymentMasterReceivingAmount =  new QRPaymentMasterReceivingAmount();
		QRPaymentMasterSenderAddress qrPaymentMasterSenderAddress =  new QRPaymentMasterSenderAddress();
		QRPaymentMasterSenderName qrPaymentMasterSenderName = new QRPaymentMasterSenderName();
		QRPaymentReceivingCard qrPaymentReceivingCard =  new QRPaymentReceivingCard();
		qrPaymentDetailVO.setHost_system(CommonConstants.MASTER+" - "+"MerchantPayment");
	       DateFormat timeFormat = new SimpleDateFormat("HHmmss");
	       DateFormat dateFormat = new SimpleDateFormat("MMdd");
	       qrPaymentMasterRequestV3.setLocalTime(timeFormat.format(qrPaymentDetailVO.getPaymentDate()));
	       qrPaymentMasterRequestV3.setLocalDate(dateFormat.format(qrPaymentDetailVO.getPaymentDate()));
	       qrPaymentMasterRequestV3.setTransactionReference("0000000"+qrPaymentDetailVO.getHost_reference());
	       if(qrPaymentDetailVO.getSourceOfFund().equalsIgnoreCase(CommonConstants.CASA)){
	    	   qrPaymentMasterRequestV3.setFundingSource(CommonConstants.MASTER_FUNDING_SOURCE_DEBIT);	   
	       }else{
	    	   qrPaymentMasterRequestV3.setFundingSource(CommonConstants.MASTER_FUNDING_SOURCE_CREDIT);
	       }
	       qrPaymentMasterRequestV3.setLanguageIdentification(CommonConstants.LANGUAGE_IDENTIFICATION);
	       qrPaymentMasterRequestV3.setChannel(CommonConstants.QR_CHANNEL);
	       /**Condition for checking the card type & setting values accordingly*/
	       /**Creating a combined string for country + card type (MASTER or VISA) + source of fund (CASA or CARD)*/

	       qrPaymentMasterRequestV3.setICA("11213");
	       qrPaymentMasterRequestV3.setProcessorId("9000002125");
	       qrPaymentMasterRequestV3.setRoutingAndTransitNumber("935621253");
	       qrPaymentMasterRequestV3.setMerchantId("935621253");

	       qrPaymentMasterRequestV3.setTransactionDesc(CommonConstants.MASTER_TRANSACTION_DESC);
	       qrPaymentMasterSenderName.setFirst(qrPaymentDetailVO.getCustomer_first_name());
	       //qrPaymentMasterSenderName.setMiddle("");
	       qrPaymentMasterSenderName.setLast(qrPaymentDetailVO.getCustomer_last_name());
	       qrPaymentMasterRequestV3.setSenderName(qrPaymentMasterSenderName);
	       
	       qrPaymentMasterSenderAddress.setLine1(qrPaymentDetailVO.getCustomer_address1());
	       qrPaymentMasterSenderAddress.setCity(qrPaymentDetailVO.getCustomer_city());
	       qrPaymentMasterSenderAddress.setCountrySubdivision(qrPaymentDetailVO.getCustomer_state());
	       qrPaymentMasterSenderAddress.setPostalCode(qrPaymentDetailVO.getCustomer_zipCode());
	       qrPaymentMasterSenderAddress.setCountry("IND");
	       qrPaymentMasterRequestV3.setSenderAddress(qrPaymentMasterSenderAddress);
	       //CardNumber
	       qrPaymentMasterFundingCard.setAccountNumber(qrPaymentDetailVO.getCardNumber());
	       qrPaymentMasterRequestV3.setFundingCard(qrPaymentMasterFundingCard);

       		BigDecimal amount = qrPaymentDetailVO.getTotalPaymentAmt() != null ?        	
       				qrPaymentDetailVO.getTotalPaymentAmt() : new BigDecimal(CommonConstants.ZERO);
       	
       		String strAmount = (Arrays.asList((String.valueOf(
               			amount.multiply(new BigDecimal(100))).
               			        split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
       		
	       qrPaymentMasterReceivingAmount.setValue(strAmount);
	       qrPaymentMasterReceivingAmount.setCurrency(qrPaymentDetailVO.getTxnCurrencyCode());
	       qrPaymentMasterRequestV3.setReceivingAmount(qrPaymentMasterReceivingAmount);
	       //Merchant PAN
	       qrPaymentReceivingCard.setAccountNumber(qrPaymentDetailVO.getMerchantPan());
	       qrPaymentMasterRequestV3.setReceivingCard(qrPaymentReceivingCard);
	       String strMaid = qrPaymentDetailVO.getMaid() != null ? qrPaymentDetailVO.getMaid() : "";
	       qrPaymentMasterCardAcceptor.setName(qrPaymentDetailVO.getCardNumber().substring(0, 10)+qrPaymentDetailVO.getMerchantCategoryCode()+strMaid+"  ");
	       qrPaymentMasterCardAcceptor.setCity(qrPaymentDetailVO.getMerchantCity());
	       qrPaymentMasterCardAcceptor.setPostalCode(qrPaymentDetailVO.getMerchantPostalCode());
	       qrPaymentMasterCardAcceptor.setCountry("IND");
	       qrPaymentMasterRequestV3.setCardAcceptor(qrPaymentMasterCardAcceptor);
	       qrPaymentMasterRequestV3.setAdditionalMessage(qrPaymentDetailVO.getAdditionalField());
	       qrPaymentMasterRequest.setPaymentRequestV3(qrPaymentMasterRequestV3);
	       ObjectMapper mapper = new ObjectMapper();
	       mapper.setSerializationInclusion(Include.NON_NULL);
		//mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		try {
			masterCardRequestJson = mapper.writeValueAsString(qrPaymentMasterRequest);
			 //System.out.println("Master Card Request  :::: "+qrPaymentDetailVO.getClient_reference()+" JSON :: "+masterCardRequestJson);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception occurred ::: ",e);
		}
		 //System.out.println("Master Card Request JSON ::::"+masterCardRequestJson);
		
		}catch(Exception e){
			LOGGER.error("Exception occurred ::: ",e);
		}
		return masterCardRequestJson;
		}

public static String buildAuthorizationHeader(String payload) throws URISyntaxException, ClientProtocolException, IOException{
	
	   String consumerKey = "5z157q9bT2EFkJVg47x2zMVPsd1-Q7bZghCUoWCT19fa7611!72a6674e7aab40648adfea9ee6c3f22b0000000000000000";//DC
	   OAuthRequest request = new OAuthRequest();
       request.setMethod(HttpMethod.POST);
       request.setRequestUrl("https://sandbox.api.mastercard.com/moneysend/v3/transfer?Format=JSON");
       request.setContentType(ContentType.APPLICATION_JSON);
       request.setBody((String) payload);
       HttpParameters params = new HttpParameters();
       try {
           params.put("oauth_body_hash", request.getOauthBodyHash(), true);
       }
       catch (Exception e) {
           throw new OAuthSignException(e.getMessage(), e);
       }
       PrivateKey pkey = setP12();
       OAuthSigner oAuthSigner = new OAuthSigner(pkey);
       // Create OAuthConsumer
       OAuthConsumer oAuthConsumer = new DefaultOAuthConsumer(consumerKey, "");
       oAuthConsumer.setMessageSigner(oAuthSigner);
       oAuthConsumer.setAdditionalParameters(params);
        try {
            oAuthConsumer.sign(request);
        }
        
        catch (Exception e) {
            throw new OAuthSignException(e.getMessage(), e);
        }
        return request.getHeader(OAuth.HTTP_AUTHORIZATION_HEADER);
        
    }
 private static PrivateKey setP12() throws OAuthSignException {
	 
		String file= "C:/Data/QR_Payments/Master_P12/SCB_IN_QR_ICA_11213-1488191518-sandbox.p12";
        try {
        	PrivateKey privateKey;
        	InputStream is = new FileInputStream(file);
        	String keyAlias = "keyalias";   
        	String keyPassword = "keystorepassword";
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(is, keyPassword.toCharArray());
            privateKey = (PrivateKey) ks.getKey(keyAlias, keyPassword.toCharArray());
            if (privateKey == null) {
                throw new OAuthSignException("No key found for alias ["+ keyAlias +"]");
            }
            return privateKey;
        } catch (Exception e) {
            throw new OAuthSignException(e.getMessage(), e);
        }
    }
 
 private static void sign(String AuthorizationHeader,String payload) throws URISyntaxException, ClientProtocolException, IOException{
	 HttpClient client = HttpClientBuilder.create().build();
      String url = "http://10.20.175.103:10084/external/mastercard/dr";
      HttpPost post = new HttpPost(url);
      post.setHeader("Authorization", AuthorizationHeader);
      post.setHeader("OutboundURL","https://sandbox.api.mastercard.com/moneysend/v3/transfer?Format=JSON");
      post.setHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_JSON.getMimeType());   
      post.setHeader(HttpHeaders.ACCEPT, ContentType.APPLICATION_JSON.getMimeType());
      StringEntity entity = new StringEntity(payload);
      post.setEntity(entity);
      HttpResponse httpResponse = client.execute(post);
      HttpEntity httpEntity = httpResponse.getEntity();
      String response = EntityUtils.toString(httpEntity);

  }
	
}
