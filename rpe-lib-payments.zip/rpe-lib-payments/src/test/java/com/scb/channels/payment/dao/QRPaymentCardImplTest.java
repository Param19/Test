package com.scb.channels.payment.dao;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.Assert;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.qrpayments.processor.QRCardAuthorizationProcessor;

public class QRPaymentCardImplTest {

	private static ApplicationContext context = null;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentCardImplTest.class);

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getProcessorContext();
		//context = TestHelper.getContext();
	}

	//@Test
	public void testPayBill() throws Exception {
		
		CamelContext camelContext = (CamelContext) context.getBean("paymentCamelConfig");
		Assert.assertNotNull(camelContext);
		
		ProducerTemplate template = camelContext.createProducerTemplate();
		PayloadDTO payload = getRequestPayload();
		Object obj = template.requestBody("direct:makeQRPayment",payload);
		
		//Object obj = template.requestBody("direct:paymentResponseTopic",readFile());
		
		//Object obj = template.requestBody("direct:paymentRetry", "TEst");
		
		Assert.assertNotNull(obj);
		//System.out.println("Response.........."+obj.toString());
	}
	
	//@Test
	public void testQRCardAuth() throws FilterException, BusinessException {
		//context = TestHelper.getContext();
		QRCardAuthorizationProcessor qrPaymentRetryProcessor = (QRCardAuthorizationProcessor) context.getBean("qrCardAuthorizationProcessor");
		PayloadDTO payload = getRequestPayload();
		qrPaymentRetryProcessor.processAuthorization(payload);
		Assert.assertNotNull(qrPaymentRetryProcessor);
		
	}
	@Test
	public void testQRCardAuthReversal() throws FilterException, BusinessException {
			//context = TestHelper.getContext();
			QRCardAuthorizationProcessor qrPaymentRetryProcessor = (QRCardAuthorizationProcessor) context.getBean("qrCardAuthorizationProcessor");
			PayloadDTO payload = getRequestPayload();
			qrPaymentRetryProcessor.processAuthorizationReversal(payload);
			Assert.assertNotNull(qrPaymentRetryProcessor);
			
		}
	public static PayloadDTO getRequestPayload() {
		PayloadDTO payload = new PayloadDTO();
		
		QRPaymentRequestVO requestVO = new QRPaymentRequestVO();
		//QRPaymentResponseVO responseVO = new QRPaymentResponseVO();
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		
		try{
		//System.out.println("Inside QR Payment Processor buildVISARequest Start ::::");
		UserVO user = new UserVO();
		requestVO.setUser(user);
		requestVO.getUser().setChannelId("IBNK");
		requestVO.getUser().setCountry("IN");
		requestVO.getUser().setCustomerId("123456789");
		 
		MessageVO messageVO = new MessageVO();
		requestVO.setMessageVO(messageVO);
		
		requestVO.getMessageVO().setRequestCode("QRPayment");
		qrPaymentDetailVO.setTxnActStatus("SAVESUCC");
		qrPaymentDetailVO.setSourceOfFund("CARD");
		qrPaymentDetailVO.setCountryCode("IN");
		qrPaymentDetailVO.setStan("345678");
		//qrPaymentDetailVO.setCard_type("VISA");
		qrPaymentDetailVO.setHost_reference("201704040004");
		qrPaymentDetailVO.setClient_reference("201704040004");
		qrPaymentDetailVO.setMerchantPan("5404608010916261");
		qrPaymentDetailVO.setTotalPaymentAmt(new BigDecimal("100.00"));
		qrPaymentDetailVO.setCardNumber("5404608010916261");
		qrPaymentDetailVO.setTxnCurrencyCode("356");
		qrPaymentDetailVO.setCustomer_full_name("XXX YY");
		qrPaymentDetailVO.setCard_type("MASTER");
		String date ="2021-12-12";
		SimpleDateFormat dt = new SimpleDateFormat("yyyyy-MM-dd");
		Date d = dt.parse(date);
		DateFormat expiryD = new SimpleDateFormat("yyMM");
		//System.out.println("Card Expiry Date.............."+expiryD.format(d));
		qrPaymentDetailVO.setCardExpiryDate(expiryD.format(d));
		requestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		payload.setRequestVO(requestVO);
		
		}catch(Exception e) {
			//System.out.println("Inside Exception Block");
			LOGGER.error("Exception occurred ::: ",e);
		}
		return payload;
		
		
		
	}



}
