package com.scb.channels.payment.dao;

import static org.junit.Assert.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.base.vo.TempBillerVO;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.dao.BillerManagementDAO;
 
public class paymentTestDao {
	
	
	ApplicationContext context =null;
	
	
	@Before
	public void Intialize(){
		System.out.println("starting context");
		context = new ClassPathXmlApplicationContext("classpath:spring/payment-dao-context.xml");
	}
	

	//@Test
	public void BillerCategorytest() {
		BillerManagementDAO bd=context.getBean("billerManagementDAO",BillerManagementDAO.class);
	  //  List l=bd.GetPayment();
		List l=bd.getActiveBillerCategories("NG");
		System.out.println(l);
	   assertNotNull(l);
	}
	
	//@Test
	public void ActiveBillersList() {
		  
		BillerManagementDAO bd=context.getBean("billerManagementDAO",BillerManagementDAO.class);
	  //  List l=bd.GetPayment();
	   
		List<BillerVO> l=bd.GetBillers("NG", "1");
		
		System.out.println(l);
		 for(BillerVO b:l){
			 
			 System.out.println("fields ....."+b.getBillerFields());
			 
		 }
		 assertNotNull(l);
	}
	
	 @Test
		public void saveBillerCategorytest() {
			BillerDownloadDAO bd=context.getBean("billerDownloadDAO",BillerDownloadDAO.class);
		   
			List<TempBillerCategoryVO> aggregatorlist= new ArrayList<TempBillerCategoryVO>();
			TempBillerCategoryVO tv1=new TempBillerCategoryVO();
				TempBillerVO tb1=new TempBillerVO();
				TempBillerVO tb2=new TempBillerVO();

				tb1.setBillerDesc("a");
				tb1.setBillerProductName("a");
				tb1.setAggregatePaymentCode("0");
				tb1.setBillerTypeCode("asdas");
				tb1.setBillerShortName("asdefasd");
				tb1.setBillerTypeCode("123123");
				tb1.setBillerUniqueId("123");
				tb1.setBillPresentmentType("1");
				tb1.setPaymentType("asd");
				tb1.setAggregatePaymentCode("12312");
				tb1.setChannel("IBANK");
				tb1.setCurrency("asdfasd");
				tb1.setCreatedBy("SYSTEM");
				tb1.setCategorytype(tv1);
				tb1.setUpdatedBy("SYSTEM");
				tb1.setBillerId("12asdas3");
				tb1.setCountryCode("NG");
				tb1.setStatusCode("A");
				
				tb2.setBillerDesc("a");
				tb2.setBillerProductName("a");
				tb2.setAggregatePaymentCode("0");
				tb2.setBillerTypeCode("asdas");
				tb2.setBillerShortName("asdefasd");
				tb2.setBillerTypeCode("asdfasd");
				tb2.setBillerUniqueId("asdfads");
				tb2.setBillPresentmentType("1");
				tb2.setPaymentType("asd");
				tb2.setAggregatePaymentCode("12312");
				tb2.setChannel("IBANK");
				tb2.setCurrency("asdfasd");
				tb2.setCreatedBy("SYSTEM");
				tb2.setCategorytype(tv1);
				tb2.setUpdatedBy("SYSTEM");
				tb2.setBillerId("12312");
				tb2.setCountryCode("NG");
				tb2.setStatusCode("A");
				tv1.getBillers().add(tb1);
				tv1.getBillers().add(tb2);
				tv1.setCategoryId("as");
				
				 
				tv1.setCategoryName("asdas");
				tv1.setChannel("IBANK");
				tv1.setCountryCode("NG");
				tv1.setDateCreated(new Date(System.currentTimeMillis()));
				tv1.setDateUpdated(new Date(System.currentTimeMillis()));
			aggregatorlist.add(tv1);
		 	bd.saveAggregatorData(aggregatorlist);
			 
		}

}
