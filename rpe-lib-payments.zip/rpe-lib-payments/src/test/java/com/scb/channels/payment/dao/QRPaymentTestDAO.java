package com.scb.channels.payment.dao;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.vo.QRMerchantVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.qrpayments.dao.MerchantDAO;
import com.scb.channels.qrpayments.dao.QRPaymentDAO;

public class QRPaymentTestDAO {


 
	
	public static  ApplicationContext getcontext(){
		ApplicationContext ap = new ClassPathXmlApplicationContext("/spring/payment-dao-context.xml");
		return ap;
		
	}
	
	@Test
		public void test() throws Exception {
			ApplicationContext context=	getcontext();
			assertNotNull(context);
			MerchantDAO merchantDAO = context.getBean("merchantDAO",MerchantDAO.class);
			
			QRPaymentDAO qrPaymentDAO =	context.getBean("qrPaymentDAO",QRPaymentDAO.class);
			QRPaymentVO qrPayment = new QRPaymentVO();
			QRMerchantVO merchantVO = new QRMerchantVO();
			
			merchantVO.setMerchant_name("CHROME");
			merchantVO.setMerchant_city("CHENNAI");
			merchantVO.setMerchant_pan("55632443333444");
			merchantVO.setMerchant_category_code("4323");
			merchantVO.setMerchant_postcode("600001");
			merchantVO.setNetwork("MASTER");
			//qrPayment.setMerchantVO(merchantVO);
			//merchantVO = (MerchantVO) merchantDAO.getMerchant(merchantVO);
			System.out.println("###############"+merchantVO);
			qrPayment.setCountry_code("IN");
			qrPayment.setCustomer_id("02121222");
			qrPayment.setCustomer_type("01");
			qrPayment.setCard_number("5546232906653342");
			qrPayment.setTxn_currency_code("356");
			qrPayment.setClient_reference("20170405666335");
			qrPayment.setHost_reference("20170405666335");
			qrPayment.setSystem_trace_audit_number("100056");
			qrPayment.setPayment_amount(new BigDecimal(10.10));
			qrPayment.setFee_amount(new BigDecimal(10.05));
			qrPayment.setTotal_amount(new BigDecimal(20.15));
			qrPayment.setPayment_date(new Timestamp(2017-03-01));
			qrPayment.setPayment_type("CARD");
			qrPayment.setPayment_status("AGGSUCC");
			qrPayment.setPayment_orginate_country("IN");
			//qrPayment.setHost_system("VISA");
			qrPayment.setHost_status_cd("00");
			qrPayment.setHost_status_desc("APPROVED");
			qrPayment.setCard_type("MASTER");
			System.out.println("PaymentAmount......."+qrPayment.getPayment_amount());
			qrPaymentDAO.savePayment(qrPayment);
			
			/*MerchantDAO merchantDAO1 = context.getBean("merchantDAO",MerchantDAO.class);
			
			QRPaymentDAO qrPaymentDAO1 =	context.getBean("qrPaymentDAO",QRPaymentDAO.class);
			QRPaymentVO qrPayment1 = new QRPaymentVO();
			QRMerchantVO merchantVO1 = new QRMerchantVO();
			
			merchantVO1.setMerchant_name("BIGBASKET");
			merchantVO1.setMerchant_city("BANGLORE");
			merchantVO1.setMerchant_pan("456322263232323");
			merchantVO1.setMerchant_category_code("6102");
			merchantVO1.setMerchant_postcode("578001");
			qrPayment1.setMerchantVO(merchantVO1);
			//merchantVO = (MerchantVO) merchantDAO.getMerchant(merchantVO);
			System.out.println("###############"+merchantVO);
			qrPayment1.setCountry_code("IN");
			qrPayment1.setCustomer_id("02121222");
			qrPayment1.setCustomer_type("01");
			qrPayment1.setCard_number("44462999996653342");
			qrPayment1.setTxn_currency_code("356");
			qrPayment1.setClient_reference("201703022211136");
			qrPayment1.setHost_reference("20170322987222232310");
			qrPayment1.setSystem_trace_audit_number("123456");
			qrPayment1.setPayment_amount(new BigDecimal(170));
			qrPayment1.setFee_amount(new BigDecimal(10));
			qrPayment1.setTotal_amount(new BigDecimal(180));
			qrPayment1.setPayment_date(new Timestamp(2017-03-11));
			qrPayment1.setPayment_type("CARD");
			qrPayment1.setPayment_status("AGGFAIL");
			qrPayment1.setPayment_orginate_country("IN");
			qrPayment1.setHost_system("MASTER");
			qrPayment1.setHost_status_cd("01");
			qrPayment1.setHost_status_desc("DECLINED");
			qrPayment.setHost_reason_code("0");		
			qrPaymentDAO1.savePayment(qrPayment1);*/
									
		}
	
	//@Test
	public void test1() {
		ApplicationContext context=	getcontext();
		assertNotNull(context);
		MerchantDAO merchantDAO = context.getBean("merchantDAO",MerchantDAO.class);
		
		QRPaymentDAO qrPaymentDAO =	context.getBean("qrPaymentDAO",QRPaymentDAO.class);
		QRPaymentVO qrPayment = new QRPaymentVO();
		qrPayment.setHost_reference("2017030800009");
		//QRMerchantVO merchantVO = new QRMerchantVO();
		QRPaymentVO dbQRPayment = qrPaymentDAO.getQRPaymentDetails(qrPayment.getHost_reference());
		System.out.println(dbQRPayment.toString());
		dbQRPayment.setCard_number("5546888877779999");
		dbQRPayment.setSystem_trace_audit_number("765432");
		dbQRPayment.setPayment_status("SAVESUCC");
		/*QRMerchantVO merchantVO = dbQRPayment.getMerchantVO();
		merchantVO.setMerchant_name("BIGBASKET");
		merchantVO.setMerchant_city("BANGLORE");
		merchantVO.setMerchant_pan("456322263232323");
		merchantVO.setMerchant_category_code("6102");
		merchantVO.setMerchant_postcode("578001");
		merchantVO.setNetwork("VISA");
		dbQRPayment.setMerchantVO(merchantVO);
		qrPaymentDAO.updatePaymentStatus(dbQRPayment);*/
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		String referenceNo = qrPaymentDAO.getQRReferenceNumber(qrPaymentDetailVO);
		System.out.println("Reference.........."+referenceNo);
		
}
	
	//@Test
	public void HistoryTest(){
		
		ApplicationContext context=	getcontext();
		assertNotNull(context);
		MerchantDAO merchantDAO = context.getBean("merchantDAO",MerchantDAO.class);
		QRPaymentDAO qrPaymentDAO =	context.getBean("qrPaymentDAO",QRPaymentDAO.class);
		QRPaymentHistoryRequestVO request = new QRPaymentHistoryRequestVO();
		UserVO user = new UserVO();
		user.setCustomerId("02121222");
		user.setCountry("IN");
		request.setUser(user);
		List<QRPaymentVO> qrPaymentList = qrPaymentDAO.getPaymentHistoryByCustId(request);
		System.out.println(qrPaymentList.toString());
	}
}
