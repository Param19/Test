package com.scb.channels.payment.dao;

import java.util.Calendar;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.payments.dao.BillerDownloadDAO;

public class BillerDownloadStatusCheckTest {
	
	private static ApplicationContext context = null;

	
	@Before
	public void IntializeContext(){
		
		context=new ClassPathXmlApplicationContext("/spring/payment-dao-context.xml");
	}
	
	@Test
	public void testBillerCategoriesCountryCOunt(){
		BillerDownloadDAO dao=context.getBean("billerDownloadDAO",BillerDownloadDAO.class);
		 
		BillerDownloadRequest billerDownloadRequest = new BillerDownloadRequest();
		UserVO user = new UserVO();
		user.setCountry("KE");
		billerDownloadRequest.setUser(user);
		
		try{
			
			BillerDownloadResponseVO billerDownloadResponseVO = dao.getBillerDownloadStatusCheck(billerDownloadRequest);
			System.out.println("---------------- Response is --------------- "+ billerDownloadResponseVO.getStatus());
			
		}catch(Exception e){
			
			e.printStackTrace();
		}
		/*getAllMasterBillersforCountry*/
	}
}

