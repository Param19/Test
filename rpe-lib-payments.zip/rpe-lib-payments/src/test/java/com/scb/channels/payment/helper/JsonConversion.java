package com.scb.channels.payment.helper;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.vo.QRPaymentVisaCardAcceptor;
import com.scb.channels.base.vo.QRPaymentVisaCardAcceptorAddress;
import com.scb.channels.base.vo.QRPaymentVisaRequest;

public class JsonConversion {
	private static final Logger LOGGER = LoggerFactory.getLogger(JsonConversion.class);
	@Test
	public   void parseJson() {
		// TODO Auto-generated method stub
		String json = null;
		QRPaymentVisaRequest qrPaymentVisaRequest = new QRPaymentVisaRequest();
		QRPaymentVisaCardAcceptor qrPaymentVisaCardAcceptor = new QRPaymentVisaCardAcceptor();
		QRPaymentVisaCardAcceptorAddress qrPaymentVisaCardAcceptorAddress = new QRPaymentVisaCardAcceptorAddress();
		//QRPaymentRequestVO qrPaymentRequestVO= (QRPaymentRequestVO)payload.getRequestVO();
		//QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
		//QRPaymentVisaPurchaseIdentifier QRPaymentVisaPurchaseIdentifier = new QRPaymentVisaPurchaseIdentifier();
		qrPaymentVisaCardAcceptorAddress.setCountry("IN");
		qrPaymentVisaCardAcceptorAddress.setCity("mVisa payment");
		qrPaymentVisaCardAcceptor.setIdCode("CA-IDCode-77765");
		qrPaymentVisaCardAcceptor.setName("mVisa merchant");
		qrPaymentVisaCardAcceptor.setAddress(qrPaymentVisaCardAcceptorAddress);
		qrPaymentVisaRequest.setSystemsTraceAuditNumber("123456");
		qrPaymentVisaRequest.setRetrievalReferenceNumber("123456789");
		qrPaymentVisaRequest.setRecipientPrimaryAccountNumber("123132131231");
		qrPaymentVisaRequest.setMerchantCategoryCode("6012");
		qrPaymentVisaRequest.setAmount(new BigDecimal(100.00));
		
		SimpleDateFormat paymentDateFormat = new SimpleDateFormat("yyyy-mm-dd");
		//qrPaymentVisaRequest.setLocalTransactionDateTime(paymentDateFormat.new Timestamp(System.currentTimeMillis()));
		qrPaymentVisaRequest.setAcquiringBin("476137");
		qrPaymentVisaRequest.setAcquirerCountryCode("356");
		qrPaymentVisaRequest.setTransactionCurrencyCode("356");
		qrPaymentVisaRequest.setBusinessApplicationId("MP");
		qrPaymentVisaRequest.setSenderAccountNumber("45454645646");
		qrPaymentVisaRequest.setSenderName("xxxxxx");
		qrPaymentVisaRequest.setCardAcceptor(qrPaymentVisaCardAcceptor);
		ObjectMapper objectMapper = new ObjectMapper();
		
			try {
				json = objectMapper.writeValueAsString(qrPaymentVisaRequest);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		System.out.println("Response---------------"+json.toString());
		
		
	}

}
