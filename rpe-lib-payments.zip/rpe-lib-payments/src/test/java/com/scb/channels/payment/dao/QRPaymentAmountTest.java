package com.scb.channels.payment.dao;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.regex.Pattern;

import com.scb.channels.base.helper.CommonConstants;

public class QRPaymentAmountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BigDecimal b = new BigDecimal(10.60);
		String amount = b.toString();
		double d = Double.parseDouble(amount)*100;
		System.out.println(d);
		System.out.println(b.multiply(new BigDecimal(100)));
		
		String strAmount = (Arrays.asList((String.valueOf(
    			b.multiply(new BigDecimal(100))).
    			        split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
	System.out.println(strAmount);
	}
	

}
