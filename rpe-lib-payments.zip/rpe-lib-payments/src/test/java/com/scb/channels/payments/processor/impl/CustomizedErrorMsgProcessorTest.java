package com.scb.channels.payments.processor.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import scala.Array;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BeneficiaryVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.ClientContext;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.MessageContext;
import com.scb.channels.common.ServiceContext;
import com.scb.channels.common.StatusType;
import com.scb.channels.common.UserContext;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.Processor;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.payments.processor.CustomizedMessageProcessor;
import com.scb.channels.payments.processor.PaymentRetryListProcessor;
import com.scb.channels.paymentservice.PaymentResponse;

public class CustomizedErrorMsgProcessorTest {

	private static ApplicationContext context = null;

	
	@Test
	public void testObjectPresent() throws FilterException, BusinessException {
		context = TestHelper.getContext();
		CustomizedMessageProcessor custMsgProcessor = (CustomizedMessageProcessor) context.getBean("customizedMessageProcessor");
		custMsgProcessor.process(getRequestPayload());
		System.out.println("------------------------");
		Assert.assertNotNull(custMsgProcessor);
	}

	public static PaymentResponse getRequestPayload() {
		Calendar cal= DateUtils.getCountryCalendar();
		
		PaymentResponse paymentResponse = new PaymentResponse();
		
		UserContext user = new UserContext();
		
		user.setCustName(TestHelper.CUST_NAME);
		//user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerId("000008971");
		user.setCustomerType(TestHelper.CUSTOMER_TYPE);
		user.setRole(TestHelper.ROLE);
		paymentResponse.setUserContext(user);
		
		
		ClientContext clientVO = new ClientContext();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel("IBNK");
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment(TestHelper.ENVIRONMENT);
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(TestHelper.SESSION_ID);
		clientVO.setVersion(CommonConstants.VERSION);
	
		paymentResponse.setClientContext(clientVO);
		
		ServiceContext serviceVO = new ServiceContext();
		serviceVO.setServiceName("BILL");
		serviceVO.setServiceTxnType("GPS");
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		
		paymentResponse.setServiceContext(serviceVO);
		
		MessageContext messageVO = new MessageContext();
		messageVO.setReqID("KE-016-151223-191833313-492394-012");
		messageVO.setRequestType(CommonConstants.BILL_PAYMENT);
		messageVO.setRequestCode("KE-016-151223-191833313-492394-012");
		paymentResponse.setMessageContext(messageVO);	
		
		
		StatusType st = new StatusType();
		st.setStatusCode("100");
		st.setStatusDesc("Success");
		
	    
	
		paymentResponse.setStatus(st);
		
		return paymentResponse;
	}
}
