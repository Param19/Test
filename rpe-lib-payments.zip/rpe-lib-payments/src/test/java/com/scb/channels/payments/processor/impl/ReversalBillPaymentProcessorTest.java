package com.scb.channels.payments.processor.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.Processor;
import com.scb.channels.payment.helper.PaymentHistoryHelper;
import com.scb.channels.payment.helper.TestHelper;

public class ReversalBillPaymentProcessorTest {
	
	ApplicationContext context;
	PayloadDTO payloadDTO;
	
/*	@Before
	public void setUp() throws Exception {
		context = TestHelper.getContext();
		payloadDTO = new PayloadDTO();
	}
	
	@Test
	public void reversalPaymentTest() throws FilterException, BusinessException{
		Processor reversalFundTransferProcessor = (Processor)context.getBean("reversalBillPaymentProcessor");		
		reversalFundTransferProcessor.process(PostPaymentProcessorTest.getRequestPayload());
	}*/
	
	
	
	@Test
	public void test() throws InterruptedException {
		//PayloadDTO bean = getPayload(); 
		
		PayloadDTO bean = PostPaymentProcessorTest.getRequestPayload(); 
		//String uri = "nwmq:queue:chnlNotifReqQueue";
		//NotificationCamelHelper.sendObject(bean, uri);
		//Thread.sleep(1000 * 240);
		
		System.out.println(bean.getRequestVO());
		//String uri = "tmq:queue:CHNL.TRNFR.REQ.QUEUE";
		//String resUri = "tmq:queue:CHNL.NOTIF.REQ.QUEUE";
		// PaymentHistoryHelper.sendObject(bean, "direct:paymentHistoryDetail");
		
	//	PaymentHistoryHelper.sendObject(bean, "direct-vm:addPayeeService");
		
		PaymentHistoryHelper.sendObject(bean, "direct:paymentReversalFailureSchedulerRouteDirect");
		
	System.out.println("---------------------------------------------------------");
	}
	
	
	

}
