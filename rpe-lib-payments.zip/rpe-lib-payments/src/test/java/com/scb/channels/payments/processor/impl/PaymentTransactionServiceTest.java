package com.scb.channels.payments.processor.impl;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payments.processor.BillPaymentStatusCheckProcessor;
import com.scb.channels.payments.processor.PaymentDetailsProcessor;

public class PaymentTransactionServiceTest { 
   
	@Test
	public void testTransactionStatusCheck(){
		ApplicationContext appContext = TestContextHelper.getContext();
		Assert.assertNotNull(appContext);
		
		BillPaymentStatusCheckProcessor processor = (BillPaymentStatusCheckProcessor) 
				appContext.getBean("billPaymentStatusCheckProcessor");
		
		UserVO userVO = new UserVO();
		userVO.setChannelId("SRM ADC");
		userVO.setCountry("KE");
		
		MessageVO messageVO = new MessageVO();
		messageVO.setRequestCode("KEADC09913082709540104133");
		
		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setMessageVO(messageVO);
		transactionInfoVO.setUserVO(userVO);
		
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();	
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		PayloadDTO payload=null;
		//PayloadDTO payload = processor.process(billerPayDetailsVO);
//		processor.updatePaymentStatus1(payload);
		Assert.assertNotNull(payload);
	}
	 
  @Test	
  public void testPaymentDetailsCheck(){
	ApplicationContext appContext = TestContextHelper.getContext();
	
	PaymentDetailsProcessor processor = (PaymentDetailsProcessor) 
			appContext.getBean("getPaymentDetailsProcessor");
	
	UserVO userVO = new UserVO();
	userVO.setChannelId("IBNK");	

	TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
	transactionInfoVO.setUserVO(userVO);
	transactionInfoVO.setTxnId("TestMessage_MobileInvoiveV1_getPaymentDetails");
	
	BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
	billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);	
	
	BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
	billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		
	/*PayloadDTO payload = processor.process(billerPayRequestVO);
	Assert.assertNotNull(payload);*/
}
	
}
