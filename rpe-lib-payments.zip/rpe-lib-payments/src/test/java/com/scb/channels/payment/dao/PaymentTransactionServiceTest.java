/*//package com.scb.channels.payment.processor.impl;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payment.helper.TestHelper;

public class PaymentTransactionServiceTest {

	@Test
	public void testTransactionStatusCheck(){
		ApplicationContext appContext = TestHelper.getContext();
		Assert.assertNotNull(appContext);
		
		BillPaymentStatusCheckProcessor processor = (BillPaymentStatusCheckProcessor) 
				appContext.getBean("billPaymentStatusCheckProcessor");
		
		UserVO userVO = new UserVO();
		userVO.setChannelId("SRM ADC");
		
		MessageVO messageVO = new MessageVO();
		messageVO.setRequestCode("KEADC099130827095401041338014675");
		
		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setMessageVO(messageVO);
		transactionInfoVO.setUserVO(userVO);
		
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();	
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		
		PayloadDTO payload = processor.process(billerPayDetailsVO);
		Assert.assertNotNull(payload);
	}
}
*/