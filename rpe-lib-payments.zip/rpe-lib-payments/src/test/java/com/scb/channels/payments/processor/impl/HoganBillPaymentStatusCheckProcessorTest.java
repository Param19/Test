package com.scb.channels.payments.processor.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.payments.processor.HoganBillPaymentStatusCheckProcessor;


public class HoganBillPaymentStatusCheckProcessorTest {
	
	@Test
	public void testTransactionPaymentStatusCheck(){
		System.out.println("@@ inside testTransactionPaymentStatusCheck @@");
		ApplicationContext context = TestHelper.getContext();
		Assert.assertNotNull(context);
		
		HoganBillPaymentStatusCheckProcessor processor = (HoganBillPaymentStatusCheckProcessor)context.getBean("hoganBillPaymentStatusCheckProcessor");
		PayloadDTO payloadDTO = new PayloadDTO();
		//populate PayloadDTO before sending it to process method
		payloadDTO = processor.process(populateRequestPayloadDTO(payloadDTO));
		Assert.assertNotNull(payloadDTO);
		//received response
		BillerPayResponseVO billerPayResponseVO =(BillerPayResponseVO) payloadDTO.getResponseVO();
		System.out.println("billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd(): "+billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
		Assert.assertNotNull(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
	}
	
	
	private PayloadDTO populateRequestPayloadDTO(PayloadDTO payloadDTO){
		System.out.println("Inside populate Request Payload DTO");
		
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();

		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("00000000-0000-0000-1709-130712947000");
		messageVO.setRequestCode("HK-123-456789-191833313-492394-222");
		billerPayRequestVO.setMessageVO(messageVO);
		
		UserVO user = new UserVO();
		user.setChannelId("IBNK");
		user.setCountry("HK");
		user.setEnvironment("DEV");
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setUserId(TestHelper.LOGIN_ID);
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId(TestHelper.LOGIN_ID);
		billerPayRequestVO.setUser(user);
		
		ClientVO clientVO = new ClientVO();
		clientVO.setClientId("1231231");
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setCountry("HK");
		clientVO.setEnvironment("DEV");
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		billerPayRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("getTransactionStatus");
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		billerPayRequestVO.setServiceVO(serviceVO);
		
		AccountVO srcAccVO = new AccountVO(); 
		srcAccVO.setAccountNumber("4509361249999743");
		srcAccVO.setAmount(new BigDecimal("14"));
		
		Date tranxDate;
        Calendar cal1 = DateUtils.getCountryCalendar();
        cal1.set(Calendar.MONTH, 9);
        cal1.set(Calendar.DATE, 13);
        cal1.set(Calendar.YEAR, 2017);
       
        tranxDate = cal1.getTime();	
        System.out.println(tranxDate);

		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setHostTxnRefNo("1000717");
		transactionInfoVO.setSourceSystemName("IBNK");
		transactionInfoVO.setDtCreated(tranxDate);
		transactionInfoVO.setSrcAccountVO(srcAccVO);
		transactionInfoVO.setDtProcessed(tranxDate);
		
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		billerPayDetailsVO.setPayRef("1000717");
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		
		payloadDTO.setRequestVO(billerPayRequestVO);
		
		return payloadDTO;
	}
	

}
