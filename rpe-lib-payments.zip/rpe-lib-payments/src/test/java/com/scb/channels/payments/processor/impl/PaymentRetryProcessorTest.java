package com.scb.channels.payments.processor.impl;

import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BeneficiaryVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.filters.FilterException;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.Processor;
import com.scb.channels.payment.helper.TestHelper;
import com.scb.channels.payments.processor.PaymentRetryListProcessor;

public class PaymentRetryProcessorTest {

	private static ApplicationContext context = null;

	
	@Test
	public void testObjectPresent() throws FilterException, BusinessException {
		context = TestHelper.getContext();
		PaymentRetryListProcessor paymentRetryProcessor = (PaymentRetryListProcessor) context.getBean("paymentRetryProcessor");
		paymentRetryProcessor.process(getRequestPayload());
		Assert.assertNotNull(paymentRetryProcessor);
		
	}

	public static PayloadDTO getRequestPayload() {
		Calendar cal= DateUtils.getCountryCalendar();
		
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_IBNK);
		user.setCountry("KE");
		user.setCustName(TestHelper.CUST_NAME);
		//user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerId("000008971");
		user.setCustomerType(TestHelper.CUSTOMER_TYPE);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setUserId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setPhone("254722665319");
		user.setEmailId("test@scb.com");
		user.setEmailNotification(true);
		user.setInboxNotification(true);
		user.setSmsNotification(true);
		billerPayRequestVO.setUser(user);
		
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel("ADC");
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry(TestHelper.COUNTRY);
		clientVO.setEnvironment(TestHelper.ENVIRONMENT);
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(TestHelper.SESSION_ID);
		clientVO.setVersion(CommonConstants.VERSION);
		clientVO.setDate(cal);
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		
		billerPayRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("BILL");
		serviceVO.setServiceTxnType("GPS");
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		
		billerPayRequestVO.setServiceVO(serviceVO);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("KE-016-151223-191833313-492394-012");
		messageVO.setRequestType(CommonConstants.BILL_PAYMENT);
		messageVO.setRequestCode("KE-016-151223-191833313-492394-012");
		billerPayRequestVO.setMessageVO(messageVO);	
		BillerPayDetailsVO billerPayDetailsVO= new BillerPayDetailsVO();
		billerPayDetailsVO.setMerchantCode("TLC");
		billerPayDetailsVO.setPayRef("Y003");
		billerPayDetailsVO.setConversionRate("50.00");
		
		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setTransferCurrencyCd("KES");
		String txnAmount="1";
		transactionInfoVO.setTxnAmount(Double.valueOf(txnAmount));
		transactionInfoVO.setTransactionBranch("00800");
		transactionInfoVO.setTransferCurrencyCd("KES");
		transactionInfoVO.setTransactionType("IFT");
		transactionInfoVO.setTxnRef1("1");
		BeneficiaryVO beneficiaryVO = new BeneficiaryVO();
		beneficiaryVO.setForcePostFlag("N");
		beneficiaryVO.setUniqueReferenceIdentifier(messageVO.getReqID().replaceAll(CommonConstants.HYPHEN, CommonConstants.EMPTY));
		beneficiaryVO.setCurrency("KES");
		AccountVO accountVO = new AccountVO();
		accountVO.setAccountNumber("0102058444000");
		accountVO.setCurrency("KES");

		Date transactionPostingDate;
		Date date;
        Calendar cal1 = Calendar.getInstance();
        cal1.set(Calendar.MONTH, 8);
        cal1.set(Calendar.DATE, 27);
        cal1.set(Calendar.YEAR, 2013);
       
        transactionPostingDate = cal1.getTime();		
        cal1.set(Calendar.MONTH, 8);
        cal1.set(Calendar.DATE, 27);
        cal1.set(Calendar.YEAR, 2013);
       
        
        date = cal1.getTime();
        transactionInfoVO.setDueDate(transactionPostingDate);
        transactionInfoVO.setSourceSystemName("ADC");
        transactionInfoVO.setSuspectedTransactionFlag("N");
        transactionInfoVO.setTxnTypeCd("BILL");       
        transactionInfoVO.setTransferMode(CommonConstants.IMMD);
        transactionInfoVO.setDtTransfer(DateUtils.getCurrentDate());
        transactionInfoVO.setTxnId(messageVO.getReqID());
		transactionInfoVO.setSrcAccountVO(accountVO);
		transactionInfoVO.setBeneficiaryVO(beneficiaryVO);
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		billerPayDetailsVO.setBillerCd("1001");
		billerPayDetailsVO.setConsumerNo("1000");
		billerPayDetailsVO.setBillerDesc("Safaricom");
		PayloadDTO payloadDTO = new PayloadDTO();
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		payloadDTO.setRequestVO(billerPayRequestVO);
		
		return payloadDTO;
	}
}
