package com.scb.channels.payments.processor.impl;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payments.service.GetPaymentStatusService;

public class GetPaymentStatusTest {

	ApplicationContext context=null;
	
	@Before
	public void IntializeContext(){
		
		context=new ClassPathXmlApplicationContext("/spring/payment-service-context.xml");
	}
	@Test
	public void ServicelevelTestForBillerDownload() {
		 
		PayloadDTO dto= new PayloadDTO();
		
		BillerPayRequestVO billerPayRequestVO= new BillerPayRequestVO();

		UserVO user= new UserVO();
		user.setCountry("NG");
		user.setChannelId(CommonConstants.IBANK);
		billerPayRequestVO.setUser(user);
		ClientVO client= new ClientVO();
		client.setCountry("NG");
		client.setVersion("1.0");
		billerPayRequestVO.setClientVO(client);
		MessageVO message= new MessageVO();
		
		message.setRequestType(CommonConstants.SYNC);
		//message.setReqID(getUniqueId());
		billerPayRequestVO.setMessageVO(message);
		ServiceVO service= new ServiceVO();
		service.setServiceName(CommonConstants.GET_PAYMENTSTATSU);
		billerPayRequestVO.setServiceVO(service);
		
		BillerPayDetailsVO billerPayDetailsVO=new BillerPayDetailsVO();
		TransactionInfoVO transactionInfoVO=new TransactionInfoVO();
		transactionInfoVO.setTxnId("NG-016-151124-191625585-907887-031");
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		billerPayDetailsVO.setHostReference("NG-016-151124-191625585-907887-031");
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		//billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnId("111111");
		//billerPayRequestVO.getBillerPayDetailsVO().setHostReference("11111111111111111111");
		
		//BillerDownloadRequest request= new BillerDownloadRequest();
		/*UserVO user= new UserVO();
		user.setCountry("NG");
		user.setChannelId(CommonConstants.IBANK);
		request.setUser(user);
		ClientVO client= new ClientVO();
		client.setCountry("NG");
		client.setVersion("1.0");
		request.setClientVO(client);
		MessageVO message= new MessageVO();
		
		message.setRequestType(CommonConstants.SYNC);
		message.setReqID(getUniqueId());
		request.setMessageVO(message);
		ServiceVO service= new ServiceVO();
		service.setServiceName(CommonConstants.BILLER_DOWNLOAD);
		service.setServiceTxnType(CommonConstants.BILLER_DOWNLOAD);
		request.setServiceVO(service);*/
		
	//	request.setCaptureSystem("Interswitch");
		//request.setAggregatorName("Interswitch");
		//request.setSubDomainType("getBillerCategories");
		//request.setTypeName("Invoice");
		//request.setMessageSender("IBANK");
		//request.setDomainName("Cash");
		//request.setPayloadFormat("XML");
		//request.setSubTypeName("getBillerCategories");
		//request.setMessageSender("IBANK");
		//request.setAggregatorTerminalId("3STC0001");
		//request.setAggregatorShortCode("IS");
		//dto.setRequestVO(billerPayRequestVO);
		GetPaymentStatusService getPaymentStatusService=context.getBean("getPaymentStatusService",GetPaymentStatusService.class);
		getPaymentStatusService.getPaymentStatus(billerPayRequestVO);
	}
	@After
public void	destroy(){
	AbstractApplicationContext abstractContext=(AbstractApplicationContext)context;
		//abstractContext.stop();
	}
	
	
	

}
