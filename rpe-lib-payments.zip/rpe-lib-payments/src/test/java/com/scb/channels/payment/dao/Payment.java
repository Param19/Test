package com.scb.channels.payment.dao;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payments.dao.PayeeManagementDAO;

public class Payment {

	//@Test
	public void test() {
		ApplicationContext context=	getcontext();
		assertNotNull(context);
		PayeeManagementDAO payee=	context.getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		UserVO u= new UserVO();
		u.setCustomerId("1002");
		u.setCountry("NG");;
		payee.viewPayeeList(u);
	}
	@Test
	public void testCheckIspayeeExists(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
		PayeeDetailsVO.setCustomerId("124");
		PayeeDetailsVO.setConsumerNumber("9876543123");
		PayeeDetailsVO.setBillerCode("123");
		PayeeDetailsVO.setCountryCode("NG");
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.checkIsPayeeExists(PayeeDetailsVO);
	}
	
	
	@Test
	public void testAddPayee(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
		PayeeDetailsVO.setCustomerId("124");
		PayeeDetailsVO.setConsumerNumber("9876543123");
		PayeeDetailsVO.setBillerCode("NGIS202101");
		PayeeDetailsVO.setCountryCode("NG");
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.savePayee(PayeeDetailsVO);
	}
	
	@Test
	public void testDeletePayee(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
	   // PayeeDetailsVO.setCustomerId("124");
		//PayeeDetailsVO.setConsumerNumber("9876543123");
		//PayeeDetailsVO.setBillerCode("NGIS202101");
		//PayeeDetailsVO.setCountryCode("NG");
		PayeeDetailsVO.setPayeeId(123);
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.deletePayee(PayeeDetailsVO);
	}
	public static  ApplicationContext getcontext(){
		ApplicationContext ap = new ClassPathXmlApplicationContext("/spring/payment-dao-context.xml");
		return ap;
		
	}

}
