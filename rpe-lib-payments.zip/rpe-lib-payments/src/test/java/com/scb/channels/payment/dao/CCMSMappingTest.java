package com.scb.channels.payment.dao;

import iso.std.iso._20022.tech.xsd.cain_001_001.MessageFunction6Code;

import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq;
import com.sc.scbml_1.PayloadFormatEnum;
import com.scb.channels.base.helper.CommonConstants;

public class CCMSMappingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AuthorizeCardPurchaseTransactionReq authorizeCardRequest = new AuthorizeCardPurchaseTransactionReq();
		if(authorizeCardRequest != null){
			
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().setPayloadFormat(PayloadFormatEnum.XML);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getHdr().setMsgFctn(MessageFunction6Code.AUTQ);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getHdr().setPrtcolVrsn(CommonConstants.DEFAULT_CATEGORY);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getHdr().setPrtcolVrsn(CommonConstants.THREE_ZEROES);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getHdr().getInitgPty().setId(CommonConstants.DEFAULT_CATEGORY);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt().getAcqrr().setId(CommonConstants.DEFAULT_CATEGORY);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt().getAccptr().getId().setId("200008000009");
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt().getAccptr().setCmonNm(CommonConstants.DEFAULT_CATEGORY);
		authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt().getAccptr().getLctn().setAddtlCtctInf(CommonConstants.DEFAULT_CATEGORY);
		System.out.println(authorizeCardRequest.toString());
			}
		else
			System.out.println("Null");
			
		}
}