package com.scb.channels.payments.processor.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import junit.framework.Assert;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ChargesTypeVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payment.helper.TestHelper;

public class BillPaymentIntegrationTest {

	private static ApplicationContext context = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void testPayBill() throws Exception {
		
		CamelContext camelContext = (CamelContext) context.getBean("paymentCamelConfig");
		Assert.assertNotNull(camelContext);
		
		ProducerTemplate template = camelContext.createProducerTemplate();
		Object obj = template.requestBody("direct:saveAndMakePayment",getRequestPayload());
		
		//Object obj = template.requestBody("direct:paymentResponseTopic",readFile());
		
		//Object obj = template.requestBody("direct:paymentRetry", "TEst");
		
		Assert.assertNotNull(obj);
	}
	
	private static PayloadDTO getRequestPayload() {
		Calendar cal= DateUtils.getCountryCalendar();
		
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		
		UserVO user = new UserVO();
		user.setChannelId(TestHelper.CHANNEL_IBNK);
		user.setCountry("NG");
		user.setCustName(TestHelper.CUST_NAME);
		user.setCustomerId(TestHelper.LOGIN_ID);
		user.setCustomerType(TestHelper.CUSTOMER_TYPE);
		user.setRole(TestHelper.ROLE);
		user.setEnvironment(TestHelper.ENVIRONMENT);
		user.setLanguage(CommonConstants.LANGUAGE);
		user.setLoginId(TestHelper.LOGIN_ID);
		user.setUserId(TestHelper.LOGIN_ID);
		user.setSegmentCode(TestHelper.SEGMENT_CODE);
		user.setPhone("254722665319");
		user.setEmailId("test@scb.com");
		user.setEmailNotification(true);
		user.setInboxNotification(true);
		user.setSmsNotification(true);
		billerPayRequestVO.setUser(user);
		
		ClientVO clientVO = new ClientVO();
		clientVO.setAppName(TestHelper.APP_NAME);
		clientVO.setChannel("IBNK");
		clientVO.setClientId(TestHelper.CLIENT_ID);
		clientVO.setCountry("NG");
		clientVO.setEnvironment(TestHelper.ENVIRONMENT);
		clientVO.setLanguage(CommonConstants.LANGUAGE);
		clientVO.setOrg(TestHelper.ORG);
		clientVO.setSessionId(TestHelper.SESSION_ID);
		clientVO.setVersion(CommonConstants.VERSION);
		clientVO.setDate(cal);
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		billerPayRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("BILL");
		serviceVO.setServiceTxnType("GPS");
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		billerPayRequestVO.setServiceVO(serviceVO);
		
		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("IBNK-SRM-0405-02");
		messageVO.setRequestType(CommonConstants.BILL_PAYMENT);
		messageVO.setRequestCode(messageVO.getReqID());
		billerPayRequestVO.setMessageVO(messageVO);	
		
		BillerPayDetailsVO billerPayDetailsVO= new BillerPayDetailsVO();
		billerPayDetailsVO.setPayeeId("1375");
		billerPayDetailsVO.setCountryCode("NG");
		billerPayDetailsVO.setChannel("IBNK");
		billerPayDetailsVO.setPayMthd("R");
		billerPayDetailsVO.setPaymentType("CASA");
		billerPayDetailsVO.setCustomerId("Arun1234");
		billerPayDetailsVO.setConsumerNo("qwertyuio1asdfghjklzxcvbnm123456789012345678901234");
		//billerPayDetailsVO.setBillerCategoryCd("6");
		//billerPayDetailsVO.setBillerCategoryDesc("Mobile Recharge");
		//billerPayDetailsVO.setBillerCd("NGIS10905");
		//billerPayDetailsVO.setBillerDesc("MTN Direct Top-up (Prepaid)");
		//billerPayDetailsVO.setMobileNumber("0987654321");
		//billerPayDetailsVO.setEmailId("a@b.c");
		billerPayDetailsVO.setStaffFlag("Y");
		
		billerPayDetailsVO.setTxnActStatus("SUCC");
		
		billerPayDetailsVO.setPayRef("IBNK-SRM-0405-02");
		billerPayDetailsVO.setHostReference("1380AR040502");
		
		AccountVO srcAccountVO = new AccountVO();
		
		//right- for positive case
		srcAccountVO.setAccountNumber("0000087762");
		//wrong- for exception case
		//srcAccountVO.setAccountNumber("000007183501");
		
		srcAccountVO.setCurrency("NGN");
		srcAccountVO.setAmount(new BigDecimal(111));
		
		AccountVO destAccountVO = new AccountVO();
		destAccountVO.setAccountNumber("01020584440111");

		ChargesTypeVO charge = new ChargesTypeVO();
		charge.setAmount(12);
		
		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setSrcAccountVO(srcAccountVO);
		transactionInfoVO.setDestAccountVO(destAccountVO);
		transactionInfoVO.setChargesTypeVO(charge);
		transactionInfoVO.setTxnPurpose("Testing");
		transactionInfoVO.setTransferCurrencyCd("NGN");
		transactionInfoVO.setDtProcessed(new Date());

        transactionInfoVO.setTxnId(messageVO.getReqID());
		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		
		PayloadDTO payloadDTO = new PayloadDTO();
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		payloadDTO.setRequestVO(billerPayRequestVO);
		
		return payloadDTO;
	}
	
	private static String readFile(){
		
		BufferedReader br = null;
		StringBuffer buffer = new StringBuffer();
		try {
			String sCurrentLine;
			br = new BufferedReader(new FileReader("C:\\Project\\Development\\Picasso_Payments\\global_payments_final\\source\\aggResposne.xml"));
			while ((sCurrentLine = br.readLine()) != null) {
				buffer.append(sCurrentLine);
				//System.out.println(sCurrentLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return buffer.toString();
	}
	
	/*public static void main(String args[]){
		Double txnAmount = 760.76d;
		String strAmount = ((Arrays.asList((String.valueOf(txnAmount*100)).split(Pattern.quote(".")))).get(0)).toString();
		
		System.out.println(strAmount);
	}*/
}
