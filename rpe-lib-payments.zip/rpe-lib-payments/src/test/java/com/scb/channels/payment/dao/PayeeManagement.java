package com.scb.channels.payment.dao;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.CollectionUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.payments.dao.PayeeManagementDAO;

public class PayeeManagement {

	//@Test
	public void test() {
		ApplicationContext context=	getcontext();
		assertNotNull(context);
		PayeeManagementDAO payee=	context.getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		UserVO u= new UserVO();
		u.setCustomerId("000047205");
		//u.setCustomerId("00005");
		u.setCountry("KE");
		List<PayeeDetailVO> listPayeeDetailVO = payee.viewPayeeList(u);
		List<PayeeDetailVO> listPayeeDetailFromDB=new ArrayList<PayeeDetailVO>();
		
	/*	if(CollectionUtils.isEmpty(listPayeeDetailVO)){
			System.out.println("PayeeManagementServiceImpl :: viewPayeeList ::Empty List From DB ");
		}else{
			System.out.println("PayeeManagementServiceImpl :: viewPayeeList :: Value List From DB ");
			
		for(PayeeDetailVO payeeDetailVO : listPayeeDetailVO){
			BillerVO biller  = payeeDetailVO.getBillerVO();
			if(biller.getStatusCode().equalsIgnoreCase(CommonConstants.D)){
				payeeDetailVO.setStatus(CommonConstants.P);
				listPayeeDetailFromDB.add(payeeDetailVO);
			}else{
				listPayeeDetailFromDB.add(payeeDetailVO);
			}
		}
		}*/
		
		System.out.println("--------------------------"+listPayeeDetailFromDB);
		
		for(PayeeDetailVO payeeDetailVO : listPayeeDetailFromDB){
			
			System.out.println(" listPayeeDetailFromDB After Modified  --- > "+payeeDetailVO.getStatus());
		}
		
for(PayeeDetailVO payeeDetailVO : listPayeeDetailVO){
			
			System.out.println("listPayeeDetailVO before Modified  --- > "+payeeDetailVO.getStatus());
		}
	}
	//@Test
	public void testCheckIspayeeExists(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
		PayeeDetailsVO.setCustomerId("124");
		PayeeDetailsVO.setConsumerNumber("9876543123");
		PayeeDetailsVO.setBillerCode("123");
		PayeeDetailsVO.setCountryCode("NG");
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.checkIsPayeeExists(PayeeDetailsVO);
	}
	
	
	@Test
	public void testAddPayee(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
		PayeeDetailsVO.setCustomerId("124");
		PayeeDetailsVO.setConsumerNumber("9876543123");
		PayeeDetailsVO.setBillerCode("NGIS202101");
		PayeeDetailsVO.setCountryCode("NG");
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.savePayee(PayeeDetailsVO);
	}
	
//	@Test
	public void testDeletePayee(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
	   // PayeeDetailsVO.setCustomerId("124");
		//PayeeDetailsVO.setConsumerNumber("9876543123");
		//PayeeDetailsVO.setBillerCode("NGIS202101");
		//PayeeDetailsVO.setCountryCode("NG");
		PayeeDetailsVO.setPayeeId(123);
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.deletePayee(PayeeDetailsVO);
	}
	public static  ApplicationContext getcontext(){
		ApplicationContext ap = new ClassPathXmlApplicationContext("/spring/payment-dao-context.xml");
		return ap;
		
	}

}
