package com.scb.channels.payments.processor.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payments.service.impl.CreditCardServiceImpl;
import com.scb.channels.payments.processor.impl.TestContextHelper;

//@RunWith(MockitoJUnitRunner.class)
public class CreditCardServiceImplTest {

	/*
	@Mock
	CreditCardAuthorizationPortType creditCardServiceClient;
	
	@Mock
	DataBean dataBean;
	
	@InjectMocks
	CreditCardServiceImpl serviceImpl;

	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
*/	
	private static ApplicationContext context = null;
	
	//@Test
	public void testC400ReverseCardPurchase(){
		/*PayloadDTO payloadDTO = populateRequestPayloadDTO(new PayloadDTO());
		BillerPayRequestVO billerPayRequest = (BillerPayRequestVO)payloadDTO.getRequestVO();
		//mockedResponse
		ReverseCardPurchaseTransactionRes revCardPurchaseRes = new ReverseCardPurchaseTransactionRes();
		ReverseCardPurchaseTransactionResPayload reverseCardPurchaseTransactionResPayload = new ReverseCardPurchaseTransactionResPayload();
		ReverseCardPurchaseTransactionResInfo reverseCardPurchaseTransactionResInfo = new ReverseCardPurchaseTransactionResInfo();
		Cain00600101 cain00600101 = new Cain00600101();
		iso.std.iso._20022.tech.xsd.cain_006_001.Document document = new iso.std.iso._20022.tech.xsd.cain_006_001.Document();
		AcquirerReversalResponse acqrrRvslRspn = new AcquirerReversalResponse();
		AcquirerReversalResponse1 rvslRspn = new AcquirerReversalResponse1();
		CardTransactionEnvironment4 envt = new CardTransactionEnvironment4();
		PaymentCard15 card = new PaymentCard15();
		PlainCardData12 plainCardData = new PlainCardData12();
		//AcqrrRvslRspn/RvslRspn/Envt/Card/PlainCardData/PAN
		plainCardData.setPAN("1231234123412"); //CardNumber
		
		//AcqrrRvslRspn/RvslRspn/Tx/TxRspn/RsltDtls - status
		//AcqrrRvslRspn/RvslRspn/Tx/TxRspn/AddtlRsltInf - description
		card.setPlainCardData(plainCardData);
		envt.setCard(card);
		rvslRspn.setEnvt(envt);
		acqrrRvslRspn.setRvslRspn(rvslRspn);
		document.setAcqrrRvslRspn(acqrrRvslRspn);
		cain00600101.setDocument(document);
		reverseCardPurchaseTransactionResInfo.setCain00600101(cain00600101);
		reverseCardPurchaseTransactionResPayload.setReverseCardPurchaseTransactionResInfo(reverseCardPurchaseTransactionResInfo);
		revCardPurchaseRes.setReverseCardPurchaseTransactionResPayload(reverseCardPurchaseTransactionResPayload);
		
		//header
		SCBMLHeaderType header = new SCBMLHeaderType();
		revCardPurchaseRes.setHeader(header);
		
		//mock
		Mockito.when(creditCardServiceClient.reverseCardPurchaseTransaction(Matchers.any(ReverseCardPurchaseTransactionReq.class))).thenReturn(revCardPurchaseRes);
		BillerPayResponseVO billPayResponse  = serviceImpl.reverseC400CardPurchase(billerPayRequest);
		String accountNumber = billPayResponse.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().getAccountNumber();
		System.out.println("AccountNumber: "+ accountNumber);
		Assert.assertEquals(plainCardData.getPAN(), billPayResponse.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().getAccountNumber());
	*/
		System.out.println("testC400ReverseCardPurchase");
		context = TestContextHelper.getProcessorContext();
		Assert.assertNotNull(context);
		PayloadDTO payloadDTO = populateRequestPayloadDTO(new PayloadDTO());
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)payloadDTO.getRequestVO();
		CreditCardServiceImpl creditCardService = (CreditCardServiceImpl) context.getBean("creditCardService"); 
		creditCardService.reverseCardAuthorization(billerPayRequestVO);	
	
	}
	
	
	@Test
	public void testC400CardPurchase(){
	/*	PayloadDTO payloadDTO = populateRequestPayloadDTO(new PayloadDTO());
		//request
		BillerPayRequestVO billerPayRequest = (BillerPayRequestVO)payloadDTO.getRequestVO();
		//mock response
		AuthorizeCardPurchaseTransactionRes authorizeCardResponse = new AuthorizeCardPurchaseTransactionRes();
		AuthorizeCardPurchaseTransactionResPayload payload = new AuthorizeCardPurchaseTransactionResPayload();
		AuthorizeCardPurchaseTransactionResInfo respInfo = new AuthorizeCardPurchaseTransactionResInfo();
		AuthorizationSupplementary authSupplementary = new AuthorizationSupplementary();
		Cain00200101 cain = new Cain00200101();
		//cain00200101.document.acqrrAuthstnRspn.authstnRspn.tx.authstnRslt.authstnCd
		authSupplementary.setResponseCode("00000"); //status
		Document document = new Document();
		AcquirerAuthorisationResponse acqAuthResp = new AcquirerAuthorisationResponse();
		AcquirerAuthorisationResponse1 acqAutResp1 = new AcquirerAuthorisationResponse1();
		CardTransaction4 tx = new CardTransaction4();
		AuthorisationResult8 authRes =  new AuthorisationResult8();
		authRes.setAuthstnCd("W21731"); // authcode
		tx.setAuthstnRslt(authRes);
		acqAutResp1.setTx(tx);
		acqAuthResp.setAuthstnRspn(acqAutResp1);
		document.setAcqrrAuthstnRspn(acqAuthResp);
		cain.setDocument(document);
		respInfo.setCain00200101(cain);
		respInfo.setAuthorizationSupplementary(authSupplementary);
		payload.setAuthorizeCardPurchaseTransactionResInfo(respInfo);
		authorizeCardResponse.setAuthorizeCardPurchaseTransactionResPayload(payload);
		//header
		SCBMLHeaderType header = new SCBMLHeaderType();
		authorizeCardResponse.setHeader(header);
		
		Mockito.when(creditCardServiceClient.authorizeCardPurchaseTransaction(Matchers.any(AuthorizeCardPurchaseTransactionReq.class))).thenReturn(authorizeCardResponse);
		//verify
		BillerPayResponseVO billerPayResponse = serviceImpl.authorizeC400CardPurchase(billerPayRequest);
		Assert.assertEquals(CommonConstants.CARD_AUTH_SUCCESS, billerPayResponse.getBillerPayDetailsVO().getTxnActStatus());*/
		
		System.out.println("testC400CardPurchase");
		context = TestContextHelper.getProcessorContext();
		Assert.assertNotNull(context);
		PayloadDTO payloadDTO = populateRequestPayloadDTO(new PayloadDTO());
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)payloadDTO.getRequestVO();
		CreditCardServiceImpl creditCardService = (CreditCardServiceImpl) context.getBean("creditCardService"); 
		creditCardService.authorizeCreditCard(billerPayRequestVO);
		
	}
	
	private PayloadDTO populateRequestPayloadDTO(PayloadDTO payloadDTO) {
		System.out.println("Inside populate Request Payload DTO");

		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();

		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("00000000-0000-0000-1709-130712947000");
		messageVO.setRequestCode("HK-123-456789-191833313-492394-222");
		billerPayRequestVO.setMessageVO(messageVO);

		UserVO user = new UserVO();
		user.setChannelId("");
		user.setCountry("KE");
		user.setEnvironment("DEV");
		user.setLoginId(TestContextHelper.LOGIN_ID);
		user.setUserId(TestContextHelper.LOGIN_ID);
		user.setCustName(TestContextHelper.CUST_NAME);
		user.setCustomerId(TestContextHelper.LOGIN_ID);
		billerPayRequestVO.setUser(user);

		ClientVO clientVO = new ClientVO();
		clientVO.setClientId("1571157");
		clientVO.setAppName(TestContextHelper.APP_NAME);
		clientVO.setCountry("KE");
		clientVO.setEnvironment("DEV");
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		billerPayRequestVO.setClientVO(clientVO);

		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("payBill");
		serviceVO.setHostEnv(CommonConstants.HOST_ENV);
		billerPayRequestVO.setServiceVO(serviceVO);

		AccountVO srcAccVO = new AccountVO();
		srcAccVO.setAccountNumber("4509361249999743"); //cardNumber
		srcAccVO.setAmount(new BigDecimal("13.00"));
		srcAccVO.setCurrency("KES");
		Date tranxDate;
		Calendar cal1 = DateUtils.getCountryCalendar();
		cal1.set(Calendar.MONTH, 12);
		cal1.set(Calendar.DATE, 21);
		cal1.set(Calendar.YEAR, 2017);

		tranxDate = cal1.getTime();
		System.out.println("tranxDate: "+tranxDate);

		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setHostTxnRefNo("RefNo1571157");
		transactionInfoVO.setSourceSystemName("IBNK");
		transactionInfoVO.setDtCreated(tranxDate);
		transactionInfoVO.setSrcAccountVO(srcAccVO);
		transactionInfoVO.setDtProcessed(tranxDate);

		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		billerPayDetailsVO.setPayRef("PayRef1571157");
		billerPayDetailsVO.setPaymentType("CARD");
		billerPayDetailsVO.setCountryCode("KE");
		billerPayDetailsVO.setChannel("IBNK");
		billerPayDetailsVO.setBillerCategoryCd("MMONEY");
		billerPayDetailsVO.setBillerCd("MPESA");
		
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		
		
		payloadDTO.setRequestVO(billerPayRequestVO);
		
		BillerPayResponseVO billerPayResponse =  new BillerPayResponseVO();
		billerPayResponse.setBillerPayDetailsVO(billerPayDetailsVO);
		payloadDTO.setResponseVO(billerPayResponse);
		
		return payloadDTO;
	}
	
	

}
