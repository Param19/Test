package com.scb.channels.payments.processor.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.helper.CreditCardConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.AccountVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.processor.CCReferenceNumberSequenceProcessor;

public class CCReferenceNumberSequenceProcessorTest {
	
	private static ApplicationContext context = null;
	@Test
	public void testCashAdvance() throws BusinessException{
		System.out.println("@@@ CCReferenceNumberSequenceProcessorTest @@@");
		context = TestContextHelper.getProcessorContext();
		Assert.assertNotNull(context);
		PayloadDTO payloadDTO = populateRequestPayloadDTO(new PayloadDTO());
		CCReferenceNumberSequenceProcessor processor = (CCReferenceNumberSequenceProcessor) context.getBean("ccReferenceNumberProcessor"); 
		processor.process(payloadDTO);
		//System.out.println("authCode: "+billerPayRequestVO.getBillerPayDetailsVO().getAuthCode());
		//Assert.assertEquals("CA4444", billerPayRequestVO.getBillerPayDetailsVO().getAuthCode());
		System.out.println("Over and Out !!");
	}
	
/*	@Test
	public void testPayBill() throws Exception {
		context = TestHelper.getContext();
		CamelContext camelContext = (CamelContext) context.getBean("paymentCamelConfig");
		Assert.assertNotNull(camelContext);
		ProducerTemplate template = camelContext.createProducerTemplate();
		PayloadDTO payload = populateRequestPayloadDTO(new PayloadDTO());
		Object obj = template.requestBody("direct:makeBillPaymentByCard",payload);
		Assert.assertNotNull(obj);
		System.out.println("Response.........."+obj.toString());
	}*/
	
	
	
	private PayloadDTO populateRequestPayloadDTO(PayloadDTO payloadDTO) {
		System.out.println("Inside populate Request Payload DTO");

		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();

		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("00000000-0000-0000-1709-130712947000");
		messageVO.setRequestCode("HK-123-456789-191833313-492394-222");
		billerPayRequestVO.setMessageVO(messageVO);

		UserVO user = new UserVO();
		user.setChannelId("IBNK");
		user.setCountry("KE");
		user.setEnvironment("DEV");
		user.setLoginId("LoginId1571157");
		user.setUserId("UserId1571157");
		user.setCustName("JAY");
		user.setCustomerId("CusId1571157");
		billerPayRequestVO.setUser(user);

		ClientVO clientVO = new ClientVO();
		clientVO.setClientId("1231231");
		clientVO.setAppName("IBNK");
		clientVO.setCountry("HK");
		clientVO.setEnvironment("DEV");
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		billerPayRequestVO.setClientVO(clientVO);

		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("getTransactionStatus");
		serviceVO.setHostEnv("IBNK");
		billerPayRequestVO.setServiceVO(serviceVO);

		AccountVO srcAccVO = new AccountVO();
		srcAccVO.setAccountNumber("4509361249999743");
		srcAccVO.setAmount(new BigDecimal("12341.457"));
		srcAccVO.setCurrency("KES");

		Date tranxDate;
		Calendar cal1 = DateUtils.getCountryCalendar();
		cal1.set(Calendar.MONTH, 11);
		cal1.set(Calendar.DATE, 30);
		cal1.set(Calendar.YEAR, 2017);

		tranxDate = cal1.getTime();
		System.out.println("tranxDate: "+tranxDate);

		TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setHostTxnRefNo("1000717");
		transactionInfoVO.setSourceSystemName("IBNK");
		transactionInfoVO.setDtCreated(tranxDate);
		transactionInfoVO.setSrcAccountVO(srcAccVO);
		transactionInfoVO.setDtProcessed(tranxDate);

		billerPayDetailsVO.setTransactionInfoVO(transactionInfoVO);
		billerPayDetailsVO.setPayRef("201711301571157");
		billerPayDetailsVO.setPaymentType("CARD");
		billerPayDetailsVO.setCountryCode("KE");
		billerPayDetailsVO.setChannel("IBNK");
		//billerPayDetailsVO.setBillerCategoryCd("MMONEY");
		billerPayDetailsVO.setBillerCategoryCd("UTILITY");
		billerPayDetailsVO.setBillerCd("School");
	//	billerPayDetailsVO.setBillerName("JOMO KENYATTA UNIVERSITY  OF AGR");
	//	billerPayDetailsVO.setBillerName("THE TECHNICAL UNIVERSITY OF KENYA OR THE KENYA POL");
		billerPayDetailsVO.setBillerName("XAVIERS HIGH");
		
		//billerPayDetailsVO.setBillerCd("MPESA");
		billerPayDetailsVO.setHostReference("HostReference1571157");
		//cardConstants
		CreditCardConstants cardConstants = new CreditCardConstants();
		billerPayDetailsVO.setCardConstants(cardConstants);
		
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);

		payloadDTO.setRequestVO(billerPayRequestVO);

		return payloadDTO;
	}


}
