package com.scb.channels.payment.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.dao.BillerManagementDAO;

public class DownloadBillerDAOTest {

ApplicationContext context=null;
	
	@Before
	public void IntializeContext(){
		
		context=new ClassPathXmlApplicationContext("/spring/payment-dao-context.xml");
	}
	
	//@Test
	public void testBillerCategoriesCountryCOunt(){
		BillerDownloadDAO dao=context.getBean("billerDownloadDAO",BillerDownloadDAO.class);
		
		try{
			
			dao.getCountBillerCategories("NG");
			
		}catch(Exception e){
			
			e.printStackTrace();
		}
		/*getAllMasterBillersforCountry*/
	}
	
	//@Test
	public void GetListofBillerCategories(){
		BillerDownloadDAO dao=context.getBean("billerDownloadDAO",BillerDownloadDAO.class);
		
		try{
			
			List<BillerCategoryVO> billers=	dao.getAllMasterBillersforCountry("NG");
			
				assertNotNull(billers);
		}catch(Exception e){
			
			e.printStackTrace();
		}
		/*getAllMasterBillersforCountry*/
	}
	//@Test
	public void GetActvieListofBillerCategories(){
		BillerManagementDAO dao=context.getBean("billerManagementDAO",BillerManagementDAO.class);
		
		try{
			
			List<BillerCategoryVO> billers= dao.getActiveBillerCategories("NG");
			assertNotNull(billers);
		}catch(Exception e){
			
			e.printStackTrace();
		}
		/*getAllMasterBillersforCountry*/
	}
	
	
		@Test
		public void GetStaticBillerCategories(){
			BillerDownloadDAO dao=context.getBean("billerDownloadDAO",BillerDownloadDAO.class);
			
			try{
				
				List<BillerCatgegoryReference> billers= dao.getCategoriesFromRef("NG");
				assertNotNull(billers);
			}catch(Exception e){
				
				e.printStackTrace();
			}
			/*getAllMasterBillersforCountry*/
		}
	
	@After
	public void	destroy(){
		AbstractApplicationContext abstractContext=(AbstractApplicationContext)context;
			abstractContext.stop();
		}
		

}
