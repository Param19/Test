package com.scb.channels.payment.dao;

import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;

public class QRPaymentPANTest {
	
	@Test
	public void testMerchantPanTest(){
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		qrPaymentDetailVO.setCardNumber("543523424234234");
		qrPaymentDetailVO.setCard_type("MASTER");
		
	
		
	/*	QRMerchantPanTypeVO merchantPanVisa1 = new QRMerchantPanTypeVO();
		merchantPanVisa1.setRefId("01");
		merchantPanVisa1.setRefValue("4461100004041116");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanVisa1);*/
		
		QRMerchantPanTypeVO merchantPanVisa2 = new QRMerchantPanTypeVO();
		merchantPanVisa2.setRefId("03");
		merchantPanVisa2.setRefValue("5761100004041116");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanVisa2);
		
		QRMerchantPanTypeVO merchantPanVisa3 = new QRMerchantPanTypeVO();
		merchantPanVisa3.setRefId("02");
		merchantPanVisa3.setRefValue("447611004041333");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanVisa3);
		
		QRMerchantPanTypeVO merchantPanVisa4 = new QRMerchantPanTypeVO();
		merchantPanVisa4.setRefId("05");
		merchantPanVisa4.setRefValue("547611004041116");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanVisa4);
		
		
		/*ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		try {
			String json = objectMapper.writeValueAsString(qrPaymentDetailVO);
			System.out.println("Json..........."+json );
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		/*QRMerchantPanTypeVO merchantPanVisa3 = new QRMerchantPanTypeVO();
		merchantPanVisa3.setRefId("06");
		merchantPanVisa3.setRefValue("45433333333333");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanVisa3);*/
		
		/*QRMerchantPanTypeVO merchantPanMaster1 = new QRMerchantPanTypeVO();
		merchantPanMaster1.setRefId("04");
		merchantPanMaster1.setRefValue("55435556564534");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanMaster1);
	
		QRMerchantPanTypeVO merchantPanMaster2 = new QRMerchantPanTypeVO();
		merchantPanMaster2.setRefId("05");
		merchantPanMaster2.setRefValue("55435556564534");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanMaster2);*/
		
		
		//String cardNo = qrPayment.getCardNumber();
		/*List<QRMerchantPanTypeVO> merchantList = qrPayment.getMerchantPanList();
		
		if (merchantList.size() > 0) {
		    Collections.sort(merchantList, new Comparator<QRMerchantPanTypeVO>() {
		        @Override
		        public int compare(final QRMerchantPanTypeVO object1, final QRMerchantPanTypeVO object2) {
		        return object1.getRefId().compareTo(object2.getRefId());      			        		
		        }
		    } );
		}
		
		for(QRMerchantPanTypeVO qrMerchantPanTypeVO : merchantList){
			if(qrPayment.getCardNumber() != null && qrPayment.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR) && (qrMerchantPanTypeVO.getRefId().equalsIgnoreCase("02") || (qrMerchantPanTypeVO.getRefId().equalsIgnoreCase("03")))){
				qrPayment.setMerchantPan(qrMerchantPanTypeVO.getRefValue());
				System.out.println("MerchantPan Visa::::::"+qrPayment.getMerchantPan());
				break;
			}
			if(qrPayment.getCardNumber() != null && qrPayment.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR) && (qrMerchantPanTypeVO.getRefId().equalsIgnoreCase("04") || (qrMerchantPanTypeVO.getRefId().equalsIgnoreCase("05")))){
				qrPayment.setMerchantPan(qrMerchantPanTypeVO.getRefValue());
				System.out.println("MerchantPan Master::::::"+qrPayment.getMerchantPan());
				break;
			}
		
		}*/
		boolean validatorFlag = false;
		if( qrPaymentDetailVO.getMerchantPanList() != null){

			List<QRMerchantPanTypeVO> merchantPanList = qrPaymentDetailVO.getMerchantPanList();	
			System.out.println("QR Merchant PAN Size :::"+merchantPanList.size());

			if(((qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)) && !qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA))
					|| (qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)) && !qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)){
					System.out.println("Something Wrong with Network and Merchant PAN");
					qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
					qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
					qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
					validatorFlag = true;
			}
			
			if(qrPaymentDetailVO.getCard_type()!=null && qrPaymentDetailVO.getCardNumber()!= null && !validatorFlag)
			{
				System.out.println("Before the for loop check");
				HashMap<String, String> merchantMap = new HashMap<String,String>();
				for(QRMerchantPanTypeVO qrMerchantPanTypeVO : merchantPanList){
					System.out.println("Inside the for loop check");
					System.out.println("REF ID:::::"+qrMerchantPanTypeVO.getRefId() +"::REF VALUE::::"+ qrMerchantPanTypeVO.getRefValue());
					if(qrMerchantPanTypeVO.getRefId() == null || qrMerchantPanTypeVO.getRefValue()==null||
							qrMerchantPanTypeVO.getRefId().equals("") || qrMerchantPanTypeVO.getRefValue().equals(""))
					{
						System.out.println("EITHER OF REF ID & REF VALUE OR BOTH NOT PRESENT");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._235.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._235.getMessage());
						validatorFlag = true;
						break;
					}
					
					if(!(CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) ||
							CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))){
						System.out.println("Given RefId is Not correct");
					}
					//if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)){
					if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0) && (CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))
							&& !qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0)){						
							System.out.println("Something Wrong with Network and Merchant PAN");
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							validatorFlag = true;
							break;
						//}
					}
					//if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)){
					if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0) && (CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))
							&& !qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0)){						
							System.out.println("Something Wrong with Network and Merchant PAN");
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							validatorFlag = true;
							break;
						//}
					}
					merchantMap.put(qrMerchantPanTypeVO.getRefId(), qrMerchantPanTypeVO.getRefValue());
				}
				if(!validatorFlag){
				String visaMerchantPan = merchantMap!= null && merchantMap.get(CommonConstants.VISA_MERCHANT_02) != null ? merchantMap.get(CommonConstants.VISA_MERCHANT_02) : merchantMap.get(CommonConstants.VISA_MERCHANT_03) ;
				String masterMerchantPan = merchantMap!= null && merchantMap.get(CommonConstants.MASTER_MERCHANT_04) != null  ? merchantMap.get(CommonConstants.MASTER_MERCHANT_04) : merchantMap.get(CommonConstants.MASTER_MERCHANT_05) ;
				System.out.println("Visa Merchant Pan : "+visaMerchantPan);
				System.out.println("Master Merchant Pan : "+masterMerchantPan);
				merchantMap.clear();
				if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)){
					if(visaMerchantPan == null){
						System.out.println("VISA merchant is Null");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
						validatorFlag = true;
					}
				}
				if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)){
					if(masterMerchantPan == null){
						System.out.println("Master Merchant is Null");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
						validatorFlag = true;
					}
				}
				}
			}
		}

	}

	
}
