package com.scb.channels.payment.dao;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;

public class QRPaymentValidationTest {
	
	public static void main(String arg[]){/*
	
		QRPaymentRequestVO qrPaymentRequestVO = new QRPaymentRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO =  new QRPaymentDetailVO();
		QRMerchantPanTypeVO merchantPanList = new QRMerchantPanTypeVO();
		merchantPanList.setRefId("02");
		merchantPanList.setRefValue("43444");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanList);
		qrPaymentDetailVO.setCard_type("VISA");
		qrPaymentDetailVO.setCardNumber("44354453535255");
		
		for(QRMerchantPanTypeVO qrMerchantPanTypeVO : qrPaymentDetailVO.getMerchantPanList()){
			
			if(CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())){
				if(!((qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)
						&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)))){
					System.out.println("ITs VISA Card");
				}
			}

			if(CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())){
				
				if(!((qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR)
						&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)))){
					System.out.println("Its Master Card");
				}
			}
			if(!(((CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())) &&
					(qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR))))){
				System.out.println("QR Merchant PAN and Card Type & Card Number are not same Network :::");
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.FAIL);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(ExceptionMessages._207.getCode());
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(ExceptionMessages._207.getMessage());
			}
			
			if(!(((CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())) &&
					(qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR))))){
				System.out.println("QR Merchant PAN and Card Type & Card Number are not same Network :::");
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.FAIL);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(ExceptionMessages._207.getCode());
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(ExceptionMessages._207.getMessage());
			}

		}
	*/
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -12);
        Date fromDate = calendar.getTime();
        System.out.println("fromDate--------------"+fromDate);
        
        Calendar cal = DateUtils.getCountryCalendar();
        cal.add(Calendar.HOUR, 5);
        Date toDate = cal.getTime();
        System.out.println("toDate-------------"+toDate);
        
        Calendar updatedTimeCalendar = Calendar.getInstance();
        //updatedTimeCalendar.setTime(new Date());
        updatedTimeCalendar.add(Calendar.MINUTE, -(60));
        Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());
        System.out.println("updatedTimeStamp------------------"+updatedTimeStamp);
	}

}
