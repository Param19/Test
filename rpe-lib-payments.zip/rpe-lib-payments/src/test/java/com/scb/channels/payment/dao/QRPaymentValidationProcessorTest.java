package com.scb.channels.payment.dao;

import java.util.List;

import org.junit.Test;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;

public class QRPaymentValidationProcessorTest {
	
	//public static void main(String arg[]){
	@Test
	public void testMerchantPAN() {
		//QRPaymentRequestVO qrPaymentRequestVO = new QRPaymentRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO =  new QRPaymentDetailVO();
		QRMerchantPanTypeVO merchantPanListTest = new QRMerchantPanTypeVO();
		merchantPanListTest.setRefId("02");
		merchantPanListTest.setRefValue("53444");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanListTest);
		merchantPanListTest = new QRMerchantPanTypeVO();
		merchantPanListTest.setRefId("04");
		merchantPanListTest.setRefValue("53444");
		qrPaymentDetailVO.getMerchantPanList().add(merchantPanListTest);
		qrPaymentDetailVO.setCard_type("MASTER");
		qrPaymentDetailVO.setCardNumber("44354453535255");
		boolean validatorFlag = false;
		boolean merchantFlag=false;
		boolean multiMerchFlag=false;
		
		if( !validatorFlag && qrPaymentDetailVO.getMerchantPanList() != null){

			List<QRMerchantPanTypeVO> merchantPanList = qrPaymentDetailVO.getMerchantPanList();	
			System.out.println("QR Merchant PAN Size :::"+merchantPanList.size());
			System.out.println("validatorflag::::"+validatorFlag);
			if(merchantPanList.size()>1)
				multiMerchFlag = true;
			if(!(qrPaymentDetailVO.getCard_type()==null || qrPaymentDetailVO.getCardNumber()== null ))
			{
				
				if(multiMerchFlag) {
					for(QRMerchantPanTypeVO qrMerchantPanTypeVO : merchantPanList){
						
						System.out.println(" Ref ID - " +qrMerchantPanTypeVO.getRefId() + "Pan no - " +qrMerchantPanTypeVO.getRefValue());
						System.out.println("Inside the for loop check");
						System.out.println("REF ID:::::"+qrMerchantPanTypeVO.getRefId() +"::REF VALUE::::"+ qrMerchantPanTypeVO.getRefValue());
						if(qrMerchantPanTypeVO.getRefId() == null || qrMerchantPanTypeVO.getRefValue()==null||
								qrMerchantPanTypeVO.getRefId().equals("") || qrMerchantPanTypeVO.getRefValue().equals(""))
						{
							System.out.println("EITHER OF REF ID & REF VALUE OR BOTH NOT PRESENT");
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._235.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._235.getMessage());
							validatorFlag = true;
							break;
						} else if(CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())){
							if(qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR ,0)){
								if (qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)
								&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
							//qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							//qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							//qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							//validatorFlag = true;
							merchantFlag = true;
							//break;
							}
						} else if(!(qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0) )) {
							validatorFlag = true;
							break;
						}
						} else if(CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())){
							if(qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0)){
									if (qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)
									&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)){
								//qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
								//qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
								//qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
								//validatorFlag = true;
								merchantFlag = true;
								//break;
								}
							} else if(!(qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0) )) {
								validatorFlag = true;
								break;
							}
						} else{
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							validatorFlag = true;
							break;
						}
						
					}
					
				
				  } else {
				 
					QRMerchantPanTypeVO qrMerchantPanTypeVO = merchantPanList.get(0);
					System.out.println(" Ref ID - " +qrMerchantPanTypeVO.getRefId() + "Pan no - " +qrMerchantPanTypeVO.getRefValue());
					System.out.println("Inside the for loop check");
					System.out.println("REF ID:::::"+qrMerchantPanTypeVO.getRefId() +"::REF VALUE::::"+ qrMerchantPanTypeVO.getRefValue());
					if(qrMerchantPanTypeVO.getRefId() == null || qrMerchantPanTypeVO.getRefValue()==null||
							qrMerchantPanTypeVO.getRefId().equals("") || qrMerchantPanTypeVO.getRefValue().equals(""))
					{
						System.out.println("EITHER OF REF ID & REF VALUE OR BOTH NOT PRESENT");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._235.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._235.getMessage());
						validatorFlag = true;
						//break;
					}else if(CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())){
						if(!((qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)
								&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)))){
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							validatorFlag = true;
							//break;
						}
					}else if(CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId())){
						if(!((qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)
								&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)))){
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							validatorFlag = true;
							//break;
						}
					}else{
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
						validatorFlag = true;
						//break;
					}

				}
				/*
				System.out.println("Before the for loop check");
				for(QRMerchantPanTypeVO qrMerchantPanTypeVO : merchantPanList){
					
				}*/
			}

		}
		if(merchantFlag==false && multiMerchFlag==true) {
			System.out.println("Customer Selected Card and Merchant PAN not belong to Same Network ---> I");
		} else
		if(validatorFlag){
			System.out.println("Customer Selected Card and Merchant PAN not belong to Same Network ---> II");
		}
			
	}
}

