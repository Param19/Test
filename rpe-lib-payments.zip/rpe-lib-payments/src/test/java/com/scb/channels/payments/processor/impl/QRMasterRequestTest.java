package com.scb.channels.payments.processor.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.Assert;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.payment.helper.TestHelper;

public class QRMasterRequestTest {

	private static ApplicationContext context = null;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRMasterRequestTest.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context = TestHelper.getContext();
	}

	@Test
	public void testPayBill() throws Exception {
		
		CamelContext camelContext = (CamelContext) context.getBean("paymentCamelConfig");
		Assert.assertNotNull(camelContext);
		
		ProducerTemplate template = camelContext.createProducerTemplate();
		PayloadDTO payload = getRequestPayload();
		Object obj = template.requestBody("direct:makeQRPaymentMaster",payload);
		
		//Object obj = template.requestBody("direct:paymentResponseTopic",readFile());
		
		//Object obj = template.requestBody("direct:paymentRetry", "TEst");
		
		Assert.assertNotNull(obj);
	}
	
	public static PayloadDTO getRequestPayload() {
		PayloadDTO payload = new PayloadDTO();
		
		QRPaymentRequestVO requestVO = new QRPaymentRequestVO();
		QRPaymentResponseVO responseVO = new QRPaymentResponseVO();
		QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
		
		try{
		qrPaymentDetailVO.setCountryCode("IN");
		qrPaymentDetailVO.setStan("345678");
		qrPaymentDetailVO.setHost_reference("201704040004");
		qrPaymentDetailVO.setMerchantPan("4940767011788501");
		qrPaymentDetailVO.setSourceOfFund("CARD");
		Date expiryDate = new Date();
		DateFormat expiryD = new SimpleDateFormat("yyMM");
		qrPaymentDetailVO.setCardExpiryDate(expiryD.format(expiryDate));
		qrPaymentDetailVO.setTotalPaymentAmt(new BigDecimal("120.00"));
		qrPaymentDetailVO.setCardNumber("4940767011788501");
		qrPaymentDetailVO.setTxnCurrencyCode("356");
		qrPaymentDetailVO.setCustomer_full_name("XXX YY");
		qrPaymentDetailVO.setCard_type("VISA");
		requestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		payload.setRequestVO(requestVO);
		payload.setResponseVO(responseVO);
		
		}catch(Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		return payload;
		
		
		
	}



}
