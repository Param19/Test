package com.scb.channels.payments.processor.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.service.ReferenceService;

public class PayeeManagementTest {
 
	private static final Logger Logger = (Logger) LoggerFactory.getLogger(PayeeManagementTest.class);
	
	/*@Test
	public void testValidateWalletPayeeRpeCS() {
		Logger.info("Inside PayeeManagementTest testValidateWalletPayeeRpeCS method");
		ApplicationContext context=	getcontext();
		assertNotNull(context);
		PayloadDTO payload = populateRequestPayloadDTO(new PayloadDTO());
		PayeeManagementService paymentServiceImpl = (PayeeManagementService)context.getBean("PayeeManagementService");
		paymentServiceImpl.validateWalletPayeeRpeCS(payload);
		Logger.debug("Inside PayeeManagementTest testValidateWalletPayeeRpeCS method End");
	}*/
	
	
	@Test
	public void testCustomizedErrorMessage() {
		Logger.info("Inside PayeeManagementTest testCustomizedErrorMessage method");
		ApplicationContext context=	getcontext();
		assertNotNull(context);
		ReferenceService refService = (ReferenceService)context.getBean("referenceService");
		Map<String, ApplicationMessageVO> customizedMessages = refService.getCustomizedMessages("CI", "IBNK", "CRAFTSILICON", "ORANGEMM");
		System.out.println("customizedMessages.size(): "+customizedMessages.size());;
		Logger.debug("Inside PayeeManagementTest testCustomizedErrorMessage method End");
	}
	
	/**
	 * @return
	 */
	private PayloadDTO	populateRequestForCusMessage(PayloadDTO payload){

		System.out.println("Inside populate Request Payload DTO");
		
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();

		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("00000000-0000-2018-0608-111111111");
		messageVO.setRequestCode("00000000-0000-2018-0608-111111111");
		billerPayRequestVO.setMessageVO(messageVO);
		
		UserVO user = new UserVO();
		user.setChannelId("IBNK");
		user.setCountry("CI");
		user.setEnvironment("DEV");
		user.setCustName("Oranger");
		//user.setCustomerId("0607201801");3000008437
		//user.setCustomerId("3000008437");
		user.setCustomerId("0612201801");
		billerPayRequestVO.setUser(user);
		
		ClientVO clientVO = new ClientVO();
		clientVO.setClientId("12321");
		clientVO.setAppName("IBANK");
		clientVO.setCountry("CI");
		clientVO.setEnvironment("DEV");
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		//clientVO.setDate(new GregorianCalendar());
		billerPayRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("WALLET"); // for orang money - as per contract
		serviceVO.setHostEnv("SRM");
		serviceVO.setServiceTxnType("Insert");
		billerPayRequestVO.setServiceVO(serviceVO);
		
	/*	AccountVO srcAccVO = new AccountVO(); 
		srcAccVO.setAccountNumber("4509361249999743");
		srcAccVO.setAmount(new BigDecimal("14"));*/
		
		Date tranxDate;
        Calendar cal1 = DateUtils.getCountryCalendar();
        cal1.set(Calendar.MONTH, 9);
        cal1.set(Calendar.DATE, 13);
        cal1.set(Calendar.YEAR, 2017);
       
        tranxDate = cal1.getTime();	
        System.out.println(tranxDate);

		/*TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setHostTxnRefNo("1000717");
		transactionInfoVO.setSourceSystemName("IBNK");
		transactionInfoVO.setDtCreated(tranxDate);
		transactionInfoVO.setSrcAccountVO(srcAccVO);
		transactionInfoVO.setDtProcessed(tranxDate);*/
        BillerField billerField1 = new BillerField();
        billerField1.setFieldLabelName("INFOFIELD9");
        billerField1.setFieldType("N");
        billerField1.setCaption("WALLET ID");
        billerField1.setFieldDataType("Numeric");
        billerField1.setFieldMinLength("9");
        billerField1.setFieldMaxLength("12");
        billerField1.setIsfieldRequired("Y");
        billerField1.setOrderSequence(1);
        billerField1.setFieldValue("7702100022");
       // billerField1.setFieldValue("2018210302");
        
        BillerField billerField2 = new BillerField();
        billerField2.setFieldLabelName("INFOFIELD1");
        billerField2.setFieldType("N");
        billerField2.setCaption("Activation Key");
        billerField2.setFieldDataType("Text");
        billerField2.setFieldMinLength("5");
        billerField2.setFieldMaxLength("25");
        billerField2.setIsfieldRequired("Y");
        billerField2.setOrderSequence(3);
        billerField2.setFieldValue("D4XE2DZA");
        
        BillerField billerField3 = new BillerField();
        billerField3.setFieldLabelName("INFOFIELD3");
        billerField3.setFieldType("N");
        billerField3.setCaption("Transfer Type");
        billerField3.setFieldDataType("LIST");
        billerField3.setFieldMinLength("4");
        billerField3.setFieldMaxLength("20");
        billerField3.setIsfieldRequired("Y");
        billerField3.setOrderSequence(3);
        billerField3.setFieldValue("Account to Wallet");
        
        BillerField billerField4 = new BillerField();
        billerField4.setFieldLabelName("ACCOUNT");
        billerField4.setFieldType("N");
        billerField4.setCaption("Linking Account");
        billerField4.setFieldDataType("Text");
        billerField4.setIsfieldRequired("Y");
        billerField4.setOrderSequence(4);
        //billerField4.setFieldValue("0150101024900");//new
        billerField4.setFieldValue("0150100252000");//existing
        
        
        /*<pay:FieldLabelName>INFOFIELD9</pay:FieldLabelName>
        <pay:FieldType>N</pay:FieldType>
        <pay:Caption>WALLET ID</pay:Caption>
        <pay:FieldDataType>Numeric</pay:FieldDataType>
        <pay:FieldMinLength>9</pay:FieldMinLength>
        <pay:FieldMaxLength>12</pay:FieldMaxLength>
        <pay:IsfieldRequired>Y</pay:IsfieldRequired>
        <pay:OrderSequence>1</pay:OrderSequence>
        <pay:FieldValue>7702200022</pay:FieldValue>*/
        
		//billerPayDetailsVO.setPayeeId("");
		billerPayDetailsVO.setPayRef("1000717");
		billerPayDetailsVO.setBillerCd("ORANGEMM");
		billerPayDetailsVO.setBillerCategoryCd("AFT-Wallet");
		//billerPayDetailsVO.id
		billerPayDetailsVO.setBillerNickName("valid Key Wallet to Accnt");
	//	billerPayDetailsVO.setConsumerNo("7702200022"); //wallet number
		
		List<BillerField> billerFields = new ArrayList<BillerField>();
		billerFields.add(billerField1);
		billerFields.add(billerField2);
		billerFields.add(billerField3);
		billerFields.add(billerField4);
		
		billerPayDetailsVO.setBillerFields(billerFields);
		//billerPayDetailsVO.setBillerCd();
		//billerPayDetailsVO.consumerDesc
		//billerPayDetailsVO.consumerNo
		//billerPayDetailsVO.txnActStatus
		//billerPayDetailsVO.setBille
		//billerPayDetailsVO.payeeId
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		
        payload.setRequestVO(billerPayRequestVO);
		return payload;
	
	}
	
	/**
	 * @param payload
	 * @return
	 */
	private PayloadDTO populateRequestPayloadDTO(PayloadDTO payload){
		System.out.println("Inside populate Request Payload DTO");
		
		BillerPayRequestVO billerPayRequestVO = new BillerPayRequestVO();
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();

		MessageVO messageVO = new MessageVO();
		messageVO.setReqID("00000000-0000-2018-0608-111111111");
		messageVO.setRequestCode("00000000-0000-2018-0608-111111111");
		billerPayRequestVO.setMessageVO(messageVO);
		
		UserVO user = new UserVO();
		user.setChannelId("IBNK");
		user.setCountry("CI");
		user.setEnvironment("DEV");
		user.setCustName("Oranger");
		//user.setCustomerId("0607201801");3000008437
		//user.setCustomerId("3000008437");
		user.setCustomerId("0612201801");
		billerPayRequestVO.setUser(user);
		
		ClientVO clientVO = new ClientVO();
		clientVO.setClientId("12321");
		clientVO.setAppName("IBANK");
		clientVO.setCountry("CI");
		clientVO.setEnvironment("DEV");
		clientVO.setIpAddress("127.0.0.1");
		clientVO.setClientIpAddress("127.0.0.1");
		//clientVO.setDate(new GregorianCalendar());
		billerPayRequestVO.setClientVO(clientVO);
		
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setServiceName("WALLET"); // for orang money - as per contract
		serviceVO.setHostEnv("SRM");
		serviceVO.setServiceTxnType("Insert");
		billerPayRequestVO.setServiceVO(serviceVO);
		
	/*	AccountVO srcAccVO = new AccountVO(); 
		srcAccVO.setAccountNumber("4509361249999743");
		srcAccVO.setAmount(new BigDecimal("14"));*/
		
		Date tranxDate;
        Calendar cal1 = DateUtils.getCountryCalendar();
        cal1.set(Calendar.MONTH, 9);
        cal1.set(Calendar.DATE, 13);
        cal1.set(Calendar.YEAR, 2017);
       
        tranxDate = cal1.getTime();	
        System.out.println(tranxDate);

		/*TransactionInfoVO transactionInfoVO = new TransactionInfoVO();
		transactionInfoVO.setHostTxnRefNo("1000717");
		transactionInfoVO.setSourceSystemName("IBNK");
		transactionInfoVO.setDtCreated(tranxDate);
		transactionInfoVO.setSrcAccountVO(srcAccVO);
		transactionInfoVO.setDtProcessed(tranxDate);*/
        BillerField billerField1 = new BillerField();
        billerField1.setFieldLabelName("INFOFIELD9");
        billerField1.setFieldType("N");
        billerField1.setCaption("WALLET ID");
        billerField1.setFieldDataType("Numeric");
        billerField1.setFieldMinLength("9");
        billerField1.setFieldMaxLength("12");
        billerField1.setIsfieldRequired("Y");
        billerField1.setOrderSequence(1);
        billerField1.setFieldValue("7702100022");
       // billerField1.setFieldValue("2018210302");
        
        BillerField billerField2 = new BillerField();
        billerField2.setFieldLabelName("INFOFIELD1");
        billerField2.setFieldType("N");
        billerField2.setCaption("Activation Key");
        billerField2.setFieldDataType("Text");
        billerField2.setFieldMinLength("5");
        billerField2.setFieldMaxLength("25");
        billerField2.setIsfieldRequired("Y");
        billerField2.setOrderSequence(3);
        billerField2.setFieldValue("D4XE2DZA");
        
        BillerField billerField3 = new BillerField();
        billerField3.setFieldLabelName("INFOFIELD3");
        billerField3.setFieldType("N");
        billerField3.setCaption("Transfer Type");
        billerField3.setFieldDataType("LIST");
        billerField3.setFieldMinLength("4");
        billerField3.setFieldMaxLength("20");
        billerField3.setIsfieldRequired("Y");
        billerField3.setOrderSequence(3);
        billerField3.setFieldValue("Account to Wallet");
        
        BillerField billerField4 = new BillerField();
        billerField4.setFieldLabelName("ACCOUNT");
        billerField4.setFieldType("N");
        billerField4.setCaption("Linking Account");
        billerField4.setFieldDataType("Text");
        billerField4.setIsfieldRequired("Y");
        billerField4.setOrderSequence(4);
        //billerField4.setFieldValue("0150101024900");//new
        billerField4.setFieldValue("0150100252000");//existing
        
        
        /*<pay:FieldLabelName>INFOFIELD9</pay:FieldLabelName>
        <pay:FieldType>N</pay:FieldType>
        <pay:Caption>WALLET ID</pay:Caption>
        <pay:FieldDataType>Numeric</pay:FieldDataType>
        <pay:FieldMinLength>9</pay:FieldMinLength>
        <pay:FieldMaxLength>12</pay:FieldMaxLength>
        <pay:IsfieldRequired>Y</pay:IsfieldRequired>
        <pay:OrderSequence>1</pay:OrderSequence>
        <pay:FieldValue>7702200022</pay:FieldValue>*/
        
		//billerPayDetailsVO.setPayeeId("");
		billerPayDetailsVO.setPayRef("1000717");
		billerPayDetailsVO.setBillerCd("ORANGEMM");
		billerPayDetailsVO.setBillerCategoryCd("AFT-Wallet");
		//billerPayDetailsVO.id
		billerPayDetailsVO.setBillerNickName("valid Key Wallet to Accnt");
	//	billerPayDetailsVO.setConsumerNo("7702200022"); //wallet number
		
		List<BillerField> billerFields = new ArrayList<BillerField>();
		billerFields.add(billerField1);
		billerFields.add(billerField2);
		billerFields.add(billerField3);
		billerFields.add(billerField4);
		
		billerPayDetailsVO.setBillerFields(billerFields);
		//billerPayDetailsVO.setBillerCd();
		//billerPayDetailsVO.consumerDesc
		//billerPayDetailsVO.consumerNo
		//billerPayDetailsVO.txnActStatus
		//billerPayDetailsVO.setBille
		//billerPayDetailsVO.payeeId
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		
        payload.setRequestVO(billerPayRequestVO);
		return payload;
	}
	
	//@Test
	/*public void testCheckIspayeeExists(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
		PayeeDetailsVO.setCustomerId("124");
		PayeeDetailsVO.setConsumerNumber("9876543123");
		PayeeDetailsVO.setBillerCode("123");
		PayeeDetailsVO.setCountryCode("NG");
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.checkIsPayeeExists(PayeeDetailsVO);
	}*/
	
	
	/*@Test
	public void testAddPayee(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
		PayeeDetailsVO.setCustomerId("124");
		PayeeDetailsVO.setConsumerNumber("9876543123");
		PayeeDetailsVO.setBillerCode("NGIS202101");
		PayeeDetailsVO.setCountryCode("NG");
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.savePayee(PayeeDetailsVO);
	}*/
	
//	@Test
	/*public void testDeletePayee(){
		PayeeDetailVO PayeeDetailsVO = new PayeeDetailVO();
	   // PayeeDetailsVO.setCustomerId("124");
		//PayeeDetailsVO.setConsumerNumber("9876543123");
		//PayeeDetailsVO.setBillerCode("NGIS202101");
		//PayeeDetailsVO.setCountryCode("NG");
		PayeeDetailsVO.setPayeeId(123);
		PayeeManagementDAO payee=	getcontext().getBean("PayeeManagementDAO",PayeeManagementDAO.class);
		payee.deletePayee(PayeeDetailsVO);
	}*/
	public static  ApplicationContext getcontext(){
		ApplicationContext ap = new ClassPathXmlApplicationContext("/spring/payment-dao-context.xml","/spring/payment-service-context.xml");
		//context = new ClassPathXmlApplicationContext("classpath:spring/payment*.xml","/spring/base*.xml");
		return ap;
		
	}

}
