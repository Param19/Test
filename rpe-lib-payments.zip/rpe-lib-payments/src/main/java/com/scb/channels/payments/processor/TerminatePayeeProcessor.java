package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.PayeeManagementService;
import com.scb.channels.payments.service.PaymentDetailsService;

public class TerminatePayeeProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(TerminatePayeeProcessor.class);
	/**
	 * payeeService
	 */
	private PayeeManagementService payeeService;

	/**
	 * @return the payeeService
	 */
	public PayeeManagementService getPayeeService() {
		return payeeService;
	}

	/**
	 * @param payeeService the payeeService to set
	 */
	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}
	/**
	 * @param payloadDTO
	 * @return
	 */
	public PayloadDTO process(PayloadDTO payloadDTO) {
		LOGGER.info("TerminatePayeeProcessor :: process :: Start");
		try{
		if(payeeService.terminateInactivePayee(CommonConstants.HK_COUNTRY_CODE)){
			LOGGER.info("TerminatePayeeProcessor :: process :: Successfully");
		}else{
			LOGGER.info("TerminatePayeeProcessor :: process :: Failed");
			LOGGER.info("TERMINATE INACTIVE PAYEES PROCESS FAILED");
		}
		}catch(Exception e){
			LOGGER.info("TERMINATE INACTIVE PAYEES PROCESS FAILED");
			LOGGER.info("TerminatePayeeProcessor :: process :: Exception"+e.getMessage());	
		}
		LOGGER.info("TerminatePayeeProcessor :: process :: End");
		return payloadDTO;
	}
}