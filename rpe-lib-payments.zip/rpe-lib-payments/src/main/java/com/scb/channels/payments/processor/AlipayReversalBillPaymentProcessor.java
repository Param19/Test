/**
 * 
 */
package com.scb.channels.payments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentTransactionService;

/**
 * @author 1470817
 *
 */

public class AlipayReversalBillPaymentProcessor extends AbstractProcessor{
	
	
	public PaymentTransactionService getAlipayPaymentTransactionService() {
		return alipayPaymentTransactionService;
	}


	public void setAlipayPaymentTransactionService(
			PaymentTransactionService alipayPaymentTransactionService) {
		this.alipayPaymentTransactionService = alipayPaymentTransactionService;
	}


	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AlipayReversalBillPaymentProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService alipayPaymentTransactionService;
	
	
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
	BillerPayResponseVO billerPayResponseVO = null;
	BillerPayRequestVO billerPayRequestVO = null;
	try {
		billerPayRequestVO = bean.getRequestVO() != null ? 
				(BillerPayRequestVO)bean.getRequestVO() : null;
		
		if(billerPayRequestVO == null && bean.getResponseVO() != null) {
			billerPayRequestVO = new BillerPayRequestVO();
			billerPayResponseVO = (BillerPayResponseVO)bean.getResponseVO();
			
			billerPayRequestVO.setBillerPayDetailsVO(billerPayResponseVO.getBillerPayDetailsVO());
			billerPayRequestVO.setUser(billerPayResponseVO.getUser());
			billerPayRequestVO.setMessageVO(billerPayResponseVO.getMessageVO());
			billerPayRequestVO.setClientVO(billerPayResponseVO.getClientVO());
			billerPayRequestVO.setServiceVO(billerPayResponseVO.getServiceVO());
			
			billerPayRequestVO.setHostResponseVO(billerPayResponseVO.getHostResponseVO());
		}
		
		billerPayResponseVO = alipayPaymentTransactionService.reversalBillPayment(billerPayRequestVO);
		// To check whether the response object is empty or not
		if (billerPayResponseVO == null) {
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setStatusDesc(ExceptionMessages._106.getMessage());
			billerPayResponseVO.setStatus(ExceptionMessages._106.getCode());
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
			billerPayRequestVO.setErrorDesc(ExceptionMessages._106.getMessage());
			billerPayRequestVO.setErrorCD(ExceptionMessages._106.getCode());
		}
      }catch (Exception e) {
		LOGGER.error(e.getMessage());
		if (billerPayResponseVO == null) {
			billerPayResponseVO = new BillerPayResponseVO();
		}
		billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
		billerPayResponseVO.setStatusDesc(e.getMessage());
		billerPayRequestVO.setErrorDesc(e.getMessage());
		billerPayRequestVO.setErrorCD(ExceptionMessages._105.getCode());
		billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
		
		if(e instanceof WebServiceException){
			LOGGER.info("Setting timeout for card auth reversal ::: " 
					+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			LOGGER.error(e.getCause().toString());
			billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
			billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
			
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.REVERSAL_PAY_TIMEOUT);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
		}
		
	} finally{
		if (billerPayResponseVO == null) {
			billerPayResponseVO = new BillerPayResponseVO();
		}
		
		if(billerPayResponseVO.getHostResponseVO() != null) {
			for(HostResponseVO hostRes : billerPayRequestVO.getHostResponseVO()) {
				billerPayResponseVO.getHostResponseVO().add(hostRes);
			}
		}
		
		if(billerPayResponseVO.getBillerPayDetailsVO() == null) {
			billerPayResponseVO.setBillerPayDetailsVO(
					billerPayRequestVO.getBillerPayDetailsVO());
		}
		
		if(billerPayResponseVO.getBillerPayDetailsVO() != null && 
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
			LOGGER.info("Setting the aggregator response status details to host response list in alipay reversal" + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			
			HostResponseVO hostResponse = new HostResponseVO();
			hostResponse.setCode(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
			hostResponse.setDesc(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			hostResponse.setHostName(billerPayResponseVO.getBillerPayDetailsVO().getHostName());
			
			billerPayRequestVO.getHostResponseVO().add(hostResponse);
		}
		
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		bean.setResponseVO(billerPayResponseVO);
	}
	return bean;

	}	
	
}
