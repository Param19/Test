/**
 * 
 */
package com.scb.channels.payments.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.PaymentHistoryResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.PaymentService;
import com.scb.channels.paymentservice.PaymentHistoryResponse;

/**
 * @author 1470817
 * 
 */
public class PaymentHistoryProcessor extends AbstractProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentHistoryProcessor.class);

	private PaymentService paymentService;

	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.debug("In 000000000000 --> PaymentHistoryProcessor "+bean.getRequestVO().getMessageVO().getReqID());
		PaymentHistoryRequestVO paymentRequestVO = null;
		List<PaymentDetailVO> paymentHistList = null;
		PaymentHistoryResponseVO paymentResponse = new PaymentHistoryResponseVO();
		try {

			paymentRequestVO = (PaymentHistoryRequestVO) bean.getRequestVO();
			paymentHistList = paymentService.getCustPaymentHistoryById(paymentRequestVO);
			LOGGER.info("After getting the values from DB ------> PaymentHistoryProcessor "	+ paymentHistList);
			paymentResponse.setStatus(Messages._150.getCode());
			paymentResponse.setStatusDesc(Messages._150.getMessage());
			paymentResponse.setPaymentHistList(paymentHistList);
			paymentResponse.setClientVO(paymentRequestVO.getClientVO());
			paymentResponse.setUser(paymentRequestVO.getUser());
			paymentResponse.setServiceVO(paymentRequestVO.getServiceVO());
			paymentResponse.setMessageVO(paymentRequestVO.getMessageVO());
			
			bean.setResponseVO(paymentResponse);
		} catch (Exception e) {

			LOGGER.error("Exception block at DoTask --> PaymentHistoryProcessor "
					+ e.getMessage());
			paymentResponse.setErrorDesc(ExceptionMessages._152.getMessage());
			paymentResponse.setErrorCD(ExceptionMessages._152.getCode());
		}
		// /Testing
		
	/* PaymentHistoryResponse
		  res=BillpaymentMappingHelper.getPaymentHistoryResponse(paymentResponse);
		  
		  LOGGER.info(
		  "Convert into wsdl response object --> PaymentHistoryProcessor "+
		  res);*/
		 

		// end
		return bean;

	}
	
	protected PayloadDTO doTest(PayloadDTO bean) throws BusinessException {
		LOGGER.debug("Inside doTestttttttttttttttttttttttttttttttttttttttttt");
		LOGGER.debug(bean.getResponseVO().getStatus() + " <--- Status Before putttting in to Response Queue Status desc ---- > "+bean.getResponseVO().getStatusDesc());
		return bean;
		}

	public PaymentService getPaymentService() {
		return paymentService;
	}

	public void setPaymentService(PaymentService paymentService) {
		this.paymentService = paymentService;
	}

}
