package com.scb.channels.payments.helper;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.invoice.BillerCategory;
import com.sc.cash.payment.mobile.v2.invoice.Invoice;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillerCategoriesReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersProductsReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersProductsRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.BaseVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.BillerDownloadHistory;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.base.vo.TempBillerField;
import com.scb.channels.base.vo.TempBillerVO;
import com.scb.channels.common.vo.ReferenceVO;
import com.scb.channels.mapper.helper.AggregatorMappingHelper;
 
public class InvoiceAggregatorhelper {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceAggregatorhelper.class);
	
	public static GetBillerCategoriesReq getAggregatorBillerCatgeoryRequest(BillerDownloadRequest request){
		XMLGregorianCalendar calendar =getGregorianCalendar();
	GetBillerCategoriesReq aggregatorRequest=AggregatorMappingHelper.getBillerCategoryMapping(request);
	aggregatorRequest.getHeader().getOriginationDetails().setMessageTimestamp(calendar);
	aggregatorRequest.getHeader().getOriginationDetails().setInitiatedTimestamp(calendar);	 
	return aggregatorRequest;

	}
	
	/**
	 * <p> used for the   Aggregator Biller products mapping
	 * @param BillerDownloadRequest
	 * @return GetBillersProductsReq
	 */
	public static GetBillersProductsReq getAggregatorBillerProductRequest(BillerDownloadRequest request){
		XMLGregorianCalendar calendar =getGregorianCalendar();
		GetBillersProductsReq aggregatorRequest=AggregatorMappingHelper.getBillerProductMapping(request);
		aggregatorRequest.getHeader().getOriginationDetails().setMessageTimestamp(calendar);
		aggregatorRequest.getHeader().getOriginationDetails().setInitiatedTimestamp(calendar);	 
		return aggregatorRequest;

		}
	/**
	 * <p> used for the   Aggregator Biller products mapping
	 * @param BillerDownloadRequest
	 * @return GetBillersProductsReq
	 */
	public static GetBillersReq getAggregatorAllBillersRequest(BillerDownloadRequest request){
		GetBillersReq aggregatorBillerRequest=null;
		XMLGregorianCalendar calendar =getGregorianCalendar();
		request.getMessageVO().setReqID(getFrequentGenerateUniqueId());
		aggregatorBillerRequest=AggregatorMappingHelper.getAllBillerMapping(request);
		aggregatorBillerRequest.getHeader().getOriginationDetails().setMessageTimestamp(calendar);
		aggregatorBillerRequest.getHeader().getOriginationDetails().setInitiatedTimestamp(calendar);	 
		return aggregatorBillerRequest;

		}
	
	
	
	public  static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
			return date;
		}

	
	public static PayloadDTO aggregatorBillerCategorymapping(Invoice invoice,PayloadDTO dto){
		BillerDownloadRequest request=(BillerDownloadRequest) dto.getRequestVO();
		String Country=dto.getRequestVO().getUser().getCountry();
		String aggregatorCode =request.getAggregatorShortCode();
		BillerDownloadResponse response=AggregatorMappingHelper.getBillerCategoryMapping(invoice);
		if(response!=null && response.getTempBillerCategory()!=null && response.getTempBillerCategory().size()>0){
			//makeUniqueBillerCategoriesforAggragator(Country,aggregatorCode,response);
			dto.setResponseVO(response); 
		}else{
			request.setStatus(ExceptionMessages._181.getCode());
			request.setStatusDesc(ExceptionMessages._181.getMessage());
		}
		return dto;
		
	}
	
	
	public static void  makeUniqueBillerCategoriesforAggragator(String County, String AggregatorCode, BillerDownloadResponse response){
		 List<TempBillerCategoryVO> categoriesList=response.getTempBillerCategory();
		 for(TempBillerCategoryVO category:categoriesList){
			 String catgegoryid =category.getCategoryId();
			 category.setCategoryId(County+AggregatorCode+catgegoryid);
		 	}
		 response.setTempBillerCategory(categoriesList);
	}
	
	
	public static void generateRefnumber(BillerDownloadRequest request){
		
		String Refno="";
		try{
		Refno=ReferenceNumberGenerator.generateReferenceNumber(request.getUser().getCountry(), request.getServiceVO().getServiceName(), request.getMessageSender());
		}catch(Exception e ){
			Refno=UUID.randomUUID().toString();
			
		}
		request.setAggregatorRefNo(Refno);
	}
	
	
	public static void mappingBillercategorieswithBillerList(PayloadDTO dto,List<BillerCategory> aggregatorList){
		int count=0;
		try{
		BillerDownloadRequest request=	(BillerDownloadRequest)dto.getRequestVO();
		BillerDownloadResponse response=null;
		String Country=request.getUser().getCountry();
		String ChannelId=request.getMessageSender();
		if(dto.getResponseVO()!=null){
		  response=	(BillerDownloadResponse)dto.getResponseVO();
		}else{
			 response=new BillerDownloadResponse();
			
		}
		List<TempBillerCategoryVO> tempList=response.getTempBillerCategory();
			
		 
			
			for(BillerCategory aggregatorBiller:aggregatorList){
				BillerCategory biller=aggregatorBiller;
				TempBillerCategoryVO tempCategory=AggregatorMappingHelper.getBillerResponseSingleMapping(biller);
			//	tempList.removeAll(tempList); /** testing purpose only  to remove avoid the billers **/
				tempList.add(tempCategory);
			}
			
			response.setTempBillerCategory(tempList);
			dto.setResponseVO(response);
  
		}catch(Exception exception){
			LOGGER.error("Exception occurred during getBiller Categories. from the EDMI" + exception.getMessage());
		}
	
	}
	
	
		public static void getProductDetailsforBiller(BillerDownloadRequest request,InvoicePortType invoice){
			GetBillersProductsRes aggregatorProductResponse=null;
			GetBillersProductsReq productrequest=null;
			request.setSubTypeName(CommonConstants.EDMI_GETBILLER_PRODUCTS_NAME);
			request.setEventType(CommonConstants.GET);
			request.setInternalRequestId(getFrequentGenerateUniqueId());
			try{
				productrequest=InvoiceAggregatorhelper.getAggregatorBillerProductRequest(request);
				aggregatorProductResponse=invoice.getBillersProducts(productrequest);
				}catch (Exception exception) {
				LOGGER.error("Exception occurred during getBiller products Categories. from the EDMI" + exception.getMessage());
				exception.printStackTrace();
				}
			
		}
		
		public static String getFrequentGenerateUniqueId(){
			String id="";
			try{
				id=UUID.randomUUID().toString();
			}catch(Exception e){
				id=Long.toString(System.currentTimeMillis());
			}
			
			return id;
		}
	
		
		public static void encrichWithCountryDetails(PayloadDTO dto){
			String Channel="";
			String Country="";
			String AggCode="";
			BillerDownloadRequest  request=	(BillerDownloadRequest)dto.getRequestVO();
			BillerDownloadResponse  response=	(BillerDownloadResponse)dto.getResponseVO();
			if(StringUtils.isNotBlank(request.getUser().getChannelId())){
				Channel=request.getChannelName();
			}
			Country=request.getUser().getCountry();
		
			AggCode=request.getAggregatorShortCode();
			List<TempBillerCategoryVO>  tempCategoryList=response.getTempBillerCategory();
			for(TempBillerCategoryVO  Category:tempCategoryList ){
				TempBillerCategoryVO tempCategory=Category;
				Set<TempBillerVO>  tempbillerList=tempCategory.getBillers();
				 
						for(TempBillerVO  Biller:tempbillerList ){
							TempBillerVO tempBiller=Biller;
								tempBiller.setCountryCode(Country);
								tempBiller.setChannel(Channel);
								tempBiller.setBillerUniqueId(Country+AggCode+tempBiller.getBillerUniqueId());
								tempBiller.setStatusCode(CommonConstants.ACTIVE);
								tempBiller.setCategorytype(tempCategory);
								
								Set<TempBillerField> tempBillerFieldSet=	tempBiller.getBillerFields();
								
									for(TempBillerField Billerfield:tempBillerFieldSet ){
										TempBillerField tempBillerfield=Billerfield;
										tempBillerfield.setChannelCode(Channel);
										tempBillerfield.setCountryCode(Country);
										tempBillerfield.setBillerId(tempBiller);
										
									}
						}
						tempCategory.setChannel(Channel);
						tempCategory.setCountryCode(Country);
						tempCategory.setStatusCode(CommonConstants.ACTIVE);
			}
			
			
			
		}
		
		public static Double getDefualtAmountDouble(String doubleAmount){
			
			Double amount=null;
			try{
				if(doubleAmount!=null){
				amount=Double.valueOf(doubleAmount);
				if(amount>0){
					amount=amount/100;
					}
				}
			}catch(Exception e){
				LOGGER.error("Exception occurred ::: ",e);
			}
			
			return amount;
		}
		
		
		public static String getPresentmentType(String partPayment,String minimumAmount,String maximumAmount){
		
			String presentmentType=CommonConstants.ZERO;
			
			if(StringUtils.isNotBlank(minimumAmount) ||StringUtils.isNotBlank(maximumAmount)){
				if(CommonConstants.TRUE.equalsIgnoreCase(partPayment)){
					presentmentType=CommonConstants.ONE;
				}else{
					presentmentType=CommonConstants.TWO;
				}
			}
			
			return presentmentType;
			
		}
		
		
		public  static Set<BillerVO> mapSpecificBiller(Set<TempBillerVO> listeTempBiller,BillerCategoryVO  MasterCategory){
			
			Set<BillerVO> listMasterBillers =new  HashSet<BillerVO>();
			
			BillerVO billerVO=null;
			
		//	AggregatorMappingHelper.getMappingBillersToMasterBiller(listeTempBiller, listMasterBillers);
			for(TempBillerVO tempBillerVO:listeTempBiller){
				billerVO=new BillerVO();
			AggregatorMappingHelper.getMappingBillersToMasterBiller(tempBillerVO, billerVO);
			billerVO.setCategorytype(MasterCategory);
			listMasterBillers.add(billerVO);
			}
			
			/*for(BillerVO master:listMasterBillers){
				
				master.setCategorytype(MasterCategory);
			}*/
			
			return listMasterBillers;
			
		}
		

public static void makeinActiveBillerforInactiveCategories(BillerCategoryVO catgeory){
	try{
	catgeory.setStatusCode(CommonConstants.D);
	for(BillerVO biller:catgeory.getBillers()){
		biller.setStatusCode(CommonConstants.D);
	}
	
		}catch(Exception e){
			LOGGER.error("Exception occurred ::: ",e);
				
			}

}


public static void downloadHistoryforExistCategory(BillerCategoryVO catgeory,String Status,String remarks,List<BillerDownloadHistory> downloadHistory){
	try{
		
	BillerDownloadHistory historyCategory= new BillerDownloadHistory();
	historyCategory.setBillerCategory(catgeory.getCategoryName());
	historyCategory.setBillerCategoryId(catgeory.getCategoryId());
	historyCategory.setDescription(remarks);
	historyCategory.setStatus(Status);
	historyCategory.setCreatedTime(catgeory.getDateCreated());
	historyCategory.setUpdateTime(getCurrentTimestamp());
	downloadHistory.add(historyCategory);
	for(BillerVO biller:catgeory.getBillers()){
		downloadHistoryforExistBiller(biller, catgeory,Status, remarks, downloadHistory);
	}
		}catch(Exception e){
			LOGGER.error("Exception occurred ::: ",e);
			
		}
}

public static void downloadHistoryforExistBiller(BillerVO biller,BillerCategoryVO catgeory,String Status,String remarks,List<BillerDownloadHistory> downloadHistory){
	
	try{
		BillerDownloadHistory historyCategory = new BillerDownloadHistory();
	
	historyCategory.setBillerCategory(catgeory.getCategoryName());
	historyCategory.setBillerCategoryId(catgeory.getCategoryId());
	historyCategory.setDescription(remarks);
	historyCategory.setStatus(Status);
	historyCategory.setCreatedTime(catgeory.getDateCreated());
	historyCategory.setUpdateTime(getCurrentTimestamp());
	historyCategory.setBillerId(biller.getBillerUniqueId());
	historyCategory.setBillerName(biller.getBillerDesc());
	historyCategory.setProductName(biller.getBillerProductName());
	downloadHistory.add(historyCategory);
	}catch(Exception e){
		LOGGER.error("Exception occurred ::: ",e);
		
	}
}


/**
 * @param catgeories
 * @param Status
 * @param remarks
 * @param downloadHistory
 *   <p> Audit history for the new CategoriesSet</p>.
 */
public static void downloadHistorycategoryforNewTempList(List<TempBillerCategoryVO> catgeories,String Status,String remarks,List<BillerDownloadHistory> downloadHistory){
	try{
	for(TempBillerCategoryVO catgeory:catgeories){
		downloadHistorycategoryforNewTempcategory(catgeory,Status,remarks,downloadHistory);
	}
	}catch(Exception e){
		LOGGER.error("Exception occurred ::: ",e);
		
	}
}


/**
 * @param catgeory
 * @param Status
 * @param remarks
 * @param downloadHistory
 * <p> Audit history for the new Category</p>.
 */
public static void downloadHistorycategoryforNewTempcategory(TempBillerCategoryVO catgeory,String Status,String remarks,List<BillerDownloadHistory> downloadHistory){
	try{ 
	BillerDownloadHistory historyCategory= new BillerDownloadHistory();
	historyCategory.setBillerCategory(catgeory.getCategoryName());
	historyCategory.setBillerCategoryId(catgeory.getCategoryId());
	historyCategory.setDescription(remarks);
	historyCategory.setStatus(Status);
	historyCategory.setCountryCode(catgeory.getCountryCode());
	historyCategory.setCreatedTime(catgeory.getDateCreated());
	historyCategory.setUpdateTime(getCurrentTimestamp());
	downloadHistory.add(historyCategory);
	downloadHistorycategoryforNewTempBillersSet(catgeory.getBillers(),catgeory, Status, remarks, downloadHistory);
	}catch(Exception e){
		LOGGER.error("Exception occurred ::: ",e);
		
	}
}


public static void downloadHistorycategoryforNewTempBillersSet(Set<TempBillerVO> billers,TempBillerCategoryVO catgeory,String Status,String remarks,List<BillerDownloadHistory> downloadHistory){
	try{
	for(TempBillerVO biller :catgeory.getBillers()){
		downloadHistorycategoryforNewTempBillers( biller, catgeory, Status, remarks, downloadHistory);	
	}
	}catch(Exception e){
		LOGGER.error("Exception occurred ::: ",e);
		
	}
	
}


public static void downloadHistorycategoryforNewTempBillers(TempBillerVO biller,TempBillerCategoryVO catgeory,String Status,String remarks,List<BillerDownloadHistory> downloadHistory){
	try{
	BillerDownloadHistory historyBiller= new BillerDownloadHistory();
	historyBiller.setBillerCategory(catgeory.getCategoryName());
	historyBiller.setBillerCategoryId(catgeory.getCategoryId());
	historyBiller.setDescription(remarks);
	historyBiller.setStatus(Status);
	historyBiller.setCreatedTime(catgeory.getDateCreated());
	historyBiller.setUpdateTime(getCurrentTimestamp());
	historyBiller.setBillerId(biller.getBillerUniqueId());
	historyBiller.setBillerName(biller.getBillerDesc());
	historyBiller.setProductName(biller.getBillerProductName());
	historyBiller.setCountryCode(catgeory.getCountryCode());
	downloadHistory.add(historyBiller);
	}catch(Exception e){
		LOGGER.error("Exception occurred ::: ",e);
		
	}
}


public static List<BillerCategoryVO> maptempCategoriestoActiveCategories(	List<TempBillerCategoryVO>  tempCategory){
	
	List<BillerCategoryVO>  newCategory=new ArrayList<BillerCategoryVO>();
	AggregatorMappingHelper.getMappingempBillersCatgeoryToMasterCatgeory(tempCategory,newCategory);
	return  newCategory;
}


		public static void enrichMasterCategoryData(List<BillerCategoryVO> biller){

		
			for(BillerCategoryVO  Category:biller ){
				BillerCategoryVO masterCategory=Category;
				Set<BillerVO>  masterBillerList=masterCategory.getBillers();
				 
						for(BillerVO  Biller:masterBillerList ){
							BillerVO masterBiller=Biller;
								masterBiller.setCategorytype(masterCategory);
								Set<BillerField> BillerFieldSet=masterBiller.getBillerFields();
								
									for(BillerField Billerfield:BillerFieldSet ){
																		 
										Billerfield.setBillerId(masterBiller);
										
									}
						}
						 
			}
		
		}
		
		
		
		public static void mapSaticCategoriesfromReference(List<BillerCatgegoryReference>  categoryRef,List<TempBillerCategoryVO> tempcategory){
			
			AggregatorMappingHelper.getStaticCategoryfromRefCategeory(categoryRef, tempcategory);
			
		}
		
		
		
	public static String getJVMName() {
		String jvmName="";
		try {
		if(StringUtils.isNotBlank(System.getProperty(CommonConstants.was_server_name))){
			jvmName=InetAddress.getLocalHost().getHostName()+CommonConstants.HYPHEN+System.getProperty(CommonConstants.was_server_name);
		}else{
				jvmName=InetAddress.getLocalHost().getHostName();
			
		}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jvmName;
	}
	
	public static String getIpAddress(){
		String ipAddress = "";
		try {
			ipAddress = InetAddress.getLocalHost().getHostAddress();
		} catch (Exception exception) {
			LOGGER.error("Exception occurred ::: ",exception);
		}
		
		return ipAddress;
	}
	
	public static Timestamp getCurrentTimestamp(){
		
		return new Timestamp(System.currentTimeMillis());
	}
	public static ReferenceVO getReferenceVO(BaseVO baseVO, String defaultChannel) {
		ReferenceVO referenceVO = getReferenceVO(baseVO);			
		if(defaultChannel !=null)
			referenceVO.setChannelId(defaultChannel);
		return referenceVO;
	}
	
	public static ReferenceVO getReferenceVO(BaseVO baseVO) {
		ReferenceVO referenceVO = new ReferenceVO();			
		referenceVO.setCountryCode(baseVO.getClientVO().getCountry());
		referenceVO.setChannelId(baseVO.getClientVO().getChannel());
		referenceVO.setAggregator(baseVO.getClientVO().getPartnerName());
		referenceVO.setType(baseVO.getClientVO().getPartnerType());
		return referenceVO;
	}
}
