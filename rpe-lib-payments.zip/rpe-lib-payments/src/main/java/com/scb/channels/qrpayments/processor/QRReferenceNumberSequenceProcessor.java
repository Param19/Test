package com.scb.channels.qrpayments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.qrpayments.service.QRPaymentTransactionService;

public class QRReferenceNumberSequenceProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRReferenceNumberSequenceProcessor.class);
	
	private QRPaymentTransactionService qrPaymentTransactionService;
	
	public PayloadDTO process(PayloadDTO bean) {
		LOGGER.info("Inside QRReference Number Sequence Processor process start :::");
		QRPaymentRequestVO qrPaymentRequestVO = null;
		String referenceNumber = null;
		try{
			qrPaymentRequestVO = (QRPaymentRequestVO)bean.getRequestVO();
			QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
			if (qrPaymentRequestVO != null){
				LOGGER.info("Before STAN Gen :::::"+System.currentTimeMillis());
				String sTAN = qrPaymentTransactionService.getQRReferenceNumberSequence(qrPaymentDetailVO);
				LOGGER.info("After STAN Gen :::::"+System.currentTimeMillis());
				int refNo = ReferenceNumberGenerator.generateJulianDate();
				referenceNumber = String.valueOf(refNo);
				/*if(qrPaymentRequestVO.getQrPaymentDetailVO().getCard_type() != null && qrPaymentRequestVO.getQrPaymentDetailVO().getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
					qrPaymentDetailVO.setNetwork(CommonConstants.VISA);
				}	
				else{
					qrPaymentDetailVO.setNetwork(CommonConstants.MASTER);	
					//referenceNumber = ReferenceNumberGenerator.generateQRReferenceNo(CommonConstants.THIRTEEN);
					if(!(qrPaymentRequestVO.getQrPaymentDetailVO().getSourceOfFund() != null && qrPaymentRequestVO.getQrPaymentDetailVO().getSourceOfFund().equalsIgnoreCase(CommonConstants.CASA)))
						referenceNumber = "0000000"+referenceNumber;
				}*/
				qrPaymentRequestVO.getQrPaymentDetailVO().setHost_reference(referenceNumber+sTAN);
				LOGGER.info("QRReference Number Sequence Processor :::"+qrPaymentDetailVO.getClient_reference()+" RRN :::::::::"+qrPaymentDetailVO.getHost_reference());
				qrPaymentRequestVO.getQrPaymentDetailVO().setStan(sTAN);
				bean.setResponseVO(qrPaymentRequestVO);
			}
		}catch(Exception e){
			LOGGER.info("Exception while QR Reference Number Sequence  ::: " , e);
		}
		return bean;
		
	}

	public QRPaymentTransactionService getQrPaymentTransactionService() {
		return qrPaymentTransactionService;
	}

	public void setQrPaymentTransactionService(
			QRPaymentTransactionService qrPaymentTransactionService) {
		this.qrPaymentTransactionService = qrPaymentTransactionService;
	}

	
}
