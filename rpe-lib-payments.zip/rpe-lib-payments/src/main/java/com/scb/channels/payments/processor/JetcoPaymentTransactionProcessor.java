package com.scb.channels.payments.processor;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.JetcoPaymentDetailVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.JetcoPayMappingHelper;
import com.scb.channels.payments.service.JetcoPaymentTransactionService;

/**
 * JetcoPaymentTransactionProcessor
 * 
 * @author 1552545
 * 
 */
public class JetcoPaymentTransactionProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(JetcoPaymentTransactionProcessor.class);

	private JetcoPaymentTransactionService jetcoPaymentTransactionService;


	/**
	 * Create JETCO payment record in RPE
	 * 
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO createJetcoPayment(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in Transaction Processor ::::: Start");
		if (bean != null && bean.getRequestVO() != null) {
			JetcoPayRequestVO jetcoRequest = (JetcoPayRequestVO) bean.getRequestVO();
			try {
				LOGGER.info("saving payment of payee " + jetcoRequest.getBankMessageId());
				Long paymentId = jetcoPaymentTransactionService.savePayment(jetcoRequest);
				LOGGER.info("payment saved for payee " + jetcoRequest.getBankMessageId());
				if (paymentId != null && paymentId != 0L) {
					jetcoRequest.setTxnActStatus(CommonConstants.SAVE_SUCCESS);
				} else {
					jetcoRequest.setTxnActStatus(CommonConstants.SAVE_FAIL);
				}
			} catch (Exception e) {
				LOGGER.info("Exception occurred whle saving payments ::: " + e);
				jetcoRequest.setTxnActStatus(CommonConstants.SAVE_FAIL);
				LOGGER.error(e.getMessage());
				throw new BusinessException(e.getMessage(), e.getCause());
			}
			bean.setResponseVO(JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoRequest));
		}
		LOGGER.info("Task in Transaction Processor ::::: End");
		return bean;
	}

	/**
	 * Update JETCO payment history
	 * 
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO updateJetcoPayment(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in Payment Update processor ::: Start");
		JetcoPayRequestVO jetcoPayRequestVO = (JetcoPayRequestVO) bean.getRequestVO();
		if (bean != null && bean.getRequestVO() != null) {
			LOGGER.info("Updating from request :::: " + jetcoPayRequestVO.getBankMessageId());
			jetcoPaymentTransactionService.updatePaymentStatus(jetcoPayRequestVO);
			LOGGER.info("Update complete :::: " + jetcoPayRequestVO.getBankMessageId());
		} else {
			LOGGER.info("Payload does not have all the valkues for update");
			throw new BusinessException("PayloadDTO can't be empty...");
		}
		LOGGER.info("Task in Payment Update processor ::: End");
		return bean;
	}

	/**
	 * Validate JETCO payment history existing
	 * 
	 * @param bean
	 * @return
	 */
	public PayloadDTO validateJetcoPayment(PayloadDTO bean) {
		LOGGER.info("Task of validating payment request ::: Start");
		JetcoPayRequestVO jetcoRequest = null;
		try {
			jetcoRequest = (JetcoPayRequestVO) bean.getRequestVO();
			LOGGER.info("Validating payment request for ::: " + jetcoRequest.getMessageVO().getReqID());
			if (StringUtils.isNotEmpty(jetcoRequest.getPaymentType())) {
				jetcoRequest.setPaymentType(CommonConstants.JETCO_TRANSACTION_ON_US);
				jetcoRequest.getServiceVO().setServiceTxnType(CommonConstants.JETCO_TRANSACTION_ON_US);// set payment type for response
			} else {
				jetcoRequest.setPaymentType(CommonConstants.JETCO_TRANSACTION_DEBIT);
				jetcoRequest.getServiceVO().setServiceTxnType(CommonConstants.JETCO_TRANSACTION_DEBIT);
			}
			// check jetcoRequest whether exist
			if (null != jetcoRequest.getBankMessageId()) {
				JetcoPaymentDetailVO jetcoPaymentDetailsVO = jetcoPaymentTransactionService.getPaymentDetails(jetcoRequest.getBankMessageId());
				if (null != jetcoPaymentDetailsVO) {
					jetcoRequest.setTxnActStatus(CommonConstants.FAIL);
					jetcoRequest.getTransactionInfo().setHostRespCd(ExceptionMessages._409.getCode());
					jetcoRequest.getTransactionInfo().setHostRespDesc(ExceptionMessages._409.getMessage());
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception while validating payment request ::: ", e);
			bean.setCurrentState(CommonConstants.FAIL);
			jetcoRequest.getTransactionInfo().setHostRespCd(CommonConstants.FAIL);
			jetcoRequest.getTransactionInfo().setHostRespDesc(e.getMessage());
		} finally {
			LOGGER.info("Setting header objects in response vo in payee validation" + jetcoRequest.getMessageVO().getReqID());
			bean.setResponseVO(JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoRequest));
		}
		bean.setRequestVO(jetcoRequest);
		LOGGER.info("Task of validating payment request ::: End");
		return bean;
	}

	public void setJetcoPaymentTransactionService(JetcoPaymentTransactionService jetcoPaymentTransactionService) {
		this.jetcoPaymentTransactionService = jetcoPaymentTransactionService;
	}

}
