package com.scb.channels.payments.dao;

import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;

public interface ArchivalDAO {

	BillerDownloadResponseVO archive(BillerDownloadRequest billerDownloadRequest);
	
}
