package com.scb.channels.payments.service;

import com.scb.channels.base.vo.PayloadDTO;

public interface BillerDownloadProcessService {
	
	
	public PayloadDTO getDataFromAggregator(PayloadDTO dto);
		
	public void  getBillerfromStaticCategoery(PayloadDTO dto);

	

}
