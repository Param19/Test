package com.scb.channels.payments.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PaymentDetailVO;

/**
 * The Interface PaymentTransactionDAO.
 */
public interface PaymentTransactionDAO {
 
	  /**
	   * Save payment txn.
	   *
	   * @param billerPayDetailsVO the biller pay details vo
	   */
	PaymentDetailVO savePayment(PaymentDetailVO payment);
	  
	  /**
	   * Update payment txn.
	   *
	   * @param billerPayDetailsVO the biller pay details vo
	   */
	  void updatePaymentStatus(PaymentDetailVO payment) throws DAOException;
	  

	  List<PaymentDetailVO> getReversalFailurePaymentTransactionList(BillerPayRequestVO billerPayRequestVO);
	  
	  public void updatePmtVersion(BillerPayDetailsVO billerPayDetailsVO);
	  
	  
		public void updateRequestVOString(BillerPayDetailsVO billerPayDetailsVO);
		
		public PaymentDetailVO getPaymentDetails(String referenceNumber);
  
		public List<PaymentDetailVO> getPaymentRetryList(BillerPayRequestVO billerPayRequestVO,Date fromDate,Date toDate, Timestamp updatedTimeStamp, int retryCount, List<String> statusList, List<String> countries);
		
		public List<PaymentDetailVO> getInprocessPayments(Date fromDate,Date toDate, Timestamp updatedTimeStamp, int retryCount, List<String> countries);
		
		public String getReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO);
		
		public String getCCReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO);
}
