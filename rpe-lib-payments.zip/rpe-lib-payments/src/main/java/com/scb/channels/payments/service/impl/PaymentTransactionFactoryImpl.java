package com.scb.channels.payments.service.impl;

import com.scb.channels.payments.service.PaymentTransactionFactory;
import com.scb.channels.payments.service.PaymentTransactionService;

public class PaymentTransactionFactoryImpl implements PaymentTransactionFactory {

	private PaymentTransactionService alipayPaymentTransactionService;
	private PaymentTransactionService paymentTransactionService;
	
	public PaymentTransactionService getPaymentTransactionServiceImpl(String className) {
		
		if(className.equals("PaymentTransactionServiceImpl")) {
			return getPaymentTransactionService();
			
		} else if(className.equals("AlipayPaymentTransactionServiceImpl")) {
			return getAlipayPaymentTransactionService();
		} else { //default retrun africa Payment service
			return getPaymentTransactionService();
		}
		
	}
	

	public PaymentTransactionService getAlipayPaymentTransactionService() {
		return alipayPaymentTransactionService;
	}

	public void setAlipayPaymentTransactionService(
			PaymentTransactionService alipayPaymentTransactionService) {
		this.alipayPaymentTransactionService = alipayPaymentTransactionService;
	}

	public PaymentTransactionService getPaymentTransactionService() {
		return paymentTransactionService;
	}

	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}

}
