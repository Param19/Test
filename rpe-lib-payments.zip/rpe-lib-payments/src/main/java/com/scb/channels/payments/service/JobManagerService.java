package com.scb.channels.payments.service;

import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.PayloadDTO;

public interface JobManagerService {
	
	public boolean getjobStatus(String country,String Jobname);
	public boolean finalJObupdateStaus(String country,String Jobname);
	
	public BillerDownloadResponseVO getBillerDownloadStatusCheck(BillerDownloadRequest billerDownloadRequest);

	public boolean addJob(String country, String jobName);
	public void removeJob(String country, String jobName);
	public PayloadDTO getJobPayloadForAudit(String jobName, String status);
	public PayloadDTO getQRJobPayloadForAudit(String jobName, String status);
}
