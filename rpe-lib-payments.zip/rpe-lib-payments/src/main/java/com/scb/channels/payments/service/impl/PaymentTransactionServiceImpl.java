package com.scb.channels.payments.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import javax.jms.JMSException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo;
import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.PostPaymentReq;
import com.sc.corebanking.v1.invoice.Invoice;
import com.sc.scbcorebankinginvoice.v1.ws.provider.invoice.InvoicePortType;
import com.sc.scbcorebankinginvoice.v1.ws.provider.invoice.PayBillReq;
import com.sc.scbcorebankinginvoice.v1.ws.provider.invoice.PayBillRes;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.GetTransactionReq;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.GetTransactionRes;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.ReverseTransactionReq;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.ReverseTransactionRes;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.TransactionPortType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.PayBillReqPayload;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.PostPaymentReqPayload;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentFieldDetails;
import com.scb.channels.common.helper.NarrationHelper;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.dao.BillerManagementDAO;
import com.scb.channels.payments.dao.PayeeManagementDAO;
import com.scb.channels.payments.dao.PaymentTransactionDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.CacheManagementService;
import com.scb.channels.payments.service.PaymentCommonService;
import com.scb.channels.payments.service.PaymentTransactionService;
import com.scb.channels.payments.service.TopicPostMessageService;
import com.scb.channels.paymentservice.BillerFields;

/**
 * The Class PaymentTransactionServiceImpl.
 */
public class PaymentTransactionServiceImpl implements PaymentTransactionService {

	/** The Constant BP_00. */
	public static final String BP_00 = "bp,00";

	/** The Constant TRANSACTION_PROCESSED. */
	public static final String TRANSACTION_PROCESSED = "Transaction Processed.";

	/** The Constant PAY_BILL_BY_ACCOUNT. */
	public static final String PAY_BILL_BY_ACCOUNT = "payBillByAccount";

	/** The payment transaction dao. */
	private PaymentTransactionDAO paymentTransactionDAO;

	/** The biller service. */
	private InvoicePortType billerService;

	/** The transaction port type. */
	private TransactionPortType transactionPortType;
	
	private BillerDownloadDAO billerDownloadDAO;
	
	private DataBean dataBean;
	
	private PayeeManagementDAO payeeManagementDAO;
	
	/** The transaction port type. */
	private com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType postTransactionService;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentTransactionServiceImpl.class);
	
	private TopicPostMessageService topicPostMessageService;

	private BillerManagementDAO billerManagementDAO;
	
	private CacheManagementService cacheService;
	
	private PaymentCommonService paymentCommonService;
	
	/** The cache manager. */
	//private CacheManager cacheManager;
	
	/**
	 * Save payment txn details.
	 *
	 * @param billPmtTxnDetailsVO the bill pmt txn details vo
	 */
	/*public void savePaymentTxnDetails(BillPmtTxnDetailsVO billPmtTxnDetailsVO) {
		paymentTransactionDAO.savePaymentTxnDetails(billPmtTxnDetailsVO);
	}*/

	/**
	 * Perform bill payment in EBBS
	 *
	 * @param billerPayRequestV the biller pay request v
	 * @return the biller pay response vo
	 */
	public BillerPayResponseVO performBillPayment(BillerPayRequestVO billerPayRequestVO) {

		LOGGER.info("performBillPayment ::: TransactionServiceImpl ::: start");
		LOGGER.info("Bill payment request id: from {} for {} in {} as {}",
				new Object[] { billerPayRequestVO.getUser().getCustomerId(),
						billerPayRequestVO.getUser().getCountry(),
						billerPayRequestVO.getUser().getChannelId(),
						billerPayRequestVO.getMessageVO().getRequestCode() });
		

		BillerPayDetailsVO billpayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		populateInterfacePaymentDetails(billpayDetails);
		
		Invoice invoice = BillpaymentMappingHelper.payBillRequestMapping(billerPayRequestVO);

		LOGGER.info("Obtained core banking payment object" +	billpayDetails.getPayRef());
		
		PayBillReqPayload payBillReqPayload = new PayBillReqPayload();
		payBillReqPayload.setOperationType(PAY_BILL_BY_ACCOUNT);
		payBillReqPayload.setPayBillReq(invoice);
		payBillReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		payBillReqPayload.setPayloadVersion(CommonConstants.VERSION);
		
		PayBillReq payBillReq = new PayBillReq();
		payBillReq.setHeader(BillpaymentMappingHelper.populateHeader(
				billerPayRequestVO.getUser().getCountry(), 
				CommonConstants.I_BANKING, getGregorianCalendar(),
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef()));
		LOGGER.info("Obtained core banking header populated" +	billpayDetails.getPayRef());
		
		// CR659 - Card as source of fund for africa 
		if(billpayDetails.getPaymentType().equalsIgnoreCase(CommonConstants.CARD)){
			payBillReqPayload.setOperationType(CommonConstants.PAY_BILL_BY_CARD);//operatioonType
			invoice.getInvoiceInfo().setCardNumber(billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAccountNumber());//card number
			
			if(payBillReq.getHeader() !=null && payBillReq.getHeader().getProcess() !=null){
				payBillReq.getHeader().getProcess().setProcessName(CommonConstants.PAY_BILL_BY_CARD); //processName
				payBillReq.getHeader().getProcess().setEventType(CommonConstants.PAY_BILL);//eventType
			}
			if (payBillReq.getHeader() !=null && payBillReq.getHeader().getMessageDetails()!=null 
					&& payBillReq.getHeader().getMessageDetails().getMessageType() !=null 
					&& payBillReq.getHeader().getMessageDetails().getMessageType().getSubType()!=null) {
				
				payBillReq.getHeader().getMessageDetails().getMessageType().getSubType().setSubTypeName(CommonConstants.PAY_BILL_BY_CARD);//subTypeName
			}
			//LOGGER.info("invoiceInfo: "+invoice.getInvoiceInfo().toString()); 
		}
		// CR659 change ends
		
		billpayDetails.setHostName(CommonConstants.EBBS + " - " + CommonConstants.PAY_BILL);
		payBillReq.setPayBillReqPayload(payBillReqPayload);
		
		/*String str = CommonHelper.getXML(payBillReq, PayBillReq.class,
				PayBillReq.class.getSimpleName());
		System.out.println(str);*/
		
		PayBillRes payBillRes = billerService.payBill(payBillReq);
		LOGGER.info("Obtained response from corebanking application" +	billpayDetails.getPayRef());
		
		BillerPayResponseVO billerPayResponseVO = null;
		if (payBillRes.getHeader().getExceptions() != null) {
			billerPayResponseVO = new BillerPayResponseVO();
			// Check if there is any exception from eBBS response
			for (ExceptionType exceptionType : payBillRes.getHeader()
					.getExceptions().getException()) {
				LOGGER.info("Exceptions present in the response ::: " +	billpayDetails.getPayRef());
				LOGGER.info("Exceptions code ::: " + exceptionType.getCode().getValue() 
						+ " ::: " +	billpayDetails.getPayRef());
				LOGGER.info("Exceptions description ::: " +	exceptionType.getDescription()
						+ " ::: " +	billpayDetails.getPayRef());
				
				if (exceptionType.getCode().getValue()
						.equals(CommonConstants.TIMEOUT_CODE)) {
					
					billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
					billpayDetails.getTransactionInfoVO()
							.setTxnStatusCd(CommonConstants.TIMEOUT);
					
					billerPayResponseVO.setStatus(ExceptionMessages._124
							.getCode());
					billerPayResponseVO.setStatusDesc(ExceptionMessages._124
							.getMessage());
					billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				} else {
					billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
					billpayDetails.getTransactionInfoVO()
							.setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.setStatusDesc(
							exceptionType.getDescription());
					billerPayResponseVO.setStatus(
							exceptionType.getCode().getValue());
				}
				
				billpayDetails.getTransactionInfoVO()
					.setHostRespCd(exceptionType.getCode().getValue());
				billpayDetails.getTransactionInfoVO()
					.setHostRespDesc(exceptionType.getDescription());
			
				billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
			}
			
			LOGGER.info("performBillPayment ::: TransactionServiceImpl ::: End");
			return billerPayResponseVO;
		}
		
		billerPayResponseVO = BillpaymentMappingHelper.payBillResponseMapping(payBillRes);
		billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_SUCCESS);
		billpayDetails.getTransactionInfoVO().setHostRespCd(billerPayResponseVO.getStatus());
		billpayDetails.getTransactionInfoVO().setHostRespDesc(billerPayResponseVO.getStatusDesc());
		billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);

		billerPayResponseVO.setStatus(CommonConstants.THREE_ZEROES);
		billerPayResponseVO.setStatusDesc(TRANSACTION_PROCESSED);
		billerPayResponseVO.setErrorCD(BP_00);
		LOGGER.info("Biller Payment Response for request id:{}, {}", new Object[] {
				billerPayRequestVO.getMessageVO().getRequestCode(), billerPayResponseVO.getStatusDesc()});
		
		return billerPayResponseVO;
	}

	
	/**
	 * Inform the payment to the aggregator
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	public BillerPayRequestVO aggregatorPayment(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("aggregatorPayment ::: TransactionServiceImpl ::: Start");	
		BillerPayDetailsVO billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
		try {
			
			billerPayDetailsVO.setHostName(CommonConstants.AGGREGATOR);
			
			PostPaymentReq postPaymentReq = new PostPaymentReq();
			PostPaymentReqPayload postPaymentReqPayload = new PostPaymentReqPayload();
			postPaymentReqPayload.setPayloadVersion(CommonConstants.PAYLOAD_API_21);
			postPaymentReqPayload.setPayloadFormat(PayloadFormatEnum.XML);

			com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
			InvoiceInfo invoiceInfo = new InvoiceInfo();
			invoiceInfo.setAggregatorIdentifier(dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + 
					CommonConstants.AggregatorIdentifier));
			PaymentDetails paymentDetails = new PaymentDetails();
			
			BillerVO biller = billerManagementDAO.GetBiller(
					billerPayDetailsVO.getUtilityCd(), 
					billerPayDetailsVO.getCountryCode());
			
			String strAmount = billerPayDetailsVO.getTransactionInfoVO().
					getSrcAccountVO().getAmount() != null ? billerPayDetailsVO.
					getTransactionInfoVO().getSrcAccountVO().getAmount().toString() :
						CommonConstants.ZERO;
			
			String terminalId = dataBean.getMap().get(
					billerPayDetailsVO.getCountryCode() + 
					CommonConstants.BILLERDOWNLOAD_TERMINAL_ID);
			String applicationUserId = dataBean.getMap().get(
					billerPayDetailsVO.getCountryCode() + 
					CommonConstants.Biller_DOWNLOAD_ApplicationUserID);
			String applicationUserKey = dataBean.getMap().get(
					billerPayDetailsVO.getCountryCode() + 
					CommonConstants.Biller_DOWNLOAD_ApplicationUserKey);
			String currencyConversion = dataBean.getMap().get(
					billerPayDetailsVO.getCountryCode() + 
					CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
					
			LOGGER.info("Updating the Payment details for aggregator posting");	
			paymentDetails.setPayerTransactionID(billerPayDetailsVO.getHostReference());
			paymentDetails.setAccountNumber(billerPayDetailsVO.getConsumerNo());
			
			if(biller != null){
				paymentDetails.setBillerID(biller.getBillerId());
				paymentDetails.setPaymentMode(biller.getAggregatePaymentCode());
			}
			
			if(currencyConversion != null && !currencyConversion.isEmpty()
					&& !currencyConversion.equals(CommonConstants.ZERO)) {

				/*Double txnAmount = billerPayDetailsVO.getTransactionInfoVO().
						getSrcAccountVO().getAmount() != null ? billerPayDetailsVO.
						getTransactionInfoVO().getSrcAccountVO().getAmount().doubleValue() : 0;
				
				Integer multiplier = Integer.valueOf(currencyConversion);
						
				//Converting amount from NGN to kudos	
				strAmount = ((Arrays.asList((String.valueOf(txnAmount*multiplier))
						.split(Pattern.quote(".")))).get(0)).toString();*/
				
				// Above code commented to have currency conversion using BigDecimal instead of Double 				
				BigDecimal amount = billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?
						billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() : 	 new BigDecimal(CommonConstants.ZERO);
										 
				//Converting amount from NGN to kudos	
				strAmount = (Arrays.asList((String.valueOf(amount.multiply(new BigDecimal(currencyConversion))).
							          split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();

			} 
			LOGGER.info("PaymentTransactionServiceImpl: aggregatorPayment: strAmount: "+strAmount);
			paymentDetails.setTransactionAmount(strAmount);
			
			if(terminalId != null && !terminalId.isEmpty()) {
				paymentDetails.setTerminalID(terminalId);
			}
			if(applicationUserId != null && !applicationUserId.isEmpty()) {
				invoiceInfo.setApplicationUserID(applicationUserId);
			}
			if(applicationUserKey != null && !applicationUserKey.isEmpty()) {
				invoiceInfo.setApplicationUserKey(applicationUserKey);
			}
			
			String fieldValues = getPaymentFieldValues(
					biller.getBillerFields(), billerPayDetailsVO);
			if(fieldValues != null && !fieldValues.isEmpty()) {
				paymentDetails.setPaymentDescription(fieldValues);
			}
			
			invoiceInfo.getPaymentDetails().add(paymentDetails);
			
			invoice.setInvoiceInfo(invoiceInfo);
			postPaymentReqPayload.setPostPaymentReq(invoice);
			postPaymentReq.setPostPaymentReqPayload(postPaymentReqPayload);
			
			LOGGER.info("setting scbml header in the request");	
			postPaymentReq.setHeader(BillpaymentMappingHelper.populateSCBHeaderForAggregator(
					billerPayDetailsVO.getCountryCode(), "postPayment", 
					billerPayRequestVO.getMessageVO().getReqID(), CommonConstants.EMPTY, "put"));
			
			LOGGER.info("Generating XML string request for aggregator");	
			String xml = CommonHelper.getXML(postPaymentReq, PostPaymentReq.class, 
					CommonConstants.AGGREGATOR_SUBTYPE);
		
			LOGGER.info("request to be posted" + billerPayDetailsVO.getPayRef());
			topicPostMessageService.postMessage(xml,"scbCashPaymentMobileInvoicePostPaymentV2ReqT");
			LOGGER.info("request posted" + billerPayDetailsVO.getPayRef());	
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_INPROGRESS);
			
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.SUCCESS);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(CommonConstants.TIMEOUT_MSG);
			
		} catch (JMSException jmsException) {
			LOGGER.info("JMS Exception for ::: " + billerPayDetailsVO.getPayRef());
			LOGGER.info("JMS Exception occurred ::: " , jmsException);
			LOGGER.error("JMS Exception occurred ::: " , jmsException);
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
			
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(jmsException.getMessage());
			
			jmsException.printStackTrace();
		} catch(Exception exception){
			LOGGER.info("Exception for ::: " + billerPayDetailsVO.getPayRef());
			LOGGER.info("Exception occurred ::: " , exception);	
			LOGGER.error("Exception occurred ::: " , exception);	
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(exception.getMessage());
			
			exception.printStackTrace();
		}
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		LOGGER.info("aggregatorPayment ::: TransactionServiceImpl ::: End");
		return billerPayRequestVO;
	}
	
	/**
	 * Perform reversal fund transfer in EBBS
	 * 
	 * @param billerPayRequestVO
	 *            the biller pay request vo
	 * @return the transfer response vo
	 */
	public BillerPayResponseVO reversalBillPayment(BillerPayRequestVO billerPayRequestVO){
		
		HostResponseVO hostResponse = new HostResponseVO();
		
		LOGGER.info(
				"Reversal Fund Transfer request recieved transfer request id:{}  from {} for {} in {} as {}",
				new Object[] {billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnId(),
						billerPayRequestVO.getUser().getCustomerId(), billerPayRequestVO.getUser().getCountry(),
						billerPayRequestVO.getUser().getChannelId(), billerPayRequestVO.getMessageVO().getRequestCode() });
		
		ReverseTransactionReq reverseTransactionReq = BillpaymentMappingHelper.
										performReverseBillPaymentRequestPayload(billerPayRequestVO);
		
		if(billerPayRequestVO.getBillerPayDetailsVO() != null && 
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
			LOGGER.info("Setting the aggregator response status details to host response list" + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			
			hostResponse.setCode(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
			hostResponse.setDesc(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			hostResponse.setHostName(billerPayRequestVO.getBillerPayDetailsVO().getHostName());
		}
		
		/*String str = CommonHelper.getXML(reverseTransactionReq, 
				ReverseTransactionReq.class, ReverseTransactionReq.class.getSimpleName());
		System.out.println(str);*/
		
		ReverseTransactionRes reverseTransactionRes = transactionPortType.reverseTransaction(reverseTransactionReq);
		
		billerPayRequestVO.getBillerPayDetailsVO().setHostName(
				CommonConstants.EBBS + " - " + CommonConstants.REVERSE_TRANSACTION);
		
		BillerPayResponseVO billerPayResponseVO = BillpaymentMappingHelper
									.getReversalBillPaymentResponse(reverseTransactionRes,billerPayRequestVO);
		
		billerPayResponseVO.getHostResponseVO().add(hostResponse);
		
		LOGGER.info("Got Reversal Fund Transfer Response");
		return billerPayResponseVO;
	}

	/**
	 * Gets the gregorian calendar.
	 * 
	 * @return the gregorian calendar
	 */
	private XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

		} catch (DatatypeConfigurationException e) {

		}
		return date;
	}

	/**
	 * Save payment txn.
	 *
	 * @param billerPayDetailsVO the biller pay details vo
	 */
	public Long savePayment(BillerPayDetailsVO billerPayDetailsVO) {
		LOGGER.info("savePayment ::: TransactionServiceImpl ::: Start");
		Long paymentId = 0L;
		PaymentDetailVO payment = BillpaymentMappingHelper.getPaymentDetails(billerPayDetailsVO);
		payment.setPaymentStatus(CommonConstants.NEW);
		
		try{
			PayeeDetailVO payee = payeeManagementDAO.getPayee(
					Integer.valueOf(billerPayDetailsVO.getPayeeId()));
			
			if(payee.getPayeeName() == null && 
					payment.getPayee().getPayeeName() != null) {
				LOGGER.info("updating payer name for the payment's payee ::: " +
						billerPayDetailsVO.getPayRef());
				payee.setPayeeName(payment.getPayee().getPayeeName());
				
				payeeManagementDAO.updatePayee(payee);
				LOGGER.info("updating payer name complete for payment ::: " +
						billerPayDetailsVO.getPayRef());
			}
		} catch (Exception exception) {
			LOGGER.error("payer name update failed ::: ", exception);
		}
		
		LOGGER.info("Send to save payment ::: " + billerPayDetailsVO.getPayRef());
		payment.setPayee(null);
		paymentTransactionDAO.savePayment(payment);
		
		if(payment != null && payment.getId() != null){
			paymentId = payment.getId();
			LOGGER.info("Payment saved successfull ::: " 
					+ billerPayDetailsVO.getPayRef());
		} else {
			LOGGER.info("Problem in saving payment. Payment not saved ::::: " 
					+ billerPayDetailsVO.getPayRef());
		}
		LOGGER.info("savePayment ::: TransactionServiceImpl ::: End");
		return paymentId;
	}

	/**
	 * Update the payment record in the database
	 * @param billerPayRequestVO
	 * @return
	 */
	public void updatePaymentStatus(BillerPayDetailsVO billerPayDetailsVO) {
		LOGGER.info("updatePaymentStatus ::: transactionServiceImpl ::: Start");
		try {
			PaymentDetailVO payment = BillpaymentMappingHelper.getPaymentDetails(billerPayDetailsVO);
			if(payment.getHostStatusCode() == null){
				payment.setHostStatusCode("NA");
			}
			PaymentDetailVO dbPayment = paymentTransactionDAO.
					getPaymentDetails(payment.getReferenceNumber());
			
			if(dbPayment != null) {
				LOGGER.info("Setting latest status ::: " + payment.getReferenceNumber());
				if(dbPayment.getStaffFlag() == null 
						&& payment.getStaffFlag() != null){
					dbPayment.setStaffFlag(payment.getStaffFlag());
				}
				if(dbPayment.getHostReferenceNumber() == null){
					dbPayment.setHostReferenceNumber(payment.getHostReferenceNumber());
				}
				if(dbPayment.getAggregatorReference() == null){
					dbPayment.setAggregatorReference(payment.getAggregatorReference());
				}

				//should be set before the payment status is updated in the db payment
				updateRetryVersion(dbPayment , payment);
				
				//Should be set after the retry version is updated
				dbPayment.setPaymentStatus(payment.getPaymentStatus());
				dbPayment.setHostStatusCode(payment.getHostStatusCode());
				dbPayment.setHostStatusDescription(payment.getHostStatusDescription());
				dbPayment.setUpdatedBy(InvoiceAggregatorhelper.getJVMName());
				dbPayment.setUpdatedTime(new Timestamp(new Date().getTime()));
				//For CR659 - To store authcode provided by card system like C400
				if(dbPayment.getAuthCode() == null && payment.getAuthCode() !=null){
					LOGGER.info("updatePaymentStatus: updating AuthCode: "+ payment.getAuthCode() + "::" + payment.getReferenceNumber());
					dbPayment.setAuthCode(payment.getAuthCode());
				}
				if(dbPayment.getStan() == null && payment.getStan() !=null){
					LOGGER.info("updatePaymentStatus: updating Stan: "+ payment.getStan() + "::" + payment.getReferenceNumber());
					dbPayment.setStan(payment.getStan());
				}
				if(dbPayment.getRetrievalReferenceNumber() == null && payment.getRetrievalReferenceNumber() !=null){
					LOGGER.info("updatePaymentStatus: updating RRN: "+ payment.getRetrievalReferenceNumber() + "::" + payment.getReferenceNumber());
					dbPayment.setRetrievalReferenceNumber(payment.getRetrievalReferenceNumber());
				}
				if(dbPayment.getPaymentSubType() == null && payment.getPaymentSubType() !=null){
					LOGGER.info("updatePaymentStatus: updating paymentSubType: "+ payment.getPaymentSubType()+"::"+payment.getReferenceNumber());
					dbPayment.setPaymentSubType(payment.getPaymentSubType());
				}
				//CR659 change ends
				paymentTransactionDAO.updatePaymentStatus(dbPayment);
			}
			
			if(billerPayDetailsVO.getTxnActStatus() != null 
					 && payment.getPaymentStatus() != null 
					 && !billerPayDetailsVO.getTxnActStatus().
					 equalsIgnoreCase(payment.getPaymentStatus())){
			   
				LOGGER.info("Updating the status from ::: " + billerPayDetailsVO.getTxnActStatus() 
						+ " :::: to :::: " + payment.getPaymentStatus());
				
			   billerPayDetailsVO.setTxnActStatus(payment.getPaymentStatus());
			}
		} catch (Exception exception) {
			LOGGER.info("Exception occurred while updating payments ::: " 
					+ billerPayDetailsVO.getPayRef());
			LOGGER.info("Exception ::: " + exception);
			LOGGER.error("Exception ::: " + exception);
		}
		
		LOGGER.info("updatePaymentStatus ::: transactionServiceImpl ::: End");
	}
	
		
	/**
	 * @param billerPayDetails
	 * @return BillerPayDetailsVO
	 */
	private BillerPayDetailsVO populateInterfacePaymentDetails(BillerPayDetailsVO billerPayDetails){
		LOGGER.info("populateInterfacePaymentDetails ::: Populate all the interface relaated details for payments");
		
		BillerCatgegoryReference billerCategoryReference = paymentCommonService.getBillerCategoryReference(
				billerPayDetails.getBillerCategoryCd(), 
				billerPayDetails.getBillerCd(), 
				billerPayDetails.getCountryCode());
		
		if(billerCategoryReference != null){
			billerPayDetails.setTransactionType(billerCategoryReference.getPaymentTransactionType());
			billerPayDetails.setMerchantCode(billerCategoryReference.getPaymentTransactionCode());
			LOGGER.info("Transaction type and merchant code populated");
		} else {
			LOGGER.info("Obtained billerCategoryReference is null for the combination ::: "
					+ " agg category code ::: " + billerPayDetails.getBillerCategoryCd()
					+ " agg biller code ::: " + billerPayDetails.getBillerCd()
					+ " country code ::: " + billerPayDetails.getCountryCode());
		}
		// CR659 Change starts
		if(billerPayDetails.getPaymentType().equalsIgnoreCase(CommonConstants.CARD) && billerCategoryReference != null ){
			if (billerCategoryReference.getCorebankingCardTranType()!=null && billerCategoryReference
						.getCorebankingCardUtilityCode() !=null) {
				billerPayDetails.setTransactionType(billerCategoryReference
						.getCorebankingCardTranType());
				billerPayDetails.setMerchantCode(billerCategoryReference
						.getCorebankingCardUtilityCode());
				LOGGER.info("Card Transaction type and merchant code populated");
			} else {
				LOGGER.info("Obtained billerCategoryReference is null for the combination ::: "
						+ " agg category code ::: " + billerPayDetails.getBillerCategoryCd()
						+ " agg biller code ::: " + billerPayDetails.getBillerCd()
						+ " country code ::: " + billerPayDetails.getCountryCode());
			}
		}
		// CR659 change ends
		
		List<NarrationVO> narrationConfig = null;
		narrationConfig = cacheService.getNarration(billerPayDetails.getCountryCode(), billerPayDetails.getChannel());
		NarrationVO narrationVOObj = null;
		if(narrationConfig != null){
			LOGGER.info("narrationConfig is not null !!!!!");
			for(NarrationVO narrationVO : narrationConfig){
				if(billerPayDetails.getBillerCategoryCd().equalsIgnoreCase(narrationVO.getCategoryId())
						&& billerPayDetails.getBillerCd().equalsIgnoreCase(narrationVO.getBillerId())){
					LOGGER.info("narrationConfig --- CategoryId and BillerId are matching !!!!!");
					narrationVOObj = narrationVO;
					break;
				}else if (billerPayDetails.getBillerCategoryCd().equalsIgnoreCase(narrationVO.getCategoryId())){
					LOGGER.info("narrationConfig --- CategoryId is matching !!!!!");
					narrationVOObj = narrationVO;
					break;
				}else if(narrationVO.getBillerId() == null && narrationVO.getCategoryId() == null){
					LOGGER.info("narrationConfig --- Default  !!!!!");
					narrationVOObj = narrationVO;
					break;
				}
		
			}
		}
		billerPayDetails = NarrationHelper.populateNarration(billerPayDetails,narrationVOObj);
		
		LOGGER.info("narration population complete");
		
		LOGGER.info("populateInterfacePaymentDetails ::::: end");
		return billerPayDetails;
	}
	
	public BillerPayResponseVO paymentStatusCheck(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("Inside statusCheckFT in TransferServiceImpl");
		billerPayRequestVO.getBillerPayDetailsVO().setHostName(
			CommonConstants.EBBS + " - " + CommonConstants.TRANSACTION_STATUS_ENQUIRY);
		
		GetTransactionReq getTransactionReq = BillpaymentMappingHelper.
				performStatusCheckPaymentRequestPayload(billerPayRequestVO);
		LOGGER.info(" getTransactionReq " + getTransactionReq);

		/*String str = CommonHelper.getXML(getTransactionReq, 
				GetTransactionReq.class, GetTransactionReq.class.getSimpleName());
		System.out.println(str);*/
		
		LOGGER.info("Before sending Request to EDMI ::: " + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		GetTransactionRes  getTransactionRes = transactionPortType.getTransaction(getTransactionReq);
		LOGGER.info(" getTransactionRes " + getTransactionRes);
		
		LOGGER.info("After getting response from EDMI :::: " + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		BillerPayResponseVO  billerPayResponseVO = BillpaymentMappingHelper.
				getStatusCheckPaymentResponse(getTransactionRes,billerPayRequestVO);
		LOGGER.info("Got statusCheckFT Response ::: " + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		return billerPayResponseVO;
	}
	
	public PaymentDetailVO getPaymentDetails(String referenceNumber) {
		return paymentTransactionDAO.getPaymentDetails(referenceNumber);
	}
	
	public List<BillerPayDetailsVO> getReversalFailurePaymentTransactionList(BillerPayRequestVO billerPayRequestVO) {
		List<PaymentDetailVO> paymentDetail = paymentTransactionDAO.getReversalFailurePaymentTransactionList(billerPayRequestVO);
		List<BillerPayDetailsVO> listFromDB = new ArrayList<BillerPayDetailsVO>();
		if(!CollectionUtils.isEmpty(paymentDetail)){
			for(PaymentDetailVO paymentObj : paymentDetail){
				BillerPayDetailsVO	billerDetails = BillpaymentMappingHelper.getBillPayRequestFromPaymentDetails(paymentObj);
				billerDetails.getTransactionInfoVO().setUserVO(billerPayRequestVO.getUser());
				billerDetails.getTransactionInfoVO().setClientVO(billerPayRequestVO.getClientVO());
				billerDetails.getTransactionInfoVO().setServiceVO(billerPayRequestVO.getServiceVO());
				billerDetails.getTransactionInfoVO().setMessageVO(billerPayRequestVO.getMessageVO());
				listFromDB.add(billerDetails);
			}
		}
		return listFromDB;
	}
	
	
	public void updatePmtVersion(BillerPayDetailsVO billerPayDetailsVO) {
		paymentTransactionDAO.updatePmtVersion(billerPayDetailsVO);
	}
	
	public void updateRequestVOString(BillerPayDetailsVO billerPayDetailsVO){
		paymentTransactionDAO.updateRequestVOString(billerPayDetailsVO);
	}
	/**
	 * Sets the biller service.
	 * 
	 * @param billerService
	 *            the new biller service
	 */
	public void setBillerService(InvoicePortType billerService) {
		this.billerService = billerService;
	}

	/**
	 * Sets the payment transaction dao.
	 * 
	 * @param paymentTransactionDAO
	 *            the new payment transaction dao
	 */
	public void setPaymentTransactionDAO(
			PaymentTransactionDAO paymentTransactionDAO) {
		this.paymentTransactionDAO = paymentTransactionDAO;
	}

	/**
	 * Sets the transaction port type.
	 * 
	 * @param transactionPortType
	 *            the new transaction port type
	 */
	public void setTransactionPortType(TransactionPortType transactionPortType) {
		this.transactionPortType = transactionPortType;
	}

	/**
	 * @return the topicPostMessageService
	 */
	public TopicPostMessageService getTopicPostMessageService() {
		return topicPostMessageService;
	}

	/**
	 * @param topicPostMessageService the topicPostMessageService to set
	 */
	public void setTopicPostMessageService(
			TopicPostMessageService topicPostMessageService) {
		this.topicPostMessageService = topicPostMessageService;
	}


	/**
	 * @param billerDownloadDAO the billerDownloadDAO to set
	 */
	public void setBillerDownloadDAO(BillerDownloadDAO billerDownloadDAO) {
		this.billerDownloadDAO = billerDownloadDAO;
	}


	/**
	 * @param billerManagementDAO the billerManagementDAO to set
	 */
	public void setBillerManagementDAO(BillerManagementDAO billerManagementDAO) {
		this.billerManagementDAO = billerManagementDAO;
	}



	@Override
	public List<BillerPayDetailsVO> getPaymentRetryTransactionList(
			BillerPayRequestVO billerPayRequestVO) {
		
		String country = (billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null) ? 
				billerPayRequestVO.getBillerPayDetailsVO().getCountryCode() : null;
		country = country != null && !country.isEmpty() ? country.toString() : CommonConstants.EMPTY;
		
		LOGGER.info("Inside method  getPaymentRetryTransactionList :: country>>>>>>> " + country);
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
		List<BillerPayDetailsVO> billerPayListFromDB = new ArrayList<BillerPayDetailsVO>();
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -24); //Modified to 24 hrs from 12 hrs for RDC-50473 by 1571157 
        Date fromDate = calendar.getTime();
        
        String postBuffer = dataBean.getMap().get(country+CommonConstants.PAYMENT_TIMER_BUFFER);
        int retryBuffer = postBuffer != null && !postBuffer.isEmpty() ? 
        			Integer.parseInt(postBuffer) : 0;
        			
        Calendar cal = DateUtils.getCountryCalendar();
        cal.add(Calendar.HOUR, retryBuffer);
        Date toDate = cal.getTime();
        
        String interval = dataBean.getMap().get(country+CommonConstants.PAYMENT_RETRY_TIMER);
        int retryInterval = interval != null && !interval.isEmpty() ? 
        			Integer.parseInt(interval) : 0;
        			
		String retryValue = dataBean.getMap().get(country+CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);
        int retryCount = retryValue != null && !retryValue.isEmpty() ? 
        			Integer.parseInt(retryValue) : CommonConstants.THREE;
        			
        Object retryStatusObject = dataBean.getMap().get(country+CommonConstants.PAYMENT_TIMEOUT_RETRY_STATUS);
        List<String> retryStatus = retryStatusObject != null ? 
        		Arrays.asList(retryStatusObject.toString().split(CommonConstants.COMMA)) : 
        		CommonConstants.TIME_OUT_LIST;
        
        Object retryCountriesObject = dataBean.getMap().get(country+CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNTRY);
        List<String> retryCountries = retryCountriesObject != null ? 
        		Arrays.asList(retryCountriesObject.toString().split(CommonConstants.COMMA)) : 
        		CommonConstants.AFRICAN_COUNTRIES;
        
		LOGGER.info("retry details -- retryInterval {} -- retryCount {} -- retryStatus {} -- retryCountries {}"
        		,new Object[]{retryInterval,retryCount,retryStatus,retryCountries});
        		
        Calendar updatedTimeCalendar = Calendar.getInstance();
        //updatedTimeCalendar.setTime(new Date());
        updatedTimeCalendar.add(Calendar.MINUTE, -(retryInterval));
        Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());
        
        LOGGER.info("At getPayment retry TransactionList for countries {} and status {} --- "
        		+ "From Date {} and To Date {} and update date {} "
        		,new Object[]{retryCountries,retryStatus,fromDate,toDate,updatedTimeStamp});
        List<PaymentDetailVO>  retryList = paymentTransactionDAO.
    		   getPaymentRetryList(billerPayRequestVO, fromDate, toDate, 
    				   updatedTimeStamp, retryCount, retryStatus, retryCountries);
       if(retryList==null) {
    	   LOGGER.info("RECORDS PICKED PAYMENT RETRY NULL" );   
       }else{
        for(PaymentDetailVO paymentDetailVO:retryList){
     	   LOGGER.info("RECORDS PICKED PAYMENT RETRY" +paymentDetailVO.getReferenceNumber()+ "  "+paymentDetailVO.getHostReferenceNumber());  
        }
       }
       
       if(retryList != null && !retryList.isEmpty()){
    	   for(PaymentDetailVO paymentObj : retryList){
	   			BillerPayDetailsVO	billerDetails = BillpaymentMappingHelper.getBillPayRequestFromPaymentDetails(paymentObj);
	   			billerDetails.getTransactionInfoVO().setUserVO(billerPayRequestVO.getUser());
	   			billerDetails.getTransactionInfoVO().setClientVO(billerPayRequestVO.getClientVO());
	   			billerDetails.getTransactionInfoVO().setServiceVO(billerPayRequestVO.getServiceVO());
	   			billerDetails.getTransactionInfoVO().setMessageVO(billerPayRequestVO.getMessageVO());
	   			billerPayListFromDB.add(billerDetails);
   			}
       }
       LOGGER.info("At getPaymentRetryTransactionList End>>>.> ");
       return billerPayListFromDB;
	}
	
	public BillerPayDetailsVO populateDetailsForPayee(BillerPayDetailsVO billerPayDetails) {
		LOGGER.info("paymenttranactionserviceimpl ::: populateDetailsForPayee :::: Start");
		
		if(billerPayDetails.getTransactionInfoVO() != null &&
				billerPayDetails.getTransactionInfoVO().getTransferCurrencyCd() == null){
			billerPayDetails.getTransactionInfoVO().setTransferCurrencyCd(
					billerPayDetails.getTransactionInfoVO().getSrcAccountVO().getCurrency());
		}
		
		LOGGER.info("Getting the payee details for :::: " + billerPayDetails.getPayeeId());
		PayeeDetailVO payee = payeeManagementDAO.getPayee(
				Integer.valueOf(billerPayDetails.getPayeeId()));
		
		LOGGER.info("billerPayDetails.getCustomerId() " + billerPayDetails.getCustomerId());
		LOGGER.info("billerPayDetails.getConsumerNo():::: " + billerPayDetails.getConsumerNo());
		LOGGER.info("payee.getConsumerNumber():::: " + payee.getConsumerNumber());
		LOGGER.info("payee.getCustomerId():::: " + payee.getCustomerId());
		
		if(payee != null && payee.getConsumerNumber() != null
				&& billerPayDetails.getConsumerNo() != null
				&& billerPayDetails.getConsumerNo().
					equalsIgnoreCase(payee.getConsumerNumber())
				&& payee.getCustomerId() != null
				&& billerPayDetails.getCustomerId() != null
				&& billerPayDetails.getCustomerId().
					equalsIgnoreCase(payee.getCustomerId())) {
			
			LOGGER.info("Consumer number verification done :::: populating the values");
			
			billerPayDetails.setBillerCategoryCd(
					payee.getBillerVO().getCategorytype().getCategoryId());
			
			billerPayDetails.setBillerCategoryDesc(
			payee.getBillerVO().getCategorytype().getCategoryName());

			billerPayDetails.setBillerCd(payee.getBillerVO().getBillerId());
			billerPayDetails.setUtilityCd(payee.getBillerVO().getBillerUniqueId());
			billerPayDetails.setBillerName(payee.getBillerVO().getBillerShortName());
		} else {
			LOGGER.info("Consumer number or Customer id for the payee does not match ::: " 
					+ billerPayDetails.getPayeeId());
			return null;
		}
		
		LOGGER.info("paymenttranactionserviceimpl ::: populateDetailsForPayee :::: End");
		return billerPayDetails;
	}
	
	@Override
	public List<BillerPayDetailsVO> getInprocessPayments(
			BillerPayRequestVO billerPayRequestVO) {
		
		String country = (billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null) ? 
				billerPayRequestVO.getBillerPayDetailsVO().getCountryCode() : null;
		country = country != null && !country.isEmpty() ? country.toString() : CommonConstants.EMPTY;
		
		LOGGER.info("Inside method  getPaymentINprocessTransactionList>>>>>>> " + country);
		List<BillerPayDetailsVO> billerPayListFromDB = new ArrayList<BillerPayDetailsVO>();
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -12);
        Date fromDate = calendar.getTime();
        
        String postBuffer = dataBean.getMap().get(country+CommonConstants.PAYMENT_TIMER_BUFFER);
        int retryBuffer = postBuffer != null && !postBuffer.isEmpty() ? 
        			Integer.parseInt(postBuffer) : 0;
        			
        Calendar cal = DateUtils.getCountryCalendar();
        cal.add(Calendar.HOUR, retryBuffer);
        Date toDate = cal.getTime();

        String interval = dataBean.getMap().get(country+CommonConstants.PAYMENT_INPROCESS_TIMER);
        int retryInterval = interval != null && !interval.isEmpty() ? 
        			Integer.parseInt(interval) : 0;
        			
		String retryValue = dataBean.getMap().get(country+CommonConstants.PAYMENT_INPROCESS_RETRY_COUNT);
        int retryCount = retryValue != null && !retryValue.isEmpty() ? 
        			Integer.parseInt(retryValue) : CommonConstants.THREE;
        
		Object retryCountriesObject = dataBean.getMap().get(country+CommonConstants.PAYMENT_INPROCESS_RETRY_COUNTRY);
        List<String> retryCountries = retryCountriesObject != null ? 
        		Arrays.asList(retryCountriesObject.toString().split(CommonConstants.COMMA)) : 
        		CommonConstants.AFRICAN_COUNTRIES;
        
		LOGGER.info("inprocess details -- inprocessInterval {} -- inprocessCount {} -- inprocessCountries {}"
        		,new Object[]{retryInterval,retryCount,retryCountries});
        		
        Calendar updatedTimeCalendar = Calendar.getInstance();
        //updatedTimeCalendar.setTime(new Date());
        updatedTimeCalendar.add(Calendar.MINUTE, -(retryInterval));
        Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());
        
        LOGGER.info("At getPayment INproces TransactionList for countries {} --- From Date {} and To Date {} and update date {} "
        		,new Object[]{retryCountries,fromDate,toDate,updatedTimeStamp});
       List<PaymentDetailVO>  retryList = paymentTransactionDAO.
    		   getInprocessPayments(fromDate, toDate, updatedTimeStamp, retryCount, retryCountries); 
       if(retryList ==null){
    	   LOGGER.info("RECORDS PICKED NULL" );  
       }else{
       for(PaymentDetailVO paymentDetailVO:retryList){
    	   LOGGER.info("RECORDS PICKED INPROCESS" +paymentDetailVO.getReferenceNumber()+ "  "+paymentDetailVO.getHostReferenceNumber());  
       }
}
       
       if(retryList != null && !retryList.isEmpty()){
    	   for(PaymentDetailVO paymentObj : retryList){
	   			BillerPayDetailsVO	billerDetails = BillpaymentMappingHelper.getBillPayRequestFromPaymentDetails(paymentObj);
	   			billerPayListFromDB.add(billerDetails);
   			}
       }
       LOGGER.info("At getPaymentRetryTransactionList End>>>.> ");
       return billerPayListFromDB;
	}
	
	private String getPaymentFieldValues(Set<BillerField> billerFields,
			BillerPayDetailsVO billerPayDetailsVO) {
		LOGGER.info("At getPaymentFieldValues :::: Start>>>.> ");
		
		String secondField = null;
		String thirdField = null;
		
		StringBuilder fieldValues = new StringBuilder();
		if(billerFields != null && !billerFields.isEmpty()) {
			Iterator<BillerField> fieldIterator = billerFields.iterator();
			BillerField billerField = null;
			
			while(fieldIterator.hasNext()) {
				billerField = fieldIterator.next();
				
				if(billerField !=  null && billerField.getOrderSequence() != null) {
					LOGGER.info("Biller Field not null :::: " + billerField.getFieldLabelName()
						+ " ::::: Sequence number ::::: " + billerField.getOrderSequence());
					
					if(billerField.getOrderSequence().equals(1)) {
						fieldValues.append(billerField.getFieldLabelName()).
							append(CommonConstants.COLON).
							append(billerPayDetailsVO.getConsumerNo());
						
					} else if(billerField.getOrderSequence().equals(2)) {
						secondField = billerField.getFieldLabelName();
					} else {
						thirdField = billerField.getFieldLabelName();
					}
				}
			}
			
			if(fieldValues.length() > 0){
				fieldValues.append(CommonConstants.COLON);
			}
			
			if(thirdField != null) {
				fieldValues.append(secondField).
					append(CommonConstants.COLON).
					append(billerPayDetailsVO.
							getTransactionInfoVO().getTxnPurpose()).
					append(CommonConstants.COLON).
					append(thirdField).
					append(CommonConstants.COLON).
					append(billerPayDetailsVO.getTransactionInfoVO().
							getSrcAccountVO().getAmount());
			} else if(secondField != null) {
				fieldValues.append(secondField).
				append(CommonConstants.COLON).
				append(billerPayDetailsVO.getTransactionInfoVO().
						getSrcAccountVO().getAmount());
			}
		}
		LOGGER.info("At getPaymentFieldValues :::: End>>>> " + fieldValues);
		return String.valueOf(fieldValues);
	}
	
	/**
	 * @param dbPayment
	 * @param payment
	 * 
	 * Alter the status of the payments and retry counts based on each other
	 */
	private void updateRetryVersion(PaymentDetailVO dbPayment, PaymentDetailVO payment) {
		int retryValue = 0;
		LOGGER.info(dbPayment.getPaymentStatus() + 
				"   --- dbPayment.getPaymentStatus() Inside updateRetryVersion "
				+ "&&&&&&& payment.getPaymentStatus() ==  "
				+ payment.getPaymentStatus());
		
		if(!payment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_INPROGRESS)) {
			
			String country = dbPayment.getCountryCode();
			country = country != null && !country.isEmpty() ? country.toString() : CommonConstants.EMPTY;
			LOGGER.info("Inside updateRetryVersion : country :"+country +" payment.getReferenceNumber(): "+payment.getReferenceNumber());
			if(dbPayment.getPaymentStatus() != null && payment.getPaymentStatus() != null 
					&& dbPayment.getPaymentStatus().equalsIgnoreCase(payment.getPaymentStatus())) {
				retryValue = dbPayment.getVersion();
			} else if(dbPayment.getPaymentStatus() != null && payment.getPaymentStatus() != null 
					&& dbPayment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_INPROCESS)
					&& payment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_TIMEOUT)) {
				// Timeouts during in-process status should also be treated as in-process
				payment.setPaymentStatus(CommonConstants.AGGREGATOR_INPROCESS);
			}
			
			LOGGER.info("--Inside updateRetryVersion &&&&&&& retryValue  == > "+retryValue);
			dbPayment.setVersion(retryValue+1);
			
	        if(!payment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_INPROCESS)) {
	        	String strRetryCount = dataBean.getMap().get(country+CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);
		        int retryCount = strRetryCount != null && !strRetryCount.isEmpty() ? 
		        			Integer.parseInt(strRetryCount) : CommonConstants.THREE;
		        LOGGER.info("--- Inside updateRetryVersion : retryCount: "+retryCount +" payment.getReferenceNumber(): "+payment.getReferenceNumber());		
				if(dbPayment.getVersion() != null && dbPayment.getVersion() > retryCount) {
					if(payment.getPaymentStatus() != null && 
							CommonConstants.COREBANK_PAY_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.info("--Inside updateRetryVersion &&&&&&& "
								+ "COREBANK_PAY_TIMEOUT -updated as- COREBANK_PAY_FAILURE");
						payment.setPaymentStatus(CommonConstants.COREBANK_PAY_FAILURE);
					} else if(payment.getPaymentStatus() != null && 
							CommonConstants.AGGREGATOR_PAY_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.info("--Inside updateRetryVersion &&&&&&& "
								+ "AGGREGATOR_PAY_TIMEOUT -updated as  TIMEOUT");
						payment.setPaymentStatus(CommonConstants.TIMEOUT);
					} else if(payment.getPaymentStatus() != null && 
							CommonConstants.REVERSAL_PAY_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.info("--Inside updateRetryVersion &&&&&&& "
								+ "REVERSAL_PAY_TIMEOUT -updated as- REVERSAL_PAY_FAILURE");
						payment.setPaymentStatus(CommonConstants.REVERSAL_PAY_FAILURE);
					} else if(payment.getPaymentStatus() != null && 
							CommonConstants.CARD_AUTH_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.info("--Inside updateRetryVersion &&&&&&& "
								+ "CARD_AUTH_TIMEOUT -updated as- CARD_AUTH_FAILURE");
						payment.setPaymentStatus(CommonConstants.CARD_AUTH_FAILURE);//condition added for Hogan getTransactionStatus inquiry service
					}
				}
	        } else {
	        	String strInprocessCount = dataBean.getMap().get(country+CommonConstants.PAYMENT_INPROCESS_RETRY_COUNT);
		        int inProcessCount = strInprocessCount != null && !strInprocessCount.isEmpty() ? 
		        			Integer.parseInt(strInprocessCount) : CommonConstants.THREE;
		       LOGGER.info("Inside updateRetryVersion INPROCESS: inProcessCount:  "+inProcessCount+" payment.getReferenceNumber(): "+payment.getReferenceNumber());
				if(payment.getPaymentStatus() != null && 
						CommonConstants.AGGREGATOR_INPROCESS.equalsIgnoreCase(payment.getPaymentStatus()) 
						&& dbPayment.getVersion() != null && dbPayment.getVersion() > inProcessCount) {
					LOGGER.info("--Inside updateRetryVersion &&&&&&& "
							+ "AGGREGATOR_INPROCESS -updated as- IN_PROCESS_STATUS");
					payment.setPaymentStatus(CommonConstants.INPROCESS_STATUS);
				}
	        }
		}
	}
	
	@Override
	public String getReferenceNumberSequence(
			BillerPayRequestVO billerPayRequestVO) {
		return paymentTransactionDAO.getReferenceNumberSequence(billerPayRequestVO);
	}


	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	public void setPayeeManagementDAO(PayeeManagementDAO payeeManagementDAO) {
		this.payeeManagementDAO = payeeManagementDAO;
	}
	
	/*public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}*/
	
	public CacheManagementService getCacheService() {
		return cacheService;
	}


	public void setCacheService(CacheManagementService cacheService) {
		this.cacheService = cacheService;
	}

	/**
	 * @return the transactionPortType
	 */
	public BillerPayDetailsVO populateDetailsForPayeeCS(BillerPayDetailsVO billerPayDetails) {
		LOGGER.info("paymenttranactionserviceimpl ::: populateDetailsForPayeeCS :::: Start");
		if(billerPayDetails.getTransactionInfoVO() != null && billerPayDetails.getTransactionInfoVO().getTransferCurrencyCd() == null){
			billerPayDetails.getTransactionInfoVO().setTransferCurrencyCd(billerPayDetails.getTransactionInfoVO().getSrcAccountVO().getCurrency());
		}
		LOGGER.info("Getting the payee details for populateDetailsForPayeeCS :::: " + billerPayDetails.getPayeeId());
		PayeeDetailVO payee = payeeManagementDAO.getPayeeToValidatePayment(Integer.valueOf(billerPayDetails.getPayeeId()));
		LOGGER.info("payee customerid {}-{}", new Object[] { payee.getCustomerId(), billerPayDetails.getCustomerId()});
		LOGGER.info("payee customerid"+payee.getCustomerId());
		LOGGER.info("biller customer id"+billerPayDetails.getCustomerId());
		if(payee != null 
				&& payee.getCustomerId() != null
				&& billerPayDetails.getCustomerId() != null
				&& billerPayDetails.getCustomerId().equalsIgnoreCase(payee.getCustomerId())) {
			LOGGER.info("Consumer number verification done :::: populateDetailsForPayeeCS :: populating the values");
			billerPayDetails.setBillerCategoryCd(payee.getBillerVO().getCategorytype().getCategoryId());
			billerPayDetails.setBillerCategoryDesc(payee.getBillerVO().getCategorytype().getCategoryName());
			billerPayDetails.setBillerCd(payee.getBillerVO().getBillerId());
			billerPayDetails.setUtilityCd(payee.getBillerVO().getBillerUniqueId());
			billerPayDetails.setBillerName(payee.getBillerVO().getBillerShortName());
		} else {
			LOGGER.info("Consumer number or Customer id for the payee does not match populateDetailsForPayeeCS ::: " + billerPayDetails.getPayeeId());
			return null;
		}
		LOGGER.info("paymenttranactionserviceimpl ::: populateDetailsForPayeeCS :::: End");
		return billerPayDetails;
	}


	/**
	 * savePaymentCS.
	 *
	 * @param billerPayDetailsVO the biller pay details vo
	 */
	public Long savePaymentCS(BillerPayDetailsVO billerPayDetailsVO) {
		LOGGER.info("savePaymentCS ::: TransactionServiceImpl ::: Start "+billerPayDetailsVO.getPayRef());
		Long paymentId = 0L;
		PaymentDetailVO payment = BillpaymentMappingHelper.getPaymentDetails(billerPayDetailsVO);
		checkIfAnyNameFields(payment);
		BillerVO bilelrvo=payeeManagementDAO.getFieldInfo(billerPayDetailsVO.getUtilityCd(),payment.getCountryCode());
		for(BillerField paymentFieldDetails: billerPayDetailsVO.getBillerFields()){
			for(BillerField field:bilelrvo.getBillerFields()){
				if(field.getFieldLabelName().trim().equalsIgnoreCase(paymentFieldDetails.getFieldLabelName().trim()) 
						&& !field.getFieldType().equalsIgnoreCase(CommonConstants.N) && field.getFieldType().equalsIgnoreCase(paymentFieldDetails.getFieldType())){
					paymentFieldDetails.setStatus(field.getStatus());
				}
			}
		}
		for(PaymentFieldDetails paymentFieldDetails:payment.getPaymentFieldDetails()){
		   paymentFieldDetails.setRemarks(paymentFieldDetails.getFieldType());
			if(paymentFieldDetails.getOrderSequence()==CommonConstants.ONE_INT && paymentFieldDetails.getFieldType().equalsIgnoreCase(CommonConstants.P)){
				payment.setToAccountNumber(paymentFieldDetails.getFieldValue());
				billerPayDetailsVO.setConsumerNo(paymentFieldDetails.getFieldValue());
			}
			if(paymentFieldDetails.getFieldLabelName().equalsIgnoreCase(CommonConstants.AMOUNT) && CommonConstants.P.equalsIgnoreCase(paymentFieldDetails.getFieldType())){
				payment.setPaymentAmount(new BigDecimal(paymentFieldDetails.getFieldValue()));
				payment.setTotalAmount(new BigDecimal(paymentFieldDetails.getFieldValue()));
				billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().setAmount(new BigDecimal(paymentFieldDetails.getFieldValue()));
			}
			for(BillerField field:bilelrvo.getBillerFields()){
				if(field.getFieldLabelName().trim().equalsIgnoreCase(paymentFieldDetails.getFieldLabelName().trim()) 
						&& !field.getFieldType().equalsIgnoreCase(CommonConstants.N) && field.getFieldType().equalsIgnoreCase(paymentFieldDetails.getFieldType())){
					
					paymentFieldDetails.setFieldId(field.getId());
					paymentFieldDetails.setFieldValue(paymentFieldDetails.getFieldValue());
					paymentFieldDetails.setStatus(field.getStatus());
				}
			}
			paymentFieldDetails.setPaymentDetailVO(payment);
			LOGGER.info("Filed getFieldLabelName :: "+paymentFieldDetails.getFieldLabelName() +
					" ::  Filed getFieldValue :: "+paymentFieldDetails.getFieldValue()+
					" :: Filed getRemarks :: "+paymentFieldDetails.getRemarks()+
					":: Filed getCaption :: "+paymentFieldDetails.getCaption()+
					":: Filed Id :: "+paymentFieldDetails.getFieldId()+
					":: Filed Data type :: "+paymentFieldDetails.getFieldDataType()+" "+billerPayDetailsVO.getPayRef());
		}
		payment.setPaymentStatus(CommonConstants.NEW);
		try{
			PayeeDetailVO payee = payeeManagementDAO.getPayeeToValidatePayment(Integer.valueOf(billerPayDetailsVO.getPayeeId()));
			if(payee.getPayeeName() == null && payment.getPayee().getPayeeName() != null) {
				LOGGER.info("updating payer name for the payment's payee ::: " +billerPayDetailsVO.getPayRef());
				payee.setPayeeName(payment.getPayee().getPayeeName());
				payeeManagementDAO.updatePayee(payee);
				LOGGER.info("updating payer name complete for payment ::: " +billerPayDetailsVO.getPayRef());
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			LOGGER.error(" savePaymentCS :: payer name update failed ::: ", exception);
		}
		LOGGER.info(" savePaymentCS :: Send to save payment ::: " + billerPayDetailsVO.getPayRef());
		payment.setPayee(null);
		paymentTransactionDAO.savePayment(payment);
		if(payment != null && payment.getId() != null){
			paymentId = payment.getId();
			LOGGER.info(" savePaymentCS :: Payment saved successfull ::: " + billerPayDetailsVO.getPayRef());
		} else {
			LOGGER.info("savePaymentCS :: Problem in saving payment. Payment not saved ::::: " + billerPayDetailsVO.getPayRef());
		}
		LOGGER.info(" savePaymentCS  ::: TransactionServiceImpl ::: End");
		return paymentId;
	}


	/**
	 * @param payment
	 */
	private void checkIfAnyNameFields(PaymentDetailVO payment) {
		Set<PaymentFieldDetails> paymentFieldDetailsRP=new HashSet<PaymentFieldDetails>();;
		for(PaymentFieldDetails paymentFieldDetails:payment.getPaymentFieldDetails()){
			if(!paymentFieldDetails.getFieldType().equalsIgnoreCase(CommonConstants.N)){
				paymentFieldDetailsRP.add(paymentFieldDetails);
				
			}
		}
		payment.getPaymentFieldDetails().clear();
		payment.setPaymentFieldDetails(paymentFieldDetailsRP);
	}


	@Override
	public void saveOneTimePayee(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info(" Onetime payment  ::: TransactionServiceImpl ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		if(payee.getConsumerNumber()==null)
		for(BillerField billerField:billerPayRequestVO.getBillerPayDetailsVO().getBillerFields()){
			if(billerField.getOrderSequence()==CommonConstants.ONE_INT && billerField.getFieldType().equalsIgnoreCase(CommonConstants.P)){
				payee.setConsumerNumber(billerField.getFieldValue());	
				break;
			}
		}
		payee.setPayeeId(null);
		payee.setPayeeFieldDetails(null);
		payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_ONETIME);
		payee.setIsUpdateRequired(CommonConstants.N);
		payee.setPayeeType(CommonConstants.ONE_TIME_PAYMENT);
		payee.setStatus(CommonConstants.ACTIVE);
		LOGGER.info("Onetime payment  ::: Before getting biller details ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		payee.setBillerVO(payeeManagementDAO.getUniqueBillerId(billerPayRequestVO.getBillerPayDetailsVO().getUtilityCd(),payee.getCountryCode()));
		LOGGER.info("Onetime payment  ::: After setting biller details ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		payee.setBillerCode(billerPayRequestVO.getBillerPayDetailsVO().getUtilityCd());
		//Checking one time payee is exists
		PayeeDetailVO oneTimePayee=payeeManagementDAO.getOneTimePayee(payee);
		if(oneTimePayee!=null){
			LOGGER.info("Onetime payee  ::: already exists ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			billerPayRequestVO.getBillerPayDetailsVO().setPayeeId(oneTimePayee.getPayeeId().toString());	
		}
		if(oneTimePayee==null){
		LOGGER.info("Onetime payment  ::: before  insert :: TransactionServiceImpl ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		payeeManagementDAO.savePayeeCS(payee);
		billerPayRequestVO.getBillerPayDetailsVO().setPayeeId(payee.getPayeeId().toString());
		LOGGER.info("Onetime payment  ::: record inserted :: TransactionServiceImpl ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		}
		LOGGER.info("Onetime payment  ::: END :: TransactionServiceImpl ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef()); 
	}


	/**
	 * Inform the payment to the aggregator
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	public void setPaymentCommonService(PaymentCommonService paymentCommonService) {
		this.paymentCommonService = paymentCommonService;
	}


	/**
	 * @return the paymentTransactionDAO
	 */
	public PaymentTransactionDAO getPaymentTransactionDAO() {
		return paymentTransactionDAO;
	}


	/**
	 * @return the billerService
	 */
	public InvoicePortType getBillerService() {
		return billerService;
	}


	/**
	 * @return the payeeManagementDAO
	 */
	public PayeeManagementDAO getPayeeManagementDAO() {
		return payeeManagementDAO;
	}


	/**
	 * @return the billerManagementDAO
	 */
	public BillerManagementDAO getBillerManagementDAO() {
		return billerManagementDAO;
	}
	
	/**
	 * @param billerPayDetailsVO
	 */
	private String getPaymentInfo(BillerPayDetailsVO billerPayDetailsVO) {
		PaymentDetailVO payment = BillpaymentMappingHelper.getPaymentDetails(billerPayDetailsVO);
		List<String> duplicateFields=new ArrayList<String>();
		checkIfResponseFieldsRequireForPayment(payment,duplicateFields);
		String fieldsDelimitedStr="";
		for(PaymentFieldDetails paymentFieldDetails:payment.getPaymentFieldDetails()){
			if(paymentFieldDetails.getStatus() !=null && CommonConstants.ACTIVE.equalsIgnoreCase(paymentFieldDetails.getStatus())){
			String feildValue=paymentFieldDetails.getFieldValue()==null?"":paymentFieldDetails.getFieldValue();
			if (!duplicateFields.contains(paymentFieldDetails.getFieldLabelName()) && paymentFieldDetails.getFieldType().equalsIgnoreCase(CommonConstants.R)) {
				fieldsDelimitedStr=fieldsDelimitedStr.concat(paymentFieldDetails.getFieldLabelName().concat(CommonConstants.COLON).concat(feildValue)).concat(CommonConstants.COLON);
				}
			if (paymentFieldDetails.getFieldType() != null && paymentFieldDetails.getFieldType().equalsIgnoreCase(CommonConstants.P)) {
				fieldsDelimitedStr=fieldsDelimitedStr.concat(paymentFieldDetails.getFieldLabelName().concat(CommonConstants.COLON).concat(feildValue)).concat(CommonConstants.COLON);
				}
			/*if (paymentFieldDetails.getFieldType() != null && paymentFieldDetails.getFieldType().equalsIgnoreCase(CommonConstants.P)) {
			fieldsDelimitedStr=fieldsDelimitedStr.concat(paymentFieldDetails.getFieldLabelName().concat(CommonConstants.COLON).concat(paymentFieldDetails.getFieldValue())).concat(CommonConstants.COLON);
			}*/	//switch (paymentFieldDetails.getFieldDataType()) {}
			LOGGER.info("Payment Filed getFieldLabelName "+paymentFieldDetails.getFieldLabelName() +
					":: Filed getFieldValue "+paymentFieldDetails.getFieldValue()+
					":: Filed getRemarks "+paymentFieldDetails.getRemarks()+
					":: Filed getCaption "+paymentFieldDetails.getCaption()+
					":: Filed Id "+paymentFieldDetails.getFieldId()+
					":: Filed getFieldType "+paymentFieldDetails.getFieldType()+
					":: Filed Data type "+paymentFieldDetails.getFieldDataType()+" "+billerPayDetailsVO.getPayRef());
			}
		}
		if(fieldsDelimitedStr.length()>1){
			fieldsDelimitedStr=fieldsDelimitedStr.substring(0,fieldsDelimitedStr.length()-1);
		}
		return fieldsDelimitedStr;
	}
	/**
	 * @param payment
	 */
	private void checkIfResponseFieldsRequireForPayment(PaymentDetailVO payment,List<String> duplicateFields) {
		//Check if any response field required for payment
		for (PaymentFieldDetails paymentFieldDetails : payment.getPaymentFieldDetails()) {
			if (paymentFieldDetails.getFieldType() != null && paymentFieldDetails.getFieldType().equalsIgnoreCase(CommonConstants.R)) {
				String responseFieldValue = paymentFieldDetails.getFieldValue();
				for (PaymentFieldDetails paymentFieldDetailsin : payment.getPaymentFieldDetails()) {
					if (paymentFieldDetailsin.getFieldLabelName().equalsIgnoreCase(paymentFieldDetails.getFieldLabelName()) 
							&& paymentFieldDetailsin.getFieldType().equalsIgnoreCase(CommonConstants.P)) {
						duplicateFields.add(paymentFieldDetailsin.getFieldLabelName());
						paymentFieldDetailsin.setFieldValue(responseFieldValue);
					}
				}

			}
		}
	}

	/**
	 * Inform the payment to the aggregator
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	public BillerPayRequestVO aggregatorPaymentCS(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("Start ::: TransactionServiceImpl ::: aggregatorPaymentCS"+billerPayRequestVO.getBillerPayDetailsVO().getPayRef());	
		BillerPayDetailsVO billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
		try {
			billerPayDetailsVO.setHostName(CommonConstants.AGGREGATOR);
			PostPaymentReq postPaymentReq = new PostPaymentReq();
			PostPaymentReqPayload postPaymentReqPayload = new PostPaymentReqPayload();
			postPaymentReqPayload.setPayloadVersion(CommonConstants.PAYLOAD_API_21);
			postPaymentReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
			com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
			InvoiceInfo invoiceInfo = new InvoiceInfo();
			invoiceInfo.setAggregatorIdentifier(dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + 
					CommonConstants.AggregatorIdentifier));
			PaymentDetails paymentDetails = new PaymentDetails();
			
			BillerVO biller = billerManagementDAO.GetBiller(billerPayDetailsVO.getUtilityCd(), billerPayDetailsVO.getCountryCode());
			String strAmount = billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() != null 
					           ? billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount().toString() :CommonConstants.ZERO;
			
			String terminalId = dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + CommonConstants.BILLERDOWNLOAD_TERMINAL_ID);
			String applicationUserId = dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + CommonConstants.Biller_DOWNLOAD_ApplicationUserID);
			String applicationUserKey = dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + CommonConstants.Biller_DOWNLOAD_ApplicationUserKey);
			String currencyConversion = dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
					
			LOGGER.info("Updating the Payment details for aggregator posting aggregatorPaymentCS"+billerPayRequestVO.getBillerPayDetailsVO().getPayRef());	
			
			paymentDetails.setPayerTransactionID(billerPayDetailsVO.getHostReference());
			//paymentDetails.setAccountNumber(billerPayDetailsVO.getConsumerNo()); // Need to check to remove
			
			if(biller != null){
				paymentDetails.setBillerID(biller.getBillerId());
				paymentDetails.setPaymentMode(biller.getAggregatePaymentCode());
			}
			
			if(currencyConversion != null && !currencyConversion.isEmpty() && !currencyConversion.equals(CommonConstants.ZERO)) {
				Double txnAmount = billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() != null 
						           ? billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount().doubleValue() : 0;
				Integer multiplier = Integer.valueOf(currencyConversion);
				//Converting amount from NGN to kudos	
				strAmount = ((Arrays.asList((String.valueOf(txnAmount*multiplier)).split(Pattern.quote(".")))).get(0)).toString();
			} 
			paymentDetails.setTransactionAmount(strAmount);
			
			if(terminalId != null && !terminalId.isEmpty()) {
				paymentDetails.setTerminalID(terminalId);
			}
			if(applicationUserId != null && !applicationUserId.isEmpty()) {
				invoiceInfo.setApplicationUserID(applicationUserId);
			}
			if(applicationUserKey != null && !applicationUserKey.isEmpty()) {
				invoiceInfo.setApplicationUserKey(applicationUserKey);
			}
			
			/*//Going to change this part
			String fieldValues = getPaymentFieldValues(biller.getBillerFields(), billerPayDetailsVO);
			if(fieldValues != null && !fieldValues.isEmpty()) {
				paymentDetails.setPaymentDescription(fieldValues);
			}*/
			String fieldValues=getPaymentInfo(billerPayDetailsVO);
			paymentDetails.setPaymentInfo(fieldValues);//Consilidate payment fields and set as a payment info
			invoiceInfo.getPaymentDetails().add(paymentDetails);
			invoice.setInvoiceInfo(invoiceInfo);
			postPaymentReqPayload.setPostPaymentReq(invoice);
			postPaymentReq.setPostPaymentReqPayload(postPaymentReqPayload);
			
			LOGGER.info("setting scbml header in the request"+billerPayDetailsVO.getPayRef());	
			postPaymentReq.setHeader(BillpaymentMappingHelper.populateSCBHeaderForAggregator(
					                 billerPayDetailsVO.getCountryCode(), "postPayment", 
					                 billerPayRequestVO.getMessageVO().getReqID(), CommonConstants.EMPTY, "put"));
			
			LOGGER.info("Generating XML string request for aggregator aggregatorPaymentCS");	
			String xml = CommonHelper.getXML(postPaymentReq, PostPaymentReq.class, CommonConstants.AGGREGATOR_SUBTYPE);
			LOGGER.info("request to be posted aggregatorPaymentCS" + billerPayDetailsVO.getPayRef());
			topicPostMessageService.postMessage(xml,"scbCashPaymentMobileInvoicePostPaymentV2ReqT");
			LOGGER.info("request posted aggregatorPaymentCS" + billerPayDetailsVO.getPayRef());	
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_INPROGRESS);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.SUCCESS);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(CommonConstants.TIMEOUT_MSG);
		} catch (JMSException jmsException) {
			LOGGER.info("JMS Exception for aggregatorPaymentCS" + billerPayDetailsVO.getPayRef());
			LOGGER.info("JMS Exception occurred aggregatorPaymentCS" , jmsException);
			LOGGER.error("JMS Exception occurred aggregatorPaymentCS" , jmsException);
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(jmsException.getMessage());
			jmsException.printStackTrace();
		} catch(Exception exception){
			LOGGER.info("Exception for aggregatorPaymentCS" + billerPayDetailsVO.getPayRef());
			LOGGER.info("Exception occurred aggregatorPaymentCS" , exception);	
			LOGGER.error("Exception occurred aggregatorPaymentCS" , exception);	
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(exception.getMessage());
			exception.printStackTrace();
		}
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		LOGGER.info("aggregatorPayment ::: TransactionServiceImpl ::: aggregatorPaymentCS");
		return billerPayRequestVO;
	}

	
	/**
	 * @param postTransactionService the postTransactionService to set
	 */
	public void setPostTransactionService(
			com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType postTransactionService) {
		this.postTransactionService = postTransactionService;
	}
	
	/**
	 * @return the postTransactionService
	 */
	public com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType getPostTransactionService() {
		return postTransactionService;
	
}
	
	/**
	 * @return the transactionPortType
	 */
	public TransactionPortType getTransactionPortType() {
		return transactionPortType;
	}
	
	/**
	 * @return the paymentCommonService
	 */
	public PaymentCommonService getPaymentCommonService() {
		return paymentCommonService;
	}


	@Override
	public String getCCReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO) {
		BillerPayDetailsVO billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
		LOGGER.info("Inside  PaymentTransactionServiceImpl: getCCReferenceNumberSequence: "+ billerPayDetailsVO.getPayRef());
		return paymentTransactionDAO.getCCReferenceNumberSequence(billerPayRequestVO);
	}
}