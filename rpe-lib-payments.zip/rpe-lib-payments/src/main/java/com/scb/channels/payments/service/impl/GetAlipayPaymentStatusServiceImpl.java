package com.scb.channels.payments.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.cash.payment.mobile.v2.invoice.Invoice;
import com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo;
import com.sc.cash.payment.mobile.v2.invoice.PaymentStatus;
import com.sc.cash.payment.mobile.v2.invoice.TransactionStatus;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentStatusReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentStatusRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.GetPaymentStatusReqPayload;
import com.sc.scbml_1.PayloadFormatEnum;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.AlipayMappingHelper;
import com.scb.channels.payments.service.GetAlipayPaymentStatusService;

/**
 * @author 1508384
 *
 */
public class GetAlipayPaymentStatusServiceImpl implements GetAlipayPaymentStatusService {
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(GetAlipayPaymentStatusServiceImpl.class);
	/**
	 * invoicePortType
	 */
	private com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType invoicePortType;

	private DataBean dataBean;
	
	@Override
	public BillerPayResponseVO getAlipayPaymentStatus(
			BillerPayRequestVO billerPayRequestVO) throws Exception {
		
		LOGGER.info("GetAlipayPaymentStatusServiceImpl :: Inside getPaymentStatus :: Start");
		billerPayRequestVO.getBillerPayDetailsVO().setHostName(
			CommonConstants.ALIPAY_AGGREGATOR + " - " + CommonConstants.PAYMENT_STATUS_ENQUIRY);
		
		GetPaymentStatusReq getPaymentStatusReq = performGetPaymentStatusRequestPayload(billerPayRequestVO);
		LOGGER.info(" getPaymentStatusReq " + getPaymentStatusReq); 

		LOGGER.info("Before sending Request to EDMI");
		GetPaymentStatusRes  getPaymentStatusRes = invoicePortType.getPaymentStatus(getPaymentStatusReq);
		LOGGER.info(" getPaymentStatusReq " + getPaymentStatusRes);
		
		LOGGER.info("After getting response from EDMI");
		BillerPayResponseVO  billerPayResponseVO = performGetPaymentStatusResponseWrapper(
				getPaymentStatusRes, billerPayRequestVO);
		LOGGER.info("GetAlipayPaymentStatusServiceImpl :: Inside getPaymentStatus :: END");
		
		return billerPayResponseVO;
}
	
	
	private GetPaymentStatusReq performGetPaymentStatusRequestPayload(
			BillerPayRequestVO billerPayRequestVO) throws Exception  {
		LOGGER.info("GetAlipayPaymentStatusServiceImpl :: performGetPaymentStatusRequestPayload :: Start");
		
		Invoice invoice=new Invoice();
		InvoiceInfo invoiceInfo = new InvoiceInfo();
		GetPaymentStatusReq getPaymentStatusReq = new GetPaymentStatusReq();
		GetPaymentStatusReqPayload getPaymentStatusReqPayload = new GetPaymentStatusReqPayload();
		getPaymentStatusReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		//getPaymentStatusReqPayload.setPayloadVersion(CommonConstants.VERSION);
		getPaymentStatusReqPayload.setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
		invoiceInfo.setClientSecret("ENCRYPTION");
	
		invoiceInfo.setTransactionID(billerPayRequestVO.getBillerPayDetailsVO().getHostReference());
		LOGGER.info("Set TransactionID :::Alipay " + 
				billerPayRequestVO.getBillerPayDetailsVO().getHostReference() + " ::: " +
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		invoice.setInvoiceInfo(invoiceInfo);
		getPaymentStatusReqPayload.setGetPaymentStatusReq(invoice);
		getPaymentStatusReq.setGetPaymentStatusReqPayload(getPaymentStatusReqPayload);
		
		LOGGER.info("Setting Header :::Alipay " + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
	/*	getPaymentStatusReq.setHeader(AlipayMappingHelper.populateHeader(
				billerPayRequestVO.getUser().getCountry(), 
				CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef(), 
				CommonConstants.ALIPAY_AGGREGATOR, CommonConstants.GET_PAYMENTSTATUS,
				CommonConstants.GET, CommonConstants.INVOICE_NAME, CommonConstants.DOMAIN_NAME_AGG));*/
		
		getPaymentStatusReq.setHeader(AlipayMappingHelper.populateHeaderGetPaymentStatus(
				billerPayRequestVO.getUser().getCountry(), 
				CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef(), 
				"Alipay", CommonConstants.GET_PAYMENTSTATUS,
				CommonConstants.GET, CommonConstants.INVOICE_NAME, CommonConstants.DOMAIN_NAME_AGG));
		
		LOGGER.info("GetAlipayPaymentStatusServiceImpl :: performGetPaymentStatusRequestPayload ::Alipay End");
		return getPaymentStatusReq;
	}
	
	/**
	 * @param getPaymentStatusRes
	 * @param billerPayRequestVO
	 * @return
	 */
	private BillerPayResponseVO performGetPaymentStatusResponse(
			GetPaymentStatusRes paymentStatusResponse, 
			BillerPayRequestVO billerPayRequestVo) throws Exception {
		
		BillerPayResponseVO billerPayResponseVo = new BillerPayResponseVO();
		BillerPayDetailsVO billerDetails = billerPayRequestVo.getBillerPayDetailsVO();
		String paymentStatus = null;
		String trackingId = null;
		boolean isPaymentAvailableInAggregator = true;
		try {
			if (paymentStatusResponse.getHeader() != null
					&& paymentStatusResponse.getHeader().getOriginationDetails() != null) {
				trackingId = paymentStatusResponse.getHeader().getOriginationDetails().getTrackingId();
			
				if(paymentStatusResponse.getHeader().getExceptions() != null && 
						paymentStatusResponse.getHeader().getExceptions().getException() != null) {
					
					ExceptionType exception = paymentStatusResponse.getHeader().getExceptions().getException().get(0);
					
					LOGGER.info("Payment failed for transaction ::Alipay " + trackingId);
					LOGGER.info("error code Alipay" + exception.getCode().getValue());
					LOGGER.info("error desc Alipay" + exception.getDescription());
					
					billerDetails.getTransactionInfoVO().setTxnStatusCd(exception.getCode().getValue());
					billerDetails.getTransactionInfoVO().setHostRespDesc(exception.getDescription());
					
					billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
					
				} else {
					LOGGER.info("Getting payment status for ::::::::: " + trackingId);
					
					if(paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes() != null &&
							paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo() != null) {
						
						LOGGER.info("Payment invoice object available for ALipay::::::::: " + trackingId);
						if (paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().
								getTransactionStatus() != null &&
							paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().
								getTransactionStatus().getStatusCode() != null) {
							
							paymentStatus = paymentStatusResponse.getGetPaymentStatusResPayload().
									getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus().getStatusCode();
							
							if (Arrays.asList(dataBean.getMap().get(CommonConstants.AGGREGATOR_NODATA_STATUS).
									split(CommonConstants.COMMA)).contains(paymentStatus) &&
									(paymentStatusResponse.getGetPaymentStatusResPayload().
										getGetPaymentStatusRes().getInvoiceInfo().
										getTransactionStatus().getStatusDescription() == null ||
									paymentStatusResponse.getGetPaymentStatusResPayload().
										getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus().
										getStatusDescription().equals(CommonConstants.EMPTY) ||
									paymentStatusResponse.getGetPaymentStatusResPayload().
										getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus().
										getStatusDescription().equalsIgnoreCase("Not Found"))) {
						
								isPaymentAvailableInAggregator = false;
								billerPayResponseVo.setStatus("DOIT");
								LOGGER.info("Payment not available in aggregator ::::::::: " + trackingId);
							}
						}
						
						if(isPaymentAvailableInAggregator && paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus() != null &&
							!paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus().isEmpty() &&
							paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus().
								get(0).getTransactionStatus() != null) {
									
							PaymentStatus paymentStatusObj = paymentStatusResponse.getGetPaymentStatusResPayload().
									getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus().get(0);
							LOGGER.info("Payment status object available ::::::::: " + trackingId);
							
							//paymentStatus = paymentStatusObj.getTransactionStatus();
							
							paymentStatus = paymentStatusObj.getStatusCode();
							
							// Added newly for Alipay - start 
							// Payment Date
							/*SimpleDateFormat format = new SimpleDateFormat("dd MMM YYYY hh:mm:ss.SSS");
							Date parseDate = format.parse(paymentStatusObj.getPaymentDate());
							billerDetails.getPaymentDetailsVO().setPaymentDate(
										new java.sql.Timestamp(parseDate.getTime())); */
							
							// Transaction Id
							TransactionInfoVO transactionInfoVO= new TransactionInfoVO();
							transactionInfoVO.setTxnId(paymentStatusObj.getTransactionID());
							billerDetails.setTransactionInfoVO(transactionInfoVO);
							billerDetails.getTransactionInfoVO().setTxnId(paymentStatusObj.getTransactionID());
							
							// Added newly for Alipay - end
							
							billerDetails.getTransactionInfoVO().setHostRespCd(
									paymentStatusObj.getTransactionStatus());
							billerDetails.getTransactionInfoVO().setHostRespDesc(
									paymentStatusObj.getMessage());
							
							if(paymentStatusObj.getAggregatorTransactionID() != null){
								billerDetails.getTransactionInfoVO().setHostTxnRefNo(
										paymentStatusObj.getAggregatorTransactionID());

							}
							
							if(Arrays.asList(dataBean.getMap().
									get(CommonConstants.AGGREGATOR_SUCCESS_STATUS).
									split(CommonConstants.COMMA)).contains(paymentStatus)) {
								LOGGER.info("Setting success ::: " + paymentStatus + " ::::: " + trackingId);
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
								
							} else if(Arrays.asList(dataBean.getMap().
									get(CommonConstants.AGGREGATOR_PAY_FAILURE).
									split(CommonConstants.COMMA)).contains(paymentStatus)) {
								LOGGER.info("Setting failure ::: " + paymentStatus + " ::::: " + trackingId);
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
							}
							
							billerPayResponseVo.setStatus("DONE");
						}
						LOGGER.info("Payment status from Alipay Aggregator :::: " + paymentStatus + 
								" ::::: " + trackingId);
						LOGGER.info("Payment success after alipay aggregator call :::: " + 
								billerDetails.getTxnActStatus() + " ::::: " + trackingId);
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.info("Exception occurred in get payment status from Alipay ::: " 
					+ " ::::: " + trackingId);
			throw exception;
		}
		
		billerPayResponseVo.setUser(billerPayRequestVo.getUser());
		billerPayResponseVo.setServiceVO(billerPayRequestVo.getServiceVO());
		billerPayResponseVo.setClientVO(billerPayRequestVo.getClientVO());
		billerPayResponseVo.setMessageVO(billerPayRequestVo.getMessageVO());
		billerPayResponseVo.setBillerPayDetailsVO(billerDetails);
		
		return billerPayResponseVo;
	}
	
		/**
	 * @param getPaymentStatusRes
	 * @param billerPayRequestVO
	 * @return
	 */
	@SuppressWarnings("unused")
	private BillerPayResponseVO performGetPaymentStatusResponseWrapper(GetPaymentStatusRes paymentStatusResponse, BillerPayRequestVO billerPayRequestVo) throws Exception {
		BillerPayResponseVO billerPayResponseVo = new BillerPayResponseVO();
		BillerPayDetailsVO billerDetails = billerPayRequestVo.getBillerPayDetailsVO();
		String paymentStatus = null;
		String trackingId = null;
		boolean isPaymentAvailableInAggregator = true;
		try {
			if (paymentStatusResponse.getHeader() != null && paymentStatusResponse.getHeader().getOriginationDetails() != null) {
				trackingId = paymentStatusResponse.getHeader().getOriginationDetails().getTrackingId();
				if (paymentStatusResponse.getHeader().getExceptions() != null && paymentStatusResponse.getHeader().getExceptions().getException() != null) {
					ExceptionType exception = paymentStatusResponse.getHeader().getExceptions().getException().get(0);
					LOGGER.info("Payment failed for transaction ::Alipay " + trackingId);
					LOGGER.info("error code Alipay" + exception.getCode().getValue());
					LOGGER.info("error desc Alipay" + exception.getDescription());
					billerDetails.getTransactionInfoVO().setHostRespCd(exception.getCode().getValue());
					billerDetails.getTransactionInfoVO().setHostRespDesc(exception.getDescription());
					billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
				} else {
					LOGGER.info("Getting payment status for ::::::::: " + trackingId);
					if (paymentStatusResponse != null) {
						if (paymentStatusResponse.getGetPaymentStatusResPayload() != null) {
							if (paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes() != null) {
								if (paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes().getInvoiceInfo() != null) {
									// Transaction status
									if (paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus() != null) {
										TransactionStatus transactionStatus = paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus();
										LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusCode() " + transactionStatus.getStatusCode());
										LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatus() " + transactionStatus.getStatus());
										LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusCodeID() " + transactionStatus.getStatusCodeID());
										LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusDescription() " + transactionStatus.getStatusDescription());
										if (transactionStatus.getStatusCodeID() != null) {
											if (transactionStatus.getStatusCodeID().equalsIgnoreCase(CommonConstants.ALIPAY_SUCCESS)) {
												billerPayResponseVo.setStatus("DONE");
												List<PaymentStatus> listPaymentStatus = paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus();
												if (listPaymentStatus != null) {
													for (PaymentStatus PaymentStatus : listPaymentStatus) {
														
														billerDetails.getTransactionInfoVO().setTxnId(PaymentStatus.getTransactionID());
														billerDetails.getTransactionInfoVO().setHostRespCd(PaymentStatus.getStatusCodeID());
														billerDetails.getTransactionInfoVO().setHostRespDesc(PaymentStatus.getMessage());
														billerDetails.getTransactionInfoVO().setHostTxnRefNo(PaymentStatus.getAggregatorTransactionID());
														
														if(PaymentStatus.getStatusCodeID() != null && 
																Arrays.asList(dataBean.getMap().
																		get(billerDetails.getCountryCode() + CommonConstants.AGGREGATOR_SUCCESS_STATUS).
																		split(CommonConstants.COMMA)).
																		contains(PaymentStatus.getStatusCodeID())) {
															
															LOGGER.info("Setting success in query payment ::: " + PaymentStatus.getStatusCodeID());
															billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
															
														} else if(PaymentStatus.getStatusCodeID() != null && 
																Arrays.asList(dataBean.getMap().
																		get(billerDetails.getCountryCode() + CommonConstants.AGGREGATOR_INPROCESS_STATUS).
																		split(CommonConstants.COMMA)).
																		contains(PaymentStatus.getStatusCodeID())) {
															LOGGER.info("Setting UNknown Status to INprocess  in query payment ::: " + PaymentStatus.getStatusCodeID());
															billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_INPROCESS);								
														}else if(PaymentStatus.getStatusCodeID() != null && 
																Arrays.asList(dataBean.getMap().
																		get(billerDetails.getCountryCode() + CommonConstants.AGGREGATOR_NOT_SUCCESS).
																		split(CommonConstants.COMMA)).
																		contains(PaymentStatus.getStatusCodeID())) {
															LOGGER.info("Setting UNknown Status to INprocess  in query payment ::: " + PaymentStatus.getStatusCodeID());
															billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_NOT_SUCCESS);								
														}
														
														else {
															LOGGER.info("Setting failure  in query payment ::: " + PaymentStatus.getStatusCodeID());
															billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
														}
														
														/*if (PaymentStatus.getStatusCodeID() != null) {
															if (PaymentStatus.getStatusCodeID().equalsIgnoreCase(CommonConstants.ALIPAY_SUCCESS)) {
																billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
															} else {
																billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
															}
														}*/
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getTransactionStatus() " + PaymentStatus.getTransactionStatus());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusOfPayment() " + PaymentStatus.getStatusOfPayment());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getAmount() " + PaymentStatus.getAmount());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getMessage() " + PaymentStatus.getMessage());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getCurrencyCode() " + PaymentStatus.getCurrencyCode());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getAggregatorTransactionID() " + PaymentStatus.getAggregatorTransactionID());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusCodeID() " + PaymentStatus.getStatusCodeID());
														LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusCode() " + PaymentStatus.getStatusCode());
														break;
													}
													LOGGER.info("Tracking ID" + trackingId + "Done");
												} else {
													LOGGER.info("listPaymentStatus!=null" + trackingId);
												}

											} else if (transactionStatus.getStatusCodeID().equalsIgnoreCase(CommonConstants.ALIPAY_NO_FUND_ORDER)) {
												billerPayResponseVo.setStatus("DOIT");
												billerDetails.getTransactionInfoVO().setHostRespCd(transactionStatus.getStatusCodeID());
												billerDetails.getTransactionInfoVO().setHostRespDesc(transactionStatus.getStatusDescription());
												//billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
												LOGGER.info("Payment not available in aggregator ::::::::: " + trackingId);
											} else {
												billerDetails.getTransactionInfoVO().setHostRespCd(transactionStatus.getStatusCodeID());
												billerDetails.getTransactionInfoVO().setHostRespDesc(transactionStatus.getStatusDescription());
												//billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
												LOGGER.info("Unknown status " + transactionStatus.getStatusCodeID());
											}
										} else {
											LOGGER.info("Tracking ID" + trackingId + "  :: " + " transactionStatus.getStatusDescription() is null");
										}
									} else {
										LOGGER.info("paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus() !=null");
									}
									// Payment Status
								} else {
									LOGGER.info("paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes().getInvoiceInfo() !=null");
								}

							} else {
								LOGGER.info("Exception paymentStatusResponse.getGetPaymentStatusResPayload().getGetPaymentStatusRes() !=null");
							}

						} else {
							LOGGER.info("Exception paymentStatusResponse.getGetPaymentStatusResPayload() !");
						}

					} else {
						LOGGER.info("Exception paymentStatusResponse !=null ");
					}
				}
			}
		} catch (Exception exception) {
			//billerDetails.getTransactionInfoVO().setHostRespCd("QUERY_EXCEPTION");
			billerDetails.getTransactionInfoVO().setHostRespDesc("Exception :: "+exception.getMessage());
			//billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
			LOGGER.info("Exception occurred in get payment status from Alipay ::: ::::: " + trackingId);
			throw exception;
		}
		billerPayResponseVo.setUser(billerPayRequestVo.getUser());
		billerPayResponseVo.setServiceVO(billerPayRequestVo.getServiceVO());
		billerPayResponseVo.setClientVO(billerPayRequestVo.getClientVO());
		billerPayResponseVo.setMessageVO(billerPayRequestVo.getMessageVO());
		billerPayResponseVo.setBillerPayDetailsVO(billerDetails);

		return billerPayResponseVo;
	}

	
	public void setInvoicePortType(InvoicePortType invoicePortType) {
		this.invoicePortType = invoicePortType;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
	
}
