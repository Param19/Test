package com.scb.channels.qrpayments.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentHistoryResponseVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.base.vo.QRPaymentViewVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.qrpayments.service.QRPaymentService;

public class QRPaymentHistoryProcessor extends AbstractProcessor{

	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentHistoryProcessor.class);
	
	private QRPaymentService qrPaymentService;
	
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.debug("In 000000000000 --> PaymentHistoryProcessor ");
		QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO = null;
		List<QRPaymentVO> qrPaymentHistoryList = null;
		//List<QRPaymentViewVO> qrPaymentHistoryList = null;
		QRPaymentHistoryResponseVO qrPaymentHistoryResponse = new QRPaymentHistoryResponseVO();
		try {

			qrPaymentHistoryRequestVO = (QRPaymentHistoryRequestVO) bean.getRequestVO();
			qrPaymentHistoryList = qrPaymentService.getQRPaymentHistoryViewById(qrPaymentHistoryRequestVO);
			LOGGER.info("After getting the values from DB ------> QR PaymentHistoryProcessor "	+ qrPaymentHistoryList);
			if(qrPaymentHistoryList!=null)
			{
				qrPaymentHistoryResponse.setStatus(Messages._150.getCode());
				qrPaymentHistoryResponse.setStatusDesc(Messages._150.getMessage());
				qrPaymentHistoryResponse.setQrPaymentHistoryViewList(qrPaymentHistoryList);
			}else
			{
				qrPaymentHistoryResponse.setStatus(Messages._151.getCode());
				qrPaymentHistoryResponse.setStatusDesc(Messages._151.getMessage());
			}
			qrPaymentHistoryResponse.setClientVO(qrPaymentHistoryRequestVO.getClientVO());
			qrPaymentHistoryResponse.setUser(qrPaymentHistoryRequestVO.getUser());
			qrPaymentHistoryResponse.setServiceVO(qrPaymentHistoryRequestVO.getServiceVO());
			qrPaymentHistoryResponse.setMessageVO(qrPaymentHistoryRequestVO.getMessageVO());
			
			bean.setResponseVO(qrPaymentHistoryResponse);
		} catch (Exception e) {

			LOGGER.error("Exception block at DoTask --> QRPaymentHistoryProcessor "
					+ e.getMessage());
			qrPaymentHistoryResponse.setErrorDesc(ExceptionMessages._152.getMessage());
			qrPaymentHistoryResponse.setErrorCD(ExceptionMessages._152.getCode());
		}
		return bean;
	}
	public QRPaymentService getQrPaymentService() {
		return qrPaymentService;
	}
	public void setQrPaymentService(QRPaymentService qrPaymentService) {
		this.qrPaymentService = qrPaymentService;
	}

}
