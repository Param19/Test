package com.scb.channels.qrpayments.service;

import java.util.List;

import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.base.vo.QRPaymentViewVO;

public interface QRPaymentService {
	
	//public List<QRPaymentVO> getQRPaymentHistoryById(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO);
	
	//public List<QRPaymentViewVO> getQRPaymentHistoryViewById(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO);
	
	public List<QRPaymentVO> getQRPaymentHistoryViewById(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO);

}
