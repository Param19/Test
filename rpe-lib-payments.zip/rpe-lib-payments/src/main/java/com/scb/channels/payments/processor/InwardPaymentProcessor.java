package com.scb.channels.payments.processor;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.ConstrtaintException;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.payments.service.InwardTransactionService;
import com.scb.channels.payments.service.PaymentCommonService;

/**
 * The Class InwardPaymentProcessor.
 *
 * @author 1493439
 */
public class InwardPaymentProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(InwardPaymentProcessor.class);
	
	/**  The inward transaction service. */
	private InwardTransactionService inwardTransactionService;
	
	/** The common service. */
	private PaymentCommonService paymentCommonService;
	
	/** The data bean. */
	private DataBean dataBean;
	
	/**
	 * Process customer enquiry.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO processCustomerEnquiry(PayloadDTO payloadDTO) throws Exception {
		
	LOGGER.info("InwardPaymentProcessor processCustomerEnquiry Entry:::: "+payloadDTO);
	
		if(payloadDTO != null && payloadDTO.getRequestVO() != null){
			payloadDTO = paymentCommonService.getCustomerEnqiury(payloadDTO);
			LOGGER.info("InwardPaymentProcessor processCustomerEnquiry after customer Enquiry:::");
		}
	LOGGER.info("InwardPaymentProcessor process END:::: "+payloadDTO.getRequestVO() + "Response :::"+payloadDTO.getResponseVO());	
	return payloadDTO;
	}

	/**
	 * Process account enquiry.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO processAccountEnquiry(PayloadDTO payloadDTO) throws Exception {
			
		LOGGER.info("InwardPaymentProcessor processAccountEnquiry Entry:::: "+payloadDTO);

		if(payloadDTO != null && payloadDTO.getRequestVO() != null){
			LOGGER.info("InwardPaymentProcessor processAccountEnquiry if:::: "+payloadDTO.getRequestVO());
			payloadDTO = paymentCommonService.getAccountEnqiury(payloadDTO);
		}
		LOGGER.info("InwardPaymentProcessor process END:::: "+payloadDTO.getRequestVO() + "Response :::"+payloadDTO.getResponseVO());	
		return payloadDTO;
	}
	
	/**
	 * Process single leg post.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO processSingleLegPost(PayloadDTO payloadDTO) throws Exception{
		
		if(payloadDTO != null && payloadDTO.getRequestVO() != null){
			LOGGER.info("InwardPaymentProcessor processSingleLegPost if:::: "+payloadDTO.getRequestVO());
			payloadDTO = inwardTransactionService.performInwardBillPayment(payloadDTO);
		}
		
		return payloadDTO;
		
	}
	
	/**
	 * Save inward credit details.
	 * k
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws BusinessException the business exception
	 */
	public PayloadDTO saveInwardCreditDetails(PayloadDTO payloadDTO) throws BusinessException{
		inwardTransactionService.saveInwardPayment(payloadDTO);
		LOGGER.info("InwardPaymentProcessor saveInwardCreditDetails:::: "+payloadDTO);
		return payloadDTO;
	}
	
	/**
	 * Update inward credit details.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws ConstrtaintException the constrtaint exception
	 */
	public PayloadDTO updateInwardCreditDetails(PayloadDTO payloadDTO) throws ConstrtaintException{
		inwardTransactionService.updateInwardPayment(payloadDTO);
		LOGGER.info("InwardPaymentProcessor updateInwardCreditDetails:::: "+payloadDTO);
		return payloadDTO;
	}
	
	
	public PayloadDTO updateStatusCheck(PayloadDTO payloadDTO) throws Exception{
		inwardTransactionService.updateStatusCheck(payloadDTO);
		LOGGER.info("InwardPaymentProcessor updateStatusCheck:::: "+payloadDTO);
		return payloadDTO;
	}
	
	/**
	 * Inward inquiry.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws ConstrtaintException the constrtaint exception
	 */
	public PayloadDTO inwardInquiry(PayloadDTO payloadDTO) throws ConstrtaintException{
		
		payloadDTO = inwardTransactionService.getInwardPayment(payloadDTO);
		
		return payloadDTO;
	}
	
	/**
	 * Validate credit history request.
	 *
	 * @param payload the payload
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO validateCreditHistoryRequest(PayloadDTO payload) throws Exception {
		
		payload = inwardTransactionService.validateCreditHistoryRequest(payload);
		
		return payload;
	}
	
	
	/**
	 * Gets the credit history.
	 *
	 * @param payload the payload
	 * @return the credit history
	 * @throws Exception the exception
	 */
	public PayloadDTO getCreditHistory(PayloadDTO payload) throws Exception {
		
		payload = inwardTransactionService.getCreditHistory(payload);
		
		return payload;
	}
	/*1570965*/
	public PayloadDTO getWalletCreditHistory(PayloadDTO payload) throws Exception {
			
			payload = inwardTransactionService.getWalletCreditHistory(payload);
			
			return payload;
		}
	
	public PayloadDTO mobileValidCountryCheck(PayloadDTO payloadDTO){
		
		LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck start:::: "+payloadDTO);
		InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
		LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck start:::: "+inwardPaymentRequestVO.getReferenceNumber());
		
		String requestCountry = inwardPaymentRequestVO.getClientInfoVO().getCountry();
		String countryMap = dataBean.getMap().get("INWARD_MOBILE_VALIDATION_COUNTRIES");
		
		LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck countryMap:::: "+countryMap);
		
		if(countryMap != null){
			countryMap = countryMap.trim();
			String[] countryMaps = countryMap.split(",");
			LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck if condition countryMaps:::: "+countryMaps);
			ArrayList<String> arrayList = new ArrayList<String>();
			for(String country:countryMaps){
				arrayList.add(country);
			}
			LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck if condition arrayList:::: "+arrayList);
			if(arrayList.contains(requestCountry)){
				LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck requestCountry.equalsIgnoreCase(country):::: "+requestCountry);
				inwardPaymentRequestVO.setStatus("M000");
			} else {
				LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck else arrayList.contains(requestCountry):::: "+payloadDTO);
				inwardPaymentRequestVO.setStatus("false");
			}
		} else {
			LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck else countryMap:::: "+payloadDTO);
			inwardPaymentRequestVO.setStatus("false");
		}
		
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		LOGGER.info("InwardPaymentProcessor mobileValidCountryCheck end:::: "+payloadDTO);
		return payloadDTO;
	}
	
	public PayloadDTO processCreditStatusCheck(PayloadDTO payloadDTO) throws Exception{
		LOGGER.info("InwardPaymentProcessor processCreditStatusCheck start:::: "+payloadDTO);
		payloadDTO = inwardTransactionService.creditInquiryStatusCheck(payloadDTO);
		LOGGER.info("InwardPaymentProcessor processCreditStatusCheck end:::: "+payloadDTO);
		return payloadDTO;
	}
	
	/**
	 * Sets the inward transaction service.
	 *
	 * @param inwardTransactionService the inwardTransactionService to set
	 */
	public void setInwardTransactionService(InwardTransactionService inwardTransactionService) {
		this.inwardTransactionService = inwardTransactionService;
	}

	/**
	 * @return the paymentCommonService
	 */
	public PaymentCommonService getPaymentCommonService() {
		return paymentCommonService;
	}

	/**
	 * @param paymentCommonService the paymentCommonService to set
	 */
	public void setPaymentCommonService(PaymentCommonService paymentCommonService) {
		this.paymentCommonService = paymentCommonService;
	}

	/**
	 * @return the inwardTransactionService
	 */
	public InwardTransactionService getInwardTransactionService() {
		return inwardTransactionService;
	}

	/**
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
}
