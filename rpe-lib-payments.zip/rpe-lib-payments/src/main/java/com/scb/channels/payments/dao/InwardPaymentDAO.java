package com.scb.channels.payments.dao;

import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.ConstrtaintException;

/**
 * The Interface InwardPaymentDAO.
 *
 * @author 1493439
 */
public interface InwardPaymentDAO {

	
}
