package com.scb.channels.payments.processor;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardInquiryResponseVO;
import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.mapper.helper.InwardMappingHelper;
import com.scb.channels.payments.service.WalletTransactionService;

/**
 * The Class WalletPaymentProcessor.
 *
 * @author 1317590
 */
public class WalletPaymentProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(WalletPaymentProcessor.class);

	/** The inward transaction service. */
	private WalletTransactionService walletTransactionService;

	public WalletTransactionService getWalletTransactionService() {
		return walletTransactionService;
	}

	public void setWalletTransactionService(WalletTransactionService walletTransactionService) {
		this.walletTransactionService = walletTransactionService;
	}

	/**
	 * Validate Wallet Request.
	 *
	 * @param inwardPaymentRequestVO
	 *            the inward payment request vo
	 * @return the payload dto
	 */
	public PayloadDTO processValidateWallet(InwardPaymentRequestVO inwardPaymentRequestVO) {

		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info(":::::::: WalletPaymentProcessor processValidateWallet starts ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		InwardPaymentResponseVO inwardPaymentResponseVO = walletTransactionService
				.validateWalletRequest(inwardPaymentRequestVO);
		payloadDTO.setResponseVO(inwardPaymentResponseVO);
		LOGGER.info(":::::::: WalletPaymentProcessor processValidateWallet ends ::::::::");
		return payloadDTO;
	}

	/**
	 * Process single leg post.
	 *
	 * @param payloadDTO
	 *            the payload dto
	 * @return the payload dto
	 * @throws Exception
	 *             the exception
	 */
	public PayloadDTO processPostSingleLegTransaction(PayloadDTO payloadDTO) throws Exception {

		if (payloadDTO != null && payloadDTO.getRequestVO() != null) {
			LOGGER.info("InwardPaymentProcessor processSingleLegPost if:::: " + payloadDTO.getRequestVO());
			// CR1477, Orange Money changes Starts, 03Feb18, Vijayan A

			InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO) payloadDTO.getRequestVO();

			InwardPaymentResponseVO inwardPaymentResponseVO = walletTransactionService
					.postSingleLegTransaction(inwardPaymentRequestVO);

			payloadDTO.setRequestVO(inwardPaymentRequestVO);
			payloadDTO.setResponseVO(inwardPaymentResponseVO);
		}

		return payloadDTO;

	}

	/**
	 * Process Wallet Retry.
	 *
	 * @param
	 * @return the list of InwardInquiryRequestVO
	 * 
	 */
	public List<InwardInquiryRequestVO> processWalletRetry() {
		LOGGER.info("Inside PaymentRetryListProcessor processWalletRetry");

		List<InwardInquiryRequestVO> list = null;
		InwardPaymentDetailVO inwardPaymentDetailsVO = null;
		try {
			LOGGER.info(":::: Getting retry payments for default (africa) Wallet");
			
			List<InwardPaymentDetailVO> inwardPaymentDetailVO = walletTransactionService
					.getWalletPaymentRetryTransactionList(inwardPaymentDetailsVO);

			if(inwardPaymentDetailVO != null && inwardPaymentDetailVO.size() > 0) {
				
				list = new ArrayList<InwardInquiryRequestVO>();
				for (InwardPaymentDetailVO paymentDetailVO : inwardPaymentDetailVO) {
					list.add(InwardMappingHelper.setInwardPaymentDetail(paymentDetailVO));
				}
			}

			LOGGER.info("Inside PaymentRetryListProcessor After Fetching retry list from DB -- " + list);
		} catch (Exception e) {			
			LOGGER.error("Exception ::: ", e);
		}
		return list;
	}

	/**
	 * populatePayload for retry .
	 *
	 * @param inwardInquiryRequestVO
	 * @return PayloadDTO
	 * 
	 */
	public PayloadDTO populatePayload(InwardInquiryRequestVO inwardInquiryRequestVO) {
		PayloadDTO payloadDTO = null;
		LOGGER.info("Inside populatePayload  at PaymentRetryListProcessor ");
		BillerPayRequestVO billerPayRequestVO = null;
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();
		InwardInquiryResponseVO inwardInquiryResponseVO = new InwardInquiryResponseVO();

		try {
			billerPayRequestVO = new BillerPayRequestVO();
			if (inwardInquiryRequestVO != null) {
				LOGGER.info("Populate payload for retry :::: " + inwardInquiryRequestVO.getHostReferenceNumber());

				service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				service.setServiceName(CommonConstants.INWARD_PAYMENT);

				message.setReqID(inwardInquiryRequestVO.getHostReferenceNumber());

				client.setChannel(CommonConstants.IBANK);
				client.setCountry(inwardInquiryRequestVO.getClientInfoVO().getCountry());

				inwardInquiryRequestVO.setUser(user);
				inwardInquiryRequestVO.setClientVO(client);
				inwardInquiryRequestVO.setMessageVO(message);
				inwardInquiryRequestVO.setServiceVO(service);
				payloadDTO = new PayloadDTO();
				payloadDTO.setRequestVO(inwardInquiryRequestVO);
				payloadDTO.setResponseVO(inwardInquiryResponseVO);
			}
		} catch (Exception e) {
			payloadDTO = null;
		//	e.printStackTrace();
			LOGGER.error("Exception occurred during retry for one of the payments", e);
			//LOGGER.error(e.getMessage());
		}
		return payloadDTO;
	}
}
