package com.scb.channels.payments.vo;

import java.util.Date;

/**
 * The Class BillPmtTxnVO.
 */
public class BillPmtTxnVO {
	
	/** The id. */
	private int id;
	
	/** The txn id. */
	private String txnId;
	
	/** The request id. */
	private String requestId;
	
	/** The consumer no. */
	private String consumerNo;
	
	/** The cust id. */
	private String custId;
	
	/** The biller cd. */
	private String billerCd;
	
	/** The from acct no. */
	private String fromAcctNo;
	
	/** The from acct type. */
	private String fromAcctType;
	
	/** The from acct currency cd. */
	private String fromAcctCurrencyCd;
	
	/** The card acct no. */
	private String cardAcctNo;
	
	/** The card acct type. */
	private String cardAcctType;
	
	/** The card acct currency cd. */
	private String cardAcctCurrencyCd;
	
	/** The service type. */
	private String serviceType;
	
	/** The pmt amt. */
	private double pmtAmt;
	
	/** The debit amt. */
	private double debitAmt;
	
	/** The exchg rate. */
	private double exchgRate;
	
	/** The cost rate. */
	private double costRate;
	
	/** The cust rate. */
	private double custRate;
	
	/** The card pmt amt type. */
	private String cardPmtAmtType;
	
	/** The pmt source. */
	private String pmtSource;
	
	/** The pmt ref. */
	private String pmtRef;
	
	/** The processing mode. */
	private double processingMode;
	
	/** The dt pmt. */
	private Date dtPmt;
	
	/** The txn mode. */
	private String txnMode;
	
	/** The txn status cd. */
	private String txnStatusCd;
	
	/** The txn type cd. */
	private String txnTypeCd;
	
	/** The host txn ref no. */
	private String hostTxnRefNo;
	
	/** The host resp cd. */
	private String hostRespCd;
	
	/** The host resp desc. */
	private String hostRespDesc;
	
	/** The client ref no. */
	private String clientRefNo;
	
	/** The dt processed. */
	private Date dtProcessed;
	
	/** The is reg biller. */
	private char isRegBiller;
	
	/** The recurrence interval. */
	private String recurrenceInterval;
	
	/** The recurrence start dt. */
	private Date recurrenceStartDt;
	
	/** The recurrence end dt. */
	private Date recurrenceEndDt;
	
	/** The ctry cd. */
	private String ctryCd;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private int version;
	
	/** The dt next exec. */
	private Date dtNextExec;
	
	/** The biller trans type cd. */
	private String billerTransTypeCd;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Gets the txn id.
	 *
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}
	
	/**
	 * Sets the txn id.
	 *
	 * @param txnId the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	
	/**
	 * Gets the request id.
	 *
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}
	
	/**
	 * Sets the request id.
	 *
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	/**
	 * Gets the consumer no.
	 *
	 * @return the consumerNo
	 */
	public String getConsumerNo() {
		return consumerNo;
	}
	
	/**
	 * Sets the consumer no.
	 *
	 * @param consumerNo the consumerNo to set
	 */
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}
	
	/**
	 * Gets the cust id.
	 *
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}
	
	/**
	 * Sets the cust id.
	 *
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	/**
	 * Gets the biller cd.
	 *
	 * @return the billerCd
	 */
	public String getBillerCd() {
		return billerCd;
	}
	
	/**
	 * Sets the biller cd.
	 *
	 * @param billerCd the billerCd to set
	 */
	public void setBillerCd(String billerCd) {
		this.billerCd = billerCd;
	}
	
	/**
	 * Gets the from acct no.
	 *
	 * @return the fromAcctNo
	 */
	public String getFromAcctNo() {
		return fromAcctNo;
	}
	
	/**
	 * Sets the from acct no.
	 *
	 * @param fromAcctNo the fromAcctNo to set
	 */
	public void setFromAcctNo(String fromAcctNo) {
		this.fromAcctNo = fromAcctNo;
	}
	
	/**
	 * Gets the from acct type.
	 *
	 * @return the fromAcctType
	 */
	public String getFromAcctType() {
		return fromAcctType;
	}
	
	/**
	 * Sets the from acct type.
	 *
	 * @param fromAcctType the fromAcctType to set
	 */
	public void setFromAcctType(String fromAcctType) {
		this.fromAcctType = fromAcctType;
	}
	
	/**
	 * Gets the from acct currency cd.
	 *
	 * @return the fromAcctCurrencyCd
	 */
	public String getFromAcctCurrencyCd() {
		return fromAcctCurrencyCd;
	}
	
	/**
	 * Sets the from acct currency cd.
	 *
	 * @param fromAcctCurrencyCd the fromAcctCurrencyCd to set
	 */
	public void setFromAcctCurrencyCd(String fromAcctCurrencyCd) {
		this.fromAcctCurrencyCd = fromAcctCurrencyCd;
	}
	
	/**
	 * Gets the service type.
	 *
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}
	
	/**
	 * Sets the service type.
	 *
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	/**
	 * Gets the pmt amt.
	 *
	 * @return the pmtAmt
	 */
	public double getPmtAmt() {
		return pmtAmt;
	}
	
	/**
	 * Sets the pmt amt.
	 *
	 * @param pmtAmt the pmtAmt to set
	 */
	public void setPmtAmt(double pmtAmt) {
		this.pmtAmt = pmtAmt;
	}
	
	/**
	 * Gets the debit amt.
	 *
	 * @return the debitAmt
	 */
	public double getDebitAmt() {
		return debitAmt;
	}
	
	/**
	 * Sets the debit amt.
	 *
	 * @param debitAmt the debitAmt to set
	 */
	public void setDebitAmt(double debitAmt) {
		this.debitAmt = debitAmt;
	}
	
	/**
	 * Gets the exchg rate.
	 *
	 * @return the exchgRate
	 */
	public double getExchgRate() {
		return exchgRate;
	}
	
	/**
	 * Sets the exchg rate.
	 *
	 * @param exchgRate the exchgRate to set
	 */
	public void setExchgRate(double exchgRate) {
		this.exchgRate = exchgRate;
	}
	
	/**
	 * Gets the cost rate.
	 *
	 * @return the costRate
	 */
	public double getCostRate() {
		return costRate;
	}
	
	/**
	 * Sets the cost rate.
	 *
	 * @param costRate the costRate to set
	 */
	public void setCostRate(double costRate) {
		this.costRate = costRate;
	}
	
	/**
	 * Gets the cust rate.
	 *
	 * @return the custRate
	 */
	public double getCustRate() {
		return custRate;
	}
	
	/**
	 * Sets the cust rate.
	 *
	 * @param custRate the custRate to set
	 */
	public void setCustRate(double custRate) {
		this.custRate = custRate;
	}
	
	/**
	 * Gets the card pmt amt type.
	 *
	 * @return the cardPmtAmtType
	 */
	public String getCardPmtAmtType() {
		return cardPmtAmtType;
	}
	
	/**
	 * Sets the card pmt amt type.
	 *
	 * @param cardPmtAmtType the cardPmtAmtType to set
	 */
	public void setCardPmtAmtType(String cardPmtAmtType) {
		this.cardPmtAmtType = cardPmtAmtType;
	}
	
	/**
	 * Gets the pmt source.
	 *
	 * @return the pmtSource
	 */
	public String getPmtSource() {
		return pmtSource;
	}
	
	/**
	 * Sets the pmt source.
	 *
	 * @param pmtSource the pmtSource to set
	 */
	public void setPmtSource(String pmtSource) {
		this.pmtSource = pmtSource;
	}
	
	/**
	 * Gets the pmt ref.
	 *
	 * @return the pmtRef
	 */
	public String getPmtRef() {
		return pmtRef;
	}
	
	/**
	 * Sets the pmt ref.
	 *
	 * @param pmtRef the pmtRef to set
	 */
	public void setPmtRef(String pmtRef) {
		this.pmtRef = pmtRef;
	}
	
	/**
	 * Gets the processing mode.
	 *
	 * @return the processingMode
	 */
	public double getProcessingMode() {
		return processingMode;
	}
	
	/**
	 * Sets the processing mode.
	 *
	 * @param processingMode the processingMode to set
	 */
	public void setProcessingMode(double processingMode) {
		this.processingMode = processingMode;
	}
	
	/**
	 * Gets the dt pmt.
	 *
	 * @return the dtPmt
	 */
	public Date getDtPmt() {
		return dtPmt;
	}
	
	/**
	 * Sets the dt pmt.
	 *
	 * @param dtPmt the dtPmt to set
	 */
	public void setDtPmt(Date dtPmt) {
		this.dtPmt = dtPmt;
	}
	
	/**
	 * Gets the txn mode.
	 *
	 * @return the txnMode
	 */
	public String getTxnMode() {
		return txnMode;
	}
	
	/**
	 * Sets the txn mode.
	 *
	 * @param txnMode the txnMode to set
	 */
	public void setTxnMode(String txnMode) {
		this.txnMode = txnMode;
	}
	
	/**
	 * Gets the txn status cd.
	 *
	 * @return the txnStatusCd
	 */
	public String getTxnStatusCd() {
		return txnStatusCd;
	}
	
	/**
	 * Sets the txn status cd.
	 *
	 * @param txnStatusCd the txnStatusCd to set
	 */
	public void setTxnStatusCd(String txnStatusCd) {
		this.txnStatusCd = txnStatusCd;
	}
	
	/**
	 * Gets the txn type cd.
	 *
	 * @return the txnTypeCd
	 */
	public String getTxnTypeCd() {
		return txnTypeCd;
	}
	
	/**
	 * Sets the txn type cd.
	 *
	 * @param txnTypeCd the txnTypeCd to set
	 */
	public void setTxnTypeCd(String txnTypeCd) {
		this.txnTypeCd = txnTypeCd;
	}
	
	/**
	 * Gets the host txn ref no.
	 *
	 * @return the hostTxnRefNo
	 */
	public String getHostTxnRefNo() {
		return hostTxnRefNo;
	}
	
	/**
	 * Sets the host txn ref no.
	 *
	 * @param hostTxnRefNo the hostTxnRefNo to set
	 */
	public void setHostTxnRefNo(String hostTxnRefNo) {
		this.hostTxnRefNo = hostTxnRefNo;
	}
	
	/**
	 * Gets the host resp cd.
	 *
	 * @return the hostRespCd
	 */
	public String getHostRespCd() {
		return hostRespCd;
	}
	
	/**
	 * Sets the host resp cd.
	 *
	 * @param hostRespCd the hostRespCd to set
	 */
	public void setHostRespCd(String hostRespCd) {
		this.hostRespCd = hostRespCd;
	}
	
	/**
	 * Gets the host resp desc.
	 *
	 * @return the hostRespDesc
	 */
	public String getHostRespDesc() {
		return hostRespDesc;
	}
	
	/**
	 * Sets the host resp desc.
	 *
	 * @param hostRespDesc the hostRespDesc to set
	 */
	public void setHostRespDesc(String hostRespDesc) {
		this.hostRespDesc = hostRespDesc;
	}
	
	/**
	 * Gets the client ref no.
	 *
	 * @return the clientRefNo
	 */
	public String getClientRefNo() {
		return clientRefNo;
	}
	
	/**
	 * Sets the client ref no.
	 *
	 * @param clientRefNo the clientRefNo to set
	 */
	public void setClientRefNo(String clientRefNo) {
		this.clientRefNo = clientRefNo;
	}
	
	/**
	 * Gets the dt processed.
	 *
	 * @return the dtProcessed
	 */
	public Date getDtProcessed() {
		return dtProcessed;
	}
	
	/**
	 * Sets the dt processed.
	 *
	 * @param dtProcessed the dtProcessed to set
	 */
	public void setDtProcessed(Date dtProcessed) {
		this.dtProcessed = dtProcessed;
	}
	
	/**
	 * Gets the checks if is reg biller.
	 *
	 * @return the isRegBiller
	 */
	public char getIsRegBiller() {
		return isRegBiller;
	}
	
	/**
	 * Sets the checks if is reg biller.
	 *
	 * @param isRegBiller the isRegBiller to set
	 */
	public void setIsRegBiller(char isRegBiller) {
		this.isRegBiller = isRegBiller;
	}
	
	/**
	 * Gets the recurrence interval.
	 *
	 * @return the recurrenceInterval
	 */
	public String getRecurrenceInterval() {
		return recurrenceInterval;
	}
	
	/**
	 * Sets the recurrence interval.
	 *
	 * @param recurrenceInterval the recurrenceInterval to set
	 */
	public void setRecurrenceInterval(String recurrenceInterval) {
		this.recurrenceInterval = recurrenceInterval;
	}
	
	/**
	 * Gets the recurrence start dt.
	 *
	 * @return the recurrenceStartDt
	 */
	public Date getRecurrenceStartDt() {
		return recurrenceStartDt;
	}
	
	/**
	 * Sets the recurrence start dt.
	 *
	 * @param recurrenceStartDt the recurrenceStartDt to set
	 */
	public void setRecurrenceStartDt(Date recurrenceStartDt) {
		this.recurrenceStartDt = recurrenceStartDt;
	}
	
	/**
	 * Gets the recurrence end dt.
	 *
	 * @return the recurrenceEndDt
	 */
	public Date getRecurrenceEndDt() {
		return recurrenceEndDt;
	}
	
	/**
	 * Sets the recurrence end dt.
	 *
	 * @param recurrenceEndDt the recurrenceEndDt to set
	 */
	public void setRecurrenceEndDt(Date recurrenceEndDt) {
		this.recurrenceEndDt = recurrenceEndDt;
	}
	
	/**
	 * Gets the ctry cd.
	 *
	 * @return the ctryCd
	 */
	public String getCtryCd() {
		return ctryCd;
	}
	
	/**
	 * Sets the ctry cd.
	 *
	 * @param ctryCd the ctryCd to set
	 */
	public void setCtryCd(String ctryCd) {
		this.ctryCd = ctryCd;
	}
	
	/**
	 * Gets the dt created.
	 *
	 * @return the dtCreated
	 */
	public Date getDtCreated() {
		return dtCreated;
	}
	
	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the dtCreated to set
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	/**
	 * Gets the dt upd.
	 *
	 * @return the dtUpd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}
	
	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the dtUpd to set
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}
	
	/**
	 * Gets the upd by.
	 *
	 * @return the updBy
	 */
	public String getUpdBy() {
		return updBy;
	}
	
	/**
	 * Sets the upd by.
	 *
	 * @param updBy the updBy to set
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	
	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}
	
	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	
	/**
	 * Gets the dt next exec.
	 *
	 * @return the dtNextExec
	 */
	public Date getDtNextExec() {
		return dtNextExec;
	}
	
	/**
	 * Sets the dt next exec.
	 *
	 * @param dtNextExec the dtNextExec to set
	 */
	public void setDtNextExec(Date dtNextExec) {
		this.dtNextExec = dtNextExec;
	}
	
	/**
	 * Gets the biller trans type cd.
	 *
	 * @return the billerTransTypeCd
	 */
	public String getBillerTransTypeCd() {
		return billerTransTypeCd;
	}
	
	/**
	 * Sets the biller trans type cd.
	 *
	 * @param billerTransTypeCd the billerTransTypeCd to set
	 */
	public void setBillerTransTypeCd(String billerTransTypeCd) {
		this.billerTransTypeCd = billerTransTypeCd;
	}
	
	/**
	 * Gets the card acct no.
	 *
	 * @return the cardAcctNo
	 */
	public String getCardAcctNo() {
		return cardAcctNo;
	}
	
	/**
	 * Sets the card acct no.
	 *
	 * @param cardAcctNo the cardAcctNo to set
	 */
	public void setCardAcctNo(String cardAcctNo) {
		this.cardAcctNo = cardAcctNo;
	}
	
	/**
	 * Gets the card acct type.
	 *
	 * @return the cardAcctType
	 */
	public String getCardAcctType() {
		return cardAcctType;
	}
	
	/**
	 * Sets the card acct type.
	 *
	 * @param cardAcctType the cardAcctType to set
	 */
	public void setCardAcctType(String cardAcctType) {
		this.cardAcctType = cardAcctType;
	}
	
	/**
	 * Gets the card acct currency cd.
	 *
	 * @return the cardAcctCurrencyCd
	 */
	public String getCardAcctCurrencyCd() {
		return cardAcctCurrencyCd;
	}
	
	/**
	 * Sets the card acct currency cd.
	 *
	 * @param cardAcctCurrencyCd the cardAcctCurrencyCd to set
	 */
	public void setCardAcctCurrencyCd(String cardAcctCurrencyCd) {
		this.cardAcctCurrencyCd = cardAcctCurrencyCd;
	}
}
