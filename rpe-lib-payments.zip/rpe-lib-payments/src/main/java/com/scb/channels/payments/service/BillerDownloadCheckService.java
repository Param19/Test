package com.scb.channels.payments.service;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;

public interface BillerDownloadCheckService {
	
	
	
	public Boolean isActiverBillerCategoriesAvailable(String Country)throws BusinessException;
	
	
	public void intialBillersfromAggregator(PayloadDTO bean);
	public void compareMasterAndAggragtorBiller(PayloadDTO bean);
	public void updatePayeesOnceDownloadDone(String country);
	
	
	
}