package com.scb.channels.payments.helper;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
 
public class JetcoPayPaymentHelper {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(JetcoPayPaymentHelper.class);
	
	/**
	 * Format payment amount for HOGAN request
	 * 
	 * @param amount
	 * @return
	 */
	public static String getFormatPaymentAmount4Hogan(Double amount) {
		DecimalFormat decimalFormat = new DecimalFormat("#.00");
		decimalFormat.setRoundingMode(RoundingMode.DOWN);
		String stringAmount = decimalFormat.format(amount);
		return Arrays.asList(stringAmount.split(Pattern.quote(CommonConstants.DOT))).get(0)
				+ Arrays.asList(stringAmount.split(Pattern.quote(CommonConstants.DOT))).get(1);
	}

	/**
	 * Format payment amount for JETCO request
	 * 
	 * @param amount
	 * @return
	 */
	public static String getFormatPaymentAmount(Double amount) {
		DecimalFormat decimalFormat = new DecimalFormat("#.00");
		decimalFormat.setRoundingMode(RoundingMode.DOWN);
		return decimalFormat.format(amount);
	}

	/**
	 * convert to XMLGregorianCalendar without parameter
	 * 
	 * @return
	 */
	public static XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
			LOGGER.error(e.getMessage());
		}
		return date;
	}

	/**
	 * convert to XMLGregorianCalendar with parameter
	 * 
	 * @param format
	 * @return
	 */
	public static XMLGregorianCalendar getFormatGregorianCalendar(String format) {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(new SimpleDateFormat(format).format(c.getTime()));
		} catch (DatatypeConfigurationException e) {
			LOGGER.error(e.getMessage());
		}
		return date;
	}

	/**
	 * convert to XMLGregorianCalendar with parameter
	 * 
	 * @param format
	 * @return
	 */
	public static XMLGregorianCalendar getFormatGregorianCalendar(String strDate, String format) {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(strDate);
		} catch (DatatypeConfigurationException e) {
			LOGGER.error(e.getMessage());
		}
		return date;
	}

	/**
	 * Populate JETCO Pay response
	 * 
	 * @param request
	 * @param response
	 */
	public static void populateJetcoPayResponse(JetcoPayRequestVO request) {
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();

		user.setCustomerId(request.getUser().getCustomerId() != null ? request.getUser().getCustomerId() : CommonConstants.EMPTY);
		user.setCustomerType(request.getUser().getCustomerType() != null ? request.getUser().getCustomerType() : CommonConstants.EMPTY);
		user.setCountry(CommonConstants.HK_COUNTRY_CODE);
		user.setChannelId(request.getClientVO().getChannel() != null ? request.getClientVO().getChannel() : CommonConstants.EMPTY);
		service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
		service.setServiceName(CommonConstants.JETCO_PAY);
		service.setServiceTxnType(CommonConstants.JETCO_TRANSACTION_DEBIT);
		message.setReqID(request.getMessageVO().getReqID());
		message.setRequestCode(request.getBankMessageId());
		message.setCorrelationId(request.getBankMessageId());
		client.setChannel(request.getClientVO().getChannel() != null ? request.getClientVO().getChannel() : CommonConstants.EMPTY);
		client.setCountry(CommonConstants.HK_COUNTRY_CODE);
		client.setPartnerName(CommonConstants.JETCO);
		client.setPartnerType(CommonConstants.JETCO_PAY_TYPE);

		request.setUser(user);
		request.setClientVO(client);
		request.setMessageVO(message);
		request.setServiceVO(service);
	}
}
