package com.scb.channels.payments.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.net.ntp.TimeStamp;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerFieldItemVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayeeFieldDetailsVO;
import com.scb.channels.base.vo.PayeeFieldDetailsView;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.base.vo.ViewPayeeVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.dao.PayeeManagementDAO;
import com.scb.channels.payments.service.PayeeManagementService;


/**
 * @author 1521723
 * 
 */
public class PayeeManagementServiceImpl implements PayeeManagementService {

	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PayeeManagementServiceImpl.class);

	/**
	 * payeeDAO
	 */
	private PayeeManagementDAO payeeDAO;
	
	/**
	 * dataBean
	 */
	private DataBean dataBean;
	/**
	 * @return
	 */
	public PayeeManagementDAO getPayeeDAO() {
		return payeeDAO;
	}

	/**
	 * @param payeeDAO
	 */
	public void setPayeeDAO(PayeeManagementDAO payeeDAO) {
		this.payeeDAO = payeeDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.service.PayeeManagementService#addPayee(com
	 * .scb.channels.base.vo.BillerPayRequestVO)
	 */
	@Override
	public BillerPayResponseVO addPayee(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: addPayee :: START :: NEW"+billerPayRequestVO.getMessageVO().getReqID());
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		setPayeeType(payee);
		//payee.getBillerVO().setId(payeeDAO.getUniqueBillerId(payee.getBillerCode()));
		payeeDAO.savePayee(payee);
		//Added to get the status of the savePayee method
		if(CommonConstants.STATUS_ACTIVE.equalsIgnoreCase(payee.getStatus())){
		response = new BillerPayResponseVO();
		response.setStatus(Messages._304.getCode());
		response.setStatusDesc(Messages._304.getMessage());
		}
		LOGGER.info("PayeeManagementServiceImpl :: addPayee :: END :: NEW");
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.service.PayeeManagementService#checkIsPayeeExists
	 * (com.scb.channels.base.vo.BillerPayRequestVO)
	 */
	@Override
	public BillerPayResponseVO checkIsPayeeExists(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: checkIsPayeeExists :: START :: NEW");
		BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		LOGGER.info("Biller adding into DB  new changes {}-{}-{}-{}", new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(),
				billerPayDetails.getUtilltyTypeDesc() });
		   setPayeeType(payee);

	    List<ViewPayeeVO> payeeDetailVO = payeeDAO.viewPayeeListFromView(billerPayRequestVO.getUser());
		BillerVO billerVO =payeeDAO.getUniqueBillerId(payee.getBillerCode(),payee.getCountryCode());
		
		billerPayRequestVO.getBillerPayDetailsVO().setUniqueId(billerVO.getId());
		billerPayRequestVO.getBillerPayDetailsVO().setAggId(billerVO.getBillerId());
		billerPayRequestVO.getBillerPayDetailsVO().setPresentMentType(billerVO.getBillPresentmentType());
		if (payeeDetailVO != null) {
			LOGGER.info("payeeDetailVO is not null");
			for (ViewPayeeVO payeeDetailsVO : payeeDetailVO) {
				if (payeeDetailsVO.getBillerUniqueId().equals(payee.getBillerCode()) && payeeDetailsVO.getConsumerNumber().equals(payee.getConsumerNumber())) {

					LOGGER.info("Consume number and Biller Code is equal --------------------------");
					response = new BillerPayResponseVO();
					response.setStatus(Messages._308.getCode());
					response.setStatusDesc(Messages._308.getMessage());

					response.setErrorCD(Messages._308.getCode());
					response.setErrorDesc(Messages._308.getMessage());
					break;
				}
				if (payee.getPayeeShortName() != null && !payee.getPayeeShortName().isEmpty()) {
					if(payeeDetailsVO.getPayeeShortName() !=null && !payeeDetailsVO.getPayeeShortName().isEmpty()){
					if (payeeDetailsVO.getPayeeShortName().equals(payee.getPayeeShortName())) {

						LOGGER.info("PayeeShortName is equal --------------------------");
						response = new BillerPayResponseVO();
						response.setStatus(Messages._310.getCode());
						response.setStatusDesc(Messages._310.getMessage());

						response.setErrorCD(Messages._310.getCode());
						response.setErrorDesc(Messages._310.getMessage());
						break;
					}

				}
				}
			}

		}
		LOGGER.info("PayeeManagementServiceImpl :: checkIsPayeeExists :: ENDDDDDD :: NEW");
		return response;
	}
	
	
		
	

	private void setPayeeType(PayeeDetailVO payee) {
		//Need to add depends on condition
			payee.setPayeeType(CommonConstants.REGISTERED_USER);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.service.PayeeManagementService#deletePayee(
	 * com.scb.channels.base.vo.BillerPayRequestVO)
	 */
	@Override
	public BillerPayResponseVO deletePayee(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: deletePayee :: START ");
		BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getDeletePayeeserviceMapping(billerPayRequestVO);
		payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_DELETED);
		LOGGER.info("payee Deleting from DB  {}-{}-{}-{}",
				new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(), billerPayDetails.getUtilltyTypeDesc() });
		try {
			/*boolean checkIfAnyInprocessPayments=checkIfAnyInprocessPayments(billerPayRequestVO);
			if(checkIfAnyInprocessPayments){
				response = new BillerPayResponseVO();
				response.setStatus(ExceptionMessages._146.getCode());
				response.setStatusDesc(ExceptionMessages._146.getMessage());	
				return response;
			}
			LOGGER.info("PayeeManagementServiceImpl :: deletePayee ::  checkIfAnyInprocessPayments ::"+checkIfAnyInprocessPayments);*/
			if (payeeDAO.deletePayee(payee)) {
				LOGGER.info("PayeeManagementServiceImpl ::deletePayee :: Payee deleted succesfully" );
				response = new BillerPayResponseVO();
				response.setStatus(Messages._305.getCode());
				response.setStatusDesc(Messages._305.getMessage());
			} 
		} catch (Exception e) {
			LOGGER.info("payeemanagmentServce Error" , e);
		}
		LOGGER.info("PayeeManagementServiceImpl :: deletePayee :: END ");
		return response;
	}

	
/*	@Override
	public ViewPayeeResponseVO viewPayeeList(ViewPayeeRequestVO viewPayeeRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList :: START ");
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeResponseVO = new ViewPayeeResponseVO();
			List<PayeeDetailVO> listPayeeDetailVO = payeeDAO.viewPayeeList(viewPayeeRequestVO.getUser());
			if(CollectionUtils.isEmpty(listPayeeDetailVO)){
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList ::Empty List From DB ");
				viewPayeeResponseVO.setListPayeeDetailVO(listPayeeDetailVO);
			}else{
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList :: Value List From DB ");
				List<PayeeDetailVO> listPayeeDetailFromDB=new ArrayList<PayeeDetailVO>();
				
			for(PayeeDetailVO payeeDetailVO : listPayeeDetailVO){
				BillerVO biller  = payeeDetailVO.getBillerVO();
				if(biller.getStatusCode().equalsIgnoreCase(CommonConstants.D)){
					payeeDetailVO.setStatus(CommonConstants.P);
					listPayeeDetailFromDB.add(payeeDetailVO);
				}else{
					listPayeeDetailFromDB.add(payeeDetailVO);
				}
			}
			viewPayeeResponseVO.setListPayeeDetailVO(listPayeeDetailFromDB);
			}
		
		} catch (Exception e) {
			LOGGER.info("payeemanagmentServce Error" + e.getMessage());
		}
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList :: END ");
		return viewPayeeResponseVO;
	}*/

	// View Payee view is not working so commented out
	@Override
	public ViewPayeeResponseVO viewPayeeList(ViewPayeeRequestVO viewPayeeRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList :: START ");
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeResponseVO = new ViewPayeeResponseVO();
			List<ViewPayeeVO> listViewPayeeVO = payeeDAO.viewPayeeListFromView(viewPayeeRequestVO.getUser());
			if(listViewPayeeVO.isEmpty()){
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList ::Empty List From DB ");
				viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
			}else{
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList ::Values List From DB ");
				viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
			}
		
		} catch (Exception e) {
			LOGGER.info("payeemanagmentServce Error" , e);
		}
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeList :: END ");
		return viewPayeeResponseVO;
	}
	
	@Override
	public ViewPayeeResponseVO viewPayeeListHK(ViewPayeeRequestVO viewPayeeRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListHK :: START ");
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeResponseVO = new ViewPayeeResponseVO();
			List<ViewPayeeVO> listViewPayeeVO = payeeDAO.viewPayeeListFromViewHK(viewPayeeRequestVO);
			if(listViewPayeeVO.isEmpty()){
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListHk ::Empty List From DB ");
				viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
			}else{
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListHK ::Values List From DB ");
				viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
			}
		
		} catch (Exception e) {
			LOGGER.info("payeemanagmentServceHK Error" + e.getMessage());
			LOGGER.info("payeemanagmentServceHK Error" , e);
		}
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListHK :: END ");
		return viewPayeeResponseVO;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.PayeeManagementService#validatePayee(com.scb.channels.base.vo.BillerPayRequestVO)
	 */
	@Override
	public BillerPayResponseVO validatePayee(BillerPayRequestVO billerPayRequestVO) throws Exception{
		LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: START");
		BillerPayResponseVO response = null;
		//Calendar cal = DateUtils.getCountryCalendar();
		//Timestamp currentTime = new Timestamp(cal.getTime().getTime());
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		setPayeeType(payee);
		List<ViewPayeeVO> listFromDB = payeeDAO.getPayeeList(payee);
				
		/*Validation for Alipay Wallet Start */
         
		if (!listFromDB.isEmpty()) {
			 LOGGER.info("Payee list is not empty "+listFromDB.size());
			int maxPayeeAllowedCnt=0;
	         int maxPayeeAllowedPerDay=0;
			for (ViewPayeeVO payeeDetails : listFromDB) {
					++maxPayeeAllowedCnt;
				if (DateUtils.isSameDay(payeeDetails.getRegistrationTime(),payee.getCreatedTime())) {
					++maxPayeeAllowedPerDay;
					}
			}

			/*  Total number of payees allowed under Mobile Wallets = 40 payees*/
			if (maxPayeeAllowedCnt >= CommonConstants.MAXIMUM_PAYEE_ALLOWED_ALIPAY_WALLET) {
					LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: MORE THAN MAX LIMIT  :: "+listFromDB.size());
					response = new BillerPayResponseVO();
					response.setErrorDesc(ExceptionMessages._162.getMessage());
					response.setErrorCD(ExceptionMessages._162.getCode());
					response.setStatus(Messages._1.getCode());
					response.setStatusDesc(Messages._1.getMessage());
					return response;
			} else if (maxPayeeAllowedPerDay >= CommonConstants.MAXIMUM_PAYEE_ALLOWED_PER_DAY) {
				    LOGGER.info("MAXIMUM_PAYEE_ALLOWED_PER_DAY Voilated "+maxPayeeAllowedPerDay);
					response = new BillerPayResponseVO();
					response.setErrorDesc(ExceptionMessages._163.getMessage());
					response.setErrorCD(ExceptionMessages._163.getCode());
					response.setStatus(Messages._1.getCode());
					response.setStatusDesc(Messages._1.getMessage());
					return response;
			}
			for (ViewPayeeVO payeeDetails : listFromDB) {
				if (payeeDetails.getStatus().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)) {
					if (payeeDetails.getBillerUniqueId().equals(payee.getBillerCode())
							&& payeeDetails.getConsumerNumber().equals(payee.getConsumerNumber())) {
						LOGGER.info("Biller Code is equal, Existing is " + payeeDetails.getBillerUniqueId() + "New is " + payee.getBillerCode());
						LOGGER.info("Consumer number  is equal, Existing is " + payeeDetails.getConsumerNumber() + "New is "
								+ payee.getConsumerNumber());
						response = new BillerPayResponseVO();
						response.setStatus(Messages._1.getCode());
						response.setStatusDesc(Messages._1.getMessage());
						response.setErrorCD(Messages._308.getCode());
						response.setErrorDesc(Messages._308.getMessage());
						return response;
					}
					if (payee.getPayeeShortName() != null && !payee.getPayeeShortName().isEmpty()) {
						if (payeeDetails.getPayeeShortName() != null && !payeeDetails.getPayeeShortName().isEmpty()) {
							if (payeeDetails.getPayeeShortName().equals(payee.getPayeeShortName())) {
								LOGGER.info("PayeeShortName is equal APAY Existing is ::" + payeeDetails.getPayeeShortName() + "New is "
										+ payee.getPayeeShortName());
								response = new BillerPayResponseVO();
								response.setStatus(Messages._1.getCode());
								response.setStatusDesc(Messages._1.getMessage());
								response.setErrorCD(Messages._310.getCode());
								response.setErrorDesc(Messages._310.getMessage());
								return response;
							}

						}
					}
				}
		  }
		}
        BillerVO billerVO =payeeDAO.getUniqueBillerIdHK(payee.getBillerCode(),payee.getCountryCode());
        LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: Biller unique details fetch done");
        if(billerVO!=null){
        payee.getBillerVO().setId(billerVO.getId());
        payee.getBillerVO().setBillerId(billerVO.getBillerId());
        }else{
        	response = new BillerPayResponseVO();
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setErrorCD(ExceptionMessages._164.getCode());
			response.setErrorDesc(ExceptionMessages._164.getMessage());
			return response;
        }
        payee.setStatus(CommonConstants.STATUS_NEW);
        payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_NEW);
        if(payeeDAO.updatePayeeIfExists(payee).equalsIgnoreCase("NOT_EXISTS")){
        LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: No record found inserting record");	
        if(!payeeDAO.savePayeeHK(payee)){
        	response = new BillerPayResponseVO();
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setErrorCD(ExceptionMessages._164.getCode());
			response.setErrorDesc(ExceptionMessages._164.getMessage());
			return response;
        }
        LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: Row inserted");
        }else if(payeeDAO.updatePayeeIfExists(payee).equalsIgnoreCase("EXCEPTION")){
        	LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: Exception in updatePayeeIfExists");
        	throw new Exception(); 
        }
		LOGGER.info("PayeeManagementServiceImpl :: validatePayee :: END");
		BillerPayDetailsVO billerPayDetailsVO=new BillerPayDetailsVO();
		response = new BillerPayResponseVO();
		response.setStatus(Messages._0.getCode());
		response.setStatusDesc(Messages._0.getMessage());
		billerPayDetailsVO.setPayeeId(payee.getPayeeId().toString());
		response.setBillerPayDetailsVO(billerPayDetailsVO);
		return response;
	}
	
	public BillerPayResponseVO checkIsPayeeExistsHK(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: checkIsPayeeExists :APAY: START :: NEW");
		BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		LOGGER.info("Biller adding into DB  APAY new changes {}-{}-{}-{}", new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(),
				billerPayDetails.getUtilltyTypeDesc() });
		   setPayeeType(payee);

		   /*Required only active payee so used africa view*/
	    List<ViewPayeeVO> payeeDetailVO = payeeDAO.viewPayeeListFromView(billerPayRequestVO.getUser());
		BillerVO billerVO =payeeDAO.getUniqueBillerIdHK(payee.getBillerCode(),payee.getCountryCode());
		
		billerPayRequestVO.getBillerPayDetailsVO().setUniqueId(billerVO.getId());
		billerPayRequestVO.getBillerPayDetailsVO().setAggId(billerVO.getBillerId());
		billerPayRequestVO.getBillerPayDetailsVO().setPresentMentType(billerVO.getBillPresentmentType());
		if (payeeDetailVO != null) {
			LOGGER.info("payeeDetailVO is APAY not null");
			for (ViewPayeeVO payeeDetailsVO : payeeDetailVO) {
				if (payeeDetailsVO.getBillerUniqueId().equals(payee.getBillerCode()) && payeeDetailsVO.getConsumerNumber().equals(payee.getConsumerNumber())) {

					LOGGER.info("Consume number and APAY Biller Code is equal --------------------------");
					response = new BillerPayResponseVO();
					response.setStatus(Messages._308.getCode());
					response.setStatusDesc(Messages._308.getMessage());

					response.setErrorCD(Messages._308.getCode());
					response.setErrorDesc(Messages._308.getMessage());
					break;
				}
				if (payee.getPayeeShortName() != null && !payee.getPayeeShortName().isEmpty()) {
					if(payeeDetailsVO.getPayeeShortName() !=null && !payeeDetailsVO.getPayeeShortName().isEmpty()){
					if (payeeDetailsVO.getPayeeShortName().equals(payee.getPayeeShortName())) {

						LOGGER.info("PayeeShortName is equal APAY--------------------------");
						response = new BillerPayResponseVO();
						response.setStatus(Messages._310.getCode());
						response.setStatusDesc(Messages._310.getMessage());

						response.setErrorCD(Messages._310.getCode());
						response.setErrorDesc(Messages._310.getMessage());
						break;
					}

				}
				}
			}

		}
		LOGGER.info("PayeeManagementServiceImpl :APAY: checkIsPayeeExists :: ENDDDDDD :: NEW");
		return response;
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PayeeDetailVO payee = new PayeeDetailVO();
		PayeeDetailVO payee1 = new PayeeDetailVO();
		PayeeDetailVO payee2 = new PayeeDetailVO();
		Calendar cal= DateUtils.getCountryCalendar();
		 Timestamp updatedTimeStamp = new Timestamp(cal.getTime().getTime());
	System.out.println("cal -- > "+cal.getTime());
	payee.setCreatedTime(updatedTimeStamp);
	Calendar calendar = DateUtils.getCountryCalendar();
	calendar.add(Calendar.HOUR, -29);
	Timestamp updatedTimeStamp1 = new Timestamp(calendar.getTime().getTime());
	payee1.setCreatedTime(updatedTimeStamp1);
	
	Calendar calendar1 = DateUtils.getCountryCalendar();
	calendar1.add(Calendar.HOUR, 8);
	Timestamp updatedTimeStamp2 = new Timestamp(calendar1.getTime().getTime());
	payee2.setCreatedTime(updatedTimeStamp2);
	Calendar current = DateUtils.getCountryCalendar();
	System.out.println("cal payee   -- "+ payee.getCreatedTime() );
	System.out.println("cal payee 1 -- "+ payee1.getCreatedTime() );
	System.out.println("cal payee 2 -- "+ payee2.getCreatedTime() );
	System.out.println("current-- "+ current.getTime() );
	Timestamp curTimestamp= new Timestamp(current.getTime().getTime());
	if(DateUtils.isSameDay(payee1.getCreatedTime(),curTimestamp)){
		System.out.println("equalssssssssss" );	
	}else{
		System.out.println("elseeeeeeeeeeeeeeeeee");
	}
	
	
	List<PayeeDetailVO> sameDayPayeeCheckList = new ArrayList<PayeeDetailVO>();
	Calendar ca = DateUtils.getCountryCalendar();
	Timestamp currentTime = new Timestamp(ca.getTime().getTime());
	
	List<PayeeDetailVO> listFromDB = new ArrayList<PayeeDetailVO>();
	
	listFromDB.add(payee);
	listFromDB.add(payee1);
	listFromDB.add(payee2);
	System.out.println("listFromDB size -- > "+listFromDB.size());
	
	if(!listFromDB.isEmpty()){
		if(listFromDB.size() >=4){
		System.out.println("error exceeds 40");
		}else {
			for(PayeeDetailVO payeeDetail : listFromDB){
			if(DateUtils.isSameDay(payeeDetail.getCreatedTime(),currentTime)){
				sameDayPayeeCheckList.add(payeeDetail);
			}
			}
			System.out.println("sameDayPayeeCheckList size --- > "+sameDayPayeeCheckList.size());
			if (!sameDayPayeeCheckList. isEmpty() && sameDayPayeeCheckList.size() > 2){
				
			}
	}
	}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.service.PayeeManagementService#addPayee(com
	 * .scb.channels.base.vo.BillerPayRequestVO)
	 
	@Override
	public BillerPayResponseVO addPayeeHK(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: addPayee :: START :: NEW");
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		setPayeeType(payee);
		//payee.getBillerVO().setId(payeeDAO.getUniqueBillerId(payee.getBillerCode()));
		payeeDAO.savePayee(payee);
		//Added to get the status of the savePayee method
		if(CommonConstants.STATUS_ACTIVE.equalsIgnoreCase(payee.getStatus())){
		response = new BillerPayResponseVO();
		response.setStatus(Messages._304.getCode());
		response.setStatusDesc(Messages._304.getMessage());
		}
		LOGGER.info("PayeeManagementServiceImpl :: addPayee :: END :: NEW");
		return response;
	}
	*/
	@Override
	public BillerPayResponseVO updatePayee(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: addPayee :: START :: NEW");
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_ACTIVE);
		payee.setStatus(CommonConstants.ACTIVE);
		setPayeeType(payee);
		if(payeeDAO.updatePayeeIfExists(payee).equalsIgnoreCase(CommonConstants.PAYEE_ENTRY_FOUND)){
			LOGGER.info("PayeeManagementServiceImpl :: updatePayee :: START");
			response = new BillerPayResponseVO();
			response.setStatus(Messages._0.getCode());
			response.setStatusDesc(Messages._0.getMessage());
			response.setStatus(Messages._304.getCode());
			response.setStatusDesc(Messages._304.getMessage());
			//response.setErrorCD(Messages._304.getCode());
			//response.setErrorDesc(Messages._304.getMessage());
		}else{
			response = new BillerPayResponseVO();
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setStatus(ExceptionMessages._144.getCode());
			response.setStatusDesc(ExceptionMessages._144.getMessage());
			//response.setErrorCD(ExceptionMessages._144.getCode());
			//response.setErrorDesc(ExceptionMessages._144.getMessage());	
		}
		LOGGER.info("PayeeManagementServiceImpl :: updatePayee :: END");
		return response;
	}

	@Override
	public boolean updatePayeeStatus(PayeeDetailVO payeeDetailsVO) {
		// TODO Auto-generated method stub
		return payeeDAO.updatePayeeStatus(payeeDetailsVO);
	}

	@Override
	public boolean terminateInactivePayee(String countryCode) {
		// TODO Auto-generated method stub
		return payeeDAO.saveTerminateInactivePayee(countryCode);
	}
	
	@Override
	public void addPayeeCS(PayloadDTO bean) {
		LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: START :: NEW"+bean.getRequestVO().getMessageVO().getReqID());
		boolean isFieldExists=false;
		boolean isPrimaryFiledExists=false;
		BillerPayResponseVO billerPayResponseVO = null ;
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
		bean.setResponseVO(billerPayResponseVO);
	    PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
	    for(PayeeFieldDetailsVO payeeFieldDetailsVO: payee.getPayeeFieldDetails()){
	    	isPrimaryFiledExists = setConsumerNumber(bean, isPrimaryFiledExists, payee, payeeFieldDetailsVO);
	    	payeeFieldDetailsVO.setPayeeDetailVO(payee);
	    	payeeFieldDetailsVO.setRemarks(payeeFieldDetailsVO.getFieldDataType());
	    	payeeFieldDetailsVO.setStatus(CommonConstants.STATUS_ACTIVE);
	    	payeeFieldDetailsVO.setDateCreated(payee.getCreatedTime());
	    	payeeFieldDetailsVO.setDateUpdated(payee.getUpdateTime());
	    	payeeFieldDetailsVO.setCreatedBy(payee.getCreatedBy());
	    	payeeFieldDetailsVO.setUpdatedBy(payee.getUpdatedBy());
	    	payeeFieldDetailsVO.setVersion(CommonConstants.ZERO_INT);
	    	
	    	// field id and field label name synch --Start
	    	isFieldExists = false;
	    	String labelName =payeeFieldDetailsVO.getFieldLabelName().trim();
	    	for(BillerField billerField : billerPayRequestVO.getBillerPayDetailsVO().getFieldsFromDB()){
	    		String labelNameDB=billerField.getFieldLabelName().trim();
	    		switch(billerPayRequestVO.getBillerPayDetailsVO().getPresentMentType()){
	    		case CommonConstants.ZERO://This case for only paybill scenarios
	    			if (labelName.equalsIgnoreCase(labelNameDB) 
	    					&& billerField.getFieldType().equalsIgnoreCase(CommonConstants.P) 
	    					&&payeeFieldDetailsVO.getFieldType().equalsIgnoreCase(CommonConstants.P)) {
						setFieldIdandFiledValue(bean, payeeFieldDetailsVO, billerField);
						isFieldExists = true;
					}
	    			break;
	    		default://This case is name,responsse,paybill field scenarios
	    			if (labelName.equalsIgnoreCase(labelNameDB)  
	    					&& billerField.getFieldType().equalsIgnoreCase(CommonConstants.N) &&
	    					payeeFieldDetailsVO.getFieldType().equalsIgnoreCase(CommonConstants.N)) {
						setFieldIdandFiledValue(bean, payeeFieldDetailsVO, billerField);
						isFieldExists = true;
					}
	    		}
				
	    	}
	    	// field id and field label name synch --End
	    	
	    	if(!isFieldExists){
	    		billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._165.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._165.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
				bean.setResponseVO(billerPayResponseVO);
	    		LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: Field not exists :: " +labelName+" "+payee.getCustomerId());
	    		return;
	    	}
	    }
	    
	    if(!isPrimaryFiledExists){
    		billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._166.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._166.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			bean.setResponseVO(billerPayResponseVO);
    		LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: Primary Field not exists :: ");
    		return;	
    	}
		payee.setStatus(CommonConstants.STATUS_ACTIVE);
		setPayeeType(payee);
		LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS ::  getServiceTxnType "+billerPayRequestVO.getServiceVO().getServiceTxnType());
		if(billerPayRequestVO.getServiceVO().getServiceTxnType().equalsIgnoreCase(CommonConstants.UPDATE)){
		callPayeeUpateProcessCS(payee);}
		else{
			payee.setPayeeId(null);	
		}
		 payee.setIsUpdateRequired(CommonConstants.STRING_NO);
		 payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_ACTIVE);
		 
		 LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: before Save "
		 +bean.getRequestVO().getMessageVO().getReqID()
		 +" getCustomerId "+payee.getCustomerId()
		 +" getBillerUniqueId "+payee.getBillerVO().getBillerUniqueId()
		 +" getCountryCode "+payee.getCountryCode()
		 +" getChannelId "+payee.getChannelId()
		 +" getReferenceNumber "+payee.getReferenceNumber()
		 +" getStatus "+payee.getStatus()
		 +" getCreatedBy "+payee.getCreatedBy()
		 +" getCreatedTime "+payee.getCreatedTime()
		 +" getUpdatedBy "+payee.getUpdatedBy()
		 +" getUpdateTime "+payee.getUpdateTime()
		 +" getVersion "+payee.getVersion()
		 +" getConsumerNumber "+payee.getConsumerNumber()
		 +" getPayeeType "+payee.getPayeeType()
		 +" getIsUpdateRequired "+payee.getIsUpdateRequired());
		 
		 payeeDAO.savePayeeCS(payee);
		if(CommonConstants.STATUS_ACTIVE.equalsIgnoreCase(payee.getStatus())){
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setStatus(Messages._0.getCode());
			billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
			billerPayResponseVO.setErrorCD(Messages._304.getCode());
			billerPayResponseVO.setErrorDesc(Messages._304.getMessage());
			bean.setResponseVO(billerPayResponseVO);
			}

		LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: end "+bean.getRequestVO().getMessageVO().getReqID());
		}

	/**
	 * @param bean
	 * @param payeeFieldDetailsVO
	 * @param billerField
	 */
	private void setFieldIdandFiledValue(PayloadDTO bean, PayeeFieldDetailsVO payeeFieldDetailsVO, BillerField billerField) {
		switch (payeeFieldDetailsVO.getFieldDataType()) {
		case CommonConstants.FIELD_DATETYPE_LIST:
			for (BillerFieldItemVO item : payeeFieldDetailsVO.getPayeeFieldItems()){
				LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: List type "+bean.getRequestVO().getMessageVO().getReqID());
			//	payeeFieldDetailsVO.setFieldValue(item.getId().toString());
			    payeeFieldDetailsVO.setFieldId(billerField.getId());
				payeeFieldDetailsVO.setFieldValue(payeeFieldDetailsVO.getFieldValue());
			    break;
			}
			break;
		default:
			payeeFieldDetailsVO.setFieldId(billerField.getId());
			payeeFieldDetailsVO.setFieldValue(payeeFieldDetailsVO.getFieldValue());
		}
	}

	/**
	 * @param bean
	 * @param isPrimaryFiledExists
	 * @param payee
	 * @param payeeFieldDetailsVO
	 * @return
	 */
	private boolean setConsumerNumber(PayloadDTO bean, boolean isPrimaryFiledExists, PayeeDetailVO payee, PayeeFieldDetailsVO payeeFieldDetailsVO) {
		if(payeeFieldDetailsVO.getOrderSequence()==CommonConstants.ONE_INT){
			if(payeeFieldDetailsVO.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
				for (BillerFieldItemVO item : payeeFieldDetailsVO.getPayeeFieldItems()){
					LOGGER.info("PayeeManagementServiceImpl :: addPayeeCS :: List type "+bean.getRequestVO().getMessageVO().getReqID());
					//payee.setConsumerNumber(item.getId());
					payee.setConsumerNumber(payeeFieldDetailsVO.getFieldValue());
				}
			}
			else
				payee.setConsumerNumber(payeeFieldDetailsVO.getFieldValue());	
			isPrimaryFiledExists=true;
		}
		return isPrimaryFiledExists;
	}

	/**
	 * @param payee
	 */
	private void callPayeeUpateProcessCS(PayeeDetailVO payee) {
		LOGGER.info("PayeeManagementServiceImpl :: callPayeeUpateProcess :: start " + payee.getReferenceNumber());
		List<PayeeFieldDetailsView> listPayeeFieldDetailsVO = null;
		Set<PayeeFieldDetailsVO> updatePayeeFieldDetailsVOList = new HashSet<PayeeFieldDetailsVO>();
		boolean isItOldField = false;
		 listPayeeFieldDetailsVO=payeeDAO.getPayeeFieldsCS(payee);
		// PayeeDetailVO payee = BillpaymentMappingHelper.getPayeeFieldserviceMapping(listPayeeFieldDetailsVO);
		// one field is there , but new field has come, need to disable the
		// existing and add new field.
		// one field is there, along with new fields identified
		// three fields is there, now only two existing fields has come
		//
		//This for loop will handle New and update scenarios
		for (PayeeFieldDetailsVO payeeFieldDetailsVO : payee.getPayeeFieldDetails()) {
			isItOldField = false;
			String fieldLabel = payeeFieldDetailsVO.getFieldLabelName().trim();
			for (PayeeFieldDetailsView payeeFieldDetailsView : listPayeeFieldDetailsVO) {
				String fieldLabelDB = payeeFieldDetailsView.getFieldLabelName().trim();
				if (fieldLabelDB.equalsIgnoreCase(fieldLabel) && payeeFieldDetailsView.getFieldType().equalsIgnoreCase(payeeFieldDetailsVO.getFieldType())) {
					PayeeFieldDetailsVO payeeFieldDetailsDB=new  PayeeFieldDetailsVO();
					isItOldField = true;
					payeeFieldDetailsDB.setPayeeDetailVO(payee);
					payeeFieldDetailsDB.setFieldId(payeeFieldDetailsVO.getFieldId());
					payeeFieldDetailsDB.setId(payeeFieldDetailsView.getPayeeFieldId());
					payeeFieldDetailsDB.setFieldValue(payeeFieldDetailsVO.getFieldValue());
					payeeFieldDetailsDB.setRemarks(payeeFieldDetailsVO.getFieldDataType());
					payeeFieldDetailsDB.setCreatedBy(payeeFieldDetailsVO.getCreatedBy());
					payeeFieldDetailsDB.setDateCreated(payeeFieldDetailsVO.getDateCreated());
					payeeFieldDetailsDB.setUpdatedBy(payeeFieldDetailsVO.getUpdatedBy());
					payeeFieldDetailsDB.setDateUpdated(payeeFieldDetailsVO.getDateUpdated());
					payeeFieldDetailsDB.setStatus(CommonConstants.STATUS_ACTIVE);
					updatePayeeFieldDetailsVOList.add(payeeFieldDetailsDB);
				}
			}
			if (!isItOldField) {
				updatePayeeFieldDetailsVOList.add(payeeFieldDetailsVO);
			}
		}
	 	//This for loop will handle deleted cases, TO identify deleted cases
		for (PayeeFieldDetailsView payeeFieldDetailsView : listPayeeFieldDetailsVO) {
			isItOldField = false;
			String fieldLabelDB = payeeFieldDetailsView.getFieldLabelName().trim();
			for (PayeeFieldDetailsVO payeeFieldDetailsVO : payee.getPayeeFieldDetails()) {
				String fieldLabel = payeeFieldDetailsVO.getFieldLabelName().trim();
				if (fieldLabelDB.equalsIgnoreCase(fieldLabel)) {
					isItOldField = true;
				}
			}
			if (!isItOldField) {
				PayeeFieldDetailsVO payeeFieldDetailsDB=new  PayeeFieldDetailsVO();
				payeeFieldDetailsDB.setPayeeDetailVO(payee);
				payeeFieldDetailsDB.setId(payeeFieldDetailsView.getPayeeFieldId());
				payeeFieldDetailsDB.setFieldId(payeeFieldDetailsView.getFieldId());
				payeeFieldDetailsDB.setFieldValue(payeeFieldDetailsView.getFieldValue());
				payeeFieldDetailsDB.setRemarks(payeeFieldDetailsView.getRemarks());
				payeeFieldDetailsDB.setDateCreated(payeeFieldDetailsView.getDateCreated());
				payeeFieldDetailsDB.setDateUpdated(new java.util.Date());
				payeeFieldDetailsDB.setCreatedBy(payeeFieldDetailsView.getCreatedBy());
				payeeFieldDetailsDB.setUpdatedBy(payee.getCustomerId());
				payeeFieldDetailsDB.setStatus(CommonConstants.D);
				updatePayeeFieldDetailsVOList.add(payeeFieldDetailsDB);
			}

		}
       payee.getPayeeFieldDetails().clear(); 
       payee.setPayeeFieldDetails(updatePayeeFieldDetailsVOList);
		LOGGER.info("PayeeManagementServiceImpl :: callPayeeUpateProcess :: end " + payee.getReferenceNumber());
	}

	@Override
	public void validatePayeeRpeCs(PayloadDTO bean) {
		LOGGER.info("PayeeManagementServiceImpl :: validatePayeeRpeCs :: START "+bean.getRequestVO().getMessageVO().getReqID());
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
		BillerPayResponseVO response = new BillerPayResponseVO();
		bean.setResponseVO(response);
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		setPayeeType(payee);
	    List<ViewPayeeVO> payeeDetailVODB = payeeDAO.getPayeeListCS(billerPayRequestVO.getUser(),payee.getPayeeId());
		BillerVO billerVO =payeeDAO.getFieldInfo(payee.getBillerCode(),payee.getCountryCode());
		LOGGER.info("PayeeManagementServiceImpl :: validatePayeeRpeCs :: got payee and biller "+bean.getRequestVO().getMessageVO().getReqID());
		billerPayRequestVO.getBillerPayDetailsVO().setUniqueId(billerVO.getId());
		billerPayRequestVO.getBillerPayDetailsVO().setAggId(billerVO.getBillerId());
		billerPayRequestVO.getBillerPayDetailsVO().setPresentMentType(billerVO.getBillPresentmentType());
		Set<BillerField> setFields=billerVO.getBillerFields();
		List<BillerField> listFields=new ArrayList<BillerField>();
		boolean isDuplicatePayee=true;
		listFields.addAll(setFields);
		billerPayRequestVO.getBillerPayDetailsVO().setFieldsFromDB(listFields);
		LOGGER.info("PayeeManagementServiceImpl :: validatePayeeRpeCs :: set biller details "+bean.getRequestVO().getMessageVO().getReqID());
		if (payeeDetailVODB != null) {
			for (ViewPayeeVO payeeDetailsFromDb : payeeDetailVODB) {
				isDuplicatePayee=true;
				if (payee.getPayeeShortName() != null && !payee.getPayeeShortName().isEmpty()) {
					if(payeeDetailsFromDb.getPayeeShortName() !=null && !payeeDetailsFromDb.getPayeeShortName().isEmpty()){
					if (payeeDetailsFromDb.getPayeeShortName().equals(payee.getPayeeShortName())) {
						LOGGER.info("validatePayeeRpeCs ::PayeeShortName is equal"+bean.getRequestVO().getMessageVO().getReqID());
						response.setStatus(Messages._1.getCode());
						response.setStatusDesc(Messages._1.getMessage());
						response.setErrorCD(Messages._310.getCode());
						response.setErrorDesc(Messages._310.getMessage());
						break;
					}

				}
				}
				
				if (payeeDetailsFromDb.getBillerUniqueId().equals(payee.getBillerCode()) ) {
					for(PayeeFieldDetailsView payeeFieldDetailsdb :payeeDetailsFromDb.getPayeeFieldDetails()){
						
						for(PayeeFieldDetailsVO payeeFieldDetailsVO:payee.getPayeeFieldDetails()){
							
								String filedValue=payeeFieldDetailsVO.getFieldValue();
								/*if(payeeFieldDetailsVO.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST))
								  for(BillerFieldItemVO item: payeeFieldDetailsVO.getPayeeFieldItems())
									  filedValue=item.getId().toString();*/
								
								if(payeeFieldDetailsdb.getFieldLabelName().trim().equalsIgnoreCase(payeeFieldDetailsVO.getFieldLabelName().trim()) 
										&& !payeeFieldDetailsdb.getFieldValue().equalsIgnoreCase(filedValue)
										&& isDuplicatePayee){
									isDuplicatePayee=false;
									break;
								}
						}
					}
					if(isDuplicatePayee){
						LOGGER.info("validatePayeeRpeCs ::Payee already exists"+bean.getRequestVO().getMessageVO().getReqID());
						response.setStatus(Messages._1.getCode());
						response.setStatusDesc(Messages._1.getMessage());
						response.setErrorCD(Messages._308.getCode());
						response.setErrorDesc(Messages._308.getMessage());
						break;	
					}
				}
			}

		}
		LOGGER.info("PayeeManagementServiceImpl :: validatePayeeRpeCs :: END "+bean.getRequestVO().getMessageVO().getReqID());
	}
	
	
	@Override
	public ViewPayeeResponseVO viewPayeeListCS(ViewPayeeRequestVO viewPayeeRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListCS :: START "+viewPayeeRequestVO.getMessageVO().getReqID());
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeResponseVO = new ViewPayeeResponseVO();
			List<ViewPayeeVO> listViewPayeeVO = payeeDAO.getPayeeListCS(viewPayeeRequestVO.getUser(),null);
/*			for(ViewPayeeVO viewPayeeVO:listViewPayeeVO){
				for(PayeeFieldDetailsView field :viewPayeeVO.getPayeeFieldDetails()){
					if(field.getFieldDataType()!=null && field.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
					for(BillerFieldItemVO vo:field.getPayeeFieldItems()){
						vo.setId(Integer.parseInt(vo.getProductId()));
					}
					}
				}
			}*/
			if(listViewPayeeVO.isEmpty()){
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListCS ::Empty List From DB "+viewPayeeRequestVO.getMessageVO().getReqID());
				viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
			}else{
				LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListCS ::Values List From DB "+viewPayeeRequestVO.getMessageVO().getReqID());
				viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
			}
		
		} catch (Exception e) {
			LOGGER.info("payeemanagmentServce Error" +viewPayeeRequestVO.getMessageVO().getReqID()+"  "+e);
			LOGGER.error("payeemanagmentServce Error" ,e);
		}
		LOGGER.info("PayeeManagementServiceImpl :: viewPayeeListCS :: END "+viewPayeeRequestVO.getMessageVO().getReqID());
		return viewPayeeResponseVO;
	}

	@Override
	public BillerVO getUniqueBillerId(PayloadDTO payloadDTO) {
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		return payeeDAO.getUniqueBillerId(payee.getBillerCode(),payee.getCountryCode());
	}
	
	/**
	 * @param billerPayRequestVO
	 * @return
	 */
	private boolean checkIfAnyInprocessPayments(BillerPayRequestVO billerPayRequestVO){
		BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getDeletePayeeserviceMapping(billerPayRequestVO);
		List<String> list=Arrays.asList(dataBean.getMap().get(CommonConstants.PAYEE_DELETE_PAYMENT_INPROCESS_STATUS).split(CommonConstants.COMMA));
		// list = Arrays.asList(list.toString().split(CommonConstants.COMMA));
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -12);
        Date fromDate = calendar.getTime();
        Calendar cal = DateUtils.getCountryCalendar();
        Date toDate = cal.getTime();
        LOGGER.debug("delete {} --- From Date {} and To Date {} and list {} and payeeid {} and cntry{}"
        		,new Object[]{fromDate,toDate,toDate,list,payee.getCountryCode()});
	  return payeeDAO.checkIfAnyInprocessPayments(fromDate, toDate, payee.getPayeeId(), payee.getCountryCode(), list);	
	}
	/**
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
	
	//Added for Orange Money - start
	
		/* 
		 * 
		 * (non-Javadoc)
		 * @see com.scb.channels.payments.service.PayeeManagementService#validateWalletPayeeRpeCS(com.scb.channels.base.vo.PayloadDTO)
		 */
		public void validateWalletPayeeRpeCS(PayloadDTO bean) {
			LOGGER.info("PayeeManagementServiceImpl :: validateWalletPayeeRpeCS :: START "+bean.getRequestVO().getMessageVO().getReqID());
			BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
			
			try {
				PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
				payee.setPayeeType(CommonConstants.REGISTERED_WALLET);
				
				boolean isPrimaryFiledExists=false;
				for(PayeeFieldDetailsVO payeeFieldDetailsVO: payee.getPayeeFieldDetails()){
					isPrimaryFiledExists = setConsumerNumber(bean, isPrimaryFiledExists, payee, payeeFieldDetailsVO);
				}
				
				List<ViewPayeeVO> payeeDetailsList = null;
				List<ViewPayeeVO> payeeDetailsByUserList = null;
				BillerVO billerVO = null;
				//boolean isSameNickName = false;
				// get payeeDetailList based on the wallet id
				//get Wallet Id
				String walletId = fetchFieldValue(payee,CommonConstants.INFOFIELD9);
				LOGGER.info("Wallet Id received from the request: "+walletId);
				//get Payee list for all users. ie. send userVO as null  
				payeeDetailsList = payeeDAO.getPayeeListByWallet(billerPayRequestVO.getUser(), payee.getPayeeId(), walletId);//fetch payee details for the wallet
				
				billerVO =payeeDAO.getWalletFieldInfo(payee.getBillerCode(),payee.getCountryCode());
				billerPayRequestVO.getBillerPayDetailsVO().setUniqueId(billerVO.getId());
				billerPayRequestVO.getBillerPayDetailsVO().setAggId(billerVO.getBillerId());
				billerPayRequestVO.getBillerPayDetailsVO().setPresentMentType(billerVO.getBillPresentmentType());
				Set<BillerField> setFields=billerVO.getBillerFields();
				List<BillerField> listFields=new ArrayList<BillerField>();
				listFields.addAll(setFields);
				billerPayRequestVO.getBillerPayDetailsVO().setFieldsFromDB(listFields);
				LOGGER.info("PayeeManagementServiceImpl :: validateWalletPayeeRpeCS :: set biller details "+bean.getRequestVO().getMessageVO().getReqID());
				
				//Maximum allowed wallet account link count
				String maxAllowedWalletAccLink = "";
				String walletAccLinkMax = "";
				String countryCode = "";
				if(billerPayRequestVO.getUser()!=null && billerPayRequestVO.getUser().getCountry()!=null){
					countryCode =  billerPayRequestVO.getUser().getCountry();
					LOGGER.info("PayeeManagementServiceImpl : validateAccount: countryCode: "+countryCode);
					walletAccLinkMax = dataBean.getMap().get(countryCode + CommonConstants.WALLET_ACC_LINK_MAX);
				}
				maxAllowedWalletAccLink = (!StringUtils.isEmpty(walletAccLinkMax)) ? walletAccLinkMax : dataBean.getMap().get(CommonConstants.ALL + CommonConstants.WALLET_ACC_LINK_MAX);
				int maxLinksAllowed = (!StringUtils.isEmpty(maxAllowedWalletAccLink))?Integer.parseInt(maxAllowedWalletAccLink):0;
			
				//
				
				//validate alias name
				billerPayResponseVO = validateAliasName(bean, billerPayResponseVO, payee, payeeDetailsList,maxLinksAllowed); 
				
				if(billerPayResponseVO.getStatus()!=null && billerPayResponseVO.getStatus().equals("-1")){
					LOGGER.info("Validation failed at WALLET-ALIAS level");
				} else {
					LOGGER.info("Validation for at WALLET- ACCOUNT level");
					//get Account Id
					String accNumber = fetchFieldValue(payee,CommonConstants.ACCOUNT);
					String wallet = fetchFieldValue(payee,CommonConstants.INFOFIELD9);
					LOGGER.info("Account Number : "+accNumber +" Wallet Id: "+wallet);
					//validateAccountNumber(accNumber);
					payeeDetailsByUserList = payeeDAO.getWalletPayeeList(billerPayRequestVO.getUser(), payee.getPayeeId());//fetch viewPayeeVO details by user
					billerPayResponseVO = validateAccount(billerPayRequestVO, billerPayResponseVO, payeeDetailsByUserList, accNumber, wallet, maxLinksAllowed);
					LOGGER.info("Both Wallet-ALIAS and Wallet-Account validation");
				}
			} catch (Exception e) {
				LOGGER.error("Exception occured at PayeeManagementServiceImpl: validateWalletPayeeRpeCS : ",e);
			}
	    	
			bean.setResponseVO(billerPayResponseVO);
			LOGGER.info("PayeeManagementServiceImpl :: validateWalletPayeeRpeCS :: END "+bean.getRequestVO().getMessageVO().getReqID());
		}

	/**
	 * @param billerPayRequestVO
	 * @param response
	 * @param payeeDetailsByUserList
	 * @param accNumber
	 * @param walletId
	 * @param maxLinksAllowed
	 * @return
	 */
	private BillerPayResponseVO validateAccount(BillerPayRequestVO billerPayRequestVO, BillerPayResponseVO response,
			List<ViewPayeeVO> payeeDetailsByUserList, String accNumber, String walletId, int maxLinksAllowed) {
		boolean duplicateAccNo=false;
		String accFieldValue = "";
		
		int count = 0;
		if(billerPayRequestVO!=null){
			//validate user account
			 if(!payeeDetailsByUserList.isEmpty()){
				LOGGER.info("validateAccount: validate user account ");
				for (ViewPayeeVO viewPayeeVO : payeeDetailsByUserList) {
					for(PayeeFieldDetailsView payeeFieldDetailsDB : viewPayeeVO.getPayeeFieldDetails()){
						//check duplicateAccount
						if(payeeFieldDetailsDB.getFieldLabelName().trim().equalsIgnoreCase(CommonConstants.ACCOUNT)){
							accFieldValue = payeeFieldDetailsDB.getFieldValue();
							if(!StringUtils.isEmpty(accFieldValue) && accNumber.equalsIgnoreCase(accFieldValue)){
								duplicateAccNo = true;
								response = new BillerPayResponseVO();
								response.setStatus(Messages._1.getCode());
								response.setStatusDesc(Messages._1.getMessage());
								response.setErrorCD(Messages._357.getCode());
								response.setErrorDesc(Messages._357.getMessage());
								LOGGER.info("validateWalletPayeeRpeCS : validateAliasName : Wallet cannot be mapped with same account number!!! : response.getErrorDesc(): "+response.getErrorDesc());
								//LOGGER.info("Wallet cannot be mapped with same account number!!!");
								break;
							}
						}
					}
				}
			}
		}
		return response;
	}

	/**
	 * Method to get field Value for the given field Name
	 * @param payee
	 * @param payeeDetailsList
	 * @param fieldName
	 * @return
	 */
	private String fetchFieldValue(PayeeDetailVO payee , String fieldName) {
		String fieldValue = null;
		if (payee!=null) {
			for (PayeeFieldDetailsVO payeeFieldDetail : payee.getPayeeFieldDetails()) {
				if(payeeFieldDetail.getFieldLabelName().trim().equalsIgnoreCase(fieldName)){
					fieldValue = payeeFieldDetail.getFieldValue();
					break;
				}
			}
		}
		return fieldValue;
	}

	/**
	 * @param bean
	 * @param response
	 * @param payee
	 * @param payeeDetailsList
	 * @param maxLinksAllowed
	 * @return
	 */
	private BillerPayResponseVO validateAliasName(PayloadDTO bean, BillerPayResponseVO response, PayeeDetailVO payee, List<ViewPayeeVO> payeeDetailsList, int maxLinksAllowed) {
		boolean isSameNickName = false;
		//String walletFieldValue= "";
		//boolean isSameWallet= false;
		//int count = 0;
		if (!payeeDetailsList.isEmpty() && payeeDetailsList.size()>=maxLinksAllowed) {
			LOGGER.info("This Wallet is mapped to more than or equal to  " +maxLinksAllowed);
			response = new BillerPayResponseVO();
			response.setErrorDesc(ExceptionMessages._248.getMessage());
			response.setErrorCD(ExceptionMessages._248.getCode());
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			LOGGER.info("validateWalletPayeeRpeCS : validateAliasName : response.getErrorDesc(): "+response.getErrorDesc());
		}else if (!payeeDetailsList.isEmpty()) {
			// To check duplicate nick name
			for (ViewPayeeVO viewPayeeVO : payeeDetailsList) {
				if (StringUtils.isNotEmpty(payee.getPayeeShortName()) && StringUtils.isNotEmpty(viewPayeeVO.getPayeeShortName())) {
					if (viewPayeeVO.getPayeeShortName().equals(payee.getPayeeShortName())) {
						LOGGER.info("validateWalletPayeeRpeCS :: PayeeShortName is equal"+bean.getRequestVO().getMessageVO().getReqID());
						isSameNickName= true;
						response = new BillerPayResponseVO();
						response.setStatus(Messages._1.getCode());
						response.setStatusDesc(Messages._1.getMessage());
						response.setErrorCD(Messages._358.getCode());
						response.setErrorDesc(Messages._358.getMessage());
						LOGGER.info("validateWalletPayeeRpeCS : validateAliasName : response.getErrorDesc(): "+response.getErrorDesc());
						break;
					}
				}
			
			}
		}
		return response;
	}
		
		
		public void addPayeeWallet(PayloadDTO bean) {
			LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: START :: NEW"+bean.getRequestVO().getMessageVO().getReqID());
			boolean isFieldExists=false;
			boolean isPrimaryFiledExists=false;
			BillerPayResponseVO billerPayResponseVO = null ;
			BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			bean.setResponseVO(billerPayResponseVO);
		    PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		    
		    for(PayeeFieldDetailsVO payeeFieldDetailsVO: payee.getPayeeFieldDetails()){
		    	isPrimaryFiledExists = setConsumerNumber(bean, isPrimaryFiledExists, payee, payeeFieldDetailsVO);
		    	payeeFieldDetailsVO.setPayeeDetailVO(payee);
		    	payeeFieldDetailsVO.setRemarks(payeeFieldDetailsVO.getFieldDataType());
		    	payeeFieldDetailsVO.setStatus(CommonConstants.STATUS_ACTIVE);
		    	payeeFieldDetailsVO.setDateCreated(payee.getCreatedTime());
		    	payeeFieldDetailsVO.setDateUpdated(payee.getUpdateTime());
		    	payeeFieldDetailsVO.setCreatedBy(payee.getCreatedBy());
		    	payeeFieldDetailsVO.setUpdatedBy(payee.getUpdatedBy());
		    	payeeFieldDetailsVO.setVersion(CommonConstants.ZERO_INT);
		    	
		    	// field id and field label name synch --Start
		    	isFieldExists = false;
		    	String labelName =payeeFieldDetailsVO.getFieldLabelName().trim();
		    	for(BillerField billerField : billerPayRequestVO.getBillerPayDetailsVO().getFieldsFromDB()){
		    		String labelNameDB=billerField.getFieldLabelName().trim();
		    		switch(billerPayRequestVO.getBillerPayDetailsVO().getPresentMentType()){
		    		case CommonConstants.ZERO://This case for only paybill scenarios
		    			if (labelName.equalsIgnoreCase(labelNameDB) 
		    					&& billerField.getFieldType().equalsIgnoreCase(CommonConstants.P) 
		    					&&payeeFieldDetailsVO.getFieldType().equalsIgnoreCase(CommonConstants.P)) {
							setFieldIdandFiledValue(bean, payeeFieldDetailsVO, billerField);
							isFieldExists = true;
						}
		    			break;
		    		default://This case is name,responsse,paybill field scenarios
		    			if (labelName.equalsIgnoreCase(labelNameDB)  
		    					&& billerField.getFieldType().equalsIgnoreCase(CommonConstants.N) &&
		    					payeeFieldDetailsVO.getFieldType().equalsIgnoreCase(CommonConstants.N)) {
							setFieldIdandFiledValue(bean, payeeFieldDetailsVO, billerField);
							isFieldExists = true;
						}
		    		}
					
		    	}
		    	// field id and field label name synch --End
		    	
		    	if(!isFieldExists){
		    		billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setErrorDesc(ExceptionMessages._245.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._245.getCode());
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					bean.setResponseVO(billerPayResponseVO);
		    		LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: Field not exists :: " +labelName+" "+payee.getCustomerId());
		    		return;
		    	}
		    	
		    }
		    
		    if(!isPrimaryFiledExists){
	    		billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._246.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._246.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
				bean.setResponseVO(billerPayResponseVO);
	    		LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: Primary Field not exists :: ");
	    		return;	
	    	}
			payee.setStatus(CommonConstants.STATUS_ACTIVE);
			payee.setPayeeType(CommonConstants.REGISTERED_WALLET);
			LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet ::  getServiceTxnType "+billerPayRequestVO.getServiceVO().getServiceTxnType());
     		 payee.setPayeeId(null);	
			 payee.setIsUpdateRequired(CommonConstants.STRING_NO);
			 payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_ACTIVE);
			 payee.setConsumerDetail(billerPayRequestVO.getUser().getLoginId());
			 LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: ConsumerDetail "+ payee.getConsumerDetail());
			 
			 LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: before Save "
			 +bean.getRequestVO().getMessageVO().getReqID()
			 +" getCustomerId "+payee.getCustomerId()
			 +" getBillerUniqueId "+payee.getBillerVO().getBillerUniqueId()
			 +" getCountryCode "+payee.getCountryCode()
			 +" getChannelId "+payee.getChannelId()
			 +" getReferenceNumber "+payee.getReferenceNumber()
			 +" getStatus "+payee.getStatus()
			 +" getCreatedBy "+payee.getCreatedBy()
			 +" getCreatedTime "+payee.getCreatedTime()
			 +" getUpdatedBy "+payee.getUpdatedBy()
			 +" getUpdateTime "+payee.getUpdateTime()
			 +" getVersion "+payee.getVersion()
			 +" getConsumerNumber "+payee.getConsumerNumber()
			 +" getPayeeType "+payee.getPayeeType()
			 +" getIsUpdateRequired "+payee.getIsUpdateRequired());
			 
			 payeeDAO.savePayeeCS(payee);
			 LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: Save  Done Successfully");
			 
			if(CommonConstants.STATUS_ACTIVE.equalsIgnoreCase(payee.getStatus())){
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setStatus(Messages._0.getCode());
				billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
				billerPayResponseVO.setErrorCD(Messages._353.getCode());
				billerPayResponseVO.setErrorDesc(Messages._353.getMessage());
				bean.setResponseVO(billerPayResponseVO);
				}

			LOGGER.info("PayeeManagementServiceImpl :: addPayeeWallet :: end "+bean.getRequestVO().getMessageVO().getReqID());
			}
		
	public BillerPayResponseVO deleteWalletPayee(BillerPayRequestVO billerPayRequestVO) {
			LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayee :: START ");
			BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
			BillerPayResponseVO response = null;
			PayeeDetailVO payee = BillpaymentMappingHelper.getDeletePayeeserviceMapping(billerPayRequestVO);
			payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_DELETED);
			LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayee :: payee Deleting from DB  {}-{}-{}-{}",
					new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(), billerPayDetails.getUtilltyTypeDesc() });
			try {
				if (payeeDAO.deletePayee(payee)) {
					LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayee :: Payee deleted succesfully" );
					response = new BillerPayResponseVO();
					response.setStatus(Messages._354.getCode());
					response.setStatusDesc(Messages._354.getMessage());
				} 
			} catch (Exception e) {
				LOGGER.error("payeemanagmentServce deleteWalletPayee Error" , e);
			}
			LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayee :: END ");
			return response;
		}
	
	
	public BillerPayResponseVO addWalletPayeeBO(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: addWalletPayeeBO :: START ");
		BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getDeletePayeeserviceMapping(billerPayRequestVO);
		payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_ACTIVATED_VIA_BO);
		LOGGER.info("PayeeManagementServiceImpl :: addWalletPayeeBO :: payee Deleting from DB  {}-{}-{}-{}",
				new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(), billerPayDetails.getUtilltyTypeDesc() });
		try {
			if (payeeDAO.addPayeeBO(payee)) {
				LOGGER.info("PayeeManagementServiceImpl :: addWalletPayeeBO :: Wallet activated succesfully call via BO" );
				response = new BillerPayResponseVO();
				response.setErrorCD(Messages._360.getCode());
				response.setErrorDesc(Messages._360.getMessage());
			}else{
				response = new BillerPayResponseVO();
				response.setErrorCD(Messages._361.getCode());
				response.setErrorDesc(Messages._361.getMessage());
			}
		} catch (Exception e) {
			LOGGER.error("payeemanagmentServce addWalletPayeeBO Error" , e);
		}
		LOGGER.info("PayeeManagementServiceImpl :: addWalletPayeeBO :: END ");
		return response;
	}
	
	public BillerPayResponseVO deleteWalletPayeeBO(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayeeBO :: START ");
		BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		BillerPayResponseVO response = null;
		PayeeDetailVO payee = BillpaymentMappingHelper.getDeletePayeeserviceMapping(billerPayRequestVO);
		payee.setRemarks(CommonConstants.PAYEE_STATUS_DESCRIPTION_DELETED_VIA_BO);
		LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayeeBO :: payee Deleting from DB  {}-{}-{}-{}",
				new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(), billerPayDetails.getUtilltyTypeDesc() });
		try {
			if (payeeDAO.deletePayeeBO(payee)) {
				LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayeeBO :: Wallet deleted succesfully call via BO" );
				response = new BillerPayResponseVO();
				response.setStatus(Messages._359.getCode());
				response.setStatusDesc(Messages._359.getMessage());
			}else{
				response = new BillerPayResponseVO();
				response.setStatus(Messages._356.getCode());
				response.setStatusDesc(Messages._356.getMessage());
			}
		} catch (Exception e) {
			LOGGER.error("payeemanagmentServce deleteWalletPayeeBO Error" , e);
		}
		LOGGER.info("PayeeManagementServiceImpl :: deleteWalletPayeeBO :: END ");
		return response;
	}
		
		
	public ViewPayeeResponseVO viewWalletPayeeList(ViewPayeeRequestVO viewPayeeRequestVO) {
			LOGGER.info("PayeeManagementServiceImpl :: viewWalletPayeeList :: START ");
			ViewPayeeResponseVO viewPayeeResponseVO = null;
			try {
				viewPayeeResponseVO = new ViewPayeeResponseVO();
				List<ViewPayeeVO> listViewPayeeVO = payeeDAO.viewWalletPayeeList(viewPayeeRequestVO.getUser());
				if(listViewPayeeVO.isEmpty()){
					LOGGER.info("PayeeManagementServiceImpl :: viewWalletPayeeList ::Empty List From DB ");
					viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
				}else{
					LOGGER.info("PayeeManagementServiceImpl :: viewWalletPayeeList ::Values List From DB ");
					viewPayeeResponseVO.setListViewPayeeVO(listViewPayeeVO);
				}
			
			} catch (Exception e) {
				LOGGER.error("payeemanagmentServce Error :: viewWalletPayeeList " , e);
			}
			LOGGER.info("PayeeManagementServiceImpl :: viewWalletPayeeList :: END ");
			return viewPayeeResponseVO;
		}
		
		// Added for fetching the Wallet Information for BIC - start
		
	public List<PayeeDetailVO> getWalletPayee(BillerPayRequestVO billerPayRequestVO) {
			LOGGER.info("PayeeManagementServiceImpl :: fetchPayeeWallet :: START ");
			BillerPayDetailsVO billerPayDetails = billerPayRequestVO.getBillerPayDetailsVO();
			List<PayeeDetailVO> payeeDetailVO=new ArrayList<PayeeDetailVO>();
			PayeeDetailVO payee = BillpaymentMappingHelper.getDeletePayeeserviceMapping(billerPayRequestVO);
			LOGGER.info("payee fetching from DB  {}-{}-{}-{}",
					new Object[] { billerPayDetails.getBillerCd(), billerPayDetails.getBillerDesc(), billerPayDetails.getUtilityCd(), billerPayDetails.getUtilltyTypeDesc() });
			try {
				
				payeeDetailVO = payeeDAO.getPayeeListCS(billerPayRequestVO.getUser(), payee.getPayeeId(), CommonConstants.WALLET_PAYEE, null,null);
				
				 
			} catch (Exception e) {
				LOGGER.error("payeemanagmentServce Error" , e);
			}
			LOGGER.info("PayeeManagementServiceImpl :: deletePayee :: END ");
			return payeeDetailVO;
		}

	@Override
	public String getCommonSequenceNumberGenerator() {
		return payeeDAO.getCommonSequenceNumberGenerator(CommonConstants.WALLET_REFERENCE_NUM_GENERATOR);
	}
	
	
	public BillerVO getWalletUniqueBillerId(PayloadDTO payloadDTO) {
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		PayeeDetailVO payee = BillpaymentMappingHelper.getAddPayeeserviceMapping(billerPayRequestVO);
		return payeeDAO.getWalletUniqueBillerId(payee.getBillerCode(),payee.getCountryCode());
	}
		
		// Added for fetching the Wallet Information for BIC - end	

}
