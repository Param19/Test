/**
 * 
 *//*
package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PayeeManagementService;

*//**
 * The Class ViewPayeeListProcessor.
 * 
 * @author 1521723
 *//*
public class ViewPayeeListProcessorHK extends AbstractProcessor {

	*//** The Constant LOGGER. *//*
	private static final Logger LOGGER = LoggerFactory.getLogger(ViewPayeeListProcessorHK.class);

	private PayeeManagementService payeeService;

	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	*//** ViewPayeeListProcessor doTasks *//*
	
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang
	 * .Object)
	 

	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.info("ViewPayeeListProcessorHK :: doTasksHK :: START ");
		ViewPayeeRequestVO viewPayeeRequestVO = null;
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeRequestVO = (ViewPayeeRequestVO) bean.getRequestVO();
			viewPayeeResponseVO = payeeService.viewPayeeListHK(viewPayeeRequestVO);
			if (viewPayeeResponseVO == null) {
				viewPayeeResponseVO = new ViewPayeeResponseVO();
				viewPayeeResponseVO.setStatus(Messages._1.getCode());
				viewPayeeResponseVO.setStatusDesc(Messages._1.getMessage());
				viewPayeeResponseVO.setErrorDesc(ExceptionMessages._151.getMessage());
				viewPayeeResponseVO.setErrorCD(ExceptionMessages._151.getCode());
			} else {
				if (!viewPayeeResponseVO.getListViewPayeeHKVO(). isEmpty()) {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
				} else {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
					viewPayeeResponseVO.setErrorCD(Messages._307.getCode());
					viewPayeeResponseVO.setErrorDesc(Messages._307.getMessage());
				}
			}
			bean.setResponseVO(viewPayeeResponseVO);
		} catch (Exception e) {
			LOGGER.info("ViewPayeeListProcessorHK :: doTasks ::" + e.getMessage());
		}
		LOGGER.info("ViewPayeeListProcessorHK :: doTasks :: END ");
		return bean;
	}
}
*/