package com.scb.channels.payments.dao;

import java.util.List;
import java.util.Map;

import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayeeDetailVO;


/**
 * The Interface Payee managementDAO.
 */

public interface BillerManagementDAO {
	

	/*** add payee.
	   *
	   * @param billerPayDetailsVO the biller pay details vo
	   */
	
	public List<BillerCategoryVO> getActiveBillerCategories(String Country);
	

	
	public List<BillerVO>	GetBillers(String Country,String categoryId );
	 
	public List<PayeeDetailVO> GetPayment();
	
	public BillerVO GetBiller(String billerId, String country);
		
	public Map<String, ApplicationMessageVO> getApplicationMessages(String country,String channel);
	
	public List<NarrationVO> getNarrationConfig(String Country, String Channel);

	public List<BillerCategoryVO> getBillerCategories(String Country, String category);
	
}
