package com.scb.channels.payments.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.payments.dao.InwardPaymentDAO;

public class InwardPaymentDAOImpl extends HibernateDaoSupport implements InwardPaymentDAO {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(InwardPaymentDAOImpl.class);
	
	

}
