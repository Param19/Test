package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.payments.service.BillerDownloadCheckService;
import com.scb.channels.payments.service.impl.BillerDownloadCheckServiceImpl;

/**
 * @author 1460693
 * 
 * Processing the Biller Download from Aggregators
 *
 */
public class BillerDownloadMasterDataUpdateProcessor extends AbstractProcessor  {
	
	BillerDownloadCheckService billerDownloadCheckService;
	
	private DataBean dataBean;

	
	/**
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}
	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	/**  Logger Object **/
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadCheckServiceImpl.class);

	
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		try{
		String Country=null;
		boolean isdataAvailable;	
		Country=bean.getRequestVO().getUser().getCountry();
		LOGGER.info("country is <----   --->"+Country);
		isdataAvailable=billerDownloadCheckService.isActiverBillerCategoriesAvailable(Country);
		LOGGER.info("is already data Availble from the DB for County   "+Country+"   "+isdataAvailable);
		if(isdataAvailable){
			
			billerDownloadCheckService.compareMasterAndAggragtorBiller(bean);
			String isUpdateEnabled=dataBean.getMap().get(CommonConstants.PAYEE_UPDATE_PROCESS_KEY);
			if(isUpdateEnabled !=null && !CommonConstants.NG.equalsIgnoreCase(Country) && CommonConstants.YES.equalsIgnoreCase(isUpdateEnabled)){
				LOGGER.info("updatePayeesOnceDownloadDone excuting for :: " +Country);
			 billerDownloadCheckService.updatePayeesOnceDownloadDone(Country);
			 LOGGER.info("updatePayeesOnceDownloadDone executed :: " +Country);
			}
		}else{
			billerDownloadCheckService.intialBillersfromAggregator(bean);
			
		}
		LOGGER.info("<< BillerDownloadMasterDataUpdateProcessor End ReqId---  "+bean.getRequestVO().getMessageVO().getReqID());
			bean.getResponseVO().setStatus(CommonConstants.SUCC);
		 
		}catch(Exception e){
			LOGGER.info("Biller Downlaod Check service Failed at service Level" +e.getMessage());
			LOGGER.error("Biller Downlaod Check service Failed at service Level" ,e);
			LOGGER.info("BILLER DOWNLOAD FAILED "+bean.getRequestVO().getUser().getCountry());
			
		}
		return bean;
	}
	public BillerDownloadCheckService getBillerDownloadCheckService() {
		return billerDownloadCheckService;
	}
	public void setBillerDownloadCheckService(
			BillerDownloadCheckService billerDownloadCheckService) {
		this.billerDownloadCheckService = billerDownloadCheckService;
	}
	
	 

}
