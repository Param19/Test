package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PayeeManagementService;

public class AddPayeeProcessor  {
	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AddPayeeProcessor.class);
	/**
	 * payeeService
	 */
	private PayeeManagementService payeeService;

	/**
	 * @param payeeService
	 */
	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels
	 * .base.vo.PayloadDTO)
	 */
	public PayloadDTO process(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: Start"+bean.getRequestVO().getMessageVO().getReqID());
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayResponseVO = payeeService.addPayee(billerPayRequestVO);

			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
				billerPayResponseVO.setStatus(ExceptionMessages._144.getCode());
				billerPayResponseVO.setStatusDesc(ExceptionMessages._144.getMessage());
			}
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
		} catch (Exception e) {
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: Exception " +e.getMessage());
		}
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: End");
		return bean;
	}
	
	public PayloadDTO addPayeeAlipay(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: Start");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
			if(billerPayRequestVO.getUser().getCustomerId() != null && billerPayRequestVO.getUser().getCustomerType() !=null){
				billerPayRequestVO.getUser().setCustomerId(billerPayRequestVO.getUser().getCustomerType()+billerPayRequestVO.getUser().getCustomerId());
			}
			billerPayResponseVO = payeeService.updatePayee(billerPayRequestVO);
			bean.setResponseVO(billerPayResponseVO);
		} catch (Exception e) {
			billerPayResponseVO = new BillerPayResponseVO();
			//billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			//billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setStatusDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: Exception " +e.getMessage());
		}
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: End");
		return bean;
	}
	public PayloadDTO processCS(PayloadDTO bean) throws Exception {
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: Start"+bean.getRequestVO().getMessageVO().getReqID());
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			 payeeService.addPayeeCS(bean);
			if (bean.getResponseVO().getStatus() == null) {
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			}
			billerPayResponseVO=(BillerPayResponseVO)bean.getResponseVO();
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
		} catch (Exception e) {
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: Exception " +e.getMessage()+ " " +bean.getRequestVO().getMessageVO().getReqID());
		LOGGER.error("Inside AddPayeeProcessor :: doTasks :: Exception " ,e);
		}
		LOGGER.info("Inside AddPayeeProcessor :: doTasks :: End"+bean.getRequestVO().getMessageVO().getReqID());
		return bean;
	}
	//Orange Money - start
	
		public PayloadDTO processCSWallet(PayloadDTO bean) throws Exception {
			LOGGER.info("Inside AddPayeeProcessor :: processCSWallet :: Start"+bean.getRequestVO().getMessageVO().getReqID());
			BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			BillerPayResponseVO billerPayResponseVO = null;
	
			try {
				 payeeService.addPayeeWallet(bean);
				if (bean.getResponseVO().getStatus() == null) {
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
				}
				billerPayResponseVO=(BillerPayResponseVO)bean.getResponseVO();
				billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				bean.setResponseVO(billerPayResponseVO);
			} catch (Exception e) {
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
				billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				bean.setResponseVO(billerPayResponseVO);
		//	LOGGER.info("Inside AddPayeeProcessor :: processCSWallet :: Exception " +e.getMessage()+ " " +bean.getRequestVO().getMessageVO().getReqID());
			LOGGER.error("Inside AddPayeeProcessor :: processCSWallet :: Exception " ,e);
			}
			LOGGER.info("Inside AddPayeeProcessor :: processCSWallet :: End"+bean.getRequestVO().getMessageVO().getReqID());
			return bean;
		}
		
		//Orange Money - end
}