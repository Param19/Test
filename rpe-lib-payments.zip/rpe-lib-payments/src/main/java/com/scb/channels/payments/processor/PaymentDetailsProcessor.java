package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.PaymentDetailsService;

public class PaymentDetailsProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentDetailsProcessor.class);
	
	/** The payment transaction service. */
	private PaymentDetailsService paymentDetailsService;

	public PayloadDTO process(PayloadDTO payloadDTO) {
		LOGGER.info("Inside PaymentDetailsProcessor process method");
		BillerPayResponseVO billerPayResponseVO = null;
		//PayloadDTO payloadDTO = new PayloadDTO();
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
				LOGGER.info("Before calling the EDMI services");				
				//Sending request to EDMI
				try{
					LOGGER.info("Before hitting edmi service");
					billerPayResponseVO = paymentDetailsService.getpaymentDetails(billerPayRequestVO);
					if(!billerPayResponseVO.getStatus().equalsIgnoreCase("SUCCESS")){
						billerPayResponseVO=new BillerPayResponseVO();
						billerPayResponseVO.setStatus(ExceptionMessages._160.getCode());
						billerPayResponseVO.setStatusDesc(ExceptionMessages._160.getMessage());
					}
					payloadDTO.setRequestVO(billerPayRequestVO);
					payloadDTO.setResponseVO(billerPayResponseVO);
					LOGGER.info("After getting response from edmi service");
				}catch (Exception e) {
					billerPayResponseVO=new BillerPayResponseVO();
					billerPayResponseVO.setStatus(ExceptionMessages._129.getCode());
					billerPayResponseVO.setStatusDesc(ExceptionMessages._129.getMessage());
					payloadDTO.setRequestVO(billerPayRequestVO);
					payloadDTO.setResponseVO(billerPayResponseVO);
					//LOGGER.error(e.getMessage());
					LOGGER.error("Exception occurred ::: ",e);
				}
		return payloadDTO;
	}
	
	
	
	/*public PayloadDTO process(PayloadDTO payloadDTO) {
		LOGGER.info("Inside PaymentDetailsProcessor process method");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();							
		LOGGER.info("Before calling the EDMI services");				
		//Sending request to EDMI
		try{
			LOGGER.info("Before hitting edmi service");
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO = paymentDetailsService.getpaymentDetails(billerPayRequestVO);
			LOGGER.info("After getting response from edmi service");
		}catch (Exception e) {
			LOGGER.error(e.getMessage());
			LOGGER.error("Exception occurred ::: ",e);
		}
		
		payloadDTO.setRequestVO(billerPayRequestVO);
		payloadDTO.setResponseVO(billerPayResponseVO);
			
		return payloadDTO;
	}*/
	


	public void setPaymentDetailsService(PaymentDetailsService paymentDetailsService) {
		this.paymentDetailsService = paymentDetailsService;
	}

}
