package com.scb.channels.payments.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.CustomerPaymentAmount;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentFieldDetails;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.PaymentMode;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.vo.ReferenceVO;
import com.scb.channels.payments.dao.PaymentDAO;
import com.scb.channels.payments.service.PaymentService;


public class PaymentServiceImpl implements PaymentService {
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentServiceImpl.class);
	
	
	private PaymentDAO paymentDAO;
	
	private ReferenceService referenceService;
	

	public CustomerPaymentAmountResponseVO getCustomerOverallPaymentAmount(
			CustomerPaymentAmountRequestVO paymentAmountRequestVO) {

		
		CustomerPaymentAmountResponseVO paymentAmountResponseVO = null;
	
		//PaymentVO paymentVO = BillpaymentMappingHelper.getCustomerTotalPaymentAmountRequestMapping(paymentAmountRequestVO);
		//Dozer is not required, as only few field mapping required.
		
		PaymentDetailVO paymentVO = new PaymentDetailVO();
		paymentVO.setCountryCode(paymentAmountRequestVO.getClientVO().getCountry());
		paymentVO.setCustomerId(paymentAmountRequestVO.getUser().getCustomerId());
		//paymentVO.setPaymentDate(DateUtils.getDateWithoutTime(paymentAmountRequestVO.getClientVO().getDate()));
		paymentVO.setPaymentDate(new Timestamp(paymentAmountRequestVO.getClientVO().getDate().getTimeInMillis()));
		PaymentMode paymentMode = paymentAmountRequestVO.getPaymentMode();
	   	paymentVO.setPaymentType(paymentMode.getPaymentType());
		paymentVO.setPaymentOption(paymentMode.getPaymentOption());
		
		ReferenceVO referenceVO = new ReferenceVO();
		
		referenceVO.setCountryCode(paymentAmountRequestVO.getClientVO().getCountry());
		referenceVO.setChannelId(paymentAmountRequestVO.getClientVO().getChannel());
		referenceVO.setType(CommonConstants.BILL_PAYMENT);
		
		try{
			
			String transactionStatus = referenceService.getReferenceMap(referenceVO).get(paymentAmountRequestVO.getServiceVO().getServiceName());
			
			LOGGER.info("CustomerTotalPaymentAmountRequestVO transactionStatus-{}",new Object[] {transactionStatus});
		
			//double totalPaymentAmount = paymentDAO.getCustomerOverallPaymentAmount(paymentAmountRequestVO);
			
			double totalPaymentAmount = paymentDAO.getCustomerOverallPaymentAmount(paymentVO, transactionStatus);
			paymentAmountResponseVO = new CustomerPaymentAmountResponseVO();	
			CustomerPaymentAmount amount = new CustomerPaymentAmount();
			paymentAmountResponseVO.setStatus(Messages._0.getCode());
			paymentAmountResponseVO.setStatusDesc(Messages._0.getMessage());
			amount.setTotalPaymentAmount(totalPaymentAmount);
			paymentAmountResponseVO.setPaymentAmount(amount);
			
		}catch(Exception e){
			LOGGER.error("getCustomerTotalPaymentAmount Error", e);
			paymentAmountResponseVO = new CustomerPaymentAmountResponseVO();			
			paymentAmountResponseVO.setStatus(Messages._1.getCode());
			paymentAmountResponseVO.setStatusDesc(Messages._1.getMessage());
		}
		
		return paymentAmountResponseVO;	
	}

	@Override
	public List<PaymentDetailVO> getCustPaymentHistoryById(
			PaymentHistoryRequestVO paymentyHistoryRequestVO) {
		List<PaymentDetailVO> paymentResObj = null;
		LOGGER.info("Inside PaymentServiceImpl :: getCustPaymentHistoryById :: Start"+paymentyHistoryRequestVO.getMessageVO().getReqID());
		try {

			LOGGER.info("getPaymentHistoryByCustId into DB {}}",
					new Object[] { paymentyHistoryRequestVO.getUser()
							.getCustomerId() });

			paymentResObj = paymentDAO.getPaymentHistoryByCustId(paymentyHistoryRequestVO);

			LOGGER.info("At service class after DB Fetch getPaymentHistoryByCustId {}}",new Object[] {paymentResObj});

			if (!CollectionUtils.isEmpty(paymentResObj)) {
				return changePaymentStatus(paymentResObj);
			} else {
				return paymentResObj;
			}
		} catch (Exception e) {

			LOGGER.info("getPaymentHistoryByCustId Error" + e.getMessage());

			throw e;

		}

	}
	
	
	public List<PaymentDetailVO> changePaymentStatus(List<PaymentDetailVO> paymentRes) {
		LOGGER.info("At service class after DB Fetch changePaymentStatus {}}",new Object[] {paymentRes});
		
		List<PaymentDetailVO> statusModifiedPaymentList = new ArrayList<PaymentDetailVO>();
		
		for(PaymentDetailVO paymentDetail : paymentRes){
			if(CommonConstants.SUCCESS_PAYMENT_LIST.contains(paymentDetail.getPaymentStatus())){
				paymentDetail.setPaymentStatus(CommonConstants.SUCC);
			}else if(CommonConstants.FAIL_PAYMENT_LIST.contains(paymentDetail.getPaymentStatus())){
				paymentDetail.setPaymentStatus(CommonConstants.FAIL);
			}else{
				paymentDetail.setPaymentStatus(CommonConstants.SUBMITTED);
			}
			removeDuplicateFields(statusModifiedPaymentList, paymentDetail);
		}
		
		return statusModifiedPaymentList; 
	}

	/**
	 * @param statusModifiedPaymentList
	 * @param paymentDetail
	 */
	private void removeDuplicateFields(List<PaymentDetailVO> statusModifiedPaymentList, PaymentDetailVO paymentDetail) {
		List<String> duplicateVal=new ArrayList<String>();
		Set<PaymentFieldDetails> setFieldsP=new HashSet<PaymentFieldDetails>();
		for(PaymentFieldDetails field:paymentDetail.getPaymentFieldDetails()){
			if(field.getFieldType()!=null && field.getFieldType().equalsIgnoreCase(CommonConstants.P) && field.getFieldValue() !=null && !field.getFieldValue().isEmpty()){
				setFieldsP.add(field);
				duplicateVal.add(field.getFieldLabelName());
			}
		}
		Set<PaymentFieldDetails> setFieldsR=new HashSet<PaymentFieldDetails>();	
		for(PaymentFieldDetails field:paymentDetail.getPaymentFieldDetails()){
			String fieldName =field.getFieldLabelName();
			for(PaymentFieldDetails pmtFiled:setFieldsP){
				if(!fieldName.equalsIgnoreCase(pmtFiled.getFieldLabelName()) && field.getFieldType()!=null
						&& CommonConstants.R.equalsIgnoreCase(field.getFieldType()) && !duplicateVal.contains(fieldName)
						&& field.getFieldValue() !=null && !field.getFieldValue().isEmpty()){
					setFieldsR.add(field);
				}
			}
		}	
		setFieldsP.addAll(setFieldsR);
		paymentDetail.getPaymentFieldDetails().clear();
		paymentDetail.setPaymentFieldDetails(setFieldsP);
		statusModifiedPaymentList.add(paymentDetail);
	}

	
	public PaymentDAO getPaymentDAO() {
		return paymentDAO;
	}

	public void setPaymentDAO(PaymentDAO paymentDAO) {
		this.paymentDAO = paymentDAO;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}


	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}
	
}
