package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.payments.service.PaymentTransactionService;

public class ReferenceNumberSequenceProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentValidationProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;
	
	public PayloadDTO process(PayloadDTO bean) {
		
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
		PayloadDTO payloadDTO = new PayloadDTO(); 
		BillerPayDetailsVO billerPayDetailsVO = null;
		PaymentDetailVO paymentDetailVO=null;
		LOGGER.info("Task of ReferenceNumberSequenceProcessor ::: Start");
		try{
			if (billerPayRequestVO != null) {
				billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
					LOGGER.info("ReferenceNumberSequenceProcessor :: Before hitting  service");
					
					String referenceNumber = paymentTransactionService.getReferenceNumberSequence(billerPayRequestVO);
					//String ref=String.valueOf(referenceNumber);
					billerPayRequestVO.getBillerPayDetailsVO().setHostReference(referenceNumber);			
					LOGGER.info("ReferenceNumberSequenceProcessor :: After getting response from  service"+referenceNumber);
				    payloadDTO.setRequestVO(billerPayRequestVO);
				    payloadDTO.setResponseVO(billerPayResponseVO);
			}

			
		}catch(Exception e){
            billerPayResponseVO = new BillerPayResponseVO();
			
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			
			billerPayResponseVO.setStatus(ExceptionMessages._129.getCode());
			billerPayResponseVO.setStatusDesc(ExceptionMessages._129.getMessage());
			if(billerPayDetailsVO != null) {
				LOGGER.info("Setting billerPaydetails to response from request in exception :: " 
						+ billerPayDetailsVO.getPayRef());
				billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
			}
		    payloadDTO.setRequestVO(billerPayRequestVO);
			payloadDTO.setResponseVO(billerPayResponseVO);

			LOGGER.error("Exception while Reference Number Sequence  ::: " , e);
		}finally{
			LOGGER.error("Exception while Reference Number Sequence ::: ");
			
			
		}
		
		
		return payloadDTO;
		
		
	}
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
		
}
