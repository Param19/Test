package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentService;
import com.scb.channels.base.helper.Messages;

/**
 * This class contains Processor of GetCustomerTotalPaymentAmount
 *
 * @author 1317590
 */
public class CustomerPaymentAmountProcessor extends AbstractProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerPaymentAmountProcessor.class);

	private PaymentService paymentService;


	public PaymentService getPaymentService() {
		return paymentService;
	}


	public void setPaymentService(PaymentService paymentService) {
		this.paymentService = paymentService;
	}


	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		CustomerPaymentAmountRequestVO paymentAmountRequestVO = null;
		CustomerPaymentAmountResponseVO paymentAmountResponseVO = null;

		try {

			paymentAmountRequestVO = (CustomerPaymentAmountRequestVO) bean.getRequestVO();
			LOGGER.info("doTasks in GetCustomerTotalPaymentAmountProcessor {}-{}-{}-{}",new Object[] {paymentAmountRequestVO.getClientVO().getCountry(),paymentAmountRequestVO.getUser().getCustomerId()});
			paymentAmountResponseVO = paymentService.getCustomerOverallPaymentAmount(paymentAmountRequestVO);
		
			LOGGER.info("doTasks in paymentAmountResponseVO {}-{}-{}-{}",new Object[] {paymentAmountResponseVO.getPaymentAmount().getTotalPaymentAmount()});
			
			paymentAmountResponseVO.setUser(paymentAmountRequestVO.getUser());
			paymentAmountResponseVO.setClientVO(paymentAmountRequestVO.getClientVO());
			paymentAmountResponseVO.setMessageVO(paymentAmountRequestVO.getMessageVO());
			paymentAmountResponseVO.setServiceVO(paymentAmountRequestVO.getServiceVO());

			bean.setResponseVO(paymentAmountResponseVO);
			
		} catch (Exception e) {
			
			paymentAmountResponseVO = new CustomerPaymentAmountResponseVO();
			paymentAmountResponseVO.setMessageVO(paymentAmountRequestVO.getMessageVO());
			paymentAmountResponseVO.setUser(paymentAmountRequestVO.getUser());
			paymentAmountResponseVO.setServiceVO(paymentAmountRequestVO.getServiceVO());
			paymentAmountResponseVO.setClientVO(paymentAmountRequestVO.getClientVO());
			paymentAmountResponseVO.setStatus(Messages._1.getCode());
			paymentAmountResponseVO.setStatusDesc(Messages._1.getMessage());
			paymentAmountResponseVO.setErrorDesc(e.getMessage());
			paymentAmountResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			bean.setResponseVO(paymentAmountResponseVO);

		}
		return bean;
	}

}
