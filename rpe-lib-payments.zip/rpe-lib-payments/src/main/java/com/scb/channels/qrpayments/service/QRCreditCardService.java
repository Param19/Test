package com.scb.channels.qrpayments.service;

import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;

public interface QRCreditCardService {
	
	public QRPaymentResponseVO authorizeCreditCard(QRPaymentRequestVO qrPaymentRequest);
	
	public QRPaymentResponseVO reverseCardAuthorization(QRPaymentRequestVO qrPaymentRequest);
	
	public QRPaymentResponseVO authorizeCreditCardV2(QRPaymentRequestVO qrPaymentRequest);
	
	public QRPaymentResponseVO reverseCardAuthorizationV2(QRPaymentRequestVO qrPaymentRequest);
	

}
