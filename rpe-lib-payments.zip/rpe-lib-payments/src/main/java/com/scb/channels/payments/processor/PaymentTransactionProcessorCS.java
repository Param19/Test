package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentTransactionService;

/**
 * The Class PaymentTransactionProcessor.
 */
public class PaymentTransactionProcessorCS extends AbstractProcessor{

    /** The payment transaction service. */
    private PaymentTransactionService paymentTransactionService;
    
    /** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentTransactionProcessorCS.class);
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in PaymentTransactionProcessorCS ::::: Start");
		if(bean!=null && bean.getRequestVO()!=null){
			BillerPayRequestVO billerPayRequestVO =(BillerPayRequestVO) bean.getRequestVO();
			try{
				LOGGER.info("Transaction details update :: PaymentTransactionProcessorCS");
				TransactionInfoVO transationInfoVO = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO();
				transationInfoVO.setDtCreated(DateUtils.getCurrentDate());
				transationInfoVO.setCreatedBy(billerPayRequestVO.getUser().getCustomerId());
				transationInfoVO.setDtUpd(transationInfoVO.getDtCreated());
				transationInfoVO.setUpdBy(billerPayRequestVO.getUser().getCustomerId());
				transationInfoVO.setClientVO(billerPayRequestVO.getClientVO());
				transationInfoVO.setUserVO(billerPayRequestVO.getUser());
				transationInfoVO.setMessageVO(billerPayRequestVO.getMessageVO());
				transationInfoVO.setTxnMode(CommonConstants.IMMD);
				transationInfoVO.setTxnTypeCd(CommonConstants.BILL);
				transationInfoVO.setTxnStatusCd(CommonConstants.SUCC);
				transationInfoVO.setDtTransfer(DateUtils.getCurrentDate());
				LOGGER.info("saving payment of payee :: PaymentTransactionProcessorCS" + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				Long paymentId = paymentTransactionService.savePaymentCS(billerPayRequestVO.getBillerPayDetailsVO());
				LOGGER.info("payment saved for payee :: PaymentTransactionProcessorCS" + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				if(paymentId != null && paymentId != 0L
						&& !CommonConstants.FAIL.equalsIgnoreCase(billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus())){
					billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.SAVE_SUCCESS);
				} else {
					billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.SAVE_FAIL);
				}
			} catch (Exception e) {
				LOGGER.error("Exception occurred whle saving payments ::: PaymentTransactionProcessorCS :: " , e);
				LOGGER.error("Exception occurred whle saving payments ::: PaymentTransactionProcessorCS :: " + e);
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.SAVE_FAIL);
				LOGGER.error(e.getMessage());
				throw new BusinessException(e.getMessage(), e.getCause());
			}
			BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			bean.setResponseVO(billerPayResponseVO);
		}
		LOGGER.info("Task in Transaction Processor ::::: PaymentTransactionProcessorCS :: End");
		return bean;
	}
	
	/**
	 * Sets the payment transaction service.
	 *
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
}
