package com.scb.channels.payments.service;

import java.util.List;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;

/**
 * @author 1521723
 *
 */
public interface PayeeManagementService {
	
	
	/**
	 * perfom Add Biller.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the biller pay response vo
	 */
		
	
	BillerPayResponseVO addPayee(BillerPayRequestVO billerPayRequestVO);
	
	/**
	 * perfom delete Biller.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the biller pay response vo
	 */
	BillerPayResponseVO deletePayee(BillerPayRequestVO billerPayRequestVO);
	
	
	/**
	 * @param billerPayRequestVO
	 * @return
	 */
	BillerPayResponseVO checkIsPayeeExists(BillerPayRequestVO billerPayRequestVO);

	
	BillerPayResponseVO checkIsPayeeExistsHK(BillerPayRequestVO billerPayRequestVO);

	/**
	 * @param billerPayRequestVO
	 * @return
	 */
	ViewPayeeResponseVO viewPayeeList(ViewPayeeRequestVO viewPayeeRequestVO);
	
	/**
	 * @param billerPayRequestVO
	 * @return
	 */
	ViewPayeeResponseVO viewPayeeListHK(ViewPayeeRequestVO viewPayeeRequestVO);
	
	/**
	 * @param billerPayRequestVO
	 * @return
	 * @throws Exception
	 */
	BillerPayResponseVO validatePayee(BillerPayRequestVO billerPayRequestVO) throws Exception;
	/**
	 * @param billerPayRequestVO
	 * @return
	 */
	BillerPayResponseVO updatePayee(BillerPayRequestVO billerPayRequestVO);
	
	/**
	 * @param PayeeDetailsVO
	 * @return
	 */
	boolean updatePayeeStatus(PayeeDetailVO PayeeDetailsVO);
	
	/**
	 * @param countryCode
	 * @return
	 */
	boolean terminateInactivePayee(String countryCode);
	
	/**
	 * @param bean
	 * @return
	 */
	void validatePayeeRpeCs(PayloadDTO bean);
	
	/**
	 * @param bean
	 * @return
	 */
	void addPayeeCS(PayloadDTO bean);
	
	
	/**
	 * @param viewPayeeRequestVO
	 * @return
	 */
	ViewPayeeResponseVO viewPayeeListCS(ViewPayeeRequestVO viewPayeeRequestVO);
	
	/**
	 * @param billerUniqueId
	 * @param cntry
	 * @return
	 */
	public BillerVO getUniqueBillerId(PayloadDTO payloadDTO) ;
	
    //Added for Orange Money 
	void addPayeeWallet(PayloadDTO bean);
	
	BillerPayResponseVO deleteWalletPayee(BillerPayRequestVO billerPayRequestVO);
	
	ViewPayeeResponseVO viewWalletPayeeList(ViewPayeeRequestVO viewPayeeRequestVO);
	
	void validateWalletPayeeRpeCS(PayloadDTO bean);
	
	List<PayeeDetailVO> getWalletPayee(BillerPayRequestVO billerPayRequestVO);
	
	BillerPayResponseVO deleteWalletPayeeBO(BillerPayRequestVO billerPayRequestVO);
	
	BillerPayResponseVO addWalletPayeeBO(BillerPayRequestVO billerPayRequestVO);
	
	public String getCommonSequenceNumberGenerator();
	
	public BillerVO getWalletUniqueBillerId(PayloadDTO payloadDTO) ;
	
}
