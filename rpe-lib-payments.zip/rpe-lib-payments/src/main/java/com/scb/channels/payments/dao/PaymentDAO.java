package com.scb.channels.payments.dao;

import java.util.List;

import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;

public interface PaymentDAO {
	
	/**
	 * Gets the getCustomerOverallPaymentAmount.
	 *
	 * @param PaymentDetailVO
	 * @return the total amount
	 */
	public double getCustomerOverallPaymentAmount(PaymentDetailVO detailVO, String status);
		
	public void savePayment(PaymentDetailVO paymentVO);
	
	public void updatePaymentStatus(PaymentDetailVO paymentVO);
		
	public List<PaymentDetailVO> getPaymentHistoryByCustId(PaymentHistoryRequestVO paymentyHistoryRequestVO);

	
	
	

}
