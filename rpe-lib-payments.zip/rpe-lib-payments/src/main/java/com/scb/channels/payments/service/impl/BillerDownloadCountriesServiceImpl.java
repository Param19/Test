package com.scb.channels.payments.service.impl;

import org.apache.commons.lang.StringUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.common.dao.VariableDAO;
import com.scb.channels.common.vo.VariablesVO;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.service.BillerDownloadCountriesService;

public class BillerDownloadCountriesServiceImpl implements BillerDownloadCountriesService {


	/**	variableDao for variable **/
	private VariableDAO   variable;
	
	@Override
	public String getBillerDownloadCountries() {
		String countries=null;

		VariablesVO variablevalue =variable.getValuefromkey(null,null,CommonConstants.BILLER_DOWNLOAD_COUNTRIES);
			if(StringUtils.isNotBlank(variablevalue.getVariableValue())){
				countries=variablevalue.getVariableValue();
			}
			return countries;
	}


	
	public VariableDAO getVariable() {
		return variable;
	}
	public void setVariable(VariableDAO variable) {
		this.variable = variable;
	}


}
