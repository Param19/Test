package com.scb.channels.payments.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.payments.dao.BillerManagementDAO;
import com.scb.channels.payments.service.CacheManagementService;

public class CacheManagementServiceImpl implements CacheManagementService {

	
	/**
	 * EH cachemanager service
	 */
	private CacheManager cacheManager;

	
	private BillerManagementDAO billerManageDAO;
	

	private static final Logger LOGGER = LoggerFactory.getLogger(CacheManagementServiceImpl.class);
	
	private DataBean dataBean;


	@Override
	public List<BillerCategoryVO> getBillers(String Country) {
		List<BillerCategoryVO>  categoryList=null;
		
		LOGGER.debug("Fetching BILLER CATEGORY LIST   {} ", new Object[] {Country});
		if(cacheManager.getCache(CommonConstants.BILLER_CACHE).get(Country+CommonConstants.BILLER_CATEGORY_LIST)==null){
			LOGGER.debug("Calling DB due to no Billers Available on  cache  ");
			  categoryList=billerManageDAO.getActiveBillerCategories(Country);
			 // if(!Country.equalsIgnoreCase(CommonConstants.NG))
			/*for (BillerCategoryVO billerCategoryVO : categoryList) {
				Set<BillerVO> billerList = billerCategoryVO.getBillers();
				for (BillerVO billerVO : billerList) {
					Set<BillerField> billerFieldList = billerVO.getBillerFields();
					Set<BillerField> billerFieldListToRemove = new HashSet<BillerField>();
					for (BillerField billerField : billerFieldList) { 
						if(billerField.getFieldType()!=null && !billerField.getFieldType().equalsIgnoreCase(CommonConstants.N)){
							Integer presentment=Integer.parseInt(billerVO.getBillPresentmentType());
							if(presentment<=0){
								// Need to add this scenarios
							}else{
								billerFieldListToRemove.add(billerField);	
							}
					}
					}
					billerFieldList.removeAll(billerFieldListToRemove);
				}
			}*/
		  if(categoryList !=null && categoryList.size()>0){
				  LOGGER.debug("getting  the Biller categories  into DB");
				  cacheManager.getCache(CommonConstants.BILLER_CACHE).put(new Element(Country+CommonConstants.BILLER_CATEGORY_LIST , categoryList));
			  }else{
				  LOGGER.debug("No BILLER categories  AVAILABLE in DB as well");
			  }
			  
			
		}else{
			LOGGER.debug("BILLER categories  AVAILABLE in Cache");
			categoryList =(List<BillerCategoryVO>)cacheManager.getCache(CommonConstants.BILLER_CACHE).get(Country+CommonConstants.BILLER_CATEGORY_LIST).getValue();
		}
		
		
		return categoryList;
	}
	
	public Map<String,ApplicationMessageVO> getCustomizedMessages(String country,String channel){
		Map<String, ApplicationMessageVO> mapFromDB = null;
		LOGGER.debug("Fetching getCustomizedMessages   {} ", new Object[] {country});
		if(cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(country+channel+CommonConstants.APPLICATION_MESSAGE)==null){
			
			LOGGER.debug("Fetch the messages from DB -- DB Call Start channel "+channel);
			
			mapFromDB=billerManageDAO.getApplicationMessages(country,channel);
			  
			  if(mapFromDB != null && mapFromDB.size() > 0){
				  LOGGER.debug("Got Messages from DB and put it into CACHE" );
				  cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).put(new Element(country+channel+CommonConstants.APPLICATION_MESSAGE , mapFromDB));
			  }else{
				  LOGGER.debug("Customized Message not  AVAILABLE in DB");
			  }
		}else{
			LOGGER.debug("Customized Application Messages  AVAILABLE in Cache");
			mapFromDB =( Map<String, ApplicationMessageVO>)cacheManager.getCache(CommonConstants.APPLICATION_MESSAGE_CACHE).get(country+channel+CommonConstants.APPLICATION_MESSAGE).getValue();
		}
		
		return mapFromDB;
		
	}

	
	public CacheManager getCacheManager() {
		return cacheManager;
	}

	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}
	
	public BillerManagementDAO getBillerManageDAO() {
		return billerManageDAO;
	}


	public void setBillerManageDAO(BillerManagementDAO billerManageDAO) {
		this.billerManageDAO = billerManageDAO;
	}


	@Override
	public void clearBillerCache(String country) {
		
		
		if(cacheManager.getCache(CommonConstants.BILLER_CACHE).get(country+CommonConstants.BILLER_CATEGORY_LIST)!=null){
			
			cacheManager.getCache(CommonConstants.BILLER_CACHE).remove(country+CommonConstants.BILLER_CATEGORY_LIST);
			LOGGER.info("Biller cache deleted from the cache managment");
			
		}
		
		
	}
	
	
	
	// Narration Configuration - Start
	
	
	@Override
	public List<NarrationVO> getNarration(String country, String channel) {
		List<NarrationVO>  narrationList=null;
		
		LOGGER.debug("Fetching NARRATION LIST   {} ", new Object[] {country, channel});
		if(cacheManager.getCache(CommonConstants.NARRATION_CACHE).get(country+channel+CommonConstants.NARRATION_LIST)==null){
			
			LOGGER.debug("Calling DB due to no Narration Configuration Available on  cache  ");
			
			narrationList=billerManageDAO.getNarrationConfig(country,channel);
			  
			  if(narrationList !=null && narrationList.size()>0){
				  LOGGER.debug("setting  the Narration Configuration into CACHE");
				  cacheManager.getCache(CommonConstants.NARRATION_CACHE).put(new Element(country+channel+CommonConstants.NARRATION_LIST , narrationList));
				  LOGGER.debug("setting  the Narration Configuration into CACHE done");
			  }else{
				  LOGGER.debug("No Narration Configuration AVAILABLE in DB as well");
			  }
			  
			
		}else{
			LOGGER.debug("Narration Configuration AVAILABLE in Cache");
			narrationList =(List<NarrationVO>)cacheManager.getCache(CommonConstants.NARRATION_CACHE).get(country+channel+CommonConstants.NARRATION_LIST).getValue();
		}
		
		
		return narrationList;
	}
	
	// Narration Configuration - End
	
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	// Added for Orange Money - start
	
		public List<BillerCategoryVO> getWalletBillers(String Country, String Category) {
	        List<BillerCategoryVO>  categoryList=null;
	        
	        LOGGER.debug("Fetching BILLER WALLET CATEGORY LIST   {} ", new Object[] {Country});
	        if(cacheManager.getCache(CommonConstants.BILLER_CACHE).get(Country+CommonConstants.WALLET_SERVICE+CommonConstants.BILLER_CATEGORY_LIST)==null){
	               LOGGER.debug("Calling DB due to no Billers Available on  cache  ");
	                 categoryList=billerManageDAO.getBillerCategories(Country, Category);
	        
	          if(categoryList !=null && categoryList.size()>0){
	                       LOGGER.debug("getting  the Biller WALLETcategories  into DB");
	                       cacheManager.getCache(CommonConstants.BILLER_CACHE).put(new Element(Country+CommonConstants.WALLET_SERVICE+CommonConstants.BILLER_CATEGORY_LIST , categoryList));
	                 }else{
	                       LOGGER.debug("No BILLER WALLET categories  AVAILABLE in DB as well");
	                 }
	                 
	               
	        }else{
	               LOGGER.debug("BILLER WALLET categories AVAILABLE in Cache");
	               categoryList =(List<BillerCategoryVO>)cacheManager.getCache(CommonConstants.BILLER_CACHE).get(Country+CommonConstants.WALLET_SERVICE+CommonConstants.BILLER_CATEGORY_LIST).getValue();
	        }
	                     
	        return categoryList;
	 }

}
