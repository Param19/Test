
package com.scb.channels.payments.service.impl;


import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.JobsVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.dao.VariableDAO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.vo.VariablesVO;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.BillerDownloadRequestCreateService;

public class BillerDownloadRequestCreateServiceImpl implements BillerDownloadRequestCreateService  {
	
	/**	variableDao for variable **/
	private VariableDAO   variableDAO;
	
	public BillerDownloadDAO billerDownloadDAO;
	

	/** LOGGER object * */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadRequestCreateServiceImpl.class);
	
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.BillerDownloadRequestCreateService#getRequestforCountry(java.lang.String)
	 */
	public PayloadDTO getRequestforCountry(PayloadDTO dto) throws BusinessException{
		
		String country = dto.getRequestVO().getClientVO().getCountry();
		LOGGER.info("billerDownload Started for country  --  "+country);
		Boolean JobStatus=false;
		
		String billerDownloadIsDisbaled=null;
		
		BillerDownloadRequest request= new BillerDownloadRequest();
		
		billerDownloadIsDisbaled=getVariableValue(country, CommonConstants.BILLERDOWNLOAD_DISABLE);
		
		if(CommonConstants.YES.equalsIgnoreCase(billerDownloadIsDisbaled)){
			request.setDownloadJobStatus(CommonConstants.N);
			LOGGER.info("Biller Download is disabled for this country force flag   ->  "+country);
			LOGGER.info("final Job Status"+request.getDownloadJobStatus());
			dto.setRequestVO(request);
			return dto;
		}
		
		
		JobStatus=getBillerDownloadJobStatus(country);
		
		if(JobStatus){
			request.setDownloadJobStatus(CommonConstants.YES);
			LOGGER.info("Job Status"+request.getDownloadJobStatus());
		}else{
 			
			request.setDownloadJobStatus(CommonConstants.N);
			LOGGER.info("Job Status"+request.getDownloadJobStatus());
			dto.setRequestVO(request);
			return dto;
		}
		
		LOGGER.info("Biller download Job is running for  ->  "+country);
		request.setChannelName(CommonConstants.IBANK);
		UserVO user= new UserVO();
		user.setCountry(country);
		user.setChannelId(CommonConstants.BILLER_DOWNLOAD);
		request.setUser(user);
		ClientVO client= new ClientVO();
		client.setCountry(country);
		client.setVersion(CommonConstants.PAYLOAD_API_21);//2.0
		request.setClientVO(client);
		MessageVO message= new MessageVO();
		
		message.setRequestType(CommonConstants.SYNC);
		message.setReqID(InvoiceAggregatorhelper.getFrequentGenerateUniqueId());
		request.setMessageVO(message);
		ServiceVO service= new ServiceVO();
		service.setServiceName(CommonConstants.BILLER_DOWNLOAD);
		service.setServiceTxnType(CommonConstants.BILLER_DOWNLOAD);
		request.setServiceVO(service);
		String CaptureSystem=getVariableValue(country,CommonConstants.CAPTURE_SYSTEM);
		
		request.setCaptureSystem(CaptureSystem);
		request.setAggregatorName(CaptureSystem);
		request.setSubDomainType(CommonConstants.EDMI_GETBILLERS_NAME);
		request.setTypeName(CommonConstants.INVOICE_NAME);
		request.setMessageSender(CommonConstants.IBANK);
		request.setDomainName(CommonConstants.DOMAIN_NAME_AGG);
		request.setPayloadFormat(CommonConstants.XML);
		request.setSubTypeName(CommonConstants.AGG_BILLER_CATEGORIES);
		request.setMessageSender(CommonConstants.IBANK);
		//request.setAggregatorTerminalId("3STC0001");
		request.setAggregatorTerminalId(getVariableValue(country,CommonConstants.BILLERDOWNLOAD_TERMINAL_ID));
		request.setAggregatorShortCode(getVariableValue(country,CommonConstants.AGGEREGATOR_SHORT_CODE));
		request.setBillerDownloadCategoryType(getVariableValue(country, CommonConstants.BILLER_DOWNLOAD_CATEGORY_TYPE));
		request.setApplicationUserID(getVariableValue(country,CommonConstants.Biller_DOWNLOAD_ApplicationUserID));
		request.setApplicationUserKey(getVariableValue(country,CommonConstants.Biller_DOWNLOAD_ApplicationUserKey));
		request.setDefaultBillerField(getVariableValue(country,CommonConstants.DEFAULT_BILLER_LABEL));
		request.setAggregatorIdentifier(getVariableValue(country,CommonConstants.AggregatorIdentifier));
		
		
		if(!StringUtils.isNotBlank(request.getBillerDownloadCategoryType())){
			LOGGER.info("type of categories retriving from the Aggregator is Null");
			throw new  BusinessException("Need to be configured in DB  for type of category");
		}
		
		dto.setRequestVO(request);
		return dto;

	}
	
	@Override
	public  String getVariableValue(String CountryCode,String variableKey){
		String variableValue=null;
		try{
		VariablesVO variable = variableDAO.getValuefromkey(CountryCode, null, variableKey);
		LOGGER.info("requested varible Key -  "+variableKey);
		if(variable!=null){
				if(StringUtils.isNotBlank(variable.getVariableValue())){
					variableValue=variable.getVariableValue();
					LOGGER.info("value for  varible Key -  "+variableKey +"   is   "+ variableValue);

				}
			
			}
		}catch(Exception  e){
			LOGGER.info("got exception for intial values"+e.getMessage());
			e.printStackTrace();
		}
		
		return variableValue;
	}
	
	
	public Boolean getBillerDownloadJobStatus(String Country){
		
		String JobName=CommonConstants.BILLER_DOWNLOAD;
		String JvmName=InvoiceAggregatorhelper.getJVMName();
	
		try{
		JobsVO job  =	billerDownloadDAO.getJobDetails(Country, JobName);
			
			if(job==null){
			job=preareIntialStatus(Country);
			billerDownloadDAO.saveInitialJob(job);
			return true;
			
			}else{
				
				LOGGER.info("BillerDownloadJob status is "+job.getStatus());

			if(job.getStatus().equalsIgnoreCase(CommonConstants.BILLER_DOWNLOAD_COMPLETED)){
				
				/*if(checkIsSameDate(new Date(job.getJobLastUpdated().getTime()))){*/
					
					int updatedCount=billerDownloadDAO.updateBillerJobProgress(job,JvmName);
					LOGGER.info("updatedCount"+updatedCount);

						if(updatedCount>0){
							LOGGER.info("Jobstatus is true");

							return true;
						}else{
							LOGGER.info("Jobstatus is flase");
							return false;
						}
					
					/*}else{
						
						return false;
					}*/
				 
				
				
			}else if(job.getStatus().equalsIgnoreCase(CommonConstants.BILLER_DOWNLOAD_IN_PROGRESS)){
				
 
				/*if(checkIsSameDate(new Date(job.getJobLastUpdated().getTime()))){*/
					
					int updatedProgressCount=billerDownloadDAO.updateBillerJobProgress(job,JvmName);
					
					
					LOGGER.info("updatedProgressCount"+updatedProgressCount);
						if(updatedProgressCount>0){
							
							LOGGER.info("Jobstatus is true");
							return true;
						}else{
							LOGGER.info("Jobstatus is flase");
							return false;
						}
					
					/*}else{
						
					return false;
					}*/
			
			
			} else{
 				
			}
				
			LOGGER.debug("other  Job Status  present in the DB "+job.getStatus());
			}
		}catch(Exception error){
			
			error.printStackTrace();
			LOGGER.debug("Error while getting job status "+error.getMessage());
			
		}
		
		return false;
	}
	
	
	public Boolean checkIsSameDate(Date jobdate){
		
		try{
			
			int iJobFragmentInMin = (int)DateUtils.getFragmentInMinutes(jobdate, Calendar.DATE);
			LOGGER.info("last Job ran on "+jobdate);
			LOGGER.info("Job Fragment in Minutes "+iJobFragmentInMin);
			
			int DateFragmentInMint = (int)DateUtils.getFragmentInMinutes(new Date(System.currentTimeMillis()), Calendar.DATE);
			LOGGER.info("new Date(System.currentTimeMillis()) is : " + new Date(System.currentTimeMillis()));
			LOGGER.info("Job difference in minutes DateFragmentInMint is "+DateFragmentInMint);
			
			int runFrequency = Integer.parseInt(getVariableValue(null,CommonConstants.BILLER_DOWNLOAD_FREQUENCY_TIME_IN_MINUTES));
			LOGGER.info("Job runFrequency :::" + runFrequency);
			
			if (!DateUtils.isSameDay(jobdate, new Date(System.currentTimeMillis()))){
				LOGGER.info("Comapring the Jobs which ran in Different Date");
				
				int iMaxMintPerDay = Integer.parseInt(CommonConstants.MAX_MINT_PER_DAY);
				
				int iDiffMintDiffDay = iMaxMintPerDay - iJobFragmentInMin;
				System.out.println(("Job difference iDiffMintDiffDay in minutes is "+iDiffMintDiffDay));
				
				int iTotalDiffrMintDiffDay = iDiffMintDiffDay + DateFragmentInMint;
				System.out.println(("Job difference iTotalDiffrMintDiffDay in minutes is "+iTotalDiffrMintDiffDay));
				
				if(iTotalDiffrMintDiffDay >= runFrequency){
					LOGGER.info("Job difference in time is valid ahead the expected time for Different Date");
					return true;
				}else{
					LOGGER.info("Job difference in time is  less so it is false for Different Date");
					return false;
				} 
				
			}
			else {
				
				int iTotalDiffrMintSameDay = DateFragmentInMint - iJobFragmentInMin;
				LOGGER.info("iTotalDiffrMintSameDay : "+ iTotalDiffrMintSameDay + "DateFragmentInMint :: "+ DateFragmentInMint + " iJobFragmentInMin ::  "+ iJobFragmentInMin);
				
				if(iTotalDiffrMintSameDay >= runFrequency){
					LOGGER.info("Job difference in time is valid ahead the expected time for Same Date");
					return true;
				}else{
					LOGGER.info("Job difference in time is  less so it is false for Same Date");
					return false;
				} 
				
			}

		}catch(Exception e){
			e.printStackTrace();
			LOGGER.info("Error checking thw Job difference in time "+e.getMessage());
			return false;
		}
		
	}
	
	
	public JobsVO preareIntialStatus(String Country){
		JobsVO job= new JobsVO();
		String JvmName=InvoiceAggregatorhelper.getJVMName();
		LOGGER.info("jvm Name is  ----   "+JvmName);
		job.setJobName(CommonConstants.BILLER_DOWNLOAD);
		job.setCountryCode(Country);
		job.setJvmName(JvmName);
		job.setStatus(CommonConstants.BILLER_DOWNLOAD_IN_PROGRESS);
		job.setJobDescription(CommonConstants.BILLER_DOWNLOAD);
		job.setJobLastUpdated(new Timestamp(System.currentTimeMillis()));
	
		return job;
	}
	
	
	public VariableDAO getVariableDAO() {
		return variableDAO;
	}


	public void setVariableDAO(VariableDAO variableDAO) {
		this.variableDAO = variableDAO;
	}
	
	public BillerDownloadDAO getBillerDownloadDAO() {
		return billerDownloadDAO;
	}

	public void setBillerDownloadDAO(BillerDownloadDAO billerDownloadDAO) {
		this.billerDownloadDAO = billerDownloadDAO;
	}

}
