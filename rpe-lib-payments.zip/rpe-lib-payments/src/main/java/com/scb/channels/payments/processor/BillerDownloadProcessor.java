package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.BillerDownloadCheckService;
import com.scb.channels.payments.service.BillerDownloadProcessService;
import com.scb.channels.payments.service.impl.BillerDownloadCheckServiceImpl;

/**
 * @author 1460693
 * 
 * Processing the Biller Download from Aggregators
 *
 */
public class BillerDownloadProcessor extends AbstractProcessor  {
	
BillerDownloadProcessService billerDownloadProcessorService;
	 
	/**  Logger Object **/
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadCheckServiceImpl.class);
	@Override
	
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		 
		try{
			LOGGER.info("biller DownloadStarted");
			PayloadDTO dto=billerDownloadProcessorService.getDataFromAggregator(bean);
			LOGGER.info("biller Download Completed");
			LOGGER.info("biller Download status"+dto.getRequestVO().getStatus());
			
		}catch(Exception e){
			LOGGER.info("BILLER DOWNLOAD FAILED "+bean.getRequestVO().getUser().getCountry());
			LOGGER.info("Biller Downlaod Failed at service Level");
			bean.getRequestVO().setStatus(CommonConstants.FAIL);;
		}
		return bean;
	}
	
	public BillerDownloadProcessService getBillerDownloadProcessorService() {
		return billerDownloadProcessorService;
	}
	public void setBillerDownloadProcessorService(
			BillerDownloadProcessService billerDownloadProcessorService) {
		this.billerDownloadProcessorService = billerDownloadProcessorService;
	}
}