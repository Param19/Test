package com.scb.channels.payments.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.AlipayMappingHelper;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.PaymentDetailsService;

/**
 * The Class PaymentTransactionServiceImpl.
 */
public class PaymentDetailsServiceImpl implements PaymentDetailsService {

	/** The invoice port type. */
	private InvoicePortType invoicePortType;
	private com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType invoicePortTypeV2;

	/**
	 * @return the invoicePortTypeV2
	 */
	public com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType getInvoicePortTypeV2() {
		return invoicePortTypeV2;
	}

	/**
	 * @param invoicePortTypeV2
	 *            the invoicePortTypeV2 to set
	 */
	public void setInvoicePortTypeV2(com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType invoicePortTypeV2) {
		this.invoicePortTypeV2 = invoicePortTypeV2;
	}

	private DataBean dataBean;

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentDetailsServiceImpl.class);

	public BillerPayResponseVO getpaymentDetails(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("Inside PaymentDetailsServiceImpl:: getpaymentDetails --Start "+billerPayRequestVO.getMessageVO().getReqID());

		billerPayRequestVO.getBillerPayDetailsVO().setApplicationUserID(dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.Biller_DOWNLOAD_ApplicationUserID));
		billerPayRequestVO.getBillerPayDetailsVO().setApplicationUserKey(
				dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.Biller_DOWNLOAD_ApplicationUserKey));
		String aggregatorIdentifier=dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.AggregatorIdentifier);
		GetPaymentDetailsReq getPaymentDetailsRequest = BillpaymentMappingHelper.performPaymentDetailsInvoiceRequestPayload(billerPayRequestVO,aggregatorIdentifier);
		GetPaymentDetailsRes getPaymentDetailsResponse = invoicePortType.getPaymentDetails(getPaymentDetailsRequest);
		LOGGER.info("Inside PaymentDetailsServiceImpl:: getpaymentDetails :: Got Edmi response "+billerPayRequestVO.getMessageVO().getReqID());
		BillerPayResponseVO billerPayResponseVO = BillpaymentMappingHelper.getPaymentDetailsInvoiceResponse(getPaymentDetailsResponse,billerPayRequestVO);
		LOGGER.info("Inside PaymentDetailsServiceImpl:: getpaymentDetails --End "+billerPayRequestVO.getMessageVO().getReqID());
		return billerPayResponseVO;
	}

	@Override
	public BillerPayResponseVO validateWallet(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("Inside PaymentDetailsServiceImpl :: validateWallet--Start");
		// Credentials has to change as per ALipay
		billerPayRequestVO.getBillerPayDetailsVO().setApplicationUserID(
				dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.Biller_DOWNLOAD_ApplicationUserID));
		billerPayRequestVO.getBillerPayDetailsVO().setApplicationUserKey(
				dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.Biller_DOWNLOAD_ApplicationUserKey));

		com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsReq getPaymentDetailsRequest = AlipayMappingHelper
				.validateWalletDetatilsRequestWraper(billerPayRequestVO);
		
		LOGGER.info("Before sending Request to EDMI");
		com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentDetailsRes getPaymentDetailsResponse =
		 invoicePortTypeV2.getPaymentDetails(getPaymentDetailsRequest);
		 LOGGER.info(" getPaymentDetailsRes " + getPaymentDetailsResponse);
		LOGGER.info("After getting response from EDMI");
		BillerPayResponseVO billerPayResponseVO =  AlipayMappingHelper.validateWalletDetatilsResponseWraper(getPaymentDetailsResponse,billerPayRequestVO);
		//BillerPayDetailsVO v=new BillerPayDetailsVO();
		//billerPayResponseVO.setBillerPayDetailsVO(v);
		//LOGGER.info("Response mapping done");
		//billerPayResponseVO.setStatus("SUCCESS");
		LOGGER.info("Inside PaymentDetailsServiceImpl :: validateWallet--End");
		return billerPayResponseVO;
	}

	public void setInvoicePortType(InvoicePortType invoicePortType) {
		this.invoicePortType = invoicePortType;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
	// Added for Orange Money 
	public BillerPayResponseVO getpaymentWalletDetails(BillerPayRequestVO billerPayRequestVO,String fieldsDelimitedStr) {
		LOGGER.info("Inside PaymentDetailsServiceImpl:: getpaymentDetails --Start "+billerPayRequestVO.getMessageVO().getReqID());

		billerPayRequestVO.getBillerPayDetailsVO().setApplicationUserID(dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.Biller_DOWNLOAD_ApplicationUserID));
		billerPayRequestVO.getBillerPayDetailsVO().setApplicationUserKey(
				dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.Biller_DOWNLOAD_ApplicationUserKey));
		String aggregatorIdentifier=dataBean.getMap().get(billerPayRequestVO.getUser().getCountry() + CommonConstants.AggregatorIdentifier);
		GetPaymentDetailsReq getPaymentDetailsRequest = BillpaymentMappingHelper.performPaymenWallettDetailsInvoiceRequestPayload(billerPayRequestVO,aggregatorIdentifier,fieldsDelimitedStr);
		String str = CommonHelper.getXML(getPaymentDetailsRequest, 
				GetPaymentDetailsReq.class, "getPaymentDetails");
		//System.out.println(str);
		GetPaymentDetailsRes getPaymentDetailsResponse = invoicePortType.getPaymentDetails(getPaymentDetailsRequest);
		LOGGER.info("Inside PaymentDetailsServiceImpl:: getpaymentDetails :: Got Edmi response "+billerPayRequestVO.getMessageVO().getReqID());
		BillerPayResponseVO billerPayResponseVO = BillpaymentMappingHelper.getPaymentDetailsInvoiceResponse(getPaymentDetailsResponse,billerPayRequestVO);
		//LOGGER.info("Inside PaymentDetailsServiceImpl:: getpaymentDetails --End "+billerPayRequestVO.getMessageVO().getReqID());
		return billerPayResponseVO;
	}

}
