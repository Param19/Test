package com.scb.channels.qrpayments.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Pattern;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.corebanking.debitcard.v1.cardauthorization.BillingDetailsType;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.AuthorizeCardPurchaseReq;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.AuthorizeCardPurchaseRes;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.CardAuthorizationPortType;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.ReverseCardPurchaseReq;
import com.sc.corebanking.debitcard.v1.ws.provider.cardauthorization.ReverseCardPurchaseRes;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.QRCardAuthConstant;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.AlipayMappingHelper;
import com.scb.channels.mapper.helper.DebitCardMappingHelper;
import com.scb.channels.qrpayments.service.QRDebitCardService;
import com.scb.channels.qrpayments.service.QRPaymentCommonService;

public class QRDebitCardServiceImpl implements QRDebitCardService{
	
	private CardAuthorizationPortType qrDebitCardServiceClient;
	
	private QRPaymentCommonService qrPaymentCommonService;

	private DataBean dataBean;
	
	private ReferenceService referenceService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRDebitCardServiceImpl.class);

	@Override
	public QRPaymentResponseVO authorizeDebitCard(QRPaymentRequestVO qrPaymentRequest) {
		
		QRPaymentResponseVO qrPaymentResponseVO = null;
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequest.getQrPaymentDetailVO();
		
		try{
			LOGGER.info("Debit Card Authorization request : from {} for {} in {} as {}",
					new Object[] { qrPaymentRequest.getUser().getCountry(),
					qrPaymentRequest.getUser().getCustomerId(),
					qrPaymentRequest.getUser().getChannelId(),
					qrPaymentRequest.getMessageVO().getRequestCode() });
			
			LOGGER.info("Debit Card Authorization request for :::: "+qrPaymentDetailVO.getClient_reference());
			AuthorizeCardPurchaseReq authorizeDebitCardRequest = DebitCardMappingHelper.getDebitCardAuthorizationRequest(qrPaymentDetailVO);
			
			String captureSystem=null;
			String txtCurrency=null;
			if(qrPaymentDetailVO.getCountryCode()!=null 
					&& qrPaymentDetailVO.getCountryCode()!=CommonConstants.EMPTY
					&& qrPaymentDetailVO.getCountryCode().equals(CommonConstants.IN)){
				captureSystem=CommonConstants.EURONET;
				txtCurrency=qrPaymentDetailVO.getTxnCurrencyCode();
			}else{
				captureSystem=QRCardAuthConstant.SPARROW;
				txtCurrency=qrPaymentDetailVO.getTransactionCurrency();
			}
			
			XMLGregorianCalendar xmlGregCalendar=AlipayMappingHelper.getGregorianCalendar();
			if(authorizeDebitCardRequest != null) {
				authorizeDebitCardRequest.setHeader(DebitCardMappingHelper.populateHeader(
						qrPaymentRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, xmlGregCalendar,
						qrPaymentDetailVO.getClient_reference(), 
						captureSystem,CommonConstants.EVENT_TYPE,CommonConstants.TYPE_NAME,
						CommonConstants.DOMAIN_NAME,CommonConstants.DEBIT_CARD_PURCHASE,
						AlipayMappingHelper.getGregorianCalFromTimestamp(qrPaymentDetailVO.getPaymentDate())));
			}		
			qrPaymentDetailVO.setHost_system(captureSystem + " - " + CommonConstants.DEBIT_CARD_AUTHORIZE);
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().setPayloadFormat(PayloadFormatEnum.XML);
			
			BigDecimal amount = qrPaymentDetailVO.getTotalPaymentAmt();
			
			ISOCODESVO isoCodes = null;
			int precisionAmt=100;
			String strAmount=CommonConstants.EMPTY;
			int txtCrcyCode=0;
			List<ISOCODESVO> isocodesvos = referenceService.getPrecisionCurrency(txtCurrency);
			if(isocodesvos != null && isocodesvos.size()>0){
				isoCodes=isocodesvos.get(0);
				if(isoCodes!=null){
					precisionAmt=isoCodes.getCurrency_precision();
					txtCrcyCode=isoCodes.getCurrencycode_numeric();
					strAmount = (Arrays.asList((String.valueOf(amount.multiply(new BigDecimal(precisionAmt))).split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
				}else if (amount!=null){
					String amountStr=(String)amount.toString();
					if(amountStr!=null && amountStr!=CommonConstants.EMPTY){
						strAmount=amountStr.replaceAll("\\.", CommonConstants.EMPTY);
					}
				}
			}
						
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
			getAuthorizeCardPurchaseRq().setTransactionAmount(strAmount);
			
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
			getAuthorizeCardPurchaseRq().setTransactionCurrencyCode(String.valueOf(txtCrcyCode));
			
			String acquiringBin = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+qrPaymentDetailVO.getSourceOfFund();
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().getAuthorizeCardPurchaseRq().
												setForwardingInstitutionIdentificationCode(dataBean.map.get(acquiringBin+CommonConstants.UNDERSCORE+CommonConstants.BIN));
			
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().getAuthorizeCardPurchaseRq().
												setTransactionIdentifier(CommonConstants.THREE_ZEROES+qrPaymentDetailVO.getHost_reference());
			
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().getAuthorizeCardPurchaseRq().getCardAcceptorDetails().
												setCardAcceptorName(qrPaymentCommonService.buildCardAcceptorName(qrPaymentDetailVO));
			
			if(qrPaymentDetailVO.getCountryCode()!=null 
					&& qrPaymentDetailVO.getCountryCode()!=CommonConstants.EMPTY
					&& !qrPaymentDetailVO.getCountryCode().equals(CommonConstants.IN)){
				
				String acqInstId=dataBean.map.get(qrPaymentDetailVO.getCountryCode()+QRCardAuthConstant.ACQ_INST_ID);			
				
				authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
				getAuthorizeCardPurchaseRq().setAcquiringInstitutionIdentificationCode(acqInstId);
				
				String cardSchemeIndr=CommonConstants.EMPTY;
				if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
					cardSchemeIndr=CommonConstants.VISA_CARD_SCH_INDR;
				}else{
					cardSchemeIndr=CommonConstants.MASTER_CARD_SCH_INDR;
				}				
				authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
				getAuthorizeCardPurchaseRq().setCardSchemeIndicator(cardSchemeIndr);
				
				authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
				getAuthorizeCardPurchaseRq().setDestinationAccountNumber(qrPaymentDetailVO.getMerchantPan());
				
				BillingDetailsType billDtlsType=new BillingDetailsType();
				if(qrPaymentDetailVO.isCrossCurrency()){				
										
					String debitAmountStr=CommonConstants.EMPTY;
					int dbtCrcyCode=0;
					BigDecimal debitAmount = qrPaymentDetailVO.getDebitAmount();
					isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getDebitAccCurrency());
					if(isocodesvos != null && isocodesvos.size()>0){
						isoCodes=isocodesvos.get(0);
						if(isoCodes!=null){
							precisionAmt=isoCodes.getCurrency_precision();
							dbtCrcyCode=isoCodes.getCurrencycode_numeric();
							debitAmountStr = (Arrays.asList((String.valueOf(debitAmount.multiply(new BigDecimal(precisionAmt))).split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
						}else if (debitAmount!=null){
							String amountStr=(String)debitAmount.toString();
							if(amountStr!=null && amountStr!=CommonConstants.EMPTY){
								debitAmountStr=amountStr.replaceAll("\\.", CommonConstants.EMPTY);
							}
						}
					}				
					
					billDtlsType.setBillingRate(debitCardFXrateConversion(qrPaymentDetailVO.getDebitAmtFxRate()));
					billDtlsType.setBillingAmount(debitAmountStr);
					billDtlsType.setBillingCurrencyCode(String.valueOf(dbtCrcyCode));
				
				}else{
					
					billDtlsType.setBillingRate(QRCardAuthConstant.LOCAL_TRANS_FX_RATE);
					billDtlsType.setBillingAmount(strAmount);
					billDtlsType.setBillingCurrencyCode(String.valueOf(txtCrcyCode));
					
				}
				authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
				getAuthorizeCardPurchaseRq().setCardHolderBillingDetails(billDtlsType);	
				
			}
			
			String acqInsCountryCode=CommonConstants.EMPTY;
			isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getAcquireCountryCode());
			if(isocodesvos != null && isocodesvos.size()>0){
				isoCodes=isocodesvos.get(0);
				if(isoCodes!=null){
					acqInsCountryCode=String.valueOf(isoCodes.getCurrencycode_numeric());
				}
			}
			authorizeDebitCardRequest.getAuthorizeCardPurchaseReqPayload().getAuthorizeCardPurchaseReq().
			getAuthorizeCardPurchaseRq().setAcquiringInstitutionCountryCode(acqInsCountryCode);
			
			/*String requestXML = CommonHelper.getXML(authorizeDebitCardRequest, AuthorizeCardPurchaseReq.class,AuthorizeCardPurchaseReq.class.getSimpleName());
			LOGGER.info(":::EDMI::DC:::Auth:::requestXML::::::"+requestXML);*/
			
			AuthorizeCardPurchaseRes authorizeCardResponse = qrDebitCardServiceClient.authorizeCardPurchase(authorizeDebitCardRequest);
			
			/*String responseXML = CommonHelper.getXML(authorizeCardResponse, AuthorizeCardPurchaseRes.class,AuthorizeCardPurchaseRes.class.getSimpleName());
			LOGGER.info(":::EDMI::DC:::Auth:::responseXML::::::"+responseXML);*/
			
			if (authorizeCardResponse.getHeader().getExceptions() != null) {
				qrPaymentResponseVO = new QRPaymentResponseVO();
				
				// Check if there is any exception from CCMS response
				for (ExceptionType exceptionType : authorizeCardResponse.getHeader().getExceptions().getException()) {
					LOGGER.info("Exceptions present in card authorize response ::: "+qrPaymentDetailVO.getClient_reference());
					LOGGER.info("Exceptions code in card authorize ::: " + exceptionType.getCode().getValue());
					LOGGER.info("Exceptions description in card authorize ::: " +	exceptionType.getDescription());
					qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_TIMEOUT);
					qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
					
					qrPaymentResponseVO.setStatusDesc(exceptionType.getDescription());
					qrPaymentResponseVO.setStatus(exceptionType.getCode().getValue());
					
					qrPaymentDetailVO.setHostResponseCode(exceptionType.getCode().getValue());
					qrPaymentDetailVO.setHostResponseDesc(exceptionType.getDescription());
				
					break;
				} 
				//MOCK
				/*qrPaymentDetailVO.setHostResponseCode("00000");
				qrPaymentDetailVO.setHostResponseDesc("SUCCESS");
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);*/
			} else {
				qrPaymentResponseVO = DebitCardMappingHelper.getDebitCardAuthorizationResponse(authorizeCardResponse);
				LOGGER.info("Got  Debit CardAuth response ::: "+qrPaymentDetailVO.getClient_reference());
				String status = null;
				String description = null;
				
				if(qrPaymentResponseVO != null && qrPaymentResponseVO.getStatus() != null) {
					
					status = qrPaymentResponseVO.getStatus();
					if(status != null && status.equals(CommonConstants.DOUBLE_ZERO)) {
						LOGGER.info("QR Debit card authentication success ::: "+qrPaymentDetailVO.getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_SUCCESS);
						qrPaymentDetailVO.setAuth_code(qrPaymentResponseVO.getQrPaymentDetailVO().getAuth_code());
						description = CommonConstants.SUCCESS;
					} else {
						LOGGER.info("QR Debit card authentication failure ::: "+qrPaymentDetailVO.getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_FAILURE);
						description = CommonConstants.FAILURE;
					}
					qrPaymentDetailVO.setHostResponseCode(status);
					qrPaymentDetailVO.setHostResponseDesc(description);
				}
				LOGGER.info("QR Card Authorization Response for request id:{}, :: {} :: {}", 
					new Object[] {qrPaymentRequest.getMessageVO().getRequestCode(), 
						qrPaymentDetailVO.getHostResponseCode(),
						qrPaymentDetailVO.getHostResponseDesc()});
			}
		}catch(Exception e){
			LOGGER.error("Error Inside QRDebitCardServiceImpl authorizeDebitCard :::",e);
			LOGGER.info("Inside Exception Block QRDebitCardServiceImpl  :::",e+" ::"+qrPaymentDetailVO.getClient_reference());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_TIMEOUT);
			
			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_TIMEOUT);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.NEGATIVE);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());
			
			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO();
			}
		}finally {
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		}
		LOGGER.info("QRDebitCardServiceImpl ::: authorizeDebitCard ::: Status ::"+qrPaymentRequest.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("QRDebitCardServiceImpl authorizeDebitCard End::: "+qrPaymentDetailVO.getClient_reference());
		return qrPaymentResponseVO;
	}

	@Override
	public QRPaymentResponseVO reverseDebitCardAuthorization(QRPaymentRequestVO qrPaymentRequest) {
		
		LOGGER.info("QRCreditCardServiceImpl ::: reverseDebitCardAuthorization ::: start");
		QRPaymentResponseVO qrPaymentResponseVO = null;
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequest.getQrPaymentDetailVO();
		try{
			LOGGER.info("Debit Card Reversal request : from {} for {} in {} as {}",
					new Object[] { qrPaymentRequest.getUser().getCountry(),
					qrPaymentRequest.getUser().getCustomerId(),
					qrPaymentRequest.getUser().getChannelId(),
					qrPaymentRequest.getMessageVO().getRequestCode() });
			
			//qrPaymentDetailVO.setChannel("IBK");
			ReverseCardPurchaseReq reverseDebitCardRequest = DebitCardMappingHelper.getDebitCardReverseAuthorizationRequest(qrPaymentDetailVO);
			LOGGER.info("QRDebitCardServiceImpl ::: reverseDebitCardAuthorization ::: start ::"+qrPaymentDetailVO.getClient_reference());
			
			String captureSystem=null;
			String txtCurrency=null;
			if(qrPaymentDetailVO.getCountryCode()!=null 
					&& qrPaymentDetailVO.getCountryCode()!=CommonConstants.EMPTY
					&& qrPaymentDetailVO.getCountryCode().equals(CommonConstants.IN)){
				captureSystem=CommonConstants.EURONET;
				txtCurrency=qrPaymentDetailVO.getTxnCurrencyCode();
			}else{
				captureSystem=QRCardAuthConstant.SPARROW;
				txtCurrency=qrPaymentDetailVO.getTransactionCurrency();
			}
			
			if(reverseDebitCardRequest != null) {
				reverseDebitCardRequest.setHeader(DebitCardMappingHelper.populateHeader(
						qrPaymentRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						qrPaymentDetailVO.getClient_reference(), 
						captureSystem,CommonConstants.EVENT_TYPE,CommonConstants.TYPE_NAME,
						CommonConstants.DOMAIN_NAME,CommonConstants.DEBIT_CARD_REVERSE_PURCHASE,
						AlipayMappingHelper.getGregorianCalFromTimestamp(qrPaymentDetailVO.getPaymentDate())));
			}		
			qrPaymentDetailVO.setHost_system(captureSystem + CommonConstants.SPACE_HYPHEN_SPACE + CommonConstants.DEBIT_CARD_REVERSE);
			reverseDebitCardRequest.getReverseCardPurchaseReqPayload().setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
			
			BigDecimal amount = qrPaymentDetailVO.getTotalPaymentAmt();
			
			ISOCODESVO isoCodes = null;
			int precisionAmt=100;
			String strAmount=CommonConstants.EMPTY;
			int txtCrcyCode=0;
			List<ISOCODESVO> isocodesvos = referenceService.getPrecisionCurrency(txtCurrency);
			if(isocodesvos != null && isocodesvos.size()>0){
				isoCodes=isocodesvos.get(0);
				if(isoCodes!=null){
					precisionAmt=isoCodes.getCurrency_precision();
					txtCrcyCode=isoCodes.getCurrencycode_numeric();
					strAmount = (Arrays.asList((String.valueOf(amount.multiply(new BigDecimal(precisionAmt))).split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
				}else if (amount!=null){
					String amountStr=(String)amount.toString();
					if(amountStr!=null && amountStr!=CommonConstants.EMPTY){
						strAmount=amountStr.replaceAll("\\.", CommonConstants.EMPTY);
					}
				}
			}
			
			reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
			getReverseCardPurchaseRq().setTransactionAmount(strAmount);
			
			reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
			getReverseCardPurchaseRq().setTransactionCurrencyCode(String.valueOf(txtCrcyCode));
			
			
			String acquiringBin = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+qrPaymentDetailVO.getSourceOfFund();
			reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().getReverseCardPurchaseRq().
												setForwardingInstitutionIdentificationCode(dataBean.map.get(acquiringBin+CommonConstants.UNDERSCORE+CommonConstants.BIN));
			
			reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().getReverseCardPurchaseRq().
												setTransactionIdentifier(CommonConstants.THREE_ZEROES+qrPaymentDetailVO.getHost_reference());
		    
		    reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().getReverseCardPurchaseRq().getCardAcceptorDetails().
		    								setCardAcceptorName(qrPaymentCommonService.buildCardAcceptorName(qrPaymentDetailVO));
		    
			if(qrPaymentDetailVO.getCountryCode()!=null 
					&& qrPaymentDetailVO.getCountryCode()!=CommonConstants.EMPTY
					&& !qrPaymentDetailVO.getCountryCode().equals(CommonConstants.IN)){
				
				String acqInstId=dataBean.map.get(qrPaymentDetailVO.getCountryCode()+QRCardAuthConstant.ACQ_INST_ID);				
				
				reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
				getReverseCardPurchaseRq().setAcquiringInstitutionIdentificationCode(acqInstId);
				
				String cardSchemeIndr=CommonConstants.EMPTY;
				if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
					cardSchemeIndr=CommonConstants.VISA_CARD_SCH_INDR;
				}else{
					cardSchemeIndr=CommonConstants.MASTER_CARD_SCH_INDR;
				}				
				reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
				getReverseCardPurchaseRq().setCardSchemeIndicator(cardSchemeIndr);
				
				reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
				getReverseCardPurchaseRq().setDestinationAccountNumber(qrPaymentDetailVO.getMerchantPan());
				
				BillingDetailsType billDtlsType=new BillingDetailsType();
				
				if(qrPaymentDetailVO.getTransactionCurrency()!=null 
						&& qrPaymentDetailVO.getTransactionCurrency()!=CommonConstants.EMPTY
						&& qrPaymentDetailVO.getDebitAccCurrency()!=null 
						&& qrPaymentDetailVO.getDebitAccCurrency()!=CommonConstants.EMPTY 
						&& !qrPaymentDetailVO.getTransactionCurrency().equals(qrPaymentDetailVO.getDebitAccCurrency())){ 
									
					String debitAmountStr=CommonConstants.EMPTY;
					int dbtCrcyCode=0;
					BigDecimal debitAmount = qrPaymentDetailVO.getDebitAmount();
					isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getDebitAccCurrency());
					if(isocodesvos != null && isocodesvos.size()>0){
						isoCodes=isocodesvos.get(0);
						if(isoCodes!=null){
							precisionAmt=isoCodes.getCurrency_precision();
							dbtCrcyCode=isoCodes.getCurrencycode_numeric();
							debitAmountStr = (Arrays.asList((String.valueOf(debitAmount.multiply(new BigDecimal(precisionAmt))).split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
						}else if (debitAmount!=null){
							String amountStr=(String)debitAmount.toString();
							if(amountStr!=null && amountStr!=CommonConstants.EMPTY){
								debitAmountStr=amountStr.replaceAll("\\.", CommonConstants.EMPTY);
							}
						}
					}				
					
					billDtlsType.setBillingRate(debitCardFXrateConversion(qrPaymentDetailVO.getDebitAmtFxRate()));
					billDtlsType.setBillingAmount(debitAmountStr);
					billDtlsType.setBillingCurrencyCode(String.valueOf(dbtCrcyCode));
				
				}else{
					
					billDtlsType.setBillingRate(QRCardAuthConstant.LOCAL_TRANS_FX_RATE);
					billDtlsType.setBillingAmount(strAmount);
					billDtlsType.setBillingCurrencyCode(String.valueOf(txtCrcyCode));
					
				}
				reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
				getReverseCardPurchaseRq().setCardHolderBillingDetails(billDtlsType);	
				
				DateFormat paymentDateTimeFormat = new SimpleDateFormat("MMddHHmmss");
				String orginialTxnDetail =CommonConstants.QR_MTI_0200+qrPaymentDetailVO.getStan()+paymentDateTimeFormat.format(qrPaymentDetailVO.getPaymentDate());
			    orginialTxnDetail+=CommonConstants.FIVE_ZEROES+acqInstId+CommonConstants.ELEVEN_ZEROES;
			    
			    reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().getReverseCardPurchaseRq().setOriginalTransactionDetails(orginialTxnDetail);
				
			}else{				
				
				DateFormat dateFormat = new SimpleDateFormat("MMdd");
			    DateFormat timeFormat = new SimpleDateFormat("HHmmss");
			    
				String orginialTxnDetail =CommonConstants.QR_MTI_0200+qrPaymentDetailVO.getStan()+dateFormat.format(qrPaymentDetailVO.getPaymentDate())+timeFormat.format(qrPaymentDetailVO.getPaymentDate());
			    orginialTxnDetail+=CommonConstants.ELEVEN_ZEROES+CommonConstants.ELEVEN_ZEROES;			    
			    reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().getReverseCardPurchaseRq().setOriginalTransactionDetails(orginialTxnDetail);				
			}
			
			String acqInsCountryCode=CommonConstants.EMPTY;
			isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getAcquireCountryCode());
			if(isocodesvos != null && isocodesvos.size()>0){
				isoCodes=isocodesvos.get(0);
				if(isoCodes!=null){
					acqInsCountryCode=String.valueOf(isoCodes.getCurrencycode_numeric());
				}
			}
			reverseDebitCardRequest.getReverseCardPurchaseReqPayload().getReverseCardPurchaseReq().
			getReverseCardPurchaseRq().setAcquiringInstitutionCountryCode(acqInsCountryCode);
			
			/*String requestXML = CommonHelper.getXML(reverseDebitCardRequest, ReverseCardPurchaseReq.class,ReverseCardPurchaseReq.class.getSimpleName());
			LOGGER.info(":::EDMI::DC:::Reversal:::requestXML::::::"+requestXML);*/
		    
		    ReverseCardPurchaseRes reverseDebitCardResponse = qrDebitCardServiceClient.reverseCardPurchase(reverseDebitCardRequest);
			
			/*String responseXML = CommonHelper.getXML(reverseDebitCardResponse, ReverseCardPurchaseRes.class,ReverseCardPurchaseRes.class.getSimpleName());
			LOGGER.info(":::EDMI::DC:::Reversal:::responseXML::::::"+responseXML);
			*/
			if (reverseDebitCardResponse.getHeader().getExceptions() != null) {
				qrPaymentResponseVO = new QRPaymentResponseVO();
				
				// Check if there is any exception from EURONET response
				for (ExceptionType exceptionType : reverseDebitCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in debit card authorize reverese response ::: ");
					LOGGER.info("Exceptions code in debit card reverse authorize ::: ",exceptionType.getCode().getValue());
					LOGGER.info("Exceptions description in debit card reverse authorize ::: ",exceptionType.getDescription());
					qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_TIMEOUT);
					qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
					
					qrPaymentResponseVO.setStatusDesc(exceptionType.getDescription());
					qrPaymentResponseVO.setStatus(exceptionType.getCode().getValue());
					
					qrPaymentDetailVO.setHostResponseCode(exceptionType.getCode().getValue());
					qrPaymentDetailVO.setHostResponseDesc(exceptionType.getDescription());
				
					break;
				} 
				//MOCK
				/*qrPaymentDetailVO.setHostResponseCode("00000");
				qrPaymentDetailVO.setHostResponseDesc("SUCCESS");
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);*/
			} else {
				qrPaymentResponseVO = DebitCardMappingHelper.getDebitCardReverseAuthorizationResponse(reverseDebitCardResponse);
				LOGGER.info("Got response from Debit Card reversal response ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
				String status = null;
				String description = null;
				
				if(qrPaymentResponseVO != null && qrPaymentResponseVO.getStatus() != null) {

				status = qrPaymentResponseVO.getStatus();
					if(status != null && status.equals(CommonConstants.DOUBLE_ZERO)) {
						LOGGER.info("QR Debit card Reverse success ::: "+ qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_SUCCESS);
						description = CommonConstants.SUCCESS;
					} else {
						LOGGER.info("QR Debit card Reverse Failure ::: "+ qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_FAILURE);
						description = CommonConstants.FAILURE;
					}
					qrPaymentDetailVO.setHostResponseCode(status);
					qrPaymentDetailVO.setHostResponseDesc(description);
				}
				LOGGER.info("QR Debit Card Reversal Response for request id:{}, :: {} :: {}", 
					new Object[] {qrPaymentRequest.getMessageVO().getRequestCode(), 
						qrPaymentDetailVO.getHostResponseCode(),
						qrPaymentDetailVO.getHostResponseDesc()});
			}
		}catch(Exception e){
			LOGGER.error("Error Inside QRDebitCardServiceImpl authorizeCreditCard :::",e);
			LOGGER.info("Inside Exception Block QRDebitCardServiceImpl  :::",e+" ::: "+ qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_TIMEOUT);
			
			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_TIMEOUT);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.NEGATIVE);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());
			
			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO();
			}
		}finally {
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		}
		LOGGER.info("QRDeditCardServiceImpl ::: reverseAuthorizeCreditCard ::: Status ::"+qrPaymentRequest.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("QRDeditCardServiceImpl ::: reverseAuthorizeCreditCard ::: End ::"+qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
		return qrPaymentResponseVO;
	}

	public CardAuthorizationPortType getQrDebitCardServiceClient() {
		return qrDebitCardServiceClient;
	}

	public void setQrDebitCardServiceClient(
			CardAuthorizationPortType qrDebitCardServiceClient) {
		this.qrDebitCardServiceClient = qrDebitCardServiceClient;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	public QRPaymentCommonService getQrPaymentCommonService() {
		return qrPaymentCommonService;
	}

	public void setQrPaymentCommonService(
			QRPaymentCommonService qrPaymentCommonService) {
		this.qrPaymentCommonService = qrPaymentCommonService;
	}
	
	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	public static String debitCardFXrateConversion(BigDecimal amount){
		String fxRate=CommonConstants.EMPTY;
		String zeroFill=CommonConstants.EMPTY;
		if(amount!=null){
			
			String amtStr = amount.toString();
			if(amtStr!=CommonConstants.EMPTY && amtStr!=null && amtStr.length()>8){
				amtStr=amtStr.substring(0, 8);
				amount=new BigDecimal(amtStr);
			}
			
			String[] amtArry = amount.toString().split("\\.");
			if(amtArry!=null && amtArry.length>1){
				int pricision=amtArry[1].length();
				int zerosInt=8-(amtArry[0].length()+amtArry[1].length());
				for(int i=0;i<zerosInt-1;i++){
					zeroFill+=0;
				}
				fxRate=pricision+zeroFill+amtArry[0]+amtArry[1];
			}else{
				fxRate=amtArry[0];
			}
		}
		LOGGER.info("::amount::::"+amount+":::::::fxRate::::::::::"+fxRate);
		return fxRate;
	}
}
