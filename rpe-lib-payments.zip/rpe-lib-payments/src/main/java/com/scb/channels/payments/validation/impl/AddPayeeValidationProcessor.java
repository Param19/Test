package com.scb.channels.payments.validation.impl;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.BillerManagementService;
import com.scb.channels.payments.service.PayeeManagementService;


public class AddPayeeValidationProcessor {
	/**
	 * BILLER_ADDED
	 */
	public static final String BILLER_ADDED = "Biller Added";
	/**
	 * A_Z_A_Z0_9_$
	 */
	public static final String A_Z_A_Z0_9_$ = "[a-zA-Z0-9 _-]*$";

	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AddPayeeValidationProcessor.class);
	/**
	 * payeeService
	 */
	private PayeeManagementService payeeService;

	/**servieceManager
	 * 
	 */
	private BillerManagementService servieceManager;

	/**
	 * @param payeeService
	 */
	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.base.vo.PayloadDTO)
	 */
	public PayloadDTO process(PayloadDTO bean) throws BusinessException {
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			if (billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null) {
				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo() ------ " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName() ------ " + billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName());

				if (StringUtils.isEmpty(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo()) || !isAlphaNemericWithSpcl(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo())) {
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

					billerPayResponseVO.setErrorCD(Messages._311.getCode());
					billerPayResponseVO.setErrorDesc(Messages._311.getMessage());
					LOGGER.info("getConsumerNo and getConsumerNo is ---blank ----NEW----------------------");

				} else if (billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName()!=null) {
					 if (!isContainSymbol(billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName())){
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

					billerPayResponseVO.setErrorCD(Messages._312.getCode());
					billerPayResponseVO.setErrorDesc(Messages._312.getMessage());
					LOGGER.info("getBillerNickName is ---blank ---------NEW-----------------");
					 }
				}
					billerPayResponseVO = payeeService.checkIsPayeeExists(billerPayRequestVO);
					//billerPayResponseVO.getBillerPayDetailsVO().getBillerCd();
			}
			if (billerPayResponseVO == null) {
				/*String presentMentType = billerPayRequestVO.getBillerPayDetailsVO().getPresentMentType();
				String presentMentType = null;
				List<BillerVO> billerList = servieceManager.getBillerList(billerPayRequestVO);
				for (BillerVO billerVO : billerList) {
					if (billerVO.getBillerUniqueId().equalsIgnoreCase(billerPayRequestVO.getBillerPayDetailsVO().getBillerCd())) {
						presentMentType = billerVO.getBillPresentmentType();
						break;
					}
				}*/
				
				bean.setCurrentState(CommonConstants.ONE);
				//temporarily commented the validate payee service..as of now no payee validation service
				/*if (bean.getRequestVO().getClientVO().getCountry().equalsIgnoreCase(CommonConstants.NG)) {
					bean.setCurrentState(CommonConstants.ONE);
				} else {
					if (Integer.parseInt(presentMentType) <= CommonConstants.ZERO_INT) {
						bean.setCurrentState(CommonConstants.TWO);
					} else if (Integer.parseInt(presentMentType) > CommonConstants.ZERO_INT) {
						bean.setCurrentState(CommonConstants.THREE_STR);
					}
				}*/
			}
			
			bean.setRequestVO(billerPayRequestVO);
			bean.setResponseVO(billerPayResponseVO);
		} catch (Exception e) {
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			bean.setRequestVO(billerPayRequestVO);
			bean.setResponseVO(billerPayResponseVO);
			e.printStackTrace();
		}
		return bean;
	}
	/**
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO validatePayee(PayloadDTO bean) throws BusinessException {
		LOGGER.info("AddPayeeValidationProcessor :: Validate Payee :: Start" +bean.getRequestVO().getMessageVO().getReqID());
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
	
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
			if (billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null) {
				LOGGER.info("validatePayee :: getConsumerNo() ------ " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
				LOGGER.info("validatePayee :: getBillerNickName() ------ " + billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName());

				if (StringUtils.isEmpty(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo()) || !isAlphaNemericWithSpcl(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo())) {
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

					billerPayResponseVO.setErrorCD(ExceptionMessages._164.getCode());
					billerPayResponseVO.setErrorDesc(ExceptionMessages._164.getMessage());
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					LOGGER.info("getConsumerNo and getConsumerNo is ---blank ----NEW----------------------");
					return bean;
				}/*else if (billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName()==null || billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName().isEmpty()) {
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

					billerPayResponseVO.setErrorCD(Messages._312.getCode());
					billerPayResponseVO.setErrorDesc(Messages._312.getMessage());
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					//return bean;
					LOGGER.info("getBillerNickName is ---blank ---------NEW-----------------");
					return bean;
				}
*/				else if (billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName()!=null) {
					 if (!isAlphaNemericWithSpclHK(billerPayRequestVO.getBillerPayDetailsVO().getBillerNickName())){
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

					billerPayResponseVO.setErrorCD(Messages._312.getCode());
					billerPayResponseVO.setErrorDesc(Messages._312.getMessage());
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					LOGGER.info("getBillerNickName is ---blank ---------NEW-----------------");
					return bean;
					 }
				}
				billerPayResponseVO = payeeService.validatePayee(billerPayRequestVO);
				
			}else{
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._164.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._164.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
				bean.setRequestVO(billerPayRequestVO);
				bean.setResponseVO(billerPayResponseVO);
				return bean;
			}
			if (billerPayResponseVO != null) {
				if(billerPayResponseVO.getStatus().equalsIgnoreCase(Messages._0.getCode())){
					bean.setCurrentState(CommonConstants.ONE);	
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					return bean;
				}else
				{
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
				}
			}else{
				bean.setRequestVO(billerPayRequestVO);
				bean.setResponseVO(billerPayResponseVO);	
			}
			LOGGER.info("AddPayeeValidationProcessor :: Validate Payee :: END");
		} catch (Exception e) {
			LOGGER.info("Exception :: validatePayee :: "+e.getMessage());
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._164.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._164.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			bean.setRequestVO(billerPayRequestVO);
			bean.setResponseVO(billerPayResponseVO);
			e.printStackTrace();
		}
		return bean;
	}
	/**
	 * @param value
	 * @return
	 */
	public boolean isContainSymbol(String value) {
		String regex = A_Z_A_Z0_9_$;
		return Pattern.matches(regex, value);
	}

	/**
	 * @return
	 */
	public BillerManagementService getServieceManager() {
		return servieceManager;
	}

	/**
	 * @param servieceManager
	 */
	public void setServieceManager(BillerManagementService servieceManager) {
		this.servieceManager = servieceManager;
	}
	
	private  boolean isAlphaNemericWithSpcl(String str){
		String PATTERN = "^[/&_A-Za-z0-9@-]+$";
      //  CharSequence inputStr = "1fjoiasdfjiajio";
        Pattern pattern = Pattern.compile(PATTERN);
        Matcher matcher = pattern.matcher(str);
        if(matcher.matches()){
        	return true;
           // System.out.println("Success");
        }else{
        	return false;
            //System.out.println("Failure");
        }
		
	}
	
	private  boolean isAlphaNemericWithSpclHK(String str){
		String PATTERN = "^[\".*',) (/&A-Za-z0-9@-]+$";
      //  CharSequence inputStr = "1fjoiasdfjiajio";
        Pattern pattern = Pattern.compile(PATTERN);
        Matcher matcher = pattern.matcher(str);
        if(matcher.matches()){
        	 System.out.println("Success");
        	return true;
           
        }else{
        	 System.out.println("Failure");
        	return false;
           
        }
		
	}

	
	/**
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO validatePayeeRpeCs(PayloadDTO bean) throws BusinessException {
		LOGGER.info("AddPayeeValidationProcessor :: validatePayeeCS :: Start" + bean.getRequestVO().getMessageVO().getReqID());
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
			if (billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null) {
				List<BillerField> listBillerFields = billerPayRequestVO.getBillerPayDetailsVO().getBillerFields();
				if (listBillerFields != null && !listBillerFields.isEmpty()) {
					LOGGER.info("validatePayeeRpeCs :: List contains values "+bean.getRequestVO().getMessageVO().getReqID());
					payeeService.validatePayeeRpeCs(bean);
					if(bean.getResponseVO().getStatus() ==null)
					bean.setCurrentState(CommonConstants.ONE);
				} else {
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._165.getCode());
					billerPayResponseVO.setErrorDesc(ExceptionMessages._165.getMessage());
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					LOGGER.info("validatePayeeRpeCs :: Biller filed is empty" + bean.getRequestVO().getMessageVO().getReqID());
					return bean;
				}
			}
			LOGGER.info("AddPayeeValidationProcessor :: Validate Payee :: END " + bean.getRequestVO().getMessageVO().getReqID());
		} catch (Exception e) {
			LOGGER.info("Exception :: validatePayee :: " + bean.getRequestVO().getMessageVO().getReqID() + " "+ e);
			LOGGER.info("Exception :: validatePayee :: " , e);
			billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			bean.setRequestVO(billerPayRequestVO);
			bean.setResponseVO(billerPayResponseVO);
			e.printStackTrace();
		}
		return bean;
	}
	// Added for Orange Money - start
	public PayloadDTO validateWalletPayeeRpeCS(PayloadDTO bean) throws BusinessException {
		LOGGER.info("AddPayeeValidationProcessor :: validateWalletPayeeRpeCS :: Start" + bean.getRequestVO().getMessageVO().getReqID());
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
			if (billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null) {
				List<BillerField> listBillerFields = billerPayRequestVO.getBillerPayDetailsVO().getBillerFields();
				
				//calling from BOA for activating the wallets
				if(CommonConstants.ADD_WALLET_PAYEE.equalsIgnoreCase(billerPayRequestVO.getServiceVO().getServiceName()) &&
						CommonConstants.BACK_OFFICE.equalsIgnoreCase(billerPayRequestVO.getServiceVO().getHostEnv())){
					billerPayResponseVO = payeeService.addWalletPayeeBO(billerPayRequestVO);
					billerPayResponseVO.setStatus(Messages._0.getCode());
					billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					return bean;
				}				
				else if (listBillerFields != null && !listBillerFields.isEmpty()) {
					LOGGER.info("AddPayeeValidationProcessor ::  validateWalletPayeeRpeCS :: List contains values "+bean.getRequestVO().getMessageVO().getReqID());
					payeeService.validateWalletPayeeRpeCS(bean);
					if(bean.getResponseVO().getStatus() ==null)
					bean.setCurrentState(CommonConstants.ONE);
				} else {
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._165.getCode());
					billerPayResponseVO.setErrorDesc(ExceptionMessages._165.getMessage());
					bean.setResponseVO(billerPayResponseVO);
					bean.setRequestVO(billerPayRequestVO);
					LOGGER.info("validateWalletPayeeRpeCS :: Biller filed is empty" + bean.getRequestVO().getMessageVO().getReqID());
					return bean;
				}
			}
			LOGGER.info("AddPayeeValidationProcessor :: validateWalletPayeeRpeCS Payee :: END " + bean.getRequestVO().getMessageVO().getReqID());
		} catch (Exception e) {
			LOGGER.error("Exception :: validateWalletPayeeRpeCS :: requestID: " + bean.getRequestVO().getMessageVO().getReqID());
			LOGGER.error("Exception :: validateWalletPayeeRpeCS :: " , e);
			billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			bean.setRequestVO(billerPayRequestVO);
			bean.setResponseVO(billerPayResponseVO);
		//	e.printStackTrace();
		}
		return bean;
	}
	// Added for Orange Money - end
}