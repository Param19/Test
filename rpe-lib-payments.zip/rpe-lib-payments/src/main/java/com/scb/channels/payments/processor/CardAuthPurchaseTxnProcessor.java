package com.scb.channels.payments.processor;

import java.math.BigDecimal;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.CardAuthPurchaseTxnService;

public class CardAuthPurchaseTxnProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CardAuthPurchaseTxnProcessor.class);
	
	/**
	 * CreditCardService bean
	 */
	private CardAuthPurchaseTxnService cardAuthPurchaseTxnService;
	
	/**
	 * Method to consume process card authorization service of C400
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO processAuthorizeCardPurchase(PayloadDTO bean) throws BusinessException{
		LOGGER.info("Task in C400 Card Authorization Processor ::: processAuthorizationC400 : Start");
		BillerPayRequestVO billerPayRequestVO = null;
 		BillerPayResponseVO billerPayResponseVO = null;
		try {
			if(bean != null && bean.getRequestVO() != null){
				billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
				LOGGER.info("Posting request to C400 credit card system ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				//setting IBK for C400 Processing
				billerPayRequestVO.getBillerPayDetailsVO().setChannel(CommonConstants.DOMAIN_TYPE);
				
				LOGGER.info(" processAuthorizeCardPurchase : hostName: "+billerPayRequestVO.getBillerPayDetailsVO().getHostName());
				
				
				billerPayResponseVO = cardAuthPurchaseTxnService.authorizeCardPurchaseTransaction(billerPayRequestVO);
				
				LOGGER.info("Received response from C400 credit card system ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			}
		}catch (Exception e) {
			LOGGER.info("Exception Occurred while Card authorization from C400 credit card system : processAuthorizationC400 ::" +
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			LOGGER.error("Exception :::: ", e);
			
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
			
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for C400 card auth : processAuthorizationC400 :: " + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				LOGGER.error(e.getCause().toString());
				billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			}
			
		} finally{
			
			if (billerPayResponseVO != null) {
				finalResponse(billerPayRequestVO, billerPayResponseVO); //update final response
			}
			bean.setResponseVO(billerPayResponseVO);
			bean.setRequestVO(billerPayRequestVO);
		}
		LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() : processAuthorizationC400 :::: " 
				+ billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus());
		
		LOGGER.info("Task in C400 Card Authorization Processor ::: processAuthorizationC400 : End");
		return bean;
	}


	/**
	 * Method to set final response and re-conversion of amount to original value 
	 * @param billerPayRequestVO
	 * @param billerPayResponseVO
	 */
	private void finalResponse(BillerPayRequestVO billerPayRequestVO, BillerPayResponseVO billerPayResponseVO) {
		LOGGER.info("CardAuthPurchaseTxnProcessor: Inside FinalResponse method: Setting header objects in response value object" 
				+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		if(billerPayResponseVO.getBillerPayDetailsVO() == null) {
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
		}
		
		if(billerPayResponseVO.getBillerPayDetailsVO() != null && 
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
			LOGGER.info("Setting the aggregator response status details to host response list in C400 card auth posting" + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			
			HostResponseVO hostResponse = new HostResponseVO();
			hostResponse.setCode(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
			hostResponse.setDesc(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			hostResponse.setHostName(billerPayResponseVO.getBillerPayDetailsVO().getHostName());
			
			billerPayRequestVO.getHostResponseVO().add(hostResponse);
		}
		
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		
		//Reverting the channel & amount
		billerPayRequestVO.getBillerPayDetailsVO().setChannel(CommonConstants.I_BANKING);
		BigDecimal txnAmount = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().getAmount();
		billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getSrcAccountVO().setAmount(txnAmount.divide(new BigDecimal(100)));
		
		LOGGER.info("Transaction Amount Resetting [" + txnAmount +"]");
		LOGGER.info("finalResponse : hostName: "+billerPayRequestVO.getBillerPayDetailsVO().getHostName());
		LOGGER.info("CardAuthPurchaseTxnProcessor: Inside finalResponse: end");
	}
	
	
	/**
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO processReverseCardPurchase(PayloadDTO bean) throws BusinessException {
		
		LOGGER.info("Task in process Authorization Reversal : processC400AuthorizationReversal ::: Start");
		BillerPayRequestVO billerPayRequestVO = null;
 		BillerPayResponseVO billerPayResponseVO = null;
		try {
				
			if( bean != null && bean.getResponseVO() != null) {  
				billerPayRequestVO = new BillerPayRequestVO();
				billerPayResponseVO = (BillerPayResponseVO)bean.getResponseVO();
				
				billerPayRequestVO.setBillerPayDetailsVO(billerPayResponseVO.getBillerPayDetailsVO());
				billerPayRequestVO.setUser(billerPayResponseVO.getUser());
				billerPayRequestVO.setMessageVO(billerPayResponseVO.getMessageVO());
				billerPayRequestVO.setClientVO(billerPayResponseVO.getClientVO());
				billerPayRequestVO.setServiceVO(billerPayResponseVO.getServiceVO());
			}
			
				LOGGER.info("Posting request to credit card system for auth reversal : processC400AuthorizationReversal:: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				//setting IBK for C400 Processing
				billerPayRequestVO.getBillerPayDetailsVO().setChannel(CommonConstants.DOMAIN_TYPE);

				
				billerPayResponseVO = cardAuthPurchaseTxnService.reverseCardPurchaseTransaction(billerPayRequestVO);
				
			
		}catch (Exception e) {
			LOGGER.info("Exception Occurred while Card authorization from credit card system : processC400AuthorizationReversal::" +
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			LOGGER.error("Exception during auth reversal :::: ", e);
			
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			
			/*LOGGER.info("Setting Fail status for the card authorization due to Exception : processC400AuthorizationReversal:: " 
					+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
			billerPayResponseVO.setStatusDesc(e.getMessage());
			billerPayResponseVO.setErrorDesc(e.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._105.getCode());*/
			
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
			
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for card auth reversal :  processC400AuthorizationReversal :: " 
						+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				LOGGER.error(e.getCause().toString());
				billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			}
			
		} finally{
			
			if (billerPayResponseVO != null) {
				LOGGER.info("Inside Finally : CardAuthPurchaseTxnProcessor: processReverseCardPurchase : "+billerPayResponseVO.getBillerPayDetailsVO().getPayRef());
				finalResponse(billerPayRequestVO, billerPayResponseVO); // update response object
			}
			bean.setResponseVO(billerPayResponseVO);
			bean.setRequestVO(billerPayRequestVO);
		}
		LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() : processC400AuthorizationReversal :::: " 
				+ billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus());
		
		LOGGER.info("Task in process Authorization Reversal : processC400AuthorizationReversal ::: End");
		return bean;
	}

	/**
	 * @param cardAuthPurchaseTxnService
	 */
	public void setCardAuthPurchaseTxnService(
			CardAuthPurchaseTxnService cardAuthPurchaseTxnService) {
		this.cardAuthPurchaseTxnService = cardAuthPurchaseTxnService;
	}
	

}
