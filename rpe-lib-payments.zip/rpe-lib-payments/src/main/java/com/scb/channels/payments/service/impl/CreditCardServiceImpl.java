package com.scb.channels.payments.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.CreditCardAuthorizationPortType;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.AlipayMappingHelper;
import com.scb.channels.mapper.helper.CreditCardMappingHelper;
import com.scb.channels.payments.service.CreditCardService;

public class CreditCardServiceImpl implements CreditCardService{

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditCardServiceImpl.class);
	
	private CreditCardAuthorizationPortType creditCardServiceClient;
	
	private DataBean dataBean;
	
	@Override
	public BillerPayResponseVO authorizeCreditCard(
			BillerPayRequestVO billerPayRequest) {
		LOGGER.info("CreditCardServiceImpl ::: authorizeCreditCard ::: start");
		BillerPayResponseVO billerPayResponseVO = null;
		BillerPayDetailsVO billpayDetails = billerPayRequest.getBillerPayDetailsVO();
		BigDecimal amount = null;
		try {
			LOGGER.info("Card Authorization request : from {} for {} in {} as {}",
				new Object[] { billerPayRequest.getUser().getCountry(),
						billerPayRequest.getUser().getCustomerId(),
						billerPayRequest.getUser().getChannelId(),
						billerPayRequest.getMessageVO().getRequestCode() });
			
			billpayDetails.setChannel("IBK");
			String currencyConversion = dataBean.getMap().get(
	        		billpayDetails.getCountryCode() + 
					CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
			
			if(currencyConversion != null && !currencyConversion.isEmpty()) {
				LOGGER.info("Currency conversion :::: " +	billpayDetails.getPayRef());
				
				amount = billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?
					billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
				
	            String strAmount = (Arrays.asList((String.valueOf(
	            	amount.multiply(new BigDecimal(currencyConversion))).
		        		split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
	            
			    billpayDetails.getTransactionInfoVO().getSrcAccountVO()
					.setAmount(new BigDecimal(strAmount));
			}
			
			AuthorizeCardPurchaseTransactionReq authorizeCardRequest = 
					CreditCardMappingHelper.getCardAuthorizationRequest(billerPayRequest);
			
			if(authorizeCardRequest != null) {
				authorizeCardRequest.setHeader(AlipayMappingHelper.populateHeader(
						billerPayRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						billerPayRequest.getBillerPayDetailsVO().getPayRef(), 
						CommonConstants.HOGAN, CommonConstants.CARD_AUTHORIZATION_TRANSACTION,
						CommonConstants.POST_SINGLE_LEG,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
			}
			
			LOGGER.info("Obtained card authorization object" +	billpayDetails.getPayRef());
			
			billpayDetails.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.CARD_AUTHORIZE);
			
			authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().setPayloadFormat(PayloadFormatEnum.XML);
			authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
			
			/*String str = CommonHelper.getXML(authorizeCardRequest, 
					AuthorizeCardPurchaseTransactionReq.class, "authorizeCardPurchaseTransaction");
			System.out.println(str);*/

			AuthorizeCardPurchaseTransactionRes authorizeCardResponse = creditCardServiceClient.
					authorizeCardPurchaseTransaction(authorizeCardRequest);
			LOGGER.info("Obtained response from Card application ::: " +	billpayDetails.getPayRef());

			/*String resstr = CommonHelper.getXML(authorizeCardResponse, 
					AuthorizeCardPurchaseTransactionRes.class, "authorizeCardPurchaseTransactionResponse");
			System.out.println(resstr);*/
			
			if (authorizeCardResponse.getHeader().getExceptions() != null) {
				billerPayResponseVO = new BillerPayResponseVO();
				
				// Check if there is any exception from eBBS response
				for (ExceptionType exceptionType : authorizeCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in card authorize response ::: " 
						+	billpayDetails.getPayRef());
					LOGGER.info("Exceptions code in card authorize ::: " 
						+ exceptionType.getCode().getValue() 
						+ " ::: " +	billpayDetails.getPayRef());
					LOGGER.info("Exceptions description in card authorize ::: " 
						+	exceptionType.getDescription()
						+ " ::: " +	billpayDetails.getPayRef());
					
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
					billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.setStatusDesc(
							exceptionType.getDescription());
					billerPayResponseVO.setStatus(
							exceptionType.getCode().getValue());
					
					billpayDetails.getTransactionInfoVO()
						.setHostRespCd(exceptionType.getCode().getValue());
					billpayDetails.getTransactionInfoVO()
						.setHostRespDesc(exceptionType.getDescription());
				
					break;
				} 
			} else {
				billerPayResponseVO = CreditCardMappingHelper.
						getCardAuthorizationResponse(authorizeCardResponse);
				LOGGER.info("Obtained payload response from Card response ::: " + billpayDetails.getPayRef());
				String status = null;
				String description = null;
				
				if(billerPayResponseVO != null && billerPayResponseVO.getStatus() != null) {
					if(billerPayResponseVO.getStatus().contains(CommonConstants.TILDE)) {
						LOGGER.info("Tilde operator available for creditcard status ::: " + billpayDetails.getPayRef());
						List<String> statusDetails = Arrays.asList(
								billerPayResponseVO.getStatus().split(CommonConstants.TILDE));
						
						if(statusDetails != null) {
							if(statusDetails.size() == 1){
								status = statusDetails.get(0);
							} else if(statusDetails.size() == 2){
								status = statusDetails.get(0);
								description = statusDetails.get(1);
							}
						}
						
					} else {
						LOGGER.info("Tilde operator not available for creditcard status ::: " + billpayDetails.getPayRef());
						status = billerPayResponseVO.getStatus();
					}
				
					if(status != null && status.equals("00000")) {
						LOGGER.info("Credit card authentication success ::: " + billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);
					} else {
						LOGGER.info("Credit card authentication failure ::: " + billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
					}
				
					billpayDetails.getTransactionInfoVO().setHostRespCd(status);
					billpayDetails.getTransactionInfoVO().setHostRespDesc(description);
				}
				
				LOGGER.info("Card Authorization Response for request id:{}, :: {} :: {}", 
					new Object[] {billerPayRequest.getMessageVO().getRequestCode()
						, billpayDetails.getTransactionInfoVO().getHostRespCd(),
						billpayDetails.getTransactionInfoVO().getHostRespDesc()});
				
			}
		} catch (Exception exception) {
			billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
			LOGGER.info("Credit card authentication Exception ::: " + billpayDetails.getPayRef());
			LOGGER.error("Exception during card auth ::: ", exception);
		} finally {
			if(amount != null && amount != new BigDecimal(0)) {
				billpayDetails.getTransactionInfoVO().
					getSrcAccountVO().setAmount(amount);
			}
			billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
		}
		
		LOGGER.info("CreditCardServiceImpl ::: authorizeCreditCard ::: End");
		return billerPayResponseVO;
	}

	@Override
	public BillerPayResponseVO reverseCardAuthorization(
			BillerPayRequestVO billerPayRequest) {

		LOGGER.info("CreditCardServiceImpl ::: reverseCardAuthorization ::: start");
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();;
		BillerPayDetailsVO billpayDetails = billerPayRequest.getBillerPayDetailsVO();
		BigDecimal amount = null;
		
		try {
			LOGGER.info("Card Authorization reversal request : from {} for {} in {} as {}",
					new Object[] { billerPayRequest.getUser().getCountry(),
							billerPayRequest.getUser().getCustomerId(),
							billerPayRequest.getUser().getChannelId(),
							billerPayRequest.getMessageVO().getRequestCode() });
			
			billpayDetails.setChannel("IBK");
			
			String currencyConversion = dataBean.getMap().get(
	        		billpayDetails.getCountryCode() + 
					CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
			
			if(currencyConversion != null && !currencyConversion.isEmpty()) {
				LOGGER.info("Currency conversion :::: " +	billpayDetails.getPayRef());
				
				amount = billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?
					billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
				
	            String strAmount = (Arrays.asList((String.valueOf(
	            	amount.multiply(new BigDecimal(currencyConversion))).
		        		split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
	            
			    billpayDetails.getTransactionInfoVO().getSrcAccountVO()
					.setAmount(new BigDecimal(strAmount));
			}
			
			ReverseCardPurchaseTransactionReq reverseAuthorizeCardRequest = 
					CreditCardMappingHelper.getReverseCardAuthorizationRequest(billerPayRequest);
			LOGGER.info("Obtained card authorization reversal object" +	billpayDetails.getPayRef());
			
			if(reverseAuthorizeCardRequest != null) {
				reverseAuthorizeCardRequest.setHeader(AlipayMappingHelper.populateHeader(
						billerPayRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						billerPayRequest.getBillerPayDetailsVO().getPayRef(), 
						CommonConstants.HOGAN, CommonConstants.CARD_AUTHORIZATION_TRANSACTION,
						CommonConstants.POST_SINGLE_LEG,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
			}
			LOGGER.info("Obtained core banking header populated for card reversal" +	billpayDetails.getPayRef());

			billpayDetails.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.CARD_AUTHORIZE_REVERSE);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().setPayloadFormat(PayloadFormatEnum.XML);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
			
			/*String str = CommonHelper.getXML(payBillReq, PayBillReq.class,
					PayBillReq.class.getSimpleName());
			System.out.println(str);*/
			
			ReverseCardPurchaseTransactionRes reverseAuthorizeCardResponse = creditCardServiceClient.
					reverseCardPurchaseTransaction(reverseAuthorizeCardRequest);
			LOGGER.info("Obtained card auth reversal response from Card application" +	billpayDetails.getPayRef());
			
			if (reverseAuthorizeCardResponse.getHeader().getExceptions() != null) {
				
				// Check if there is any exception from Hogan response
				for (ExceptionType exceptionType : reverseAuthorizeCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in card authorize reversal response ::: " 
						+	billpayDetails.getPayRef());
					LOGGER.info("Exceptions code in card authorize reversal ::: " 
						+ exceptionType.getCode().getValue() 
						+ " ::: " +	billpayDetails.getPayRef());
					LOGGER.info("Exceptions description in card authorize reversal ::: " 
						+	exceptionType.getDescription()
						+ " ::: " +	billpayDetails.getPayRef());
					
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
					billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.setStatusDesc(
							exceptionType.getDescription());
					billerPayResponseVO.setStatus(
							exceptionType.getCode().getValue());
					
					billpayDetails.getTransactionInfoVO()
						.setHostRespCd(exceptionType.getCode().getValue());
					billpayDetails.getTransactionInfoVO()
						.setHostRespDesc(exceptionType.getDescription());
				
					billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
					
					break;
				} 
			} else {
				billerPayResponseVO = CreditCardMappingHelper.
						getReverseCardAuthorizationResponse(reverseAuthorizeCardResponse);
				LOGGER.info("Obtained payload response from Card reversal response ::: " + billpayDetails.getPayRef());

				String status = null;
				String description = null;
				if(billerPayResponseVO != null && billerPayResponseVO.getStatus() != null) {
					if(billerPayResponseVO.getStatus().contains(CommonConstants.TILDE)) {
						LOGGER.info("Tilde operator available for creditcard reversal status ::: " + billpayDetails.getPayRef());
						List<String> statusDetails = Arrays.asList(
								billerPayResponseVO.getStatus().split(CommonConstants.TILDE));
						
						if(statusDetails != null) {
							if(statusDetails.size() == 1){
								status = statusDetails.get(0);
							} else if(statusDetails.size() == 2){
								status = statusDetails.get(0);
								description = statusDetails.get(1);
							}
						}
					} else {
						LOGGER.info("Tilde operator not available for creditcard reversal status ::: " + billpayDetails.getPayRef());
						status = billerPayResponseVO.getStatus();
					}
				
					if(status != null && status.equals("00000")) {
						LOGGER.info("Credit card reverse authentication success ::: " + billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);
					} else {
						LOGGER.info("Credit card reverse authentication failure ::: " + billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
					}
				
					billpayDetails.getTransactionInfoVO().setHostRespCd(status);
					billpayDetails.getTransactionInfoVO().setHostRespDesc(description);
				}
				
				LOGGER.info("Card Authorization reversal Response for request id:{}, :: {} :: {}", 
					new Object[] {billerPayRequest.getMessageVO().getRequestCode()
						, billpayDetails.getTransactionInfoVO().getHostRespCd(),
						billpayDetails.getTransactionInfoVO().getHostRespDesc()});
				
			
				/*if(billerPayResponseVO != null && billerPayResponseVO.getStatus() != null 
						&& billerPayResponseVO.getStatus().equals("00000")) {
					LOGGER.info("Credit card authentication success ::: " + billpayDetails.getPayRef());
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);
				} else {
					LOGGER.info("Credit card authentication failure ::: " + billpayDetails.getPayRef());
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
				}
				
				billpayDetails.getTransactionInfoVO().setHostRespCd(billerPayResponseVO.getStatus());
				billpayDetails.getTransactionInfoVO().setHostRespDesc(billerPayResponseVO.getStatusDesc());
	
				LOGGER.info("Card Authorization Response for request id:{}, {}", 
					new Object[] {billerPayRequest.getMessageVO().getRequestCode()
						, billerPayResponseVO.getStatus()});*/
				
			}
		} catch (Exception exception) {
			billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
			LOGGER.error("Exception in card reversal ::: ", exception);
			
		} /*finally {
			billerPayResponseVO.getHostResponseVO().add(hostResponse);
		}*/
		
		LOGGER.info("CreditCardServiceImpl ::: reverseAuthorizeCreditCard ::: End");
		return billerPayResponseVO;
	}

	public void setCreditCardServiceClient(
			CreditCardAuthorizationPortType creditCardServiceClient) {
		this.creditCardServiceClient = creditCardServiceClient;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
}
