package com.scb.channels.payments.service;

import java.util.List;
import java.util.Map;

import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.NarrationVO;
   


/**
 * @author 1460693
 * Interface for Biller management 
 */
public interface CacheManagementService {
	
	
	
	 
	 
	/**
	 * <p> Get Billers From cache Managment</p>
	 * 
	 * @return    List<BillerCategoryVO>
	 * @param Country
	 *  
	 */
	public  List<BillerCategoryVO> getBillers(String Country);
	
	public void clearBillerCache(String country);
	
	public Map<String,ApplicationMessageVO> getCustomizedMessages(String country,String channel);
	
	public List<NarrationVO> getNarration(String Country, String Channel);
	public List<BillerCategoryVO> getWalletBillers(String Country, String category);
 
}
