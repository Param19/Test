package com.scb.channels.payments.service;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;

public interface CardAuthPurchaseTxnService {
	
	public BillerPayResponseVO authorizeCardPurchaseTransaction(BillerPayRequestVO billerPayRequest);
	
	public BillerPayResponseVO reverseCardPurchaseTransaction(BillerPayRequestVO billerPayRequest);

}
