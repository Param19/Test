package com.scb.channels.payments.service.impl;

import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.cash.payment.mobile.v2.invoice.Invoice;
import com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo;
import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.invoice.PaymentStatus;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentStatusReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetPaymentStatusRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.GetPaymentStatusReqPayload;
import com.sc.scbml_1.PayloadFormatEnum;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.GetPaymentStatusService;

/**
 * @author 1521723
 *
 */
public class GetPaymentStatusServiceImpl implements GetPaymentStatusService {
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(GetPaymentStatusServiceImpl.class);
	/**
	 * invoicePortType
	 */
	private com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType invoicePortType;

	private DataBean dataBean;
	
	@Override
	public BillerPayResponseVO getPaymentStatus(
			BillerPayRequestVO billerPayRequestVO) throws Exception {
		
		LOGGER.info("GetPaymentStatusServiceImpl :: Inside getPaymentStatus :: Start");
		billerPayRequestVO.getBillerPayDetailsVO().setHostName(
			CommonConstants.AGGREGATOR + " - " + CommonConstants.PAYMENT_STATUS_ENQUIRY);
		
		GetPaymentStatusReq getPaymentStatusReq = performGetPaymentStatusRequestPayload(billerPayRequestVO);
		LOGGER.info(" getPaymentStatusReq " + getPaymentStatusReq); 

		LOGGER.info("Before sending Request to EDMI");
		GetPaymentStatusRes  getPaymentStatusRes = invoicePortType.getPaymentStatus(getPaymentStatusReq);
		LOGGER.info(" getPaymentStatusReq " + getPaymentStatusRes);
		
		LOGGER.info("After getting response from EDMI");
		BillerPayResponseVO  billerPayResponseVO = performGetPaymentStatusResponse(
				getPaymentStatusRes, billerPayRequestVO);
		LOGGER.info("GetPaymentStatusServiceImpl :: Inside getPaymentStatus :: END");
		
		return billerPayResponseVO;
}
	
	private GetPaymentStatusReq performGetPaymentStatusRequestPayload(
			BillerPayRequestVO billerPayRequestVO) throws Exception  {
		LOGGER.info("GetPaymentStatusServiceImpl :: performGetPaymentStatusRequestPayload :: Start");
		
		Invoice invoice=new Invoice();
		InvoiceInfo invoiceInfo = new InvoiceInfo();
		invoiceInfo.setAggregatorIdentifier(dataBean.getMap().get(billerPayRequestVO.getBillerPayDetailsVO().getCountryCode() + 
				CommonConstants.AggregatorIdentifier));
		GetPaymentStatusReq getPaymentStatusReq = new GetPaymentStatusReq();
		GetPaymentStatusReqPayload getPaymentStatusReqPayload = new GetPaymentStatusReqPayload();
		getPaymentStatusReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		getPaymentStatusReqPayload.setPayloadVersion(CommonConstants.PAYLOAD_API_21);
		
		String applicationUserId = dataBean.getMap().get(
				billerPayRequestVO.getBillerPayDetailsVO().getCountryCode() + 
				CommonConstants.Biller_DOWNLOAD_ApplicationUserID);
		String applicationUserKey = dataBean.getMap().get(
				billerPayRequestVO.getBillerPayDetailsVO().getCountryCode() + 
				CommonConstants.Biller_DOWNLOAD_ApplicationUserKey);
		
		if(applicationUserId != null && !applicationUserId.isEmpty()) {
			invoiceInfo.setApplicationUserID(applicationUserId);
			LOGGER.info("Set ApplicationUserID ::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		}
		
		if(applicationUserKey != null && !applicationUserKey.isEmpty()) {
			invoiceInfo.setApplicationUserKey(applicationUserKey);
			LOGGER.info("Set ApplicationUserKey ::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		}
		
		if(billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getDtProcessed() != null) {
			SimpleDateFormat format = new SimpleDateFormat("dd MMM YYYY");
			invoiceInfo.setPaymentDate(format.format(
					billerPayRequestVO.getBillerPayDetailsVO().
					getTransactionInfoVO().getDtProcessed().getTime()));
			LOGGER.info("Set PaymentDate ::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		}

		invoiceInfo.setTransactionID(billerPayRequestVO.getBillerPayDetailsVO().getHostReference());
		LOGGER.info("Set TransactionID ::: " + 
				billerPayRequestVO.getBillerPayDetailsVO().getHostReference() + " ::: " +
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		invoice.setInvoiceInfo(invoiceInfo);
		getPaymentStatusReqPayload.setGetPaymentStatusReq(invoice);
		getPaymentStatusReq.setGetPaymentStatusReqPayload(getPaymentStatusReqPayload);
		
		LOGGER.info("Setting Header ::: " + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		getPaymentStatusReq.setHeader(BillpaymentMappingHelper.populateSCBHeaderForAggregator(
				billerPayRequestVO.getBillerPayDetailsVO().getCountryCode(), 
				CommonConstants.GET_PAYMENTSTATUS, 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef(), 
				CommonConstants.AGGREGATOR, CommonConstants.GET));
		
		LOGGER.info("GetPaymentStatusServiceImpl :: performGetPaymentStatusRequestPayload :: End");
		return getPaymentStatusReq;
	}
	
	/**
	 * @param getPaymentStatusRes
	 * @param billerPayRequestVO
	 * @return
	 */
	private BillerPayResponseVO performGetPaymentStatusResponse(
			GetPaymentStatusRes paymentStatusResponse, 
			BillerPayRequestVO billerPayRequestVo) throws Exception {
		
		BillerPayResponseVO billerPayResponseVo = new BillerPayResponseVO();
		BillerPayDetailsVO billerDetails = billerPayRequestVo.getBillerPayDetailsVO();
		String paymentStatus = null;
		String trackingId = null;
		boolean isPaymentAvailableInAggregator = true;
		try {
			if (paymentStatusResponse.getHeader() != null
					&& paymentStatusResponse.getHeader().getOriginationDetails() != null) {
				trackingId = paymentStatusResponse.getHeader().getOriginationDetails().getTrackingId();
			
				if(paymentStatusResponse.getHeader().getExceptions() != null && 
						paymentStatusResponse.getHeader().getExceptions().getException() != null) {
					
					ExceptionType exception = paymentStatusResponse.getHeader().getExceptions().getException().get(0);
					
					LOGGER.info("Payment failed for transaction :: " + trackingId);
					LOGGER.info("error code " + exception.getCode().getValue());
					LOGGER.info("error desc " + exception.getDescription());
					
					billerDetails.getTransactionInfoVO().setTxnStatusCd(exception.getCode().getValue());
					billerDetails.getTransactionInfoVO().setHostRespDesc(exception.getDescription());
					
					billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
					
				} else {
					LOGGER.info("Getting payment status for ::::::::: " + trackingId);
					
					if(paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes() != null &&
							paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo() != null) {
						
						LOGGER.info("Payment invoice object available ::::::::: " + trackingId);
						if (paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().
								getTransactionStatus() != null &&
							paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().
								getTransactionStatus().getStatusCode() != null) {
							
							paymentStatus = paymentStatusResponse.getGetPaymentStatusResPayload().
									getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus().getStatusCode();
							
							if (Arrays.asList(dataBean.getMap().get(CommonConstants.AGGREGATOR_NODATA_STATUS).
									split(CommonConstants.COMMA)).contains(paymentStatus) &&
									(paymentStatusResponse.getGetPaymentStatusResPayload().
										getGetPaymentStatusRes().getInvoiceInfo().
										getTransactionStatus().getStatusDescription() == null ||
									paymentStatusResponse.getGetPaymentStatusResPayload().
										getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus().
										getStatusDescription().equals(CommonConstants.EMPTY) ||
									paymentStatusResponse.getGetPaymentStatusResPayload().
										getGetPaymentStatusRes().getInvoiceInfo().getTransactionStatus().
										getStatusDescription().equalsIgnoreCase("Not Found"))) {
						
								isPaymentAvailableInAggregator = false;
								billerPayResponseVo.setStatus("DOIT");
								LOGGER.info("Payment not available in aggregator ::::::::: " + trackingId);
							}
						}
						
						if(isPaymentAvailableInAggregator && paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus() != null &&
							!paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus().isEmpty() &&
							paymentStatusResponse.getGetPaymentStatusResPayload().
								getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus().
								get(0).getTransactionStatus() != null) {
									
							PaymentStatus paymentStatusObj = paymentStatusResponse.getGetPaymentStatusResPayload().
									getGetPaymentStatusRes().getInvoiceInfo().getPaymentStatus().get(0);
							LOGGER.info("Payment status object available ::::::::: " + trackingId);
							
							paymentStatus = paymentStatusObj.getTransactionStatus();
							
							billerDetails.getTransactionInfoVO().setHostRespCd(
									paymentStatusObj.getTransactionStatus());
							billerDetails.getTransactionInfoVO().setHostRespDesc(
									paymentStatusObj.getMessage());
							LOGGER.info("Setting token for biller ::::::::: " +
									billerDetails.getUtilityCd() + 
									" ::::::::: " + trackingId);
							if(paymentStatusObj.getAggregatorTransactionID() != null){
								billerDetails.getTransactionInfoVO().setHostTxnRefNo(
										paymentStatusObj.getAggregatorTransactionID());
								LOGGER.info("dataBean.getMap() ::::::::: " +dataBean.getMap().
								get(CommonConstants.BILLERS_WITH_TOKEN).
								split(CommonConstants.COMMA)+" "+trackingId);
								if(billerDetails.getUtilityCd() != null && 
										Arrays.asList(dataBean.getMap().
										get(CommonConstants.BILLERS_WITH_TOKEN).
										split(CommonConstants.COMMA)).contains(
												billerDetails.getUtilityCd())) {
									LOGGER.info("Setting token for biller ::::::::: " +
											billerDetails.getUtilityCd() + 
											" ::::::::: " + trackingId);
									billerDetails.getTransactionInfoVO().setOtpRefNo(
										paymentStatusObj.getAggregatorTransactionID());
								}
							}
							
							if(paymentStatusObj.getInvoiceNumber() != null){
								billerDetails.getTransactionInfoVO().setOtpRefNo(
										paymentStatusObj.getInvoiceNumber());
							}
							
							if(Arrays.asList(dataBean.getMap().
									get(CommonConstants.AGGREGATOR_SUCCESS_STATUS).
									split(CommonConstants.COMMA)).contains(paymentStatus)) {
								LOGGER.info("Setting success ::: " + paymentStatus + " ::::: " + trackingId);
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
								
							} else if(Arrays.asList(dataBean.getMap().
									get(CommonConstants.AGGREGATOR_INPROCESS_STATUS).
									split(CommonConstants.COMMA)).contains(paymentStatus)) {
								LOGGER.info("Setting in-process ::: " + paymentStatus + " ::::: " + trackingId);
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_INPROCESS);
								
							} else if(Arrays.asList(dataBean.getMap().
									get(CommonConstants.AGGREGATOR_MANUAL_PROCESS_STATUS).
									split(CommonConstants.COMMA)).contains(paymentStatus)) {
								LOGGER.info("Setting mannual process ::: " + paymentStatus + " ::::: " + trackingId);
								billerDetails.setTxnActStatus(CommonConstants.MANUAL_PROCESS_STATUS);
							} else {
								LOGGER.info("Setting failure ::: " + paymentStatus + " ::::: " + trackingId);
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
							}
							
							billerPayResponseVo.setStatus("DONE");
						}
						LOGGER.info("Payment status from Aggregator:::: " + paymentStatus + 
								" ::::: " + trackingId);
						LOGGER.info("Payment success after aggregator call :::: " + 
								billerDetails.getTxnActStatus() + " ::::: " + trackingId);
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.info("Exception occurred in get payment status ::: " 
					+ " ::::: " + trackingId);
			throw exception;
		}
		
		billerPayResponseVo.setUser(billerPayRequestVo.getUser());
		billerPayResponseVo.setServiceVO(billerPayRequestVo.getServiceVO());
		billerPayResponseVo.setClientVO(billerPayRequestVo.getClientVO());
		billerPayResponseVo.setMessageVO(billerPayRequestVo.getMessageVO());
		billerPayResponseVo.setBillerPayDetailsVO(billerDetails);
		
		return billerPayResponseVo;
	}
	
	public void setInvoicePortType(InvoicePortType invoicePortType) {
		this.invoicePortType = invoicePortType;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
	
}
