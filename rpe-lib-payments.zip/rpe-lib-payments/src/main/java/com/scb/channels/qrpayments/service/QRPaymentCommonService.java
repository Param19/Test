package com.scb.channels.qrpayments.service;

import com.scb.channels.base.vo.QRPaymentDetailVO;

public interface QRPaymentCommonService {
	
	public String buildCardAcceptorName(QRPaymentDetailVO qrPaymentDetailVO);

}
