package com.scb.channels.payments.service;

import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.v5.customer.ContactDetails2;
import com.sc.corebanking.v5.customer.Customer;
import com.sc.corebanking.v5.customer.CustomerInfo;
import com.sc.corebanking.v5.customer.GetCustomerContactDetailsResPayload;
import com.sc.corebanking.v5.ws.provider.customer.CustomerPortType;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerContactDetailsReq;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerContactDetailsRes;
import com.sc.corebanking.v6.account.Account;
import com.sc.corebanking.v6.account.AccountInfo;
import com.sc.corebanking.v6.account.GetAccountDetailsResPayload;
import com.sc.corebanking.v6.account.SubsidiaryAccountMasterRelationship;
import com.sc.corebanking.v6.ws.provider.account.AccountPortType;
import com.sc.corebanking.v6.ws.provider.account.GetAccountDetailsReq;
import com.sc.corebanking.v6.ws.provider.account.GetAccountDetailsRes;
import com.sc.scbml_1.ExceptionType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.HostResponseTypeVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.StatusTypeVO;
import com.scb.channels.common.helper.NarrationHelper;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.dao.BillerDownloadDAO;

/**
 * The Class PaymentCommonService.
 *
 * @author 1493439
 */
public class PaymentCommonService {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentCommonService.class);
	
	/** The customer port type. */
	private CustomerPortType customerPortType;
	
	/** The account port type. */
	private AccountPortType accountPortType;
	
	/** The biller download dao. */
	private BillerDownloadDAO billerDownloadDAO;
	
	//CR1477, Orange Money changes Starts, 03Feb18, Vijayan A
	/** The dateBean. */
	private DataBean dataBean;
	
	/** The reference service. */
	public ReferenceService referenceService;
	
	/** The cache service. */
	private CacheManagementService cacheService;

	//CR1477, Orange Money Ends Starts, 03Feb18, Vijayan A
	
	

	/**
	 * Gets the cache service.
	 *
	 * @return the cacheService
	 */
	public CacheManagementService getCacheService() {
		return cacheService;
	}

	/**
	 * Sets the cache service.
	 *
	 * @param cacheService the cacheService to set
	 */
	public void setCacheService(CacheManagementService cacheService) {
		this.cacheService = cacheService;
	}

	
	public ReferenceService getReferenceService() {
		return referenceService;
	}


	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}


	public DataBean getDataBean() {
		return dataBean;
	}


	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	/**
	 * Gets the customer enqiury.
	 *
	 * @param payloadDTO the payload dto
	 * @return the customer enqiury
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	public PayloadDTO getCustomerEnqiury(PayloadDTO payloadDTO) throws DatatypeConfigurationException {
		
		LOGGER.info("PaymentTransactionServiceImpl getCustomerEnqiury start:::");
		InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
		String referenceNumber = inwardPaymentRequestVO.getReferenceNumber();
		InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
		GetCustomerContactDetailsReq customerContactDetailsReq = null;
		GetCustomerContactDetailsRes contactDetailsRes = null;
		LOGGER.info("PaymentTransactionServiceImpl getCustomerEnqiury referenceNumber:::"+referenceNumber);
		inwardPaymentRequestVO.setServiceName(CommonConstants.CB_CUSTOMER_SERVICE_NAME);
		customerContactDetailsReq = BillpaymentMappingHelper.processCustomerEnquiryRequest(inwardPaymentRequestVO);
		contactDetailsRes = customerPortType.getCustomerContactDetails(customerContactDetailsReq);
		GetCustomerContactDetailsResPayload contactDetailsResPayload =  contactDetailsRes.getGetCustomerContactDetailsResPayload();
		if(contactDetailsResPayload != null){
			LOGGER.info("PaymentTransactionServiceImpl contactDetailsResPayload:::"+contactDetailsResPayload.getGetCustomerContactDetailsRes()+" ::Reference Number:: "+referenceNumber);
			Customer customer =   contactDetailsResPayload.getGetCustomerContactDetailsRes();
			//LOGGER.info("PaymentTransactionServiceImpl customer:::"+customer);
			if(customer != null){
				CustomerInfo customerInfo = customer.getCustomerInfo();
				List<ContactDetails2> contactDetails = customerInfo.getContactDetails();
				
				//CR1477, Orange Money changes Starts, 03Feb18, Vijayan A
				String contactType = dataBean.getMap().get(inwardPaymentRequestVO.getClientInfoVO().getCountry() + CommonConstants.CUSTOMER_CONTACT_TYPE);
				
				if (StringUtils.isEmpty(contactType)) {
					contactType = dataBean.getMap().get(CommonConstants.CUSTOMER_CONTACT_TYPE);
				}
				contactType = StringUtils.isNotEmpty(contactType)?contactType: CommonConstants.CONTACT_TYPE;//Mobile Contact Type BY Default
				
				//CR1477, Orange Money changes Ends, 03Feb18, Vijayan A
				for(ContactDetails2 contactDetails2: contactDetails){
					LOGGER.info("PaymentTransactionServiceImpl contactDetails2 available :::"+referenceNumber);
				
					//CR1477, Orange Money changes Starts, 03Feb18, Vijayan A
					//Adding condition to check available contact type
					//if(contactDetails2.getContactTypeClassification().getValue().equalsIgnoreCase(CommonConstants.CONTACT_TYPE)){
					
					if(Arrays.asList(contactType.split(CommonConstants.COMMA)).contains(contactDetails2.getContactTypeClassification().getValue().toUpperCase())) {
						LOGGER.info("PaymentTransactionServiceImpl getContactTypeClassification:::"+referenceNumber);
						String ebbsMobileNumber = contactDetails2.getContactTelephoneNumber().getValue();
						if(StringUtils.isNotBlank(ebbsMobileNumber)){
							ebbsMobileNumber = StringUtils.trimToEmpty(StringUtils.replaceChars(ebbsMobileNumber, CommonConstants.SPECIAL_CHARACTERS, StringUtils.EMPTY));
							ebbsMobileNumber = StringUtils.stripStart(ebbsMobileNumber, CommonConstants.ZERO);
						}
						LOGGER.info("Ebbs Mobile number after format ebbsMobileNumber::: "+ebbsMobileNumber+" ::ReferenceNumber::"+referenceNumber);
						if(inwardPaymentRequestVO.getSenderInfoVO().getMobileNumber().equalsIgnoreCase(ebbsMobileNumber)){
							//LOGGER.info("PaymentTransactionServiceImpl if inwardPaymentRequestVO.getSenderInfoVO().getMobileNumber():::"+referenceNumber);
							LOGGER.info("PaymentTransactionServiceImpl : Ebbs Mobile number after format ebbsMobileNumber Inside if::: "+ebbsMobileNumber+" ::ReferenceNumber::"+referenceNumber);
							inwardPaymentResponseVO.setStatus(CommonConstants.CUSTOMER_STATUS_CHECK_CD);
							inwardPaymentResponseVO.setStatusDesc(CommonConstants.VALIDATION_SUCCESS);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDSUCC);
							inwardPaymentRequestVO.setHostStatusCode("H200");
							inwardPaymentResponseVO.setStatusTypeVO(null);
							inwardPaymentRequestVO.setHostStatusDescription(CommonConstants.MOBILE_VALIDATION_SUCCESS);
							break;
						} else {
							LOGGER.info("PaymentTransactionServiceImpl else inwardPaymentRequestVO.getSenderInfoVO().getMobileNumber():::ReferenceNumber: "+referenceNumber+"::: ebbsMobileNumber::"+ebbsMobileNumber);
							//LOGGER.info("Ebbs Mobile number after format ebbsMobileNumber Inside else::: "+ebbsMobileNumber+" ::ReferenceNumber::"+referenceNumber);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
							StatusTypeVO statusTypeVO = new StatusTypeVO();
							statusTypeVO.setStatusCode(ExceptionMessages._452.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._452.getMessage());
							HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
							hostResponseTypeVO.setCode(ExceptionMessages._452.getCode());
							hostResponseTypeVO.setDesc(ExceptionMessages._452.getMessage());
							hostResponseTypeVO.setHostName(CommonConstants.RPE);
							statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
							inwardPaymentResponseVO.setStatus(CommonConstants.FAIL);
							inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
							inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._452.getCode());
							inwardPaymentRequestVO.setHostStatusDescription(ExceptionMessages._452.getMessage());
						}
					}
				}
				
			} else if(contactDetailsRes.getHeader().getExceptions()!=null) {
				LOGGER.info("PaymentTransactionServiceImpl else condition:::"+referenceNumber);
					List<ExceptionType> exceptionTypes = contactDetailsRes.getHeader().getExceptions().getException();
					for(ExceptionType exceptionType : exceptionTypes){
						LOGGER.info("Exception Code:::: "+exceptionType.getCode());
						LOGGER.info("Exception Description:::: "+exceptionType.getDescription());
						StatusTypeVO statusTypeVO = new StatusTypeVO();
						statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
						if(exceptionType.getCode().getValue().equalsIgnoreCase(CommonConstants.TIMEOUT_CODE)){
							statusTypeVO.setStatusCode(ExceptionMessages._457.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._457.getMessage());
						} else {
							statusTypeVO.setStatusCode(ExceptionMessages._458.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._458.getMessage());
						}
						HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
						hostResponseTypeVO.setHostName(CommonConstants.CODE_EBBS);
						hostResponseTypeVO.setDesc(exceptionType.getDescription());
						hostResponseTypeVO.setCode(exceptionType.getCode().getValue());
						statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
						inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						inwardPaymentRequestVO.setHostStatusCode(exceptionType.getCode().getValue());
						inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());
						inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
						inwardPaymentRequestVO.setHostStatusCode(exceptionType.getCode().getValue());
						inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());
					}
			} else {
				
				LOGGER.info("No response payload from host ::: " +	inwardPaymentRequestVO.getReferenceNumber());
				HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setCode(ExceptionMessages._503.getCode());
				hostResponseTypeVO.setDesc("No response payload from host");
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._457.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._457.getMessage());
				statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
				statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
				inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._503.getCode());
				inwardPaymentRequestVO.setHostStatusDescription("No response payload from host");
			}
		} 
			
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		payloadDTO.setResponseVO(inwardPaymentResponseVO);
		return payloadDTO;
	}

	
	/**
	 * Gets the account enqiury.
	 *
	 * @param payloadDTO the payload dto
	 * @return the account enqiury
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	public PayloadDTO getAccountEnqiury(PayloadDTO payloadDTO) throws DatatypeConfigurationException {
		
		LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury start:::");
		InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
		String referenceNumber = inwardPaymentRequestVO.getReferenceNumber();
		InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
		GetAccountDetailsReq accountDetailsReq = new GetAccountDetailsReq();
		inwardPaymentRequestVO.setServiceName(CommonConstants.CB_ACCOUNT_SERVICE_NAME);
		GetAccountDetailsRes accountDetailsRes = null;
		LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury reference number:::"+referenceNumber);
		accountDetailsReq = BillpaymentMappingHelper.processAccountEnquiryRequest(inwardPaymentRequestVO);
		accountDetailsRes = accountPortType.getAccountDetails(accountDetailsReq);
		
		GetAccountDetailsResPayload getAccountDetailsResPayload = accountDetailsRes.getGetAccountDetailsResPayload();
	
		if(getAccountDetailsResPayload != null){
			LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury getAccountDetailsResPayload if condition:::"+referenceNumber);
			Account account = getAccountDetailsResPayload.getGetAccountDetailsRes();
			if(account != null){
				LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury account if condition:::"+referenceNumber);
				AccountInfo accountInfo = account.getAccountInfo();
				if(accountInfo != null){
					List<SubsidiaryAccountMasterRelationship> accountMasterRelationships =	accountInfo.getSubsidiaryAccountMasterRelationship();
					for(SubsidiaryAccountMasterRelationship accountMasterRelationship: accountMasterRelationships){
						if(accountMasterRelationship.getPrimaryRelationshipFlag().getValue().equalsIgnoreCase(CommonConstants.YES)){
							LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury getPrimaryRelationshipFlag if condition:::"+referenceNumber);
							inwardPaymentResponseVO.setStatus(CommonConstants.ACCOUNT_STATUS_CHECK_CD);
							inwardPaymentRequestVO.setRelId(accountMasterRelationship.getHolderRelationshipNumber().getValue());
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDSUCC);
							inwardPaymentRequestVO.setHostStatusCode(CommonConstants.THREE_ZEROES);
							inwardPaymentRequestVO.setHostStatusDescription(CommonConstants.SUCCESS);
							inwardPaymentResponseVO.setStatusTypeVO(null);
						} else {
							LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury getPrimaryRelationshipFlag else condition:::"+referenceNumber);
							StatusTypeVO statusTypeVO = new StatusTypeVO();
							statusTypeVO.setStatusCode(ExceptionMessages._451.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._451.getMessage());
							HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
							hostResponseTypeVO.setDesc(ExceptionMessages._451.getMessage());
							hostResponseTypeVO.setCode(ExceptionMessages._451.getCode());
							hostResponseTypeVO.setHostName(CommonConstants.RPE);
							statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
							inwardPaymentResponseVO.setStatus(CommonConstants.FAIL);
							inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
							inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._451.getCode());
							inwardPaymentRequestVO.setHostStatusDescription(ExceptionMessages._451.getMessage());
						}
					}
					
				}
			} else if(accountDetailsRes.getHeader().getExceptions()!=null){
				LOGGER.info("PaymentTransactionServiceImpl else condition:::"+referenceNumber);
					List<ExceptionType> exceptionTypes = accountDetailsRes.getHeader().getExceptions().getException();
					for(ExceptionType exceptionType : exceptionTypes){
						LOGGER.info("Exception Code:::: "+exceptionType.getCode()+" ::Reference Number::"+referenceNumber);
						LOGGER.info("Exception Description:::: "+exceptionType.getDescription());
						StatusTypeVO statusTypeVO = new StatusTypeVO();
						statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
						
						if(exceptionType.getCode().getValue().equalsIgnoreCase(CommonConstants.TIMEOUT_CODE)){
							statusTypeVO.setStatusCode(ExceptionMessages._457.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._457.getMessage());
						} else {
							statusTypeVO.setStatusCode(ExceptionMessages._458.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._458.getMessage());
						}
						
						HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
						hostResponseTypeVO.setHostName(CommonConstants.EBBS);
						hostResponseTypeVO.setDesc(exceptionType.getDescription());
						hostResponseTypeVO.setCode(exceptionType.getCode().getValue());
						statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
						inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						inwardPaymentRequestVO.setHostStatusCode(exceptionType.getCode().getValue());
						inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());
						inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
					}
			} else {
				LOGGER.info("No response payload from host ::: " +	inwardPaymentRequestVO.getReferenceNumber());
				HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setCode(ExceptionMessages._503.getCode());
				hostResponseTypeVO.setDesc("No response payload from host");
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				statusTypeVO.setStatusCode(ExceptionMessages._457.getCode());
				statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
				statusTypeVO.setStatusDesc(ExceptionMessages._457.getMessage());
				statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
				inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
				inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._503.getCode());
				inwardPaymentRequestVO.setHostStatusDescription("No response payload from host");
				}
		}
		LOGGER.info("PaymentTransactionServiceImpl getAccountEnqiury END::: " +	inwardPaymentRequestVO.getReferenceNumber());	
		inwardPaymentResponseVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		payloadDTO.setResponseVO(inwardPaymentResponseVO);
		
		return payloadDTO;
	}

	
	/**
	 * Gets the gregorian calendar.
	 *
	 * @return the gregorian calendar
	 */
	/*public XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

		} catch (DatatypeConfigurationException e) {

		}
		return date;
	}*/
	
	/**
	 * @param category
	 * @param biller
	 * @param country
	 * @return BillerCatgegoryReference
	 */
	public BillerCatgegoryReference getBillerCategoryReference(
			String category, String biller, String country){
		
		BillerCatgegoryReference billerReference = null;
		BillerCatgegoryReference categoryreference = null;
		BillerCatgegoryReference defaultReference = null;
		
		List<BillerCatgegoryReference> billerCategoryReferences = null;
		List<String> referenceValues = Arrays.asList(category, biller, CommonConstants.DEFAULT_CATEGORY);
		
		billerCategoryReferences = billerDownloadDAO.getCategoryReference(referenceValues, country);
		LOGGER.info("Obtained category reference from database ::: " 
				+ category + " ::: " + country);
		
		if(billerCategoryReferences != null){
			LOGGER.info("Obtained category reference inside billerCategoryReferences != null ::: " 	+billerCategoryReferences);
			for(BillerCatgegoryReference billerCatgegoryReference : billerCategoryReferences){
				if(billerCatgegoryReference.getCategoryId().equalsIgnoreCase(biller)){
					billerReference = billerCatgegoryReference;
				} else if (billerCatgegoryReference.getCategoryId().equalsIgnoreCase(category)) {
					categoryreference = billerCatgegoryReference;
				} else {
					defaultReference = billerCatgegoryReference;
				}
			}
		} else {
			LOGGER.info("Obtained category reference inside billerCategoryReferences != null else ::: " 	+billerCategoryReferences);
		}
		
		if(billerReference != null) {
			LOGGER.info("Obtained biller reference::: ");
			return billerReference;
		} else if (categoryreference != null) {
			LOGGER.info("Obtained category reference::: ");
			return categoryreference;
		} else {
			LOGGER.info("Returning default reference ::: " + defaultReference);
			return defaultReference;
		}
	}
	
	//CR1477, OrangeMoney Changes Starts, 10Feb18, Vijayan A
	/**
	 * @param decimalNotAllowCountries
	 * @param amount
	 * @param country
	 * @return boolean
	 */
	
	public boolean decimalAmountValidation(String decimalNotAllowCountries, String country, double amount){
		
		if(decimalNotAllowCountries != null){
			decimalNotAllowCountries = decimalNotAllowCountries.trim();
			String[] decimalNotAllows = decimalNotAllowCountries.split(CommonConstants.COMMA);
			List<String> arrayList = Arrays.asList(decimalNotAllows);
			LOGGER.info("InwardPaymentProcessor decimalAmountValidation "+ arrayList +" ::Amount:: "+amount);
		
			if(arrayList.contains(country)){
				if(amount%1 != 0){					
					LOGGER.info("InwardPaymentProcessor decimalAmountValidation amount%1 end Failed");
					return false;
				}
			}	
		}
		return true;		
	}
	
	/**
	 * Currency and decimal check.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return true, if successful
	 */
	public String currencyValidation(InwardPaymentRequestVO inwardPaymentRequestVO){
		LOGGER.info("InwardCreditPaymentProcessor currencyCheck start:::"+inwardPaymentRequestVO.getReferenceNumber());
		String flag = ExceptionMessages._454.getErrorCode() ; //invalid currency
		
		List<ISOCODESVO> isocodesvos = referenceService.getCurrency(inwardPaymentRequestVO.getClientInfoVO().getCountry());
		
		if(isocodesvos != null && isocodesvos.size()>0){
			LOGGER.info("InwardCreditPaymentProcessor currencyCheck isocodesvos:::"+isocodesvos);
			for(ISOCODESVO isocodesvo : isocodesvos){
				if(isocodesvo.getCurrencycode_char().equalsIgnoreCase(inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency())){
					LOGGER.info("InwardCreditPaymentProcessor currencyCheck isocodesvos currency check:::"+isocodesvos);
					flag = CommonConstants.SUCCESS;
					break;
				}
			}
		} else {
			flag = ExceptionMessages._456.getErrorCode(); //invalid country
		}

		LOGGER.info("InwardCreditPaymentProcessor currencyCheck end:::"+inwardPaymentRequestVO.getReferenceNumber());
		return flag;
	}
	
	/**
	 * Sets the narration.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the inward payment request vo
	 */
	public InwardPaymentRequestVO populateNarration(InwardPaymentRequestVO inwardPaymentRequestVO, String Channel, String category, String biller){
		LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig start !!!!!");
		List<NarrationVO> narrationConfig = null;
		narrationConfig = cacheService.getNarration(inwardPaymentRequestVO.getClientInfoVO().getCountry(), Channel);
		NarrationVO narrationVOObj = null;
		LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig is not null !!!!!");
		if(narrationConfig != null){
			LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig is not null !!!!!"+narrationConfig);
			
			for(NarrationVO narrationVO : narrationConfig){
				if(category != null && biller != null && category.equalsIgnoreCase(narrationVO.getCategoryId())
						&& biller.equalsIgnoreCase(narrationVO.getBillerId())){
					LOGGER.info("narrationConfig --- CategoryId and BillerId are matching !!!!!");
					narrationVOObj = narrationVO;
					break;
				}else if (biller != null &&  biller.equalsIgnoreCase(narrationVO.getCategoryId())){
					LOGGER.info("narrationConfig --- CategoryId is matching !!!!!");
					narrationVOObj = narrationVO;
					break;
				}else if(narrationVO.getBillerId() == null && narrationVO.getCategoryId() == null){
					LOGGER.info("narrationConfig --- Default  !!!!!");
					narrationVOObj = narrationVO;
					break;
				}		
			}		
		}
		
		LOGGER.info("InwardPaymentRequestVO setNarration narrationVOObj !!!!!"+narrationVOObj);
		InwardPaymentRequestVO inwardPaymentRequestVO2 = NarrationHelper.populateNarration(inwardPaymentRequestVO,narrationVOObj);
		LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig end !!!!!"+inwardPaymentRequestVO2);
		return inwardPaymentRequestVO2;
	}
	
	
	
	public boolean dailyLimitCheckValidation(String walletLimitCheckCountries, String country, double amount, double debitAmountPerDay, double dailyLimitCheckAmount){
		
		if(walletLimitCheckCountries != null){
			walletLimitCheckCountries = walletLimitCheckCountries.trim();
			String[] walletLimitCountries = walletLimitCheckCountries.split(CommonConstants.COMMA);
			List<String> arrayList = Arrays.asList(walletLimitCountries);
			LOGGER.info("InwardPaymentProcessor dailyLimitAmountValidation "+ arrayList +" ::Amount:: "+amount + " Max. daily Limit Check Amount :: " + dailyLimitCheckAmount);
			double debitSumAmountPerDay = amount + debitAmountPerDay;
			if(arrayList.contains(country)){
				if(debitSumAmountPerDay > dailyLimitCheckAmount){					
					LOGGER.info("InwardPaymentProcessor dailyLimitAmountValidation Transfer amount is greater than Max daily Limit");
					return false;
				}
			}	
		}
		return true;		
	}
	//CR1477, OrangeMoney Changes Ends, 10Feb18, Vijayan A
	
	/**
	 * Gets the customer port type.
	 *
	 * @return the customerPortType
	 */
	public CustomerPortType getCustomerPortType() {
		return customerPortType;
	}


	/**
	 * Sets the customer port type.
	 *
	 * @param customerPortType the customerPortType to set
	 */
	public void setCustomerPortType(CustomerPortType customerPortType) {
		this.customerPortType = customerPortType;
	}


	/**
	 * Gets the account port type.
	 *
	 * @return the accountPortType
	 */
	public AccountPortType getAccountPortType() {
		return accountPortType;
	}


	/**
	 * Sets the account port type.
	 *
	 * @param accountPortType the accountPortType to set
	 */
	public void setAccountPortType(AccountPortType accountPortType) {
		this.accountPortType = accountPortType;
	}


	/**
	 * @return the billerDownloadDAO
	 */
	public BillerDownloadDAO getBillerDownloadDAO() {
		return billerDownloadDAO;
	}


	/**
	 * @param billerDownloadDAO the billerDownloadDAO to set
	 */
	public void setBillerDownloadDAO(BillerDownloadDAO billerDownloadDAO) {
		this.billerDownloadDAO = billerDownloadDAO;
	}
}
