package com.scb.channels.payments.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.hibernate.classic.Session;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.payments.dao.PaymentDAO;

public class PaymentDAOImpl extends HibernateDaoSupport implements PaymentDAO  {
 

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentDAOImpl.class);
	
	
	public double getCustomerOverallPaymentAmount(PaymentDetailVO detailVO, String transactionStatus) {
		
		Session session = null;
		double totalAmount = 0;
		
		try {
		
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(PaymentDetailVO.class);			
			
			criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, detailVO.getCustomerId()));
			criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, detailVO.getCountryCode()));
		
			Date minDate = DateUtils.getDateWithoutTime(detailVO.getPaymentDate());
			Date maxDate = DateUtils.getDateWithMaxTime(minDate); 
			
			Conjunction con = Restrictions.conjunction();
			con.add(Restrictions.ge(HibernateHelper.PAYMENT_DATE, minDate));//The order date must be >= Date - 00h00
			con.add(Restrictions.lt(HibernateHelper.PAYMENT_DATE, maxDate));//And the order date must be < Date- 00h00
			
			LOGGER.info("PaymentDAOImpl: getCustomerOverallPaymentAmount, minDate, maxDate {}-{}", new Object[] {minDate, maxDate});
			
			criteria.add(con);  
			
			//criteria.add(Restrictions.sqlRestriction("TRUNC("+HibernateHelper.PAYMENT_DATE+") = TO_DATE('" + sDate + "','" + DateUtils.DateFormat_ddMMYYYY + "')"));
			//LOGGER.info("PaymentDAOImpl :getCustomerOverallPaymentAmount, criteria ",new Object[] {criteria});
			
			if(transactionStatus != null && !transactionStatus.isEmpty()) {
				criteria.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS, transactionStatus.split(CommonConstants.COMMA)));
			}
			
			if(detailVO.getPaymentType()!= null && !detailVO.getPaymentType().isEmpty())
				criteria.add(Restrictions.eq(HibernateHelper.PAYMENT_TYPE, detailVO.getPaymentType()));
			
		    
		    if(detailVO.getPaymentOption()!= null && !detailVO.getPaymentOption().isEmpty() )
				criteria.add(Restrictions.eq(HibernateHelper.PAYMENT_OPTION, detailVO.getPaymentOption()));
			
			criteria.setProjection(Projections.sum(HibernateHelper.PAYMENT_TOTAL_AMOUT));
			
			LOGGER.info("PaymentDAOImpl :getCustomerOverallPaymentAmount, criteria ", new Object[] {criteria});
						
			Object result = criteria.uniqueResult();
			LOGGER.info("PaymentDAOImpl :getCustomerOverallPaymentAmount, result ", new Object[] {result});
			
			if(result != null) {
				if(result instanceof Double) {
					totalAmount = (Double) result;
				} else if (result instanceof BigDecimal) {
					BigDecimal bd = (BigDecimal) result;
				
					if (bd != null)	
						totalAmount = bd.doubleValue();
				}
			}
			LOGGER.info("totalAmount {} ", new Object[] {totalAmount});
			
		}catch(Exception e) {
			logger.error("Data layer Error at getCustomerOverallPaymentAmount --> ", e);
		} finally {
			if(session != null) {
				LOGGER.info("PaymentDAOImpl :getCustomerOverallPaymentAmount, closing Session ");
				session.close();
			}
		}		
		return totalAmount;
	}

		
	public List<PaymentDetailVO> getPaymentHistoryByCustId(
			PaymentHistoryRequestVO paymentHistoryRequestVO) {
		LOGGER.info("Inside PaymentDAOImpl :: getPaymentHistoryByCustId :: Start"+paymentHistoryRequestVO.getMessageVO().getReqID());
		List<PaymentDetailVO> paymentRes = null;
		Session session = null;
		try {
			session = getHibernateTemplate().getSessionFactory().openSession();

          Criteria criteria = session.createCriteria(PaymentDetailVO.class);
        
          criteria.add(Restrictions.eq("customerId", paymentHistoryRequestVO.getUser().getCustomerId()));
          if(paymentHistoryRequestVO.getUser().getCountry()!= null){
        	  criteria.add(Restrictions.eq("countryCode", paymentHistoryRequestVO.getUser().getCountry()));
          }
		if(paymentHistoryRequestVO.getPaymentStatus() != null && !paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase("ALL")){
			if(paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.SUCC) || paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.SUCCESS)){
				criteria.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS,CommonConstants.SUCCESS_PAYMENT_LIST));
			}else if(paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.FAILED) || paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.FAILED_STAT)){
				criteria.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS,CommonConstants.FAIL_PAYMENT_LIST));
			}else if(paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.SUBM) || paymentHistoryRequestVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.SUBMITTED)){
				criteria.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS,CommonConstants.SUBMIT_PAYMENT_LIST));
			}else
				criteria.add(Restrictions.eq(HibernateHelper.PAYMENT_STATUS,paymentHistoryRequestVO.getPaymentStatus()));
		}else{
			criteria.add(Restrictions.ne(HibernateHelper.PAYMENT_STATUS, CommonConstants.NEW));
	
		}
		if(paymentHistoryRequestVO.getMinimumAmount() != null &&  paymentHistoryRequestVO.getMaximumAmount() != null){
			criteria.add(Restrictions.between(HibernateHelper.PAYMENT_AMOUNT, paymentHistoryRequestVO.getMinimumAmount(), paymentHistoryRequestVO.getMaximumAmount()));	
		}
		
		if(paymentHistoryRequestVO.getPaymentType() != null){
			criteria.add(Restrictions.eq(HibernateHelper.PAYMENT_TYPE,paymentHistoryRequestVO.getPaymentType()));	
		}
		
		if(paymentHistoryRequestVO.getFromDate() != null){
            LOGGER.debug("At PaymentHistory Service getPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{paymentHistoryRequestVO.getFromDate(), paymentHistoryRequestVO.getToDate()});
         Calendar cal = DateUtils.getCountryCalendar();
         Date toDat = cal.getTime();
         if(paymentHistoryRequestVO.getToDate() !=  null){
            toDat = paymentHistoryRequestVO.getToDate();
         }
        LOGGER.debug("At PaymentHistory Service iff part getPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{paymentHistoryRequestVO.getFromDate(), toDat});
            criteria.add(Restrictions.between(HibernateHelper.PAYMENT_DATE, paymentHistoryRequestVO.getFromDate(), toDat)); 
     }else{
            Calendar calendar = DateUtils.getCountryCalendar();
            calendar.add(Calendar.DAY_OF_YEAR, -30);
      Date fromDate = calendar.getTime();
      Calendar cal = DateUtils.getCountryCalendar();
      Date toDate = cal.getTime();
      LOGGER.debug("At PaymentHistory Service elseeeeee part getPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{fromDate, toDate});
      criteria.add(Restrictions.between(HibernateHelper.PAYMENT_DATE, fromDate, toDate));
     }

			
		criteria.addOrder(Order.desc(HibernateHelper.PAYMENT_DATE));
		logger.debug("beforre DB Fetch  ## at getCustomerPaymentHistory payment history");
		paymentRes = criteria.list();
		
		
		logger.debug("After DB Fetch at getCustomerPaymentHistory payment history size  ");
			if (!paymentRes.isEmpty()) {
				//Deleting duplicate records 
				Set<PaymentDetailVO> setValueFrDB = new LinkedHashSet<PaymentDetailVO>(paymentRes);
				List<PaymentDetailVO> modifiedResponse  =new LinkedList<PaymentDetailVO>(setValueFrDB);
				paymentRes = modifiedResponse;
				logger.info("After DB Fetch at getCustomerPaymentHistory Datalayer payment history size  "
						+ paymentRes.size());
			}
		}catch(Exception e) {
			 LOGGER.error("Exception occurred duirng PaymentHistory::: ",e);
		} finally {
			if(session != null) {
				LOGGER.info("PaymentDAOImpl :PaymentHistory, closing Session ");
				session.close();
			}
		}	
		return paymentRes; 
	}
	
	
	
	@Override
	public void savePayment(PaymentDetailVO paymentVO) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void updatePaymentStatus(PaymentDetailVO paymentVO) {
		// TODO Auto-generated method stub
		
	}
	
}
