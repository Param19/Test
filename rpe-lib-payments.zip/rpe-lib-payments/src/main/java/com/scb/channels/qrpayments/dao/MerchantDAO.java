package com.scb.channels.qrpayments.dao;

import com.scb.channels.base.vo.QRMerchantVO;

public interface MerchantDAO {
	
	public void savePayment(QRMerchantVO merchantVO);
	
	public QRMerchantVO getMerchant(QRMerchantVO merchantVO);

}
