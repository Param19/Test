package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.PostPaymentRes;
import com.sc.scbml_1.ExceptionType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.PaymentTransactionService;

public class BillPaymentResponseProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(BillPaymentResponseProcessor.class);
	
	PaymentTransactionService paymentTransactionService;
	
	private DataBean dataBean;
	
	public PayloadDTO process(PostPaymentRes paymentResponse){
		PayloadDTO payload = new PayloadDTO();
		BillerPayResponseVO response = new BillerPayResponseVO();
		BillerPayDetailsVO billerDetails = new BillerPayDetailsVO();
		TransactionInfoVO transaction = new TransactionInfoVO();
		
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();
		
		if(paymentResponse != null && paymentResponse.getHeader() != null &&
				paymentResponse.getHeader().getOriginationDetails() != null &&
				paymentResponse.getHeader().getOriginationDetails().getTrackingId() != null) {
			
			String trackingId = paymentResponse.getHeader().getOriginationDetails().getTrackingId();
			
			
			LOGGER.info("Fetch the payment details from the DB :::: " + 
					paymentResponse.getHeader().getOriginationDetails().getTrackingId());
			System.out.println("Fetch the payment details from the DB :::: " + 
					paymentResponse.getHeader().getOriginationDetails().getTrackingId());
			
			PaymentDetailVO paymentDetails = paymentTransactionService.getPaymentDetails(trackingId);
			
			if(paymentDetails != null){
				billerDetails = BillpaymentMappingHelper.
						getBillPayRequestFromPaymentDetails(paymentDetails);
				
				 transaction = billerDetails.getTransactionInfoVO(); //Retrieving transaction object - required for CR659
				
				LOGGER.info("Payment details object available :::: " + 
						paymentResponse.getHeader().getOriginationDetails().getTrackingId());
				System.out.println("Payment details object available :::: " + 
						paymentResponse.getHeader().getOriginationDetails().getTrackingId());
			
				
				billerDetails.setHostName(CommonConstants.AGGREGATOR);
				/*billerDetails.setPayRef(
						paymentResponse.getHeader().getOriginationDetails().getTrackingId());
				billerDetails.setCountryCode(
						paymentResponse.getHeader().getOriginationDetails().
						getMessageSender().getCountryCode());*/
				
				if(paymentResponse.getHeader().getExceptions() != null && 
						paymentResponse.getHeader().getExceptions().getException() != null) {
					
					ExceptionType exception = paymentResponse.getHeader().getExceptions().getException().get(0);
					
					LOGGER.info("Payment failed for transaction :: " + trackingId);
					LOGGER.info("error code " + exception.getCode().getValue());
					LOGGER.info("error desc " + exception.getDescription());
					
					transaction.setHostRespCd(exception.getCode().getValue());
					transaction.setHostRespDesc(exception.getDescription());
					
					billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
					billerDetails.setTransactionInfoVO(transaction);
					
				} else {
					if(paymentResponse.getPostPaymentResPayload() != null && 
							paymentResponse.getPostPaymentResPayload().
							getPostPaymentRes().getInvoiceInfo() != null &&
									paymentResponse.getPostPaymentResPayload().
							getPostPaymentRes().getInvoiceInfo().
							getPaymentDetails() != null) {
						
						PaymentDetails invoicePaymentDetails = 
								paymentResponse.getPostPaymentResPayload().getPostPaymentRes().
								getInvoiceInfo().getPaymentDetails().get(0);
						
						if(invoicePaymentDetails != null && invoicePaymentDetails.getTransactionStatus() != null) {
							LOGGER.info("Payment TransactionStatus object identified :::: " + 
									paymentResponse.getHeader().getOriginationDetails().getTrackingId());
							System.out.println("Payment TransactionStatus object identified :::: " + 
									paymentResponse.getHeader().getOriginationDetails().getTrackingId());
							
							transaction.setHostRespCd(
									invoicePaymentDetails.getTransactionStatus().getStatusCode());
							transaction.setHostRespDesc(
									invoicePaymentDetails.getTransactionStatus().getStatusDescription());
							
							if(invoicePaymentDetails.getAggregatorTransactionID() != null){
								transaction.setHostTxnRefNo(invoicePaymentDetails.getAggregatorTransactionID());
								
								if(billerDetails.getUtilityCd() != null && 
										Arrays.asList(dataBean.getMap().
										get(CommonConstants.BILLERS_WITH_TOKEN).
										split(CommonConstants.COMMA)).contains(
												billerDetails.getUtilityCd())) {
									LOGGER.info("Setting token for biller ::::::::: " +
											billerDetails.getUtilityCd() + 
											" ::::::::: " + trackingId);
									transaction.setOtpRefNo(invoicePaymentDetails.
											getAggregatorTransactionID());
								}
							}
							
							
							if(invoicePaymentDetails.getAggregatorTransactionID()==null && invoicePaymentDetails.getAggregatorTransactionReference() != null){
								transaction.setHostTxnRefNo(invoicePaymentDetails.getAggregatorTransactionReference());
								
								if(billerDetails.getUtilityCd() != null && 
										Arrays.asList(dataBean.getMap().
										get(CommonConstants.BILLERS_WITH_TOKEN).
										split(CommonConstants.COMMA)).contains(
												billerDetails.getUtilityCd())) {
									LOGGER.info("Payment Setting token for biller referece::::::::: " +
											billerDetails.getUtilityCd() + 
											" ::::::::: " + trackingId);
									//invoicePaymentDetails.getA
									transaction.setOtpRefNo(invoicePaymentDetails.
											getAggregatorTransactionReference());
								}
							}
							
							
							
							if(invoicePaymentDetails.getInvoiceNumber() != null){
								transaction.setOtpRefNo(invoicePaymentDetails.getInvoiceNumber());
							}
							
							if(transaction.getHostRespCd() != null && 
									Arrays.asList(dataBean.getMap().
											get(CommonConstants.AGGREGATOR_SUCCESS_STATUS).
											split(CommonConstants.COMMA)).
											contains(transaction.getHostRespCd())){
								
								LOGGER.info("Setting success ::: " + transaction.getHostRespCd());
								System.out.println("Setting success ::: " + transaction.getHostRespCd());
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
								
							} else if(transaction.getHostRespCd() != null && 
									Arrays.asList(dataBean.getMap().
											get(CommonConstants.AGGREGATOR_INPROCESS_STATUS).
											split(CommonConstants.COMMA)).
											contains(transaction.getHostRespCd())){
								LOGGER.info("Setting InProcess ::: " + transaction.getHostRespCd());
								System.out.println("Setting InProcess ::: " + transaction.getHostRespCd());
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_INPROCESS);
								
							} else if(transaction.getHostRespCd() != null && 
									Arrays.asList(dataBean.getMap().
											get(CommonConstants.AGGREGATOR_MANUAL_PROCESS_STATUS).
											split(CommonConstants.COMMA)).
											contains(transaction.getHostRespCd())){
								LOGGER.info("Setting Mannual Process ::: " + transaction.getHostRespCd());
								System.out.println("Setting Mannual Process ::: " + transaction.getHostRespCd());
								billerDetails.setTxnActStatus(CommonConstants.MANUAL_PROCESS_STATUS);
							} else {
								LOGGER.info("Setting failure ::: " + transaction.getHostRespCd());
								System.out.println("Setting failure ::: " + transaction.getHostRespCd());
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
							}
							
							LOGGER.info("Collected all required details :::: " + 
									billerDetails.getPayRef() + " :::: " +
									billerDetails.getCountryCode() + " :::: " + 
									billerDetails.getTransactionInfoVO().getHostRespCd() + " :::: " +
									billerDetails.getTransactionInfoVO().getHostRespDesc() + " :::: ");
							System.out.println("Collected all required details :::: " + 
									billerDetails.getPayRef() + " :::: " +
									billerDetails.getCountryCode() + " :::: " + 
									billerDetails.getTransactionInfoVO().getHostRespCd() + " :::: " +
									billerDetails.getTransactionInfoVO().getHostRespDesc() + " :::: ");
							
							user.setCustomerId(billerDetails.getCustomerId() != null ?
									billerDetails.getCustomerId() : CommonConstants.EMPTY);
							user.setCountry(billerDetails.getCountryCode());
							user.setChannelId(billerDetails.getChannel() != null ?
									billerDetails.getChannel() : CommonConstants.EMPTY);
							
							service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
							service.setServiceName(CommonConstants.BILL_PAYMENT);
							
							message.setReqID(billerDetails.getPayRef());
							message.setRequestCode(billerDetails.getPayRef());
							message.setCorrelationId(billerDetails.getPayRef());
							
							client.setChannel(billerDetails.getChannel() != null ?
									billerDetails.getChannel() : CommonConstants.EMPTY);
							client.setCountry(billerDetails.getCountryCode());
							
						} else {
							transaction.setHostRespCd(CommonConstants.NEGATIVE);
							transaction.setHostRespDesc("Missing Invoice details in payment response");
							billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
	
							LOGGER.info("Missing Payment TransactionStatus object details for payment status");
							System.out.println("Missing Payment TransactionStatus object details for payment status");
						}
					} else {
						transaction.setHostRespCd(CommonConstants.NEGATIVE);
						transaction.setHostRespDesc("Missing payload details in payment response");
						billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
						
						LOGGER.info("Missing payload details for payment status");
						System.out.println("Missing payload details for payment status");
					}
				}
				response.setStatus(CommonConstants.SUCC);
			}
		} else {
			transaction.setHostRespCd(CommonConstants.NEGATIVE);
			transaction.setHostRespDesc("Missing tracking id in payment response");
			billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			
			LOGGER.info("Payment Status Object is NULL");
			System.out.println("Payment Status Object is NULL");
			response.setStatus(CommonConstants.FAIL);
		}
		
		billerDetails.setHostName(CommonConstants.AGGREGATOR);
		billerDetails.setTransactionInfoVO(transaction);

		response.setBillerPayDetailsVO(billerDetails);
		response.setMessageVO(message);
		response.setServiceVO(service);
		response.setUser(user);
		response.setClientVO(client);
		
		payload.setResponseVO(response);
		return payload;
	}

	/**
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
}
