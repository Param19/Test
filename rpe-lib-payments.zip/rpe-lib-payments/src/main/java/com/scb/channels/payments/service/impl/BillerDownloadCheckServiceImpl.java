package com.scb.channels.payments.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BackupMasterBillerCategoryVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerDownloadHistory;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerFieldItemVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.base.vo.TempBillerField;
import com.scb.channels.base.vo.TempBillerFieldItemVO;
import com.scb.channels.base.vo.TempBillerVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.AggregatorMappingHelper;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.BillerDownloadCheckService;
import com.scb.channels.payments.service.CacheManagementService;

public class BillerDownloadCheckServiceImpl implements BillerDownloadCheckService {
	
	public BillerDownloadDAO billerDownloadDAO;
	
	private CacheManagementService cacheManagement;
	
	

	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadCheckServiceImpl.class);
	@Override
	public Boolean isActiverBillerCategoriesAvailable(String Country) throws BusinessException {
		boolean  isAvailable=false;
		LOGGER.info("Checking is any active Biller categories available");
		
		try{
			
			int billerCategoriesCount=billerDownloadDAO.getCountBillerCategories(Country);
			if(billerCategoriesCount==0){
				LOGGER.info("No  Biller categories available In DB Master table ");
				
			}else{
				LOGGER.info("Biller categories available In DB Master table  with count "+billerCategoriesCount);
				isAvailable=true;
			}
		}catch(Exception e){
			
			LOGGER.info(Country +"Exception while checking the available Biller categories count Intially "+e.getMessage());
			LOGGER.error(Country +"Exception while checking the available Biller categories count Intially ",e);
			LOGGER.info("BILLER DOWNLOAD FAILED " +Country);
			throw new BusinessException("Exception while retreiving the Biller categories count");
			
		}
		
		return isAvailable;
	}

	
	

	@Override
	public void intialBillersfromAggregator(PayloadDTO bean) {
		
		BillerDownloadRequest request= (BillerDownloadRequest)	bean.getRequestVO();
		String country=request.getUser().getCountry();
		BillerDownloadResponse response= (BillerDownloadResponse)	bean.getResponseVO();
		List<TempBillerCategoryVO>  temproaryCategories=response.getTempBillerCategory();
		List<BillerCategoryVO>  MaserCategories=response.getBillerCategory();
		LOGGER.info(country +" size of the Temporary Biller {} ",new Object[]{temproaryCategories.size()});
		AggregatorMappingHelper.getMappingempBillersCatgeoryToMasterCatgeory(temproaryCategories,MaserCategories);
		LOGGER.info(country +"size of the new Biller Categorie   {} ",new Object[]{MaserCategories.size()});
		billerDownloadDAO.saveMasterBiller(MaserCategories);
		updateJobStatus(country);
		
	}
	
	public void compareMasterAndAggragtorBiller(PayloadDTO bean){
		try{
			
		List<BackupMasterBillerCategoryVO> backupBiller= new ArrayList<BackupMasterBillerCategoryVO>();
		BillerDownloadRequest request= (BillerDownloadRequest)	bean.getRequestVO();
		String country=request.getUser().getCountry();
		BillerDownloadResponse response= (BillerDownloadResponse)	bean.getResponseVO();
		List<BillerDownloadHistory> history=response.getBillerDownloadHistory();
		List<TempBillerCategoryVO>  temproaryCategories=response.getTempBillerCategory();
		List<BillerCategoryVO>  masterBillers=billerDownloadDAO.getAllMasterBillersforCountry(request.getUser().getCountry(),response.getAggFetchFailedCategories(),response.getAggFetchFailedBillers());
		AggregatorMappingHelper.getBackupfromMaster(masterBillers, backupBiller);
		LOGGER.info("Completed backup data from master --- "+backupBiller.size());
		billerDownloadDAO.saveBackupDatafromMaster(country, backupBiller);
		inActiveVarianceBiller(temproaryCategories,masterBillers,history);
		
		LOGGER.info("comparing  both Master Catgeory ID &tempCategoryId  Completed   {temproaryCategories}--{masterBillers}",new Object[]{temproaryCategories.size(),masterBillers.size()});
		
		billerDownloadDAO.saveMasterBiller(masterBillers);
		LOGGER.info("Completed new biller and old biller data");
		updateJobStatus(country);
		cacheManagement.clearBillerCache(country);
		}catch(Exception error){
			LOGGER.info("excpetion while compare and storing into DB .",error);
			LOGGER.info("excpetion while compare and storing into DB ."+error.getMessage());
			LOGGER.info("BILLER DOWNLOAD FAILED " +bean.getRequestVO().getUser().getCountry());
		}
	}
	
	
	public void inActiveVarianceBiller(List<TempBillerCategoryVO> tempCategory,List<BillerCategoryVO> masterCatgory,List<BillerDownloadHistory> history){

		boolean isCategoryPresent=false;
		List<TempBillerCategoryVO>  newCategory=new ArrayList<TempBillerCategoryVO>();
		
			for(TempBillerCategoryVO  aggCategory:tempCategory){
					String tempCategoryId=aggCategory.getCategoryId();
				for(BillerCategoryVO  MasterCategory:masterCatgory ){
					
					String mastCategoryId=MasterCategory.getCategoryId();
					
					LOGGER.info("comparing  both Master Catgeory ID &tempCategoryId   {master} -{tempcategoryId}",new Object[]{mastCategoryId,tempCategoryId});
					if(StringUtils.isNotBlank(mastCategoryId)&& StringUtils.isNotBlank(tempCategoryId)){
						if(mastCategoryId.equalsIgnoreCase(tempCategoryId)){
							
							MasterCategory.setStatusCode(CommonConstants.ACTIVE);
							MasterCategory.setDateUpdated(InvoiceAggregatorhelper.getCurrentTimestamp());
							checkForValidAndInvalidBillers(MasterCategory,aggCategory,history);
							Set<TempBillerVO>  newBillers =checkNewValidBillers(MasterCategory,aggCategory);
								
								if(newBillers.size()>0){
									InvoiceAggregatorhelper.downloadHistorycategoryforNewTempBillersSet(newBillers,aggCategory,CommonConstants.ACTIVE,CommonConstants.NEW_BILLER,history);
									Set<BillerVO> listofnewBillers=	InvoiceAggregatorhelper.mapSpecificBiller(newBillers,MasterCategory);
									MasterCategory.getBillers().addAll(listofnewBillers);
								}
							LOGGER.info("This category is Still active",new Object[]{mastCategoryId,MasterCategory.getCategoryName(),tempCategoryId,aggCategory.getCategoryName()});	
							
							LOGGER.info("for category checking for the Biller actvie of not");
							
							isCategoryPresent=true;
							break;
						}
						
					} else{
						
					LOGGER.info("some thing goes wrong with biller categories{master} -{tempcategoryId}",new Object[]{mastCategoryId,tempCategoryId});
					}
					
				}
				
				if(!isCategoryPresent){
					LOGGER.info("THis category comes newly {tempCategoryId}  ",new Object[]{tempCategoryId});
					
					newCategory.add(aggCategory);
				}
				isCategoryPresent=false;
			}
		
			
			
				//** BillerCategoryVO  MasterCategory:masterCatgory  **//*
			
			for(BillerCategoryVO  MasterCategorys:masterCatgory ){
					for(TempBillerCategoryVO  aggCategorys:tempCategory){
						String mastCategoryIds=MasterCategorys.getCategoryId();
						String tempCategoryIds=aggCategorys.getCategoryId();
						if(mastCategoryIds.equalsIgnoreCase(tempCategoryIds)){
							LOGGER.info("this category is equals with new as well"+tempCategoryIds +aggCategorys.getCategoryName());
							LOGGER.info("this category is equals with new as well {}--{} ",new Object[]{MasterCategorys.getId(),MasterCategorys.getCategoryName(),MasterCategorys.getCategoryId()});
							isCategoryPresent=true;
							 
						break;
						}
						
					}
				
					LOGGER.info("this category is inActive  {}--{} ",new Object[]{MasterCategorys.getId(),MasterCategorys.getCategoryName(),MasterCategorys.getCategoryId()});
					if(!isCategoryPresent){
					MasterCategorys.setStatusCode(CommonConstants.D);
					InvoiceAggregatorhelper.makeinActiveBillerforInactiveCategories(MasterCategorys);	
					}
					isCategoryPresent=false;

			}
	
			 
			
			if(newCategory.size()>0){
			
				List<BillerCategoryVO>  actvieCatgeories=InvoiceAggregatorhelper.maptempCategoriestoActiveCategories(newCategory);
				masterCatgory.addAll(actvieCatgeories);
				
			}
		
		System.out.println(masterCatgory);	
		InvoiceAggregatorhelper.enrichMasterCategoryData(masterCatgory);
			
		
	}
	
	
					
	/**
	 * @param masterCategory
	 * @param aggCategory
	 * @return  invalid and valid Billers for particular Category
	 */
	public void checkForValidAndInvalidBillers(BillerCategoryVO  masterCategory,TempBillerCategoryVO  aggCategory,List<BillerDownloadHistory> history){
		boolean isBillerPresent=false;
		//Set<BillerVO> inavlidAndValidBillers=new HashSet<BillerVO>();
		Set<BillerVO> masterBillerList=masterCategory.getBillers();
		Set<TempBillerVO> tempBillerList=aggCategory.getBillers();
		for(BillerVO masterBiller:masterBillerList){
 			for(TempBillerVO tempBiller:tempBillerList){
				String tempBillerUniqueId=tempBiller.getBillerUniqueId();
				String masterBillerUniqueId=masterBiller.getBillerUniqueId();
				if(StringUtils.isNotBlank(tempBillerUniqueId)&& StringUtils.isNotBlank(masterBillerUniqueId)){
						if(tempBillerUniqueId.equalsIgnoreCase(masterBillerUniqueId)){
							
							if(masterBiller.getStatusCode().equals(CommonConstants.D)){
								InvoiceAggregatorhelper.downloadHistoryforExistBiller(masterBiller, masterCategory,CommonConstants.ACTIVE, CommonConstants.D2A, null);
							}else{
								masterBiller.setDateUpdated(InvoiceAggregatorhelper.getCurrentTimestamp());	
							}
							
							
							masterBiller.setStatusCode(CommonConstants.ACTIVE);
							masterBiller.setIsOnline(tempBiller.getIsOnline());
							masterBiller.setUpdatedBy(tempBiller.getUpdatedBy());
							masterBiller.setDateUpdated(tempBiller.getDateUpdated());
					 		masterBiller.setMaximumAmount(tempBiller.getMaximumAmount());
					 		masterBiller.setMinimumAmount(tempBiller.getMinimumAmount());
					 		masterBiller.setDefaultAmount(tempBiller.getDefaultAmount());
					 		masterBiller.setDateUpdated(tempBiller.getDateUpdated());
					 		masterBiller.setBillerProductName(tempBiller.getBillerProductName());
					 		masterBiller.setBillerDesc(tempBiller.getBillerDesc());
					 		//Biller short name update --Start
					 		masterBiller.setBillerShortName(tempBiller.getBillerDesc());
					 		//Biller short name end    --End
					 		masterBiller.setBillPresentmentType(tempBiller.getBillPresentmentType());
					 		updateBillerFieldsCS(masterBiller,tempBiller);
 					 		//inavlidAndValidBillers.add(masterBiller);
					 		isBillerPresent=true;
							LOGGER.info("This Biller Id is Still active",new Object[]{tempBillerUniqueId,masterBillerUniqueId});
							break;			
				}else{
					// updateBillerFields(masterBiller,tempBiller);
					LOGGER.info("  billers are not equal",new Object[]{tempBillerUniqueId,masterBillerUniqueId});
				}
			}
				
		}
 			LOGGER.info("Setting this Biller as inactive ..." +masterBiller.getBillerUniqueId());
		if(!isBillerPresent){
			masterBiller.setStatusCode(CommonConstants.D);
			InvoiceAggregatorhelper.downloadHistoryforExistBiller(masterBiller, masterCategory,CommonConstants.D, CommonConstants.A2D, history);
			//masterBiller.setDateUpdated(InvoiceAggregatorhelper.getCurrentTimestamp());	
		}
		isBillerPresent=false;
 		//inavlidAndValidBillers.add(masterBiller);
	}
	
	 
		 
	}
	
	/**
	 * @param masterBiller
	 * @param tempBiller
	 * 
	 * This method performs the biller fields updation
	 */
	@SuppressWarnings("unused")
	private void updateBillerFieldsCS(BillerVO masterBiller, TempBillerVO tempBiller) {
		LOGGER.info("BillerDownloadCheckServiceImpl :: updateBillerFields --START");
		BillerField newBillerField = null;
		boolean isExistingFieldPresent=false;
		if(masterBiller.getBillerFields()!=null && masterBiller.getBillerFields().isEmpty()){
			for (TempBillerField tempBillerField : tempBiller.getBillerFields()) {
				addNewField(masterBiller, tempBiller, tempBillerField);
			}
		}else{
		for (BillerField billerFeilds : masterBiller.getBillerFields()) {
			if(billerFeilds.getFieldType() ==null){
				billerFeilds.setFieldType("P");	
			}
			isExistingFieldPresent=false;
			for (TempBillerField tempBillerField : tempBiller.getBillerFields()) {
				if(billerFeilds.getFieldLabelName().equalsIgnoreCase(tempBillerField.getFieldLabelName()) 
						&& billerFeilds.getFieldType().equalsIgnoreCase(tempBillerField.getFieldType())){
					//Biller field items update --Start
					updateBillerFiledItems(billerFeilds,tempBillerField);
					//Biller field items update --end
					billerFeilds.setCountryCode(tempBiller.getCountryCode());
					billerFeilds.setChannelCode(CommonConstants.IBANK);
					billerFeilds.setCreatedBy(CommonConstants.SYSTEM);
					billerFeilds.setUpdatedBy(CommonConstants.SYSTEM);
					billerFeilds.setDateCreated(new Timestamp(System.currentTimeMillis()));
					billerFeilds.setDateUpdated(new Timestamp(System.currentTimeMillis()));
					billerFeilds.setFieldLabelName(tempBillerField.getFieldLabelName());
					billerFeilds.setFieldDataType(tempBillerField.getFieldDataType());
					billerFeilds.setFieldMaxLength(tempBillerField.getFieldMaxLength());
					billerFeilds.setFieldMinLength(tempBillerField.getFieldMinLength());
					billerFeilds.setStatus(CommonConstants.ACTIVE);
					billerFeilds.setOrderSequence(tempBillerField.getOrderSequence());
					billerFeilds.setCaption(tempBillerField.getCaption());
					billerFeilds.setFieldType(tempBillerField.getFieldType());
					billerFeilds.setIsfieldRequired(tempBillerField.getIsfieldRequired());
					billerFeilds.setVersion(0);
					//masterBiller.getBillerFields().add(billerFeilds);
					isExistingFieldPresent=true;
					break;
				}
			}
			billerFeilds.setStatus(isExistingFieldPresent?CommonConstants.ACTIVE:CommonConstants.D);
			masterBiller.getBillerFields().add(billerFeilds);
		}
		isExistingFieldPresent=false;
		for(TempBillerField tempBillerField : tempBiller.getBillerFields()){
			isExistingFieldPresent=false;
			for (BillerField billerFeilds : masterBiller.getBillerFields()) {
				if(billerFeilds.getFieldLabelName().equalsIgnoreCase(tempBillerField.getFieldLabelName()) && billerFeilds.getFieldType().equalsIgnoreCase(tempBillerField.getFieldType())){
					isExistingFieldPresent=true;
				}
			}
			if(!isExistingFieldPresent){
				addNewField(masterBiller, tempBiller, tempBillerField);	
			}
		}
		
		}
		LOGGER.info("BillerDownloadCheckServiceImpl :: updateBillerFields --START");
	}
	
	/**
	 * @param billerFeilds
	 * @param tempBillerField
	 */
	private void updateBillerFiledItems(BillerField masterbillerFeild, TempBillerField tempBillerField) {
		LOGGER.info("BillerDownloadCheckServiceImpl :: updateBillerFields --START");
		//BillerFieldItemVO billerFieldItemVO = null;
		boolean isExistingFieldItmPresent=false;
		if(masterbillerFeild.getBillerFieldItems() !=null && masterbillerFeild.getBillerFieldItems().isEmpty()){
			for (TempBillerFieldItemVO  tempBillerFieldItemVO: tempBillerField.getBillerFieldItems()) {
				addNewFieldItem(masterbillerFeild, tempBillerFieldItemVO);
			}
		}else{
		for (BillerFieldItemVO billerFieldItemVO : masterbillerFeild.getBillerFieldItems()) {
			isExistingFieldItmPresent=false;
			for (TempBillerFieldItemVO tempBillerFieldItemVO : tempBillerField.getBillerFieldItems()) {
				if(billerFieldItemVO.getId().equalsIgnoreCase(tempBillerFieldItemVO.getId())){
					billerFieldItemVO.setDescription(tempBillerFieldItemVO.getDescription());
					billerFieldItemVO.setRemarks(tempBillerFieldItemVO.getRemarks());
					billerFieldItemVO.setStatus(tempBillerFieldItemVO.getStatus());
					billerFieldItemVO.setBillerField(masterbillerFeild);
					isExistingFieldItmPresent=true;
					break;
				}
			}
			billerFieldItemVO.setStatus(isExistingFieldItmPresent?CommonConstants.ACTIVE:CommonConstants.D);
			masterbillerFeild.getBillerFieldItems().add(billerFieldItemVO);
		}
		for(TempBillerFieldItemVO  tempBillerFieldItemVO: tempBillerField.getBillerFieldItems()){
			isExistingFieldItmPresent=false;
			for (BillerFieldItemVO billerFieldItemVO : masterbillerFeild.getBillerFieldItems()) {
				if(billerFieldItemVO.getId().equalsIgnoreCase(tempBillerFieldItemVO.getId())){
					isExistingFieldItmPresent=true;
				}
			}
			if(!isExistingFieldItmPresent){
				addNewFieldItem(masterbillerFeild, tempBillerFieldItemVO);	
			}
		}
		}
		LOGGER.info("BillerDownloadCheckServiceImpl :: updateBillerFields --START");
	}
	/**
	 * @param masterbillerFeild
	 * @param tempBillerField
	 * @param tempBillerFieldItemVO
	 */
	private void addNewFieldItem(BillerField masterbillerFeild, TempBillerFieldItemVO tempBillerFieldItemVO) {
		LOGGER.info("BillerDownloadCheckServiceImpl :: addNewFieldItem --START");
		BillerFieldItemVO billerFieldItemVO=new BillerFieldItemVO();
		billerFieldItemVO.setId(tempBillerFieldItemVO.getId());
		billerFieldItemVO.setDescription(tempBillerFieldItemVO.getDescription());
		billerFieldItemVO.setRemarks(tempBillerFieldItemVO.getRemarks());
		billerFieldItemVO.setStatus(tempBillerFieldItemVO.getStatus());
		billerFieldItemVO.setBillerField(masterbillerFeild);
		masterbillerFeild.getBillerFieldItems().add(billerFieldItemVO);
		LOGGER.info("BillerDownloadCheckServiceImpl :: addNewFieldItem --END");
		
	}
	/**
	 * @param masterBiller
	 * @param tempBiller
	 * @param tempBillerField
	 */
	private void addNewField(BillerVO masterBiller, TempBillerVO tempBiller, TempBillerField tempBillerField) {
		BillerField newBillerField;
		newBillerField = new BillerField();
		BillerFieldItemVO billerFieldItemVO=null;
		Set<BillerFieldItemVO> setBillerFieldItemVO=new HashSet<>();
		newBillerField.setCountryCode(tempBillerField.getCountryCode());
		newBillerField.setChannelCode(CommonConstants.IBANK);
		newBillerField.setCreatedBy(CommonConstants.SYSTEM);
		newBillerField.setUpdatedBy(CommonConstants.SYSTEM);
		newBillerField.setDateCreated(new Timestamp(System.currentTimeMillis()));
		newBillerField.setDateUpdated(new Timestamp(System.currentTimeMillis()));
		newBillerField.setFieldLabelName(tempBillerField.getFieldLabelName());
		newBillerField.setFieldDataType(tempBillerField.getFieldDataType());
		newBillerField.setFieldMaxLength(tempBillerField.getFieldMaxLength());
		newBillerField.setFieldMinLength(tempBillerField.getFieldMinLength());
		newBillerField.setFieldType(tempBillerField.getFieldType());
		newBillerField.setIsfieldRequired(tempBillerField.getIsfieldRequired());
		newBillerField.setStatus(CommonConstants.ACTIVE);
		newBillerField.setOrderSequence(tempBillerField.getOrderSequence());
		newBillerField.setVersion(0);
		newBillerField.setCaption(tempBillerField.getCaption());
		if(tempBillerField.getBillerFieldItems()!=null && !tempBillerField.getBillerFieldItems().isEmpty()){
			for(TempBillerFieldItemVO tempBillerFieldItemVO :tempBillerField.getBillerFieldItems()){
				billerFieldItemVO=new BillerFieldItemVO();
				billerFieldItemVO.setId(tempBillerFieldItemVO.getId());
				billerFieldItemVO.setDescription(tempBillerFieldItemVO.getDescription());
				billerFieldItemVO.setRemarks(tempBillerFieldItemVO.getRemarks());
				billerFieldItemVO.setStatus(tempBillerFieldItemVO.getStatus());
				billerFieldItemVO.setBillerField(newBillerField);
				setBillerFieldItemVO.add(billerFieldItemVO);
			}
			newBillerField.setBillerFieldItems(setBillerFieldItemVO);
		}else{
			LOGGER.info("BillerDownloadCheckServiceImpl :: addNewField --ITEMS EMPTY");	
		}
		
		masterBiller.getBillerFields().add(newBillerField);
	}
	
	/**
	 * @param masterBiller
	 * @param tempBiller
	 * 
	 * This method performs the biller fields updation
	 */
	private void updateBillerFields(BillerVO masterBiller, TempBillerVO tempBiller) {
		LOGGER.info("BillerDownloadCheckServiceImpl :: updateBillerFields --START");
		BillerField newBillerField = null;
        int cnt =0;
		for (BillerField billerFeilds : masterBiller.getBillerFields()) {
			billerFeilds.setStatus("D");
			cnt++;
		}
	//	LOGGER.info("Deleted biller cnt " +cnt);
		cnt=0;
		for (TempBillerField tempBillerField : tempBiller.getBillerFields()) {
			addNewField(masterBiller, tempBiller, tempBillerField);
           cnt++;
		}
		//LOGGER.info("New Biller Cnt " +cnt);
		LOGGER.info("BillerDownloadCheckServiceImpl :: updateBillerFields --START");
	}
	public Set<TempBillerVO> checkNewValidBillers(BillerCategoryVO  masterCategory,TempBillerCategoryVO  aggCategory){
		boolean isBillerNew=true;
		Set<TempBillerVO> validBillers=new HashSet<TempBillerVO>();
		Set<BillerVO> masterBillerList=masterCategory.getBillers();
		Set<TempBillerVO> tempBillerList=aggCategory.getBillers();
		
		for(TempBillerVO tempBiller:tempBillerList){
	 			for(BillerVO masterBiller:masterBillerList){
					String tempBillerUniqueId=tempBiller.getBillerUniqueId();
					String masterBillerUniqueId=masterBiller.getBillerUniqueId();
					if(StringUtils.isNotBlank(tempBillerUniqueId)&& StringUtils.isNotBlank(masterBillerUniqueId)){
							if(tempBillerUniqueId.equalsIgnoreCase(masterBillerUniqueId)){
								isBillerNew=false;
								LOGGER.info("This Biller Id is Still active",new Object[]{tempBillerUniqueId,masterBillerUniqueId});
								break;			
						 	}
					}else{
						LOGGER.info("some thing goes wrong with billers",new Object[]{tempBillerUniqueId,masterBillerUniqueId});
					}
			}
 	 		
 			if(isBillerNew){
 	 			LOGGER.info("Setting this Biller as active ..." +tempBiller.getBillerUniqueId());
	 			validBillers.add(tempBiller);
	 		}
 	
 			isBillerNew=true;
	}
		
		return validBillers;
	}

	public void updateJobStatus(String country){
		
		billerDownloadDAO.updatefinalJobStatus(country);
		
		
	}
	

	public CacheManagementService getCacheManagement() {
		return cacheManagement;
	}


	public void setCacheManagement(CacheManagementService cacheManagement) {
		this.cacheManagement = cacheManagement;
	}
	
	public BillerDownloadDAO getBillerDownloadDAO() {
		return billerDownloadDAO;
	}
	public void setBillerDownloadDAO(BillerDownloadDAO billerDownloadDAO) {
		this.billerDownloadDAO = billerDownloadDAO;
	}
	@Override
	public void updatePayeesOnceDownloadDone(String country) {
		billerDownloadDAO.saveUpdatePayeesOnceDownloadDone(country);
		
	}

}