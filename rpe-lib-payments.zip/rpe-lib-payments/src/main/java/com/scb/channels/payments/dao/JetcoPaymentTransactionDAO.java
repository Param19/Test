package com.scb.channels.payments.dao;

import com.scb.channels.base.exception.DAOException;
import com.scb.channels.base.vo.JetcoPaymentDetailVO;

/**
 * JETCO payment transaction dao
 * 
 * @author 1552545
 * 
 */
public interface JetcoPaymentTransactionDAO {

	/**
	 * get JETCO payment details by messageId
	 * 
	 * @param messageId
	 *            the bank message id
	 * @return
	 */
	public JetcoPaymentDetailVO getJetcoPaymentDetails(String messageId);

	/**
	 * get JETCO payment details by sender account number, receiver mobile number, transaction amount.
	 *
	 * @param payment
	 *            the SC pay details VO
	 * @return
	 */
	public JetcoPaymentDetailVO getMatchJetcoPaymentDetails(JetcoPaymentDetailVO payment);

	/**
	 * save JETCO payment details.
	 * 
	 * @param payment
	 *            the SC pay details VO
	 */
	public JetcoPaymentDetailVO saveJetcoPayment(JetcoPaymentDetailVO payment);

	/**
	 * update JETCO payment details.
	 * 
	 * @param payment
	 *            the SC pay details VO
	 */
	public void updatePaymentStatus(JetcoPaymentDetailVO payment) throws DAOException;

}
