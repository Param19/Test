package com.scb.channels.payments.processor;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ApplicationContext;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.qrpayments.processor.QRVisaPaymentProcessor;

public class PaymentsGeneralProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentsGeneralProcessor.class);

	private DataBean dataBean;
	
	public boolean checkCashAdvance(PayloadDTO payload){
		LOGGER.info("checkCashAdvance method: start ");
		BillerPayDetailsVO billerPayDetailsVO = null;
		BillerPayResponseVO responseVO = (BillerPayResponseVO)payload.getResponseVO();
		List<String> listBillerCats = null; 
		List<String> listCountries = null;
		
		try {
			if(responseVO != null && responseVO.getBillerPayDetailsVO()!=null){
				billerPayDetailsVO = responseVO.getBillerPayDetailsVO();
				// get configured list of billerCategoryDesc values from dataBean
				Object billerCategories = dataBean.getMap().get(CommonConstants.CASHADVANCE_BILLERCATEGORIES);
				Object countries =  dataBean.getMap().get(CommonConstants.CASHADVANCE_COUNTRIES);
				listBillerCats = (billerCategories != null)?Arrays.asList(billerCategories.toString().split(CommonConstants.COMMA)):null;
				listCountries = (countries!=null)?Arrays.asList(countries.toString().split(CommonConstants.COMMA)):null;
				LOGGER.info("billerCategories: "+ billerCategories +" :: listCountries: " + listCountries );
			
				if(listBillerCats != null && listCountries !=null){
					//check if the incoming request's billerCategoryDesc matches with anyone of the configured values			
					if (listBillerCats.contains(billerPayDetailsVO.getBillerCategoryDesc())
							&& listCountries.contains(billerPayDetailsVO.getCountryCode())) {
						LOGGER.info("CashAdvance Biller Category Found!" + billerPayDetailsVO.getBillerCategoryDesc() + " :: " + billerPayDetailsVO.getPayRef());
						return true; 
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.error("Exception occured while checkCashAdvance " +exception);
		}finally{
			
			LOGGER.info("checkCashAdvance method: end ");
		}
		return false;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	
	/**
	 * Method to clear MDC object 
	 * Helps to avoid cross logging 
	 * ex. writing KE logs in NG directory
	 */
	public void clearMDC(){
		//System.out.println(":: Clearing MDC object ::");
		ApplicationContext.remove();
	}
}
