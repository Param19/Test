package com.scb.channels.qrpayments.service;

import com.scb.channels.base.vo.QRMerchantVO;

public interface MerchantDetailService {
	
	public void saveMerchant(QRMerchantVO merchantVO);

}
