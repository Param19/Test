package com.scb.channels.qrpayments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.qrpayments.service.QRDebitCardService;

public class QRCasaPaymentProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRCasaPaymentProcessor.class);
	
	private QRDebitCardService qrDebitCardService;
	
	public PayloadDTO processAuthorization(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in QR DebitCard Authorization Processor :::: Start");
		
		QRPaymentRequestVO  qrPaymentRequestVO  = null;
		QRPaymentResponseVO qrPaymentResponseVO = null;
		try{
			if(bean != null && bean.getRequestVO() != null){
				qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
				LOGGER.info("Posting request to EURONET ::: ");
				qrPaymentResponseVO = qrDebitCardService.authorizeDebitCard(qrPaymentRequestVO);
			}
		}catch(Exception e){
			LOGGER.error("Error inside QRCasaPaymentProcessor processAuthorization :::  ",e);
			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO(); 
			}
			LOGGER.info("Setting Fail status for the debit_card authorization due to Exception ::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			qrPaymentResponseVO.setStatus(ExceptionMessages._105.getCode());
			qrPaymentResponseVO.setStatusDesc(e.getMessage());
			qrPaymentResponseVO.setErrorDesc(e.getMessage());
			qrPaymentResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_FAILURE);
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for debit_card auth ::: " + qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
				LOGGER.error("Setting timeout for debit_card auth :::",e.getCause().toString());
				qrPaymentResponseVO.setStatusDesc(CommonConstants.FAILURE);
				qrPaymentResponseVO.setStatus(CommonConstants.NEGATIVE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.DEBIT_CARD_AUTH_TIMEOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.NEGATIVE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			}
			
		}finally{		
			if (qrPaymentResponseVO != null) {
				
				LOGGER.info("Inside Debit_Card processAuth finally to set response value object  :::: "+ qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference());		
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostName(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_system());	
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
					LOGGER.info("QR DebitCard Auth Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
				}				
				qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
				qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
				qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
				qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
			}		
			bean.setResponseVO(qrPaymentResponseVO);		
		}
		LOGGER.info("QR DebitCard Auth TXTStatus :::: "+qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("Task in QR DebitCard processAuthorization Processor :::: End");
		return bean;
	}
	
	public PayloadDTO processAuthorizationReversal(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in QR DebitCard Authorization Reversal Processor :::: Start");
		
		QRPaymentRequestVO  qrPaymentRequestVO  = null;
		QRPaymentResponseVO qrPaymentResponseVO = null;
		try{
			if(bean != null && bean.getRequestVO() != null){
				qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
				LOGGER.info("Posting Reversal request to EURONET ::: ");
				qrPaymentResponseVO = qrDebitCardService.reverseDebitCardAuthorization(qrPaymentRequestVO);
			}
		}catch(Exception e){
			LOGGER.error("Error inside QRDebitCardAuthorizationProcessor processAuthorizationReversal :::  ",e);
			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO(); 
			}
			LOGGER.info("Setting Fail status for the debit_card authorization reversal due to Exception ::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			qrPaymentResponseVO.setStatus(ExceptionMessages._105.getCode());
			qrPaymentResponseVO.setStatusDesc(e.getMessage());
			qrPaymentResponseVO.setErrorDesc(e.getMessage());
			qrPaymentResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_FAILURE);
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for debit_card auth reversal ::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
				LOGGER.error("Setting timeout for debit_card auth reversal ::: ",e.getCause().toString());
				qrPaymentResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				qrPaymentResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.DEBIT_CARD_AUTH_REV_TIMEOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.NEGATIVE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			}
		}finally{		
			if (qrPaymentResponseVO != null) {
				
				LOGGER.info("Inside Debit_Card processAuthRev finally to set response value object"+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					LOGGER.info("Setting the aggregator response status details to host response list in debit_card auth reversal" + 
						qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference() +
						qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode() +
						qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference()+
						qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					
					
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostName(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_system());		
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
				}				
				qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
				qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
				qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
				qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
			}
			bean.setResponseVO(qrPaymentResponseVO);		
		}
		LOGGER.info("QR Debit Card Auth Reversal TXTStatus ::::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("Task in Debit Card Auth ReversalPost Transaction Processor :::: End");
		return bean;
	}

	public QRDebitCardService getQrDebitCardService() {
		return qrDebitCardService;
	}

	public void setQrDebitCardService(QRDebitCardService qrDebitCardService) {
		this.qrDebitCardService = qrDebitCardService;
	}
	
	

}
