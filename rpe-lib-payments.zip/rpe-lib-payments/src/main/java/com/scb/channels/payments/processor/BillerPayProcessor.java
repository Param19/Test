/**
 * 
 */
package com.scb.channels.payments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentTransactionService;

/**
 * The Class BillerPayProcessor.
 *
 * @author 1464141
 */
public class BillerPayProcessor extends AbstractProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerPayProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

		LOGGER.info("Task in core banking Payment Processor :::: Start");
		
		BillerPayRequestVO billerPayRequestVO = null;
 		BillerPayResponseVO billerPayResponseVO = null;
		try {
			if(bean != null && bean.getRequestVO() != null){
				billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
				LOGGER.info("Sending request to core banking system ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				billerPayResponseVO = paymentTransactionService.performBillPayment(billerPayRequestVO);
				LOGGER.info("Received response from core banking system ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			}
		}catch (Exception e) {
			LOGGER.info("Exception Occurred while sending request to core banking system :::" +
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			LOGGER.info("Exception info:::: " , e);
			LOGGER.error("Exception error:::: " , e);
			
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			
			if(billerPayResponseVO.getBillerPayDetailsVO() == null) {
				billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			}
			
			LOGGER.info("Setting Fail status for the payment" 
					+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
			billerPayResponseVO.setStatusDesc(e.getMessage());
			billerPayResponseVO.setErrorDesc(e.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
			
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			
			if(e instanceof WebServiceException && e.getCause().toString().contains(CommonConstants.SOCKET_TIMEOUT)){
				LOGGER.info("Setting timeout for payment" + 
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				LOGGER.error(e.getCause().toString());
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.TIMEOUT);
				billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
				billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(CommonConstants.TIMEOUT);
				
			}		
			
		} finally{
			
			if (billerPayResponseVO != null) {
				LOGGER.info("Setting header objects in response vo" 
						+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			}
			bean.setResponseVO(billerPayResponseVO);
		}
		LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() ::: " 
				+ billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus());
		LOGGER.info("Task in core banking Payment Processor :::: End");
		return bean;
	
	}

	/**
	 * Gets the payment transaction service.
	 *
	 * @return the paymentTransactionService
	 */
	public PaymentTransactionService getPaymentTransactionService() {
		return paymentTransactionService;
	}

	/**
	 * Sets the payment transaction service.
	 *
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}

	

}
