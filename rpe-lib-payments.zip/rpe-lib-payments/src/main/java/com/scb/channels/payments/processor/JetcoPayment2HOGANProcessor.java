package com.scb.channels.payments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.JetcoPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.JetcoPayMappingHelper;
import com.scb.channels.payments.service.JetcoPaymentTransactionService;

/**
 * Process JETCO payment to HOGAN service
 * 
 * @author 1552545
 * 
 */
public class JetcoPayment2HOGANProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(JetcoPayment2HOGANProcessor.class);

	private JetcoPaymentTransactionService jetcoPaymentTransactionService;

	/**
	 * Send payment request to HOGAN
	 * 
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO debit2Hogan(PayloadDTO bean) throws BusinessException {

		LOGGER.info("Task in core banking Payment Processor :::Jetco: Start");

		JetcoPayRequestVO jetcoPayRequestVO = null;
		JetcoPayResponseVO jetcoPayResponseVO = null;
		try {
			if (bean != null && bean.getRequestVO() != null) {
				jetcoPayRequestVO = (JetcoPayRequestVO) bean.getRequestVO();
				LOGGER.info("Sending request to core banking system ::Jetco: " + jetcoPayRequestVO.getBankMessageId());
				jetcoPayResponseVO = jetcoPaymentTransactionService.performJetcoPayment(jetcoPayRequestVO);
				LOGGER.info("Received response from core banking system :Jetco:: " + jetcoPayRequestVO.getBankMessageId());
			}
		} catch (Exception e) {
			LOGGER.info("Exception Occurred while sending request to core banking system ::Jetco:" + jetcoPayRequestVO.getBankMessageId());
			LOGGER.info("Exception :Jetco:: " + e);
			LOGGER.error("Exception ::Jetco.:: " + e);
			if (jetcoPayResponseVO == null) {
				jetcoPayResponseVO = new JetcoPayResponseVO();
				jetcoPayResponseVO.setTransactionInfo(new TransactionInfoVO());
			}
			LOGGER.info("Setting Fail status for the payment" + jetcoPayRequestVO.getBankMessageId());
			jetcoPayResponseVO.setStatus(ExceptionMessages._105.getCode());
			jetcoPayResponseVO.setStatusDesc(e.getMessage());
			jetcoPayResponseVO.setErrorDesc(e.getMessage());
			jetcoPayResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			jetcoPayResponseVO.getTransactionInfo().setTxnStatusCd(CommonConstants.FAIL);
			jetcoPayRequestVO.setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
			jetcoPayResponseVO.getTransactionInfo().setHostRespCd(CommonConstants.FAIL);
			jetcoPayResponseVO.getTransactionInfo().setHostRespDesc(e.getMessage());
			if (e instanceof WebServiceException) {
				LOGGER.info("Setting timeout for card auth reversal ::: " + jetcoPayRequestVO.getBankMessageId());
				LOGGER.error(e.getCause().toString());
				jetcoPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				jetcoPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
				jetcoPayRequestVO.getTransactionInfo().setHostRespCd(CommonConstants.NEGATIVE);
				jetcoPayRequestVO.getTransactionInfo().setHostRespDesc(e.getMessage());
			}
		} finally {
			if (jetcoPayResponseVO != null) {
				LOGGER.info("Setting header objects in response Jetco vo" + jetcoPayRequestVO.getBankMessageId());
				if (jetcoPayResponseVO.getHostResponseVO() != null) {
					for (HostResponseVO hostRes : jetcoPayRequestVO.getHostResponseVO()) {
						jetcoPayResponseVO.getHostResponseVO().add(hostRes);
					}
				}
				if (jetcoPayResponseVO != null && jetcoPayResponseVO.getTransactionInfo() != null) {
					LOGGER.info("Setting the aggregator response status details to host response list in Jetco post transaction "
							+ jetcoPayRequestVO.getBankMessageId() + jetcoPayResponseVO.getTransactionInfo().getHostRespCd()
							+ jetcoPayResponseVO.getTransactionInfo().getHostRespDesc());
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(jetcoPayResponseVO.getTransactionInfo().getHostRespCd());
					hostResponse.setDesc(jetcoPayResponseVO.getTransactionInfo().getHostRespDesc());
					hostResponse.setHostName(CommonConstants.HOGAN);
					jetcoPayRequestVO.getHostResponseVO().add(hostResponse);
					jetcoPayResponseVO.getHostResponseVO().add(hostResponse);
				}
				jetcoPayResponseVO.setMessageVO(jetcoPayRequestVO.getMessageVO());
				jetcoPayResponseVO.setUser(jetcoPayRequestVO.getUser());
				jetcoPayResponseVO.setServiceVO(jetcoPayRequestVO.getServiceVO());
				jetcoPayResponseVO.setClientVO(jetcoPayRequestVO.getClientVO());
			}
			bean.setResponseVO(jetcoPayResponseVO);
		}
		LOGGER.info("jetcoPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() :Jetco:: " + jetcoPayRequestVO.getTxnActStatus());
		LOGGER.info("Task in core banking Payment Processor :::Jetco: End");
		return bean;

	}

	/**
	 * refund to HOGAN
	 * 
	 * @param bean
	 * @return
	 * @throws BusinessException
	 */
	public PayloadDTO reverse2Hogan(PayloadDTO bean) throws BusinessException {
		JetcoPayRequestVO jetcoPayRequestVO = null;
		JetcoPayResponseVO jetcoPayResponseVO = null;
		try {
			jetcoPayRequestVO = bean.getRequestVO() != null ? (JetcoPayRequestVO) bean.getRequestVO() : null;
			if (jetcoPayRequestVO == null && bean.getResponseVO() != null) {
				jetcoPayRequestVO = new JetcoPayRequestVO();
				jetcoPayResponseVO = (JetcoPayResponseVO) bean.getResponseVO();
				jetcoPayRequestVO = JetcoPayMappingHelper.getJetcoPaymentRequest(jetcoPayResponseVO);
			}
			if (null != jetcoPayRequestVO.getTransactionInfo()) {
				jetcoPayRequestVO.getTransactionInfo().setTxnSubType(CommonConstants.REVERSAL);
			}
			jetcoPayResponseVO = jetcoPaymentTransactionService.reversalJetcoPayment(jetcoPayRequestVO);
			// To check whether the response object is empty
			if (jetcoPayResponseVO == null) {
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
				jetcoPayRequestVO.setErrorDesc(ExceptionMessages._106.getMessage());
				jetcoPayRequestVO.setErrorCD(ExceptionMessages._106.getCode());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			jetcoPayRequestVO.setErrorDesc(e.getMessage());
			jetcoPayRequestVO.setErrorCD(ExceptionMessages._105.getCode());
			jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
			if (e instanceof WebServiceException) {
				LOGGER.info("Setting timeout for card auth reversal ::: " + jetcoPayRequestVO.getBankMessageId());
				LOGGER.error(e.getCause().toString());
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
				jetcoPayRequestVO.getTransactionInfo().setHostRespCd(CommonConstants.NEGATIVE);
				jetcoPayRequestVO.getTransactionInfo().setHostRespDesc(e.getMessage());
			}
		} finally {
			bean.setResponseVO(JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoPayRequestVO));
		}

		return bean;
	}

	public JetcoPaymentTransactionService getJetcoPaymentTransactionService() {
		return jetcoPaymentTransactionService;
	}

	public void setJetcoPaymentTransactionService(JetcoPaymentTransactionService jetcoPaymentTransactionService) {
		this.jetcoPaymentTransactionService = jetcoPaymentTransactionService;
	}

}
