package com.scb.channels.payments.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.v6.transaction.Maker;
import com.sc.corebanking.v6.transaction.PaymentIdentifierType;
import com.sc.corebanking.v6.transaction.PostTransactionReq;
import com.sc.corebanking.v6.transaction.PostTransactionReqPayload;
import com.sc.corebanking.v6.transaction.PostTransactionRes;
import com.sc.corebanking.v6.transaction.Transaction;
import com.sc.corebanking.v6.transaction.TransactionInfo;
import com.sc.corebanking.v6.transaction.TransactionsPosting;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransaction;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType;
import com.sc.scbml_1.DomainName;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.MessageSender;
import com.sc.scbml_1.MessageSenderType;
import com.sc.scbml_1.MessageType;
import com.sc.scbml_1.OriginationDetailsType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.ProcessType;
import com.sc.scbml_1.SCBMLHeaderType;
import com.sc.scbml_1.SenderDomainType;
import com.sc.scbml_1.SubDomainName;
import com.sc.scbml_1.SubType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.JetcoPayResponseVO;
import com.scb.channels.base.vo.JetcoPaymentDetailVO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.mapper.helper.JetcoPayMappingHelper;
import com.scb.channels.payments.dao.JetcoPaymentTransactionDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.helper.JetcoPayPaymentHelper;
import com.scb.channels.payments.service.JetcoPaymentTransactionService;

/**
 * JetcoPaymentTransactionServiceImpl
 * 
 * @author 1552545
 * 
 */
public class JetcoPaymentTransactionServiceImpl implements JetcoPaymentTransactionService {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(JetcoPaymentTransactionServiceImpl.class);

	public static final String YYYY_MM_DD_T_HH_MM_SS = "yyyy-MM-dd'T'HH:mm:ss";

	public static final String TRANSACTION_PROCESSED = "Transaction Processed.";

	private ReferenceService referenceService;

	private TransactionPortType postTransactionService;

	private JetcoPaymentTransactionDAO jetcoPaymentTransactionDAO;

	@Override
	public Long savePayment(JetcoPayRequestVO request) {
		LOGGER.info("savePayment ::: JetcoPaymentTransactionServiceImpl ::: Start");
		Long paymentId = 0L;
		JetcoPaymentDetailVO payment = JetcoPayMappingHelper.getJetcoPaymentDetails(request);
		payment.setPaymentStatus(CommonConstants.NEW);
		LOGGER.info("Send to save payment ::: " + request.getBankMessageId());
		jetcoPaymentTransactionDAO.saveJetcoPayment(payment);

		if (payment != null && payment.getId() != null) {
			paymentId = payment.getId();
			LOGGER.info("Payment saved successfull ::: " + request.getBankMessageId());
		} else {
			LOGGER.info("Problem in saving payment. Payment not saved ::::: " + request.getBankMessageId());
		}
		LOGGER.info("savePayment ::: JetcoPaymentTransactionServiceImpl ::: End");
		return paymentId;
	}

	@Override
	public void updatePaymentStatus(JetcoPayRequestVO jetcoPayRequestVO) {
		LOGGER.info("updatePaymentStatus ::: transactionServiceImpl ::: Start");
		try {
			JetcoPaymentDetailVO dbPayment = jetcoPaymentTransactionDAO.getJetcoPaymentDetails(jetcoPayRequestVO.getBankMessageId());
			if (dbPayment != null) {
				LOGGER.info("Setting latest status ::: " + jetcoPayRequestVO.getBankMessageId());
				// set send money "DUPL" flag
				if (StringUtils.isNotEmpty(jetcoPayRequestVO.getSeverity())) {
					dbPayment.setReasonCode(jetcoPayRequestVO.getSeverity());
				}
				if (StringUtils.isNotEmpty(jetcoPayRequestVO.getP2pTransactionId())) {
					dbPayment.setP2PTransactionId(jetcoPayRequestVO.getP2pTransactionId());
				}
				if (StringUtils.isNotEmpty(jetcoPayRequestVO.getJetcoMessageId())) {
					dbPayment.setJetcoMessageId(jetcoPayRequestVO.getJetcoMessageId());
				}
				if (null != jetcoPayRequestVO.getTransactionInfo()) {
					dbPayment.setHostStatusCode(jetcoPayRequestVO.getTransactionInfo().getHostRespCd());
					dbPayment.setHostStatusDesc(jetcoPayRequestVO.getTransactionInfo().getHostRespDesc());
				}

				dbPayment.setPaymentStatus(jetcoPayRequestVO.getTxnActStatus());
				dbPayment.setUpdatedBy(InvoiceAggregatorhelper.getJVMName());
				dbPayment.setUpdatedDate(new Timestamp(new Date().getTime()));
				jetcoPaymentTransactionDAO.updatePaymentStatus(dbPayment);
			}
		} catch (Exception exception) {
			LOGGER.info("Exception occurred while updating payments ::: " + jetcoPayRequestVO.getBankMessageId());
			LOGGER.info("Exception ::: " + exception);
			LOGGER.error("Exception ::: " + exception);
		}
		LOGGER.info("updatePaymentStatus ::: transactionServiceImpl ::: End");
	}

	@Override
	public JetcoPaymentDetailVO getPaymentDetails(String messageId) {
		return jetcoPaymentTransactionDAO.getJetcoPaymentDetails(messageId);
	}

	@Override
	public JetcoPayResponseVO performJetcoPayment(JetcoPayRequestVO jetcoPayRequestVO) {
		LOGGER.info("performBillPayment ::Jetco: JetcoPaymentTransactionServiceImpl ::: start" + jetcoPayRequestVO.getBankMessageId());

		JetcoPayResponseVO response = new JetcoPayResponseVO();
		PostTransaction transactionRequest = new PostTransaction();
		this.populatePostTransaction(jetcoPayRequestVO, transactionRequest);
		jetcoPayRequestVO.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.POST_TRANSACTION);
		PostTransactionResponse transactionResponse = postTransactionService.postTransaction(transactionRequest);

		LOGGER.info("Obtained response from Hogan" + jetcoPayRequestVO.getBankMessageId());
		PostTransactionRes postTransactionRes = transactionResponse.getPostTransactionResponse();
		Transaction transactionRes = postTransactionRes.getPostTransactionResPayload().getPostTransactionRes();
		// validate transactionResponse
		if (transactionResponse != null && postTransactionRes != null && postTransactionRes.getHeader() != null
				&& postTransactionRes.getHeader().getExceptions() != null) {
			// Check if there is any exception from Hogan response
			for (ExceptionType exceptionType : postTransactionRes.getHeader().getExceptions().getException()) {
				LOGGER.info("Exceptions present in the :Jetco response ::: " + jetcoPayRequestVO.getBankMessageId());
				LOGGER.info("Exceptions code :Jetco::: " + exceptionType.getCode().getValue() + " ::: " + jetcoPayRequestVO.getBankMessageId());
				LOGGER.info("Exceptions description :Jetco::: " + exceptionType.getDescription() + " ::: " + jetcoPayRequestVO.getBankMessageId());

				jetcoPayRequestVO.setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
				jetcoPayRequestVO.getTransactionInfo().setTxnStatusCd(CommonConstants.FAIL);
				jetcoPayRequestVO.getTransactionInfo().setHostRespCd(exceptionType.getCode().getValue());
				jetcoPayRequestVO.getTransactionInfo().setHostRespDesc(exceptionType.getDescription());
				response = JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoPayRequestVO);
				response.setStatusDesc(exceptionType.getDescription());
				response.setStatus(exceptionType.getCode().getValue());
			}
			LOGGER.info("performBillPayment ::: Jetco JetcoPaymentTransactionServiceImpl ::: End");
			return response;
		} else if (transactionResponse != null && postTransactionRes != null && postTransactionRes.getPostTransactionResPayload() != null
				&& transactionRes != null && transactionRes.getTransactionInfo() != null) {
			LOGGER.info("JETCO payload available for ::: " + jetcoPayRequestVO.getBankMessageId());
			jetcoPayRequestVO.getTransactionInfo().setHostRespCd(transactionRes.getTransactionInfo().getTransactionResultCode());
			jetcoPayRequestVO.getTransactionInfo().setHostRespDesc(transactionRes.getTransactionInfo().getTransactionStatusDescription());
			LOGGER.info("Status Details :::: {} ::: {} ::: {} :::::", new Object[] { jetcoPayRequestVO.getBankMessageId(),
					jetcoPayRequestVO.getTransactionInfo().getHostRespCd(), jetcoPayRequestVO.getTransactionInfo().getHostRespDesc() });
			if (CommonConstants.HOGAN_FAILUR_LIST.contains(postTransactionRes.getPostTransactionResPayload().getPostTransactionRes().getTransactionInfo()
					.getTransactionStatus())) {
				LOGGER.info("Hogan failure status while post transaction :::: " + jetcoPayRequestVO.getBankMessageId());
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
			} else {
				LOGGER.info("Hogan success status while post transaction :::: " + jetcoPayRequestVO.getBankMessageId());
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.COREBANK_PAY_SUCCESS);
			}
		} else {
			LOGGER.info("No response payload from host ::: " + jetcoPayRequestVO.getBankMessageId());
			jetcoPayRequestVO.setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
			jetcoPayRequestVO.getTransactionInfo().setTxnStatusCd(CommonConstants.FAIL);
			jetcoPayRequestVO.getTransactionInfo().setHostRespCd(CommonConstants.TIMEOUT_CODE);
			jetcoPayRequestVO.getTransactionInfo().setHostRespDesc("No response payload from host");
		}
		response = JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoPayRequestVO);
		LOGGER.info("Payment Response Jetco for request id:{}, {}, {}", new Object[] { jetcoPayRequestVO.getMessageVO().getRequestCode(),
				jetcoPayRequestVO.getTransactionInfo().getHostRespCd(), jetcoPayRequestVO.getTransactionInfo().getHostRespDesc() });

		return response;
	}

	@Override
	public JetcoPayResponseVO reversalJetcoPayment(JetcoPayRequestVO jetcoPayRequestVO) throws Exception {
		LOGGER.info("reversalJetcoPayment ::Jetco: JetcoPaymentTransactionServiceImpl ::: start" + jetcoPayRequestVO.getBankMessageId());

		PostTransaction transactionRequest = new PostTransaction();
		this.populatePostTransaction(jetcoPayRequestVO, transactionRequest);
		jetcoPayRequestVO.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.REVERSE_TRANSACTION);
		PostTransactionResponse transactionResponse = postTransactionService.postTransaction(transactionRequest);

		LOGGER.info("Obtained response from Hogan" + jetcoPayRequestVO.getBankMessageId());
		PostTransactionRes postTransactionRes = transactionResponse.getPostTransactionResponse();
		JetcoPayResponseVO jetcoPayResponseVO = new JetcoPayResponseVO();
		Transaction transactionRes = postTransactionRes.getPostTransactionResPayload().getPostTransactionRes();
		if (transactionResponse != null && postTransactionRes != null && postTransactionRes.getHeader() != null
				&& postTransactionRes.getHeader().getExceptions() != null) {
			// Check if there is any exception from Hogan response
			for (ExceptionType exceptionType : postTransactionRes.getHeader().getExceptions().getException()) {
				LOGGER.info("Exceptions present in the reversal transaction:Jetco response ::: " + jetcoPayRequestVO.getBankMessageId());
				LOGGER.info("Exceptions code reversal transaction :Jetco::: " + exceptionType.getCode().getValue() + " ::: "
						+ jetcoPayRequestVO.getBankMessageId());
				LOGGER.info("Exceptions description reversal transaction :Jetco::: " + exceptionType.getDescription() + " ::: "
						+ jetcoPayRequestVO.getBankMessageId());
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_TIMEOUT);
				jetcoPayRequestVO.getTransactionInfo().setTxnStatusCd(CommonConstants.FAIL);
				jetcoPayRequestVO.getTransactionInfo().setHostRespDesc(exceptionType.getDescription());
				jetcoPayRequestVO.getTransactionInfo().setHostRespCd(exceptionType.getCode().getValue());

				jetcoPayResponseVO = JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoPayRequestVO);
				jetcoPayResponseVO.setStatus(exceptionType.getCode().getValue());
				jetcoPayResponseVO.setStatusDesc(exceptionType.getDescription());
			}
			LOGGER.info("performBillPayment ::: Jetco reversal TransactionServiceImpl ::: End");
			return jetcoPayResponseVO;
		} else if (transactionResponse != null && postTransactionRes != null && postTransactionRes.getPostTransactionResPayload() != null
				&& transactionRes != null && transactionRes.getTransactionInfo() != null) {
			LOGGER.info("reversal payload available for ::: " + jetcoPayRequestVO.getBankMessageId());
			jetcoPayRequestVO.getTransactionInfo().setHostRespCd(transactionRes.getTransactionInfo().getTransactionResultCode());
			jetcoPayRequestVO.getTransactionInfo().setHostRespDesc(transactionRes.getTransactionInfo().getTransactionStatusDescription());
			LOGGER.info("Status Details :::: {} ::: {} ::: {} :::: ", new Object[] { jetcoPayRequestVO.getBankMessageId(),
					jetcoPayRequestVO.getTransactionInfo().getHostRespCd(), jetcoPayRequestVO.getTransactionInfo().getHostRespDesc() });
			if (CommonConstants.HOGAN_FAILUR_LIST.contains(transactionRes.getTransactionInfo().getTransactionStatus())) {
				LOGGER.info("Hogan failure status while reversal transaction :::: " + jetcoPayRequestVO.getBankMessageId());
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
			} else {
				LOGGER.info("Hogan success status while reversal transaction :::: " + jetcoPayRequestVO.getBankMessageId());
				jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_SUCCESS);
			}
		} else {
			LOGGER.info("No reversal response payload from host ::: " + jetcoPayRequestVO.getBankMessageId());
			jetcoPayRequestVO.setTxnActStatus(CommonConstants.REVERSAL_PAY_TIMEOUT);
			jetcoPayRequestVO.getTransactionInfo().setTxnStatusCd(CommonConstants.FAIL);
			jetcoPayRequestVO.getTransactionInfo().setHostRespCd(CommonConstants.TIMEOUT_CODE);
			jetcoPayRequestVO.getTransactionInfo().setHostRespDesc("No response payload from host");
		}
		jetcoPayResponseVO = JetcoPayMappingHelper.getJetcoPaymentResponse(jetcoPayRequestVO);
		LOGGER.info("Got Reversal Fund Transfer Jetco Response");
		return jetcoPayResponseVO;
	}



	/**
	 * Populate header.
	 * 
	 * @param country
	 *            the country
	 * @param channel
	 *            the channel
	 * @param date2
	 *            the date2
	 * @param requestCode
	 *            the request code
	 * @return the sCBML header type
	 */
	private SCBMLHeaderType populateHeader(String country, String channel, XMLGregorianCalendar date2, String requestCode, String captureSystem,
			String processName, String eventType, String typeName, String domain) {

		SCBMLHeaderType sCBMLHeaderType = new SCBMLHeaderType();
		sCBMLHeaderType.setCaptureSystem(captureSystem);

		ProcessType processType = new ProcessType();
		processType.setProcessName(processName);
		processType.setEventType(eventType);
		sCBMLHeaderType.setProcess(processType);

		BigDecimal bg = new BigDecimal(CommonConstants.DECIMAL_ONE);

		MessageDetailsType messageDetailsType = new MessageDetailsType();
		messageDetailsType.setMessageVersion(bg);

		MessageType messageType = new MessageType();
		messageType.setTypeName(typeName);
		SubType subType = new SubType();
		// subType.setSubTypeName(processName);
		subType.setSubTypeName(eventType);
		messageType.setSubType(subType);
		messageDetailsType.setMessageType(messageType);

		OriginationDetailsType originationDetailsType = new OriginationDetailsType();

		MessageSenderType messageSenderType = new MessageSenderType();
		MessageSender messageSender = new MessageSender();
		messageSender.setValue(channel);
		messageSenderType.setMessageSender(messageSender);
		messageSenderType.setCountryCode(country);

		SenderDomainType senderDomainType = new SenderDomainType();
		DomainName domainName = new DomainName();
		domainName.setValue(domain);
		senderDomainType.setDomainName(domainName);

		SubDomainName subDomainName = new SubDomainName();
		// subDomainName.setSubDomainType(processName);
		subDomainName.setSubDomainType(channel);
		senderDomainType.setSubDomainName(subDomainName);
		messageSenderType.setSenderDomain(senderDomainType);

		originationDetailsType.setMessageSender(messageSenderType);
		originationDetailsType.setMessageTimestamp(date2);
		originationDetailsType.setInitiatedTimestamp(date2);
		originationDetailsType.setTrackingId(requestCode);
		originationDetailsType.setConversationID(requestCode);
		originationDetailsType.setPossibleDuplicate(true);
		originationDetailsType.setCorrelationID(requestCode);
		sCBMLHeaderType.setMessageDetails(messageDetailsType);
		sCBMLHeaderType.setOriginationDetails(originationDetailsType);

		return sCBMLHeaderType;

	}

	/**
	 * Populate HOGAN request - PostTransaction
	 * 
	 * @param jetcoPayRequestVO
	 * @param transactionRequest
	 */
	private void populatePostTransaction(JetcoPayRequestVO jetcoPayRequestVO, PostTransaction transactionRequest) {
		PostTransactionReq postTransactionReq = new PostTransactionReq();

		String processName = CommonConstants.POST_SINGLE_LEG_TRANSACTION;
		String eventType = CommonConstants.POST_SINGLE_LEG;
		if (CommonConstants.JETCO_TRANSACTION_ON_US.equals(jetcoPayRequestVO.getPaymentType())) {
			processName = CommonConstants.TRANSFER_FUNDS_BY_PYMTID_TRANSACTION;
			eventType = CommonConstants.POST_BY_PAYMENT_ID;
		}
		// set transaction header
		postTransactionReq.setHeader(this.populateHeader(jetcoPayRequestVO.getClientVO().getCountry(), CommonConstants.IBANK,
				JetcoPayPaymentHelper.getGregorianCalendar(), jetcoPayRequestVO.getBankMessageId(), CommonConstants.HOGAN, processName, eventType,
				CommonConstants.GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME, CommonConstants.DOMAIN_NAME));

		PostTransactionReqPayload postTransactionReqPayload = new PostTransactionReqPayload();
		postTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		postTransactionReqPayload.setPayloadVersion(CommonConstants.JETCO_PAYLOAD_VERSION);
		postTransactionReqPayload.setPostTransactionReq(this.setTransaction(jetcoPayRequestVO));
		postTransactionReq.setPostTransactionReqPayload(postTransactionReqPayload);

		transactionRequest.setPostTransactionRequest(postTransactionReq);
	}


	/**
	 * Populate HOGAN request - Transaction
	 * 
	 * @param jetcoPayRequestVO
	 * @return
	 */
	private Transaction setTransaction(JetcoPayRequestVO jetcoPayRequestVO) {
		LOGGER.info("Inside Jetco setTransaction ::Start");
		Transaction transaction = new Transaction();
		TransactionInfo transactionInfo = new TransactionInfo();
		if (null != jetcoPayRequestVO.getPaymentType() && CommonConstants.JETCO_TRANSACTION_DEBIT.equals(jetcoPayRequestVO.getPaymentType())) { // OFF-US
			transactionInfo.setTransactionStatusCode(CommonConstants.JETCO_TRANS_CODE_0);
			transactionInfo.setMessageSubType(CommonConstants.POST_SINGLE_LEG);
		} else if (null != jetcoPayRequestVO.getPaymentType() && CommonConstants.JETCO_TRANSACTION_ON_US.equals(jetcoPayRequestVO.getPaymentType())) { // ON-US
			transactionInfo.setFromAccountNumber(jetcoPayRequestVO.getSenderAccountNumber());
			transactionInfo.setFromCurrencyCode(jetcoPayRequestVO.getSenderAccountCurrency());
			transactionInfo.setTransactionAmount(JetcoPayPaymentHelper.getFormatPaymentAmount4Hogan(jetcoPayRequestVO.getPaymentAmount()));
			transactionInfo.setTransactionStatus(CommonConstants.JETCO_TRANS_CODE_0);
			transactionInfo.setMessageSubType(CommonConstants.POST_BY_PAYMENT_ID);
		}
		transactionInfo.setTransactionSequenceNumber(CommonConstants.JETCO_HOGAN_TRANS_SEQ_NUM);
		transactionInfo.setTransactionBranch(CommonConstants.JETCO_TRANSACTION_BRANCH);
		transactionInfo.setChannelID(CommonConstants.DOMAIN_TYPE + CommonConstants.SPACE + CommonConstants.SPACE);
		transactionInfo.setChannelSubID(CommonConstants.JETCO_MAKER_ID);
		transactionInfo.setMACValue(CommonConstants.JETCO_HOGAN_MAC);
		transactionInfo.setKeyIndexHostSecurity(CommonConstants.DOUBLE_ZERO);
		transactionInfo.setSubHostVersionNumber("1000");
		transactionInfo.setSCBCustomeridentification(jetcoPayRequestVO.getUser().getCustomerType() + jetcoPayRequestVO.getUser().getCustomerId());
		transactionInfo.setSCBWalletIdentifier(CommonConstants.JETCO_WALLET_IDENTIFIER_7);
		transactionInfo.setTransactionReferenceNumber(jetcoPayRequestVO.getBankTransactionId());
		transactionInfo.setTransactionDate(jetcoPayRequestVO.getBankTransactionCreationDateTime());
		transactionInfo.setBankMessageID(jetcoPayRequestVO.getBankMessageId());
		transactionInfo.setBankMessageDate(jetcoPayRequestVO.getBankMessageCreationDateTime());
		transactionInfo.setReceiverMaskedName(jetcoPayRequestVO.getMaskedReceiverAccountName());
		transactionInfo.getTransactionsPosting().add(this.setTransactionsPostingList(jetcoPayRequestVO));

		PaymentIdentifierType paymentIdentifierType = new PaymentIdentifierType();
		paymentIdentifierType.setPaymentIdentifier(jetcoPayRequestVO.getReceiverMobileNumber());
		transactionInfo.getPaymentIdentifierType().add(paymentIdentifierType);

		Maker m = new Maker();
		m.setID(CommonConstants.JETCO_MAKER_ID);
		transactionInfo.setMaker(m);

		transaction.setTransactionInfo(transactionInfo);
		LOGGER.info("Inside Jetco SingleLeg setTransaction ::End");
		return transaction;
	}

	/**
	 * Populate HOGAN request transaction info - TransactionsPosting
	 * 
	 * @param jetcoPayRequestVO
	 * @return
	 */
	private TransactionsPosting setTransactionsPostingList(JetcoPayRequestVO jetcoPayRequestVO) {
		TransactionsPosting transactionsPosting = new TransactionsPosting();
		try {
			LOGGER.info("Inside method populateTransactionPostingDetails -- > Post transaction service start ");
			if (null != jetcoPayRequestVO.getPaymentType() && CommonConstants.JETCO_TRANSACTION_DEBIT.equals(jetcoPayRequestVO.getPaymentType())) {
				transactionsPosting.setSCBTransactionSubcode(CommonConstants.JETCO_TRANSACTION_DEBIT);// DEBIT
				transactionsPosting.setAccountNumber(jetcoPayRequestVO.getSenderAccountNumber());
				transactionsPosting.setAccountCurrencyCode(jetcoPayRequestVO.getSenderAccountCurrency());
				transactionsPosting.setTransactionAmount(JetcoPayPaymentHelper.getFormatPaymentAmount4Hogan(jetcoPayRequestVO.getPaymentAmount()));
			} else if (null != jetcoPayRequestVO.getPaymentType() && CommonConstants.JETCO_TRANSACTION_ON_US.equals(jetcoPayRequestVO.getPaymentType())) {
				transactionsPosting.setSCBTransactionSubcode(CommonConstants.JETCO_TRANSACTION_ON_US);// ON-US
			}
			if (null != jetcoPayRequestVO && null != jetcoPayRequestVO.getTransactionInfo()
					&& CommonConstants.REVERSAL.equalsIgnoreCase(jetcoPayRequestVO.getTransactionInfo().getTxnSubType())
					&& CommonConstants.JETCO_TRANSACTION_DEBIT.equals(jetcoPayRequestVO.getPaymentType())) {
				transactionsPosting.setSCBTransactionReverseindicator(CommonConstants.REVERSAL_INDICATOR); // Reversal transaction - 'X'
			} else {
				transactionsPosting.setSCBTransactionReverseindicator(CommonConstants.SPACE); // "Normal transaction - ' '
			}
			transactionsPosting.setCustomerReferenceNumber(jetcoPayRequestVO.getSenderCustomerReferenceId());
			transactionsPosting.setSenderReferenceNumber(jetcoPayRequestVO.getSenderP2PId());

			LOGGER.info("Inside method populateTransactionPostingDetails -- > Post transaction service end ");
		} catch (Exception e) {
			LOGGER.debug("Inside method populateTransactionPostingDetails Exception block-- > Post transaction service " + e.getMessage());
			LOGGER.error("Exception while reversal to HOGAN ::: ", e);
		}
		return transactionsPosting;
	}

	public JetcoPaymentTransactionDAO getJetcoPaymentTransactionDAO() {
		return jetcoPaymentTransactionDAO;
	}

	public void setJetcoPaymentTransactionDAO(JetcoPaymentTransactionDAO jetcoPaymentTransactionDAO) {
		this.jetcoPaymentTransactionDAO = jetcoPaymentTransactionDAO;
	}

	public TransactionPortType getPostTransactionService() {
		return postTransactionService;
	}

	public void setPostTransactionService(TransactionPortType postTransactionService) {
		this.postTransactionService = postTransactionService;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}


}
