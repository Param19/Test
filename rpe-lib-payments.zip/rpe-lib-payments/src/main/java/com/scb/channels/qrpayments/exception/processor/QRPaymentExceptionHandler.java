package com.scb.channels.qrpayments.exception.processor;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.camel.CamelException;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.http.HttpOperationFailedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentMasterErrorDetailResponse;
import com.scb.channels.base.vo.QRPaymentMasterErrorDetailsResponse;
import com.scb.channels.base.vo.QRPaymentMasterErrorResponse;
import com.scb.channels.base.vo.QRPaymentMasterErrorsResponse;
import com.scb.channels.base.vo.QRPaymentMasterResponse;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.QRPaymentVisaResponse;

public class QRPaymentExceptionHandler implements Processor{

	public static final String JMS_CORRELATION_ID = "JMSCorrelationID";
	public static final String ERROR_CAUGHT = "ERROR_CAUGHT";
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentExceptionHandler.class);

	public void process(Exchange exchange) throws CamelException {
		LOGGER.info("Inside QR Exception handling from {}", exchange.getFromRouteId());
		LOGGER.error("Error ", exchange.getProperty(Exchange.EXCEPTION_CAUGHT));	
		Exception ex = (Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);

		if (ex != null) {
			ex.printStackTrace();
			LOGGER.info("QR Exception Appeared  ::::: ",ex);
			LOGGER.info("Response code :::::::  ",exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
			LOGGER.info("Response code :::::::  ",exchange.getOut().getHeader(Exchange.HTTP_RESPONSE_CODE));
			LOGGER.info("Getting Payload from Exchange :::"+exchange.getProperty("payload"));
			int httpStatusCode =0;
			PayloadDTO payload = (PayloadDTO) exchange.getProperty("payload");
			exchange.setProperty(Exchange.EXCEPTION_CAUGHT, ex);
			PayloadDTO beanNew = exchange.getIn().getBody(PayloadDTO.class);
			if(payload != null && payload.getRequestVO()!= null){
				QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
				QRPaymentResponseVO qrPaymentResponseVO = (QRPaymentResponseVO)payload.getResponseVO();
			
				if(ex instanceof HttpOperationFailedException){
					LOGGER.info("Caught in Exception Block HttpOperationFailedException   :::::");
					HttpOperationFailedException httpOperationFailedException = (HttpOperationFailedException)ex;
					httpStatusCode = httpOperationFailedException.getStatusCode();
					String responseBody = httpOperationFailedException.getResponseBody();
					LOGGER.info("Http Status Code  ::::"+httpStatusCode+" Error ResponseBody  ::::"+responseBody);
						if(qrPaymentRequestVO != null){
						qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_FAILURE);
						qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
						qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
						qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(ex.getMessage());
						qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
						
						qrPaymentResponseVO.setStatus(ExceptionMessages._400.getCode());
						qrPaymentResponseVO.setStatusDesc(ex.getMessage());
						qrPaymentResponseVO.setErrorDesc(ex.getMessage());
						qrPaymentResponseVO.setErrorCD(ExceptionMessages._400.getCode());
						
						if(qrPaymentRequestVO.getQrPaymentDetailVO() != null){
							QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
							if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
								LOGGER.info("Inside VISA Error object to convertJsontoObject ::::");
								QRPaymentVisaResponse qrPaymentVISAResponse = null;
								ObjectMapper visaMapper = new ObjectMapper();
								try {
									qrPaymentVISAResponse = visaMapper.readValue(responseBody.getBytes(), QRPaymentVisaResponse.class);
									qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(qrPaymentVISAResponse.getErrorMessage());
									if(qrPaymentVISAResponse.getResponseStatus()!= null && qrPaymentVISAResponse.getErrorMessage() == null){
										qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(qrPaymentVISAResponse.getResponseStatus().getMessage());
									}
									} catch (JsonParseException e) {
										e.printStackTrace();
									} catch (JsonMappingException e) {
										e.printStackTrace();
									} catch (IOException e) {
										e.printStackTrace();
									}					
							}
							if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)){
								ObjectMapper masterMapper = new ObjectMapper();
								masterMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
								try {
									LOGGER.info("Inside Master Error object to convertJsontoObject ::::");
									QRPaymentMasterResponse qrPaymentMasterResponse = masterMapper.readValue(responseBody.getBytes(), QRPaymentMasterResponse.class);
									QRPaymentMasterErrorsResponse qrPaymentMasterErrorsResponse = (QRPaymentMasterErrorsResponse)qrPaymentMasterResponse.getErrors();	
									List<LinkedHashMap<String, QRPaymentMasterErrorResponse>> qrPaymentMasterErrorsResponses = qrPaymentMasterErrorsResponse.getExceptions();
									if(!(qrPaymentMasterErrorsResponses.size()>0)){
										LOGGER.info("Inside Master Error object values is 1 ::::");
										LinkedHashMap<String, QRPaymentMasterErrorResponse> exception = (LinkedHashMap<String, QRPaymentMasterErrorResponse>)qrPaymentMasterErrorsResponse.getException();
										if(exception != null){
											qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(String.valueOf(exception.get("Description")));
											qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(String.valueOf(exception.get("ReasonCode")));
											String errorCode = (String.valueOf(exception.get("ReasonCode")));
											String source = (String.valueOf(exception.get("Source")));
											if(source != null && source.equalsIgnoreCase("SYSTEM") && errorCode != null && (!((errorCode.equalsIgnoreCase("SERVICE_ERROR")) || ((errorCode.equalsIgnoreCase("SYSTEM_ERROR")))))){
												LOGGER.info("Inside Master Trasnaction Declined Error ::::");
												Object obj = exception.get("Details");
												LinkedHashMap<String,QRPaymentMasterErrorDetailsResponse> details =(LinkedHashMap<String,QRPaymentMasterErrorDetailsResponse>)obj;
												List<LinkedHashMap<String,QRPaymentMasterErrorDetailResponse>> detailList = (List<LinkedHashMap<String, QRPaymentMasterErrorDetailResponse>>) details.get("Detail");
												if(detailList.size()>0 && detailList.size() <= 2){
													LinkedHashMap<String,QRPaymentMasterErrorDetailResponse> detailValue = detailList.get(0);
													LinkedHashMap<String,QRPaymentMasterErrorDetailResponse> detailValue1 = detailList.get(1);
													qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(String.valueOf((detailValue.get("Value"))));
													qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(String.valueOf((detailValue1.get("Value"))));
												}
											}
										}
									}
									if(qrPaymentMasterErrorsResponses.size()>0){
										LOGGER.info("Inside VISA Error object > 1 ::::");
										StringBuilder errorCode = null;
										StringBuilder errorDesc = null;
										for(LinkedHashMap<String, QRPaymentMasterErrorResponse> exceptionMap : qrPaymentMasterErrorsResponses){
											errorCode = errorCode != null ? errorCode.append("|") : new StringBuilder();
											errorDesc = errorDesc != null ? errorDesc.append("|") : new StringBuilder();
											errorCode.append(exceptionMap.get("ReasonCode"));
											errorDesc.append(exceptionMap.get("Description"));
										}
										if(errorDesc != null){
											qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(String.valueOf(errorDesc));
										}
										if(errorCode != null){
											qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(String.valueOf(errorCode));
										}
									}
								} catch (JsonParseException e) {
									e.printStackTrace();
								} catch (JsonMappingException e) {
									e.printStackTrace();
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
					}else{
						LOGGER.info("QRException RequestVO is Null ::::::");
					}
			}else if(ex instanceof SocketTimeoutException){
				LOGGER.info("Inside the instance of SocketTimeoutException Block  ::::");
				SocketTimeoutException soTMOUT = (SocketTimeoutException)ex;
				if(qrPaymentRequestVO.getQrPaymentDetailVO() != null && 
					qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus().equalsIgnoreCase(CommonConstants.ACQUIRER_TIMEOUT)){
					qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.ACQUIRER_TIMEOUT);
					qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.ACQUIRER_TIMEOUT);
					qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(CommonConstants.ACQUIRER_TIMEOUT);
					qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.TIMEOUT_CODE);
					qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.TIMEOUT_CODE);
				}else{
				qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.TIMEOUT_CODE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.TIMEOUT_CODE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(soTMOUT.getMessage());
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
				}
			}else{
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(ex.getMessage());
				if(null == ex.getMessage() || "null" == ex.getMessage()){
					qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(CommonConstants.FAIL);
				}
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(ExceptionMessages._105.getCode());
				LOGGER.info("Not an  SocketTimeoutException && HttpOperationFailedException Else Loop::::",ex.getMessage());
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_FAILURE);
			}
			/*if("202".equalsIgnoreCase(String.valueOf(httpStatusCode))){
				System.out.println("Timed Out from VISA end");
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGTMOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGTMOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(String.valueOf(httpStatusCode));
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc("VISA TMOUT");
			}*/
			
			//qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			if(!("400".equalsIgnoreCase(qrPaymentResponseVO.getStatus())))
					qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(ex.getMessage());
			
			if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
			}				
			if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
				LOGGER.info("QR Payment Exception Block Setting the QRResponseVO :: "+qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode()+
						" - "+qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());				
				HostResponseVO hostResponse = new HostResponseVO();
				hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
				hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
				hostResponse.setHostName(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_system());		
				qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
				LOGGER.info("QR Exception HostResponse Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
			}				
			qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
			qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
			qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
			qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
			
			payload.setRequestVO(qrPaymentRequestVO);
			payload.setResponseVO(qrPaymentResponseVO);
			beanNew = payload;
			
			if (beanNew != null && beanNew.getRequestVO() != null && beanNew.getRequestVO().getMessageVO()!=null) {
				exchange.getOut().setHeader(JMS_CORRELATION_ID, beanNew.getRequestVO().getMessageVO().getReqID());
			}
			
			exchange.getOut().setBody(beanNew);
			LOGGER.info("QR Payment Exception TXTStatus :: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
			LOGGER.info("QR Payment Exception TXTStatus :: "+ qrPaymentResponseVO.getQrPaymentDetailVO().getTxnActStatus());
			}else{
				LOGGER.info("QRException Payload is Null ::::::");
			}
			
		}

	}	
}
