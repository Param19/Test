package com.scb.channels.qrpayments.processor;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import oauth.signpost.OAuth;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.http.HttpParameters;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentMasterCardAcceptor;
import com.scb.channels.base.vo.QRPaymentMasterFundingCard;
import com.scb.channels.base.vo.QRPaymentMasterReceivingAmount;
import com.scb.channels.base.vo.QRPaymentMasterRequest;
import com.scb.channels.base.vo.QRPaymentMasterRequestV3;
import com.scb.channels.base.vo.QRPaymentMasterResponse;
import com.scb.channels.base.vo.QRPaymentMasterSenderAddress;
import com.scb.channels.base.vo.QRPaymentMasterSenderName;
import com.scb.channels.base.vo.QRPaymentReceivingCard;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.qrpayments.security.oauth.HttpMethod;
import com.scb.channels.qrpayments.security.oauth.OAuthRequest;
import com.scb.channels.qrpayments.security.oauth.OAuthSignException;
import com.scb.channels.qrpayments.security.oauth.OAuthSigner;

public class QRMasterPaymentProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRMasterPaymentProcessor.class);
	
	private DataBean dataBean;
	
	private ReferenceService referenceService;
	
	public String buildRequest(PayloadDTO payload) throws Exception{
		
		QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
		String masterCardRequestJson = null;
		ISOCODESVO isoCodes = null;
		/**SETTING VALUE TO FETCH FROM CASA*/
		//qrPaymentDetailVO.setSourceOfFund("CASA");
		
		List<ISOCODESVO> isocodesvos = referenceService.getCurrency(qrPaymentDetailVO.getCountryCode());
		if(isocodesvos != null && isocodesvos.size()>0){
			for(ISOCODESVO isocodesvo : isocodesvos){
				if(isocodesvo.getCountrycode().equalsIgnoreCase(qrPaymentDetailVO.getCountryCode())){
					isoCodes = isocodesvo;
					break;
				}
			}
		} 
		try{
			LOGGER.info("Inside Master Card Build Request Start ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
		QRPaymentMasterRequest qrPaymentMasterRequest = new QRPaymentMasterRequest();
		QRPaymentMasterRequestV3 qrPaymentMasterRequestV3 =  new QRPaymentMasterRequestV3();
		QRPaymentMasterCardAcceptor qrPaymentMasterCardAcceptor = new QRPaymentMasterCardAcceptor();
		QRPaymentMasterFundingCard qrPaymentMasterFundingCard = new QRPaymentMasterFundingCard();
		QRPaymentMasterReceivingAmount qrPaymentMasterReceivingAmount =  new QRPaymentMasterReceivingAmount();
		QRPaymentMasterSenderAddress qrPaymentMasterSenderAddress =  new QRPaymentMasterSenderAddress();
		QRPaymentMasterSenderName qrPaymentMasterSenderName = new QRPaymentMasterSenderName();
		QRPaymentReceivingCard qrPaymentReceivingCard =  new QRPaymentReceivingCard();
		qrPaymentDetailVO.setHost_system(CommonConstants.MASTER+" - "+"MerchantPayment");
	       DateFormat timeFormat = new SimpleDateFormat("HHmmss");
	       DateFormat dateFormat = new SimpleDateFormat("MMdd");
	       qrPaymentMasterRequestV3.setLocalTime(timeFormat.format(qrPaymentDetailVO.getPaymentDate()));
	       qrPaymentMasterRequestV3.setLocalDate(dateFormat.format(qrPaymentDetailVO.getPaymentDate()));
	       qrPaymentMasterRequestV3.setTransactionReference("0000000"+qrPaymentDetailVO.getHost_reference());
	       if(qrPaymentDetailVO.getSourceOfFund().equalsIgnoreCase(CommonConstants.CASA)){
	    	   qrPaymentMasterRequestV3.setFundingSource(CommonConstants.MASTER_FUNDING_SOURCE_DEBIT);	   
	       }else{
	    	   qrPaymentMasterRequestV3.setFundingSource(CommonConstants.MASTER_FUNDING_SOURCE_CREDIT);
	       }
	       LOGGER.info("Master Card RRN :::: "+qrPaymentMasterRequestV3.getTransactionReference());
	       qrPaymentMasterRequestV3.setLanguageIdentification(CommonConstants.LANGUAGE_IDENTIFICATION);
	       qrPaymentMasterRequestV3.setChannel(CommonConstants.QR_CHANNEL);
	       /**Condition for checking the card type & setting values accordingly*/
	       /**Creating a combined string for country + card type (MASTER or VISA) + source of fund (CASA or CARD)*/
	       String keyToOpen=qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+qrPaymentDetailVO.getSourceOfFund();

	       /* qrPaymentMasterRequestV3.setICA("3560");
	    		   qrPaymentMasterRequestV3.setProcessorId("9000002120");
	    		   qrPaymentMasterRequestV3.setRoutingAndTransitNumber("935621208");
	    		   qrPaymentMasterRequestV3.setTransactionDesc(CommonConstants.MASTER_TRANSACTION_DESC);
	    		   qrPaymentMasterRequestV3.setMerchantId("123456");*/
	       qrPaymentMasterRequestV3.setICA(dataBean.map.get(keyToOpen+"_ICA"));
	       qrPaymentMasterRequestV3.setProcessorId(dataBean.map.get(keyToOpen+"_PID"));
	       qrPaymentMasterRequestV3.setRoutingAndTransitNumber(dataBean.map.get(keyToOpen+"_RTN"));

	       qrPaymentMasterRequestV3.setTransactionDesc(CommonConstants.MASTER_TRANSACTION_DESC);
	       qrPaymentMasterRequestV3.setMerchantId(dataBean.map.get(keyToOpen+"_RTN"));
	       String firstName = (qrPaymentDetailVO.getCustomer_first_name()!= null && qrPaymentDetailVO.getCustomer_first_name().length() > 35) ?
	    		   qrPaymentDetailVO.getCustomer_first_name().substring(0, 35):qrPaymentDetailVO.getCustomer_first_name();
	       qrPaymentMasterSenderName.setFirst(firstName);
	       //qrPaymentMasterSenderName.setMiddle("");
	       String lastName = (qrPaymentDetailVO.getCustomer_last_name() != null && qrPaymentDetailVO.getCustomer_last_name().length() > 35 ) ?
	    		   qrPaymentDetailVO.getCustomer_last_name().substring(0, 35):qrPaymentDetailVO.getCustomer_last_name();
	       qrPaymentMasterSenderName.setLast(lastName);
	       qrPaymentMasterRequestV3.setSenderName(qrPaymentMasterSenderName);
	       
	       qrPaymentMasterSenderAddress.setLine1(qrPaymentDetailVO.getCustomer_address1());
	       qrPaymentMasterSenderAddress.setCity(qrPaymentDetailVO.getCustomer_city());
	       qrPaymentMasterSenderAddress.setCountrySubdivision(qrPaymentDetailVO.getCustomer_state());
	       qrPaymentMasterSenderAddress.setPostalCode(qrPaymentDetailVO.getCustomer_zipCode());
	       //qrPaymentMasterSenderAddress.setCountry("IND");
	       qrPaymentMasterSenderAddress.setCountry(isoCodes.getCountrycode_char());
	       qrPaymentMasterRequestV3.setSenderAddress(qrPaymentMasterSenderAddress);
	       //CardNumber
	       qrPaymentMasterFundingCard.setAccountNumber(qrPaymentDetailVO.getCardNumber());
	       qrPaymentMasterRequestV3.setFundingCard(qrPaymentMasterFundingCard);

       		BigDecimal amount = qrPaymentDetailVO.getTotalPaymentAmt() != null ?        	
       				qrPaymentDetailVO.getTotalPaymentAmt() : new BigDecimal(CommonConstants.ZERO);
       	
       		String strAmount = (Arrays.asList((String.valueOf(
               			amount.multiply(new BigDecimal(100))).
               			        split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
       		
	       qrPaymentMasterReceivingAmount.setValue(strAmount);
	       qrPaymentMasterReceivingAmount.setCurrency(qrPaymentDetailVO.getTxnCurrencyCode());
	       qrPaymentMasterRequestV3.setReceivingAmount(qrPaymentMasterReceivingAmount);
	       //Merchant PAN
	       qrPaymentReceivingCard.setAccountNumber(qrPaymentDetailVO.getMerchantPan());
	       qrPaymentMasterRequestV3.setReceivingCard(qrPaymentReceivingCard);
	       String strMaid = qrPaymentDetailVO.getMaid() != null ? qrPaymentDetailVO.getMaid() : "";
	       qrPaymentMasterCardAcceptor.setName(qrPaymentDetailVO.getCardNumber().substring(0, 10)+qrPaymentDetailVO.getMerchantCategoryCode()+strMaid+"  ");
	       qrPaymentMasterCardAcceptor.setCity(qrPaymentDetailVO.getMerchantCity());
	       qrPaymentMasterCardAcceptor.setPostalCode(qrPaymentDetailVO.getMerchantPostalCode());
	       qrPaymentMasterCardAcceptor.setCountry(isoCodes.getCountrycode_char());
	       qrPaymentMasterRequestV3.setCardAcceptor(qrPaymentMasterCardAcceptor);
	       qrPaymentMasterRequestV3.setAdditionalMessage(qrPaymentDetailVO.getAdditionalField());
	       qrPaymentMasterRequest.setPaymentRequestV3(qrPaymentMasterRequestV3);
	       ObjectMapper mapper = new ObjectMapper();
	       mapper.setSerializationInclusion(Include.NON_NULL);
		//mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		try {
			masterCardRequestJson = mapper.writeValueAsString(qrPaymentMasterRequest);
			LOGGER.info("Master Card Request  :::: "+qrPaymentDetailVO.getClient_reference()+" JSON :: "+masterCardRequestJson);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Master Card Request Json Parse Exception ::::",e);
		}
		LOGGER.info("Master Card Request JSON ::::"+masterCardRequestJson);
		
		}catch(Exception e){
			LOGGER.error("Master Card Build Request General Exception ::::",e);
		}
		return masterCardRequestJson;
		}
	
	public String buildAuthorizationHeader(String payload,PayloadDTO payloadOBJ) throws URISyntaxException, ClientProtocolException, IOException{
		
		QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payloadOBJ.getRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
		String keyToOpen=qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+qrPaymentDetailVO.getSourceOfFund();

		   //String consumerKey = "VHu4g_27q70EsnFH6fH75Uuh5Puc-oUx7zIfHu3X5e2f178c!4f165dfa06e34d4ab01ef44084f48b460000000000000000";//CC
		   //String consumerKey = "5z157q9bT2EFkJVg47x2zMVPsd1-Q7bZghCUoWCT19fa7611!72a6674e7aab40648adfea9ee6c3f22b0000000000000000";//DC
		   String consumerKey = dataBean.map.get(keyToOpen+"_CK");
		   OAuthRequest request = new OAuthRequest();
	       request.setMethod(HttpMethod.POST);
	       //request.setRequestUrl("https://sandbox.api.mastercard.com/moneysend/v3/transfer?Format=JSON");
	       request.setRequestUrl(dataBean.map.get((qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type())+"_API_URL"));
	       request.setContentType(ContentType.APPLICATION_JSON);
	       request.setBody((String) payload);
	       HttpParameters params = new HttpParameters();
	       try {
	           params.put("oauth_body_hash", request.getOauthBodyHash(), true);
	       }
	       catch (Exception e) {
	           throw new OAuthSignException(e.getMessage(), e);
	       }
	       PrivateKey pkey = setP12(payloadOBJ);
	       OAuthSigner oAuthSigner = new OAuthSigner(pkey);
	       // Create OAuthConsumer
	       OAuthConsumer oAuthConsumer = new DefaultOAuthConsumer(consumerKey, "");
	       oAuthConsumer.setMessageSigner(oAuthSigner);
	       oAuthConsumer.setAdditionalParameters(params);
	        try {
	            oAuthConsumer.sign(request);
	        }
	        
	        catch (Exception e) {
	            throw new OAuthSignException(e.getMessage(), e);
	        }
	        return request.getHeader(OAuth.HTTP_AUTHORIZATION_HEADER);
	        
	    }
	 private PrivateKey setP12(PayloadDTO payloadOBJ) throws OAuthSignException {
		 
		 QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payloadOBJ.getRequestVO();
			QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();

			String keyToOpen=qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+qrPaymentDetailVO.getSourceOfFund();
			String file= dataBean.map.get(qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+"_P12_PATH")+dataBean.map.get(keyToOpen+"_P12_FILE");
			LOGGER.info("FILE PATH ::::::::::::::"+file);
	        try {
	        	PrivateKey privateKey;
	        	InputStream is = new FileInputStream(file);
	        	LOGGER.info("keyToOpen"+keyToOpen);
	        	String keyAlias = dataBean.map.get(keyToOpen+"_KS_ALIAS");   
	        	String keyPassword = dataBean.map.get(keyToOpen+"_KS_PWD");
	        	LOGGER.info("keypassword:::::::::::::::"+keyPassword+"::::::::::::keyAlias"+keyAlias);
	            KeyStore ks = KeyStore.getInstance("PKCS12");
	            ks.load(is, keyPassword.toCharArray());
	            privateKey = (PrivateKey) ks.getKey(keyAlias, keyPassword.toCharArray());
	            if (privateKey == null) {
	                throw new OAuthSignException("No key found for alias ["+ keyAlias +"]");
	            }
	            return privateKey;
	        } catch (Exception e) {
	            throw new OAuthSignException(e.getMessage(), e);
	        }
	    }
	 public QRPaymentMasterResponse convertJsontoObject(String  responseJson) throws com.fasterxml.jackson.core.JsonParseException, com.fasterxml.jackson.databind.JsonMappingException, IOException{
			LOGGER.info("Inside QR Payment Processor convertJsontoObject Start ::::"+responseJson.toString());
			QRPaymentMasterResponse qrPaymentMasterResponse = null;
			ObjectMapper mapper = new ObjectMapper();
				mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
				qrPaymentMasterResponse = mapper.readValue(responseJson.toString(), QRPaymentMasterResponse.class);				
			return qrPaymentMasterResponse;
		}
	 
	 public PayloadDTO setMasterResponseToPayload(QRPaymentMasterResponse qrPaymentMasterResponse,PayloadDTO payload) throws Exception{
		 
		 QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
		 QRPaymentResponseVO qrPaymentResponseVO = (QRPaymentResponseVO)payload.getResponseVO();
			
		 if(qrPaymentMasterResponse != null && qrPaymentMasterResponse.getTransfer().getTransactionHistory().getTransaction().getResponse().getCode().equalsIgnoreCase("00")){
				LOGGER.info("Got Success Status from Master :::: "+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference()+" RRN ::"+qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference());
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
				qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_SUCCESS);
				qrPaymentRequestVO.getQrPaymentDetailVO().setNetworkReferenceNumber(qrPaymentMasterResponse.getTransfer().getTransactionHistory().getTransaction().getNetworkReferenceNumber());
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(qrPaymentMasterResponse.getTransfer().getTransactionHistory().getTransaction().getResponse().getCode());
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(qrPaymentMasterResponse.getTransfer().getTransactionHistory().getTransaction().getResponse().getDescription());
				qrPaymentRequestVO.getQrPaymentDetailVO().setAgg_stan(qrPaymentMasterResponse.getTransfer().getTransactionHistory().getTransaction().getSystemTraceAuditNumber());

				LOGGER.info("Agg Stan ::::::::::::::::: "+qrPaymentRequestVO.getQrPaymentDetailVO().getAgg_stan());
				if(qrPaymentResponseVO != null){
					if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
						qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
					}				
					if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
						HostResponseVO hostResponse = new HostResponseVO();
						hostResponse.setCode(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseCode());
						hostResponse.setDesc(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseDesc());
						hostResponse.setHostName(qrPaymentRequestVO.getQrPaymentDetailVO().getHost_system());	
						qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
						LOGGER.info("QR VISA Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
					}	
				}
			}else{
				LOGGER.info("Got Failure Status from Master ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_FAILURE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(qrPaymentMasterResponse.getTransfer().getTransactionHistory().getTransaction().getResponse().getCode());
				//qrPaymentRequestVO.getQrPaymentDetailVO().setHostReasonCode(qrPaymentVISAResponse.getResponseCode());
				if(qrPaymentResponseVO != null){
					if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
						qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
					}				
					if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
						HostResponseVO hostResponse = new HostResponseVO();
						hostResponse.setCode(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseCode());
						hostResponse.setDesc(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseDesc());
						hostResponse.setHostName(qrPaymentRequestVO.getQrPaymentDetailVO().getHost_system());	
						qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
						LOGGER.info("QR Master Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
					}	
				}
			}
			payload.setResponseVO(qrPaymentResponseVO);
			
			LOGGER.info("QR Master Payment TXTStatus ::::: "+qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
			LOGGER.info("End of the setMasterResponseToPayload Method ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			return payload;
	 }

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	public DataBean getDataBean() {
		return dataBean;
	}
	 
}
