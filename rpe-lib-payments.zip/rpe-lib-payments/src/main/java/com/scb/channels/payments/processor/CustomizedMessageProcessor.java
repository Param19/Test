/**
 * 
 */
package com.scb.channels.payments.processor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.payments.service.CacheManagementService;
import com.scb.channels.paymentservice.PaymentResponse;

/**
 * @author 1470817
 * Get the Customized message from Application message table with respect to interface response code and set it back to NFS response
 */
public class CustomizedMessageProcessor  {
	
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(CustomizedMessageProcessor.class);
	
	private CacheManagementService cacheService;
	
	private ReferenceService referenceService;
	
	public PaymentResponse process(PaymentResponse paymentResponse) {
		
		LOGGER.info("Transforming payment response desc  to Customized Message ");
		Map<String,ApplicationMessageVO> applicationMsgMap = null;
		String srmCustomizedDesc = null;
		try {
			if(paymentResponse != null){
		
			String country = paymentResponse.getClientContext().getCountry();
			String channel = paymentResponse.getClientContext().getChannel();
			
			if (StringUtils.isEmpty(country) || StringUtils.isEmpty(channel))
			{
				LOGGER.info(country +"--- country  -- Inside Customized Message Processor channel  or country is empty channel -- "+channel);
				return paymentResponse;
			}
			
			/** applicationMsgMap contains code as key and Application message as value, So code must be unique with respect to country or channel */
			applicationMsgMap =  cacheService.getCustomizedMessages(country,channel);
			
			LOGGER.info("Customized MessageProcessor Message List -- > "+applicationMsgMap);
		
			  if(applicationMsgMap != null && paymentResponse.getStatus().getHostResponse() != null){
				  Iterator<HostResponseType> iterator = paymentResponse.getStatus().getHostResponse().iterator();
				  
				   while(iterator.hasNext()){
					   HostResponseType hostRes = iterator.next();
						  LOGGER.info("Customized MessageProcessor Corresponding Aggregatorrrrr code  -- > "+applicationMsgMap+" <<<Srm Desc" + srmCustomizedDesc);
						  
						  ApplicationMessageVO appMsg= applicationMsgMap.get(hostRes.getCode());
						  /**If source system is SRM ,no need to  get the description from db -- Scenario Payment Submitted response to NFS */
						  if(appMsg != null && !hostRes.getHostName().equalsIgnoreCase(CommonConstants.SRM_SOURCE_SYSTEM_NAME)){
							  
						  srmCustomizedDesc = appMsg.getSrmErrorDesc();
						  
						  /** Terminate the loop if aggregator code is present, don't consider ebbs response code */
						  if(hostRes.getHostName() != null && hostRes.getHostName().equalsIgnoreCase(CommonConstants.AGGREGATOR))
						  break;
						  
						  }
						  LOGGER.info("Customized MessageProcessor Corresponding <<<Srm Desc" + srmCustomizedDesc);
				   }
				   
			   }
			}
			LOGGER.info("Customized MessageProcessor Corresponding code  finallllllll  srmCustomizedDesc-- > "+srmCustomizedDesc);
			if(!StringUtils.isEmpty(srmCustomizedDesc)){
				paymentResponse.getStatus().setStatusDesc(srmCustomizedDesc);
			}
		}catch(Exception e){
			LOGGER.debug(" Customized MessageProcessor Message List   Exception block -- > ",e );
			return paymentResponse;
			
		}
		LOGGER.info("Customized MessageProcessor Enddd Corresponding code  srmCustomizedDesc-- > "+srmCustomizedDesc);
		return paymentResponse;
		}
	//Added for Orange Money - Start

	 public PayloadDTO processCustomMessageDesc(PayloadDTO payloadDTO){
		LOGGER.info("processCustomMessageDesc: Transforming to Customized Message: start ");
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)payloadDTO.getRequestVO();
		BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO)payloadDTO.getResponseVO();
		Map<String,ApplicationMessageVO> applicationMsgMap = null;
		String srmCustomizedErr = null;
		String srmCustomizedDsc = null;
		try {
			if(billerPayRequestVO != null){
		
			String country = billerPayRequestVO.getClientVO().getCountry();
			String channel = billerPayRequestVO.getClientVO().getChannel();
			
			if (org.apache.commons.lang.StringUtils.isNotBlank(country) && org.apache.commons.lang.StringUtils.isNotBlank(channel)) {
						
			/** applicationMsgMap contains code as key and Application message as value, So code must be unique with respect to country or channel */
			applicationMsgMap =  referenceService.getCustomizedMessages(country,channel,CommonConstants.CRAFTSILICON.toUpperCase(),billerPayRequestVO.getBillerPayDetailsVO().getBillerCd());
			
			LOGGER.info("Customized MessageProcessor Message List -- > "+applicationMsgMap);
			
			if(applicationMsgMap != null){
			
		    LOGGER.info("Customized MessageProcessor Corresponding Aggregatorrrrr code  -- > "+applicationMsgMap+" <<<Srm Desc: " + srmCustomizedErr);
						  
			ApplicationMessageVO appMsg= applicationMsgMap.get(billerPayResponseVO.getErrorCD());
			  /**If source system is SRM ,no need to  get the description from db -- Scenario Payment Submitted response to NFS */
			  if(appMsg != null){
				  
				  srmCustomizedErr = appMsg.getCompErrorCode();
				  srmCustomizedDsc =  appMsg.getCompErrorDesc();
			  
			  LOGGER.info("Customized MessageProcessor Corresponding <<<Srm Desc: " + srmCustomizedErr + " : srmCustomizedDsc : " + srmCustomizedDsc);
			   }
				   
			   }
			 }
			}
			if(!StringUtils.isEmpty(srmCustomizedErr) && !StringUtils.isEmpty(srmCustomizedDsc)){
				billerPayResponseVO.setErrorDesc(srmCustomizedDsc);
				billerPayResponseVO.setErrorCD(srmCustomizedErr);
				payloadDTO.setResponseVO(billerPayResponseVO);
				
			}
		}catch(Exception e){
			LOGGER.debug(" Customized MessageProcessor Message List   Exception block -- > ",e );
			return payloadDTO;
			
		}
		return payloadDTO;
	}
			
	//Added for Orange Money - End

	public CacheManagementService getCacheService() {
		return cacheService;
	}

	public void setCacheService(CacheManagementService cacheService) {
		this.cacheService = cacheService;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}
}
