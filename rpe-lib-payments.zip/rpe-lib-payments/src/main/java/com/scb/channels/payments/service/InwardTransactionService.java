package com.scb.channels.payments.service;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.ConstrtaintException;

// TODO: Auto-generated Javadoc
/**
 * The Interface InwardTransactionService.
 */
public interface InwardTransactionService {

	
	/**
	 * Gets the credit history validated.
	 *
	 * @param payloadDTO the payload dto
	 * @return validated history request
	 * @throws Exception the exception
	 */
	
	public PayloadDTO validateCreditHistoryRequest(PayloadDTO payloadDTO) throws Exception;
	
	/**
	 * Gets the inward payment history.
	 *
	 * @param payloadDTO the payload dto
	 * @return the inward payment history
	 * @throws Exception the exception
	 */
	public PayloadDTO getCreditHistory(PayloadDTO payloadDTO) throws Exception;
	
	
	/*1570965*/
	public PayloadDTO getWalletCreditHistory(PayloadDTO payloadDTO) throws Exception;
	
	/**
	 * Perform inward bill payment.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO performInwardBillPayment(PayloadDTO payloadDTO) throws Exception;
	
	/**
	 * Save inward payment.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws BusinessException the business exception
	 */
	public PayloadDTO saveInwardPayment(PayloadDTO payloadDTO) throws BusinessException;
	
	/**
	 * Update inward payment.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws ConstrtaintException the constrtaint exception
	 */
	public PayloadDTO updateInwardPayment(PayloadDTO payloadDTO) throws ConstrtaintException;
	
	/**
	 * Gets the inward payment.
	 *
	 * @param payloadDTO the payload dto
	 * @return the inward payment
	 * @throws ConstrtaintException the constrtaint exception
	 */
	public PayloadDTO getInwardPayment(PayloadDTO payloadDTO) throws ConstrtaintException;
	
	/**
	 * Credit inquiry status check.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO creditInquiryStatusCheck(PayloadDTO payloadDTO) throws Exception;
	
	/**
	 * Update status check.
	 *
	 * @param payloadDTO the payload dto
	 * @return the payload dto
	 * @throws Exception the exception
	 */
	public PayloadDTO updateStatusCheck(PayloadDTO payloadDTO) throws Exception;
}
