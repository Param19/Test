package com.scb.channels.payments.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerFieldItemVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayeeFieldDetailsView;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.base.vo.ViewPayeeHKVO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeVO;
import com.scb.channels.payments.dao.PayeeManagementDAO;

public class PayeeManagementDAOImpl extends HibernateDaoSupport implements PayeeManagementDAO {
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PayeeManagementDAOImpl.class);

	/**
	 * deletePayeeQuery
	 */
	private static final String deletePayeeQuery = " UPDATE PayeeDetailVO SET STATUS='I', remarks=:remarks, updateTime=:updateTime WHERE payeeId=:payeeId  AND STATUS='A' AND countryCode=:countryCode AND customerId=:customerId ";
	
	/**
	 * 
	 */
	private static final String updatePayeeQuery = " UPDATE PayeeDetailVO SET  remarks=:remarks WHERE payeeId=:payeeId ";
	/**
	 * viewPayeeListQuery
	 */
	private static final String viewPayeeListQuery = " FROM  PayeeDetailVO  WHERE  customerId=:customerId  AND countryCode=:countryCode AND status='A' AND payeeType='R' ";

	/**
	 * checkIsPayeeExistsQuery
	 */
	//private static final String checkIsPayeeExistsQuery = " FROM  PayeeDetailVO  WHERE  customerId=:customerId  AND countryCode=:countryCode   AND consumerNumber=:consumerNumber AND status='A' and payeeType=:payeeType ";
	private static final String checkIsPayeeExistsQuery = " FROM  PayeeDetailVO  WHERE  customerId=:customerId  AND countryCode=:countryCode  AND status='A' and payeeType=:payeeType ";
		
	/**
	 * getbillerId
	 */
	private static final String getbillerId = " FROM  BillerVO  WHERE  billerUniqueId=:billerUniqueId  ";
	
	/**
	 * 
	 */
	private static final String updatePayee_ifExistis = " UPDATE PayeeDetailVO SET status=:status, referenceNumber=:referenceNumber,updateTime=:updateTime, remarks=:remarks,payeeShortName=:payeeShortName, channelId=:channelId WHERE  consumerNumber=:consumerNumber AND STATUS='N' AND countryCode=:countryCode AND customerId=:customerId ";
	
	/**
	 * 
	 */
	private static final String updatePayee = " UPDATE PayeeDetailVO SET status=:status, referenceNumber=:referenceNumber,updateTime=:updateTime, remarks=:remarks WHERE  consumerNumber=:consumerNumber AND STATUS='N' AND countryCode=:countryCode AND customerId=:customerId  and channelId=:channelId ";
	/**
	 * 
	 */
	
	private static final String fetchActivePaymentPayees = " SELECT payeeId FROM  PaymentDetailVO  WHERE  paymentDate>=SYSDATE-365  AND  paymentDate<=SYSDATE AND countryCode=:countryCode ";
	
	/**
	 * 
	 */
	private static final String fetchOneOldPayees = " SELECT payeeId FROM  PayeeDetailVO  WHERE  createdTime<SYSDATE-365  and countryCode=:countryCode AND payeeType=:payeeType AND status='A' ";
	/**
	 * 
	 */
	private static final String terminateInActivePayees = " UPDATE PayeeDetailVO SET  status='T',remarks=:remarks,updateTime=SYSDATE,updatedBy='SYSTEM' WHERE payeeId IN (:payeeId) ";
	
	private static final String deleteDisabledFileds = " DELETE com.scb.channels.base.vo.PayeeFieldDetailsVO  WHERE status='D' ";
	
	
	private static final String deletePayeeQueryBO = " UPDATE PayeeDetailVO SET STATUS='I', remarks=:remarks, updateTime=:updateTime WHERE STATUS='A' AND countryCode=:countryCode AND customerId=:customerId AND payeeType='W' ";
	
	private static final String activatePayeeQueryBO = " UPDATE PayeeDetailVO SET STATUS='A', remarks=:remarks, updateTime=:updateTime WHERE STATUS='I' AND countryCode=:countryCode AND customerId=:customerId AND payeeType='W' AND remarks='BO Wallet Deactivated'";
	private static final String fetchCustomerId = "SELECT customerId FROM  PayeeDetailVO  WHERE  countryCode=:countryCode AND consumerDetail=:consumerDetail AND payeeType='W' AND status='A' ";
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.dao.PayeeManagementDAO#savePayee(com.scb.channels
	 * .base.vo.PayeeDetailVO)
	 */
	@Override
	public void savePayee(PayeeDetailVO PayeeDetailsVO) {
		LOGGER.info("PayeeManagementDAOImpl :: savePayee :: Start "+PayeeDetailsVO.getConsumerNumber());
			
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			PayeeDetailsVO.setStatus(CommonConstants.STATUS_ACTIVE);
			//getHibernateTemplate().save(PayeeDetailsVO);
			try{
				LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
				transaction = session.beginTransaction();
				LOGGER.info(":::::::::::::; doing insert :::::::::::::");
				session.save(PayeeDetailsVO);
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info(":::::::::::::; Add payee Commit successfull :::::::::::::");
			} catch (Exception exception) {
				//added for get the status of the method into calling function, status field is used for temp status
				PayeeDetailsVO.setStatus(CommonConstants.D);
				LOGGER.error(":::::::::::::; going to rollback add payee :::::::::::::" , exception);
				transaction.rollback();
				session.close();
				LOGGER.info(":::::::::::::; Add payee Rollback successfull :::::::::::::");
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: savePayee :: End ");
	}
	
	
		/* (non-Javadoc)
		 * @see com.scb.channels.payments.dao.PayeeManagementDAO#getUniqueBillerId(java.lang.String)
		 */
		public BillerVO getUniqueBillerId(String billerUniqueId,String countryCode) {
			LOGGER.info("PayeeManagementDAOImpl :: getUniqueBillerId :: Start ");
			Session session = null;
			BillerVO billerVO=null;
			List<BillerVO> list=null;
			Set<BillerField> setBillerField=null;
			
			Set<BillerFieldItemVO> setItems=null;
			try {
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria  cretria=session.createCriteria(BillerVO.class);
			/*  ProjectionList projectionsList = Projections.projectionList();
	        projectionsList.add(Projections.property("billerUniqueId").as("billerUniqueId"));
	        projectionsList.add(Projections.property("billerId").as("billerId"));
	        projectionsList.add(Projections.property("countryCode").as("countryCode"));
	        projectionsList.add(Projections.property("id").as("id"));
	        projectionsList.add(Projections.property("statusCode").as("statusCode"));
	        projectionsList.add(Projections.property("billPresentmentType").as("billPresentmentType"));
	        cretria.setProjection(projectionsList);
	      cretria.setResultTransformer(Transformers.aliasToBean(BillerVO.class));
	    */    cretria.add(Restrictions.eq("billerUniqueId", billerUniqueId));
	        cretria.add(Restrictions.eq("statusCode", CommonConstants.STATUS_ACTIVE));
	        cretria.add(Restrictions.eq(CommonConstants.PAYEE_COUNTRY_CODE, countryCode));
	        if(!countryCode.equalsIgnoreCase(CommonConstants.NG)){
	        	cretria.add(Restrictions.eq("isOnline", CommonConstants.YES_Y));	
	        }
	        list=cretria.list();
	        if(list.size()>0){
	        billerVO= list.get(0);
	    	if(billerVO.getIsOnline()!=null && billerVO.getIsOnline().equalsIgnoreCase(CommonConstants.YES_Y)){
	    		setBillerField=new HashSet<BillerField>();
				for(BillerField field:billerVO.getBillerFields()){
					
					if(field.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
						if(field.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
							setItems=new HashSet<BillerFieldItemVO>();
							for(BillerFieldItemVO item:field.getBillerFieldItems()){
								if(item.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
									setItems.add(item);
								}
							}
							field.setBillerFieldItems(setItems);
						}
						setBillerField.add(field);
					}
				}
				billerVO.setBillerFields(setBillerField);//
			}
	        }
	        
			LOGGER.info("completed retriving");

	        
			}catch(Exception e){
				LOGGER.info("Exception BillerVO.getId()************************",e);
				//LOGGER.debug("BillerVO.getId()************************"+e.getMessage());
			}finally{
				if(session != null){
					session.flush();
					session.close();
				}
				
			}
			LOGGER.info("PayeeManagementDAOImpl :: getUniqueBillerId :: End ");
			return billerVO;
	}
		public BillerVO getFieldInfo(String billerUniqueId,String countryCode) {
			LOGGER.info("PayeeManagementDAOImpl :: getFieldInfo :: Start ");
			Session session = null;
			BillerVO billerVO=null;
			List<BillerVO> list=null;
			try {
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria  cretria=session.createCriteria(BillerVO.class);
		    cretria.add(Restrictions.eq("billerUniqueId", billerUniqueId));
	        cretria.add(Restrictions.eq("statusCode", CommonConstants.STATUS_ACTIVE));
	        cretria.add(Restrictions.eq(CommonConstants.PAYEE_COUNTRY_CODE, countryCode));
	        if(!countryCode.equalsIgnoreCase(CommonConstants.NG)){
	        	cretria.add(Restrictions.eq("isOnline", CommonConstants.YES_Y));	
	        }
	        list=cretria.list();
	        if(list.size()>0){
	        billerVO= list.get(0);
	        }
			LOGGER.info("completed retriving getFieldInfo:: "+billerUniqueId);
			}catch(Exception e){
				LOGGER.info("Exception in getUniqueBillerId :",e);
				//LOGGER.debug("BillerVO.getId()************************"+e.getMessage());
			}finally{
				if(session != null){
					session.flush();
					session.close();
				}
				
			}
			LOGGER.info("PayeeManagementDAOImpl :: getFieldInfo :: End ");
			return billerVO;
	}
		
		
		public BillerVO getUniqueBillerIdHK(String billerUniqueId,String countryCode){
			LOGGER.info("PayeeManagementDAOImpl ::APAY  getUniqueBillerId :: Start ");
			Session session = null;
			BillerVO billerVO=null;
			List<BillerVO> list=null;
			try {
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria  cretria=session.createCriteria(BillerVO.class);
	        ProjectionList projectionsList = Projections.projectionList();
	        projectionsList.add(Projections.property("billerUniqueId").as("billerUniqueId"));
	        projectionsList.add(Projections.property("billerId").as("billerId"));
	        projectionsList.add(Projections.property("countryCode").as("countryCode"));
	        projectionsList.add(Projections.property("id").as("id"));
	        projectionsList.add(Projections.property("statusCode").as("statusCode"));
	        projectionsList.add(Projections.property("billPresentmentType").as("billPresentmentType"));
	        cretria.setProjection(projectionsList);
	      cretria.setResultTransformer(Transformers.aliasToBean(BillerVO.class));
	        cretria.add(Restrictions.eq("billerUniqueId", billerUniqueId));
	        cretria.add(Restrictions.eq("statusCode", CommonConstants.STATUS_ACTIVE));
	        cretria.add(Restrictions.eq("countryCode",countryCode));
	        
	        list=cretria.list();
	        if(list.size()>0){
	        billerVO= list.get(0);
	        }
	        
			LOGGER.info("completed retriving");

	        
			}catch(Exception e){
				LOGGER.info("BillerVO.getId()**********APAY**************"+e);
				LOGGER.debug("BillerVO.getId()**********APAY**************"+e.getMessage());
			}finally{
				if(session != null){
					session.flush();
					session.close();
				}
				
			}
			LOGGER.info("PayeeManagementDAOImpl :: APAY :: getUniqueBillerId :: End ");
			return billerVO;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.dao.PayeeManagementDAO#checkIsPayeeExists(com
	 * .scb.channels.base.vo.PayeeDetailVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PayeeDetailVO> checkIsPayeeExists(PayeeDetailVO PayeeDetailsVO) {
		// Pending with adding Categeory code comparison
		Session session = null;
		//boolean payeeFlag=false;
		List<PayeeDetailVO> listPayeeDetailVO = null;
		try {
			LOGGER.info("PayeeManagementDAOImpl :: checkIsPayeeExists :: Start :: NEW");
			session = getHibernateTemplate().getSessionFactory().openSession();
			Query query = session.createQuery(checkIsPayeeExistsQuery).setParameter("customerId", PayeeDetailsVO.getCustomerId())
					//.setParameter("consumerNumber", PayeeDetailsVO.getConsumerNumber())
					.setParameter("payeeType", PayeeDetailsVO.getPayeeType())
					.setParameter("countryCode", PayeeDetailsVO.getCountryCode());
			LOGGER.info("Query is ---NEW -------------------------- "+ query);
			listPayeeDetailVO = query.list();
			
			LOGGER.info("listPayeeDetailVO is ---------NEW-------------------- "+ listPayeeDetailVO);
			LOGGER.info("PayeeManagementDAOImpl :: checkIsPayeeExists :: Start, PayeeDetailsVO.getConsumerNumber(), getPayeeShortName ", new String[] { PayeeDetailsVO.getConsumerNumber(), PayeeDetailsVO.getPayeeShortName()});
			
		} catch (Exception e) {
			LOGGER.info("PayeeManagementDAOImpl :: checkIsPayeeExists :: End :: NEW",e);
			//payeeFlag=true;
			// TODO: handle exception 
			//session.flush();
			//session.close();
		}finally{			 
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: checkIsPayeeExists :: End :: NEW");
		return listPayeeDetailVO;
	}

	/*
	 * This function performs the soft deletion of payee.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.dao.PayeeManagementDAO#deletePayee(com.scb.
	 * channels.base.vo.PayeeDetailVO)
	 */
	@Override
	public boolean deletePayee(PayeeDetailVO PayeeDetailsVO) {
		boolean deleteStatus = false;
			LOGGER.info("PayeeManagementDAOImpl :: deletePayee :: Start ");
			
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			try{
				LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
				transaction = session.beginTransaction();
				LOGGER.info(":::::::::::::; doing delete :::::::::::::");
				Query query = session.createQuery(deletePayeeQuery).setParameter("payeeId", PayeeDetailsVO.getPayeeId())
						                                            .setParameter("customerId",PayeeDetailsVO.getCustomerId() )
						                                            .setParameter("countryCode", PayeeDetailsVO.getCountryCode())
						                                            .setParameter("remarks", CommonConstants.PAYEE_STATUS_DESCRIPTION_DELETED)
						                                            .setParameter(CommonConstants.PAYEE_UPDATED_TIMESTAMP, PayeeDetailsVO.getUpdateTime());
				deleteStatus=query.executeUpdate()==1?true:false;
				LOGGER.info("Delete Status :: "+deleteStatus);
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info(":::::::::::::; delete payee Commit successfully :::::::::::::");
			} catch (Exception exception) {
				LOGGER.error(":::::::::::::; going to rollback delete payee :::::::::::::", exception);
				transaction.rollback();
				session.close();
				LOGGER.info(":::::::::::::; delete payee Rollback successfully :::::::::::::");
				return false;
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: deletePayee :: End ");
		return deleteStatus;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ViewPayeeVO> viewPayeeListFromView(UserVO userVO) {
		LOGGER.info("PayeeManagementDAOImpl :: viewPayeeListFromView :: Start ");
		List<ViewPayeeVO> listViewPayeeVO = null;
		String statusList[]=new String[]{CommonConstants.STATUS_ACTIVE,"P"};
		Session session = null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(ViewPayeeVO.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);;
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, userVO.getCountry()));
		criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, userVO.getCustomerId()));
		criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.REGISTER_PAYEE));
		//criteria.add(Restrictions.eq(HibernateHelper.STATUS, CommonConstants.STATUS_ACTIVE));
		criteria.add(Restrictions.in(HibernateHelper.STATUS,statusList));
		listViewPayeeVO = criteria.list();
		LOGGER.info("PayeeManagementDAOImpl :: viewPayeeListFromView :: End"+listViewPayeeVO);
		
		if(listViewPayeeVO!=null){
			LOGGER.info("listViewPayeeVO size is "+listViewPayeeVO.size());
			
		}else{
			LOGGER.info("listViewPayeeVO size is null");
			
		 }
		} catch (Exception e) {
			// TODO: handle exception
			if(session != null){
				session.flush();
				session.close();
			}
			LOGGER.info("viewPayeeListFromView :: Exception ",e);
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
		}
		return listViewPayeeVO;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public PayeeDetailVO getPayee(Integer payeeId) {
		Session session = null;
		PayeeDetailVO payee = null;
		try {
			LOGGER.info("PayeeManagementDAOImpl :: getPayee :: Start :: " + payeeId);
			session = getHibernateTemplate().getSessionFactory().openSession();
			Object object = session.get(PayeeDetailVO.class, payeeId);
			payee = object != null ? (PayeeDetailVO)object : null;
			
			payee = payee != null && payee.getStatus() != null && 
				payee.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE) ? payee : null;
			LOGGER.info("PayeeManagementDAOImpl :: getPayee :: End ::: " + payeeId);
			
		} catch (Exception exception) {
			LOGGER.info("Exception occured while fetching Payee details :::: " + payeeId);
			LOGGER.error("Exception occured while fetching Payee details :::: " + payeeId);
			LOGGER.info("Exception :::: " , exception);
			LOGGER.error("Exception :::: " , exception);
			exception.printStackTrace();
		} finally {
			LOGGER.info("closing session for getPayee");
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: checkIsPayeeExists :: End :: NEW");
		return payee;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.dao.PayeeManagementDAO#updatePayee(com.scb.channels.base.vo.PayeeDetailVO)
	 */
	public void updatePayee(PayeeDetailVO payeeDetails) {
		LOGGER.info("updatePayee ::: payeeManagementDao ::: Start");
		
		Session session = null;
		Transaction transaction = null;
		try {
			LOGGER.info("Creating Session for update payee ::: " + payeeDetails.getPayeeId());
			session = getHibernateTemplate().getSessionFactory().openSession();
				
			LOGGER.info("Update the payee for payment ::: " + payeeDetails.getPayeeId());
			transaction = session.beginTransaction();
			session.update(payeeDetails);
			
			transaction.commit();
			session.flush();
			LOGGER.info("Update complete for payee details ::: " + payeeDetails.getPayeeId());
			
		} catch (Exception exception) {
			exception.printStackTrace();
			 LOGGER.info("Exception for update payee ::: " + payeeDetails.getPayeeId());
			 LOGGER.info("Exception occurred duirng update payee details ::: " , exception);
			 LOGGER.error("",exception);
			 if (transaction != null) {
				LOGGER.info("Closing transaction in update payee details");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in update payee details");
				session.close();
			}
		}
		LOGGER.info("updatePayee ::: payeeManagementDao ::: Start");
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ViewPayeeVO> viewPayeeListFromViewHK(ViewPayeeRequestVO viewReq) {
		LOGGER.info("PayeeManagementDAOImpl :: viewPayeeListFromViewHK :: Start ");
		List<ViewPayeeVO> listViewPayeeVO = null;
		Session session = null;
		String custId = null;
		String partnerName = null;
		String partnerType = null;
		try {
			if(viewReq != null && viewReq.getUser() !=null && viewReq.getClientVO() != null){
				custId = viewReq.getUser().getCustomerId();
				partnerName  = viewReq.getClientVO().getPartnerName();
				partnerType =   viewReq.getClientVO().getPartnerType();
			}
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(ViewPayeeHKVO.class);
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, viewReq.getUser().getCountry()));
		criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, custId));//+userVO.getCustomerType()));
		criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.REGISTER_PAYEE));
		if(partnerName != null){
		criteria.add(Restrictions.eq(HibernateHelper.BILLER_UNIQUE_ID, partnerName));
		}
		if(partnerType != null){
			criteria.add(Restrictions.eq(HibernateHelper.BILLER_NAME, partnerType));	
		}
		listViewPayeeVO = (List<ViewPayeeVO>)criteria.list();
		LOGGER.info("PayeeManagementDAOImpl :: viewPayeeListFromView :: End"+listViewPayeeVO);
		
		if(listViewPayeeVO!=null){
			LOGGER.info("listViewPayeeVOHK size is "+listViewPayeeVO.size());
			
		}else{
			LOGGER.info("listViewPayeeVOHK size is null");
			
		 }
		} catch (Exception e) {
			// TODO: handle exception
			if(session != null){
				session.flush();
				session.close();
			}
			LOGGER.info("viewPayeeListFromViewHK :: Exception "+e.getMessage());
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
		}
		return listViewPayeeVO;
	}
	
	public List<ViewPayeeVO> getPayeeList(PayeeDetailVO payeeDetailsVO) {
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeList :: Start ");
		Session session = null;
		String statusList[]=new String[]{CommonConstants.STATUS_ACTIVE};
		List<ViewPayeeVO> listPayees = null;
			try {
				session = getHibernateTemplate().getSessionFactory().openSession();
				Criteria criteria = session.createCriteria(ViewPayeeVO.class);
				criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, payeeDetailsVO.getCountryCode()));
				criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, payeeDetailsVO.getCustomerId()));
				criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.REGISTER_PAYEE));
				criteria.add(Restrictions.in(HibernateHelper.STATUS,statusList));
				listPayees = criteria.list();
				LOGGER.info("PayeeManagementDAOImpl :: getPayeeList :: Validate Payee :: End"+listPayees);
				
				if(listPayees!=null){
					LOGGER.info("getPayeeList :: Validate Payee  size is "+listPayees.size());
					
				}else{
					LOGGER.info("getPayeeList :: Validate Payee  size is null");
					
				 }
				}catch (Exception e) {
					// TODO: handle exception
					if(session != null){
						session.flush();
						session.close();
					}
					LOGGER.info("getPayeeList :: Validate Payee   :: Exception "+e.getMessage());
				}finally{
					if(session != null){
						session.flush();
						session.close();
					}
				}
			
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeList :: Validate Payee   :: End ");
		return listPayees;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.payments.dao.PayeeManagementDAO#savePayee(com.scb.channels
	 * .base.vo.PayeeDetailVO)
	 */
	@Override
	public boolean savePayeeHK(PayeeDetailVO payeeDetailsVO) {
		boolean status=false;
		LOGGER.info("PayeeManagementDAOImpl :: savePayeeHK :: Start ");
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			try{
				transaction = session.beginTransaction();
				session.save(payeeDetailsVO);
				System.out.println("Generated payee id is :"+payeeDetailsVO.getPayeeId());
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info("PayeeManagementDAOImpl :: savePayeeHK :: Commit complete ");
				status=true;
			} catch (Exception exception) {
				status=false;
				LOGGER.info("PayeeManagementDAOImpl :: savePayeeHK :: going to rollback add payee ::" + exception.getMessage());
				transaction.rollback();
				session.close();
				LOGGER.info("PayeeManagementDAOImpl :: savePayeeHK :: Rollback successfull");
			}
			
			LOGGER.info("PayeeManagementDAOImpl :: savePayeeHK :: End ");
			return status;
	}
	
	@Override
	public String updatePayeeIfExists(PayeeDetailVO PayeeDetailsVO) {
		String updateString = CommonConstants.PAYEE_ENTRY_NOT_FOUND;
		String updateQuery = PayeeDetailsVO.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)?updatePayee:updatePayee_ifExistis;
		
		boolean updateStatus = false;
			LOGGER.info("PayeeManagementDAOImpl :: updatePayeeIfExists :: Start ");
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			try{
				LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
				transaction = session.beginTransaction();
				LOGGER.info(":::::::::::::; doing updatePayeeIfExists :::::::::::::");
				Query query = session.createQuery(updateQuery).setParameter(CommonConstants.PAYEE_CONSUMER_NUM, PayeeDetailsVO.getConsumerNumber())
						                                            .setParameter(CommonConstants.PAYEE_CUST_ID,PayeeDetailsVO.getCustomerId() )
						                                            .setParameter(CommonConstants.PAYEE_COUNTRY_CODE, PayeeDetailsVO.getCountryCode())
						                                            .setParameter(CommonConstants.PAYEE_REMARKS,PayeeDetailsVO.getRemarks() )
						                                            .setParameter(CommonConstants.PAYEE_STATUS_STRING, PayeeDetailsVO.getStatus())
						                                            .setParameter(CommonConstants.PAYEE_REFERENCE_NUM,PayeeDetailsVO.getReferenceNumber())
						                                            .setParameter(CommonConstants.PAYEE_UPDATED_TIMESTAMP, PayeeDetailsVO.getUpdateTime())
						                                            .setParameter(CommonConstants.PAYEE_CHNLID, PayeeDetailsVO.getChannelId())
						                                            ;
				if(!PayeeDetailsVO.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
					query.setParameter(CommonConstants.PAYEE_SHORTNAME, PayeeDetailsVO.getPayeeShortName())	;
				}
				int updateCount=query.executeUpdate();
				LOGGER.info("Record update status Consumer num ::"+PayeeDetailsVO.getConsumerNumber()+" ::  "+updateCount);
				updateStatus=updateCount==CommonConstants.ONE_INT?true:false;
				if(updateStatus){
					Criteria criteria = session.createCriteria(PayeeDetailVO.class);
					criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, PayeeDetailsVO.getCountryCode()));
					criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, PayeeDetailsVO.getCustomerId()));
					criteria.add(Restrictions.eq(CommonConstants.PAYEE_CONSUMER_NUM, PayeeDetailsVO.getConsumerNumber()));
					criteria.add(Restrictions.eq(CommonConstants.PAYEE_STATUS_STRING, PayeeDetailsVO.getStatus()));
					criteria.add(Restrictions.eq(CommonConstants.PAYEE_REFERENCE_NUM,PayeeDetailsVO.getReferenceNumber()));
					criteria.add(Restrictions.eq(CommonConstants.PAYEE_CHNLID, PayeeDetailsVO.getChannelId()));
					
					if(PayeeDetailsVO.getPayeeShortName()!=null ){
						criteria.add(Restrictions.eq(CommonConstants.PAYEE_SHORTNAME, PayeeDetailsVO.getPayeeShortName()));
					}else{
						criteria.add(Restrictions.isNull(CommonConstants.PAYEE_SHORTNAME));
					}
					List<PayeeDetailVO>listPayees = criteria.list();
					for(PayeeDetailVO payeeDetailVO:listPayees){
						PayeeDetailsVO.setPayeeId(payeeDetailVO.getPayeeId());
						LOGGER.info("Record found updated successfully payee id is :: "+payeeDetailVO.getPayeeId());
					}
					updateString=CommonConstants.PAYEE_ENTRY_FOUND;	
					LOGGER.info("Record found updated successfully"+PayeeDetailsVO.getConsumerNumber()+" "+PayeeDetailsVO.getCustomerId()+" "+PayeeDetailsVO.getCountryCode());
				}
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info(":::::::::::::; updatePayeeIfExists payee Commit successfully :::::::::::::");
			} catch (Exception exception) {
				LOGGER.info(":::::::::::::; going to rollback updatePayeeIfExists payee :::::::::::::"+exception.getMessage());
				transaction.rollback();
				session.close();
				LOGGER.info(":::::::::::::; updatePayeeIfExists payee Rollback successfully :::::::::::::");
				updateString=CommonConstants.PAYEE_UPDATE_EXCEPTION;
				return updateString;
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: updatePayeeIfExists :: End ");
		return updateString;
	}

	@Override
	public boolean updatePayeeStatus(PayeeDetailVO PayeeDetailsVO) {
		boolean updateStatus = false;
			LOGGER.info("PayeeManagementDAOImpl :: updatePayeeStatus :: Start ");
			
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			try{
				LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
				transaction = session.beginTransaction();
				LOGGER.info(":::::::::::::; doing updatePayeeStatus :::::::::::::");
				Query query = session.createQuery(updatePayeeQuery).setParameter("payeeId", PayeeDetailsVO.getPayeeId())
						                                            .setParameter("remarks", PayeeDetailsVO.getRemarks());
		        updateStatus=query.executeUpdate()==1?true:false;
				LOGGER.info("updateStatus Status :: "+updateStatus);
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info(":::::::::::::; updateStatus payee Commit successfully :::::::::::::");
			} catch (Exception exception) {
				LOGGER.info(":::::::::::::; going to rollback updateStatus payee :::::::::::::",exception);
				transaction.rollback();
				session.close();
				LOGGER.info(":::::::::::::; updateStatus payee Rollback successfully :::::::::::::");
				return false;
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: updateStatus :: End ");
		return updateStatus;
	}


	@SuppressWarnings({ "unused", "unchecked" })
	@Override
	public boolean saveTerminateInactivePayee(String countryCode) {
		LOGGER.info("PayeeManagementDAOImpl :: terminateInactivePayee :: Start "+DateUtils.getCurrentDate());
		boolean updateStatus = false;
		Session session = null;
		Transaction transaction = null;
		List<Integer> listOneYrOldPayees = null;
		List<String> listActivePaymentPayees = null;
		List<Integer> inactivePayees = new ArrayList<Integer>();
		try {
            session = getHibernateTemplate().getSessionFactory().openSession();
			Query qry = session.getNamedQuery("TERMINATION_INACTIVE_PAYEE");
			List list = qry.list();
			updateStatus=true;
		} catch (Exception exception) {
			LOGGER.info("PayeeManagementDAOImpl :: terminateInactivePayee :: END ",exception);
			session.close();
			return false;
		}
		LOGGER.info("PayeeManagementDAOImpl :: terminateInactivePayee :: END "+DateUtils.getCurrentDate());
		return updateStatus;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<ViewPayeeVO> getPayeeListCS(UserVO userVO,Integer payeeId) {
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS :: Start "+ userVO.getCustomerId());
		List<ViewPayeeVO> listViewPayeeVO = null;
		Session session = null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(ViewPayeeVO.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, userVO.getCountry()));
		criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, userVO.getCustomerId()));
		criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.REGISTER_PAYEE));
		if(payeeId!=null){
		criteria.add(Restrictions.ne(HibernateHelper.PAYEE_ID, payeeId));
		//criteria.add(Restrictions.eq(HibernateHelper.IS_UPATE_REQUIRED, CommonConstants.YES));
		}
		listViewPayeeVO = criteria.list();
		if(listViewPayeeVO!=null){  
			LOGGER.info("getPayeeListCS :: listViewPayeeVO size with refnum"+ userVO.getCustomerId()+"  "+listViewPayeeVO.size());
		}else{
			LOGGER.info("getPayeeListCS :: listViewPayeeVO size is null"+ userVO.getCustomerId());
		 }
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS :: Exception "+ userVO.getCustomerId()+e.getMessage());
			// TODO: handle exception
			if(session != null){
				session.flush();
				session.close();
			}
			LOGGER.error("getPayeeListCS :: viewPayeeListFromView :: Exception ",e);
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS :: end "+ userVO.getCustomerId());
		return listViewPayeeVO;
	}
	
	@Override
	public void savePayeeCS(PayeeDetailVO payeeDetailsVO) {
		LOGGER.info("PayeeManagementDAOImpl :: savePayeeCS :: Start "+payeeDetailsVO.getReferenceNumber());
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction transaction = null;
		try{
			transaction = session.beginTransaction(); 
			//transaction.commit();
			//session.flush();
			//session.close();
			//session = getHibernateTemplate().getSessionFactory().openSession();
			//transaction = session.beginTransaction();
			/*for(PayeeFieldDetailsVO vo:payeeDetailsVO.getPayeeFieldDetails()){
				if(vo.getStatus().equalsIgnoreCase(CommonConstants.D)){
					session.delete(vo);	
				}
			}*/
			session.saveOrUpdate(payeeDetailsVO);
			Query query = session.createQuery(deleteDisabledFileds);
			query.executeUpdate();
			transaction.commit();
			session.flush(); 
			session.close();
		} catch (Exception exception) {
			exception.printStackTrace();
			payeeDetailsVO.setStatus(CommonConstants.D);
			LOGGER.info("PayeeManagementDAOImpl :: savePayeeCS ::" + exception.getMessage()+" "+payeeDetailsVO.getReferenceNumber());
			LOGGER.info("Exception", exception);
			transaction.rollback();
			session.close();
		}
		LOGGER.info("PayeeManagementDAOImpl :: savePayeeCS :: End "+payeeDetailsVO.getReferenceNumber());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PayeeFieldDetailsView> getPayeeFieldsCS(PayeeDetailVO payeeDetailVO) {
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeFieldsCS :: Start "+ payeeDetailVO.getCustomerId());
		List<PayeeFieldDetailsView> listPayeeFieldDetailsVO = null;
		Session session = null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(PayeeFieldDetailsView.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("payeeId", payeeDetailVO.getPayeeId()));
		listPayeeFieldDetailsVO = criteria.list();
		if(listPayeeFieldDetailsVO!=null){  
			LOGGER.info("PayeeManagementDAOImpl :: getPayeeFieldsCS size with refnum"+ payeeDetailVO.getCustomerId()+"  "+listPayeeFieldDetailsVO.size());
		}else{
			LOGGER.info("PayeeManagementDAOImpl :: getPayeeFieldsCS size is null"+ payeeDetailVO.getCustomerId());
		 }
		} catch (Exception e) {
			LOGGER.error("PayeeManagementDAOImpl :: getPayeeFieldsCS :: Exception ",e);
			e.printStackTrace();
			LOGGER.info("PayeeManagementDAOImpl :: getPayeeFieldsCS :: Exception "+ payeeDetailVO.getCustomerId()+e.getMessage());
			// TODO: handle exception
			if(session != null){
				session.flush();
				session.close();
			}
			LOGGER.info("Exception ", e);
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeListToValidateCS :: end "+ payeeDetailVO.getCustomerId());
		return listPayeeFieldDetailsVO;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public PayeeDetailVO getPayeeToValidatePayment(Integer payeeId) {
		Session session = null;
		PayeeDetailVO payee = null;
		try {
			LOGGER.info("PayeeManagementDAOImpl :: getPayeeToValidatePayment :: Start :: " + payeeId);
			session = getHibernateTemplate().getSessionFactory().openSession();
			Object object = session.get(PayeeDetailVO.class, payeeId);
			payee = object != null ? (PayeeDetailVO)object : null;
			
			payee = payee != null && payee.getStatus() != null && 
				payee.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE) ? payee : null;
			LOGGER.info("PayeeManagementDAOImpl :: getPayeeToValidatePayment :: End ::: " + payeeId);
			
		} catch (Exception exception) {
			//exception.printStackTrace();
			LOGGER.info("Exception occured while fetching Payee details :::: getPayeeToValidatePayment " + payeeId);
			LOGGER.error("Exception occured while fetching Payee details :::: getPayeeToValidatePayment " + payeeId +" "+exception);
			//LOGGER.info("Exception :::: " + exception);
			LOGGER.error("Exception :::: " , exception);
			exception.printStackTrace();
		} finally {
			LOGGER.info("closing session for getPayee :: getPayeeToValidatePayment ");
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeToValidatePayment :: End");
		return payee;
	}


	@Override
	public PayeeDetailVO getOneTimePayee(PayeeDetailVO payeeDetailVO) {
		Session session = null;
		List<PayeeDetailVO> payee = null;
		try {
			LOGGER.info("PayeeManagementDAOImpl :: getOneTimePayee :: Start :: " + payeeDetailVO.getCustomerId());
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria  cretria=session.createCriteria(PayeeDetailVO.class);
	       // cretria.setResultTransformer(Transformers.aliasToBean(BillerVO.class));
	        cretria.add(Restrictions.eq(CommonConstants.PAYEE_CUST_ID, payeeDetailVO.getCustomerId()));
	        cretria.add(Restrictions.eq(CommonConstants.PAYEE_COUNTRY_CODE, payeeDetailVO.getCountryCode()));
	       // cretria.add(Restrictions.eq(CommonConstants.PAYEE_BILLER_CODE, payeeDetailVO.getBillerCode()));
	        cretria.add(Restrictions.eq("consumerNumber", payeeDetailVO.getConsumerNumber()));
	        cretria.add(Restrictions.eq(CommonConstants.PAYEE_TYPE, CommonConstants.ONE_TIME_PAYMENT));
	        payee=cretria.list();
			LOGGER.info("PayeeManagementDAOImpl :: getOneTimePayee :: End ::: " + payeeDetailVO.getCustomerId());
			if(payee !=null && !payee.isEmpty()){
				for(PayeeDetailVO paye:payee){
					if(paye.getBillerVO().getBillerUniqueId().equalsIgnoreCase(payeeDetailVO.getBillerCode())){
						return paye;
					}
				}
			}
			
		} catch (Exception exception) {
			LOGGER.info("Exception occured while fetching Payee details :::: getOneTimePayee " + payeeDetailVO.getCustomerId());
			LOGGER.error("Exception occured while fetching Payee details :::: getOneTimePayee " + payeeDetailVO.getCustomerId());
			//LOGGER.info("Exception :::: " + exception);
			LOGGER.error("Exception :::: " , exception);
			exception.printStackTrace();
		} finally {
			LOGGER.info("closing session for getPayee :: getOneTimePayee ");
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: getOneTimePayee :: End");
		return null;
	}


	/* (non-Javadoc)
	 * @see com.scb.channels.payments.dao.PayeeManagementDAO#checkIfAnyInprocessPayments(java.util.Date, java.util.Date, java.lang.String, java.lang.String)
	 */
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.dao.PayeeManagementDAO#checkIfAnyInprocessPayments(java.util.Date, java.util.Date, java.lang.String, java.lang.String)
	 */
	@Override
	public boolean checkIfAnyInprocessPayments(Date fromDate, Date toDate, Integer payeeId, String countryCode,List<String> statusList) {
		Session session = null;
		Criteria criteria = null;
		List<PaymentDetailVO> list = new ArrayList<PaymentDetailVO>();
		boolean flag=false;
		try {
			LOGGER.debug("Inside checkIfAnyInprocessPayments:: Start ");
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria = session.createCriteria(PaymentDetailVO.class);
			criteria.add(Restrictions.eq(CommonConstants.PAYEE_ID, new Long(payeeId)));
			criteria.add(Restrictions.between("paymentDate", fromDate, toDate));
			criteria.add(Restrictions.not(Restrictions.in(HibernateHelper.PAYMENT_STATUS, statusList)));
			list = criteria.list();
			LOGGER.debug("Inside checkIfAnyInprocessPayments:: After db hit size "+list.size() +" PAYEE_ID"+payeeId);
			if(list.size()>0){
			flag= true;	
			}else{
				flag= false;
			}
		} catch (Exception exception) {
			flag=true;
			LOGGER.info("Exception occurred duirng checkIfAnyInprocessPayments ::: " , exception);
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in checkIfAnyInprocessPayments details");
				session.close();
			}
		}
     return flag;
	}
	
	//Added for Orange Money - start
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ViewPayeeVO> viewWalletPayeeList(UserVO userVO) {
		LOGGER.info("PayeeManagementDAOImpl :: viewWalletPayeeList :: Start ");
		List<ViewPayeeVO> listViewPayeeVO = null;
		String statusList[]=new String[]{CommonConstants.STATUS_ACTIVE,"P"};
		Session session = null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(ViewPayeeVO.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);;
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, userVO.getCountry()));
		criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, userVO.getCustomerId()));
		criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.REGISTERED_WALLET));
		criteria.add(Restrictions.in(HibernateHelper.STATUS,statusList));
		listViewPayeeVO = criteria.list();
		//LOGGER.info("PayeeManagementDAOImpl :: viewWalletPayeeList :: End"+listViewPayeeVO);
		
		if(listViewPayeeVO!=null){
			LOGGER.info("listViewPayeeVO size is "+listViewPayeeVO.size());
			
		}else{
			LOGGER.info("listViewPayeeVO size is null");
			
		 }
		} catch (Exception e) {
			LOGGER.error("PayeeManagementDAOImpl :: viewWalletPayeeList :: Exception ", e);
			// TODO: handle exception
			if(session != null){
				session.flush();
				session.close();
			}
			//LOGGER.info("viewWalletPayeeList :: Exception ",e);
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
		}
		return listViewPayeeVO;
	}
	
	
	public List<PayeeDetailVO> getPayeeListCS(UserVO userVO, Integer payeeId, String WalletType, String Country, String AccountNumber) {
       // LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS for Wallet :: Start "+ userVO.getCustomerId());
        List<PayeeDetailVO> listViewPayeeVO = null;
        Session session = null;
        try {
        session = getHibernateTemplate().getSessionFactory().openSession();
        Criteria criteria = session.createCriteria(PayeeDetailVO.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        
        if(userVO != null) {
               criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, userVO.getCountry()));
               criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, userVO.getCustomerId())); 
        } 
        
        if (Country != null && AccountNumber != null ) {
               criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, Country));
               criteria.add(Restrictions.eq(HibernateHelper.CONSUMER_DETAIL, AccountNumber));
        }
        criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, WalletType));
        criteria.add(Restrictions.eq(HibernateHelper.STATUS, CommonConstants.STATUS_ACTIVE));
        
        if(payeeId!=null){
               criteria.add(Restrictions.eq(HibernateHelper.PAYEE_ID, payeeId));
        }
        listViewPayeeVO = criteria.list();
        if(listViewPayeeVO!=null){  
               LOGGER.info("getPayeeListCS :: listViewPayeeVO size with refnum"+ listViewPayeeVO.size());
        }else{
               LOGGER.info("getPayeeListCS :: listViewPayeeVO size is null");
        }
        } catch (Exception e) {
              // e.printStackTrace();
               LOGGER.error("PayeeManagementDAOImpl :: getPayeeListCS :: Exception ",  e);
               // TODO: handle exception
               if(session != null){
                     session.flush();
                     session.close();
               }
            //   LOGGER.error("getPayeeListCS :: viewPayeeListFromView :: Exception ",e);
        }finally{
               if(session != null){
                     session.flush();
                     session.close();
               }
        }
        LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS :: end ");
        return listViewPayeeVO;
 }
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ViewPayeeVO> getWalletPayeeList(UserVO userVO,Integer payeeId) {
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS :: Start "+ userVO.getCustomerId());
		List<ViewPayeeVO> listViewPayeeVO = null;
		Session session = null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(ViewPayeeVO.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, userVO.getCountry()));
		criteria.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, userVO.getCustomerId()));
		criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.WALLET_PAYEE));
		if(payeeId!=null){
		criteria.add(Restrictions.ne(HibernateHelper.PAYEE_ID, payeeId));
		//criteria.add(Restrictions.eq(HibernateHelper.IS_UPATE_REQUIRED, CommonConstants.YES));
		}
		listViewPayeeVO = criteria.list();
		if(listViewPayeeVO!=null){  
			LOGGER.info("getPayeeListCS :: listViewPayeeVO size with refnum"+ userVO.getCustomerId()+"  "+listViewPayeeVO.size());
		}else{
			LOGGER.info("getPayeeListCS :: listViewPayeeVO size is null"+ userVO.getCustomerId());
		 }
		} catch (Exception e) {
			//e.printStackTrace();
			LOGGER.error("PayeeManagementDAOImpl :: getPayeeListCS :: Exception " , e);
			// TODO: handle exception
			if(session != null){
				session.flush();
				session.close();
			}
		//	LOGGER.error("getPayeeListCS :: viewPayeeListFromView :: Exception ",e);
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: getPayeeListCS :: end "+ userVO.getCustomerId());
		return listViewPayeeVO;
	}

	
	public boolean deletePayeeBO(PayeeDetailVO PayeeDetailsVO) {
		boolean deleteStatus = false;
			LOGGER.info("PayeeManagementDAOImpl :: deletePayeeBO :: Start ");
			
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			try{
				LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
				transaction = session.beginTransaction();
				LOGGER.info(":::::::::::::; doing delete :::::::::::::");
				Query query = session.createQuery(deletePayeeQueryBO).setParameter("customerId",PayeeDetailsVO.getCustomerId() )
						                                            .setParameter("countryCode", PayeeDetailsVO.getCountryCode())
						                                            .setParameter("remarks", CommonConstants.PAYEE_STATUS_DESCRIPTION_DELETED_VIA_BO)
						                                            .setParameter(CommonConstants.PAYEE_UPDATED_TIMESTAMP, PayeeDetailsVO.getUpdateTime());
				deleteStatus=query.executeUpdate() >= 1?true:false;
				LOGGER.info("Delete Status :: "+deleteStatus);
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info(":::::::::::::; delete payee Commit successfully :::::::::::::");
			} catch (Exception exception) {
				LOGGER.error(":::::::::::::; going to rollback delete payee :::::::::::::", exception);
				transaction.rollback();
				session.close();
			//	LOGGER.info(":::::::::::::; delete payee Rollback successfully :::::::::::::");
				return false;
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: deletePayeeBO :: End ");
		return deleteStatus;
	}
	
	
	public boolean addPayeeBO(PayeeDetailVO PayeeDetailsVO) {
		boolean addStatus = false;
			LOGGER.info("PayeeManagementDAOImpl :: addPayeeBO :: Start ");
			
			Session session = getHibernateTemplate().getSessionFactory().openSession();
			Transaction transaction = null;
			try{
				LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
				transaction = session.beginTransaction();
				LOGGER.info(":::::::::::::; doing update :::::::::::::");
				Query query = session.createQuery(activatePayeeQueryBO).setParameter("customerId",PayeeDetailsVO.getCustomerId() )
						                                            .setParameter("countryCode", PayeeDetailsVO.getCountryCode())
						                                            .setParameter("remarks", CommonConstants.PAYEE_STATUS_DESCRIPTION_ACTIVATED_VIA_BO)
						                                            .setParameter(CommonConstants.PAYEE_UPDATED_TIMESTAMP, PayeeDetailsVO.getUpdateTime());
				addStatus=query.executeUpdate() >= 1?true:false;
				LOGGER.info("added Status :: "+addStatus);
				transaction.commit();
				session.flush();
				session.close();
				LOGGER.info(":::::::::::::; add payee BO Commit successfully :::::::::::::");
			} catch (Exception exception) {
				LOGGER.error(":::::::::::::; going to rollback add payee :::::::::::::",exception);
				transaction.rollback();
				session.close();
				//LOGGER.info(":::::::::::::; add payee Rollback successfully :::::::::::::");
				return false;
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: addPayeeBO :: End ");
		return addStatus;
	}


	@Override
	public String getCommonSequenceNumberGenerator(String strNamedQueryFunName) {
		
		LOGGER.info("PayeeManagementDAOImpl start Session " + strNamedQueryFunName);
		Session session = null;
		String key=null;
		try {
 			session = getHibernateTemplate().getSessionFactory().openSession();
			Query query = session.getNamedQuery(strNamedQueryFunName);
 			key =query.uniqueResult().toString();
 		    LOGGER.info("OrangeMoney Sequence Number is:: "+key);
		    return key;
		    
	       }catch(Exception ex) {
	    	   //ex.printStackTrace();
		   LOGGER.error("Exception occurred duirng Sequence Number generated ::: " , ex);
		 
	} finally {
		if(session != null) {
			LOGGER.info("PayeeManagementDAOImpl closing Session ");
			session.close();
		}

	}
		return key;

	}
	@Override
	public String getCurrentDayPayment(String strCountry, String strAccountNumber) {
		
		String strCustomerId = null;
		LOGGER.info("PayeeManagementDAOImpl :: addPayeeBO :: Start ");
		
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction transaction = null;
		try{
			LOGGER.info(":::::::::::::; initiate transaction :::::::::::::");
			transaction = session.beginTransaction();
			LOGGER.info(":::::::::::::; doing update :::::::::::::");
			Query query = session.createQuery(fetchCustomerId).setParameter("countryCode", strCountry)
					                                            .setParameter("consumerDetail", strAccountNumber);
			
			strCustomerId=query.uniqueResult().toString();
			LOGGER.info(" Customer id :: "+ strCustomerId);
			return strCustomerId;
		}
			catch(Exception ex) {
		    	   //ex.printStackTrace();
			   LOGGER.error("Exception occurred duirng Sequence Number generated ::: " , ex);
			 
		} finally {
			if(session != null) {
				LOGGER.info("PayeeManagementDAOImpl closing Session ");
				session.close();
			}

		}
			return strCustomerId;

	}
	
	
	
	@SuppressWarnings("unchecked")
    @Override
    public List<ViewPayeeVO> getPayeeListByWallet(UserVO userVO,Integer payeeId, String walletNumber) {
          LOGGER.info("PayeeManagementDAOImpl :: getPayeeListByWallet :: Start "+ userVO.getCustomerId());
          List<ViewPayeeVO> listViewPayeeVO = null;
          Session session = null;
          try {
          session = getHibernateTemplate().getSessionFactory().openSession();
          Criteria criteria = session.createCriteria(ViewPayeeVO.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
          criteria.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE, userVO.getCountry()));

          criteria.add(Restrictions.eq(HibernateHelper.REG_PAYEE, CommonConstants.WALLET_PAYEE));
          criteria.add(Restrictions.eq(HibernateHelper.CONSUMER_NUMBER, walletNumber));//walletnumber
          if(payeeId!=null){
          criteria.add(Restrictions.ne(HibernateHelper.PAYEE_ID, payeeId));
          //criteria.add(Restrictions.eq(HibernateHelper.IS_UPATE_REQUIRED, CommonConstants.YES));
          }
          listViewPayeeVO = criteria.list();
          if(listViewPayeeVO!=null){  
                LOGGER.info("getPayeeListByWallet :: listViewPayeeVO size with refnum"+ userVO.getCustomerId()+"  "+listViewPayeeVO.size());
          }else{
                LOGGER.info("getPayeeListByWallet :: listViewPayeeVO size is null"+ userVO.getCustomerId());
          }
          } catch (Exception e) {
               // e.printStackTrace();
                LOGGER.error("PayeeManagementDAOImpl :: getPayeeListByWallet :: Exception ", e);
                // TODO: handle exception
                if(session != null){
                      session.flush();
                      session.close();
                }
               // LOGGER.error("getPayeeListByWallet :: viewPayeeListFromView :: Exception ",e);
          }finally{
                if(session != null){
                      session.flush();
                      session.close();
                }
          }
          LOGGER.info("PayeeManagementDAOImpl :: getPayeeListByWallet :: end "+ userVO.getCustomerId());
          return listViewPayeeVO;
    }

	
	// Added for Orange Money Biller got disabled in Biller Download Handing - start
	
	public BillerVO getWalletFieldInfo(String billerUniqueId,String countryCode) {
		LOGGER.info("PayeeManagementDAOImpl :: getWalletFieldInfo :: Start ");
		Session session = null;
		BillerVO billerVO=null;
		List<BillerVO> list=null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria  cretria=session.createCriteria(BillerVO.class);
	    cretria.add(Restrictions.eq("billerUniqueId", billerUniqueId));
        //cretria.add(Restrictions.eq("statusCode", CommonConstants.STATUS_ACTIVE));
        cretria.add(Restrictions.eq(CommonConstants.PAYEE_COUNTRY_CODE, countryCode));
        if(!countryCode.equalsIgnoreCase(CommonConstants.NG)){
        	cretria.add(Restrictions.eq("isOnline", CommonConstants.YES_Y));	
        }
        list=cretria.list();
        if(list.size()>0){
        billerVO= list.get(0);
        }
		LOGGER.info("completed retriving getWalletFieldInfo:: "+billerUniqueId);
		}catch(Exception e){
			LOGGER.info("Exception in getWalletFieldInfo :",e);
			//LOGGER.debug("BillerVO.getId()************************"+e.getMessage());
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
			
		}
		LOGGER.info("PayeeManagementDAOImpl :: getFieldInfo :: End ");
		return billerVO;
}


public BillerVO getWalletUniqueBillerId(String billerUniqueId,String countryCode) {
		LOGGER.info("PayeeManagementDAOImpl :: getWalletUniqueBillerId :: Start ");
		Session session = null;
		BillerVO billerVO=null;
		List<BillerVO> list=null;
		Set<BillerField> setBillerField=null;
		
		Set<BillerFieldItemVO> setItems=null;
		try {
		session = getHibernateTemplate().getSessionFactory().openSession();
		Criteria  cretria=session.createCriteria(BillerVO.class);
		cretria.add(Restrictions.eq("billerUniqueId", billerUniqueId));
        //cretria.add(Restrictions.eq("statusCode", CommonConstants.STATUS_ACTIVE));
        cretria.add(Restrictions.eq(CommonConstants.PAYEE_COUNTRY_CODE, countryCode));
        if(!countryCode.equalsIgnoreCase(CommonConstants.NG)){
        	cretria.add(Restrictions.eq("isOnline", CommonConstants.YES_Y));	
        }
        list=cretria.list();
        if(list.size()>0){
        billerVO= list.get(0);
    	if(billerVO.getIsOnline()!=null && billerVO.getIsOnline().equalsIgnoreCase(CommonConstants.YES_Y)){
    		setBillerField=new HashSet<BillerField>();
			for(BillerField field:billerVO.getBillerFields()){
				
				if(field.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
					if(field.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
						setItems=new HashSet<BillerFieldItemVO>();
						for(BillerFieldItemVO item:field.getBillerFieldItems()){
							if(item.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
								setItems.add(item);
							}
						}
						field.setBillerFieldItems(setItems);
					}
					setBillerField.add(field);
				}
			}
			billerVO.setBillerFields(setBillerField);//
		}
        }
        
		LOGGER.info("completed retriving");

        
		}catch(Exception e){
			LOGGER.info("Exception getWalletUniqueBillerId BillerVO.getId()************************",e);
			//LOGGER.debug("BillerVO.getId()************************"+e.getMessage());
		}finally{
			if(session != null){
				session.flush();
				session.close();
			}
			
		}
		LOGGER.info("PayeeManagementDAOImpl :: getWalletUniqueBillerId :: End ");
		return billerVO;
}
	
	// Added for Orange Money Biller got disabled in Biller Download Handling - end
	
	//Added for Orange Money - end
}