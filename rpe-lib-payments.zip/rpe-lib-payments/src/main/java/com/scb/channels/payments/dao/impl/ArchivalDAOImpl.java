package com.scb.channels.payments.dao.impl;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.payments.dao.ArchivalDAO;

public class ArchivalDAOImpl extends HibernateDaoSupport implements ArchivalDAO{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ArchivalDAOImpl.class);

	@Override
	public BillerDownloadResponseVO archive(
			BillerDownloadRequest billerDownloadRequest) {

		LOGGER.info("ArchivalDAO inside archive method");
		
		Session session = null;
		
		BillerDownloadResponseVO billerDownloadResponse = new BillerDownloadResponseVO();
		try {
 			session = getHibernateTemplate().getSessionFactory().openSession();
			
			Query billPaymentquery = session.getNamedQuery("callStockStoreProcedureBillPayment");
			billPaymentquery.setString("i_tablename", "BILL_PAYMENT");
			List billPaymentList = billPaymentquery.list();
			System.out.println("------billPaymentList--------value ---------" + billPaymentList);
			LOGGER.info("-----billPaymentList---------value --------- ::: " + billPaymentList);
			
			billerDownloadResponse.setStatus("Submitted");
			billerDownloadResponse.setStatusDesc("Submitted");
			
		}catch(Exception ex) {
			 
			 LOGGER.error("Exception occurred duirng Archieve Process::: " + ex.getMessage());
			 
		} finally {
			if(session != null) {
				LOGGER.info("ArchivalDAOImpl closing Session ");
				session.close();
			}
		}	
		return billerDownloadResponse; 
	}

}
