package com.scb.channels.qrpayments.processor;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRAdditionalFieldVO;
import com.scb.channels.base.vo.QRFeeTypeVO;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.qrpayments.service.QRPaymentTransactionService;

public class QRPaymentTransactionProcessor extends AbstractProcessor{
	
	
	 /** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentTransactionProcessor.class);
	
	QRPaymentTransactionService qrPaymentTransactionService;

	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

		QRPaymentRequestVO qrPaymentRequestVO = null;
		QRPaymentResponseVO qrPaymentResponseVO = null;
		try{
		qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
		LOGGER.info("Task in QRPayment Transaction Processor ::::: Start :::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
		List<QRMerchantPanTypeVO> merchantPanList = qrPaymentRequestVO.getQrPaymentDetailVO().getMerchantPanList();		
		if (merchantPanList.size() > 0) {
		    Collections.sort(merchantPanList, new Comparator<QRMerchantPanTypeVO>() {
		        @Override
		        public int compare(final QRMerchantPanTypeVO object1, final QRMerchantPanTypeVO object2) {
		        return object1.getRefId().compareTo(object2.getRefId());      			        		
		        }
		    } );
		}
				
		for(QRMerchantPanTypeVO qrMerchantPanTypeVO : merchantPanList){
			if(qrPaymentRequestVO.getQrPaymentDetailVO().getCardNumber() != null && qrPaymentRequestVO.getQrPaymentDetailVO().getCardNumber().startsWith(CommonConstants.VISA_INDICATOR) && 
					(qrMerchantPanTypeVO.getRefId() != null && qrMerchantPanTypeVO.getRefId().equalsIgnoreCase(CommonConstants.VISA_MERCHANT_02) || 
						(qrMerchantPanTypeVO.getRefId() != null && qrMerchantPanTypeVO.getRefId().equalsIgnoreCase(CommonConstants.VISA_MERCHANT_03)))){
				if(qrMerchantPanTypeVO.getRefValue() == null)
					throw new BusinessException("Customer Select Visa Card , but the merchant PAN not belong to Visa Network");
				if(qrMerchantPanTypeVO.getRefValue() != null && qrMerchantPanTypeVO.getRefValue().trim().length()>6 && qrMerchantPanTypeVO.getRefValue().trim().length() <16){
					String visaPAN = visaMerchantPanGenerator(qrMerchantPanTypeVO.getRefValue());
					qrPaymentRequestVO.getQrPaymentDetailVO().setMerchantPan(visaPAN);
				}else{
				qrPaymentRequestVO.getQrPaymentDetailVO().setMerchantPan(qrMerchantPanTypeVO.getRefValue());
				}
				LOGGER.info("MerchantPan Visa  :::"+qrPaymentRequestVO.getQrPaymentDetailVO().getMerchantPan());
				break;
			}
				
			if(qrPaymentRequestVO.getQrPaymentDetailVO().getCardNumber() != null && qrPaymentRequestVO.getQrPaymentDetailVO().getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR) &&
					(qrMerchantPanTypeVO.getRefId() != null && qrMerchantPanTypeVO.getRefId().equalsIgnoreCase(CommonConstants.MASTER_MERCHANT_04) || 
						(qrMerchantPanTypeVO.getRefId() != null && qrMerchantPanTypeVO.getRefId().equalsIgnoreCase(CommonConstants.MASTER_MERCHANT_05)))){
				if(qrMerchantPanTypeVO.getRefValue() == null)
					throw new BusinessException("Customer Select Master Card , but the merchant PAN not belong to Master Network");
				//System.out.println("Before calling Master :::"+qrMerchantPanTypeVO.getRefValue().length());
				if(qrMerchantPanTypeVO.getRefValue() != null && qrMerchantPanTypeVO.getRefValue().trim().length() == 15){
					String masterPAN = masterPANCheckDigitGenerator(qrMerchantPanTypeVO.getRefValue());
					qrPaymentRequestVO.getQrPaymentDetailVO().setMerchantPan(masterPAN);
				}else{
				qrPaymentRequestVO.getQrPaymentDetailVO().setMerchantPan(qrMerchantPanTypeVO.getRefValue());
				}
				LOGGER.info("MerchantPan Master :::  "+qrPaymentRequestVO.getQrPaymentDetailVO().getMerchantPan());
				break;
			}
		}
		if(qrPaymentRequestVO.getQrPaymentDetailVO().getMerchantPan() == null){
			LOGGER.info("Merchant Pan is Null :::::::::::::");
			throw new BusinessException("Merchant Pan Should Not be Null");
		}
		List<QRFeeTypeVO> feeList = qrPaymentRequestVO.getQrPaymentDetailVO().getFeeList();
		
		for(QRFeeTypeVO qrFeeTypeVO : feeList){
			if(qrFeeTypeVO != null && qrFeeTypeVO.getRefId()!= null && qrFeeTypeVO.getRefId().equalsIgnoreCase(CommonConstants.QR_FLAT_FEE_INDICATOR)){
				qrPaymentRequestVO.getQrPaymentDetailVO().setTipOrConvenienceFee(qrFeeTypeVO.getRefValue());
			}else if(qrFeeTypeVO != null && qrFeeTypeVO.getRefId()!= null && qrFeeTypeVO.getRefId().equalsIgnoreCase(CommonConstants.QR_PERCENTAGE_FEE_INDICATOR)){
				qrPaymentRequestVO.getQrPaymentDetailVO().setTipOrConvenienceFee(qrFeeTypeVO.getRefValue());
			}else if(qrFeeTypeVO != null && qrFeeTypeVO.getRefId()!= null && qrFeeTypeVO.getRefId().equalsIgnoreCase(CommonConstants.QR_CUSTOMER_ENTERED_TIP)){
				qrPaymentRequestVO.getQrPaymentDetailVO().setTipOrConvenienceFee(qrFeeTypeVO.getRefValue());
			}
			
		}
		//qrPaymentRequestVO.getQrPaymentDetailVO().setPaymentRemarks(CommonConstants.QR_PAYMENT_REMARKS);
		List<QRAdditionalFieldVO> additionalTagList = qrPaymentRequestVO.getQrPaymentDetailVO().getAdditionalTagList();
		for(QRAdditionalFieldVO additionalTagVO : additionalTagList){
			if(additionalTagVO.getRefId() != null && additionalTagVO.getRefId().equalsIgnoreCase(CommonConstants.QR_ADDITIONAL_TAG_MAID_STR))
				qrPaymentRequestVO.getQrPaymentDetailVO().setMastercardAssignID(additionalTagVO.getRefValue());
			/*if(additionalTagVO.getRefId() != null && additionalTagVO.getRefId().equalsIgnoreCase("11"))*/
				if(additionalTagVO.getRefId() != null && additionalTagVO.getRefId().equalsIgnoreCase(CommonConstants.QR_ADDITIONAL_TAG_MAID))
				qrPaymentRequestVO.getQrPaymentDetailVO().setMaid(additionalTagVO.getRefValue());
			/*if(additionalTagVO.getRefId() != null && additionalTagVO.getRefId().equalsIgnoreCase("07"))*/
				if(additionalTagVO.getRefId() != null && additionalTagVO.getRefId().equalsIgnoreCase(CommonConstants.QR_ADDITIONAL_TAG_TERMINAL_ID))
				qrPaymentRequestVO.getQrPaymentDetailVO().setTerminalId(additionalTagVO.getRefValue());
		}
		
		
		/*if (additionalTagList.size() > 0) {
		    Collections.sort(additionalTagList, new Comparator<QRAdditionalFieldVO>() {
		        @Override
		        public int compare(final QRAdditionalFieldVO object1, final QRAdditionalFieldVO object2) {
		        return object1.getRefId().compareTo(object2.getRefId());      			        		
		        }
		    } );
		}*/
		if(qrPaymentRequestVO.getQrPaymentDetailVO().getCard_type() != null && qrPaymentRequestVO.getQrPaymentDetailVO().getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
			LOGGER.info("Inside To set Purchase Identifier & Secondary Id from AdditionTag Size  :::::::: "+additionalTagList.size());
				if(additionalTagList.size() >0){
					QRAdditionalFieldVO additionalTagVO = additionalTagList.get(0);
					if(additionalTagVO != null && additionalTagVO.getRefId() != null && additionalTagVO.getRefValue() != null){
						qrPaymentRequestVO.getQrPaymentDetailVO().setPurchaseIdentfier(additionalTagVO.getRefValue());
					}
				}
				if(additionalTagList.size() >1){
					QRAdditionalFieldVO additionalTagVO1 = additionalTagList.get(1);
					if(additionalTagVO1 != null && additionalTagVO1.getRefId() != null && additionalTagVO1.getRefValue() != null){
						qrPaymentRequestVO.getQrPaymentDetailVO().setSecondaryId(additionalTagVO1.getRefValue());
					}
				}
		}
		
		Long qrPaymentId = qrPaymentTransactionService.savePayment(qrPaymentRequestVO);
		if(qrPaymentId != null && qrPaymentId != 0L ){
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.SAVE_SUCCESS);
		}else{
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.SAVE_FAIL);
		}
		}catch(Exception e){
			LOGGER.error("Exception occurred in QRPaymentTransactionProcessor  :::: ",e);
			e.printStackTrace();
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.SAVE_FAIL);
			if(qrPaymentResponseVO == null) {
				qrPaymentResponseVO = new QRPaymentResponseVO();
			}				
			if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
			}	
				HostResponseVO hostResponse = new HostResponseVO();
				hostResponse.setCode(ExceptionMessages._105.getCode());
				hostResponse.setDesc(ExceptionMessages._105.getMessage());
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);	
				qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
				
			qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
			qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
			qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
			qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
			bean.setResponseVO(qrPaymentResponseVO);
			//throw new BusinessException(e.getMessage(), e.getCause());
		}
		bean.setRequestVO(qrPaymentRequestVO);
		LOGGER.info("Task in QRPayment Transaction Processor ::::: End ::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
		return bean;
	}

	public QRPaymentTransactionService getQrPaymentTransactionService() {
		return qrPaymentTransactionService;
	}

	public void setQrPaymentTransactionService(QRPaymentTransactionService qrPaymentTransactionService) {
		this.qrPaymentTransactionService = qrPaymentTransactionService;
	}
	
	private String visaMerchantPanGenerator(String merchantPAN){
		LOGGER.info("Inside merchantPanGenerator Method Start ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		System.out.println("Inside merchantPanGenerator Method Start ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		int oldPanLength = merchantPAN.length();
		int zeroLength = 16 - oldPanLength;
		String bin = merchantPAN.substring(0, 6);
		String checkDigit = merchantPAN.substring(6);
		String amendZeros = "";
		for(int i = 0 ; i < zeroLength ; i++){
			amendZeros = amendZeros +"0";
		}
		if(StringUtils.isNotBlank(bin) && StringUtils.isNotBlank(checkDigit) && StringUtils.isNotBlank(amendZeros)){
			merchantPAN = bin.trim()+amendZeros.trim()+checkDigit.trim(); 
		}
		LOGGER.info("Inside merchantPanGenerator Method End ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		System.out.println("Inside merchantPanGenerator Method End ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		return merchantPAN;
	}
	
	private String masterPANCheckDigitGenerator(String merchantPAN){
		LOGGER.info("Inside masterPANCheckDigitGenerator Method Start ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		System.out.println("Inside masterPANCheckDigitGenerator Method Start ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		String digit;
		int[] digits = new int[merchantPAN.length()];
		for (int i = 0; i < merchantPAN.length(); i++) {
			digits[i] = Character.getNumericValue(merchantPAN.charAt(i));
		}
		for (int i = digits.length - 1; i >= 0; i -= 2)	{
			digits[i] += digits[i];
			if (digits[i] >= 10) {
				digits[i] = digits[i] - 9;
			}
		}
		int sum = 0;
		for (int i = 0; i < digits.length; i++) {
			sum += digits[i];
		}
		sum = sum * 9;
		digit = sum + "";
		String checkDigit =  digit.substring(digit.length() - 1);
		if(StringUtils.isNotBlank(checkDigit)){
			merchantPAN = merchantPAN+checkDigit;
		}
		LOGGER.info("Inside masterPANCheckDigitGenerator Method Start ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		System.out.println("Inside masterPANCheckDigitGenerator Method Start ::::"+merchantPAN+"| length :::"+merchantPAN.length());
		return merchantPAN;
	}

}
