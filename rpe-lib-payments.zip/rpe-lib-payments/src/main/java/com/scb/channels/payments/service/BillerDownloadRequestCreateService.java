package com.scb.channels.payments.service;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;

public interface BillerDownloadRequestCreateService {

	
	
	 /**
	 * @param country
	 * @return PayloadDTO
	 * <p> request Creation for Biller Update.
	 */
	public PayloadDTO getRequestforCountry(PayloadDTO dto)throws BusinessException;

	
	/**
	 * @param CountryCode
	 * @param variableKey
	 * @return String
	 */
	public   String getVariableValue(String CountryCode,String variableKey);
}
