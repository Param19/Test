package com.scb.channels.qrpayments.service;

import java.util.List;

import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;

public interface QRPaymentTransactionService {

	public Long savePayment(QRPaymentRequestVO qrPaymentRequestVO) throws Exception;
	
	public void updatePaymentStatus(QRPaymentDetailVO qrPaymentDetailVO);
	
	public String getQRReferenceNumberSequence(QRPaymentDetailVO qrPaymentDetailVO);
	
	public List<QRPaymentDetailVO> getQRPaymentRetryTransactionList(QRPaymentRequestVO qrPaymentRequestVO);
	
	public QRPaymentResponseVO getQRPaymentTxnStatus(QRPaymentRequestVO qrPaymentRequestVO) throws Exception;
	
}
