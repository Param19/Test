package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.BillerManagementService;
import com.scb.channels.payments.service.impl.BillerManagementServiceImpl;

public class BillerProcessor extends AbstractProcessor  {

	BillerManagementService servieceManager;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerManagementServiceImpl.class);
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
			 
		try{
		BillerPayRequestVO request=(BillerPayRequestVO)bean.getRequestVO();
		
		BillerPayResponseVO responseVO=servieceManager.getBillerCategories(request);
		
		bean.setResponseVO(responseVO);
		
		LOGGER.info("Request Compleetd Successfully in BillerProcessor");
		}catch(Exception error){
			
			LOGGER.debug("Error in process class"+error.getMessage());
			
			BillerPayResponseVO response= new BillerPayResponseVO();
			response.setStatus(ExceptionMessages._105.getCode());
			response.setStatusDesc(ExceptionMessages._105.getMessage());
			bean.setResponseVO(response);
			
		}
		 
		return bean;
	}
	
	

	
	public BillerManagementService getServieceManager() {
		return servieceManager;
	}

	public void setServieceManager(BillerManagementService servieceManager) {
		this.servieceManager = servieceManager;
	}

	
}
