package com.scb.channels.payments.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.vo.JetcoPaymentDetailVO;
import com.scb.channels.payments.dao.JetcoPaymentTransactionDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;


/**
 * JetcoPaymentTransactionDAOImpl
 * 
 * @author 1552545
 * 
 */
public class JetcoPaymentTransactionDAOImpl extends HibernateDaoSupport implements JetcoPaymentTransactionDAO {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(JetcoPaymentTransactionDAOImpl.class);
	
	@Override
	public JetcoPaymentDetailVO getJetcoPaymentDetails(String messageId) {
		Session session = null;
		Criteria criteria = null;
		JetcoPaymentDetailVO jetcoPaymentDetailVO = null;
		try {
			LOGGER.info("Creating Session for update ::: " + messageId);
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria = session.createCriteria(JetcoPaymentDetailVO.class).add(Restrictions.eq("bankMessageId", messageId));

			Object object = criteria.uniqueResult();
			if (object != null) {
				jetcoPaymentDetailVO = (JetcoPaymentDetailVO) object;
				LOGGER.info("Obtained persistent object ::: " + messageId);
			} else {
				LOGGER.info("No data in the DB for ::: " + messageId);
			}
		} catch (Exception exception) {
			LOGGER.info("Exception for ::: " + messageId);
			LOGGER.info("Exception occurred duirng saving payment ::: " + exception);
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in get payment details");
				session.close();
			}
		}

		return jetcoPaymentDetailVO;
	}

	@Override
	public JetcoPaymentDetailVO getMatchJetcoPaymentDetails(JetcoPaymentDetailVO payment) {
		return null;
	}


	@Override
	public void updatePaymentStatus(JetcoPaymentDetailVO payment) {
		LOGGER.info("updatePaymentStatus ::: transactionDaoImpl ::: Start");
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			LOGGER.info("Creating Session for update ::: " + payment.getBankMessageId());
			session = getHibernateTemplate().getSessionFactory().openSession();
				
			LOGGER.info("Update the payment ::: " + payment.getBankMessageId());
			transaction = session.beginTransaction();
			session.update(payment);
			
			transaction.commit();
			session.flush();
			LOGGER.info("Update complete ::: " + payment.getBankMessageId());
			
		} catch (Exception exception) {
			LOGGER.info("Exception for ::: " + payment.getBankMessageId());
			 LOGGER.info("Exception occurred duirng update payment ::: " + exception);
			 LOGGER.error("",exception);
			 if (transaction != null) {
				LOGGER.info("Closing transaction in update payment");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in update payment");
				session.close();
			}
		}
		LOGGER.info("updatePaymentStatus ::: transactionDaoImpl ::: End");
	}
	
	@Override
	public JetcoPaymentDetailVO saveJetcoPayment(JetcoPaymentDetailVO payment) {
		LOGGER.info("savePayment ::: transactionDaoImpl ::: Start");
		Session session = null;
		Transaction transaction = null;
		try {
			LOGGER.info("create Session ::: " + payment.getBankMessageId());
			session = getHibernateTemplate().getSessionFactory().openSession();
			transaction = session.beginTransaction();
			LOGGER.info("saving payment ::: " + payment.getBankMessageId());
			payment.setCreatedBy(InvoiceAggregatorhelper.getJVMName());
			payment.setUpdatedBy(InvoiceAggregatorhelper.getJVMName());
			session.save(payment);

			transaction.commit();
			session.flush();
			LOGGER.info("Transaction committed ::: " + payment.getBankMessageId());
		} catch (Exception exception) {
			payment.setId(null);
			LOGGER.info("Exception for ::: " + payment.getBankMessageId());
			LOGGER.info("Exception occurred duirng saving payment ::: ", exception);
			LOGGER.error("", exception);
			if (transaction != null) {
				LOGGER.info("Closing transaction in save payment");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in save payment");
				session.close();
			}
		}

		LOGGER.info("savePayment ::: transactionDaoImpl ::: End");
		return payment;
	}
}
