package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentTransactionService;

/**
 * The Class PaymentUpdateTransactionProcessor.
 */
public class PaymentUpdateTransactionProcessor extends AbstractProcessor {

	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentUpdateTransactionProcessor.class);
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels.common.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in Payment Update processor ::: Start");
		
		BillerPayRequestVO billerPayRequestVO = null;	
		BillerPayResponseVO billerPayResponseVO = null;
		
		if (bean != null && bean.getResponseVO() != null
				&& ((BillerPayResponseVO) bean.getResponseVO()).getBillerPayDetailsVO() !=null ) {
			LOGGER.info("Response Object Available");
			billerPayResponseVO = (BillerPayResponseVO) bean.getResponseVO();
			
			LOGGER.info("Updating from response :::: " + 
					billerPayResponseVO.getBillerPayDetailsVO().getPayRef());
			paymentTransactionService.updatePaymentStatus((billerPayResponseVO.getBillerPayDetailsVO()));
			LOGGER.info("Update complete :::: " + 
					billerPayResponseVO.getBillerPayDetailsVO().getPayRef());
		
		} else if (bean != null && bean.getRequestVO() != null
				&& ((BillerPayRequestVO) bean.getRequestVO()).getBillerPayDetailsVO() !=null ) {
			LOGGER.info("Request Object Available");
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			
			LOGGER.info("Updating from request :::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			paymentTransactionService.updatePaymentStatus((billerPayRequestVO.getBillerPayDetailsVO()));
			LOGGER.info("Update complete :::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		} else {
			LOGGER.info("Payload does not have all the valkues for update");
			throw new BusinessException("PayloadDTO can't be empty...");
		} 
		LOGGER.info("Task in Payment Update processor ::: End");
		return bean;
	}
	
	/**
	 * Sets the payment transaction service.
	 *
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
   
	
	
}
