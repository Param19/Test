package com.scb.channels.payments.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.jms.JMSException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.sc.cash.payment.mobile.v2.invoice.InvoiceInfo;
import com.sc.cash.payment.mobile.v2.invoice.PayerInfo;
import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.PostPaymentReq;
import com.sc.corebanking.v6.transaction.GetTransactionStatusReq;
import com.sc.corebanking.v6.transaction.PostTransactionReq;
import com.sc.corebanking.v6.transaction.PostTransactionReqPayload;
import com.sc.corebanking.v6.transaction.ReverseTransactionReq;
import com.sc.corebanking.v6.transaction.ReverseTransactionReqPayload;
import com.sc.corebanking.v6.transaction.Transaction;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.GetTransactionStatus;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.GetTransactionStatusResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransaction;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.ReverseTransaction;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.ReverseTransactionResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.PostPaymentReqPayload;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.TransactionsPostingVO;
import com.scb.channels.common.helper.ChannelMaskHelper;
import com.scb.channels.common.helper.NarrationHelper;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.AlipayMappingHelper;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.dao.PayeeManagementDAO;
import com.scb.channels.payments.dao.PaymentTransactionDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.CacheManagementService;
import com.scb.channels.payments.service.PaymentTransactionService;
import com.scb.channels.payments.service.TopicPostMessageService;

/**
 * The Class PaymentTransactionServiceImpl.
 */
public class AlipayPaymentTransactionServiceImpl implements PaymentTransactionService {

	/** The Constant BP_00. */
	public static final String BP_00 = "bp,00";

	/** The Constant TRANSACTION_PROCESSED. */
	public static final String TRANSACTION_PROCESSED = "Transaction Processed.";

	/** The Constant PAY_BILL_BY_ACCOUNT. */
	public static final String OPERATION_TYPE = "operationType";

	/** The payment transaction dao. */
	private PaymentTransactionDAO paymentTransactionDAO;

	
	/** The transaction port type. */
	private TransactionPortType postTransactionService;

	private DataBean dataBean;
	
	private PayeeManagementDAO payeeManagementDAO;

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(PaymentTransactionServiceImpl.class);
	private TopicPostMessageService topicPostMessageService;

	private CacheManagementService cacheService;
	
	private ReferenceService referenceService;
	
	/** The cache manager. */
	//private CacheManager cacheManager;
	
	/**
	 * Save payment txn details.
	 *
	 * @param billPmtTxnDetailsVO the bill pmt txn details vo
	 */
	/*public void savePaymentTxnDetails(BillPmtTxnDetailsVO billPmtTxnDetailsVO) {
		paymentTransactionDAO.savePaymentTxnDetails(billPmtTxnDetailsVO);
	}*/

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}


	/**
	 * Perform bill payment in EBBS
	 *
	 * @param billerPayRequestV the biller pay request v
	 * @return the biller pay response vo
	 */

	
	public BillerPayResponseVO performBillPayment(BillerPayRequestVO billerPayRequestVO) {

		LOGGER.info("performBillPayment ::Alipay: TransactionServiceImpl ::: start");
		LOGGER.info("Bill payment request id::Alipay from {} for {} in {} as {}",
				new Object[] { billerPayRequestVO.getUser().getCustomerId(),
						billerPayRequestVO.getUser().getCountry(),
						billerPayRequestVO.getUser().getChannelId(),
						billerPayRequestVO.getMessageVO().getRequestCode() });
		

		BillerPayDetailsVO billpayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		populateInterfacePaymentDetails(billpayDetails);
		populateTransactionPostingDetails(billpayDetails,CommonConstants.POST_PAYMENT);
		Transaction transaction = AlipayMappingHelper.postTransactionRequestMapping(
				billerPayRequestVO, CommonConstants.POST_PAYMENT);
		LOGGER.info("Obtained core banking payment :Alipay object" +	billpayDetails.getPayRef());
		
		
		PostTransactionReqPayload postTransactionReqPayload= new PostTransactionReqPayload();
		//postTransactionReqPayload.setOperationType(OPERATION_TYPE); // HK OpertionType ? 
		postTransactionReqPayload.setPostTransactionReq(transaction);
		postTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
		postTransactionReqPayload.setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
		
		PostTransaction postTransaction = new PostTransaction();
		PostTransactionReq postTransactionReq = new PostTransactionReq();
		
		postTransactionReq.setHeader(AlipayMappingHelper.populateHeader(
				billerPayRequestVO.getUser().getCountry(), 
				CommonConstants.I_BANKING, getGregorianCalendar(),
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef(), 
				CommonConstants.HOGAN, CommonConstants.POST_SINGLE_LEG_TRANSACTION,
				CommonConstants.POST_SINGLE_LEG,CommonConstants.GET_TRANSACTION_STATUS_MESSAGE_TYPE_NAME,
				CommonConstants.DOMAIN_NAME));
		LOGGER.info("Obtained :Alipay core banking header populated" +	billpayDetails.getPayRef());
		
		billpayDetails.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.POST_TRANSACTION);
		postTransactionReq.setPostTransactionReqPayload(postTransactionReqPayload);
		postTransaction.setPostTransactionRequest(postTransactionReq);
		
        String currencyConversion = dataBean.getMap().get(
        		billpayDetails.getCountryCode() + 
				CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
        
        if (currencyConversion != null && !currencyConversion.isEmpty()) {
          /*  Double txnAmount = billpayDetails.getTransactionInfoVO()
        		.getSrcAccountVO().getAmount() != null ? billpayDetails
                .getTransactionInfoVO().getSrcAccountVO().getAmount().doubleValue() : 0;
	        LOGGER.info("Alipay amount from IBNK to Host serviceee Conversion Part::::"+ txnAmount);
	        
	        Integer multiplier = Integer.parseInt(currencyConversion);
	        String strAmount = ((Arrays.asList((String.valueOf(txnAmount * multiplier)).
	        		split(Pattern.quote(".")))).get(0)).toString();*/
        	
        	BigDecimal amount = billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?        	
        			billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
        	
        	String strAmount = (Arrays.asList((String.valueOf(
                			amount.multiply(new BigDecimal(currencyConversion))).
                			        split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
        			
	        LOGGER.info("Alipay amount from RPE to Host serviceee Conversion Part::::" + strAmount);
	
	        postTransaction.getPostTransactionRequest().getPostTransactionReqPayload().
        		getPostTransactionReq().getTransactionInfo().getTransactionsPosting().
        		get(0).setTransactionAmount(strAmount);
	        LOGGER.info("Alipay Currency code for  Conversion Part::TransactionAmount : End:::"+strAmount);
        }
		
		/*String str = CommonHelper.getXML(postTransaction, PostTransaction.class,
				PostTransaction.class.getSimpleName());
		System.out.println(str);*/

		PostTransactionResponse postResponse = postTransactionService.postTransaction(postTransaction);
		
		LOGGER.info("Obtained response from :Alipay corebanking application" +	billpayDetails.getPayRef());
		
		/*String responseStr = CommonHelper.getXML(postResponse, PostTransactionResponse.class,
				PostTransactionResponse.class.getSimpleName());
		System.out.println(responseStr);*/
		
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		if (postResponse != null && postResponse.getPostTransactionResponse() != null && 
				postResponse.getPostTransactionResponse().getHeader() != null && 
				postResponse.getPostTransactionResponse().getHeader().getExceptions() != null) {
			
			// Check if there is any exception from Hogan response
			for (ExceptionType exceptionType : postResponse.getPostTransactionResponse().getHeader()
					.getExceptions().getException()) {
				LOGGER.info("Exceptions present in the :Alipay response ::: " +	billpayDetails.getPayRef());
				LOGGER.info("Exceptions code :Alipay::: " + exceptionType.getCode().getValue() 
						+ " ::: " +	billpayDetails.getPayRef());
				LOGGER.info("Exceptions description :Alipay::: " +	exceptionType.getDescription()
						+ " ::: " +	billpayDetails.getPayRef());
				
				billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
				billpayDetails.getTransactionInfoVO()
						.setTxnStatusCd(CommonConstants.FAIL);
				
				billerPayResponseVO.setStatusDesc(
						exceptionType.getDescription());
				billerPayResponseVO.setStatus(
						exceptionType.getCode().getValue());
				billpayDetails.getTransactionInfoVO()
					.setHostRespCd(exceptionType.getCode().getValue());
				billpayDetails.getTransactionInfoVO()
					.setHostRespDesc(exceptionType.getDescription());
			
				billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
			}
			LOGGER.info("performBillPayment ::: Alipay TransactionServiceImpl ::: End");
			return billerPayResponseVO;
		} else if(postResponse != null && postResponse.getPostTransactionResponse() != null &&
				postResponse.getPostTransactionResponse().getPostTransactionResPayload() != null &&
				postResponse.getPostTransactionResponse().getPostTransactionResPayload().
					getPostTransactionRes() != null && 
				postResponse.getPostTransactionResponse().getPostTransactionResPayload().
					getPostTransactionRes().getTransactionInfo() != null) {
			LOGGER.info("reversal payload available for ::: " + billpayDetails.getPayRef());
			
			billpayDetails.getTransactionInfoVO().setHostRespCd(postResponse.
					getPostTransactionResponse().getPostTransactionResPayload().
					getPostTransactionRes().getTransactionInfo().getTransactionResultCode());
			
			billpayDetails.getTransactionInfoVO().setHostRespDesc(postResponse.
					getPostTransactionResponse().getPostTransactionResPayload().
					getPostTransactionRes().getTransactionInfo().getTransactionStatusDescription());
			
			LOGGER.info("Status Details :::: {} ::: {} ::: {} :::::", new Object[] {
					billpayDetails.getPayRef(), billpayDetails.getTransactionInfoVO().getHostRespCd(),
					billpayDetails.getTransactionInfoVO().getHostRespDesc()});
			
			if(CommonConstants.HOGAN_FAILUR_LIST.contains(postResponse.
					getPostTransactionResponse().getPostTransactionResPayload().
					getPostTransactionRes().getTransactionInfo().getTransactionStatus())) {
				
				LOGGER.info("Hogan failure status while post transaction :::: " + billpayDetails.getPayRef());
				
				billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
			} else {
				billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_SUCCESS);
			}
		} else { 
			LOGGER.info("No response payload from host ::: " +	billpayDetails.getPayRef());
			
			billpayDetails.setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
			billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			
			billpayDetails.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT_CODE);
			billpayDetails.getTransactionInfoVO().setHostRespDesc("No response payload from host");
		}
		billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);

		billerPayResponseVO.setStatus(CommonConstants.THREE_ZEROES);
		billerPayResponseVO.setStatusDesc(TRANSACTION_PROCESSED);
		billerPayResponseVO.setErrorCD(BP_00);
		
		LOGGER.info("Biller Payment Response Alipay for request id:{}, {}, {}", 
			new Object[] {billerPayRequestVO.getMessageVO().getRequestCode(), 
				billpayDetails.getTransactionInfoVO().getHostRespCd(),
				billpayDetails.getTransactionInfoVO().getHostRespDesc()});
		
		return billerPayResponseVO;
	}

	
	
	/**
	 * Inform the payment to the Alipay aggregator
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	public BillerPayRequestVO aggregatorPayment(BillerPayRequestVO billerPayRequestVO) {
		LOGGER.info("AlipayPaymentTransactionServiceImpl:: alipayAggregatorPayment ::: Start for ["+ billerPayRequestVO.getMessageVO().getReqID() +"]");	
		BillerPayDetailsVO billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
		try {
	
			billerPayDetailsVO.setHostName(CommonConstants.ALIPAY_AGGREGATOR);
			
			PostPaymentReq postPaymentReq = new PostPaymentReq();
			
			PostPaymentReqPayload postPaymentReqPayload = new PostPaymentReqPayload();
			com.sc.cash.payment.mobile.v2.invoice.Invoice invoice = new com.sc.cash.payment.mobile.v2.invoice.Invoice();
			InvoiceInfo  invoiceInfo = new InvoiceInfo();
			PaymentDetails paymentDetails = new PaymentDetails();
			
			String strAmount = billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ? 
					billerPayDetailsVO.	getTransactionInfoVO().getSrcAccountVO().getAmount().toString() : CommonConstants.ZERO;
				
			LOGGER.info("Updating the Payment details for alipay aggregator posting");	
			paymentDetails.setPayerTransactionID(billerPayDetailsVO.getHostReference());
			paymentDetails.setInvoiceNumber(billerPayDetailsVO.getHostReference());
			paymentDetails.setAccountNumber(billerPayDetailsVO.getConsumerNo());
			paymentDetails.setClientSecret(CommonConstants.ENCRYPTION);
			paymentDetails.setTransactionCurrencyCode(billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getCurrency());
				
			
			LOGGER.info("billerPayDetailsVO.getPaymentType(): "+billerPayDetailsVO.getPaymentType());
	
			if(billerPayDetailsVO.getPaymentType().equalsIgnoreCase(CommonConstants.CASA)) {
				paymentDetails.setPaymentMode(CommonConstants.BANKACCOUNT);
			} else {
				paymentDetails.setPaymentMode(CommonConstants.CREDITCARD);
			}
			
			PayerInfo info = new PayerInfo();
			//info.setPayerName(billerPayRequestVO.getUser().getCustName());		
			String sCustName = billerPayDetailsVO.getCustName() !=null ? billerPayDetailsVO.getCustName(): billerPayDetailsVO.getConsumerNo();
			info.setPayerName(sCustName);
					
			String maskDetails = referenceService.getReferenceMap(InvoiceAggregatorhelper.getReferenceVO(billerPayRequestVO)).get(CommonConstants.MASKING + paymentDetails.getPaymentMode());
			
			//String maskDetails = dataBean.getMap().get(billerPayDetailsVO.getCountryCode() + CommonConstants.MASK_ACCOUNTNUMBER);
			
			String maskAccNo = "";
			if(maskDetails != null) { //mask based on DB configuration
				String[] maskData = maskDetails.split(CommonConstants.COMMA);
				maskAccNo = new ChannelMaskHelper().maskString(billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAccountNumber(), 
						new Integer(maskData[1]), new Integer(maskData[2]), new Integer(maskData[3]), maskData[0]);				
			} else {
				//Default masking except last 4 charactors
				maskAccNo = new ChannelMaskHelper().maskExceptRightOperation(billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAccountNumber(), 
						billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAccountNumber().length()-4);
			}
			
			info.setPayerAccountNo(maskAccNo);
			
			LOGGER.info("masked account number [" + maskAccNo +"]");	
			paymentDetails.setPayerInfo(info);
			
			Map<String, String> referenceValues = referenceService.getReferenceMap(InvoiceAggregatorhelper.getReferenceVO(billerPayRequestVO, CommonConstants.I_BANKING));
			String currencyConversion = referenceValues.get(CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
			
			if(currencyConversion != null && !currencyConversion.isEmpty()
					&& !currencyConversion.equals(CommonConstants.ZERO)) {

				BigDecimal amount = billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?
						billerPayDetailsVO.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
					
		            strAmount = (Arrays.asList((String.valueOf(
		            	amount.multiply(new BigDecimal(currencyConversion))).
			        		split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
		            LOGGER.info("Alipay Currency code for  Conversion Part to Aggregator ::TransactionAmount : End:::"+strAmount);
				
				/*Double txnAmount = billerPayDetailsVO.getTransactionInfoVO().
						getSrcAccountVO().getAmount() != null ? billerPayDetailsVO.
						getTransactionInfoVO().getSrcAccountVO().getAmount().doubleValue() : 0;
				
				Integer multiplier = Integer.valueOf(currencyConversion);
						
				strAmount = ((Arrays.asList((String.valueOf(txnAmount*multiplier))
						.split(Pattern.quote(".")))).get(0)).toString();*/
				
			} 
			paymentDetails.setTransactionAmount(strAmount);
			
			invoiceInfo.getPaymentDetails().add(paymentDetails);
			invoice.setInvoiceInfo(invoiceInfo);	
			
			postPaymentReqPayload.setPostPaymentReq(invoice);
			postPaymentReq.setPostPaymentReqPayload(postPaymentReqPayload);
			
			LOGGER.info("setting scbml header in the request");	
		
			/*postPaymentReq.setHeader(AlipayMappingHelper.populateHeader( billerPayRequestVO.getUser().getCountry(), CommonConstants.I_BANKING, 
					AlipayMappingHelper.getGregorianCalendar(),	billerPayRequestVO.getBillerPayDetailsVO().getPayRef(),	CommonConstants.ALIPAY_AGGREGATOR, 
					CommonConstants.POST_PAYMENT, CommonConstants.PUT, CommonConstants.INVOICE_NAME, CommonConstants.DOMAIN_NAME_AGG));
			*/
			postPaymentReq.setHeader(AlipayMappingHelper.populateHeader( billerPayDetailsVO.getCountryCode(), CommonConstants.I_BANKING, 
					AlipayMappingHelper.getGregorianCalendar(),	billerPayDetailsVO.getPayRef(),	CommonConstants.ALIPAY_AGGREGATOR, 
					CommonConstants.POST_PAYMENT, CommonConstants.PUT, CommonConstants.INVOICE_NAME, CommonConstants.DOMAIN_NAME_AGG));
			LOGGER.info("Generating XML string request for aggregator");	
			String xml = CommonHelper.getXML(postPaymentReq, PostPaymentReq.class, 
					CommonConstants.AGGREGATOR_SUBTYPE);
		
			LOGGER.info("request to be posted" + billerPayDetailsVO.getPayRef());
			
			if(referenceValues.get(CommonConstants.REQUEST_TOPIC) != null)
				topicPostMessageService.postMessage(xml, referenceValues.get(CommonConstants.REQUEST_TOPIC));
			else 
				throw new Exception("Setup Not Found: Topic Details Not Found for this service");
			
			LOGGER.info("request posted" + billerPayDetailsVO.getPayRef());	
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_INPROGRESS);
			
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.SUCCESS);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(CommonConstants.TIMEOUT_MSG);
			
		} catch (JMSException jmsException) {
			LOGGER.info("Alipay JMS Exception for ::: " + billerPayDetailsVO.getPayRef());
			LOGGER.error("Alipay JMS Exception occurred ::: ", jmsException);
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
			
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(jmsException.getMessage());
			
		} catch(Exception exception){
			LOGGER.info("Alipay Exception for ::: " + billerPayDetailsVO.getPayRef());
			LOGGER.error("Alipay Exception occurred ::: ", exception);	
			
			billerPayDetailsVO.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			
			billerPayDetailsVO.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT);
			billerPayDetailsVO.getTransactionInfoVO().setHostRespDesc(exception.getMessage());
			
		}
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		LOGGER.info("Alipay ::: aggregatorPayment ::: TransactionServiceImpl ::: End for ["+ billerPayRequestVO.getMessageVO().getReqID() +"]");
		return billerPayRequestVO;
	}

	
	/**
	 * Perform reversal fund transfer in EBBS
	 * 
	 * @param billerPayRequestVO
	 *            the biller pay request vos
	 * @return the transfer response vo
	 */
	public BillerPayResponseVO reversalBillPayment(BillerPayRequestVO billerPayRequestVO){
		
		LOGGER.info(
				"Reversal Fund Transfer request recieved transfer Alipay request id:{}  from {} for {} in {} as {}",
				new Object[] {billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnId(),
						billerPayRequestVO.getUser().getCustomerId(), billerPayRequestVO.getUser().getCountry(),
						billerPayRequestVO.getUser().getChannelId(), billerPayRequestVO.getMessageVO().getRequestCode() });
		
		ReverseTransaction revTransaction = new ReverseTransaction();
		ReverseTransactionReq revReq = new ReverseTransactionReq();
		ReverseTransactionReqPayload revReqPayLoad = new ReverseTransactionReqPayload();
		
		BillerPayDetailsVO billpayDetails = billerPayRequestVO.getBillerPayDetailsVO();
		populateTransactionPostingDetails(billpayDetails,CommonConstants.REVERSAL);
		Transaction transaction = AlipayMappingHelper.postTransactionRequestMapping(
				billerPayRequestVO, CommonConstants.REVERSAL);
		LOGGER.info("Obtained Reversal core banking payment :Alipay object" +	billpayDetails.getPayRef());
		
		String currencyConversion = dataBean.getMap().get(
        		billpayDetails.getCountryCode() + 
				CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
		
        if (currencyConversion != null && !currencyConversion.isEmpty()) {
           /* Double txnAmount = billpayDetails.getTransactionInfoVO()
        		.getSrcAccountVO().getAmount() != null ? billpayDetails
                .getTransactionInfoVO().getSrcAccountVO().getAmount().doubleValue() : 0;
	        LOGGER.info("Reversal amount from IBNK to Host serviceee Conversion Part ::::"+ txnAmount);
	        
	        Integer multiplier = Integer.parseInt(currencyConversion);
	        String strAmount = ((Arrays.asList((String.valueOf(txnAmount * multiplier)).
	        		split(Pattern.quote(".")))).get(0)).toString();*/
	        
	        BigDecimal amount = billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?        	
        			billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
        	LOGGER.info("Reversal amount from IBNK to Host serviceee Conversion Part ::::"+ amount);
        	String strAmount = (Arrays.asList((String.valueOf(
                			amount.multiply(new BigDecimal(currencyConversion))).
                			        split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString();
	        
	        LOGGER.info("Reversal amount from RPE to Host serviceee Conversion Part ::::" + strAmount);
	
	        transaction.getTransactionInfo().getTransactionsPosting().get(0).setTransactionAmount(strAmount);
	        LOGGER.info("Alipay Currency code for  Conversion Part::TransactionAmount : End:::"+strAmount);
        }
		
		revReqPayLoad.setReverseTransactionReq(transaction);
		revReqPayLoad.setPayloadFormat(PayloadFormatEnum.XML);
		revReqPayLoad.setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);
		
		revReq.setHeader(AlipayMappingHelper.populateHeader(
				billerPayRequestVO.getUser().getCountry(), 
				CommonConstants.I_BANKING, getGregorianCalendar(),
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef(), 
				CommonConstants.HOGAN, CommonConstants.REVERSE_TRANSACTION,
				CommonConstants.ALIPAY_REVERSE_POSTING,CommonConstants.REVERSE_TRANSFER_MESSAGE_TYPE_NAME,
				CommonConstants.DOMAIN_NAME));
		LOGGER.info("Obtained :Alipay Reversal core banking header populated" +	billpayDetails.getPayRef());
		
		billpayDetails.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.REVERSE_TRANSFER_SUB_TYPE_NAME);
		revReq.setReverseTransactionReqPayload(revReqPayLoad);
		revTransaction.setReverseTransactionRequest(revReq);
				
		/*String str = CommonHelper.getXML(revTransaction, ReverseTransaction.class,
				ReverseTransaction.class.getSimpleName());
		System.out.println(str);*/

		ReverseTransactionResponse reverseTransactionResponse = postTransactionService.reverseTransaction(revTransaction);
		billerPayRequestVO.getBillerPayDetailsVO().setHostName(
				CommonConstants.HOGAN + " - " + CommonConstants.REVERSE_TRANSACTION);
		
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		if (reverseTransactionResponse != null && reverseTransactionResponse.getReverseTransactionResponse() != null && 
				reverseTransactionResponse.getReverseTransactionResponse().getHeader() != null &&
				reverseTransactionResponse.getReverseTransactionResponse().getHeader().getExceptions() != null) {
			
			// Check if there is any exception from Hogan response
			for (ExceptionType exceptionType : reverseTransactionResponse
					.getReverseTransactionResponse().getHeader().getExceptions().getException()) {
				
				LOGGER.info("Exceptions present in the reversal transaction:Alipay response ::: " 
						+	billpayDetails.getPayRef());
				LOGGER.info("Exceptions code reversal transaction :Alipay::: " + exceptionType.getCode().getValue() 
						+ " ::: " +	billpayDetails.getPayRef());
				LOGGER.info("Exceptions description reversal transaction :Alipay::: " +	exceptionType.getDescription()
						+ " ::: " +	billpayDetails.getPayRef());
				
			
					billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_TIMEOUT);
					billpayDetails.getTransactionInfoVO()
							.setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.setStatusDesc(
							exceptionType.getDescription());
					billerPayResponseVO.setStatus(
							exceptionType.getCode().getValue());
				billpayDetails.getTransactionInfoVO()
					.setHostRespCd(exceptionType.getCode().getValue());
				billpayDetails.getTransactionInfoVO()
					.setHostRespDesc(exceptionType.getDescription());
			
				billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
			}
			LOGGER.info("performBillPayment ::: Alipay reversal TransactionServiceImpl ::: End");
			return billerPayResponseVO;
		} else if (reverseTransactionResponse != null && 
			reverseTransactionResponse.getReverseTransactionResponse() != null && 
			reverseTransactionResponse.getReverseTransactionResponse().
				getReverseTransactionResPayload() != null &&
			reverseTransactionResponse.getReverseTransactionResponse().
				getReverseTransactionResPayload().getReverseTransactionRes() != null &&
			reverseTransactionResponse.getReverseTransactionResponse().
				getReverseTransactionResPayload().getReverseTransactionRes().getTransactionInfo() != null) {
			
			LOGGER.info("reversal payload available for ::: " + billpayDetails.getPayRef());
			
			billpayDetails.getTransactionInfoVO().setHostRespCd(reverseTransactionResponse
					.getReverseTransactionResponse().getReverseTransactionResPayload()
					.getReverseTransactionRes().getTransactionInfo().getTransactionResultCode());
			
			billpayDetails.getTransactionInfoVO().setHostRespDesc(reverseTransactionResponse
					.getReverseTransactionResponse().getReverseTransactionResPayload()
					.getReverseTransactionRes().getTransactionInfo().getTransactionStatusDescription());
			
			LOGGER.info("Status Details :::: {} ::: {} ::: {} :::: ", new Object[] {
					billpayDetails.getPayRef(), billpayDetails.getTransactionInfoVO().getHostRespCd(),
					billpayDetails.getTransactionInfoVO().getHostRespDesc()});
			
			if(CommonConstants.HOGAN_FAILUR_LIST.contains(reverseTransactionResponse
					.getReverseTransactionResponse().getReverseTransactionResPayload()
					.getReverseTransactionRes().getTransactionInfo().getTransactionStatus())) {
				
				LOGGER.info("Hogan failure status while reversal transaction :::: " + billpayDetails.getPayRef());
				
				billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
			} else {
				billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_SUCCESS);
			}
		} else {
			LOGGER.info("No reversal response payload from host ::: " +	billpayDetails.getPayRef());
			
			billpayDetails.setTxnActStatus(CommonConstants.REVERSAL_PAY_TIMEOUT);
			billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			
			billpayDetails.getTransactionInfoVO().setHostRespCd(CommonConstants.TIMEOUT_CODE);
			billpayDetails.getTransactionInfoVO().setHostRespDesc("No response payload from host");
		}
		
		billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
		billerPayResponseVO.setStatus(CommonConstants.THREE_ZEROES);
		billerPayResponseVO.setStatusDesc(TRANSACTION_PROCESSED);
		billerPayResponseVO.setErrorCD(BP_00);
		
		LOGGER.info("Biller Payment Response Alipay for request id:{}, {}", 
			new Object[] {billerPayRequestVO.getMessageVO().getRequestCode(), 
				billerPayResponseVO.getStatusDesc()});
		
		LOGGER.info("Got Reversal Fund Transfer Alipay Response");
		return billerPayResponseVO;
	}

	/**
	 * Gets the gregorian calendar.
	 * 
	 * @return the gregorian calendar
	 */
	private XMLGregorianCalendar getGregorianCalendar() {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

		} catch (DatatypeConfigurationException e) {

		}
		return date;
	}

	/**
	 * Save payment txn.
	 *
	 * @param billerPayDetailsVO the biller pay details vo
	 */
	public Long savePayment(BillerPayDetailsVO billerPayDetailsVO) {
		LOGGER.info("savePayment ::: TransactionServiceImpl ::: Start");
		Long paymentId = 0L;
		PaymentDetailVO payment = BillpaymentMappingHelper.getPaymentDetails(billerPayDetailsVO);
		payment.setPaymentStatus(CommonConstants.NEW);
		
		LOGGER.info("Send to save payment ::: " + billerPayDetailsVO.getPayRef());
		paymentTransactionDAO.savePayment(payment);
		
		if(payment != null && payment.getId() != null){
			paymentId = payment.getId();
			LOGGER.info("Payment saved successfull ::: " 
					+ billerPayDetailsVO.getPayRef());
		} else {
			LOGGER.info("Problem in saving payment. Payment not saved ::::: " 
					+ billerPayDetailsVO.getPayRef());
		}
		LOGGER.info("savePayment ::: TransactionServiceImpl ::: End");
		return paymentId;
	}

	/**
	 * Update the payment record in the database
	 * @param billerPayRequestVO
	 * @return
	 */
	public void updatePaymentStatus(BillerPayDetailsVO billerPayDetailsVO) {
		LOGGER.info("updatePaymentStatus ::: transactionServiceImpl ::: Start");
		try {
			PaymentDetailVO payment = BillpaymentMappingHelper.getPaymentDetails(billerPayDetailsVO);
			if(payment.getHostStatusCode() == null){
				payment.setHostStatusCode("NA");
			}
			PaymentDetailVO dbPayment = paymentTransactionDAO.
					getPaymentDetails(payment.getReferenceNumber());
			
			if(dbPayment != null) {
				LOGGER.info("Setting latest status ::: " + payment.getReferenceNumber());
				if(dbPayment.getStaffFlag() == null 
						&& payment.getStaffFlag() != null){
					dbPayment.setStaffFlag(payment.getStaffFlag());
				}
				if(dbPayment.getHostReferenceNumber() == null){
					dbPayment.setHostReferenceNumber(payment.getHostReferenceNumber());
				}
				if(dbPayment.getAggregatorReference() == null){
					dbPayment.setAggregatorReference(payment.getAggregatorReference());
				}
				//should be set before the payment status is updated in the db payment
				updateRetryVersion(dbPayment , payment);
				
				//Should be set after the retry version is updated
				dbPayment.setPaymentStatus(payment.getPaymentStatus());
				dbPayment.setHostStatusCode(payment.getHostStatusCode());
				dbPayment.setHostStatusDescription(payment.getHostStatusDescription());
				dbPayment.setUpdatedBy(InvoiceAggregatorhelper.getJVMName());
				dbPayment.setUpdatedTime(new Timestamp(new Date().getTime()));
				
				paymentTransactionDAO.updatePaymentStatus(dbPayment);
			}
			
			if(billerPayDetailsVO.getTxnActStatus() != null 
					 && payment.getPaymentStatus() != null 
					 && !billerPayDetailsVO.getTxnActStatus().
					 equalsIgnoreCase(payment.getPaymentStatus())){
			   
				LOGGER.info("Updating the status from ::: " + billerPayDetailsVO.getTxnActStatus() 
						+ " :::: to :::: " + payment.getPaymentStatus());
				
			   billerPayDetailsVO.setTxnActStatus(payment.getPaymentStatus());
			}
		} catch (Exception exception) {
			LOGGER.info("Exception occurred while updating payments ::: " 
					+ billerPayDetailsVO.getPayRef());
			LOGGER.info("Exception ::: " + exception);
			LOGGER.error("Exception ::: " + exception);
		}
		
		LOGGER.info("updatePaymentStatus ::: transactionServiceImpl ::: End");
	}
	
	/**
	 * @param billerPayDetails
	 * @return BillerPayDetailsVO
	 */
	private BillerPayDetailsVO populateInterfacePaymentDetails(BillerPayDetailsVO billerPayDetails){
		LOGGER.info("populateInterfacePaymentDetails ::: "
				+ "Populate all the interface relaated details for payments ::: Alipay");
		
		/*BillerCatgegoryReference billerCategoryReference = getBillerCategoryReference(
				billerPayDetails.getBillerCategoryCd(), 
				billerPayDetails.getBillerCd(), 
				billerPayDetails.getCountryCode());
		
		if(billerCategoryReference != null){
			billerPayDetails.setTransactionType(billerCategoryReference.getPaymentTransactionType());
			billerPayDetails.setMerchantCode(billerCategoryReference.getPaymentTransactionCode());
			LOGGER.info("Transaction type and merchant code populated");
		} else {
			LOGGER.info("Obtained billerCategoryReference is null for the combination ::: "
					+ " agg category code ::: " + billerPayDetails.getBillerCategoryCd()
					+ " agg biller code ::: " + billerPayDetails.getBillerCd()
					+ " country code ::: " + billerPayDetails.getCountryCode());
		}*/
		
		List<NarrationVO> narrationConfig = null;
		narrationConfig = cacheService.getNarration(billerPayDetails.getCountryCode(), billerPayDetails.getChannel());
		NarrationVO narrationVOObj = null;
		if(narrationConfig != null){
			LOGGER.debug("narrationConfig is not null ::: Alipay !!!!!");
			for(NarrationVO narrationVO : narrationConfig){
				if(billerPayDetails.getBillerCategoryCd().equalsIgnoreCase(narrationVO.getCategoryId())
						&& billerPayDetails.getBillerCd().equalsIgnoreCase(narrationVO.getBillerId())){
					LOGGER.debug("narrationConfig --- CategoryId and BillerId are matching ::: Alipay !!!!!");
					narrationVOObj = narrationVO;
					break;
				}else if (billerPayDetails.getBillerCategoryCd().equalsIgnoreCase(narrationVO.getCategoryId())){
					LOGGER.debug("narrationConfig --- CategoryId is matching ::: Alipay !!!!!");
					narrationVOObj = narrationVO;
					break;
				}else if(narrationVO.getBillerId() == null && narrationVO.getCategoryId() == null){
					LOGGER.debug("narrationConfig --- Default  ::: Alipay !!!!!");
					narrationVOObj = narrationVO;
					break;
				}
		
			}
		}
		billerPayDetails = NarrationHelper.populateNarration(billerPayDetails,narrationVOObj);
		
		LOGGER.info("narration population complete ::: Alipay");
		
		LOGGER.info("populateInterfacePaymentDetails :::::::: Alipay end");
		return billerPayDetails;
	}
	
	
	public PaymentDetailVO getPaymentDetails(String referenceNumber) {
		return paymentTransactionDAO.getPaymentDetails(referenceNumber);
	}
	
	public List<BillerPayDetailsVO> getReversalFailurePaymentTransactionList(BillerPayRequestVO billerPayRequestVO) {
		List<PaymentDetailVO> paymentDetail = paymentTransactionDAO.getReversalFailurePaymentTransactionList(billerPayRequestVO);
		List<BillerPayDetailsVO> listFromDB = new ArrayList<BillerPayDetailsVO>();
		if(!CollectionUtils.isEmpty(paymentDetail)){
			for(PaymentDetailVO paymentObj : paymentDetail){
				BillerPayDetailsVO	billerDetails = BillpaymentMappingHelper.getBillPayRequestFromPaymentDetails(paymentObj);
				billerDetails.getTransactionInfoVO().setUserVO(billerPayRequestVO.getUser());
				billerDetails.getTransactionInfoVO().setClientVO(billerPayRequestVO.getClientVO());
				billerDetails.getTransactionInfoVO().setServiceVO(billerPayRequestVO.getServiceVO());
				billerDetails.getTransactionInfoVO().setMessageVO(billerPayRequestVO.getMessageVO());
				listFromDB.add(billerDetails);
			}
		}
		return listFromDB;
	}
	
	
	public void updatePmtVersion(BillerPayDetailsVO billerPayDetailsVO) {
		paymentTransactionDAO.updatePmtVersion(billerPayDetailsVO);
	}
	
	public void updateRequestVOString(BillerPayDetailsVO billerPayDetailsVO){
		paymentTransactionDAO.updateRequestVOString(billerPayDetailsVO);
	}
	

	/**
	 * Sets the payment transaction dao.
	 * 
	 * @param paymentTransactionDAO
	 *            the new payment transaction dao
	 */
	public void setPaymentTransactionDAO(
			PaymentTransactionDAO paymentTransactionDAO) {
		this.paymentTransactionDAO = paymentTransactionDAO;
	}

	/**
	 * @return the topicPostMessageService
	 */
	public TopicPostMessageService getTopicPostMessageService() {
		return topicPostMessageService;
	}

	/**
	 * @param topicPostMessageService the topicPostMessageService to set
	 */
	public void setTopicPostMessageService(
			TopicPostMessageService topicPostMessageService) {
		this.topicPostMessageService = topicPostMessageService;
	}

	public List<BillerPayDetailsVO> getPaymentRetryTransactionList(
			BillerPayRequestVO billerPayRequestVO) {
		
		LOGGER.debug("Inside method  getPaymentRetryTransactionList>>>>>>> ");
		BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
		List<BillerPayDetailsVO> billerPayListFromDB = new ArrayList<BillerPayDetailsVO>();
		billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -12);
        Date fromDate = calendar.getTime();
        Calendar cal = DateUtils.getCountryCalendar();
        Date toDate = cal.getTime();
        
        String interval = dataBean.getMap().get(CommonConstants.PAYMENT_RETRY_TIMER);
        int retryInterval = interval != null && !interval.isEmpty() ? 
        			Integer.parseInt(interval) : 0;
        			
		String retryValue = dataBean.getMap().get(CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);
        int retryCount = retryValue != null && !retryValue.isEmpty() ? 
        			Integer.parseInt(retryValue) : CommonConstants.THREE;
        			
        Calendar updatedTimeCalendar = Calendar.getInstance();
        updatedTimeCalendar.add(Calendar.MINUTE, -(retryInterval));
        Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());
        
        LOGGER.debug("At getPaymentRetryTransactionList From Date {} and To Date {}",new Object[]{fromDate,toDate});
        List<PaymentDetailVO>  retryList = paymentTransactionDAO.
    		   getPaymentRetryList(billerPayRequestVO, fromDate, toDate, updatedTimeStamp, retryCount, null, null);
       
       if(retryList != null && !retryList.isEmpty()){
    	   for(PaymentDetailVO paymentObj : retryList){
	   			BillerPayDetailsVO	billerDetails = BillpaymentMappingHelper.getBillPayRequestFromPaymentDetails(paymentObj);
	   			billerDetails.getTransactionInfoVO().setUserVO(billerPayRequestVO.getUser());
	   			billerDetails.getTransactionInfoVO().setClientVO(billerPayRequestVO.getClientVO());
	   			billerDetails.getTransactionInfoVO().setServiceVO(billerPayRequestVO.getServiceVO());
	   			billerDetails.getTransactionInfoVO().setMessageVO(billerPayRequestVO.getMessageVO());
	   			billerPayListFromDB.add(billerDetails);
   			}
       }
       LOGGER.debug("At getPaymentRetryTransactionList End>>>.> ");
       return billerPayListFromDB;
	}
	
	public BillerPayDetailsVO populateDetailsForPayee(BillerPayDetailsVO billerPayDetails) {
		LOGGER.info("paymenttranactionserviceimpl ::: populateDetailsForPayee :::: Start");
		
		if(billerPayDetails.getTransactionInfoVO() != null &&
				billerPayDetails.getTransactionInfoVO().getTransferCurrencyCd() == null){
			billerPayDetails.getTransactionInfoVO().setTransferCurrencyCd(
					billerPayDetails.getTransactionInfoVO().getSrcAccountVO().getCurrency());
		}
		
		LOGGER.info("Getting the payee details for :::: " + billerPayDetails.getPayeeId());
		PayeeDetailVO payee = payeeManagementDAO.getPayee(
				Integer.valueOf(billerPayDetails.getPayeeId()));
		
		if(payee != null && payee.getConsumerNumber() != null
				&& billerPayDetails.getConsumerNo() != null
				&& billerPayDetails.getConsumerNo().
					equalsIgnoreCase(payee.getConsumerNumber())) {
			
			LOGGER.info("Consumer number verification done :::: populating the values");
			
			billerPayDetails.setBillerCategoryCd(
					payee.getBillerVO().getCategorytype().getCategoryId());
			
			billerPayDetails.setBillerCategoryDesc(
			payee.getBillerVO().getCategorytype().getCategoryName());

			billerPayDetails.setBillerCd(payee.getBillerVO().getBillerId());
			billerPayDetails.setUtilityCd(payee.getBillerVO().getBillerUniqueId());
			billerPayDetails.setBillerName(payee.getBillerVO().getBillerShortName());
		}
		
		LOGGER.info("paymenttranactionserviceimpl ::: populateDetailsForPayee :::: End");
		return billerPayDetails;
	}
	

	public List<BillerPayDetailsVO> getInprocessPayments(
			BillerPayRequestVO billerPayRequestVO) {
		
		LOGGER.debug("Inside method  getPaymentRetryTransactionList>>>>>>> ");
		List<BillerPayDetailsVO> billerPayListFromDB = new ArrayList<BillerPayDetailsVO>();
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -12);
        Date fromDate = calendar.getTime();
        Calendar cal = DateUtils.getCountryCalendar();
        Date toDate = cal.getTime();

        String interval = dataBean.getMap().get(CommonConstants.PAYMENT_INPROCESS_TIMER);
        int retryInterval = interval != null && !interval.isEmpty() ? 
        			Integer.parseInt(interval) : 0;
        			
		String retryValue = dataBean.getMap().get(CommonConstants.PAYMENT_INPROCESS_RETRY_COUNT);
        int retryCount = retryValue != null && !retryValue.isEmpty() ? 
        			Integer.parseInt(retryValue) : CommonConstants.THREE;
        
        Calendar updatedTimeCalendar = Calendar.getInstance();
        //updatedTimeCalendar.setTime(new Date());
        updatedTimeCalendar.add(Calendar.MINUTE, -(retryInterval));
        Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());
        
        LOGGER.debug("At getPaymentRetryTransactionList From Date {} and To Date {}",new Object[]{fromDate,toDate});
       List<PaymentDetailVO>  retryList = paymentTransactionDAO.
    		   getInprocessPayments(fromDate, toDate, updatedTimeStamp, retryCount, null); 
       
       if(retryList != null && !retryList.isEmpty()){
    	   for(PaymentDetailVO paymentObj : retryList){
	   			BillerPayDetailsVO	billerDetails = BillpaymentMappingHelper.getBillPayRequestFromPaymentDetails(paymentObj);
	   			billerPayListFromDB.add(billerDetails);
   			}
       }
       LOGGER.debug("At getPaymentRetryTransactionList End>>>.> ");
       return billerPayListFromDB;
	}
	
	/**
	 * @param dbPayment
	 * @param payment
	 * 
	 * Alter the status of the payments and retry counts based on each other
	 */
	private void updateRetryVersion(PaymentDetailVO dbPayment, PaymentDetailVO payment) {
		int retryValue = 0;
		LOGGER.debug(dbPayment.getPaymentStatus() + 
				"   --- dbPayment.getPaymentStatus() Inside updateRetryVersion "
				+ "&&&&&&& payment.getPaymentStatus() ==  "
				+ payment.getPaymentStatus());
		
		if(!payment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_INPROGRESS)) {
			
			if(dbPayment.getPaymentStatus() != null && payment.getPaymentStatus() != null 
					&& dbPayment.getPaymentStatus().equalsIgnoreCase(payment.getPaymentStatus())) {
				retryValue = dbPayment.getVersion();
			} else if(dbPayment.getPaymentStatus() != null && payment.getPaymentStatus() != null 
					&& dbPayment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_INPROCESS)
					&& payment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_TIMEOUT)) {
				// Timeouts during in-process status should also be treated as in-process
				payment.setPaymentStatus(CommonConstants.AGGREGATOR_INPROCESS);
			}
			
			LOGGER.debug("--Inside updateRetryVersion &&&&&&& retryValue  == > "+retryValue);
			dbPayment.setVersion(retryValue+1);
			
	        if(!payment.getPaymentStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_INPROCESS)) {
	        	String strRetryCount = dataBean.getMap().get(CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);
		        int retryCount = strRetryCount != null && !strRetryCount.isEmpty() ? 
		        			Integer.parseInt(strRetryCount) : CommonConstants.THREE;
		        			
				if(dbPayment.getVersion() != null && dbPayment.getVersion() > retryCount) {
					if(payment.getPaymentStatus() != null && 
							CommonConstants.COREBANK_PAY_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.debug("--Inside updateRetryVersion &&&&&&& "
								+ "COREBANK_PAY_TIMEOUT -updated as- COREBANK_PAY_FAILURE");
						payment.setPaymentStatus(CommonConstants.COREBANK_PAY_FAILURE);
					} else if(payment.getPaymentStatus() != null && 
							CommonConstants.AGGREGATOR_PAY_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.debug("--Inside updateRetryVersion &&&&&&& "
								+ "AGGREGATOR_PAY_TIMEOUT -updated as  TIMEOUT");
						payment.setPaymentStatus(CommonConstants.TIMEOUT);
					} else if(payment.getPaymentStatus() != null && 
							CommonConstants.REVERSAL_PAY_TIMEOUT.
							equalsIgnoreCase(payment.getPaymentStatus())) {
						LOGGER.debug("--Inside updateRetryVersion &&&&&&& "
								+ "REVERSAL_PAY_TIMEOUT -updated as- REVERSAL_PAY_FAILURE");
						payment.setPaymentStatus(CommonConstants.REVERSAL_PAY_FAILURE);
					} 
				}
	        } else {
	        	String strInprocessCount = dataBean.getMap().get(CommonConstants.PAYMENT_INPROCESS_RETRY_COUNT);
		        int inProcessCount = strInprocessCount != null && !strInprocessCount.isEmpty() ? 
		        			Integer.parseInt(strInprocessCount) : CommonConstants.THREE;
		        
				if(payment.getPaymentStatus() != null && 
						CommonConstants.AGGREGATOR_INPROCESS.equalsIgnoreCase(payment.getPaymentStatus()) 
						&& dbPayment.getVersion() != null && dbPayment.getVersion() > inProcessCount) {
					LOGGER.debug("--Inside updateRetryVersion &&&&&&& "
							+ "AGGREGATOR_INPROCESS -updated as- IN_PROCESS_STATUS");
					payment.setPaymentStatus(CommonConstants.INPROCESS_STATUS);
				}
	        }
		}
	}
	
	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
	public void setPostTransactionService(TransactionPortType postTransactionService) {
		this.postTransactionService = postTransactionService;
	}
	
	public void setPayeeManagementDAO(PayeeManagementDAO payeeManagementDAO) {
		this.payeeManagementDAO = payeeManagementDAO;
	}
	
	/*public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}*/
	
	public CacheManagementService getCacheService() {
		return cacheService;
	}


	public void setCacheService(CacheManagementService cacheService) {
		this.cacheService = cacheService;
	}


	/* Method to inquire payment status from hogan core banking system
	 * 
	 */
	@Override
	public BillerPayResponseVO paymentStatusCheck(BillerPayRequestVO billerPayRequestVO) {
		
		GetTransactionStatus getTranxStatus = new GetTransactionStatus();
		
		LOGGER.info(" Inside paymentStatusCheck in AlipayPaymentTransactionServiceImpl ");
		billerPayRequestVO.getBillerPayDetailsVO().setHostName(	CommonConstants.HOGAN + " - " + CommonConstants.TRANSACTION_STATUS_ENQUIRY);

		 String currConvMultiplier = dataBean.getMap().get(billerPayRequestVO.getBillerPayDetailsVO().getCountryCode() + 
					CommonConstants.CURRENCY_CONVERSION_MULTIPLIER);
		//populate getTransactionStatusRequest
		GetTransactionStatusReq getTranxStatusReq = AlipayMappingHelper.populateHoganGetTransReqPayloadAndHeader(billerPayRequestVO,currConvMultiplier);
		LOGGER.info(" getTranxStatusReq " + getTranxStatusReq);
		
		//set getTransactionStatusRequest to getTranxStatus
		getTranxStatus.setGetTransactionStatusRequest(getTranxStatusReq);
		LOGGER.info("Before sending Request to EDMI ::: " + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		GetTransactionStatusResponse getTranxStatusResp = postTransactionService.getTransactionStatus(getTranxStatus);
		LOGGER.info("After getting response from EDMI :::: " + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		// populate responseVO
		BillerPayResponseVO  billerPayResponseVO = AlipayMappingHelper.getHoganTransStatusCheckResponse(getTranxStatusResp,billerPayRequestVO);
		LOGGER.info("Got paymentStatusCheck Response ::: " + 
				billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
		
		return billerPayResponseVO;
	}
	
	private BillerPayDetailsVO populateTransactionPostingDetails(BillerPayDetailsVO billerPayDetails,String reversalIndicator){
		try{
		List<TransactionsPostingVO> listTransactionPost = new ArrayList<TransactionsPostingVO>();
		TransactionsPostingVO transactionsPosting =new TransactionsPostingVO();
		LOGGER.info("Inside method populateTransactionPostingDetails -- > Post transaction service start ");
 	transactionsPosting.setAccountCurrencyCode(billerPayDetails.getTransactionInfoVO().getTransferCurrencyCd()); //transactionInfoVO.transferCurrencyCd
		transactionsPosting.setAccountNumber(billerPayDetails.getTransactionInfoVO().getSrcAccountVO().getAccountNumber());//transactionInfoVO.srcAccountVO.accountNumber
		transactionsPosting.setChargeCode("");
		transactionsPosting.setCreditDebitIndicator(CommonConstants.YES); 
		transactionsPosting.setTransactionAmount(billerPayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount().toString());  //transactionInfoVO.srcAccountVO.amount
		transactionsPosting.setSCBTransactionSubcode(CommonConstants.ALIPAY_CASA_TOP_UP);
		
		/*if(billerPayDetails.getPaymentType().equalsIgnoreCase(CommonConstants.CASA)){
			transactionsPosting.setSCBTransactionSubcode(CommonConstants.ALIPAY_CASA_TOP_UP);
		}else{
			transactionsPosting.setSCBTransactionSubcode(CommonConstants.ALIPAY_THRU_CREDIT_CARD);
		}*/
		
		if(null != reversalIndicator && reversalIndicator.equalsIgnoreCase(CommonConstants.REVERSAL))
		{
		transactionsPosting.setSCBTransactionReverseindicator(CommonConstants.REVERSAL_INDICATOR);  // Reversal transaction - 'X'
		}else{
			transactionsPosting.setSCBTransactionReverseindicator(CommonConstants.SPACE);  // "Normal transaction - ' '
		}
		listTransactionPost.add(transactionsPosting);
		
		billerPayDetails.setTransactionsPosting(listTransactionPost);
		LOGGER.info("Inside method populateTransactionPostingDetails -- > Post transaction service end ");
		}catch(Exception e){
			LOGGER.debug("Inside method populateTransactionPostingDetails Exception block-- > Post transaction service "+e.getMessage());
			LOGGER.error("Exception while reversal to HOGAN ::: ", e);
		}
		return billerPayDetails;
		
		
	}

	@Override
	public String getReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO) {
		return paymentTransactionDAO.getReferenceNumberSequence(billerPayRequestVO);
	}


	@Override
	public BillerPayDetailsVO populateDetailsForPayeeCS(BillerPayDetailsVO billerPayDetails) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Long savePaymentCS(BillerPayDetailsVO billerPayDetailsVO) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void saveOneTimePayee(BillerPayRequestVO billerPayRequestVO) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public BillerPayRequestVO aggregatorPaymentCS(BillerPayRequestVO billerPayRequestVO) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getCCReferenceNumberSequence(
			BillerPayRequestVO billerPayRequestVO) {
		// TODO Auto-generated method stub
		return null;
	}

}
		