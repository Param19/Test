package com.scb.channels.payments.service;

import com.scb.channels.base.vo.JetcoPayRequestVO;
import com.scb.channels.base.vo.JetcoPayResponseVO;
import com.scb.channels.base.vo.JetcoPaymentDetailVO;

/**
 * JetcoPaymentTransactionService
 * 
 * @author 1552545
 * 
 */
public interface JetcoPaymentTransactionService {

	/**
	 * Save payment VO.
	 * 
	 * @param JetcoPayRequestVO
	 *            the JETCO pay details VO
	 */
	public Long savePayment(JetcoPayRequestVO request);

	/**
	 * Updates the payment record in the database
	 * 
	 * @param JetcoPayRequestVO
	 */
	public void updatePaymentStatus(JetcoPayRequestVO request);

	/**
	 * Get JETCO payment details by bankMessageId
	 * 
	 * @param messageId
	 * @return
	 */
	public JetcoPaymentDetailVO getPaymentDetails(String bankMessageId);

	/**
	 * Perform JETCO payment in HOGAN
	 * 
	 * @param JetcoPayRequestVO
	 *            the JETCO pay request VO
	 * @return the JETOC pay response VO
	 */
	public JetcoPayResponseVO performJetcoPayment(JetcoPayRequestVO request);

	/**
	 * Reverse the payment done in HOGAN
	 * 
	 * @param JetcoPayRequestVO
	 * @return
	 */
	public JetcoPayResponseVO reversalJetcoPayment(JetcoPayRequestVO request) throws Exception;

}
