/**
 * 
 */
package com.scb.channels.payments.processor;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.payments.service.PaymentTransactionService;

/**
 * @author 1470817
 *
 */
public class PaymentRetryListProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentRetryListProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */
	public List<BillerPayDetailsVO> process() {
		LOGGER.info("Inside PaymentRetryListProcessor Process");
		BillerPayRequestVO billerPayRequestVO = null;
		List<BillerPayDetailsVO> list = null;
		List<BillerPayDetailsVO> tempList = null;
		try {
			LOGGER.info(":::: Getting retry payments for default (africa) ::::");
			billerPayRequestVO = new BillerPayRequestVO();
			list = paymentTransactionService.getPaymentRetryTransactionList(billerPayRequestVO);
			
			LOGGER.info(":::: Getting retry payments for HK ::::");
			BillerPayDetailsVO details = new BillerPayDetailsVO();
			details.setCountryCode("HK");
			billerPayRequestVO.setBillerPayDetailsVO(details);
			tempList = paymentTransactionService.getPaymentRetryTransactionList(billerPayRequestVO);
			
			if(tempList != null && !tempList.isEmpty()) {
				if(list == null){
					list = new ArrayList<BillerPayDetailsVO>();
				}
				list.addAll(tempList);
			}
			
			LOGGER.info("Inside PaymentRetryListProcessor After Fetching retry list from DB -- "+list);
		}catch (Exception e) {
			LOGGER.error("Exception ::: ", e);
		} 
		if(list!=null){
			return list;
		}else{
			return null;
		}
	}
	
	public PayloadDTO populateAlipayPayload(BillerPayDetailsVO billerPayDetailsVO) {
		PayloadDTO payloadDTO = null;
		LOGGER.info("Inside populate Alipay Payload  at PaymentRetryListProcessor ");
		BillerPayRequestVO billerPayRequestVO = null;
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();
		
		try {
			billerPayRequestVO = new BillerPayRequestVO();
			if(billerPayDetailsVO!=null) {
				LOGGER.info("Populate alipay payload for retry :::: " 
						+ billerPayDetailsVO.getPayRef());
				
				user.setCustomerId(billerPayDetailsVO.getCustomerId() != null ?
						billerPayDetailsVO.getCustomerId() : CommonConstants.EMPTY);
				user.setCountry(billerPayDetailsVO.getCountryCode());
				user.setChannelId(billerPayDetailsVO.getChannel() != null ?
						billerPayDetailsVO.getChannel() : CommonConstants.EMPTY);
				
				service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				service.setServiceName(CommonConstants.WALLET_PAYMENT);
				service.setServiceTxnType(CommonConstants.INSERT);
				
				message.setReqID(billerPayDetailsVO.getPayRef());
				message.setRequestCode(billerPayDetailsVO.getPayRef());
				message.setCorrelationId(billerPayDetailsVO.getPayRef());
				
				client.setChannel(billerPayDetailsVO.getChannel() != null ?
						billerPayDetailsVO.getChannel() : CommonConstants.EMPTY);
				client.setCountry(billerPayDetailsVO.getCountryCode());
				client.setPartnerName("ALIPAY");
				client.setPartnerType("ALIPAY WALLET");
				
				billerPayDetailsVO = paymentTransactionService.
						populateDetailsForPayee(billerPayDetailsVO);
				
				billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
				billerPayRequestVO.setUser(user);
				billerPayRequestVO.setClientVO(client);
				billerPayRequestVO.setMessageVO(message);
				billerPayRequestVO.setServiceVO(service);
				
				payloadDTO = new PayloadDTO();
				payloadDTO.setRequestVO(billerPayRequestVO);
				LOGGER.info("Alipay payload for retry populated successfully :::: " 
					+ (billerPayDetailsVO == null || billerPayDetailsVO.getPayRef() == null ?
					"Payee inactive/not available in database" : billerPayDetailsVO.getPayRef()));
			}
		} catch (Exception e) {
			payloadDTO = null;
			LOGGER.error("Exception occurred during retry for one of the alipay payments", e);
			LOGGER.error(e.getMessage());
		} 
		return payloadDTO;
	}
	
	public PayloadDTO populatePayload(BillerPayDetailsVO billerPayDetailsVO) {
		PayloadDTO payloadDTO = null;
		LOGGER.info("Inside populatePayload  at PaymentRetryListProcessor ");
		BillerPayRequestVO billerPayRequestVO = null;
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();
		
		try {
			billerPayRequestVO = new BillerPayRequestVO();
			if(billerPayDetailsVO!=null) {
				LOGGER.info("Populate payload for retry :::: " 
						+ billerPayDetailsVO.getPayRef());
				
				user.setCustomerId(billerPayDetailsVO.getCustomerId() != null ?
						billerPayDetailsVO.getCustomerId() : CommonConstants.EMPTY);
				user.setCountry(billerPayDetailsVO.getCountryCode());
				user.setChannelId(billerPayDetailsVO.getChannel() != null ?
						billerPayDetailsVO.getChannel() : CommonConstants.EMPTY);
				
				service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				service.setServiceName(CommonConstants.BILL_PAYMENT);
				
				message.setReqID(billerPayDetailsVO.getPayRef());
				message.setRequestCode(billerPayDetailsVO.getPayRef());
				message.setCorrelationId(billerPayDetailsVO.getPayRef());
				
				client.setChannel(billerPayDetailsVO.getChannel() != null ?
						billerPayDetailsVO.getChannel() : CommonConstants.EMPTY);
				client.setCountry(billerPayDetailsVO.getCountryCode());
				
				billerPayDetailsVO = paymentTransactionService.
						populateDetailsForPayee(billerPayDetailsVO);
				
				billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
				billerPayRequestVO.setUser(user);
				billerPayRequestVO.setClientVO(client);
				billerPayRequestVO.setMessageVO(message);
				billerPayRequestVO.setServiceVO(service);
				
				payloadDTO = new PayloadDTO();
				payloadDTO.setRequestVO(billerPayRequestVO);
				LOGGER.info("Payload for retry populated successfully :::: " 
					+ billerPayDetailsVO != null && billerPayDetailsVO.getPayRef() != null ? 
					billerPayDetailsVO.getPayRef() : "Payee inactive/not available in database");
			}
		} catch (Exception e) {
			payloadDTO = null;
			LOGGER.error("Exception occurred during retry for one of the payments", e);
			LOGGER.error(e.getMessage());
		} 
		return payloadDTO;
	}

	public List<BillerPayDetailsVO> getInprocessPayments() {
		LOGGER.info("Inside getInprocessPayments Process :::: ");
		BillerPayRequestVO billerPayRequestVO = null;
		List<BillerPayDetailsVO> list = null;
		List<BillerPayDetailsVO> tempList = null;
		
		try {
			LOGGER.info(":::: Getting in-process payments for default (africa) ::::");
			billerPayRequestVO = new BillerPayRequestVO();
			list = paymentTransactionService.getInprocessPayments(billerPayRequestVO);
			
			LOGGER.info(":::: Getting in-process payments for HK ::::");
			BillerPayDetailsVO details = new BillerPayDetailsVO();
			details.setCountryCode("HK");
			billerPayRequestVO.setBillerPayDetailsVO(details);
			tempList = paymentTransactionService.getInprocessPayments(billerPayRequestVO);
			
			if(tempList != null && !tempList.isEmpty()) {
				if(list == null){
					list = new ArrayList<BillerPayDetailsVO>();
				}
				list.addAll(tempList);
			}
			
			LOGGER.info("Inside getInprocessPayments After Fetching in-process list from DB -- "+list);
		}catch (Exception e) {
			LOGGER.error(e.getMessage());
			LOGGER.error("Exception ::: ", e);
		} 
		if(list!=null){
			return list;
		}else{
			return null;
		}
	}
	
	/**
	 * Gets the payment transaction service.
	 *
	 * @return the paymentTransactionService
	 */
	public PaymentTransactionService getPaymentTransactionService() {
		return paymentTransactionService;
	}

	/**
	 * Sets the payment transaction service.
	 *
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
	
}
