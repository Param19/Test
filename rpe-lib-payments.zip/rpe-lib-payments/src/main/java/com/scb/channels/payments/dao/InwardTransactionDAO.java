package com.scb.channels.payments.dao;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.ConstrtaintException;

// TODO: Auto-generated Javadoc
/**
 * The Interface InwardPaymentDAO.
 *
 * @author 1493439
 */
public interface InwardTransactionDAO {
	
	/**
	 * Gets the credit transactions.
	 *
	 * @param inquiryRequest the inquiry request
	 * @return the credit transactions
	 * @throws Exception the exception
	 */
	public List<InwardPaymentDetailVO> getCreditTransactions(InwardInquiryRequestVO inquiryRequest) throws Exception;
	
	/**
	 * Save credit payment.
	 *
	 * @param inwardPaymentDetailVO the inward payment detail vo
	 * @return the inward payment detail vo
	 * @throws BusinessException the business exception
	 */
	InwardPaymentDetailVO saveCreditPayment(InwardPaymentDetailVO inwardPaymentDetailVO) throws BusinessException;
	
	/**
	 * Update credit payment.
	 *
	 * @param inwardPaymentDetailVO the inward payment detail vo
	 */
	void updateCreditPayment(InwardPaymentDetailVO inwardPaymentDetailVO);
	
	/**
	 * Gets the credit payment.
	 *
	 * @param ReferenceNumber the reference number
	 * @return the credit payment
	 * @throws ConstrtaintException the constrtaint exception
	 */
	InwardPaymentDetailVO getCreditPayment(String ReferenceNumber) throws ConstrtaintException;
	
	/**
	 * Update status check.
	 *
	 * @param inwardPaymentDetailVO the inward payment detail vo
	 * @throws Exception the exception
	 */
	void updateStatusCheck(InwardPaymentDetailVO inwardPaymentDetailVO) throws Exception;
	
	//CR1477 Orange Money Changes Starts, 20Feb18, Vijayan A
	/**
	 * get Wallet Transactions for Retry.
	 *
	 * @param fromDate, toDate, updatedTimeStamp, retryCount, statusList, countries as input
	 * @return List of InwardPaymentDetailVO
	 * @throws Exception the exception
	 */
	public List<InwardPaymentDetailVO> geWallettPaymentRetryList(Date fromDate,Date toDate, Timestamp updatedTimeStamp, int retryCount, 
			List<String> statusList, List<String> countries);
	
	public List<InwardPaymentDetailVO> getCreditWalletTransactions(InwardInquiryRequestVO inquiryRequest) throws Exception;

	
	public Double getTotalDebitWalletPayment(String strCustomerId, String strCountry, Calendar date);
	
	//CR1477 Orange Money Changes Starts, 20Feb18, Vijayan A
}
