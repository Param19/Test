package com.scb.channels.payments.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ApplicationMessageVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.payments.dao.BillerManagementDAO;

public class BillerManagementDAOImpl extends HibernateDaoSupport implements BillerManagementDAO {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(BillerManagementDAOImpl.class);
	
	@Override
	public List<BillerCategoryVO> getActiveBillerCategories(String ctryCd) {
		LOGGER.info("Inside BillerManagementDAOImpl getActiveBillerCategories method-Start"+ctryCd);
		List<BillerCategoryVO> categoryList=null;
		Session session=null;
			try{
				session=getHibernateTemplate().getSessionFactory().openSession();
			Criteria c=	session.createCriteria(BillerCategoryVO.class);
			c.add(Restrictions.eq("countryCode", ctryCd));
			c.add(Restrictions.eq("statusCode", CommonConstants.ACTIVE));
			c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			categoryList =c.list();
			}finally{
				if(session!=null&& session.isOpen()){
					session.close();
				}
			}
			
			return categoryList;
	}

	@Override
	public List<BillerVO> GetBillers(String Country, String categoryId) {
		LOGGER.info("Inside BillerManagementDAOImpl GetBillers method-Start :: Country: "+ Country +"CategoryId:"+ categoryId);
		List<BillerVO> list =null;
		Session session=null;
		try{
			session=getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria=	session.createCriteria(BillerVO.class);
		criteria.add(Restrictions.eq("countryCode", Country));
		BillerCategoryVO billerCategory= new BillerCategoryVO();
		billerCategory.setId(Integer.valueOf(categoryId));
		criteria.add(Restrictions.eq("categorytype",billerCategory));
		criteria.add(Restrictions.eq("statusCode", CommonConstants.ACTIVE));
		list=(List<BillerVO>)criteria.list();
		
		}finally{
			
			if(session!=null&& session.isOpen()){
				session.close();
			}
		}
		return list;
	}
	
	@Override
	public BillerVO GetBiller(String billerId, String country) {
		LOGGER.info("BillerManagementDAOImpl -- GetBiller -- Start ::: " + billerId);
		Session session=null;
		Object object = null;
		try{
			session = getHibernateTemplate().getSessionFactory().openSession();
			
			Criteria criteria = session.createCriteria(BillerVO.class);
			
			criteria.add(Restrictions.eq("countryCode", country));
			criteria.add(Restrictions.eq("billerUniqueId", billerId));
			criteria.add(Restrictions.eq("statusCode", CommonConstants.ACTIVE));
			
			object = criteria.uniqueResult();
			
		} catch (Exception exception) {
			LOGGER.error("Exception occurred while GetBillers :::: " + exception);
			exception.printStackTrace();
		} finally {
			if(session != null && session.isOpen()) {
				LOGGER.info("closing the session in GetBillers" + billerId);
				session.close();
			}
		}
		LOGGER.info("BillerManagementDAOImpl -- GetBiller -- End ::: " + billerId);
		return  object != null ? (BillerVO) object : null;
	}
	
	public Map<String,ApplicationMessageVO> getApplicationMessages(String country,String channel){
		LOGGER.info("BillerManagementDAOImpl -- getApplicationMessages -- ::: " + country+"----channel --- > "+channel);
		Session session=null;
		List<ApplicationMessageVO> persistentObjectList = null;
		
		Map<String,ApplicationMessageVO> dbMapObject = new HashMap<String, ApplicationMessageVO>();
		
		try{
			session = getHibernateTemplate().getSessionFactory().openSession();

			Criteria criteria = session
					.createCriteria(ApplicationMessageVO.class);
			criteria.add(Restrictions.eq("countryCode", country));
			criteria.add(Restrictions.eq("channel", channel));		
			criteria.add(Restrictions.isNull(CommonConstants.MODULE_NAME));
						
			persistentObjectList = criteria.list();
			
			for (ApplicationMessageVO appMsg: persistentObjectList) {
				dbMapObject.put(appMsg.getCompErrorCode(), appMsg);
			}
			
		} catch (Exception exception) {
			LOGGER.error("Exception occurred while getApplicationMessages :::: " + exception);
			exception.printStackTrace();
		} finally {
			if(session != null && session.isOpen()) {
				LOGGER.info("closing the session in getApplicationMessages");
				session.close();
			}
		}
		LOGGER.info("BillerManagementDAOImpl -- getApplicationMessages -- End ::: ");
		return dbMapObject;
	}
	
	public List<PayeeDetailVO> GetPayment(){
		
		Criteria criteria=	getSession().createCriteria(PayeeDetailVO.class);
		//PayeeDetailVO p= new PayeeDetailVO();
		//p.setPayeeID(12);
		
		//criteria.add(Restrictions.eq("payee", p));
		List<PayeeDetailVO> l = criteria.list();
		
		if (l != null && !l.isEmpty()) {
			for(PayeeDetailVO pay : l){
				
				 System.out.println(pay);
		}
		System.out.println(l.size());
		
		
	}
		return l;
	
	}

	@Override
	public List<NarrationVO> getNarrationConfig(String Country, String Channel) {
		List<NarrationVO> list = null;
		Session session=null;
		try{
		session=getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria=session.createCriteria(NarrationVO.class);
		criteria.add(Restrictions.eq("countryCode", Country));
		criteria.add(Restrictions.eq("channel",Channel));
		list=(List<NarrationVO>)criteria.list();
		
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		finally{
			if(session!=null&& session.isOpen()){
				session.close();
			}
		}
		return list;
	}
	// Added for Orange Money - start
	
	public List<BillerCategoryVO> getBillerCategories(String ctryCd, String categoryId) {
        LOGGER.info("Inside BillerManagementDAOImpl getBillerCategories method-Start" + ctryCd + "categoryId" + categoryId);
        List<BillerCategoryVO> categoryList = null;
        Session session = null;
        try {
               session = getHibernateTemplate().getSessionFactory().openSession();
               Criteria c = session.createCriteria(BillerCategoryVO.class);
               c.add(Restrictions.eq("countryCode", ctryCd));
               // category id refers Aggregator category id here.
               if (categoryId != null) {
                     c.add(Restrictions.eq("categoryId", categoryId));
               }

               c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
               categoryList = c.list();
        } finally {
               if (session != null && session.isOpen()) {
                     session.close();
               }
        }
        LOGGER.info("Inside BillerManagementDAOImpl getBillerCategories method-Ends");
        return categoryList;
 }
	
}
