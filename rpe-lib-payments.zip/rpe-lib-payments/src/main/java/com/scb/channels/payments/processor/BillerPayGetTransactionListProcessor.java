
/**
 * 
 */
package com.scb.channels.payments.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.PaymentTransactionService;

/**
 * @author 1470817
 *
 */
public class BillerPayGetTransactionListProcessor {
	
		
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerPayGetTransactionListProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */
	public List<BillerPayDetailsVO> process(PayloadDTO payloadDTO) {
		return null;
		/*LOGGER.info("Inside BillerPayGetTransactionListProcessor - process");
		BillerPayRequestVO billerPayRequestVO = null;
		List<BillerPayDetailsVO> list = null;
		try {
			billerPayRequestVO = new BillerPayRequestVO();
			list = paymentTransactionService.getPaymentTransactionInfoVOList(billerPayRequestVO);
		}catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
			LOGGER.error(e.getMessage());
		} 
		if(list!=null){
			return list;
		}else{
			return null;
		}*/
	}
	
	public List<BillerPayDetailsVO> getReversalFailureList(PayloadDTO payloadDTO) {
		LOGGER.info("Inside BillerPayGetTransactionListProcessor - getReversalFailureList()");
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		List<BillerPayDetailsVO> list = null;
		try {
			if(billerPayRequestVO == null)
			billerPayRequestVO = new BillerPayRequestVO();
			LOGGER.info("Before getting REVF transaction list");
			list = paymentTransactionService.getReversalFailurePaymentTransactionList(billerPayRequestVO);
			LOGGER.info("After  getting REVF transaction list size {}",new Object[]{list!=null?list.size():0});
		}catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		} 
		if(!CollectionUtils.isEmpty(list)){
			return list;
		}else{
			return null;
		}
	}
	
	
	public PayloadDTO payloadConverter(BillerPayDetailsVO billerPayDetailsVO) {
		PayloadDTO payloadDTO = new PayloadDTO();
		LOGGER.info("Inside BillerPayGetTransactionListProcessor - payloadConverter()");
		BillerPayRequestVO billerPayRequestVO = null;
		try {
			billerPayRequestVO = new BillerPayRequestVO();
			if(billerPayDetailsVO!=null){
				billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
				billerPayRequestVO.setUser(billerPayDetailsVO.getTransactionInfoVO().getUserVO());
				billerPayRequestVO.setClientVO(billerPayDetailsVO.getTransactionInfoVO().getClientVO());
				billerPayRequestVO.setMessageVO(billerPayDetailsVO.getTransactionInfoVO().getMessageVO());
				billerPayRequestVO.setServiceVO(billerPayDetailsVO.getTransactionInfoVO().getServiceVO());
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnId(billerPayDetailsVO.getPayRef());
				payloadDTO.setRequestVO(billerPayRequestVO);
			}
			
		}catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		} 
		return payloadDTO;
	}
	
	
	/*public List<BillerPayDetailsVO> getFirstLegTimeoutTransactionListWithAggregator(PayloadDTO payloadDTO) {
		LOGGER.info("Inside BillerPayGetTransactionListProcessor - getFirstLegTimeoutTransactionWithAggregator");
		BillerPayRequestVO billerPayRequestVO = null;
		List<BillerPayDetailsVO> list = null;
		try {
			billerPayRequestVO = new BillerPayRequestVO();
			list = paymentTransactionService.getPaymentStatusFirstLegTimeoutWithAggregator(billerPayRequestVO);
		LOGGER.info("Completed  - getFirstLegTimeoutTransactionWithAggregator");
		}catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
			LOGGER.error(e.getMessage());
		} 
		if(list!=null){
			return list;
		}else{
			return null;
		}
	}*/

	/**
	 * Gets the payment transaction service.
	 *
	 * @return the paymentTransactionService
	 */
	public PaymentTransactionService getPaymentTransactionService() {
		return paymentTransactionService;
	}

	/**
	 * Sets the payment transaction service.
	 *
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
	
	
	/*public void method1(BillerPayDetailsVO billerPayDetailsVO){
		System.out.println(billerPayDetailsVO);
	}*/
	


}
