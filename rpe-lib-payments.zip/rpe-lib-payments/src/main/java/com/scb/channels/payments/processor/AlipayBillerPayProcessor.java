package com.scb.channels.payments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentTransactionService;

public class AlipayBillerPayProcessor extends AbstractProcessor {
			
			/** The Constant LOGGER. */
			private static final Logger LOGGER = LoggerFactory.getLogger(AlipayBillerPayProcessor.class);
			
			/** The payment transaction service. */
			private PaymentTransactionService alipayPaymentTransactionService;

			/* (non-Javadoc)
			 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
			 */
			@Override
			protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

				LOGGER.info("Task in core banking Payment Processor :::Alipay: Start");
				
				BillerPayRequestVO billerPayRequestVO = null;
		 		BillerPayResponseVO billerPayResponseVO = null;
				try {
					if(bean != null && bean.getRequestVO() != null){
						billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
						LOGGER.info("Sending request to core banking system ::Alipay: " +
								billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
						
						billerPayResponseVO = alipayPaymentTransactionService.performBillPayment(billerPayRequestVO);
						LOGGER.info("Received response from core banking system :Alipay:: " +
								billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
					}
				}catch (Exception e) {
					LOGGER.info("Exception Occurred while sending request to core banking system ::Alipay:" +
							billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
					LOGGER.info("Exception :Alipay:: " + e);
					LOGGER.error("Exception ::Alipay.:: " + e);
					
					if (billerPayResponseVO == null) {
						billerPayResponseVO = new BillerPayResponseVO();
					}
					
					if(billerPayResponseVO.getBillerPayDetailsVO() == null) {
						billerPayResponseVO.setBillerPayDetailsVO(
								billerPayRequestVO.getBillerPayDetailsVO());
					}
					
					LOGGER.info("Setting Fail status for the payment" 
							+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
					billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
					billerPayResponseVO.setStatusDesc(e.getMessage());
					billerPayResponseVO.setErrorDesc(e.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._105.getCode());
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
					billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.COREBANK_PAY_FAILURE);
					
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
					
					if(e instanceof WebServiceException){
						LOGGER.info("Setting timeout for card auth reversal ::: " 
								+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
						LOGGER.error(e.getCause().toString());
						billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
						billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
						
						billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
						billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
						billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
					}
					
				} finally{
					
					if (billerPayResponseVO != null) {
						LOGGER.info("Setting header objects in response Alipay vo" 
								+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
						
						if(billerPayResponseVO.getHostResponseVO() != null) {
							for(HostResponseVO hostRes : billerPayRequestVO.getHostResponseVO()) {
								billerPayResponseVO.getHostResponseVO().add(hostRes);
							}
						}
						
						if(billerPayResponseVO.getBillerPayDetailsVO() != null && 
								billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
							LOGGER.info("Setting the aggregator response status details to host response list in alipay post transaction" + 
									billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
								billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
								billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
							
							HostResponseVO hostResponse = new HostResponseVO();
							hostResponse.setCode(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
							hostResponse.setDesc(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
							hostResponse.setHostName(billerPayResponseVO.getBillerPayDetailsVO().getHostName());
							
							billerPayRequestVO.getHostResponseVO().add(hostResponse);
						}
						
						billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
						billerPayResponseVO.setUser(billerPayRequestVO.getUser());
						billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
						billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
					}
					bean.setResponseVO(billerPayResponseVO);
				}
				LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() :Alipay:: " 
						+ billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus());
				LOGGER.info("Task in core banking Payment Processor :::Alipay: End");
				return bean;
			
			}

			public PaymentTransactionService getAlipayPaymentTransactionService() {
				return alipayPaymentTransactionService;
			}

			public void setAlipayPaymentTransactionService(
					PaymentTransactionService alipayPaymentTransactionService) {
				this.alipayPaymentTransactionService = alipayPaymentTransactionService;
			}
	
}
