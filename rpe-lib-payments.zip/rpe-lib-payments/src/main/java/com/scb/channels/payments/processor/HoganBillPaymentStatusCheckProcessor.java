package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.PaymentTransactionService;

public class HoganBillPaymentStatusCheckProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger logger = LoggerFactory.getLogger(HoganBillPaymentStatusCheckProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService alipayPaymentTransactionService;

	/**
	 * @param payloadDTO
	 * @return
	 */
	public PayloadDTO process(PayloadDTO payloadDTO) {
		logger.info("Inside HoganBillPaymentStatusCheckProcessor : starts");
		BillerPayRequestVO hoganBillerPayRequestVO = (BillerPayRequestVO)payloadDTO.getRequestVO();
		BillerPayResponseVO hoganBillerPayResponseVO = null;
		
		try {
			if(hoganBillerPayRequestVO != null){
				String requestCode = hoganBillerPayRequestVO.getBillerPayDetailsVO().getPayRef();
				logger.info("Before updating intermediate status ::::::: " + requestCode);
				//Sending request to EDMI
				try{
					logger.info("Before hitting edmi service");
					hoganBillerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnId(requestCode);
					hoganBillerPayResponseVO = new BillerPayResponseVO();
					hoganBillerPayResponseVO = alipayPaymentTransactionService.paymentStatusCheck(hoganBillerPayRequestVO);
					logger.info("After getting response from edmi service");
				}catch (Exception e) {
					logger.error("HoganBillPaymentStatusCheckProcessor :: Exception: ", e);
					hoganBillerPayResponseVO.setUser(hoganBillerPayRequestVO.getUser());
					hoganBillerPayResponseVO.setMessageVO(hoganBillerPayRequestVO.getMessageVO());
					hoganBillerPayResponseVO.setClientVO(hoganBillerPayRequestVO.getClientVO());
					hoganBillerPayResponseVO.setServiceVO(hoganBillerPayRequestVO.getServiceVO());
					hoganBillerPayResponseVO.setBillerPayDetailsVO(hoganBillerPayRequestVO.getBillerPayDetailsVO());
					
					hoganBillerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 		setTxnStatusCd(CommonConstants.FAIL);
				
					hoganBillerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 			setHostRespCd("-1");
					
					hoganBillerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 			setHostRespDesc(e.getMessage());
				}

				payloadDTO.setResponseVO(hoganBillerPayResponseVO);
			}else{
				logger.info("HoganBillPaymentStatusCheckProcessor: Request cannot be empty !");
			}
		}catch (Exception e) {
			logger.error("Exception occurred ::: ",e);
		}
		logger.info("Inside HoganBillPaymentStatusCheckProcessor : ends");
		return payloadDTO;
	}

	public PaymentTransactionService getAlipayPaymentTransactionService() {
		return alipayPaymentTransactionService;
	}

	public void setAlipayPaymentTransactionService(
			PaymentTransactionService alipayPaymentTransactionService) {
		this.alipayPaymentTransactionService = alipayPaymentTransactionService;
	}

}
