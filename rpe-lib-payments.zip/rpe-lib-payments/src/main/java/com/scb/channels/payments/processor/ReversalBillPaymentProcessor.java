/**
 * 
 */
package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PaymentTransactionService;


public class ReversalBillPaymentProcessor extends AbstractProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ReversalBillPaymentProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;

	/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */
	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

		BillerPayResponseVO billerPayResponseVO = null;
		BillerPayRequestVO billerPayRequestVO = null;
		try {
			billerPayRequestVO = bean.getRequestVO() != null ? 
					(BillerPayRequestVO)bean.getRequestVO() : new BillerPayRequestVO();
			
			if(bean.getResponseVO() != null) {
				billerPayResponseVO = (BillerPayResponseVO)bean.getResponseVO();
				billerPayRequestVO.setBillerPayDetailsVO(billerPayResponseVO.getBillerPayDetailsVO());
				billerPayRequestVO.setUser(billerPayResponseVO.getUser());
				billerPayRequestVO.setMessageVO(billerPayResponseVO.getMessageVO());
				billerPayRequestVO.setClientVO(billerPayResponseVO.getClientVO());
				billerPayRequestVO.setServiceVO(billerPayResponseVO.getServiceVO());
			}
			
			billerPayResponseVO = paymentTransactionService.reversalBillPayment(billerPayRequestVO);
			// To check whether the response object is empty or not
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setStatusDesc(ExceptionMessages._106.getMessage());
				billerPayResponseVO.setStatus(ExceptionMessages._106.getCode());
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
				billerPayRequestVO.setErrorDesc(ExceptionMessages._106.getMessage());
				billerPayRequestVO.setErrorCD(ExceptionMessages._106.getCode());
			}
          }catch (Exception e) {
        	  LOGGER.error("Exception occurred ::: ",e);
			LOGGER.error(e.getMessage());
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
			billerPayResponseVO.setStatusDesc(e.getMessage());
			billerPayRequestVO.setErrorDesc(e.getMessage());
			billerPayRequestVO.setErrorCD(ExceptionMessages._105.getCode());
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.REVERSAL_PAY_FAILURE);
		} finally{
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			} 
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			bean.setResponseVO(billerPayResponseVO);
		}
		return bean;
	
	}

	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}


}
