package com.scb.channels.payments.service;

import java.util.List;

import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PaymentDetailVO;

/**
 * The Interface PaymentTransactionService.
 */
public interface PaymentTransactionService {
	

	/**
	 * Save payment txn details.
	 *
	 * @param billPmtTxnDetailsVO the bill pmt txn details vo
	 */
	//void savePaymentTxnDetails(BillPmtTxnDetailsVO billPmtTxnDetailsVO);
	
	/**
	 * Perform bill payment in EBBS
	 *
	 * @param billerPayRequestV the biller pay request v
	 * @return the biller pay response vo
	 */
	BillerPayResponseVO performBillPayment(BillerPayRequestVO billerPayRequestV);
	
	/**
	 * Save payment txn.
	 *
	 * @param billerPayDetailsVO the biller pay details vo
	 */
	Long savePayment(BillerPayDetailsVO billerPayDetailsVO);
	
	/**
	 * Reverse the payment done in EBBS
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	BillerPayResponseVO reversalBillPayment(BillerPayRequestVO billerPayRequestVO) throws Exception;
	
	/**
	 * updates the payment record in the database
	 * 
	 * @param billerPayDetailsVO
	 */
	public void updatePaymentStatus(BillerPayDetailsVO billerPayDetailsVO);
	
	/**
	 * Inform the payment to the aggregator
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	public BillerPayRequestVO aggregatorPayment(BillerPayRequestVO billerPayRequestVO);
	
	/**
	 * paymentStatusCheck.
	 *
	 * @param BillerPayRequestVO the billerPayRequestVO
	 * @return the BillerPay Response VO
	 */
	public BillerPayResponseVO paymentStatusCheck(BillerPayRequestVO billerPayRequestVO);
	
	
	/**
	 * getReversalFailurePaymentTransactionList.
	 *
	 * @return the biller pay details vo
	 */
	List<BillerPayDetailsVO> getReversalFailurePaymentTransactionList(BillerPayRequestVO billerPayRequestVO);
	
	  
	public void updatePmtVersion(BillerPayDetailsVO billerPayDetailsVO);
	  
	  
	public void updateRequestVOString(BillerPayDetailsVO billerPayDetailsVO);
	
	public PaymentDetailVO getPaymentDetails(String referenceNumber);
	
	public List<BillerPayDetailsVO> getPaymentRetryTransactionList(BillerPayRequestVO billerPayRequestVO);
	
	public BillerPayDetailsVO populateDetailsForPayee(BillerPayDetailsVO billerPayDetails);
	
	public List<BillerPayDetailsVO> getInprocessPayments(BillerPayRequestVO billerPayRequestVO);
	
	public String getReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO);
	
	public String getCCReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO);
	
	/**
	 * @param billerPayDetails
	 * @return
	 */
	public BillerPayDetailsVO populateDetailsForPayeeCS(BillerPayDetailsVO billerPayDetails);
	
	/**
	 * @param billerPayDetailsVO
	 * @return
	 */
	Long savePaymentCS(BillerPayDetailsVO billerPayDetailsVO);
	
	/**
	 * @param billerPayRequestVO
	 */
	void saveOneTimePayee(BillerPayRequestVO billerPayRequestVO);
	
	/**
	 * Inform the payment to the aggregator
	 * 
	 * @param billerPayRequestVO
	 * @return
	 */
	public BillerPayRequestVO aggregatorPaymentCS(BillerPayRequestVO billerPayRequestVO);
}
