package com.scb.channels.qrpayments.processor;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRMerchantPanTypeVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.service.FieldValidationService;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.vo.FieldValidationVO;

public class QRPaymentValidationProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentValidationProcessor.class);

	private FieldValidationService fieldValidationService;	
	private ReferenceService referenceService;
	private boolean validatorFlag = false;	

	public PayloadDTO process(PayloadDTO bean) {
		LOGGER.info("Task of validating qrpayment request ::: Start");

		QRPaymentRequestVO qrPaymentRequestVO = null;
		QRPaymentResponseVO qrPaymentResponseVO = null;
		QRPaymentDetailVO qrPaymentDetailVO = null;
		ClientVO clientVO= null;

		String fieldName=CommonConstants.EMPTY;
		String defaultVal=CommonConstants.EMPTY;
		Object fieldValue=CommonConstants.EMPTY;
		boolean empty=false;

		String module=CommonConstants.MODULE;
		String status=CommonConstants.STATUS_ACTIVE;
		String baseObject=CommonConstants.QR_PAY_DTLS_VO;

		try{
			qrPaymentRequestVO = (QRPaymentRequestVO)bean.getRequestVO();
			clientVO=(ClientVO)qrPaymentRequestVO.getClientVO();

			if(qrPaymentRequestVO.getQrPaymentDetailVO() == null){
				LOGGER.info("QR Detail VO is NULL :::");
				qrPaymentDetailVO = new QRPaymentDetailVO();
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
				qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._201.getCode());
				qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._201.getMessage());
				qrPaymentRequestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			}else{
				
				qrPaymentDetailVO=qrPaymentRequestVO.getQrPaymentDetailVO();
				
				LOGGER.info("InDetailVO object");

				/**Validating fields START */

				List<FieldValidationVO> fieldValidationList = fieldValidationService.getfieldValidationList(module, status, baseObject, clientVO);

				if(fieldValidationList!=null && fieldValidationList.size()>0){
					for (FieldValidationVO fieldValidationVO : fieldValidationList) {						
						fieldName=(String)fieldValidationVO.getFieldName();
						defaultVal=(String)fieldValidationVO.getDefaultValue();
						empty=false;

						if(fieldName!=null && fieldName!=CommonConstants.EMPTY){
							fieldValue = PropertyUtils.getProperty(qrPaymentDetailVO,fieldName);

							if(fieldValue==null || fieldValue==CommonConstants.EMPTY){
								empty=true;
							}	
							if ( fieldValue instanceof List <?> ) {
								List<?> list = (List<?>)fieldValue ;
								if(list.size()<1){
									empty=true;
								}
							}
							if(empty){									
								LOGGER.info("QR "+ fieldName +" is Null");
								qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
								qrPaymentDetailVO.setHostResponseCode((String)fieldValidationVO.getErrorCode());
								qrPaymentDetailVO.setHostResponseDesc((String)fieldValidationVO.getErrorMsg());	
								validatorFlag = true;
								break;
							}
						}

						if(defaultVal!=null && defaultVal!=CommonConstants.EMPTY  && !defaultVal.equalsIgnoreCase((String)fieldValue)){	
							LOGGER.info("QR "+ fieldName +" is Invalid");
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode((String)fieldValidationVO.getDefaultErrorCode());
							qrPaymentDetailVO.setHostResponseDesc((String)fieldValidationVO.getDefaultErrorMsg());		
							validatorFlag = true;
							break;
						}

					}
				}

				/** QR txn Currency Code numeric validation **/
				if(!validatorFlag && qrPaymentDetailVO.getTxnCurrencyCode()!=null 
						&& (qrPaymentDetailVO.getTxnCurrencyCode().length()!=3 
						|| !qrPaymentDetailVO.getTxnCurrencyCode().matches(CommonConstants.QR_NUM_REGEX))){
					qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
					qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._612.getCode());
					qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._612.getMessage());	
					validatorFlag = true;
				}

				/** QR country iso code validation **/
				if(qrPaymentDetailVO.getCountryCode()!=null 
						&& qrPaymentDetailVO.getCountryCode()!=CommonConstants.EMPTY
						&& !qrPaymentDetailVO.getCountryCode().equals(CommonConstants.IN)){

					baseObject=CommonConstants.QR_COUNTRY_VALID;					
					List<FieldValidationVO> validIsoCountryList = fieldValidationService.getfieldValidationList(module, status, baseObject, clientVO);

					if(validIsoCountryList!=null && validIsoCountryList.size()>0){
						for (FieldValidationVO fieldValidationVO : validIsoCountryList) {						
							fieldName=(String)fieldValidationVO.getFieldName();
							fieldValue = PropertyUtils.getProperty(qrPaymentDetailVO,fieldName);
							if(!validatorFlag && fieldValue!=null && fieldValue!=CommonConstants.EMPTY){
								List<ISOCODESVO> isocodesvos = referenceService.getPrecisionCurrency(String.valueOf(fieldValue));
								if(isocodesvos==null || isocodesvos.size()<=0){
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode((String)fieldValidationVO.getErrorCode());
									qrPaymentDetailVO.setHostResponseDesc((String)fieldValidationVO.getErrorMsg());	
									validatorFlag = true;
									break;
								}
							}
						}
					}
				}

				/** QR cross currency validation **/
				if(!validatorFlag && qrPaymentDetailVO.getTransactionCurrency()!=null 
						&& qrPaymentDetailVO.getTransactionCurrency()!=CommonConstants.EMPTY
						&& qrPaymentDetailVO.getDebitAccCurrency()!=null 
						&& qrPaymentDetailVO.getDebitAccCurrency()!=CommonConstants.EMPTY 
						&& !qrPaymentDetailVO.getTransactionCurrency().equals(qrPaymentDetailVO.getDebitAccCurrency())){ 
					qrPaymentDetailVO.setCrossCurrency(true);

					if(qrPaymentDetailVO.getDebitAmount()==null){
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._601.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._601.getMessage());	
						validatorFlag = true;
					}

					if(!validatorFlag && qrPaymentDetailVO.getDebitAmtFxRate()==null){
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
						qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._602.getCode());
						qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._602.getMessage());	
						validatorFlag = true;
					}

					if(qrPaymentDetailVO.getSourceOfFund()!=null 
						&& qrPaymentDetailVO.getSourceOfFund()!=CommonConstants.EMPTY
						&& qrPaymentDetailVO.getSourceOfFund().equals(CommonConstants.CARD)){
					
						if(!validatorFlag && (qrPaymentDetailVO.getSettlementCurrency()==null 
								|| qrPaymentDetailVO.getSettlementCurrency()==CommonConstants.EMPTY)){
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._603.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._603.getMessage());	
							validatorFlag = true;
						}
	
						if(!validatorFlag && qrPaymentDetailVO.getSettlementAmount()==null){
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._604.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._604.getMessage());	
							validatorFlag = true;
						}
	
						if(!validatorFlag && qrPaymentDetailVO.getSettlementAmtFxRate()==null){
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._605.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._605.getMessage());	
							validatorFlag = true;
						}		
					
					}
				}

				/**Validating fields END */

				if( !validatorFlag && qrPaymentDetailVO.getMerchantPanList() != null){

					List<QRMerchantPanTypeVO> merchantPanList = qrPaymentDetailVO.getMerchantPanList();	
					LOGGER.info("QR Merchant PAN Size :::"+merchantPanList.size());
					LOGGER.info("validatorflag::::"+validatorFlag);
					
					if(((qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)) && !qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA))
							|| (qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)) && !qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)){
							LOGGER.info("Failed Due to CardType and CardNumber are not Matching");
							qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
							qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
							qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
							validatorFlag = true;
					}

					if(qrPaymentDetailVO.getCard_type()!=null && qrPaymentDetailVO.getCardNumber()!= null && !validatorFlag)
					{
						LOGGER.info("Before the for loop check");
						HashMap<String, String> merchantMap = new HashMap<String,String>();
						for(QRMerchantPanTypeVO qrMerchantPanTypeVO : merchantPanList){
							LOGGER.info("Inside the for loop check");
							LOGGER.info("REF ID:::::"+qrMerchantPanTypeVO.getRefId() +"::REF VALUE::::"+ qrMerchantPanTypeVO.getRefValue());
							if(qrMerchantPanTypeVO.getRefId() == null || qrMerchantPanTypeVO.getRefValue()==null||
									qrMerchantPanTypeVO.getRefId().equals("") || qrMerchantPanTypeVO.getRefValue().equals(""))
							{
								LOGGER.info("EITHER OF REF ID & REF VALUE OR BOTH NOT PRESENT");
								qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
								qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._235.getCode());
								qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._235.getMessage());
								validatorFlag = true;
								break;
							}/*else if((CommonConstants.VISA.equalsIgnoreCase(qrPaymentDetailVO.getCard_type()))&& (CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))){
								if(!((qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)
										&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)))){
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
									qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
									validatorFlag = true;
									break;
								}
							}else if((CommonConstants.MASTER.equalsIgnoreCase(qrPaymentDetailVO.getCard_type()))&&(CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))){
								if(!((qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0) && qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)
										&& qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.MASTER)))){
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
									qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
									validatorFlag = true;
									break;
								}
							}else{
								qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
								qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
								qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
								validatorFlag = true;
								break;
							}*/
							if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0) && (CommonConstants.VISA_MERCHANT_02.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.VISA_MERCHANT_03.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))
									&& !qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.VISA_INDICATOR,0)){						
									LOGGER.info("Something Wrong with VISA Network and Merchant PAN");
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
									qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
									validatorFlag = true;
									break;
							}
							if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0) && (CommonConstants.MASTER_MERCHANT_04.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()) || CommonConstants.MASTER_MERCHANT_05.equalsIgnoreCase(qrMerchantPanTypeVO.getRefId()))
									&& !qrMerchantPanTypeVO.getRefValue().startsWith(CommonConstants.MASTER_INDICATOR,0)){						
									LOGGER.info("Something Wrong with MASTER Network and Merchant PAN");
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._207.getCode());
									qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._207.getMessage());
									validatorFlag = true;
									break;
								}
							merchantMap.put(qrMerchantPanTypeVO.getRefId(), qrMerchantPanTypeVO.getRefValue());
						}
						if(!validatorFlag){
							String visaMerchantPan = merchantMap!= null && merchantMap.get(CommonConstants.VISA_MERCHANT_02) != null ? merchantMap.get(CommonConstants.VISA_MERCHANT_02) : merchantMap.get(CommonConstants.VISA_MERCHANT_03) ;
							String masterMerchantPan = merchantMap!= null && merchantMap.get(CommonConstants.MASTER_MERCHANT_04) != null  ? merchantMap.get(CommonConstants.MASTER_MERCHANT_04) : merchantMap.get(CommonConstants.MASTER_MERCHANT_05) ;
							LOGGER.info("Visa Merchant Pan : "+visaMerchantPan);
							LOGGER.info("Master Merchant Pan : "+masterMerchantPan);
							if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.VISA_INDICATOR,0)){
								if(visaMerchantPan == null){
									LOGGER.info("VISA merchant is Null");
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._613.getCode());
									qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._613.getMessage());
									validatorFlag = true;
								}
							}
							if(qrPaymentDetailVO.getCardNumber().startsWith(CommonConstants.MASTER_INDICATOR,0)){
								if(masterMerchantPan == null){
									LOGGER.info("Master Merchant is Null");
									qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
									qrPaymentDetailVO.setHostResponseCode(ExceptionMessages._613.getCode());
									qrPaymentDetailVO.setHostResponseDesc(ExceptionMessages._613.getMessage());
									validatorFlag = true;
								}
							}
						}
					}
				}
			}

			if(!validatorFlag){
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.SUCCESS);
			}else{
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
				qrPaymentDetailVO.setHost_system(CommonConstants.SOURCE_SYSTEM);
			}


		}catch(Exception e){
			LOGGER.error("Inside QRPaymentValidationProcessor Exception Block",e);
			e.printStackTrace();
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.FAIL);
			qrPaymentDetailVO.setHost_system(CommonConstants.SOURCE_SYSTEM);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());

		}finally{

			LOGGER.info("Inside the finally block of QRValidatorProcessor :::: ");
			if(qrPaymentDetailVO.getTxnActStatus() != null && CommonConstants.FAIL.equalsIgnoreCase(qrPaymentDetailVO.getTxnActStatus())){

				LOGGER.info("Invalid Request :::");	
				if(qrPaymentResponseVO == null) {
					qrPaymentResponseVO = new QRPaymentResponseVO();
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
				}	

				HostResponseVO hostResponse = new HostResponseVO();
				hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
				hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
				hostResponse.setHostName(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_system());	
				qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
				LOGGER.info("Inside the finally block of QRValidatorProcessor :::: ");

				qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
				qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
				qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
				qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
				qrPaymentResponseVO.getHostResponseVO().add(hostResponse);
			}
			bean.setResponseVO(qrPaymentResponseVO);
		}

		validatorFlag = false;
		return bean;
	}

	public FieldValidationService getFieldValidationService() {
		return fieldValidationService;
	}
	public void setFieldValidationService(
			FieldValidationService fieldValidationService) {
		this.fieldValidationService = fieldValidationService;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}
	
}