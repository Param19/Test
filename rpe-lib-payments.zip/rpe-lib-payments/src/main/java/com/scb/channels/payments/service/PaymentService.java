package com.scb.channels.payments.service;

import java.util.List;

import com.scb.channels.base.vo.CustomerPaymentAmountRequestVO;
import com.scb.channels.base.vo.CustomerPaymentAmountResponseVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;


public interface PaymentService {
	
	/**
	 * perfom get the Customers Total Payment Amount on that day based on SUBMITTED & SUCCESS transaction status.
	 *
	 * @param CustomerTotalPaymentAmountRequestVO the Customers Total Payment Amount request vo
	 * @return the Customers Total Payment Amount response vo
	 */		
	
	CustomerPaymentAmountResponseVO getCustomerOverallPaymentAmount(CustomerPaymentAmountRequestVO amountRequest);
	
	public List<PaymentDetailVO> getCustPaymentHistoryById(PaymentHistoryRequestVO paymentyHistoryRequestVO);


	


}
