/**
 * 
 */
package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PayeeManagementService;

/**
 * The Class DeletePayeeProcessor.
 * 
 * @author 1521723
 */
public class DeletePayeeProcessor  {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(DeletePayeeProcessor.class);

	private PayeeManagementService payeeService;

	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/** The payment transaction service. */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang
	 * .Object)
	 */

	public PayloadDTO process(PayloadDTO bean) throws BusinessException {
		LOGGER.info("DeletePayeeProcessor :: doTasks :: START ");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			
			if(billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null){
				
				if(billerPayRequestVO.getBillerPayDetailsVO().getId() == null){
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					
					billerPayResponseVO.setErrorCD(Messages._313.getCode());
					billerPayResponseVO.setErrorDesc(Messages._313.getMessage());
					LOGGER.info("Payee Id is ---blank ----NEW----------------------");
				}
				else {billerPayResponseVO = payeeService.deletePayee(billerPayRequestVO);
				}
			}
		} catch (Exception exception) {
			//LOGGER.info("DeletePayeeProcessor :: doTasks :: Exception" + exception);
			LOGGER.error("DeletePayeeProcessor :: doTasks :: Exception" , exception);
		}
		bean.setResponseVO(billerPayResponseVO);
		LOGGER.info("DeletePayeeProcessor :: doTasks :: END ");
		return bean;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang
	 * .Object)
	 */

	public PayloadDTO processAlipay(PayloadDTO bean) throws BusinessException {
		LOGGER.info("DeletePayeeProcessor :: doTasks :: START ");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
			if(billerPayRequestVO.getUser().getCustomerId() != null && billerPayRequestVO.getUser().getCustomerType() !=null){
				billerPayRequestVO.getUser().setCustomerId(billerPayRequestVO.getUser().getCustomerType()+billerPayRequestVO.getUser().getCustomerId() );
			}
			
			if(billerPayRequestVO != null && billerPayRequestVO.getBillerPayDetailsVO() != null){
				
				if(billerPayRequestVO.getBillerPayDetailsVO().getId() == null){
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					
					billerPayResponseVO.setErrorCD(Messages._313.getCode());
					billerPayResponseVO.setErrorDesc(Messages._313.getMessage());
					LOGGER.info("Payee Id is ---blank ----NEW----------------------");
				}else if(billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo() == null){
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					
					billerPayResponseVO.setErrorCD(Messages._315.getCode());
					billerPayResponseVO.setErrorDesc(Messages._315.getMessage());
					LOGGER.info("Payee Id is ---blank ----NEW----------------------");
				}
				else billerPayResponseVO = payeeService.deletePayee(billerPayRequestVO);
			}
		} catch (Exception exception) {
			//LOGGER.info("DeletePayeeProcessor :: doTasks :: Exception" + exception.getMessage());
			LOGGER.error("DeletePayeeProcessor :: doTasks :: Exception" ,exception);
		}
		bean.setResponseVO(billerPayResponseVO);
		LOGGER.info("DeletePayeeProcessor :: doTasks :: END ");
		return bean;
	}
	
	//Added for Orange Money - start
	public PayloadDTO processWallet(PayloadDTO bean) throws BusinessException {
		LOGGER.info("DeletePayeeProcessor :: processWallet :: START ");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
            billerPayResponseVO = payeeService.deleteWalletPayee(billerPayRequestVO);
			}
		 catch (Exception exception) {
	        //exception.printStackTrace();
			//LOGGER.info("DeletePayeeProcessor :: processWallet :: Exception" + exception.getMessage());
			LOGGER.error("DeletePayeeProcessor :: processWallet :: Exception" ,exception);
		}
		bean.setResponseVO(billerPayResponseVO);
		LOGGER.info("DeletePayeeProcessor :: processWallet :: END ");
		return bean;
	}
	
	//Added for Orange Money - end
}
