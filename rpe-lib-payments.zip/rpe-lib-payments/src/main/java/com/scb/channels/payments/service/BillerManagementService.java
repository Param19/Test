package com.scb.channels.payments.service;

import java.util.List;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerVO;



/**
 * @author 1460693
 * Interface for Biller management 
 */
public interface BillerManagementService {
	
	
	
	/**
	 * returns the List of the Biller categories.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the biller pay response vo
	 * 
	 */
	
	public  BillerPayResponseVO getBillerCategories(BillerPayRequestVO billerPayRequestVO);
		
	

	/**
	 * returns the List of the Biller names.
	 *
	 * @param billerPayRequestVO the biller pay request vo
	 * @return the biller pay response vo
	 * 
	 */
	public BillerPayResponseVO getBillerNames(BillerPayRequestVO billerPayRequestVO);
	public List<BillerVO> getBillerList(BillerPayRequestVO billerPayRequestVO);
		

	public BillerPayResponseVO getWalletBillerNames(BillerPayRequestVO billerPayRequestVO);
}
