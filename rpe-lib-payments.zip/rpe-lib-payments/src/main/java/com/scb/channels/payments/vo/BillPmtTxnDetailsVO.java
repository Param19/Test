package com.scb.channels.payments.vo;

import java.util.Date;

/**
 * The Class BillPmtTxnDetailsVO.
 */
public class BillPmtTxnDetailsVO {
	
	/** The id. */
	private int id;
	
	/** The txn id. */
	private String txnId;
	
	/** The txn ref no. */
	private String  txnRefNo;
	
	/** The consumer key. */
	private String consumerKey;
	
	/** The consumer value. */
	private String consumerValue;
	
	/** The dt created. */
	private Date dtCreated;
	
	/** The created by. */
	private String createdBy;
	
	/** The dt upd. */
	private Date dtUpd;
	
	/** The upd by. */
	private String updBy;
	
	/** The version. */
	private int version;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the txn id.
	 *
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}

	/**
	 * Sets the txn id.
	 *
	 * @param txnId the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	/**
	 * Gets the consumer key.
	 *
	 * @return the consumerKey
	 */
	public String getConsumerKey() {
		return consumerKey;
	}

	/**
	 * Sets the consumer key.
	 *
	 * @param consumerKey the consumerKey to set
	 */
	public void setConsumerKey(String consumerKey) {
		this.consumerKey = consumerKey;
	}

	/**
	 * Gets the consumer value.
	 *
	 * @return the consumerValue
	 */
	public String getConsumerValue() {
		return consumerValue;
	}

	/**
	 * Sets the consumer value.
	 *
	 * @param consumerValue the consumerValue to set
	 */
	public void setConsumerValue(String consumerValue) {
		this.consumerValue = consumerValue;
	}

	/**
	 * Gets the dt created.
	 *
	 * @return the dtCreated
	 */
	public Date getDtCreated() {
		return dtCreated;
	}

	/**
	 * Sets the dt created.
	 *
	 * @param dtCreated the dtCreated to set
	 */
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	/**
	 * Gets the created by.
	 *
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the dt upd.
	 *
	 * @return the dtUpd
	 */
	public Date getDtUpd() {
		return dtUpd;
	}

	/**
	 * Sets the dt upd.
	 *
	 * @param dtUpd the dtUpd to set
	 */
	public void setDtUpd(Date dtUpd) {
		this.dtUpd = dtUpd;
	}

	/**
	 * Gets the upd by.
	 *
	 * @return the updBy
	 */
	public String getUpdBy() {
		return updBy;
	}

	/**
	 * Sets the upd by.
	 *
	 * @param updBy the updBy to set
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * Gets the txn ref no.
	 *
	 * @return the txnRefNo
	 */
	public String getTxnRefNo() {
		return txnRefNo;
	}

	/**
	 * Sets the txn ref no.
	 *
	 * @param txnRefNo the txnRefNo to set
	 */
	public void setTxnRefNo(String txnRefNo) {
		this.txnRefNo = txnRefNo;
	}

}
