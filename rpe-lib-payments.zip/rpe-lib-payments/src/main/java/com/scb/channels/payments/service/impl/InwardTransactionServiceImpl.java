package com.scb.channels.payments.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.ws.WebServiceException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.v6.transaction.ContraAccountNarration;
import com.sc.corebanking.v6.transaction.CreditNarration;
import com.sc.corebanking.v6.transaction.PostTransactionReq;
import com.sc.corebanking.v6.transaction.PostTransactionReqPayload;
import com.sc.corebanking.v6.transaction.Transaction;
import com.sc.corebanking.v6.transaction.TransactionInfo;
import com.sc.corebanking.v6.transaction.TransactionReference;
import com.sc.corebanking.v6.transaction.TransactionsPosting;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.GetTransactionReq;
import com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.GetTransactionRes;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransaction;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.TagsType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.HostResponseTypeVO;
import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardInquiryResponseVO;
import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.StatusTypeVO;
import com.scb.channels.common.helper.NarrationHelper;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.processor.ConstrtaintException;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.mapper.helper.InwardMappingHelper;
import com.scb.channels.payments.dao.InwardTransactionDAO;
import com.scb.channels.payments.service.CacheManagementService;
import com.scb.channels.payments.service.InwardTransactionService;
import com.scb.channels.payments.service.PaymentCommonService;

/**
 * The Class InwardTransactionServiceImpl.
 *
 * @author 1493439
 */
public class InwardTransactionServiceImpl implements InwardTransactionService {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(InwardTransactionServiceImpl.class);

	/** The inward transaction dao. */
	private InwardTransactionDAO inwardTransactionDao;
	
	/** The payment common service. */
	private PaymentCommonService paymentCommonService;
	
	/** The transaction port type. */
	private TransactionPortType transactionPortType;
	
	/** The transaction port type. */
	private com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.TransactionPortType transactionPortTypeStatus;
	
	/** The cache service. */
	private CacheManagementService cacheService;
	
	/** The data bean. */
	private DataBean dataBean;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.InwardTransactionService#validateCreditHistoryRequest(com.scb.channels.base.vo.PayloadDTO)
	 */
	public PayloadDTO validateCreditHistoryRequest(PayloadDTO payload) throws Exception {
		LOGGER.info("InwardPaymentRequestVO validateCreditHistoryRequest start !!!!! ");
		
		boolean valid = false;
		
		InwardInquiryRequestVO request = (payload != null && payload.getRequestVO() != null) ? 
				(InwardInquiryRequestVO) payload.getRequestVO() : new InwardInquiryRequestVO();
				
		if(request.getReferenceNumber() != null){
			LOGGER.info("From date ::: " + request.getFromDate() 
					+ " ::: To date ::: " + request.getToDate());
			
			if(request.getClientInfoVO() != null || 
					request.getClientInfoVO().getCountry() != null ){
				valid = true;
			} else {
				LOGGER.info("Country Code check failed ::: " + request.getReferenceNumber());
			}
			
			if(valid && (request.getFromDate() != null || request.getToDate() != null)) {

				SimpleDateFormat dateFormat = new SimpleDateFormat(CommonConstants.HISTORY_DATE_FORMAT);
				
				Calendar currentDate = Calendar.getInstance();
				currentDate.setTime(DateUtils.getCurrentDate());
				
				Date currentDateFormat=dateFormat.parse(dateFormat.format(currentDate.getTime()));
				Calendar fromDate = Calendar.getInstance();
				fromDate.setTime(request.getFromDate());
				
				Date fromDateFormat = dateFormat.parse(dateFormat.format(fromDate.getTime()));
				
				Calendar toDate = Calendar.getInstance();
				toDate.setTime(request.getToDate());
				
				Date toDateFormat = dateFormat.parse(dateFormat.format(toDate.getTime()));
				
				if(fromDateFormat.compareTo(currentDateFormat) < 0 
					&& toDateFormat.compareTo(currentDateFormat) < 0
					&& fromDateFormat.compareTo(toDateFormat) < 0) {
					
					LOGGER.info("Date Validation Complete ::: " + request.getReferenceNumber());
					valid = true;
				} else {
					LOGGER.info("Date Validation Failed ::: " + request.getReferenceNumber());
				}
			} else {
				LOGGER.info("No from / to date ::: " + request.getReferenceNumber());
			}
		}

		InwardInquiryResponseVO response = (payload != null && payload.getResponseVO() != null) ? 
				(InwardInquiryResponseVO) payload.getResponseVO() : new InwardInquiryResponseVO();
		
		if (!valid) {
			LOGGER.info("Validation Failure ::: " + request.getReferenceNumber());
			StatusTypeVO statusTypeVO = new StatusTypeVO();
			statusTypeVO.setStatusCode(ExceptionMessages._125.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._125.getMessage());
			statusTypeVO.setReferenceNumber(request.getReferenceNumber());
			response.setStatusTypeVO(statusTypeVO);
		} else {
			LOGGER.info("Validation Success ::: " + request.getReferenceNumber());
			response.setStatus(CommonConstants._00000);
			response.setStatusDesc(CommonConstants.SUCCESS);
		}
		
		LOGGER.info("Setting response :: " + request.getReferenceNumber());
		payload.setResponseVO(response);
		
		LOGGER.info("InwardPaymentRequestVO validateCreditHistoryRequest end !!!!! " 
				+ request.getReferenceNumber());
		return payload;
	}
	/*1570965*/
	public PayloadDTO getWalletCreditHistory(PayloadDTO payload) throws Exception {
		LOGGER.info("InwardPaymentRequestVO getWalletCreditHistory Start !!!!! ");
		String referenceNumber = "";
		InwardInquiryRequestVO request = (payload != null && payload.getRequestVO() != null) ? 
				(InwardInquiryRequestVO) payload.getRequestVO() : new InwardInquiryRequestVO();
		
		InwardInquiryResponseVO response = (payload != null && payload.getResponseVO() != null) ? 
				(InwardInquiryResponseVO) payload.getResponseVO() : new InwardInquiryResponseVO();
					if(request.getReferenceNumber() != null){
			referenceNumber = request.getReferenceNumber();
			LOGGER.info("InwardPaymentRequestVO getCreditHistory Reference Numner !!!!! "+referenceNumber);
			LOGGER.info("From date for history ::: " + request.getFromDate() 
					+ " ::: To date for history ::: " + request.getToDate());
			
			if(request.getFromDate() != null || request.getToDate() != null) {
				List<InwardPaymentDetailVO> inwardPayments = 
					inwardTransactionDao.getCreditWalletTransactions(request);
				
				if(inwardPayments!=null && !inwardPayments.isEmpty()){
					LOGGER.info("InwardPaymentRequestVO getCreditHistory SUCCESS status set !!!!! "+referenceNumber);
					
					for(InwardPaymentDetailVO inwardPaymentDetailVO:inwardPayments){
						if(inwardPaymentDetailVO.getPaymentStatus()!=null) {
							LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
							if(inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_SUCCESS)){
								LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() if !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
								inwardPaymentDetailVO.setPaymentStatus(CommonConstants.SUCCESS);
							} else if(inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_TIMEOUT) 
									|| inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.SAVE_SUCCESS) 
									|| inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.VALIDSUCC)
									|| inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.ACC_SUCCESS)){
								
								LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() else if !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
								inwardPaymentDetailVO.setPaymentStatus(CommonConstants.SUBMITTED);
							} else {
								LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() else !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
								inwardPaymentDetailVO.setPaymentStatus(CommonConstants.FAILURE);
							}
							if(inwardPaymentDetailVO.getPayee() != null && inwardPaymentDetailVO.getPayee().getConsumerNumber() != null) {
								inwardPaymentDetailVO.setWalletID(inwardPaymentDetailVO.getPayee().getConsumerNumber());
							}
						}
					}
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(CommonConstants.THREE_ZEROES);
					statusTypeVO.setStatusDesc(CommonConstants.SUCCESS);
					statusTypeVO.setReferenceNumber(referenceNumber);
					response.setStatusTypeVO(statusTypeVO);
					response.setInwardPayments(inwardPayments);
				} else {
					LOGGER.info("InwardPaymentRequestVO getCreditHistory FAILURE status set !!!!! "+referenceNumber);
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(ExceptionMessages._249.getCode());
					statusTypeVO.setStatusDesc(ExceptionMessages._249.getMessage());
					statusTypeVO.setReferenceNumber(referenceNumber);
					response.setStatusTypeVO(statusTypeVO);
				}
			}
		}
		
		payload.setResponseVO(response);
		LOGGER.info("InwardPaymentRequestVO getCreditHistory end !!!!! " + request.getReferenceNumber());
		return payload;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.InwardTransactionService#getCreditHistory(com.scb.channels.base.vo.PayloadDTO)
	 */
	public PayloadDTO getCreditHistory(PayloadDTO payload) throws Exception {
		LOGGER.info("InwardPaymentRequestVO getCreditHistory Start !!!!! ");
		String referenceNumber = "";
		InwardInquiryRequestVO request = (payload != null && payload.getRequestVO() != null) ? 
				(InwardInquiryRequestVO) payload.getRequestVO() : new InwardInquiryRequestVO();
		
		InwardInquiryResponseVO response = (payload != null && payload.getResponseVO() != null) ? 
				(InwardInquiryResponseVO) payload.getResponseVO() : new InwardInquiryResponseVO();
						
		if(request.getReferenceNumber() != null){
			referenceNumber = request.getReferenceNumber();
			LOGGER.info("InwardPaymentRequestVO getCreditHistory Reference Numner !!!!! "+referenceNumber);
			LOGGER.info("From date for history ::: " + request.getFromDate() 
					+ " ::: To date for history ::: " + request.getToDate());
			
			if(request.getFromDate() != null || request.getToDate() != null) {
				List<InwardPaymentDetailVO> inwardPayments = 
					inwardTransactionDao.getCreditTransactions(request);
				
				if(inwardPayments!=null && !inwardPayments.isEmpty()){
					LOGGER.info("InwardPaymentRequestVO getCreditHistory SUCCESS status set !!!!! "+referenceNumber);
					
					for(InwardPaymentDetailVO inwardPaymentDetailVO:inwardPayments){
						if(inwardPaymentDetailVO.getPaymentStatus()!=null) {
							LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
							if(inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_SUCCESS)){
								LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() if !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
								inwardPaymentDetailVO.setPaymentStatus(CommonConstants.SUCCESS);
							} else if(inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_TIMEOUT) 
									|| inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.SAVE_SUCCESS) 
									|| inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.VALIDSUCC)
									|| inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.ACC_SUCCESS)){
								
								LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() else if !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
								inwardPaymentDetailVO.setPaymentStatus(CommonConstants.SUBMITTED);
							} else {
								LOGGER.info("InwardPaymentRequestVO getCreditHistory inwardPaymentDetailVO.getPaymentStatus() else !!!!! "+referenceNumber+" Payment Status::: "+inwardPaymentDetailVO.getPaymentStatus());
								inwardPaymentDetailVO.setPaymentStatus(CommonConstants.FAILURE);
							}
						}
					}
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(CommonConstants.THREE_ZEROES);
					statusTypeVO.setStatusDesc(CommonConstants.SUCCESS);
					statusTypeVO.setReferenceNumber(referenceNumber);
					response.setStatusTypeVO(statusTypeVO);
					response.setInwardPayments(inwardPayments);
				} else {
					LOGGER.info("InwardPaymentRequestVO getCreditHistory FAILURE status set !!!!! "+referenceNumber);
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(ExceptionMessages._152.getCode());
					statusTypeVO.setStatusDesc(ExceptionMessages._152.getMessage());
					statusTypeVO.setReferenceNumber(referenceNumber);
					response.setStatusTypeVO(statusTypeVO);
				}
			}
		}
		
		payload.setResponseVO(response);
		LOGGER.info("InwardPaymentRequestVO getCreditHistory end !!!!! " + request.getReferenceNumber());
		return payload;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.InwardTransactionService#performInwardBillPayment(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public PayloadDTO performInwardBillPayment(PayloadDTO payloadDTO) {

	try {
		
			LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: start");
			InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
			inwardPaymentRequestVO.setServiceName(CommonConstants.POST_TRANSACTION);
			BillerCatgegoryReference  billerCatgegoryReference = paymentCommonService.getBillerCategoryReference(inwardPaymentRequestVO.getClientInfoVO().getServiceProvider(), null, inwardPaymentRequestVO.getClientInfoVO().getCountry());
			/*if(billerCatgegoryReference != null){
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: setting billerCatgegoryReference:: "+inwardPaymentRequestVO.getReferenceNumber());
				transactionInfo.setTransactionType(billerCatgegoryReference.getPaymentTransactionType());
			} */

			LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: billerCatgegoryReference:: "+billerCatgegoryReference);
			PostTransactionResponse postResponse = null;
			
			InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
			
			if(billerCatgegoryReference != null && billerCatgegoryReference.getFetchType()!= null && billerCatgegoryReference.getFetchType().equalsIgnoreCase(CommonConstants.INWARD_FETCH_TYPE)){
				
				PostTransaction postTransaction = new PostTransaction();
				PostTransactionReq postTransactionReq = new PostTransactionReq();
				PostTransactionReqPayload postTransactionReqPayload = new PostTransactionReqPayload();
				Transaction transaction = new Transaction();
				postTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
				postTransactionReqPayload.setPayloadVersion(CommonConstants.TWO_DECIMAL);
				
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: referenceNumber:: "+inwardPaymentRequestVO.getReferenceNumber());
				TransactionInfo transactionInfo = new TransactionInfo();
				transactionInfo.setMessageSubType(CommonConstants.POST_SINGLE_LEG);
				transactionInfo.setUniqueReferenceIdentifier(inwardPaymentRequestVO.getHostReferenceNumber());
				transactionInfo.setForcePostFlag(CommonConstants.YES);
				transactionInfo.setApproveInSufficientFundsFlag(CommonConstants.YES);
				transactionInfo.setTransactionBranch("");
				//getGregorianCalendar().toString() 2017-05-06T12:35:51.555+03:00 2017-02-02T01:24:46.125
				transactionInfo.setTransactionPostingDate(BillpaymentMappingHelper.getGregorianCalendar().toString());
				//transactionInfo.setTransactionPostingDate("2017-02-02T01:24:46.125");
				transactionInfo.setSourceSystemName(CommonConstants.I_BANKING);
				transactionInfo.setSuspectedTransactionFlag(CommonConstants.TRUE);
				
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: setting billerCatgegoryReference:: "+inwardPaymentRequestVO.getReferenceNumber());
				transactionInfo.setTransactionType(billerCatgegoryReference.getPaymentTransactionType());
				
				transactionInfo.setTransactionCurrencyCode(inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency());
				List<TransactionsPosting> transactionsPostings = transactionInfo.getTransactionsPosting();
				postTransactionReqPayload.setPostTransactionReq(transaction);
				//List<DebitNarration> debitNarrations = transactionInfo.getDebitNarration();
				List<ContraAccountNarration>  debitNarrations = transactionInfo.getContraAccountNarration();
				List<CreditNarration> creditNarrations = transactionInfo.getCreditNarration();
				
				inwardPaymentRequestVO = setNarration(inwardPaymentRequestVO);
				List<NarrationVO> narrationVOs = inwardPaymentRequestVO.getDebitNarrationVOs();
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl Debit Narrations:::"+narrationVOs+" ::ReferenceNumber:: "+inwardPaymentRequestVO.getReferenceNumber());
				
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl inwardPaymentRequestVO:::"+inwardPaymentRequestVO);
				if(narrationVOs != null){
					for(NarrationVO narrationVO: narrationVOs){
						ContraAccountNarration debitNarration = new ContraAccountNarration();
						debitNarration.setNarration(narrationVO.getNarration());
						debitNarrations.add(debitNarration);
						/*DebitNarration debitNarration = new DebitNarration();
						debitNarration.setDebitNarration(narrationVO.getNarration());
						debitNarrations.add(debitNarration);*/
						LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: Debit NarrationVO:: "+narrationVO);
					}
				}
				
				List<NarrationVO> cnarrationVOs = inwardPaymentRequestVO.getCreditNarrationVOs();
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: cnarrationVOs "+cnarrationVOs);
				if(cnarrationVOs != null){
					for(NarrationVO narrationVO: cnarrationVOs){
						CreditNarration creditNarration = new CreditNarration();
						creditNarration.setCreditNarration(narrationVO.getNarration());
						creditNarrations.add(creditNarration);
						LOGGER.info("performInwardBillPayment::: TransactionServiceImpl ::: credit narrationVO"+narrationVO);
					}
				}
				
				LOGGER.info("performInwardBillPayment::: TransactionServiceImpl :::"+inwardPaymentRequestVO.getReferenceNumber());
				TransactionsPosting transactionsPosting = new TransactionsPosting();
				transactionsPosting.setAccountNumber(inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber());
				transactionsPosting.setAccountCurrencyCode(inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency());
				transactionsPosting.setTransactionAmount(inwardPaymentRequestVO.getInwardTransactionInfoVO().getAmount());
				transactionsPosting.setCreditDebitIndicator(StringUtils.trim(CommonConstants.CREDIT));
				TransactionReference transactionReference = new TransactionReference();
				transactionsPostings.add(transactionsPosting);
				//Commented by 1508384 for OM
				//transactionReference.setReferenceNumber(inwardPaymentRequestVO.getHostReferenceNumber());
				postTransactionReqPayload.setPostTransactionReq(transaction);
				transactionsPosting.setTransactionReference(transactionReference);
				transaction.setTransactionInfo(transactionInfo);
				postTransactionReq.setPostTransactionReqPayload(postTransactionReqPayload);
				
				postTransactionReq.setHeader(BillpaymentMappingHelper.populateInwardHeader(
						inwardPaymentRequestVO.getClientInfoVO().getCountry(), 
						CommonConstants.I_BANKING, BillpaymentMappingHelper.getGregorianCalendar(),inwardPaymentRequestVO.getReferenceNumber(),
						CommonConstants.CAPTURING_SYSTEM, CommonConstants.POST_SINGLE_LEG_TRANSACTION,
						CommonConstants.POST_SINGLE_LEG,CommonConstants.INWARD_TRANSACTION_STATUS_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));

				postTransaction.setPostTransactionRequest(postTransactionReq);

				
				postResponse = transactionPortType.postTransaction(postTransaction);
				
				
				if (postResponse != null && postResponse.getPostTransactionResponse() != null && 
						postResponse.getPostTransactionResponse().getHeader() != null && 
						postResponse.getPostTransactionResponse().getHeader().getExceptions() != null) {
					
					for (ExceptionType exceptionType : postResponse.getPostTransactionResponse().getHeader().getExceptions().getException()) {
						
						LOGGER.info("Exceptions present in the :performInwardBillPayment response ::: " +inwardPaymentRequestVO.getReferenceNumber());
						LOGGER.info("Exceptions code :performInwardBillPayment::: " +exceptionType.getCode().getValue()+ " ::: " +	inwardPaymentRequestVO.getReferenceNumber());
						LOGGER.info("Exceptions description :performInwardBillPayment::: " +exceptionType.getDescription()+ " ::: " +	inwardPaymentRequestVO.getReferenceNumber());
						
						StatusTypeVO statusTypeVO = new StatusTypeVO();
						HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
						String exceptionCode =  exceptionType.getCode().getValue().trim();
						
						if(exceptionCode.equalsIgnoreCase(CommonConstants.TIMEOUT_CODE)){
							
							statusTypeVO.setStatusCode(ExceptionMessages._202.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._202.getMessage());
							hostResponseTypeVO.setCode(exceptionType.getCode().getValue());
							hostResponseTypeVO.setDesc(exceptionType.getDescription());
							hostResponseTypeVO.setHostName(CommonConstants.EBBS);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
							inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._202.getMessage());
							inwardPaymentRequestVO.setHostStatusCode(exceptionCode);
							inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());
							
						} else {
							
							statusTypeVO.setStatusCode(ExceptionMessages._458.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._458.getMessage());
							hostResponseTypeVO.setCode(exceptionType.getCode().getValue());
							hostResponseTypeVO.setDesc(exceptionType.getDescription());
							hostResponseTypeVO.setHostName(CommonConstants.EBBS);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_FAILURE);
							inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._201.getMessage());
							inwardPaymentRequestVO.setHostStatusCode(exceptionType.getCode().getValue());
							inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());
						}
						
						statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
						inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						inwardPaymentResponseVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
						
					}
					
				} else if(postResponse != null && postResponse.getPostTransactionResponse() != null &&
						postResponse.getPostTransactionResponse().getPostTransactionResPayload() != null &&
						postResponse.getPostTransactionResponse().getPostTransactionResPayload().getPostTransactionRes() != null && 
						postResponse.getPostTransactionResponse().getPostTransactionResPayload().getPostTransactionRes().getTransactionInfo() != null) {
					
					LOGGER.info("Response payload from host ::: " +	inwardPaymentRequestVO.getReferenceNumber());
					TransactionInfo  transactionInfo2 = postResponse.getPostTransactionResponse().getPostTransactionResPayload().getPostTransactionRes().getTransactionInfo();
					inwardPaymentResponseVO.setReferenceNumber(transactionInfo2.getTransactionReferenceNumber());
					HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
					hostResponseTypeVO.setHostName(CommonConstants.EBBS);
					hostResponseTypeVO.setCode(transactionInfo2.getTransactionResponse().getCode());
					hostResponseTypeVO.setDesc(transactionInfo2.getTransactionResponse().getDescription());
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(ExceptionMessages._000.getCode());
					statusTypeVO.setStatusDesc(ExceptionMessages._000.getMessage());
					statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
					statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
					inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
					inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_SUCCESS);
					inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._000.getMessage());
					inwardPaymentRequestVO.setHostStatusCode(transactionInfo2.getTransactionResponse().getCode());
					inwardPaymentRequestVO.setHostStatusDescription(transactionInfo2.getTransactionResponse().getDescription());
					
				} else {
					
					LOGGER.info("No response payload from host ::: " +	inwardPaymentRequestVO.getReferenceNumber());
					HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
					hostResponseTypeVO.setCode(ExceptionMessages._503.getCode());
					hostResponseTypeVO.setDesc("No response payload from host");
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(ExceptionMessages._457.getCode());
					statusTypeVO.setStatusDesc(ExceptionMessages._457.getMessage());
					statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
					statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
					inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
					inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
					inwardPaymentRequestVO.setPaymentDescription(CommonConstants.TIMEOUT);
					inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._503.getCode());
					inwardPaymentRequestVO.setHostStatusDescription("No response payload from host");
					
					}
				LOGGER.info("performBillPayment ::: performInwardBillPayment TransactionServiceImpl ::: End"+inwardPaymentRequestVO.getReferenceNumber());
				
			} else {
				
				LOGGER.info("Service Provider Problem ::: " +	inwardPaymentRequestVO.getReferenceNumber());
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setCode(ExceptionMessages._455.getCode());
				hostResponseTypeVO.setDesc(ExceptionMessages._455.getMessage());
				statusTypeVO.setStatusCode(ExceptionMessages._455.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._455.getMessage());
				statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
				statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
				inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
				inwardPaymentRequestVO.setPaymentDescription("Invalid Service Provider");
				inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._455.getCode());
				inwardPaymentRequestVO.setHostStatusDescription(ExceptionMessages._455.getMessage());
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				
			}
		
			payloadDTO.setRequestVO(inwardPaymentRequestVO);
			payloadDTO.setResponseVO(inwardPaymentResponseVO);
			
		return payloadDTO;
			
	} catch (WebServiceException ex) {
			InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
			LOGGER.info("performInwardBillPayment TransactionServiceImpl SocketTimeoutException WebServiceException:::::"+ex.getClass());
			ex.printStackTrace();
			StatusTypeVO statusType = new StatusTypeVO();
			statusType.setStatusCode(ExceptionMessages._202.getCode());
			statusType.setStatusDesc(ExceptionMessages._202.getMessage());
			HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
			hostResponseTypeVO.setHostName(CommonConstants.EBBS);
			hostResponseTypeVO.setCode(ExceptionMessages._202.getCode());
			hostResponseTypeVO.setDesc(CommonConstants.HOST_TIMEOUT_MESSAGE);
			statusType.setHostResponseTypeVO(hostResponseTypeVO);
			inwardPaymentResponseVO.setStatusTypeVO(statusType);	
			payloadDTO.setResponseVO(inwardPaymentResponseVO);
			InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
			inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
			inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._202.getMessage());
			inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._503.getCode());
			inwardPaymentRequestVO.setHostStatusDescription(CommonConstants.HOST_TIMEOUT_MESSAGE);
			return payloadDTO;
		}
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.PaymentTransactionService#saveInwardPayment(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public PayloadDTO saveInwardPayment(PayloadDTO payloadDTO) throws BusinessException {
		
		InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
		LOGGER.info("PaymentTrasactionImpl saveInwardPayment start::: " +payloadDTO);
		InwardPaymentDetailVO inwardPaymentDetailVO = InwardMappingHelper.setInwardPaymentDetail(inwardPaymentRequestVO);
		InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
		StatusTypeVO statusTypeVO = new StatusTypeVO();
		inwardPaymentDetailVO.setPaymentStatus(CommonConstants.NEW);
		LOGGER.info("PaymentTrasactionImpl saveInwardPayment ::: " +payloadDTO+" ::Reference Number:: "+inwardPaymentDetailVO.getReferenceNumber());
		InwardPaymentDetailVO detailVO = inwardTransactionDao.saveCreditPayment(inwardPaymentDetailVO);
		
		if(detailVO == null){
			LOGGER.info("PaymentTrasactionImpl saveInwardPayment Invalid data::: " +payloadDTO.getRequestVO()+" ::Reference Number:: "+inwardPaymentDetailVO.getReferenceNumber());
			statusTypeVO.setStatusCode(ExceptionMessages._400.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._400.getMessage());
			inwardPaymentRequestVO.setPaymentStatus(CommonConstants.SAVE_FAIL);
			inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
			inwardPaymentResponseVO.setReferenceNumber(((InwardPaymentRequestVO)payloadDTO.getRequestVO()).getReferenceNumber());
			/*payloadDTO.setResponseVO(inwardPaymentResponseVO);*/
			LOGGER.info("PaymentTrasactionImpl saveInwardPayment FAIL ::: " +payloadDTO);
		} else {
			if(detailVO.getFlag()!=null && detailVO.getFlag().equalsIgnoreCase(CommonConstants.FALSE)){
				
				LOGGER.info("PaymentTrasactionImpl saveInwardPayment  Duplicate remittance request ::: " +payloadDTO.getRequestVO()+" ::Reference Number:: "+inwardPaymentDetailVO.getReferenceNumber());
				statusTypeVO.setStatusCode(ExceptionMessages._409.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._409.getMessage());
				inwardPaymentRequestVO.setPaymentStatus(CommonConstants.SAVE_FAIL);
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
				inwardPaymentResponseVO.setReferenceNumber(((InwardPaymentRequestVO)payloadDTO.getRequestVO()).getReferenceNumber());
				LOGGER.info("PaymentTrasactionImpl saveInwardPayment FAIL ::: " +payloadDTO);
				
			} else {
				LOGGER.info("PaymentTrasactionImpl saveInwardPayment SUCCESS ::: " +payloadDTO+" ::Reference Number:: "+inwardPaymentDetailVO.getReferenceNumber());
				inwardPaymentRequestVO.setPaymentStatus(CommonConstants.SAVE_SUCCESS);
				/*payloadDTO.setRequestVO(inwardPaymentRequestVO);*/
				updateInwardPayment(payloadDTO);
			}
		}
		
		LOGGER.info("PaymentTrasactionImpl saveInwardPayment Payment Status "+inwardPaymentRequestVO.getPaymentStatus());
		payloadDTO.setRequestVO(inwardPaymentRequestVO);
		payloadDTO.setResponseVO(inwardPaymentResponseVO);
		LOGGER.info("PaymentTrasactionImpl saveInwardPayment END ::: " +payloadDTO);
		return payloadDTO;
	}


	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.PaymentTransactionService#updateInwardPayment(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public PayloadDTO updateInwardPayment(PayloadDTO payloadDTO) throws ConstrtaintException {
		LOGGER.info("PaymentTrasactionImpl updateInwardPayment start");
		InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)payloadDTO.getRequestVO();
		LOGGER.info("PaymentTrasactionImpl updateInwardPayment Reference Number ::: " +inwardPaymentRequestVO.getReferenceNumber());
		InwardPaymentDetailVO  inwardPaymentDetailVO1 = inwardTransactionDao.getCreditPayment(inwardPaymentRequestVO.getReferenceNumber());
		
		LOGGER.info("PaymentTrasactionImpl updateInwardPayment ::: " +payloadDTO);
		if(inwardPaymentDetailVO1 != null){
			LOGGER.info("PaymentTrasactionImpl updateInwardPayment inside if::: " +inwardPaymentRequestVO);
			
			InwardPaymentDetailVO inwardPaymentDetailVO = InwardMappingHelper.setInwardPaymentDetail(inwardPaymentRequestVO);
			inwardPaymentDetailVO.setId(inwardPaymentDetailVO1.getId());
			inwardPaymentDetailVO.setUpdatedTime(new Timestamp(new Date().getTime()));
			LOGGER.info("InwardPaymentDetailVO updateInwardPayment ::: " +inwardPaymentDetailVO);
			inwardTransactionDao.updateCreditPayment(inwardPaymentDetailVO);
		}
		LOGGER.info("PaymentTrasactionImpl updateInwardPayment END");
		return payloadDTO;
	}


	@Override
	public PayloadDTO updateStatusCheck(PayloadDTO payloadDTO) throws Exception {
		LOGGER.info("PaymentTrasactionImpl updateStatusCheck start");
		Object object = payloadDTO.getRequestVO();
		InwardPaymentDetailVO inwardPaymentDetailVO  = null;
		if(object instanceof InwardPaymentRequestVO){
			InwardPaymentRequestVO inwardPaymentRequestVO = (InwardPaymentRequestVO)object;
			inwardPaymentDetailVO = InwardMappingHelper.setInwardPaymentDetail(inwardPaymentRequestVO);	
		}
		
		if(object instanceof InwardInquiryRequestVO){
			InwardInquiryRequestVO inwardInquiryRequestVO = (InwardInquiryRequestVO)object;
			inwardPaymentDetailVO = InwardMappingHelper.setInwardPaymentDetail(inwardInquiryRequestVO);
		}
		
		
		inwardTransactionDao.updateStatusCheck(inwardPaymentDetailVO);
		return payloadDTO;
	}
	
	/* (non-Javadoc)
	 * @see com.scb.channels.payments.service.InwardTransactionService#getInwardPayment(com.scb.channels.base.vo.PayloadDTO)
	 */
	@Override
	public PayloadDTO getInwardPayment(PayloadDTO payloadDTO) throws ConstrtaintException {
		LOGGER.info("PaymentTrasactionImpl getInwardPayment start");
		InwardInquiryRequestVO inwardInquiryRequestVO = (InwardInquiryRequestVO)payloadDTO.getRequestVO();
		InwardPaymentDetailVO  inwardPaymentDetailVO = inwardTransactionDao.getCreditPayment(inwardInquiryRequestVO.getReferenceNumber());
		LOGGER.info("PaymentTrasactionImpl getInwardPayment Reference Number"+inwardInquiryRequestVO.getReferenceNumber());
		InwardInquiryResponseVO inwardInquiryResponseVO = new InwardInquiryResponseVO();
		StatusTypeVO statusTypeVO = new StatusTypeVO();
		HostResponseTypeVO hostResponseType = new HostResponseTypeVO();
		if(inwardPaymentDetailVO != null){
			LOGGER.info("PaymentTrasactionImpl getInwardPayment inwardPaymentDetailVO if ::"+inwardInquiryRequestVO.getReferenceNumber());
			if(inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_SUCCESS)){
				LOGGER.info("PaymentTrasactionImpl getInwardPayment inwardPaymentDetailVO inwardPaymentDetailVO.getPaymentStatus() if ::"+inwardInquiryRequestVO.getReferenceNumber());
				statusTypeVO.setStatusCode(CommonConstants.THREE_ZEROES);
				statusTypeVO.setStatusDesc(CommonConstants.SUCCESS);
				hostResponseType.setCode(inwardPaymentDetailVO.getHostStatusCode());
				hostResponseType.setDesc(inwardPaymentDetailVO.getHostStatusDescription());
				hostResponseType.setHostName(CommonConstants.RPE);
				statusTypeVO.setHostResponseTypeVO(hostResponseType);
			
			} else if(inwardPaymentDetailVO != null && inwardPaymentDetailVO.getPaymentStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_TIMEOUT)){
				inwardInquiryRequestVO.setRetryCount(inwardPaymentDetailVO.getRetryCount());
				statusTypeVO.setStatusCode(CommonConstants.FAILURE_STATUS);
				inwardInquiryRequestVO.setHostReferenceNumber(inwardPaymentDetailVO.getHostReferenceNumber());
				LOGGER.info("PaymentTrasactionImpl getInwardPayment inwardPaymentDetailVO else ::"+inwardInquiryRequestVO.getHostReferenceNumber());
			} else {
				LOGGER.info("PaymentTrasactionImpl getInwardPayment inwardPaymentDetailVO inwardPaymentDetailVO.getPaymentStatus() else ::"+inwardInquiryRequestVO.getReferenceNumber());
				statusTypeVO.setStatusCode(ExceptionMessages._201.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._201.getMessage());
				hostResponseType.setCode(inwardPaymentDetailVO.getHostStatusCode());
				hostResponseType.setDesc(inwardPaymentDetailVO.getHostStatusDescription());
				hostResponseType.setHostName(CommonConstants.RPE);
				statusTypeVO.setHostResponseTypeVO(hostResponseType);
			}
		} else {
			LOGGER.info("PaymentTrasactionImpl getInwardPayment inwardPaymentDetailVO else ::"+inwardInquiryRequestVO.getReferenceNumber());
			statusTypeVO.setStatusCode(ExceptionMessages._204.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._204.getMessage());
			hostResponseType.setHostName(CommonConstants.RPE);
			statusTypeVO.setHostResponseTypeVO(hostResponseType);
		}
		inwardInquiryResponseVO.setStatusTypeVO(statusTypeVO);
		
		payloadDTO.setResponseVO(inwardInquiryResponseVO);
		payloadDTO.setRequestVO(inwardInquiryRequestVO);
		
		LOGGER.info("PaymentTrasactionImpl updateInwarPayment inside if::: " +inwardInquiryResponseVO);
		LOGGER.info("PaymentTrasactionImpl getInwardPayment END");
		return payloadDTO;
	}
	
	/**
	 * Sets the narration.
	 *
	 * @param inwardPaymentRequestVO the inward payment request vo
	 * @return the inward payment request vo
	 */
	public InwardPaymentRequestVO setNarration(InwardPaymentRequestVO inwardPaymentRequestVO){
		LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig start !!!!!");
		List<NarrationVO> narrationConfig = null;
		narrationConfig = cacheService.getNarration(inwardPaymentRequestVO.getClientInfoVO().getCountry(), "INWARD");
		NarrationVO narrationVOObj = null;
		LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig is not null !!!!!");
		if(narrationConfig != null){
			LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig is not null !!!!!"+narrationConfig);
			for(NarrationVO narrationVO : narrationConfig){
				 if(narrationVO.getBillerId() == null && narrationVO.getCategoryId() == null){
					 LOGGER.debug("InwardPaymentRequestVO setNarration narrationConfig --- Default  !!!!!"+narrationVO);
					narrationVOObj = narrationVO;
					break;
				}
		
			}
		}
		
		LOGGER.info("InwardPaymentRequestVO setNarration narrationVOObj !!!!!"+narrationVOObj);
		InwardPaymentRequestVO inwardPaymentRequestVO2 = NarrationHelper.populateNarration(inwardPaymentRequestVO,narrationVOObj);
		LOGGER.info("InwardPaymentRequestVO setNarration narrationConfig end !!!!!"+inwardPaymentRequestVO2);
		return inwardPaymentRequestVO2;
	}
	
	public PayloadDTO creditInquiryStatusCheck(PayloadDTO payloadDTO){
		StatusTypeVO statusTypeVO = new StatusTypeVO();
		
		Object object = payloadDTO.getRequestVO();
		Object objectResponse = payloadDTO.getResponseVO();
		InwardInquiryRequestVO inquiryRequestVO = null;
		InwardPaymentRequestVO inwardPaymentRequestVO = null;
		InwardPaymentResponseVO inwardPaymentResponseVO = null;
		InwardInquiryResponseVO inwardInquiryResponseVO = null;
		String referenceNumber = "";
		String hostReferenceNumber = "";
		String country = "";
		String serviceName = CommonConstants.GET_TRANSACTION;
		int retryCount = 0;
		
		if(object instanceof InwardPaymentRequestVO){
			LOGGER.info("Inside creditInquiryStatusCheck in InwardTransactionServiceImpl");
			inwardPaymentRequestVO = (InwardPaymentRequestVO)object;
			referenceNumber = inwardPaymentRequestVO.getReferenceNumber();
			hostReferenceNumber = inwardPaymentRequestVO.getHostReferenceNumber();
			LOGGER.info("Inside creditInquiryStatusCheck in InwardTransactionServiceImpl"+referenceNumber);
			country = inwardPaymentRequestVO.getClientInfoVO().getCountry();
			inwardPaymentRequestVO.setServiceName(serviceName);
			inwardPaymentRequestVO.setRetryCount(CommonConstants.ONE);
			
		} else if(object instanceof InwardInquiryRequestVO){
			inquiryRequestVO = (InwardInquiryRequestVO)object;
			referenceNumber = inquiryRequestVO.getReferenceNumber();
			hostReferenceNumber = inquiryRequestVO.getHostReferenceNumber();
			country = inquiryRequestVO.getClientInfoVO().getCountry();
			inquiryRequestVO.setServiceName(serviceName);
			retryCount = inquiryRequestVO.getRetryCount();
			retryCount = retryCount+1;
			inquiryRequestVO.setRetryCount(retryCount);
		}
		
		if(objectResponse instanceof InwardPaymentResponseVO){
			LOGGER.info("Inside creditInquiryStatusCheck in InwardTransactionServiceImpl");
			inwardPaymentResponseVO = (InwardPaymentResponseVO)objectResponse;
			LOGGER.info("Inside creditInquiryStatusCheck in InwardTransactionServiceImpl"+referenceNumber);
			
		} else if(objectResponse instanceof InwardInquiryResponseVO){
			inwardInquiryResponseVO = (InwardInquiryResponseVO)objectResponse;
		}
		
		LOGGER.info("Inside creditInquiryStatusCheck in InwardTransactionServiceImpl"+referenceNumber);
		GetTransactionReq getTransactionReq = BillpaymentMappingHelper.performStatusCheckPaymentRequestPayload(referenceNumber,hostReferenceNumber,country);
		LOGGER.info(" getTransactionReq " + getTransactionReq);

		LOGGER.info("InwardTransactionServiceImpl Before sending Request to EDMI ::: " + referenceNumber);
		GetTransactionRes  getTransactionRes = null;
		try{
			getTransactionRes = transactionPortTypeStatus.getTransaction(getTransactionReq);
		} catch (WebServiceException webServiceException) {
			LOGGER.info("InwardTransactionServiceImpl webServiceException setting failure status");
			statusTypeVO.setStatusCode(ExceptionMessages._202.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._202.getMessage());
			if(inwardInquiryResponseVO != null){
				inwardInquiryResponseVO.setStatusTypeVO(statusTypeVO);
			}
			
			if(inwardPaymentResponseVO != null){
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
			}
			webServiceException.printStackTrace();
		}
		
		LOGGER.info("InwardTransactionServiceImpl getTransactionRes " + getTransactionRes);
		
		if (getTransactionRes != null) {
			LOGGER.info("InwardTransactionServiceImpl After getting response from EDMI :::: " + referenceNumber);
			ExceptionListType exceptions = getTransactionRes.getExceptions();
			TagsType metaData = getTransactionRes.getHeader().getMetadata();
			
			if(getTransactionRes != null && getTransactionRes.getGetTransactionResPayload() != null 
					&& getTransactionRes.getGetTransactionResPayload().getGetTransactionRes() != null
					&& getTransactionRes.getGetTransactionResPayload().getGetTransactionRes().getTransactionInfo() != null){
				LOGGER.info("InwardTransactionServiceImpl Got creditInquiryStatusCheck Response ::: " + hostReferenceNumber);
				com.sc.corebanking.v1.transaction.TransactionInfo responseInfo = getTransactionRes.getGetTransactionResPayload().getGetTransactionRes().getTransactionInfo();
				if(responseInfo != null){
					String status = responseInfo.getTransactionStatusCode();
					if(status.equalsIgnoreCase(CommonConstants.THREE_ZEROES)){
						if(inquiryRequestVO !=null){
							inquiryRequestVO.setStatus("S000");
							LOGGER.info("InwardTransactionServiceImpl Got creditInquiryStatusCheck inquiryRequestVO S000 ::: " + hostReferenceNumber);
							inquiryRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_SUCCESS);
							inquiryRequestVO.setPaymentDescription(CommonConstants.PAYMENT_DESC);
							statusTypeVO.setStatusCode(ExceptionMessages._000.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._000.getMessage());
							//Added for Audit - OM
							inquiryRequestVO.setHostStatusCode(responseInfo.getTransactionStatusCode());
							inquiryRequestVO.setHostStatusDescription(responseInfo.getTransactionStatusDescription());
							//Added for Audit - OM
							inwardInquiryResponseVO.setStatusTypeVO(statusTypeVO);
						}
						if(inwardPaymentRequestVO !=null){
							inwardPaymentRequestVO.setStatus("S000");
							LOGGER.info("InwardTransactionServiceImpl Got creditInquiryStatusCheck inwardPaymentRequestVO S000 ::: " + hostReferenceNumber);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_SUCCESS);
							inwardPaymentRequestVO.setPaymentDescription(CommonConstants.PAYMENT_DESC);
							statusTypeVO.setStatusCode(ExceptionMessages._000.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._000.getMessage());
							//Added for Audit - OM
							inwardPaymentRequestVO.setHostStatusCode(responseInfo.getTransactionStatusCode());
							inwardPaymentRequestVO.setHostStatusDescription(responseInfo.getTransactionStatusDescription());
							//Added for Audit - OM
							inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						}
						
					} else {
						if(inquiryRequestVO != null){
							inquiryRequestVO.setStatus("S001");
							LOGGER.info("InwardTransactionServiceImpl Got creditInquiryStatusCheck inquiryRequestVO S001 ::: " + hostReferenceNumber);
							inquiryRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_FAILURE);
							inquiryRequestVO.setPaymentDescription(ExceptionMessages._201.getMessage());
							statusTypeVO.setStatusCode(ExceptionMessages._201.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._201.getMessage());
							//Added for Audit - OM
							inquiryRequestVO.setHostStatusCode(responseInfo.getTransactionStatusCode());
							inquiryRequestVO.setHostStatusDescription(responseInfo.getTransactionStatusDescription());
							//Added for Audit - OM
							inwardInquiryResponseVO.setStatusTypeVO(statusTypeVO);
						}
						if(inwardPaymentRequestVO != null){
							inwardPaymentRequestVO.setStatus("S001");
							LOGGER.info("InwardTransactionServiceImpl Got creditInquiryStatusCheck inwardPaymentRequestVO S001 ::: " + hostReferenceNumber);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_FAILURE);
							inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._201.getMessage());
							statusTypeVO.setStatusCode(ExceptionMessages._201.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._201.getMessage());
							//Added for Audit - OM
							inwardPaymentRequestVO.setHostStatusCode(responseInfo.getTransactionStatusCode());
							inwardPaymentRequestVO.setHostStatusDescription(responseInfo.getTransactionStatusDescription());
							//Added for Audit - OM
							inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						}
					}
				}
			}
			
		} else {
			
			LOGGER.info("InwardTransactionServiceImpl responseInfo != null else setting failure status");
			statusTypeVO.setStatusCode(ExceptionMessages._202.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._202.getMessage());
			if(inwardInquiryResponseVO != null){
				inwardInquiryResponseVO.setStatusTypeVO(statusTypeVO);
			}
			
			if(inwardPaymentResponseVO != null){
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
			}
		}
		
		if(inwardInquiryResponseVO != null){
			LOGGER.info("InwardTransactionServiceImpl inwardInquiryResponseVO setting paylaod status");
			payloadDTO.setResponseVO(inwardInquiryResponseVO);	
		}
		
		if(inwardPaymentResponseVO != null){
			LOGGER.info("InwardTransactionServiceImpl inwardPaymentResponseVO setting paylaod status");
			payloadDTO.setResponseVO(inwardPaymentResponseVO);	
		}
		
		return payloadDTO;
		
	}
	
	/**
	 * Sets the inward transaction dao.
	 *
	 * @param inwardTransactionDao the inwardTransactionDao to set
	 */
	public void setInwardTransactionDao(InwardTransactionDAO inwardTransactionDao) {
		this.inwardTransactionDao = inwardTransactionDao;
	}

	/**
	 * Sets the data bean.
	 *
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	/**
	 * Gets the payment common service.
	 *
	 * @return the paymentCommonService
	 */
	public PaymentCommonService getPaymentCommonService() {
		return paymentCommonService;
	}

	/**
	 * Sets the payment common service.
	 *
	 * @param paymentCommonService the paymentCommonService to set
	 */
	public void setPaymentCommonService(PaymentCommonService paymentCommonService) {
		this.paymentCommonService = paymentCommonService;
	}

	/**
	 * Gets the transaction port type.
	 *
	 * @return the transactionPortType
	 */
	public TransactionPortType getTransactionPortType() {
		return transactionPortType;
	}

	/**
	 * Sets the transaction port type.
	 *
	 * @param transactionPortType the transactionPortType to set
	 */
	public void setTransactionPortType(TransactionPortType transactionPortType) {
		this.transactionPortType = transactionPortType;
	}

	/**
	 * Gets the cache service.
	 *
	 * @return the cacheService
	 */
	public CacheManagementService getCacheService() {
		return cacheService;
	}

	/**
	 * Sets the cache service.
	 *
	 * @param cacheService the cacheService to set
	 */
	public void setCacheService(CacheManagementService cacheService) {
		this.cacheService = cacheService;
	}

	/**
	 * Gets the inward transaction dao.
	 *
	 * @return the inwardTransactionDao
	 */
	public InwardTransactionDAO getInwardTransactionDao() {
		return inwardTransactionDao;
	}

	/**
	 * Gets the data bean.
	 *
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}

	/**
	 * @return the transactionPortTypeStatus
	 */
	public com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.TransactionPortType getTransactionPortTypeStatus() {
		return transactionPortTypeStatus;
	}

	/**
	 * @param transactionPortTypeStatus the transactionPortTypeStatus to set
	 */
	public void setTransactionPortTypeStatus(
			com.sc.scbcorebankingtransaction.v1.ws.provider.transaction.TransactionPortType transactionPortTypeStatus) {
		this.transactionPortTypeStatus = transactionPortTypeStatus;
	}

	
	
}
