package com.scb.channels.payments.dao.impl;

import java.sql.BatchUpdateException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BackupMasterBillerCategoryVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.JobsVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.payments.dao.BillerDownloadDAO;

/**
 * @author 1460693
 *
 */
public class BillerDownloadDAOImpl extends HibernateDaoSupport implements BillerDownloadDAO {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(BillerDownloadDAOImpl.class);
	public String deleteTempCategoryquery="DELETE FROM com.scb.channels.base.vo.TempBillerCategoryVO where countryCode=?";
	public String deleteTempBillerquery="DELETE FROM com.scb.channels.base.vo.TempBillerVO where countryCode=?";
	public String deleteTempBillerFeildsquery="DELETE FROM com.scb.channels.base.vo.TempBillerField where countryCode=?";
	
	public String delteBackupCategoryquery="DELETE FROM com.scb.channels.base.vo.BackupMasterBillerCategoryVO where countryCode=?";
	public String delteBackupBillerquery="DELETE FROM com.scb.channels.base.vo.BackupMasterBillerVO where countryCode=?";
	public String delteBackupBillerFeildsquery="DELETE FROM com.scb.channels.base.vo.BackupMasterBillerField where countryCode=?";
	
	public String deleteMasterCategoryquery="DELETE FROM com.scb.channels.base.vo.BillerCategoryVO";
	public String deleteMasterBillerquery="DELETE FROM com.scb.channels.base.vo.BillerVO";
	public String deleteMasterBillerFeildsquery="DELETE FROM com.scb.channels.base.vo.BillerField";
	
	public String retrieveAllBillerCategories="from com.scb.channels.base.vo.BillerCategoryVO where countryCode=? ";
	
	
	public String BillerDownloadJob= "UPDATE com.scb.channels.base.vo.JobsVO set jvmName=?,status=? ,jobLastUpdated =? where    jobId=? and jobLastUpdated=? and status=?" ;
	
	public String genralJOBupdateASProgress= "UPDATE com.scb.channels.base.vo.JobsVO set jvmName=?,status=? ,jobLastUpdated =? where    jobId=? and jobLastUpdated=? and status=?" ;
	
	public String updatefinalDownloadJobStatus= "UPDATE com.scb.channels.base.vo.JobsVO set status=? where countryCode=? and jobName=? ";
	
	public String deleteMasterBillerFeildsqueryDisabled="DELETE FROM com.scb.channels.base.vo.BillerField WHERE status='D' ";
	@Override
	public Integer getCountBillerCategories(String Country) {
		Integer count=0;
		
		Session session =getHibernateTemplate().getSessionFactory().openSession();
		Criteria criteria=session.createCriteria(BillerCategoryVO.class);//.setProjection(Projections.rowCount());
		criteria.add(Restrictions.eq("countryCode", Country));
		count=((Long)criteria.setProjection(Projections.rowCount()).uniqueResult()).intValue();
		if(session!=null&& session.isOpen()){
			session.close();
		}
 		return count;
	}

	@Override
	/**
	 * <p>used for the store  aggragator Data in DB intemp table
	 * @param aggregatorlist
	 */
	public void saveAggregatorData(List<TempBillerCategoryVO> aggregatorCategoryList ) {
  			getHibernateTemplate().saveOrUpdateAll(aggregatorCategoryList); 
	}

	
	
	/*  @author 1460693
	 * (non-Javadoc)
	 * @see com.scb.channels.payments.dao.BillerDownloadDAO#deleteTemporayTableData();
	 * <p>used for the remove   aggragator Data in DB in temp  all  three tables
	 */
	@Override
	public void deleteTemporayTableData(String country) {
		 
		getHibernateTemplate().bulkUpdate(deleteTempBillerFeildsquery,country);
		getHibernateTemplate().bulkUpdate(deleteTempBillerquery,country);
		getHibernateTemplate().bulkUpdate(deleteTempCategoryquery,country);

	}

	/**
	 * @param masterCatgegories
	 */
	@Override
	public void saveMasterBiller(List<BillerCategoryVO> masterCatgegories) {
		
		/**  Temporary delete for Development environment  **/
		//deleteMastertableData();
		getHibernateTemplate().saveOrUpdateAll(masterCatgegories);
		//getHibernateTemplate().bulkUpdate(deleteMasterBillerFeildsqueryDisabled);
		
	}

	 
	public void deleteMastertableData(){
		getHibernateTemplate().bulkUpdate(deleteMasterBillerFeildsquery);
		getHibernateTemplate().bulkUpdate(deleteMasterBillerquery);
		getHibernateTemplate().bulkUpdate(deleteMasterCategoryquery);
	}

	@Override
	public List<BillerCategoryVO> getAllMasterBillersforCountry(String Country,String[] category,String[] billers) {
	 	List<BillerCategoryVO> categoryList=null;
	 	Set<BillerVO> billerSet=new HashSet<BillerVO>();
 	 	Session session=getHibernateTemplate().getSessionFactory().openSession();
	 	Criteria c=	session.createCriteria(BillerCategoryVO.class, "category");
	 	
		c.add(Restrictions.eq("category.countryCode", Country));
		//Modified for partial biller update at category level --Start
		if(category.length>0){
			LOGGER.info("BillerDownloadDAOImpl :: FOUND FAILED CATEGORIES ::: " + category);
		c.add(Restrictions.not(Restrictions.in("category.categoryId",category)));
		}
		//Modified for partial biller update at category level--End
 		c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		categoryList =c.list();
		//Modified for partial biller update at biller level--End
		if(billers !=null){
			if(billers.length>0){
				LOGGER.info("BillerDownloadDAOImpl :: FOUND FAILED BILLERS ::: " + billers);	
				for(BillerCategoryVO billerCategoryVO :categoryList){
					for(BillerVO billerVO:billerCategoryVO.getBillers()){
						for(String billerId:billers){
							if(billerId.equalsIgnoreCase(billerVO.getBillerId())){
								billerSet.add(billerVO);
							}
						}
					}
					billerCategoryVO.getBillers().removeAll(billerSet);
				}
			}
		}
		//Modified for partial biller update at biller level--End
		if(session!=null&& session.isOpen()){
			session.close();
		}		 	 	
	 	return categoryList;
	}
	
	
	public List<BillerCatgegoryReference> getCategoriesFromRef(String country){
		
		List<BillerCatgegoryReference> list=null;
		Session session=getHibernateTemplate().getSessionFactory().openSession();
		Criteria categoryList=	session.createCriteria(BillerCatgegoryReference.class);
		categoryList.add(Restrictions.eq("countryCode", country));
		categoryList.add(Restrictions.eq("fetchType",CommonConstants.BILLER_CATEGORY_AGGREGATOR_FETCH));
		categoryList.add(Restrictions.ne("categoryName", "Default"));
		list=categoryList.list();
		
		if(session!=null&& session.isOpen()){
			session.close();
		}
		return list;
	}

	@Override
	public void saveBackupDatafromMaster(String country,
			List<BackupMasterBillerCategoryVO> MasterData) {
		
		getHibernateTemplate().bulkUpdate(delteBackupBillerFeildsquery,country);
		getHibernateTemplate().bulkUpdate(delteBackupBillerquery,country);
		getHibernateTemplate().bulkUpdate(delteBackupCategoryquery,country);
		getHibernateTemplate().saveOrUpdateAll(MasterData);
		
	}

	@Override
	public JobsVO getJobDetails(String country, String jobName) {
			
		
		List<JobsVO> job=null;	
		Session session=null;
		try{
		  session=getHibernateTemplate().getSessionFactory().openSession();
		Criteria  criteria= session.createCriteria(JobsVO.class);
		criteria.add(Restrictions.eq("countryCode", country));
		criteria.add(Restrictions.eq("jobName", jobName));
		
		job= criteria.list();
		}finally{
			if(session!=null&& session.isOpen()){
				session.close();
			}
		}
		if(job!=null && job.size()>0){
			return job.get(0);	
		}else{
			return null;
		}
		 
		
		
	}

	@Override
	public void saveInitialJob(JobsVO job) {
		getHibernateTemplate().save(job);
	}

	@Override
	public int updateBillerJobProgress(JobsVO job, String jvmName) {
		int count=getHibernateTemplate().bulkUpdate(BillerDownloadJob, new Object[]{jvmName,CommonConstants.BILLER_DOWNLOAD_IN_PROGRESS,new Date(System.currentTimeMillis()),job.getJobId(),job.getJobLastUpdated(), job.getStatus()});
		return count;
	}

		@Override
	public int updatefinalJobStatus(String country) {
		int count=getHibernateTemplate().bulkUpdate(updatefinalDownloadJobStatus, new Object[]{CommonConstants.BILLER_DOWNLOAD_COMPLETED,country,CommonConstants.BILLER_DOWNLOAD});
		return count;
	}
	
	public List<BillerCatgegoryReference> getCategoryReference(List<String> category, String country) {
		LOGGER.info("BillerDownloadDAOImpl -- getCategoryReference -- Start ::: " + category);
		
		List<BillerCatgegoryReference> categoryReferences = new ArrayList<BillerCatgegoryReference>();
		Session session = null;
		try {
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria categoryList = session
					.createCriteria(BillerCatgegoryReference.class);
			categoryList.add(Restrictions.eq("countryCode", country))
					.add(Restrictions.in("categoryId", category))
					.add(Restrictions.eq("statusCode", CommonConstants.ACTIVE));

			Object object = categoryList.list();

			if (object != null && object instanceof List) {
				categoryReferences = (List<BillerCatgegoryReference>) object;
			} else if (object != null && object instanceof BillerCatgegoryReference) {
				categoryReferences.add((BillerCatgegoryReference) object);
			}
		} catch (Exception exception) {
			LOGGER.error("Exception occurred while getCategoryReference :::: " , exception);
			exception.printStackTrace();
		} finally {
			if (session != null && session.isOpen()) {
				LOGGER.info("closing the session in getCategoryReference" + category);
				session.close();
			}
		}
		LOGGER.info("BillerDownloadDAOImpl -- getCategoryReference -- End ::: " + category);
		return categoryReferences;
	}

		@Override
		public int updateJob(JobsVO job, String JVMName,String newStatus) {
					
			int count=	getHibernateTemplate().bulkUpdate(genralJOBupdateASProgress, new Object[]{JVMName,newStatus,new Date(System.currentTimeMillis()),job.getJobId(),job.getJobLastUpdated(),job.getStatus()});
	
			return count;
			
		}

		//Biller Download Status Check - start
		
		@Override		
		public BillerDownloadResponseVO getBillerDownloadStatusCheck(
				BillerDownloadRequest billerDownloadRequest) {
		
			List<JobsVO> job=null;	
			Session session = null;
			
			BillerDownloadResponseVO billerDownloadResponse = new BillerDownloadResponseVO();
			try {
				session = getHibernateTemplate().getSessionFactory().openSession();

	          Criteria criteria = session.createCriteria(JobsVO.class);
	        
	          if(billerDownloadRequest.getUser().getCountry()!= null){
	        	  criteria.add(Restrictions.eq("countryCode", billerDownloadRequest.getUser().getCountry()));
	          }
	          criteria.add(Restrictions.eq("jobName", "BILLER_DOWNLOAD"));
			
	          job = criteria.list();
	          
	          if(job!=null && job.size()>0){
	        	  billerDownloadResponse.setStatus(job.get(0).getStatus());	
	        	  logger.debug("After DB Fetch at getBillerDownloadStatusCheck job status :  " + job.get(0).getStatus());
	  		}else{
	  			 billerDownloadResponse.setStatus("Job Not Found");
	  		}

			}catch(Exception e) {
				
				 LOGGER.info("Exception occurred duirng getBillerDownloadStatusCheck::: ");
				 
			} finally {
				if(session != null) {
					LOGGER.info("BillerDownloadDAOImpl closing Session ");
					session.close();
				}
			}	
			return billerDownloadResponse; 
		}
		
		
		// Biller Download Status Check - end
		
	@Override
	public Long saveJob(JobsVO job) {
		LOGGER.info("saveJob ::: billerDownloadDaoImpl ::: Start");
		Session session = null;
		Transaction transaction = null;
		Long returnValue = 0L;
		try {
			LOGGER.info("create Session ::: " + job.getJobName());
			session = getHibernateTemplate().getSessionFactory().openSession();

			transaction = session.beginTransaction();
			LOGGER.info("saving retry Job ::: " + job.getJobName());
			Object id = session.save(job);
			
			transaction.commit();
			session.flush();
			returnValue = id != null ? Long.valueOf(id.toString()) : 0L;
			
			LOGGER.info("save job committed ::: " + id + " ::: " + job.getJobName());
		} catch (ConstraintViolationException exception) {
			returnValue = 0L;
			LOGGER.info("ConstraintViolationException for ::: " + job.getJobName());
			//LOGGER.info("ConstraintViolationException occurred duirng saving job ::: ", exception);
			//LOGGER.error("", exception);
			if (transaction != null) {
				LOGGER.info("Closing transaction in save job");
				transaction.rollback();
			}
		} catch (Exception exception) {
			returnValue = 0L;
			LOGGER.info("Exception for ::: " + job.getJobName());
			LOGGER.info("Exception occurred duirng saving job ::: ", exception);
			LOGGER.error("", exception);
			if (transaction != null) {
				LOGGER.info("Closing transaction in save job");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in save job");
				session.close();
			}
		}

		LOGGER.info("saveJob ::: billerDownloadDaoImpl ::: End");

		return returnValue;
	}

	@Override
	public void deleteJob(String country, String jobName) {
		LOGGER.info("deleteJob ::: billerDownloadDaoImpl ::: Start");

		Session session = null;
		Criteria criteria = null;
		Transaction transaction = null;
		try {
			LOGGER.info("Creating Session for delete job ::: " + jobName);
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria = session.createCriteria(JobsVO.class)
					.add(Restrictions.eq("jobName", jobName))
					.add(Restrictions.eq("countryCode", country));

			Object object = criteria.uniqueResult();
			if (object != null) {
				transaction = session.beginTransaction();
				session.delete(object);
				transaction.commit();
				LOGGER.info("deleting job ::: " + jobName);
			} else {
				LOGGER.info("No job in the DB for ::: " + jobName);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception for ::: " + jobName);
			LOGGER.info("Exception occurred duirng delete job ::: " + exception);
			LOGGER.error("", exception);
			if (transaction != null) {
				LOGGER.info("Closing transaction in update payment");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in update payment");
				session.close();
			}
		}
		LOGGER.info("deleteJob ::: billerDownloadDaoImpl ::: End");
	}

	@Override
	public BillerDownloadResponseVO saveUpdatePayeesOnceDownloadDone(String country) {
		LOGGER.info("saveUpdatePayeesOnceDownloadDone ::: billerDownloadDaoImpl ::: start");
		Session session = null;
		BillerDownloadResponseVO billerDownloadResponse = new BillerDownloadResponseVO();
		try {
 			session = getHibernateTemplate().getSessionFactory().openSession();
			Query updatedBillers = session.getNamedQuery("saveUpdatePayeesOnceDownloadDone");
			updatedBillers.setString("i_country", country);
			List updatedBillersList = updatedBillers.list();
			LOGGER.info("UPDATED BILLERS AFTER DOWNLOAD COUNTRY: " +country+" BILLERS: "+ updatedBillersList);
			billerDownloadResponse.setStatus(CommonConstants.SUCCESS);
		}catch(Exception ex) {
			ex.printStackTrace();
			LOGGER.error("Exception UPDATED BILLERS::: " + ex);
			 LOGGER.error("Exception occurred duirng Archieve Process::: " + ex.getMessage());
			 
		} finally {
			if(session != null) {
				session.close();
			}
		}	
		LOGGER.info("saveUpdatePayeesOnceDownloadDone ::: billerDownloadDaoImpl ::: End");
		return billerDownloadResponse; 
	}
}
