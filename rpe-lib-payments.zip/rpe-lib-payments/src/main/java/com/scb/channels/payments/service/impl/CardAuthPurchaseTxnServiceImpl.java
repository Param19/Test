package com.scb.channels.payments.service.impl;

import iso.std.iso._20022.tech.xsd.cain_001_001.AccountIdentification30Choice;
import iso.std.iso._20022.tech.xsd.cain_001_001.Acquirer6;
import iso.std.iso._20022.tech.xsd.cain_001_001.AcquirerAuthorisationInitiation1;
import iso.std.iso._20022.tech.xsd.cain_001_001.Algorithm13Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.Algorithm15Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.Algorithm7Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.AlgorithmIdentification11;
import iso.std.iso._20022.tech.xsd.cain_001_001.AlgorithmIdentification13;
import iso.std.iso._20022.tech.xsd.cain_001_001.AlgorithmIdentification14;
import iso.std.iso._20022.tech.xsd.cain_001_001.AttributeType1Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.AuthenticationMethod5Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardAccount1;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardDataReading2Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardPaymentServiceType7Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionAmount1;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionContext1;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionContext2;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionDetail1;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionEnvironment1;
import iso.std.iso._20022.tech.xsd.cain_001_001.Cardholder9;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardholderAuthentication7;
import iso.std.iso._20022.tech.xsd.cain_001_001.CertificateIssuer1;
import iso.std.iso._20022.tech.xsd.cain_001_001.ContentInformationType10;
import iso.std.iso._20022.tech.xsd.cain_001_001.ContentType2Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.CurrencyAndAmount;
import iso.std.iso._20022.tech.xsd.cain_001_001.DetailedAmount10;
import iso.std.iso._20022.tech.xsd.cain_001_001.DetailedAmount8;
import iso.std.iso._20022.tech.xsd.cain_001_001.EncryptedContent3;
import iso.std.iso._20022.tech.xsd.cain_001_001.EnvelopedData4;
import iso.std.iso._20022.tech.xsd.cain_001_001.GenericIdentification32;
import iso.std.iso._20022.tech.xsd.cain_001_001.IssuerAndSerialNumber1;
import iso.std.iso._20022.tech.xsd.cain_001_001.KEK4;
import iso.std.iso._20022.tech.xsd.cain_001_001.KEKIdentifier2;
import iso.std.iso._20022.tech.xsd.cain_001_001.KeyTransport4;
import iso.std.iso._20022.tech.xsd.cain_001_001.OnLinePIN4;
import iso.std.iso._20022.tech.xsd.cain_001_001.Organisation18;
import iso.std.iso._20022.tech.xsd.cain_001_001.PINFormat3Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.PaymentCard12;
import iso.std.iso._20022.tech.xsd.cain_001_001.Recipient4Choice;
import iso.std.iso._20022.tech.xsd.cain_001_001.Recipient5Choice;
import iso.std.iso._20022.tech.xsd.cain_001_001.RelativeDistinguishedName1;
import iso.std.iso._20022.tech.xsd.cain_005_001.CardTransactionDetail5;
import iso.std.iso._20022.tech.xsd.cain_005_001.CardTransactionEnvironment3;
import iso.std.iso._20022.tech.xsd.cain_005_001.MessageReason1Code;
import iso.std.iso._20022.tech.xsd.cain_005_001.Organisation19;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import card.std.xsd.v2.supp.AuthorizationSupplementary;
import card.std.xsd.v2.supp.SupplementaryType;

import com.sc.corebanking.creditcard.v2.creditcardauthorization.ReverseCardPurchaseTransactionReqPayload;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.CreditCardAuthorizationPortType;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq;
import com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.SCBMLHeaderType;
import com.sc.scbml_1.SubDomainName;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.mapper.helper.CreditCardC400MappingHelper;
import com.scb.channels.payments.service.CardAuthPurchaseTxnService;
import com.scb.channels.payments.service.PaymentCommonService;

public class CardAuthPurchaseTxnServiceImpl implements CardAuthPurchaseTxnService{

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CardAuthPurchaseTxnServiceImpl.class);
	
	private CreditCardAuthorizationPortType creditCardC400ServiceClient;
	
	private DataBean dataBean;
	
	private PaymentCommonService paymentCommonService;
	
	public void setPaymentCommonService(PaymentCommonService paymentCommonService) {
		this.paymentCommonService = paymentCommonService;
	}

	public PaymentCommonService getPaymentCommonService() {
		return paymentCommonService;
	}
	
	
	/* Method to authorize card purchase transaction
	 * (non-Javadoc)
	 * @see com.scb.channels.payments.service.CreditCardService#authorizeC400CardPurchase(com.scb.channels.base.vo.BillerPayRequestVO)
	 */
	@Override
	public BillerPayResponseVO authorizeCardPurchaseTransaction(BillerPayRequestVO billerPayRequest) {
		LOGGER.info("CardAuthPurchaseTxnServiceImpl ::: authorizeC400CardPurchase ::: start");
		BillerPayResponseVO billerPayResponseVO = null;
		BillerPayDetailsVO billpayDetails = billerPayRequest.getBillerPayDetailsVO();
		BigDecimal amount = null;
		SCBMLHeaderType header = null;
		AuthorizeCardPurchaseTransactionRes authorizeCardResponseC400 = null;
		try {
			LOGGER.info("Card Authorization request : authorizeC400CardPurchase : from {} for {} in {} as {}",
				new Object[] { billerPayRequest.getUser().getCountry(),
						billerPayRequest.getUser().getCustomerId(),
						billerPayRequest.getUser().getChannelId(),
						billerPayRequest.getMessageVO().getReqID() });
			
			//billpayDetails.setChannel(CommonConstants.DOMAIN_TYPE); // --mapped in dozer
				
			amount = billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ? billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
			String strAmount = CreditCardC400MappingHelper.getConvertedStrAmount(amount);
			LOGGER.info("CardAuthPurchaseTxnServiceImpl ::: authorizeC400CardPurchase : amount and converted amount: "+ amount+" :"+ strAmount);
			billpayDetails.getTransactionInfoVO().getSrcAccountVO().setAmount(new BigDecimal(strAmount)); // set amount 
			
			//dozer mapping
			AuthorizeCardPurchaseTransactionReq authorizeCardRequestC400 = CreditCardC400MappingHelper.getCardAuthorizationRequestC400(billerPayRequest);
			
			String paymentSubType = "";
			
			//populate optional fields
			populateC400CardAuthOptionalFields(authorizeCardRequestC400, billpayDetails);
			
			// cash advance - overriding MsgFctn and TxTp values
			if(billpayDetails !=null && billpayDetails.getPaymentSubType() != null ){
				paymentSubType = billpayDetails.getPaymentSubType();
				LOGGER.info("paymentSubType: cashAdvance or cardAuth ? : "+ paymentSubType);
				if(CommonConstants.CASH_ADV_REQ.equalsIgnoreCase(paymentSubType) ){
					LOGGER.info("Received CASHADVANCE Request :: setting TxTp as CHWD: "+billpayDetails.getPayRef());
					//authorizeCardPurchaseTransactionReqPayload.authorizeCardPurchaseTransactionReq.document.acqrrAuthstnInitn.authstnInitn.tx.txTp
					authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getTx().setTxTp(CardPaymentServiceType7Code.CHWD);
				} 
			}
			// header
			if(authorizeCardRequestC400 != null) {
				authorizeCardRequestC400.setHeader(BillpaymentMappingHelper.populateHeader(
						billerPayRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, BillpaymentMappingHelper.getGregorianCalendar(),
						billerPayRequest.getBillerPayDetailsVO().getPayRef(), 
						CommonConstants.C400, CommonConstants.CARD_AUTHORIZATION_TRANSACTION,
						CommonConstants.CARD_AUTHORIZATION_TRANSACTION,CommonConstants.CREDIT_CARD_AUTH,
						CommonConstants.DOMAIN_NAME));
				//Message Version 2.0
				MessageDetailsType messageDetails = authorizeCardRequestC400.getHeader().getMessageDetails();
				messageDetails.setMessageVersion(new BigDecimal(CommonConstants.TWO_DECIMAL));
				// override sub-domain type value
				SubDomainName subDomainName = authorizeCardRequestC400.getHeader().getOriginationDetails().getMessageSender().getSenderDomain().getSubDomainName();
				subDomainName.setSubDomainType(CommonConstants.CREDIT_CARD);
			}
			
			
			LOGGER.info("Obtained card authorization object : authorizeC400CardPurchase : " +	billpayDetails.getPayRef());
			
			billpayDetails.setHostName(CommonConstants.C400 + CommonConstants.SPACE_HYPHEN_SPACE + CommonConstants.CARD_AUTHORIZATION_TRANSACTION);
			
			authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().setPayloadFormat(PayloadFormatEnum.XML); // format
			authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().setPayloadVersion(CommonConstants.TWO_DECIMAL); // version
			
			//utility code
			SupplementaryType supplementaryData = authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getAuthorizationSupplementary().getSupplementaryData();
			supplementaryData.setUtilityCode(getCardUtilityCode(billpayDetails));
			
			/*String str = CommonHelper.getXML(authorizeCardRequestC400, 
					AuthorizeCardPurchaseTransactionReq.class, "authorizeCardPurchaseTransaction");
			System.out.println(str);*/
			
			/*String mockEnabled = dataBean.getMap().get(billpayDetails.getCountryCode() + "authorizeC400CardPurchase_MockEnabled");
			if(mockEnabled != null && mockEnabled.equalsIgnoreCase("YES") && !CommonHelper.getJVMName().contains("PRD")) {
				//authorizeCardResponseC400 = creditCardC400ServiceClient.authorizeCardPurchaseTransaction(authorizeCardRequestC400);
			} else {
				authorizeCardResponseC400 = creditCardC400ServiceClient.authorizeCardPurchaseTransaction(authorizeCardRequestC400);
			}*/
			
			LOGGER.info("authorizeCardPurchaseTransaction : BEFORE POSTING TO EDMI "+billpayDetails.getPayRef());
			authorizeCardResponseC400 = creditCardC400ServiceClient.authorizeCardPurchaseTransaction(authorizeCardRequestC400);
			LOGGER.info("authorizeCardPurchaseTransaction : AFTER POSTING TO EDMI "+billpayDetails.getPayRef());		
			

			/*String resstr = CommonHelper.getXML(authorizeCardResponse, 
					AuthorizeCardPurchaseTransactionRes.class, "authorizeCardPurchaseTransactionResponse");
			System.out.println(resstr);*/
			
			if (authorizeCardResponseC400 !=null && authorizeCardResponseC400.getHeader() !=null && authorizeCardResponseC400.getHeader().getExceptions() != null) {
				billerPayResponseVO = new BillerPayResponseVO();
				
				// Check if there is any exception from eBBS response
				for (ExceptionType exceptionType : authorizeCardResponseC400.getHeader().getExceptions().getException()) {
					LOGGER.info("Exceptions present in card authorize response : authorizeC400CardPurchase :: reqId: {} :: exception Code: {} :: exception Desc : "+	
								new Object[] {billpayDetails.getPayRef(), exceptionType.getCode().getValue(), exceptionType.getDescription()});
					
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
					billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.setStatusDesc(exceptionType.getDescription());
					billerPayResponseVO.setStatus(exceptionType.getCode().getValue());
					
					billpayDetails.getTransactionInfoVO().setHostRespCd(exceptionType.getCode().getValue());
					billpayDetails.getTransactionInfoVO().setHostRespDesc(exceptionType.getDescription());
				
					break;
				} 
			} else {
				
				/*if(mockEnabled != null && mockEnabled.equalsIgnoreCase("YES") && !CommonHelper.getJVMName().contains("PRD")) {
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setAuthCode("CA2132");//TODO Mocked response code
					billerPayResponseVO.setStatus("00000"); //TODO Mocked response status
					
				} else {
					billerPayResponseVO = CreditCardC400MappingHelper.getCardAuthorizationResponseC400(authorizeCardResponseC400);
				}*/
				
				billerPayResponseVO = CreditCardC400MappingHelper.getCardAuthorizationResponseC400(authorizeCardResponseC400);
				LOGGER.info("Obtained payload response from Card response : authorizeC400CardPurchase :: " + billpayDetails.getPayRef());
				String status = null;
				String description = null;
				status = (billerPayResponseVO.getStatus() !=null)?billerPayResponseVO.getStatus():"";
				description = (billerPayResponseVO.getStatusDesc() !=null)?	billerPayResponseVO.getStatusDesc() :""; 
				if (billerPayResponseVO != null && billerPayResponseVO.getAuthCode() != null) {
					if (status != null && status.equals(CommonConstants._00000)) {  
						LOGGER.info("Credit card authentication success : authorizeC400CardPurchase :: "+ billpayDetails.getPayRef());
						billpayDetails.setAuthCode(billerPayResponseVO.getAuthCode());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);
					} else {
						LOGGER.info("Credit card authentication failure : authorizeC400CardPurchase :: "+ billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
					}
				} else{
					LOGGER.info("Credit Card Authcode not received : Setting status to CCAUTFAIL: " +billpayDetails.getPayRef());
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);	
				}
				billpayDetails.getTransactionInfoVO().setHostRespCd(status);
				billpayDetails.getTransactionInfoVO().setHostRespDesc(description);
				
				LOGGER.info("Card Authorization Response for request id:{}, :: {} :: {}", 
					new Object[] {billerPayRequest.getMessageVO().getReqID()
						, billpayDetails.getTransactionInfoVO().getHostRespCd(),
						billpayDetails.getTransactionInfoVO().getHostRespDesc()});
				
			}
		}catch (Exception exception) {
			LOGGER.error("Credit card authentication Exception :: req Id: {}, :: exception: {}", 
					new Object[] {billpayDetails.getPayRef(), exception});
			LOGGER.info("Setting txnActStatus to CCAUTTMOT: "+billpayDetails.getPayRef());
			billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
			billpayDetails.getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billpayDetails.getTransactionInfoVO().setHostRespDesc(exception.getMessage());
			
		} finally {
			if(billerPayResponseVO == null){
				billerPayResponseVO = new BillerPayResponseVO();
			}
			billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
		}
		
		LOGGER.info("CardAuthPurchaseTxnServiceImpl ::: authorizeCreditCard ::: End");
		return billerPayResponseVO;
	}
	
	/**
	 * Method to getCardUtilityCode 
	 */
	private String getCardUtilityCode(BillerPayDetailsVO billerPayDetails){
		LOGGER.info("Getting cardUtilityCode for "+billerPayDetails.getPayRef());
		BillerCatgegoryReference billerCategoryReference = paymentCommonService.getBillerCategoryReference(billerPayDetails.getBillerCategoryCd(),	billerPayDetails.getBillerCd(),	billerPayDetails.getCountryCode());
		String cardUtilityCode = "";
		if(billerCategoryReference != null){
			cardUtilityCode = billerCategoryReference.getCardUtilityCode();
			LOGGER.info("getCardUtilityCode for the biller: "+billerPayDetails.getBillerCd() +" cardUtilityCod : " +cardUtilityCode);
		} else {
			LOGGER.info("getCardUtilityCode: received billerCategoryReference is null for the combination ::: "
					+ " agg category code ::: " + billerPayDetails.getBillerCategoryCd()
					+ " agg biller code ::: " + billerPayDetails.getBillerCd()
					+ " country code ::: " + billerPayDetails.getCountryCode());
		}
		return cardUtilityCode;
	}
	
	

	/**
	 * Card Auth Reuqest Optional Fields
	 * @param authorizeCardRequestC400
	 */
	private void populateC400CardAuthOptionalFields(AuthorizeCardPurchaseTransactionReq authorizeCardRequestC400, BillerPayDetailsVO billerPayDetails) {
		AcquirerAuthorisationInitiation1 authstnInitn = authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn();
		CardTransactionEnvironment1 envt = authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt();
		GenericIdentification32 id = new GenericIdentification32();
		PaymentCard12 card = authorizeCardRequestC400.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt().getCard();
		EnvelopedData4 envlpdData =  new EnvelopedData4();
		List<Recipient4Choice> rcpt = new ArrayList<Recipient4Choice>();
		List<CardholderAuthentication7> authntcn = new ArrayList<CardholderAuthentication7>();
		KeyTransport4 keyTrnsprt = new KeyTransport4();
		Recipient5Choice rcptId =  new Recipient5Choice();
		KEKIdentifier2 keyIdr = new KEKIdentifier2();
		AlgorithmIdentification11 keyNcrptnAlgo = new AlgorithmIdentification11();
		AlgorithmIdentification13 keyNcrptnAlgo13 = new AlgorithmIdentification13();
		Cardholder9 crdhldr = new Cardholder9();
		CardholderAuthentication7 cardholderAuthentication7 = new CardholderAuthentication7();
		OnLinePIN4 crdhldrOnLinePIN = new OnLinePIN4();
		
		//Relative Distinguished Name Attribute Type and value
		IssuerAndSerialNumber1 issrAndSrlNb = new IssuerAndSerialNumber1();
		CertificateIssuer1 issr = new CertificateIssuer1();
		Recipient4Choice reciptChoice = new Recipient4Choice();
		KEK4 kek4= new KEK4();
		KEKIdentifier2 kekId = new KEKIdentifier2();
		KEKIdentifier2 keyIdr2 = new KEKIdentifier2();
		EncryptedContent3 ncrptdCntt = new EncryptedContent3();
		AlgorithmIdentification14 cnttNcrptnAlgo = new AlgorithmIdentification14(); 
		ContentInformationType10 ncrptdPINBlck = new ContentInformationType10();
		CardTransactionContext1 cntxt = new CardTransactionContext1();
		CardTransactionContext2 txCntxt = new CardTransactionContext2();
		Acquirer6 acqrr = new Acquirer6();
		acqrr.setId(CommonConstants.EMPTY); //AcqInstID
		acqrr.setCtryCd(billerPayDetails.getCountryCode()); //AcqCountryCode
		envt.setAcqrr(acqrr);
		
		Organisation18 accptr = envt.getAccptr();
		GenericIdentification32 id2 = new GenericIdentification32();
		id2.setId(CommonConstants.EMPTY);//Card Acceptor Identification Code or MerchantID - blanks as expected at C400
		accptr.setId(id2);
		
		String billerName  = billerPayDetails.getBillerName();
		if(billerName !=null){
			billerName = (billerName.length()>26) ? billerName.substring(0,26):billerName;
		}
		LOGGER.info("billerName:"+ billerName);	
		accptr.setCmonNm(billerName); // Card Acceptor Name or MerchantName - blanks as expected at C400
		
		List<RelativeDistinguishedName1> rltvDstngshdNm = issr.getRltvDstngshdNm();
		RelativeDistinguishedName1 relativeDistinguishedName1 = new RelativeDistinguishedName1();
		relativeDistinguishedName1.setAttrTp(AttributeType1Code.CNAT); //Relative Distinguished Name Attribute Type
		relativeDistinguishedName1.setAttrVal(CommonConstants.DEFAULT); //Relative Distinguished Name Attribute Value
		rltvDstngshdNm.add(relativeDistinguishedName1); 
		
		byte[] byteZero =  {0};
		issrAndSrlNb.setSrlNb(byteZero);
		issrAndSrlNb.setIssr(issr);
		keyIdr.setKeyId(CommonConstants.DEFAULT); //KEKIdentifier2 - Key Identifier
		keyIdr.setKeyVrsn(CommonConstants.DEFAULT); //KEKIdentifier2 - Key Version 
		rcptId.setKeyIdr(keyIdr);
		rcptId.setIssrAndSrlNb(issrAndSrlNb);
		keyTrnsprt.setRcptId(rcptId);
		
		keyNcrptnAlgo.setAlgo(Algorithm7Code.ERSA);//AlgorithmIdentification11 - Algorithim used
		keyTrnsprt.setKeyNcrptnAlgo(keyNcrptnAlgo);

		reciptChoice.setKeyTrnsprt(keyTrnsprt); 

		keyNcrptnAlgo13.setAlgo(Algorithm13Code.EA_2_C);// AlgorithmIdentification13	- Algorithim used
		kek4.setKeyNcrptnAlgo(keyNcrptnAlgo13);
		kek4.setNcrptdKey(byteZero); // Encrypted Key
		kekId.setKeyId(CommonConstants.DEFAULT); //KEKIdentifier2 - Key Identifier
		kekId.setKeyVrsn(CommonConstants.DEFAULT); // KEKIdentifier2 - Key Version
		kek4.setKEKId(kekId);
		
		reciptChoice.setKEK(kek4);
		
		keyIdr2.setKeyId(CommonConstants.DEFAULT); // KEKIdentifier2 - Key Identifier
		keyIdr2.setKeyVrsn(CommonConstants.DEFAULT);// KEKIdentifier2 - Key Version
		
		reciptChoice.setKeyIdr(keyIdr2);
		rcpt.add(reciptChoice);
		
		cnttNcrptnAlgo.setAlgo(Algorithm15Code.EA_2_C);//AlgorithmIdentification14 - Algorithim Used
		ncrptdCntt.setCnttNcrptnAlgo(cnttNcrptnAlgo);
		envlpdData.setNcrptdCntt(ncrptdCntt);
		envlpdData.getRcpt().addAll(0, rcpt);
		ncrptdPINBlck.setCnttTp(ContentType2Code.AUTH); // ContentInformationType10 - Content Type
		ncrptdPINBlck.setEnvlpdData(envlpdData);
		crdhldrOnLinePIN.setNcrptdPINBlck(ncrptdPINBlck); // 
		crdhldrOnLinePIN.setPINFrmt(PINFormat3Code.ISO_0);
		cardholderAuthentication7.setAuthntcnMtd(AuthenticationMethod5Code.TOKP); // Authentication Method
		cardholderAuthentication7.setCrdhldrOnLinePIN(crdhldrOnLinePIN);
		authntcn.add(cardholderAuthentication7);
		crdhldr.getAuthntcn().addAll(0, authntcn);
		
		txCntxt.setCardDataNtryMd(CardDataReading2Code.PHYS);//Card Data Entry Mode
		cntxt.setTxCntxt(txCntxt);
		
		// Retrieve TxnAmt and currency and set the same for 1. SettlementAmt 2. BillingAmt
		CardTransactionDetail1 txDtls = authstnInitn.getTx().getTxDtls();
		CardTransactionAmount1 txAmts = txDtls.getTxAmts();
		CurrencyAndAmount ttlAmt  = txAmts.getTtlAmt();
		
		//1. SettlementAmt
		//List<DetailedAmount10> addtlAmts = txDtls.getAddtlAmts();
		DetailedAmount10 detailAmt = new DetailedAmount10();
		detailAmt.setAmt(ttlAmt);
		detailAmt.setAddtlTp(CommonConstants.SETTLEMENT_AMT);
		txDtls.getAddtlAmts().add(detailAmt);
		
		//TransactionFee
		DetailedAmount10 txrnFee = new DetailedAmount10();
		txrnFee.setAmt(ttlAmt);
		txrnFee.setAddtlTp(CommonConstants.TRANSACTION_FEE);
		txrnFee.setLabl(CommonConstants.TRANSACTION_FEE);
		txDtls.getAddtlAmts().add(txrnFee);
		
		//2. Billing Amt
		//AcqrrAuthstnInitn/AuthstnInitn/Tx/TxDtls/TxAmts/CrdhldrBllgTxAmt/Amt
		DetailedAmount8 crdhldrBllgTxAmt = new DetailedAmount8();
		crdhldrBllgTxAmt.setAmt(ttlAmt.getValue()); // txn amt as billing amt
		crdhldrBllgTxAmt.setXchgRate(new BigDecimal(1)); //default exchange rate is 1
		txAmts.setCrdhldrBllgTxAmt(crdhldrBllgTxAmt);
		
		card.setCardCcyCd(ttlAmt.getCcy()); //txn ccy as billing ccy
		
		authstnInitn.getTx().setMrchntCtgyCd(CommonConstants.EMPTY);//Merchant Category Code (MCC)

		CardAccount1 acctTo = new CardAccount1();
		AccountIdentification30Choice acctIdr = new AccountIdentification30Choice();
		acctIdr.setBBAN(CommonConstants.EMPTY);// Account number or BBAN
		acctTo.setAcctIdr(acctIdr);
		txDtls.setAcctTo(acctTo);
		
		envt.setCard(card);
		envt.setCrdhldr(crdhldr);
		authstnInitn.setEnvt(envt);
		authstnInitn.setCntxt(cntxt);
	}
	
	
	/* Method to authorize Reverse Card Purchase transaction
	 * (non-Javadoc)
	 * @see com.scb.channels.payments.service.CreditCardService#reverseC400CardPurchase(com.scb.channels.base.vo.BillerPayRequestVO)
	 */
	public BillerPayResponseVO reverseCardPurchaseTransaction(BillerPayRequestVO billerPayRequest) {

		LOGGER.info("CardAuthPurchaseTxnServiceImpl ::: reverseC400CardPurchase ::: start");
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();;
		BillerPayDetailsVO billpayDetails = billerPayRequest.getBillerPayDetailsVO();
		BigDecimal amount = null;
		ReverseCardPurchaseTransactionRes reverseAuthorizeCardResponseC400 = null;
		try {
			LOGGER.info("Card Authorization reversal request : reverseC400CardPurchase : from {} for {} in {} as {}",
					new Object[] { billerPayRequest.getUser().getCountry(),
							billerPayRequest.getUser().getCustomerId(),
							billerPayRequest.getUser().getChannelId(),
							billerPayRequest.getMessageVO().getReqID() });
			
			//billpayDetails.setChannel("IBK"); 
			
			LOGGER.info("Currency conversion :::: " +	billpayDetails.getPayRef());
			
			amount = billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() != null ?
				billpayDetails.getTransactionInfoVO().getSrcAccountVO().getAmount() : new BigDecimal(CommonConstants.ZERO);
			
            String strAmount = CreditCardC400MappingHelper.getConvertedStrAmount(amount);// call get converted amount
            
		    billpayDetails.getTransactionInfoVO().getSrcAccountVO().setAmount(new BigDecimal(strAmount));
			
			ReverseCardPurchaseTransactionReq reverseAuthorizeCardRequestC400 = CreditCardC400MappingHelper.getReverseCardAuthorizationRequestC400(billerPayRequest);
			LOGGER.info("Obtained card authorization reversal object: reverseC400CardPurchase :  " +	billpayDetails.getPayRef());
			
			String revPaymentSubType = "";
			if(billpayDetails != null && billpayDetails.getPaymentSubType() != null){
				revPaymentSubType = billpayDetails.getPaymentSubType();
				LOGGER.info("revPaymentSubType: cashAdvance or cardAuth ? : "+ revPaymentSubType);
				if(CommonConstants.CASH_ADV_REQ.equalsIgnoreCase(revPaymentSubType)){
					LOGGER.info("Received CASHADVANCE REVERSAL Request :: setting TxTp as CHWD: "+billpayDetails.getPayRef());
					//reverseCardPurchaseTransactionReqPayload.reverseCardPurchaseTransactionReq.document.acqrrRvslInitn.rvslInitn.tx.txTp				
					reverseAuthorizeCardRequestC400.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getTx().setTxTp(iso.std.iso._20022.tech.xsd.cain_005_001.CardPaymentServiceType7Code.CHWD);
				}
			}
			
			if(reverseAuthorizeCardRequestC400 != null) {
				reverseAuthorizeCardRequestC400.setHeader(BillpaymentMappingHelper.populateHeader(
						billerPayRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, BillpaymentMappingHelper.getGregorianCalendar(),
						billerPayRequest.getBillerPayDetailsVO().getPayRef(), 
						CommonConstants.C400, CommonConstants.REVERSE_CARD_AUTHORIZATION_TRANSACTION,
						CommonConstants.REVERSE_CARD_AUTHORIZATION_TRANSACTION,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
				//Message Version 2.0
				MessageDetailsType messageDetails = reverseAuthorizeCardRequestC400.getHeader().getMessageDetails();
				messageDetails.setMessageVersion(new BigDecimal(CommonConstants.TWO_DECIMAL));
				//SubDomainType
				SubDomainName subDomainName = reverseAuthorizeCardRequestC400.getHeader().getOriginationDetails().getMessageSender().getSenderDomain().getSubDomainName();
				subDomainName.setSubDomainType(CommonConstants.CREDIT_CARD);
			}
			LOGGER.info("Obtained header populated for card reversal : reverseC400CardPurchase: " +	billpayDetails.getPayRef());

			billpayDetails.setHostName(CommonConstants.C400 + CommonConstants.SPACE_HYPHEN_SPACE + CommonConstants.REVERSE_CARD_AUTHORIZATION_TRANSACTION);

			// payload version and format
			ReverseCardPurchaseTransactionReqPayload reverseCardPurchaseTransactionReqPayload = reverseAuthorizeCardRequestC400.getReverseCardPurchaseTransactionReqPayload();
			reverseCardPurchaseTransactionReqPayload.setPayloadFormat(PayloadFormatEnum.XML);
			reverseCardPurchaseTransactionReqPayload.setPayloadVersion(CommonConstants.TWO_DECIMAL);
			
			AuthorizationSupplementary authorizationSupplementary = reverseCardPurchaseTransactionReqPayload.getReverseCardPurchaseTransactionReq().getAuthorizationSupplementary();
			//originalMessageType = lookUp value of original MsgTypId + STAN + OriginalTransactionDateTime + orgAcquiringInst + orgForwardingInst
			//LOGGER.info("billpayDetails.toString(): "+billpayDetails.toString());
			LOGGER.info("billpayDetails.getPaymentDetailsVO().toString(): "+billpayDetails.getTransactionInfoVO().toString());
			String originalMessageType = CreditCardC400MappingHelper
					.populateOrgMessageType(CommonConstants.FNCQ_LOOKUP_VALUE,
							billpayDetails.getStan(),
							billpayDetails.getTransactionInfoVO().getDtProcessed(),
							CommonConstants.ELEVEN_SPACES,
							CommonConstants.ELEVEN_SPACES);
			authorizationSupplementary.getSupplementaryData().setOriginalMessageType(originalMessageType);
			
			/*String str = CommonHelper.getXML(payBillReq, PayBillReq.class,
					PayBillReq.class.getSimpleName());
			System.out.println(str);*/
			
			CardTransactionDetail5 txDtls = reverseCardPurchaseTransactionReqPayload.getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getTx().getTxDtls();
			List<MessageReason1Code> msgRsn = new ArrayList<MessageReason1Code>();
			msgRsn.add(MessageReason1Code.COFF);
			txDtls.getMsgRsn().addAll(msgRsn);//msgRsn
			
			CardTransactionEnvironment3 envt = reverseCardPurchaseTransactionReqPayload.getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getEnvt();
			Organisation19 accptr = new Organisation19();
			iso.std.iso._20022.tech.xsd.cain_005_001.GenericIdentification32 id = new iso.std.iso._20022.tech.xsd.cain_005_001.GenericIdentification32();
			id.setId(CommonConstants.EMPTY);//Acceptor Id	Merchant Id
			accptr.setId(id);
			accptr.setCmonNm(CommonConstants.EMPTY);// Acceptor Name - blank as expected by c400
			envt.setAccptr(accptr);
			
			// Mocked response
/*			String mockEnabled = dataBean.getMap().get(billpayDetails.getCountryCode() + "authorizeC400CardPurchase_MockEnabled");
			if(mockEnabled != null && mockEnabled.equalsIgnoreCase("YES") && !CommonHelper.getJVMName().contains("PRD")) {
				//reverseAuthorizeCardResponseC400 = creditCardC400ServiceClient.reverseCardPurchaseTransaction(reverseAuthorizeCardRequestC400);
				reverseAuthorizeCardResponseC400 = new ReverseCardPurchaseTransactionRes();
				ReverseCardPurchaseTransactionResPayload resPayload = new ReverseCardPurchaseTransactionResPayload();
				ReverseCardPurchaseTransactionResData resData = new ReverseCardPurchaseTransactionResData();
				AuthorizationSupplementary authSupp = new AuthorizationSupplementary();
				SupplementaryType suppType  = new SupplementaryType();
				suppType.setResponseCode("00000");
				authSupp.setSupplementaryData(suppType);
				resData.setAuthorizationSupplementary(authSupp);
				resPayload.setReverseCardPurchaseTransactionRes(resData);
				reverseAuthorizeCardResponseC400.setReverseCardPurchaseTransactionResPayload(resPayload);
			} else {
				reverseAuthorizeCardResponseC400 = creditCardC400ServiceClient.reverseCardPurchaseTransaction(reverseAuthorizeCardRequestC400);
			}
*/			
			LOGGER.info("reverseCardPurchaseTransaction : BEFORE POSTING TO EDMI" + billpayDetails.getPayRef());
			reverseAuthorizeCardResponseC400 = creditCardC400ServiceClient.reverseCardPurchaseTransaction(reverseAuthorizeCardRequestC400);
			LOGGER.info("reverseCardPurchaseTransaction : AFTER POSTING TO EDMI "+billpayDetails.getPayRef());
			
			if (reverseAuthorizeCardResponseC400 !=null && reverseAuthorizeCardResponseC400.getHeader() !=null && reverseAuthorizeCardResponseC400.getHeader().getExceptions() != null) {

				// Check if there is any exception from C400 response
				for (ExceptionType exceptionType : reverseAuthorizeCardResponseC400.getHeader().getExceptions().getException()) {
					
					LOGGER.info("Exceptions present in card authorize reversal response : reverseC400CardPurchase :: refId: {} :: exception Code: {} :: exception Desc : "+	
							new Object[] {billpayDetails.getPayRef(), exceptionType.getCode().getValue(), exceptionType.getDescription()});
					
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
					billpayDetails.getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
					
					billerPayResponseVO.setStatusDesc(exceptionType.getDescription());
					billerPayResponseVO.setStatus(exceptionType.getCode().getValue());
					
					billpayDetails.getTransactionInfoVO().setHostRespCd(exceptionType.getCode().getValue());
					billpayDetails.getTransactionInfoVO().setHostRespDesc(exceptionType.getDescription());
				
					billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
					
					break;
				} 
			} else {
				billerPayResponseVO = CreditCardC400MappingHelper.getReverseCardAuthorizationResponseC400(reverseAuthorizeCardResponseC400);
				LOGGER.info("Obtained payload response from Card reversal response : reverseC400CardPurchase :: " + billpayDetails.getPayRef());

				String status = null;
				String description = null;
				
				if(billerPayResponseVO != null && billerPayResponseVO.getStatus() != null) {
					status = billerPayResponseVO.getStatus();
					description = (billerPayResponseVO.getStatusDesc() !=null)?	billerPayResponseVO.getStatusDesc() :""; 

					if(status != null && status.equals(CommonConstants._00000)) {
						LOGGER.info("Credit card reverse authentication success : reverseC400CardPurchase :: " + billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);
					} else {
						LOGGER.info("Credit card reverse authentication failure : reverseC400CardPurchase :: " + billpayDetails.getPayRef());
						billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
					}
					billpayDetails.getTransactionInfoVO().setHostRespCd(status);
					billpayDetails.getTransactionInfoVO().setHostRespDesc(description);
				} else {
					// status not received from C400 - setting value to fail
					LOGGER.info("Status NOT AVAILABLE for Card Auth reversal response: Setting status to AUTREVFAIL" +billpayDetails.getPayRef());
					billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
					billpayDetails.getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
					billpayDetails.getTransactionInfoVO().setHostRespDesc("Status not received");//TODO
				}
				
				LOGGER.info("Card Authorization reverseC400CardPurchase reversal Response for request id:{}, :: {} :: {}", 
					new Object[] {billerPayRequest.getMessageVO().getReqID(), 
						billpayDetails.getTransactionInfoVO().getHostRespCd(),
						billpayDetails.getTransactionInfoVO().getHostRespDesc()});
				
			}
		} catch (Exception exception) {
			LOGGER.error("Exception in card reversal : Setting status to FAILURE :: ", exception);
			billpayDetails.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
			billpayDetails.getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billpayDetails.getTransactionInfoVO().setHostRespDesc(exception.getMessage());
		} finally {
			billerPayResponseVO.setBillerPayDetailsVO(billpayDetails);
		}
		//LOGGER.info("reverseCardPurchaseTransaction: billpayDetails.toString() :  "+billpayDetails.toString());
		LOGGER.info("CardAuthPurchaseTxnServiceImpl ::: reverseC400CardPurchase ::: End");
		return billerPayResponseVO;
	}
	
	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
	
	/**
	 * @param creditCardC400ServiceClient
	 */
	public void setCreditCardC400ServiceClient(
			CreditCardAuthorizationPortType creditCardC400ServiceClient) {
		this.creditCardC400ServiceClient = creditCardC400ServiceClient;
	}

	
}
