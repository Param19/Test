package com.scb.channels.qrpayments.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.vo.QRMerchantVO;
import com.scb.channels.qrpayments.dao.MerchantDAO;

public class MerchantDAOImpl extends HibernateDaoSupport implements MerchantDAO{

	@Override
	public void savePayment(QRMerchantVO merchantVO) {
		
		Session session = null;
		Transaction transaction = null;
		try{
			System.out.println("Inside the MerchantDAOImpl>>>>>>>>>>>"+merchantVO);
			session = getHibernateTemplate().getSessionFactory().openSession();
			transaction = session.beginTransaction();
			session.save(merchantVO);
			transaction.commit();
			session.flush();
			session.close();
		}catch(Exception e){
			e.printStackTrace();
			transaction.rollback();
			session.close();
		}
		
	}

	@Override
	public QRMerchantVO getMerchant(QRMerchantVO merchantVO) {
		
		Session session = null;
		try{
			System.out.println("Inside the getMerchant MerchantDAOImpl>>>>>>>>>>>"+merchantVO);
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(QRMerchantVO.class);
			criteria.add(Restrictions.eq("merchant_pan", merchantVO.getMerchant_pan()));
			criteria.add(Restrictions.eq("merchant_name", merchantVO.getMerchant_name()));		
			criteria.add(Restrictions.eq("merchant_city", merchantVO.getMerchant_city()));	
			criteria.add(Restrictions.eq("merchant_postcode", merchantVO.getMerchant_postcode()));	
			merchantVO = (QRMerchantVO)criteria.uniqueResult();
		}catch(Exception e){
			e.printStackTrace();
			session.close();
		}finally {
			if(session != null && session.isOpen()) {
				System.out.println("closing the session in getApplicationMessages");
				session.close();
			}
		}
		
		return merchantVO;
	}

}
