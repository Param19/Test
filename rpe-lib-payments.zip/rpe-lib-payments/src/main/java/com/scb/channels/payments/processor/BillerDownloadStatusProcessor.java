/**
 * 
 */
package com.scb.channels.payments.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.PaymentHistoryRequestVO;
import com.scb.channels.base.vo.PaymentHistoryResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.JobManagerService;
import com.scb.channels.payments.service.PaymentService;
import com.scb.channels.paymentservice.PaymentHistoryResponse;

/**
 * @author 1470817
 * 
 */
public class BillerDownloadStatusProcessor extends AbstractProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadStatusProcessor.class);

	private JobManagerService jobManagerService;

	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.debug("In 000000000000 --> BillerDownloadStatusProcessor ");
		BillerDownloadRequest billerDownloadRequest = null;
		BillerDownloadResponseVO billerDownloadResponse = new BillerDownloadResponseVO();
		try {

			billerDownloadRequest = (BillerDownloadRequest) bean.getRequestVO();
			billerDownloadResponse = jobManagerService.getBillerDownloadStatusCheck(billerDownloadRequest);
			LOGGER.info("After getting the values from DB ------> BillerDownloadStatusProcessor "	+ billerDownloadResponse);
			//billerDownloadResponse.setStatus(Messages._150.getCode());
			//billerDownloadResponse.setStatusDesc(Messages._150.getMessage());
			
			bean.setResponseVO(billerDownloadResponse);
		} catch (Exception e) {

			LOGGER.error("Exception block at DoTask --> BillerDownloadStatusProcessor "
					+ e.getMessage());
			billerDownloadResponse.setErrorDesc(ExceptionMessages._152.getMessage());
			billerDownloadResponse.setErrorCD(ExceptionMessages._152.getCode());
		}
		return bean;

	}
	
	public JobManagerService getJobManagerService() {
		return jobManagerService;
	}

	public void setJobManagerService(JobManagerService jobManagerService) {
		this.jobManagerService = jobManagerService;
	}

}
