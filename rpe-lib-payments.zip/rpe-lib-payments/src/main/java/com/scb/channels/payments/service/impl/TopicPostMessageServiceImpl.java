package com.scb.channels.payments.service.impl;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.destination.DestinationResolver;

import com.scb.channels.payments.service.TopicPostMessageService;

public class TopicPostMessageServiceImpl implements TopicPostMessageService {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory
			.getLogger(TopicPostMessageServiceImpl.class);
	
	ConnectionFactory connectionFactory;
	ConnectionFactory connectionAlipayFactory;

	DestinationResolver destinationResolver;
	
	@Override
	public void postMessage(String message) throws JMSException, Exception {
		LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Start");
		Connection connection = null;
		Session session = null;
		
		try {
			connection = connectionFactory.createConnection();
			LOGGER.info("Connection Created" + connection.toString());
			
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			Destination destination = destinationResolver.resolveDestinationName(session, 
					"scbCashPaymentMobileInvoicePostPaymentV1ReqT", true);
			LOGGER.info("Destination Created" + destination);
			
			MessageProducer producer = session.createProducer(destination);
			TextMessage msg = session.createTextMessage(message);
			
			LOGGER.info( " :::::::::::::::::::::::::::::::::::: "
								+ msg.getText());
			producer.send(msg);
			
			LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Complete Successfully");
		} catch (JMSException jmsException) {
			LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Failed");
			LOGGER.info("JMS Exception occurred ::: " + jmsException);
			throw jmsException;
		} catch (Exception exception) {
			LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Failed");
			LOGGER.info("Exception occurred ::: " + exception);
			throw exception;
		} finally {
			LOGGER.info("Closing the jms session");
			if(session != null){
				try {
					session.close();
					session = null;
					LOGGER.info("Jms Session closed");
				} catch (JMSException e) {
					e.printStackTrace();
				}
			}
			LOGGER.info("Closing the jms connection");
			if(connection != null) {
				try {
					connection.close();
					connection = null;
					LOGGER.info("Jms Connection closed");
				} catch (JMSException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
	public void postMessage(String message, String topic) throws JMSException, Exception {
		LOGGER.info("TopicPostMessageServiceImpl ::: postMessage with Topic::: Start");
		Connection connection = null;
		Session session = null;
		
		try {
			//connection = connectionAlipayFactory.createConnection("rpeuser","abc123");
			connection = connectionAlipayFactory.createConnection();
			
			LOGGER.info("Connection Created" + connection.toString());
			
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			Destination destination = destinationResolver.resolveDestinationName(session, 
					topic, true);
			LOGGER.info("Destination Created" + destination);
			
			MessageProducer producer = session.createProducer(destination);
			TextMessage msg = session.createTextMessage(message);
			
			LOGGER.info( " :::::::::::::::::::::::::::::::::::: "
								+ msg.getText());
			producer.send(msg);
			
			LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Complete Successfully");
		} catch (JMSException jmsException) {
			LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Failed");
			LOGGER.info("JMS Exception occurred ::: " + jmsException);
			throw jmsException;
		} catch (Exception exception) {
			LOGGER.info("TopicPostMessageServiceImpl ::: postMessage ::: Failed");
			LOGGER.info("Exception occurred ::: " + exception);
			throw exception;
		} finally {
			LOGGER.info("Closing the jms session");
			if(session != null){
				try {
					session.close();
					session = null;
					LOGGER.info("Jms Session closed");
				} catch (JMSException e) {
					e.printStackTrace();
				}
			}
			LOGGER.info("Closing the jms connection");
			if(connection != null) {
				try {
					connection.close();
					connection = null;
					LOGGER.info("Jms Connection closed");
				} catch (JMSException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * @return the connectionFactory
	 */
	/*public TopicConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}


 	*//**
	 * @param connectionFactory the connectionFactory to set
	 *//*
	public void setConnectionFactory(TopicConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}
*/

	public void setConnectionAlipayFactory(ConnectionFactory connectionAlipayFactory) {
		this.connectionAlipayFactory = connectionAlipayFactory;
	}

	/**
	 * @return the destinationResolver
	 */
	public DestinationResolver getDestinationResolver() {
		return destinationResolver;
	}


	/**
	 * @param destinationResolver the destinationResolver to set
	 */
	public void setDestinationResolver(DestinationResolver destinationResolver) {
		this.destinationResolver = destinationResolver;
	}
	
	public ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

}
