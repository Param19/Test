package com.scb.channels.qrpayments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.qrpayments.service.QRPaymentTransactionService;

public class QRPaymentUpdateTransactionProcessor extends AbstractProcessor{
	
	private QRPaymentTransactionService qrPaymentTransactionService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentUpdateTransactionProcessor.class);
	
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in Payment Update processor ::: Start");
		
		QRPaymentRequestVO qrPaymentRequestVO = null;	
		QRPaymentResponseVO qrPaymentResponseVO = null;
		
		
		if (bean != null && bean.getResponseVO() != null &&  ((QRPaymentResponseVO) bean.getResponseVO()).getQrPaymentDetailVO() !=null ) {
			LOGGER.info("Response Object Available");
			
			qrPaymentResponseVO = (QRPaymentResponseVO) bean.getResponseVO();	
			qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
			LOGGER.info("Updating from response :::: " + qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference());
			/**Adding the client reference in case if its not available in responseVO obj*/
			
			if(qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference() == null)
			{
				LOGGER.info("Setting value from request vo obj to resposne vo obj -- client reference value");
				qrPaymentResponseVO.getQrPaymentDetailVO().setClient_reference(qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			}
						
			qrPaymentTransactionService.updatePaymentStatus(qrPaymentResponseVO.getQrPaymentDetailVO());
			LOGGER.info("Update complete :::: " + 	qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference());
		
		} else if (bean != null && bean.getRequestVO() != null && ((QRPaymentRequestVO) bean.getRequestVO()).getQrPaymentDetailVO() !=null ) {
			LOGGER.info("Request Object Available");
			
			qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
			
			LOGGER.info("Updating from request :::: " + qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference());
			
			qrPaymentTransactionService.updatePaymentStatus(qrPaymentRequestVO.getQrPaymentDetailVO());
			
			LOGGER.info("Update complete :::: " + qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference());
		
		} else {
			LOGGER.info("Payload does not have all the valkues for update");
			throw new BusinessException("PayloadDTO can't be empty...");
		} 
		
		LOGGER.info("Task in Payment Update processor ::: End");
		return bean;
	}

	public QRPaymentTransactionService getQrPaymentTransactionService() {
		return qrPaymentTransactionService;
	}

	public void setQrPaymentTransactionService(
			QRPaymentTransactionService qrPaymentTransactionService) {
		this.qrPaymentTransactionService = qrPaymentTransactionService;
	}
	
   
}
