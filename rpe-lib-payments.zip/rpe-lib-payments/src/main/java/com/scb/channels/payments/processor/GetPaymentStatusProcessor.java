package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.GetAlipayPaymentStatusService;
import com.scb.channels.payments.service.GetPaymentStatusService;

public class GetPaymentStatusProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(GetPaymentStatusProcessor.class);

	/** getPaymentStatusService */
	private GetPaymentStatusService getPaymentStatusService;
	
	/** getAlipayPaymentStatusService */
	private GetAlipayPaymentStatusService getAlipayPaymentStatusService;

	public PayloadDTO process(PayloadDTO bean) {
		LOGGER.info("GetPaymentStatusProcessor ::  process :: Start");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
		PayloadDTO payloadDTO = new PayloadDTO(); 
		BillerPayDetailsVO billerPayDetailsVO = null;
		try {
			if (billerPayRequestVO != null) {
				billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
					LOGGER.info("GetPaymentStatusProcessor :: Before hitting edmi service");
					billerPayResponseVO = getPaymentStatusService.getPaymentStatus(billerPayRequestVO);
					LOGGER.info("GetPaymentStatusProcessor :: After getting response from edmi service");
				    payloadDTO.setRequestVO(billerPayRequestVO);
				    payloadDTO.setResponseVO(billerPayResponseVO);
			}

		} catch (Exception e) {
			billerPayResponseVO = new BillerPayResponseVO();
			
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			
			billerPayResponseVO.setStatus(ExceptionMessages._129.getCode());
			billerPayResponseVO.setStatusDesc(ExceptionMessages._129.getMessage());
			if(billerPayDetailsVO != null) {
				LOGGER.info("Setting billerPaydetails to response from request in exception :: " 
						+ billerPayDetailsVO.getPayRef());
				billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
			}
		    payloadDTO.setRequestVO(billerPayRequestVO);
			payloadDTO.setResponseVO(billerPayResponseVO);
			LOGGER.info("GetPaymentStatusProcessor :: Process :: ",e.getMessage());
			LOGGER.error("GetPaymentStatusProcessor :: Process Exception :: ",e);
		}
		LOGGER.info("GetPaymentStatusProcessor :: Process :: END");
		return payloadDTO;
	}
	
	// Added for Alipay - start
	
	public PayloadDTO alipayProcess(PayloadDTO bean) {
		LOGGER.info("GetPaymentStatusProcessor ::  alipayProcess :: Start");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
		PayloadDTO payloadDTO = new PayloadDTO(); 
		BillerPayDetailsVO billerPayDetailsVO = null;
		try {
			if (billerPayRequestVO != null) {
				billerPayDetailsVO = billerPayRequestVO.getBillerPayDetailsVO();
					LOGGER.info("GetPaymentStatusProcessor :: alipayProcess :: Before hitting edmi service");
					billerPayResponseVO = getAlipayPaymentStatusService.getAlipayPaymentStatus(billerPayRequestVO);
					LOGGER.info("GetPaymentStatusProcessor :: alipayProcess :: After getting response from edmi service");
				    payloadDTO.setRequestVO(billerPayRequestVO);
				    payloadDTO.setResponseVO(billerPayResponseVO);
			}

		} catch (Exception e) {
			billerPayResponseVO = new BillerPayResponseVO();
			
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			
			billerPayResponseVO.setStatus(ExceptionMessages._129.getCode());
			billerPayResponseVO.setStatusDesc(ExceptionMessages._129.getMessage());
			if(billerPayDetailsVO != null) {
				LOGGER.info("Setting billerPaydetails to response from request in exception - alipayProcess :: " 
						+ billerPayDetailsVO.getPayRef());
				billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
			}
		    payloadDTO.setRequestVO(billerPayRequestVO);
			payloadDTO.setResponseVO(billerPayResponseVO);
			//LOGGER.info("GetPaymentStatusProcessor :: alipayProcess :: ",e.getMessage());
			LOGGER.error("GetPaymentStatusProcessor :: alipayProcess Exception :: ",e);
		} finally {
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			
			if(billerPayResponseVO.getBillerPayDetailsVO() != null && 
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
				LOGGER.info("Setting the aggregator response status details to host response list in alipay reversal" + 
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
				
				HostResponseVO hostResponse = new HostResponseVO();
				hostResponse.setCode(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
				hostResponse.setDesc(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
				hostResponse.setHostName(billerPayResponseVO.getBillerPayDetailsVO().getHostName());
				
				billerPayRequestVO.getHostResponseVO().add(hostResponse);
			}
			
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			bean.setResponseVO(billerPayResponseVO);
		}
		LOGGER.info("GetPaymentStatusProcessor :: alipayProcess :: END");
		return payloadDTO;
	}
	
	// Added for Alipay - end

	/**
	 * @return the getPaymentStatusService
	 */
	public GetPaymentStatusService getGetPaymentStatusService() {
		return getPaymentStatusService;
	}

	/**
	 * @param getPaymentStatusService the getPaymentStatusService to set
	 */
	public void setGetPaymentStatusService(GetPaymentStatusService getPaymentStatusService) {
		this.getPaymentStatusService = getPaymentStatusService;
	}

	
	public GetAlipayPaymentStatusService getGetAlipayPaymentStatusService() {
		return getAlipayPaymentStatusService;
	}

	public void setGetAlipayPaymentStatusService(
			GetAlipayPaymentStatusService getAlipayPaymentStatusService) {
		this.getAlipayPaymentStatusService = getAlipayPaymentStatusService;
	}
	
}
