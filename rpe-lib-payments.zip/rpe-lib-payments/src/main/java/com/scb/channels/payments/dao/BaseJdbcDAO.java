package com.scb.channels.payments.dao;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public abstract class BaseJdbcDAO
{
  private int maxRows = 100;
  protected JdbcTemplate jdbcTemplate;
  private DataSource dataSource;
  private int timeout = 30;

  public void setDataSource(DataSource paramDataSource)
  {
    this.dataSource = paramDataSource;
    this.jdbcTemplate = new JdbcTemplate(paramDataSource);
    this.jdbcTemplate.setMaxRows(this.maxRows);
    this.jdbcTemplate.setQueryTimeout(this.timeout);
  }

  public DataSource getDataSource()
  {
    return this.dataSource;
  }

  public JdbcTemplate getJdbcTemplate()
  {
    return this.jdbcTemplate;
  }

  public void setJdbcTemplate(JdbcTemplate paramJdbcTemplate)
  {
    this.jdbcTemplate = paramJdbcTemplate;
  }

  public int getMaxRows()
  {
    return this.maxRows;
  }

  public void setMaxRows(int paramInt)
  {
    this.maxRows = paramInt;
  }

  public int getTimeout()
  {
    return this.timeout;
  }

  public void setTimeout(int paramInt)
  {
    this.timeout = paramInt;
  }

  public JdbcTemplate getNewJdbcTemplate()
  {
    JdbcTemplate localJdbcTemplate = new JdbcTemplate(this.dataSource);
    this.jdbcTemplate.setMaxRows(this.maxRows);
    this.jdbcTemplate.setQueryTimeout(this.timeout);
    return localJdbcTemplate;
  }
}