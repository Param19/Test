package com.scb.channels.qrpayments.service;

import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;

public interface QRDebitCardService {
	
	public QRPaymentResponseVO authorizeDebitCard(QRPaymentRequestVO qrPaymentRequest);
	
	public QRPaymentResponseVO reverseDebitCardAuthorization(QRPaymentRequestVO qrPaymentRequest);

}
