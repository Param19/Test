package com.scb.channels.qrpayments.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentVO;

public interface QRPaymentDAO {
	
	public QRPaymentVO savePayment(QRPaymentVO qrPaymentVO) throws Exception;
	
	public String getQRReferenceNumber(QRPaymentDetailVO qrPaymentDetailVO);
	
	public void updatePaymentStatus(QRPaymentVO qrPaymentVO);
	
	public QRPaymentVO getQRPaymentDetails(String host_reference);
	
	public List<QRPaymentVO> getPaymentHistoryByCustId(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO);
	
	//public List<QRPaymentViewVO> getPaymentHistoryViewByCustId(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO);
	
	public List<QRPaymentVO> getPaymentHistoryViewByCustId(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO);
	
	public ISOCODESVO getIsoCodesVo(String countryCode);
	
	public List<QRPaymentVO> getQRPaymentRetryList(Date fromDate,Date toDate, Timestamp updatedTimeStamp, int retryCount, List<String> statusList, String country, String sourceOfFund);

}
