package com.scb.channels.payments.service;

import com.scb.channels.payments.service.PaymentTransactionService;

public interface PaymentTransactionFactory {
	PaymentTransactionService getPaymentTransactionServiceImpl(String className);
}

