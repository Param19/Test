package com.scb.channels.payments.service;

import java.util.List;

import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;

/**
 * The Class WalletTransactionService.
 *
 * @author 1317590
 */
public interface WalletTransactionService {

	
	/**
	 * Gets the validate Wallet Request.
	 *
	 * @param InwardPaymentRequestVO the Request Payeload dto
	 * @return InwardPaymentResponseVO response  
	 * @throws Exception the exception
	 */
	
	InwardPaymentResponseVO validateWalletRequest(InwardPaymentRequestVO inwardPaymentRequestVO);
	
	InwardPaymentResponseVO postSingleLegTransaction(InwardPaymentRequestVO inwardPaymentRequestVO);
	
	List<InwardPaymentDetailVO> getWalletPaymentRetryTransactionList(InwardPaymentDetailVO inwardPaymentDetailsVO);
	
}
