package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PayeeManagementService;

public class AddPayeeProcessorHK extends AbstractProcessor {
	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AddPayeeProcessor.class);
	/**
	 * payeeService
	 */
	private PayeeManagementService payeeService;

	/**
	 * @param payeeService
	 */
	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(com.scb.channels
	 * .base.vo.PayloadDTO)
	 */
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Inside AddPayeeProcessorHK :: doTasks :: Start");
		BillerPayRequestVO billerPayRequestVO = null;
		//BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO) bean.getRequestVO();
			billerPayRequestVO.getUser().setCustomerId(billerPayRequestVO.getUser().getCustomerId()+billerPayRequestVO.getUser().getCustomerType());
//			billerPayResponseVO = payeeService.addPayee(billerPayRequestVO);

/*			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
				billerPayResponseVO.setStatus(ExceptionMessages._144.getCode());
				billerPayResponseVO.setStatusDesc(ExceptionMessages._144.getMessage());
			}
*/			//billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			/*billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
*/		} catch (Exception e) {
/*			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._144.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			bean.setResponseVO(billerPayResponseVO);
*/		LOGGER.info("Inside AddPayeeProcessorHK :: doTasks :: Exception " +e.getMessage());
		}
		LOGGER.info("Inside AddPayeeProcessorHK :: doTasks :: End");
		return bean;
	}
}