package com.scb.channels.qrpayments.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.QRPaymentMappingHelper;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.qrpayments.dao.QRPaymentDAO;
import com.scb.channels.qrpayments.service.QRPaymentTransactionService;

public class QRPaymentTransactionServiceImpl implements QRPaymentTransactionService{
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(QRPaymentTransactionServiceImpl.class);
	
	private QRPaymentDAO qrPaymentDAO;
	
	private DataBean dataBean;
	
	@Override
	public Long savePayment(QRPaymentRequestVO qrPaymentRequestVO) throws Exception{
		Long qrPaymentId = 0L;
		
			try{
				QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
				LOGGER.info("savePayment ::: QRPaymentTransactionServiceImpl Start ::: "+qrPaymentDetailVO.getClient_reference());
				QRPaymentVO qrPaymentVO = QRPaymentMappingHelper.getQRPaymentVO(qrPaymentDetailVO);
				qrPaymentVO.setPayment_status(CommonConstants.NEW);
				qrPaymentDAO.savePayment(qrPaymentVO);
				if(qrPaymentId != null && qrPaymentVO.getQrpayment_id() != null){
					qrPaymentId = qrPaymentVO.getQrpayment_id();
					LOGGER.info("Payment saved successfull ::: "+qrPaymentId);
				} else {
					LOGGER.info("Problem in saving payment.Payment not saved ::::: ");
				}
				LOGGER.info("savePayment ::: TransactionServiceImpl ::: End"+qrPaymentDetailVO.getClient_reference());
			}catch(Exception e){
				throw new Exception(e);
		}
		return qrPaymentId;
	}
	
	public String getQRReferenceNumberSequence(QRPaymentDetailVO qrPaymentDetailVO) {
		return qrPaymentDAO.getQRReferenceNumber(qrPaymentDetailVO);
	}

	@Override
	public void updatePaymentStatus(QRPaymentDetailVO qrPaymentDetailVO) {

		try {
			QRPaymentVO qrPaymentVO = QRPaymentMappingHelper.getQRPaymentVO(qrPaymentDetailVO);
			if(qrPaymentVO.getHost_status_cd() == null){
				qrPaymentVO.setHost_status_cd("NA");
			}
			LOGGER.info("QRPaymentTransactionServiceImpl updatePaymentStatus ::: " + qrPaymentVO.getClient_reference());
			QRPaymentVO dbQRPayment = qrPaymentDAO.getQRPaymentDetails(qrPaymentVO.getClient_reference());
			if(dbQRPayment != null) {
				
				if(dbQRPayment.getHost_reference() == null){
					dbQRPayment.setHost_reference(qrPaymentVO.getHost_reference());
				}				
				if(dbQRPayment.getAuth_code() == null && qrPaymentVO.getAuth_code() != null){
					dbQRPayment.setAuth_code(qrPaymentVO.getAuth_code());
				}
				if(dbQRPayment.getNetworkReferenceNo() == null && qrPaymentVO.getNetworkReferenceNo() != null){
					dbQRPayment.setNetworkReferenceNo(qrPaymentVO.getNetworkReferenceNo());
				}
				if(dbQRPayment.getTransactionIdentifier() == null && qrPaymentVO.getTransactionIdentifier() != null){
					dbQRPayment.setTransactionIdentifier(qrPaymentVO.getTransactionIdentifier());
				}
				if(dbQRPayment.getStatusIdentifier() == null && qrPaymentVO.getStatusIdentifier() != null){
					dbQRPayment.setStatusIdentifier(qrPaymentVO.getStatusIdentifier());
				}
				if(!dbQRPayment.getMerchant_category_code().equalsIgnoreCase(qrPaymentDetailVO.getMerchantCategoryCode())){
					dbQRPayment.setMerchant_category_code(qrPaymentDetailVO.getMerchantCategoryCode());
				}
				if(dbQRPayment.getAgg_stan() == null && qrPaymentVO.getAgg_stan() != null){
					dbQRPayment.setAgg_stan(qrPaymentVO.getAgg_stan());
				}
				
				updateRetryVersion(dbQRPayment , qrPaymentVO);
				dbQRPayment.setPayment_status(qrPaymentVO.getPayment_status());
				dbQRPayment.setHost_status_cd(qrPaymentVO.getHost_status_cd());
				dbQRPayment.setHost_status_desc(qrPaymentVO.getHost_status_desc());
				dbQRPayment.setUpdated_by(InvoiceAggregatorhelper.getJVMName());
				dbQRPayment.setUpdated_timestamp(new Timestamp(new Date().getTime()));
				qrPaymentDAO.updatePaymentStatus(dbQRPayment);
			}
			if(qrPaymentDetailVO.getTxnActStatus() != null  && qrPaymentVO.getPayment_status() != null 
					 && !qrPaymentDetailVO.getTxnActStatus().equalsIgnoreCase(qrPaymentVO.getPayment_status())){
				LOGGER.info("Updating the status from ::: " + qrPaymentDetailVO.getTxnActStatus()+" :::: to :::: " + qrPaymentVO.getPayment_status());
				qrPaymentDetailVO.setTxnActStatus(qrPaymentVO.getPayment_status());
			}
		} catch (Exception exception) {
			LOGGER.info("Exception in updatePaymentStatus method of QRPaymentTransactionServiceImpl ::: ",exception);
			exception.printStackTrace();
		}
		LOGGER.info("updatePaymentStatus ::: QRPaymentTransactionServiceImpl ::: End");
	}

	public QRPaymentDAO getQrPaymentDAO() {
		return qrPaymentDAO;
	}

	public void setQrPaymentDAO(QRPaymentDAO qrPaymentDAO) {
		this.qrPaymentDAO = qrPaymentDAO;
	}

	@Override
	public List<QRPaymentDetailVO> getQRPaymentRetryTransactionList(QRPaymentRequestVO qrPaymentRequestVO) {

		List<QRPaymentDetailVO> qrPaymentDetailFromDB = new ArrayList<QRPaymentDetailVO>();
		String country = (qrPaymentRequestVO != null && qrPaymentRequestVO.getQrPaymentDetailVO() != null) ? 
				qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode() : null;
		String sourceOfFund = (qrPaymentRequestVO != null && qrPaymentRequestVO.getQrPaymentDetailVO() != null) ? 	
				qrPaymentRequestVO.getQrPaymentDetailVO().getSourceOfFund() : null;
				
		country = country != null && !country.isEmpty() ? country.toString() : CommonConstants.EMPTY;
		sourceOfFund = sourceOfFund != null && !sourceOfFund.isEmpty() ? sourceOfFund.toString() : CommonConstants.EMPTY;
		
		LOGGER.info("Inside method  getQRPaymentRetryTransactionList country ::::::::::: " + country);
		Calendar calendar = DateUtils.getCountryCalendar();
		LOGGER.info("JVM Time ::::::::::: " + calendar.getTime());
		calendar.add(Calendar.HOUR, -12);
        Date fromDate = calendar.getTime();
        LOGGER.info("-12 Hours ::::::::::: " + fromDate);
        
        String postBuffer = dataBean.getMap().get(country+sourceOfFund+CommonConstants.PAYMENT_TIMER_BUFFER);
        int retryBuffer = postBuffer != null && !postBuffer.isEmpty() ? 
        			Integer.parseInt(postBuffer) : 0;
        			
        Calendar cal = DateUtils.getCountryCalendar();
        cal.add(Calendar.HOUR, retryBuffer);
        Date toDate = cal.getTime();
        LOGGER.info("Buffer Date ::::::::::: " + toDate);
        String interval = dataBean.getMap().get(country+sourceOfFund+CommonConstants.PAYMENT_RETRY_TIMER);
        int retryInterval = interval != null && !interval.isEmpty() ? Integer.parseInt(interval) : 0;
        
		String retryValue = dataBean.getMap().get(country+sourceOfFund+CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);
        int retryCount = retryValue != null && !retryValue.isEmpty() ?	Integer.parseInt(retryValue) : CommonConstants.THREE;
        			
        Object retryStatusObject = dataBean.getMap().get(country+sourceOfFund+CommonConstants.PAYMENT_TIMEOUT_RETRY_STATUS);
        List<String> retryStatus = retryStatusObject != null ? Arrays.asList(retryStatusObject.toString().split(CommonConstants.COMMA)) : CommonConstants.QR_TIME_OUT_LIST;
        
        //Object retryCountriesObject = dataBean.getMap().get(country+sourceOfFund+CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNTRY);
        //List<String> retryCountries = retryCountriesObject != null ? Arrays.asList(retryCountriesObject.toString().split(CommonConstants.COMMA)) : 	CommonConstants.QR_COUNTRY_LIST;
        
		LOGGER.info("qr retry details -- retryInterval {} -- retryCount {} -- retryStatus {} -- retryCountries {}"
        		,new Object[]{retryInterval,retryCount,retryStatus,country});
        		
        Calendar updatedTimeCalendar = Calendar.getInstance();
        //updatedTimeCalendar.setTime(new Date());
        updatedTimeCalendar.add(Calendar.MINUTE, -(retryInterval));
        Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());
        
        
        LOGGER.info("At getQRPayment retry TransactionList for countries {} and status {} --- "
        		+ "From Date {} and To Date {} and update date {} "
        		,new Object[]{country,retryStatus,fromDate,toDate,updatedTimeStamp});
        
        List<QRPaymentVO>  retryList = qrPaymentDAO.getQRPaymentRetryList(fromDate, toDate, updatedTimeStamp, retryCount, retryStatus, country,sourceOfFund);
       
       if(retryList != null && !retryList.isEmpty()){
    	   for(QRPaymentVO paymentObj : retryList){
	   			QRPaymentDetailVO	qrPaymentDetailVO = QRPaymentMappingHelper.getQRPaymentDetailMapping(paymentObj);
	   			qrPaymentDetailFromDB.add(qrPaymentDetailVO);
   			}
       }
       LOGGER.info("At getQRPaymentRetryTransactionList End  >>>> ");
       return qrPaymentDetailFromDB;
	
	}
	
	 private void updateRetryVersion(QRPaymentVO dbPayment, QRPaymentVO payment) {

		 LOGGER.info("Before updateRetryVersion Incase of Retry DB::::::" + dbPayment.getPayment_status()+ " VO ::::: " + payment.getPayment_status());
		 LOGGER.info("Before updateRetryVersion Incase of Retry DB::::::" + dbPayment.getVersion()+ " VO ::::: " + payment.getVersion());
	               
	     if(dbPayment.getPayment_status() != null && payment.getPayment_status() != null 
	    		 && dbPayment.getPayment_status().equalsIgnoreCase(payment.getPayment_status())) {
	    	 dbPayment.setVersion(dbPayment.getVersion()+1);
	     }else{
	    	 dbPayment.setVersion(1);
	     }
	     if(payment.getPayment_status() != null &&  CommonConstants.AGGREGATOR_PAY_TIMEOUT.equalsIgnoreCase(payment.getPayment_status())
	    		 && CommonConstants.MASTER.equalsIgnoreCase(payment.getCard_type())){
	    	 payment.setPayment_status(CommonConstants.TIMEOUT);
	     }
	    		 
	     if(payment.getPayment_status() != null && 
	    		 (CommonConstants.AGGREGATOR_PAY_TIMEOUT.equalsIgnoreCase(payment.getPayment_status())|| 
	    				 CommonConstants.ACQUIRER_TIMEOUT.equalsIgnoreCase(payment.getPayment_status()))) {
	    	 
	    	 String country = dbPayment.getCountry_code() != null && !dbPayment.getCountry_code().isEmpty() ? 
	                                   dbPayment.getCountry_code().toString() : CommonConstants.EMPTY;
	         String cardType = dbPayment.getCard_type() != null && !dbPayment.getCard_type().isEmpty() ? 
	                                   dbPayment.getCard_type().toString()  : CommonConstants.EMPTY;
	         String strRetryCount = dataBean.getMap().get(country + cardType + CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);           
	         int retryCount = strRetryCount != null && !strRetryCount.isEmpty() ? Integer.parseInt(strRetryCount) : CommonConstants.THREE;
	         LOGGER.info("Inside Visa Timeout updating the retry "+ country + cardType + CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT+" count :::::"+retryCount);  
	         if(dbPayment.getVersion() != null && dbPayment.getVersion() > retryCount) {
	        	 LOGGER.info("Inside Visa Timeout exceed the 3 retry count and updating to TIMEOUT  ::::: ");
	             payment.setPayment_status(CommonConstants.TIMEOUT);
	          }
	      }
	     
	     if(payment.getPayment_status() != null && 
	    		 (CommonConstants.CARD_AUTH_REV_TIMEOUT.equalsIgnoreCase(payment.getPayment_status())|| 
	    				 CommonConstants.DEBIT_CARD_AUTH_REV_TIMEOUT.equalsIgnoreCase(payment.getPayment_status()))) {
	    	 
	    	 String country = dbPayment.getCountry_code() != null && !dbPayment.getCountry_code().isEmpty() ? 
	                                   dbPayment.getCountry_code().toString() : CommonConstants.EMPTY;
	         String paymentType = dbPayment.getPayment_type() != null && !dbPayment.getPayment_type().isEmpty() ? 
	                                   dbPayment.getPayment_type().toString() : CommonConstants.EMPTY;
	         String strRetryCount = dataBean.getMap().get(country + paymentType + CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT);           
	         int retryCount = strRetryCount != null && !strRetryCount.isEmpty() ? Integer.parseInt(strRetryCount) : CommonConstants.THREE;
	         LOGGER.info("Inside Reversal Timeout updating the retry "+ country + paymentType + CommonConstants.PAYMENT_TIMEOUT_RETRY_COUNT+" count :::::"+retryCount); 
	         if(dbPayment.getVersion() != null && dbPayment.getVersion() > retryCount) {
	        	 LOGGER.info("Inside reverse Timeout exceed the  retry count and updating to TIMEOUT  ::::: ");
	             payment.setPayment_status(CommonConstants.TIMEOUT);
	          }
	      }
	     
	         LOGGER.info("retryValue  db version :::: " + dbPayment.getVersion() + " && db Payment status :::: " + dbPayment.getPayment_status());
	  }

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	@Override
	public QRPaymentResponseVO getQRPaymentTxnStatus(QRPaymentRequestVO qrPaymentRequestVO){
		QRPaymentDetailVO qrPaymentDetailVO;
		QRPaymentResponseVO qrPaymentResponseVO = new QRPaymentResponseVO();
		try{
			
			qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
			LOGGER.info("QRPaymentTransactionServiceImpl Fetch PaymentStatus ::: " + qrPaymentDetailVO.getClient_reference());
			
			QRPaymentVO dbQRPayment = qrPaymentDAO.getQRPaymentDetails(qrPaymentDetailVO.getClient_reference());
			if(dbQRPayment!=null)
				qrPaymentDetailVO = QRPaymentMappingHelper.getQRPaymentDetailMapping(dbQRPayment);
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			
			
		} catch(Exception exception){
			LOGGER.info("Exception in getQRPaymentTxnStatus method of QRPaymentTransactionServiceImpl ::: ",exception);
		}
		return qrPaymentResponseVO;
	}
}
