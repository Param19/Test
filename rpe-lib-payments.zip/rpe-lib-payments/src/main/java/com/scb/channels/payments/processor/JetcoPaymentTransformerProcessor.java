package com.scb.channels.payments.processor;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.JetcoPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.StatusType;
import com.scb.channels.mapper.helper.JetcoPayMappingHelper;
import com.scb.channels.paymentservice.PaymentResponse;

/**
 * JetcoPaymentTransformerProcessor
 * 
 * @author 1552545
 * 
 */
public class JetcoPaymentTransformerProcessor {

	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(JetcoPaymentTransformerProcessor.class);


	public PaymentResponse getPaymentFinalStatus(PayloadDTO payload) {
		LOGGER.info("JetcoPaymentTransformerProcessor --- sendPaymentFinalStatus --- Start");
		PaymentResponse response = new PaymentResponse();
		HostResponseType hostResponse = new HostResponseType();
		StatusType status = new StatusType();
		Set<HostResponseVO> hostResponseList = new HashSet<HostResponseVO>();
		try {
			if (payload != null && payload.getResponseVO() != null && payload.getResponseVO() instanceof JetcoPayResponseVO) {
				JetcoPayResponseVO responseVo = (JetcoPayResponseVO) payload.getResponseVO();
				response = JetcoPayMappingHelper.getPaymentResponseVOMapping(responseVo);
				hostResponseList = responseVo.getHostResponseVO();
				if (responseVo.getTxnActStatus() != null && responseVo.getBankMessageId() != null && responseVo.getTransactionInfo() != null) {
					hostResponse.setCode(responseVo.getTransactionInfo().getHostRespCd());
					hostResponse.setDesc(responseVo.getTransactionInfo().getHostRespDesc());
					hostResponse.setHostReference(responseVo.getTransactionInfo().getHostTxnRefNo());
					if (responseVo.getTxnActStatus().equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS)
							|| (responseVo.getTxnActStatus().equalsIgnoreCase(CommonConstants.COREBANK_PAY_SUCCESS) && CommonConstants.JETCO_TRANSACTION_ON_US
									.equals(responseVo.getPaymentType()))) {
						LOGGER.info("AGGREGATOR_PAY_SUCCESS ::: " + responseVo.getBankMessageId());
						LOGGER.info("TOKEN VALUE ::: " + responseVo.getTransactionInfo().getOtpRefNo());
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.SUCCESS);
						response.setToken(responseVo.getTransactionInfo().getOtpRefNo());
						hostResponse.setHostName(responseVo.getHostName());
					} else {
						LOGGER.info("FAILURE STATUS ::: " + responseVo.getBankMessageId());
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						hostResponse.setHostName(responseVo.getHostName());
					}
					LOGGER.info("Incoming response has details");
					status.setRefrenceNumber(responseVo.getReferenceNumber());
				} else {
					LOGGER.info("The response object is not complete");
					status.setStatusCode(CommonConstants.TIMEOUT_CODE);
					status.setStatusDesc(CommonConstants.FAILURE);
					hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				}
				LOGGER.info("Payment response generated for :::::: " + response.getMessageContext().getReqID());
			} else {
				LOGGER.info("The response object is not complete");
				System.out.println("The response object is not complete");
				status.setStatusCode(CommonConstants.TIMEOUT_CODE);
				status.setStatusDesc(CommonConstants.FAILURE);
				hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
				hostResponse.setDesc(CommonConstants.FAILURE);
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			}
			if (status.getStatusDesc() != null) {
				if (hostResponseList != null && !hostResponseList.isEmpty()) {
					LOGGER.info("Setting the previous host response ::: ");
					for (HostResponseVO previousHostResponse : hostResponseList) {
						HostResponseType hostResponseType = new HostResponseType();
						hostResponseType.setCode(previousHostResponse.getCode());
						hostResponseType.setDesc(previousHostResponse.getDesc());
						hostResponseType.setHostName(previousHostResponse.getHostName());
						status.getHostResponse().add(hostResponseType);
					}
				}
			}
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);
			LOGGER.info("JetcoPaymentTransformerProcessor --- response.getToken() --- End ---- " + response.getToken());
		} catch (Exception e) {
			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
			hostResponse.setDesc(CommonConstants.FAILURE);
			hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);
			LOGGER.error("Exception for Payment final response :::: " + response.getMessageContext().getReqID());
			LOGGER.error("Exception occurred while Payment final response :::: " + e.getMessage());
		}
		return response;
	}

	public String getFinalStatusXml(PaymentResponse paymentResponse) {
		String responseXml = null;
		LOGGER.info("Transforming payment response object to xml string");
		try {
			responseXml = CommonHelper.getXML(paymentResponse, PaymentResponse.class, PaymentResponse.class.getSimpleName());
			if (responseXml != null) {
				LOGGER.info("Transforming payment response xml successful --- > ::: " + responseXml);
			} else {
				LOGGER.info("Transforming payment response xml is NOT successful --- > ::: " + responseXml);
			}
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT FINAL RESPONSE XML :::::: " + e.getMessage());
			LOGGER.error(e.getMessage());
		}
		return responseXml;
	}

	public PaymentResponse respondJetcoPaySubmitted(PayloadDTO dto) {
		LOGGER.info("JetcoPaymentTransformerProcessor --- respondJetcoPaySubmitted --0000- Start");

		HostResponseType hostResponse = new HostResponseType();
		PaymentResponse response = new PaymentResponse();
		StatusType status = new StatusType();
		try {
			if (dto != null && dto.getResponseVO() != null && dto.getResponseVO() instanceof JetcoPayResponseVO) {
				JetcoPayResponseVO responseVo = (JetcoPayResponseVO) dto.getResponseVO();
				response = JetcoPayMappingHelper.getPaymentResponseVOMapping(responseVo);
				status.setRefrenceNumber(responseVo.getReferenceNumber());
				if (responseVo.getUser() != null && responseVo.getServiceVO() != null && responseVo.getClientVO() != null && responseVo.getMessageVO() != null
						&& responseVo.getTxnActStatus() != null && responseVo.getTxnActStatus().equalsIgnoreCase(CommonConstants.SAVE_SUCCESS)) {
					LOGGER.info("Incoming request has details");
					hostResponse.setCode(CommonConstants.ZERO);
					hostResponse.setDesc(CommonConstants.SUBMITTED);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
					status.getHostResponse().add(hostResponse);
					status.setStatusCode(CommonConstants.ZERO);
					status.setStatusDesc(CommonConstants.INPROCESS_STATUS);

				} else {
					LOGGER.info("Incoming request is not complete");
					hostResponse.setCode(CommonConstants.NEGATIVE);
					if (responseVo.getTransactionInfo() != null & !StringUtils.isEmpty(responseVo.getTransactionInfo().getHostRespDesc())) {
						hostResponse.setDesc(responseVo.getTransactionInfo().getHostRespDesc());
					} else {
						hostResponse.setDesc(CommonConstants.FAILURE);
					}
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
					status.getHostResponse().add(hostResponse);
					status.setStatusCode(CommonConstants.NEGATIVE);
					status.setStatusDesc(CommonConstants.FAILURE);
				}
			} else {
				LOGGER.info("Incoming request is not complete");
				hostResponse.setCode(CommonConstants.NEGATIVE);
				hostResponse.setDesc(CommonConstants.FAILURE);
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				status.getHostResponse().add(hostResponse);
				status.setStatusCode(CommonConstants.NEGATIVE);
				status.setStatusDesc("The Request is not complete. Missing context details.");
			}
			response.setStatus(status);
			LOGGER.info("Payment response generated for :::::: " + response.getMessageContext().getReqID());
			LOGGER.info("JetcoPaymentTransformerProcessor --- respondJetcoPaySubmitted --- End");
		} catch (Exception e) {
			status.setStatusCode(CommonConstants.NEGATIVE);
			status.setStatusDesc(e.getMessage());
			LOGGER.error("Exception for Payment :::: " + response.getMessageContext().getReqID());
			LOGGER.error("Exception occurred while submitting Payment :::: " + e.getMessage());
		}
		return response;
	}
}
