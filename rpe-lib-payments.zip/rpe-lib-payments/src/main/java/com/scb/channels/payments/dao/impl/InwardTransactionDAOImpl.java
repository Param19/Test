package com.scb.channels.payments.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.StringUtils;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.InwardInquiryRequestVO;
import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.common.processor.ConstrtaintException;
import com.scb.channels.payments.dao.InwardTransactionDAO;

public class InwardTransactionDAOImpl extends HibernateDaoSupport implements InwardTransactionDAO {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(InwardTransactionDAOImpl.class);
	
	public List<InwardPaymentDetailVO> getCreditTransactions(
			InwardInquiryRequestVO inquiryRequest) throws Exception {
		
		String country  = inquiryRequest.getClientInfoVO().getCountry();
		Session session = null;
		Criteria criteria = null;
		List<InwardPaymentDetailVO> creditPayments = new ArrayList<InwardPaymentDetailVO>();
		try {
			 LOGGER.info("Creating Session for update ::: " + inquiryRequest.getReferenceNumber());
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria = session.createCriteria(InwardPaymentDetailVO.class)
					.add(Restrictions.between("paymentDate", 
							new Timestamp(inquiryRequest.getFromDate().getTime()), 
							new Timestamp(inquiryRequest.getToDate().getTime())))
					.add(Restrictions.eq("countryCode", country))
					.add(Restrictions.isNull("paymentType"))
					.add(Restrictions.isNull("payeeId"));
			
			//creditPayments = criteria.list();
			Object object = criteria.list();
			if(object != null) {
				creditPayments = (List<InwardPaymentDetailVO>) object;
				LOGGER.info("Obtained persistent object ::: " + inquiryRequest.getReferenceNumber());
			} else {
				LOGGER.info("No data in the DB for ::: " + inquiryRequest.getReferenceNumber());
			}
		} catch (Exception exception){
			 LOGGER.info("Exception for ::: " + inquiryRequest.getReferenceNumber());
			 LOGGER.info("Exception occurred duirng saving payment ::: ", exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in get payment details");
				 session.close();
			 }
		 }
		return creditPayments;
	}
	
	/** The Constant selectInwardData. */
	private static final String selectInwardData = "FROM InwardPaymentDetailVO where REFERENCE_NUMBER= :referenceNumber";
	
	@Override
	public InwardPaymentDetailVO saveCreditPayment(InwardPaymentDetailVO inwardPaymentDetailVO) throws ConstrtaintException {

		LOGGER.info("PayeeManagementDAOImpl :: savePayee :: Start ");
		Session session = null;
		Transaction transaction = null;
			try{
					session = getHibernateTemplate().getSessionFactory().openSession();
					LOGGER.info(":::::::::::::; initiate transaction saveCreditPayment:::::::::::::" + inwardPaymentDetailVO.getReferenceNumber());
					transaction = session.beginTransaction();
					LOGGER.info(":::::::::::::; doing insert saveCreditPayment:::::::::::::");
					session.save(inwardPaymentDetailVO);
					transaction.commit();
					session.flush();
					session.close();
				
				LOGGER.info("::::::::::::: Inward Commit saveCreditPayment successfull :::::::::::::");
			} catch (ConstraintViolationException exception) {
				LOGGER.info("::::::::::::: ConstraintViolationException block :::::::::::::" + exception.getMessage()+" ::Reference Number::::"+ inwardPaymentDetailVO.getReferenceNumber());
				inwardPaymentDetailVO = new InwardPaymentDetailVO();
				inwardPaymentDetailVO.setFlag(CommonConstants.FALSE);
				LOGGER.error(":::::::::::::Exception occured in ConstraintViolationException block :::::::::::::" , exception);
				//exception.printStackTrace();
				transaction.rollback();
				session.close();
				LOGGER.error(":::::::::::::; Inward Commit saveCreditPayment ConstraintViolationException Rollback successfull :::::::::::::");
			} catch (Exception exception) {
				LOGGER.error("::::::::::::: Other Exception going to rollback :::::::::::::" + exception.getMessage()+" ::Reference Number::::"+ inwardPaymentDetailVO.getReferenceNumber());
				//exception.printStackTrace();
				inwardPaymentDetailVO = null;
				LOGGER.error(":::::::::::::Exception occured in Other Exception block :::::::::::::" , exception);
				transaction.rollback();
				session.close();
				LOGGER.error("::::::::::::: Inward Commit saveCreditPayment Rollback successfull :::::::::::::");
			}
			
		LOGGER.info("PayeeManagementDAOImpl :: savePayee :: End ");
		return inwardPaymentDetailVO;	
		
	}

	@Override
	public void updateCreditPayment(InwardPaymentDetailVO inwardPaymentDetailVO) {

		LOGGER.info("updatePayee ::: payeeManagementDao ::: Start");
		
		Session session = null;
		Transaction transaction = null;
		try {
			LOGGER.info("Creating Session for updateCreditPayment payee ::: " + inwardPaymentDetailVO.getReferenceNumber());
			session = getHibernateTemplate().getSessionFactory().openSession();
				
			LOGGER.info("Update the updateCreditPayment for payment ::: " + inwardPaymentDetailVO.getReferenceNumber());
			transaction = session.beginTransaction();
			session.update(inwardPaymentDetailVO);
			transaction.commit();
			session.flush();
			LOGGER.info("Update complete for updateCreditPayment details ::: " + inwardPaymentDetailVO.getReferenceNumber());
			
		} catch (Exception exception) {
			 LOGGER.info("Exception for updateCreditPayment payee ::: " + inwardPaymentDetailVO.getReferenceNumber());
			 LOGGER.info("Exception occurred duirng updateCreditPayment payee details ::: " + exception);
			 LOGGER.error("",exception);
			 if (transaction != null) {
				LOGGER.info("Closing transaction in updateCreditPayment details");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in updateCreditPayment details");
				session.close();
			}
		}
		LOGGER.info("updatePayee ::: payeeManagementDao ::: Start");
	}


	@Override
	public InwardPaymentDetailVO getCreditPayment(String referenceNumber) throws ConstrtaintException {
		Session session = null;
		InwardPaymentDetailVO inwardPaymentDetailVO = null;
		try {
			LOGGER.info("PayeeManagementDAOImpl :: getCreditPayment :: Start :: " + referenceNumber);
			session = getHibernateTemplate().getSessionFactory().openSession();
			Query query = session.createQuery(selectInwardData).setParameter("referenceNumber", referenceNumber);
			List<InwardPaymentDetailVO> list = query.list();
			for(InwardPaymentDetailVO detailVO : list){
				inwardPaymentDetailVO = detailVO;
			}
			LOGGER.info("PayeeManagementDAOImpl :: getCreditPayment :: End ::: " + inwardPaymentDetailVO);
		} catch (Exception exception) {
			//LOGGER.info("Exception occured while fetching getCreditPayment details :::: " + referenceNumber);
			LOGGER.error("Exception occured while fetching getCreditPayment details :::: " + referenceNumber);
			//LOGGER.info("Exception :::: " + exception);
			LOGGER.error("Exception :::: " ,exception);
			exception.printStackTrace();
		} finally {
			LOGGER.info("closing session for getCreditPayment");
			if(session != null){
				session.flush();
				session.close();
			}
		}
		LOGGER.info("PayeeManagementDAOImpl :: checkIsPayeeExists getCreditPayment :: End :: NEW");
		return inwardPaymentDetailVO;
	}

	@Override
	public void updateStatusCheck(InwardPaymentDetailVO inwardPaymentDetailVO) throws Exception {
		Query query = getHibernateTemplate().getSessionFactory().openSession().createQuery(
		"Update InwardPaymentDetailVO set paymentStatus=:paymentStatus, paymentDescription=:paymentDescription, updatedTime=:updatedTime, retryCount=:retryCount, hostStatusCode=:hostStatusCode, hostStatusDescription=:hostStatusDescription    where referenceNumber = :referenceNumber");
		query.setParameter("referenceNumber", inwardPaymentDetailVO.getReferenceNumber());
		query.setParameter("paymentStatus", inwardPaymentDetailVO.getPaymentStatus());
		query.setParameter("paymentDescription", inwardPaymentDetailVO.getPaymentDescription());
		query.setParameter("retryCount", inwardPaymentDetailVO.getRetryCount());
		query.setParameter("updatedTime", DateUtils.getCurrentDate());
		
		//Added for OM start
		query.setParameter("hostStatusCode", inwardPaymentDetailVO.getHostStatusCode());
		query.setParameter("hostStatusDescription", inwardPaymentDetailVO.getHostStatusDescription());
		//Added for OM end
		query.executeUpdate();
		
	}
	
	//CR1477 Orange Money Changes Starts, 20Feb18, Vijayan A
	/**
	 * get Wallet Transactions for Retry.
	 *
	 * @param fromDate, toDate, updatedTimeStamp, retryCount, statusList, countries as input
	 * @return List of InwardPaymentDetailVO
	 * @throws Exception the exception
	 */
	
	public List<InwardPaymentDetailVO> geWallettPaymentRetryList(Date fromDate,Date toDate, Timestamp updatedTimeStamp, int retryCount, 
			List<String> statusList, List<String> countries) {
		Session session = null;
		Criteria criteria = null;
		List<InwardPaymentDetailVO> list = new ArrayList<InwardPaymentDetailVO>();
		try{
			LOGGER.debug("Inside geWallettPaymentRetryList befor  DB Fetch ");
		 session = getHibernateTemplate().getSessionFactory().openSession();
		 criteria =session.createCriteria(InwardPaymentDetailVO.class); 
		criteria.add(Restrictions.in(HibernateHelper.COUNTRY_CODE, countries));
		criteria.add(Restrictions.between("paymentDate", fromDate, toDate));
		criteria.add(Restrictions.lt("updatedTime", updatedTimeStamp));
		criteria.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS, statusList));
		criteria.add(Restrictions.le("retryCount", retryCount));
		list = criteria.list();
		LOGGER.debug("Inside geWallettPaymentRetryList After  DB Fetch List "+list);
		
		if (!list.isEmpty()) {
			//Deleting duplicate records 
			Set<InwardPaymentDetailVO> setValueFrDB = new LinkedHashSet<InwardPaymentDetailVO>(list);
			List<InwardPaymentDetailVO> modifiedResponse  =new LinkedList<InwardPaymentDetailVO>(setValueFrDB);
			list = modifiedResponse;
			logger.info("After DB Fetch at InwardPaymentDetailVO Datalayer payment Retry size  "
					+ list.size());
		}
		} catch (Exception exception){
			 LOGGER.info("Exception occurred duirng saving payment ::: " , exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in getPaymentRetryList details");
				 session.close();
			 }
		 }
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list;
		}		
	}
	
	
	public List<InwardPaymentDetailVO> getCreditWalletTransactions(
			InwardInquiryRequestVO inquiryRequest) throws Exception {
		
		String country  = inquiryRequest.getClientInfoVO().getCountry();
		String paymentType = inquiryRequest.getServiceVO().getServiceTxnType();
		Session session = null;
		Criteria criteria = null;
		List<InwardPaymentDetailVO> creditPayments = new ArrayList<InwardPaymentDetailVO>();
		try {
			 LOGGER.info("Creating Session for update ::: " + inquiryRequest.getReferenceNumber());
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria = session.createCriteria(InwardPaymentDetailVO.class)
					.add(Restrictions.between("paymentDate", 
							new Timestamp(inquiryRequest.getFromDate().getTime()), 
							new Timestamp(inquiryRequest.getToDate().getTime())))
					.add(Restrictions.eq("countryCode", country))/*1570965*/
					.add(Restrictions.isNotNull("paymentType"))
					.add(Restrictions.isNotNull("payeeId"));
			
			if(paymentType!=null  && !StringUtils.isEmpty(paymentType)){
				criteria.add(Restrictions.eq("paymentType", inquiryRequest.getServiceVO().getServiceTxnType()));
			}
			
			//creditPayments = criteria.list();
			Object object = criteria.list();
			if(object != null) {
				creditPayments = (List<InwardPaymentDetailVO>) object;
				
				logger.debug("After DB Fetch at getCustomerPaymentHistory payment history size  ");
				if (!creditPayments.isEmpty()) {
					//Deleting duplicate records 
					Set<InwardPaymentDetailVO> setValueFrDB = new LinkedHashSet<InwardPaymentDetailVO>(creditPayments);
					List<InwardPaymentDetailVO> modifiedResponse  =new LinkedList<InwardPaymentDetailVO>(setValueFrDB);
					creditPayments = modifiedResponse;
					logger.info("After DB Fetch at getCustomerPaymentHistory Datalayer payment history size  " + creditPayments.size());
				}
				
				
				
				LOGGER.info("Obtained persistent object ::: " + inquiryRequest.getReferenceNumber());
			} else {
				LOGGER.info("No data in the DB for ::: " + inquiryRequest.getReferenceNumber());
			}
		} catch (Exception exception){
			 LOGGER.info("Exception for ::: " + inquiryRequest.getReferenceNumber());
			 LOGGER.info("Exception occurred duirng saving payment ::: ", exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in get payment details");
				 session.close();
			 }
		 }
		return creditPayments;
	}
	
	@Override
	public Double getTotalDebitWalletPayment(String strCustomerId, String strCountry, Calendar date) {
		
		String strCustId  = strCustomerId;
		Date paymentDate = date.getTime();
		
		BigDecimal sum = new BigDecimal(9);
		String[] strPaymentStatus = { CommonConstants.COREBANK_PAY_SUCCESS,CommonConstants.SUBMITTED };

		Session session = null;
		Criteria criteria = null;
		try {
			 LOGGER.info("Creating Session for customer id ::: " + strCustId + "paymentDate: Date: "+paymentDate);
			session = getHibernateTemplate().getSessionFactory().openSession();
						
			criteria = session.createCriteria(InwardPaymentDetailVO.class)
					.add(Restrictions.eq(HibernateHelper.COUNTRY_CODE,strCountry))
					.add(Restrictions.eq(HibernateHelper.PAYMENT_TYPE, CommonConstants.DISCHARGE))
					.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS, strPaymentStatus))
					.add(Restrictions.eq(HibernateHelper.CUSTOMER_ID, strCustId));
			
			Date minDate = DateUtils.getDateWithoutTime(paymentDate);
			Date maxDate = DateUtils.getDateWithMaxTime(minDate); 
			
			Conjunction con = Restrictions.conjunction();
			con.add(Restrictions.ge(HibernateHelper.PAYMENT_DATE, minDate));//The order date must be >= Date - 00h00
			con.add(Restrictions.lt(HibernateHelper.PAYMENT_DATE, maxDate));//And the order date must be < Date- 00h00
			
			LOGGER.info("PaymentDAOImpl: getCustomerOverallPaymentAmount, minDate, maxDate {}-{}", new Object[] {minDate, maxDate});
			
			criteria.add(con);  
			criteria.setProjection(Projections.sum(HibernateHelper.PAYMENT_AMOUNT));
			
			//creditPayments = criteria.list();
			Object object = criteria.uniqueResult();
			if(object != null) {
				sum =  (BigDecimal)object;
				logger.debug("After DB Fetch at getCustomerPaymentHistory sum of debit amount is :::: " + sum.doubleValue());
				return sum.doubleValue();
			} 
		} catch (Exception exception){
			 LOGGER.info("Exception occurred duirng saving payment ::: ", exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in get payment details");
				 session.close();
			 }
		 }
		return sum.doubleValue();
		
	}
	
	//CR1477 Orange Money Changes Ends, 20Feb18, Vijayan A
	
}
