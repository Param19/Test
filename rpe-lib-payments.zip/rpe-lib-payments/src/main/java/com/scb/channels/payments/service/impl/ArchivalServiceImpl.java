package com.scb.channels.payments.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.payments.dao.ArchivalDAO;
import com.scb.channels.payments.service.ArchivalService;

public class ArchivalServiceImpl implements ArchivalService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ArchivalServiceImpl.class);
	
	private ArchivalDAO archivalDAO;

	public void setArchivalDAO(ArchivalDAO archivalDAO) {
		this.archivalDAO = archivalDAO;
	}

	@Override
	public BillerDownloadResponseVO archive(
			BillerDownloadRequest billerDownloadRequest) {
		
		BillerDownloadResponseVO billerDownloadResponseVO = null;

		LOGGER.info("Archival Service inside archive method");
		
		try{
			LOGGER.info("ArchivalService into DB {}}",
					new Object[] { billerDownloadRequest.getUser()
							.getCountry() });
			
			billerDownloadResponseVO = archivalDAO.archive(billerDownloadRequest);
			
			LOGGER.info("Archival Service inside archive method --- After archive process done!!!!");
			
		}catch(Exception ex){
			
			LOGGER.error("Exception block at DoTask --> Archival Processor "
					+ ex.getMessage());
			
		}
		
		return billerDownloadResponseVO;
	}

}
