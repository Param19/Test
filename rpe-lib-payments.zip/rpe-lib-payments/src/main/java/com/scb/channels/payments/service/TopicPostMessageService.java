package com.scb.channels.payments.service;

import javax.jms.JMSException;

public interface TopicPostMessageService {

	public void postMessage(String message)  throws JMSException, Exception;
	public void postMessage(String message, String topicName)  throws JMSException, Exception;
}
