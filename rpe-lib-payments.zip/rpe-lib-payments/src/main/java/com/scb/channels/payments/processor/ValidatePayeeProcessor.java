package com.scb.channels.payments.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.helper.ReferenceNumberGenerator;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.helper.NarrationHelper;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.payments.service.PayeeManagementService;
import com.scb.channels.payments.service.PaymentDetailsService;

public class ValidatePayeeProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidatePayeeProcessor.class);
	/** The Constant CLOSE_SQUARE. */
	public static final String CLOSE_SQUARE = "]";

	/** The Constant OPEN_SQUARE. */
	private static final String OPEN_SQUARE = "[";

	/** The Constant CLOSE_CURL. */
	private static final String CLOSE_CURL = "}";

	/** The Constant OPEN_CURL. */
	private static final String OPEN_CURL = "{";
	
	/** The Constant shortCodeMap. */
	public static final Map<String, String> shortCodeMap = new HashMap<String, String>();
	
	/** The Constant REQUEST_VO_BILLER_PAY_DETAILS_VO. */
	public static final String REQUEST_VO_BILLER_PAY_DETAILS_VO = "requestVO.billerPayDetailsVO";
	
	public static final String RQ_BPD = "rq.bpd";
	
	static {
		shortCodeMap.put(RQ_BPD, REQUEST_VO_BILLER_PAY_DETAILS_VO);
	}

	/**
	 * paymentDetailsService
	 */
	private PaymentDetailsService paymentDetailsService;
	
	/**
	 * payeeService
	 */
	private PayeeManagementService payeeService;
	
	/**
	 * dataBean
	 */
	private DataBean dataBean;
	/** The reference service. */
	public ReferenceService referenceService;
	
	
	/**
	 * @return the referenceService
	 */
	public ReferenceService getReferenceService() {
		return referenceService;
	}

	/**
	 * @param referenceService the referenceService to set
	 */
	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	/**
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	/**
	 * @return the payeeService
	 */
	public PayeeManagementService getPayeeService() {
		return payeeService;
	}

	/**
	 * @param payeeService the payeeService to set
	 */
	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/**
	 * @param payloadDTO
	 * @return
	 */
	public PayloadDTO process(PayloadDTO payloadDTO) {
		LOGGER.info("Inside ValidatePayeeProcessor process method-Start");
		LOGGER.info("Inside ValidatePayeeProcessor process "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		BillerPayResponseVO billerPayResponseVO = null;
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		billerPayRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
		PayeeDetailVO payeeDetailVO=null;
		LOGGER.info("Request is from ::" + billerPayRequestVO.getServiceVO().getServiceName());
		try {
			if(billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_INSERT_ROUTE)){
				billerPayResponseVO=(BillerPayResponseVO) payloadDTO.getResponseVO();
				if(billerPayResponseVO !=null){
					if(billerPayResponseVO.getBillerPayDetailsVO()!=null){
						payeeDetailVO=new PayeeDetailVO();
						payeeDetailVO.setPayeeId(Integer.parseInt(billerPayResponseVO.getBillerPayDetailsVO().getPayeeId()));
					}
				}
			}
			
			/*String topUpAmount=billerPayRequestVO.getBillerPayDetailsVO().getTopupAmount();
			if(topUpAmount!=null){
				Double topUpamt=Double.parseDouble(topUpAmount);
			billerPayRequestVO.getBillerPayDetailsVO().setTopupAmount(((Arrays.asList((String.valueOf(topUpamt*100)).split(Pattern.quote(".")))).get(0)).toString());		
			}*/ 
			// Code commented to use BigDecimal instead of Double and conversion using multiplier logic
        	BigDecimal amount = new BigDecimal((billerPayRequestVO.getBillerPayDetailsVO().getTopupAmount() != null)? billerPayRequestVO.getBillerPayDetailsVO().getTopupAmount() : CommonConstants.ZERO);
        	billerPayRequestVO.getBillerPayDetailsVO().setTopupAmount((Arrays.asList((String.valueOf(
            			amount.multiply(new BigDecimal(100))).
            			        split(Pattern.quote(CommonConstants.DOT)))).get(0)).toString());
	        LOGGER.info("ValidatePayee: post Conversion Part:: getTopupAmount::" + billerPayRequestVO.getBillerPayDetailsVO().getTopupAmount()); 
			
			billerPayResponseVO = paymentDetailsService.validateWallet(billerPayRequestVO);
			if (billerPayResponseVO != null) {
				LOGGER.info("billerPayResponseVO.getStatus() "+billerPayResponseVO.getStatus() +" ::  "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo())  ;
				LOGGER.info("billerPayResponseVO.getStatusDesc() "+billerPayResponseVO.getStatusDesc()+"  :: "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
				if (billerPayResponseVO.getStatus() != null) {
					switch (billerPayResponseVO.getStatus()) {

					case CommonConstants.ALIPAY_SUCCESS:
						LOGGER.info("Got success from Aggregator for " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						if (payeeDetailVO != null) {
							billerPayRequestVO.getBillerPayDetailsVO().setPayeeId(payeeDetailVO.getPayeeId().toString());
						}
						
						billerPayRequestVO.getBillerPayDetailsVO().setBillerMaxPmt(billerPayResponseVO.getBillerPayDetailsVO().getBillerMaxPmt());
						billerPayRequestVO.getBillerPayDetailsVO().setBillerMinPmt(billerPayResponseVO.getBillerPayDetailsVO().getBillerMinPmt());
						billerPayResponseVO.setErrorDesc(Messages._350.getMessage());
						billerPayResponseVO.setErrorCD(Messages._350.getCode());
						billerPayResponseVO.setStatus(Messages._0.getCode());
						billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
						if (payeeDetailVO != null) {
							payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_SUCCESS);
						}
						break;

					case CommonConstants.ALIPAY_ACCOUNT_STATUS_ABNORMAL:
						LOGGER.info("Got Failure from Aggregator for" + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						billerPayResponseVO = new BillerPayResponseVO();
						billerPayResponseVO.setErrorDesc("ACCOUNT_STATUS_ABNORMAL");
						billerPayResponseVO.setErrorCD(CommonConstants.ALIPAY_ACCOUNT_STATUS_ABNORMAL);
						billerPayResponseVO.setStatus(Messages._1.getCode());
						billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
						if (payeeDetailVO != null) {
							payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
						}
						break;
					case CommonConstants.ALIPAY_PAYEE_ACCOUNT_NOT_EXIST:
						LOGGER.info("Got Failure from Aggregator for" + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						billerPayResponseVO = new BillerPayResponseVO();
						billerPayResponseVO.setErrorDesc("PAYEE_ACCOUNT_NOT_EXIST");
						billerPayResponseVO.setErrorCD(CommonConstants.ALIPAY_PAYEE_ACCOUNT_NOT_EXIST);
						billerPayResponseVO.setStatus(Messages._1.getCode());
						billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
						if (payeeDetailVO != null) {
							payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
						}
						break;
					case CommonConstants.ALIPAY_AMOUNT_EXCEED_LIMIT:
						if(billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_INSERT_ROUTE)){
							LOGGER.info("Got success from Aggregator for " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
							if (payeeDetailVO != null) {
								billerPayRequestVO.getBillerPayDetailsVO().setPayeeId(payeeDetailVO.getPayeeId().toString());
							}
							billerPayRequestVO.getBillerPayDetailsVO().setBillerMaxPmt(billerPayResponseVO.getBillerPayDetailsVO().getBillerMaxPmt());
							billerPayRequestVO.getBillerPayDetailsVO().setBillerMinPmt(billerPayResponseVO.getBillerPayDetailsVO().getBillerMinPmt());
							billerPayResponseVO.setErrorDesc(Messages._350.getMessage());
							billerPayResponseVO.setErrorCD(Messages._350.getCode());
							billerPayResponseVO.setStatus(Messages._0.getCode());
							billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
							if (payeeDetailVO != null) {
								payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_SUCCESS);
							}
						}else{
						LOGGER.info("Got Failure from Aggregator for " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						billerPayResponseVO = new BillerPayResponseVO();
						billerPayResponseVO.setErrorDesc("AMOUNT_EXCEED_LIMIT");
						billerPayResponseVO.setErrorCD(CommonConstants.ALIPAY_AMOUNT_EXCEED_LIMIT);
						billerPayResponseVO.setStatus(Messages._1.getCode());
						billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
						if (payeeDetailVO != null) {
							payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
						}
						}
						break;
					case CommonConstants.ALIPAY_SYSTEM_ERROR:
						LOGGER.info("Got Failure from Aggregator for " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						billerPayResponseVO = new BillerPayResponseVO();
						billerPayResponseVO.setErrorDesc("SYSTEM_ERROR");
						billerPayResponseVO.setErrorCD(CommonConstants.ALIPAY_SYSTEM_ERROR);
						billerPayResponseVO.setStatus(Messages._1.getCode());
						billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
						if (payeeDetailVO != null) {
							payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
						}
						break;
					default:
						LOGGER.info("Got Failure from Aggregator for " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
						//billerPayResponseVO = new BillerPayResponseVO();
						billerPayResponseVO.setErrorDesc(billerPayResponseVO.getStatusDesc());
						billerPayResponseVO.setErrorCD(billerPayResponseVO.getStatus());
						billerPayResponseVO.setStatus(Messages._1.getCode());
						billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
						if (payeeDetailVO != null) {
							payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
						}
					}
					if(!billerPayResponseVO.getErrorCD().equalsIgnoreCase(Messages._350.getCode())){
					billerPayRequestVO.getBillerPayDetailsVO().setHostName(CommonConstants.ALIPAY_AGGREGATOR);
				}
				} else {
					// Null status
					LOGGER.info("Got Failure from Aggregator for " + billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO.setErrorDesc(ExceptionMessages._164.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._164.getCode());
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					if (payeeDetailVO != null) {
						payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
					}
				}
			} else {
				// Null response
				LOGGER.info("Got Failure from Aggregator for "+billerPayRequestVO.getBillerPayDetailsVO().getConsumerNo());
				billerPayResponseVO = new BillerPayResponseVO();
				billerPayResponseVO.setErrorDesc(ExceptionMessages._164.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._164.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
				if(payeeDetailVO!=null){
					payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_FAILED);
					}
			}
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			payloadDTO.setResponseVO(billerPayResponseVO);
			payloadDTO.setRequestVO(billerPayRequestVO);
			LOGGER.info("Inside ValidatePayeeProcessor process method-End");
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
			LOGGER.info("Inside ValidatePayeeProcessor process method Exception"+e.getMessage()); 
			payeeDetailVO=new PayeeDetailVO();
			payeeDetailVO.setRemarks(CommonConstants.PAYEE_AUTH_AGG_EXCEPTION);
			billerPayResponseVO = new BillerPayResponseVO();
			billerPayResponseVO.setErrorDesc(ExceptionMessages._164.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._164.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());

			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			payloadDTO.setResponseVO(billerPayResponseVO);
		}finally{
			if(billerPayRequestVO.getServiceVO().getServiceName().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_INSERT_ROUTE))
			payeeService.updatePayeeStatus(payeeDetailVO);
		}
		return payloadDTO;
	}

	/**
	 * @param paymentDetailsService
	 */
	public void setPaymentDetailsService(PaymentDetailsService paymentDetailsService) {
		this.paymentDetailsService = paymentDetailsService;
	}
	
	/**
	 * @param payloadDTO
	 * @return
	 */
	public PayloadDTO processCS(PayloadDTO payloadDTO) {
		LOGGER.info("Inside ValidatePayeeProcessor processCS method-Start "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		BillerPayDetailsVO billerPayDetailsVO=billerPayRequestVO.getBillerPayDetailsVO();
		List<BillerField> paybillFields=new ArrayList<BillerField>();
		List<BillerField> resbillFields=new ArrayList<BillerField>();
		String dueAmtValue="";
		/*List<String> doNotDisplay=new ArrayList<String>();
		doNotDisplay.add("DueAmount");
		doNotDisplay.add("Balance");
		doNotDisplay.add("DueDate");
		doNotDisplay.add("Amount");*/
		try{
		BillerVO billerVO=payeeService.getUniqueBillerId(payloadDTO);
		billerPayDetailsVO.setBillerCd(billerVO.getBillerId());;
		LOGGER.info("Inside ValidatePayeeProcessor got biller data from DB "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		//This block will only execute when validation is required --Start
		
		if(Integer.parseInt(billerVO.getBillPresentmentType())>CommonConstants.ZERO_INT){
			LOGGER.info("Inside ValidatePayeeProcessor processCS before edmi call "+payloadDTO.getRequestVO().getMessageVO().getReqID());
			BillerPayResponseVO aggregaorRes = paymentDetailsService.getpaymentDetails(billerPayRequestVO);
			billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());;
			if(aggregaorRes.getStatus()!=null && !aggregaorRes.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)){
				return sendFailureResponse(payloadDTO, billerPayResponseVO, billerPayRequestVO);
				}else{
				//String validatePayeeResponse="AccountID|0010904-03|Name| KANTARIA INVESTMENTS |Amount Due|2317.82";
					//AccountID|11111|Name|WANJIRU MUTHONI|Balance|800.12|DueDate|2016-11-30
				String aggregatorResposneFileds=aggregaorRes.getBillerPayDetailsVO().getPaymentDetailsVO().getPaymentDescription();
				//Process response fields received from Aggregator in case of success --Start
				//String [] responseFields=aggregatorResposneFileds.split(CommonConstants.RESPONSE_FIELDS_DELIMITER);
				String [] responseFields=aggregatorResposneFileds.split("\\|");
				//String validatePayeeResponse="AccountID|11111|Name|WANJIRU MUTHONI|Balance|800.12|DueDate|2016-11-30";
				//String [] responseFields=validatePayeeResponse.split("\\|");
				/*if(!checkIsReponseFieldsMatchesWitExisingFields(responseFields,billerVO)){
					return sendFailureResponse(payloadDTO, billerPayResponseVO, billerPayRequestVO);	
				}*/
				LOGGER.info("Inside ValidatePayeeProcessor :: response fields "+responseFields+" req id"+payloadDTO.getRequestVO().getMessageVO().getReqID());
				BillerField resField=null;
				boolean isFieldId=true;
					for (String field : responseFields) {
						if (isFieldId) {
							resField = new BillerField();
							resField.setFieldLabelName(field);
							isFieldId = false;
						} else {
							resField.setFieldValue(field);
							isFieldId = true;
						}
						if (isFieldId) {
							if(Arrays.asList(dataBean.getMap().
									get(CommonConstants.CS_RESPOSNE_AMT_FIELDS).
									split(CommonConstants.COMMA)).contains(
											resField.getFieldLabelName())){
								dueAmtValue=resField.getFieldValue();
							}
							LOGGER.info("Response fields for  biller Uniqueid "
									+ billerVO.getBillerUniqueId()
									+ "biller id "
									+ billerVO.getBillerId()
									+ "getFieldLabelName "
									+ resField.getFieldLabelName()
									+ "getFieldValue "
									+ resField.getFieldValue()
									+ "Req Id       "
									+ payloadDTO.getRequestVO().getMessageVO()
											.getReqID());

							resbillFields.add(resField);
						}
					}
			}
		}
		billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());;
		//This block will only execute when validation is required --End
		//String doNotDisplay[]=new String[]{"Due Amount","Due Date","Balence"};
		//List<String>  
		//Process Name fields , Paybill fields , response fields --Start
		for (BillerField dbField : billerVO.getBillerFields()) {
			if(!dbField.getFieldType().equalsIgnoreCase(CommonConstants.N)){
			String dbFieldName = dbField.getFieldLabelName().trim();
     		switch (dbField.getFieldType()) {
				case CommonConstants.P:
					
					for (BillerField billerFieldIn : billerPayDetailsVO.getBillerFields()) {
					if (dbFieldName.equalsIgnoreCase(billerFieldIn.getFieldLabelName().trim())) {
						if(dbFieldName.equalsIgnoreCase(CommonConstants.AMOUNT_FIELD)){
							dbField.setFieldValue(dueAmtValue);	
						}else{
						dbField.setFieldValue(billerFieldIn.getFieldValue());
						}
					}
					}
					if(billerPayRequestVO.getServiceVO().getServiceTxnType()!=null && billerPayRequestVO.getServiceVO().getServiceTxnType().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_FETCH)){
					paybillFields.add(dbField);
					}
                    break;
                    
                    
				case CommonConstants.R:
					for(BillerField responseField:resbillFields){
						if(responseField.getFieldLabelName().equalsIgnoreCase(dbFieldName)){
							dbField.setFieldValue(responseField.getFieldValue());
						}
					}
					if(billerPayRequestVO.getServiceVO().getServiceTxnType()!=null && billerPayRequestVO.getServiceVO().getServiceTxnType().equalsIgnoreCase(CommonConstants.VALIDATE_PAYEE_FETCH)){
						paybillFields.add(dbField);
					}else{
							if(!Arrays.asList(dataBean.getMap().
									get(CommonConstants.CS_DONOT_DISPLAY_TAGS_ADDPAYEE).
									split(CommonConstants.COMMA)).contains(
											dbField.getFieldLabelName())){
								paybillFields.add(dbField);	
							}
						
						/*if(!doNotDisplay.contains(dbField.getFieldLabelName())){
							paybillFields.add(dbField);	
						}*/
						
						}
                     break;
                     
				case CommonConstants.N:
					/*if (dbFieldName.equalsIgnoreCase(inputFieldName)) {
						dbField.setFieldValxcxue(billerField.getFieldValue());
					}
					paybillFields.add(dbField);*/
					break;
				default:

				}
			}
		}
		//Process Name fields , Paybill fields , response fields --End
		billerPayDetailsVO.getBillerFields().clear();
		billerPayDetailsVO.getBillerFields().addAll(paybillFields);
		
		billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
		billerPayResponseVO.setErrorDesc(Messages._351.getMessage());
		billerPayResponseVO.setErrorCD(Messages._351.getCode());
		billerPayResponseVO.setStatus(Messages._0.getCode());
		billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		payloadDTO.setResponseVO(billerPayResponseVO);
		payloadDTO.setRequestVO(billerPayRequestVO);
		}catch(Exception e){
			LOGGER.info("Inside ValidatePayeeProcessor Exception "+payloadDTO.getRequestVO().getMessageVO().getReqID());
			LOGGER.error("Inside ValidatePayeeProcessor Error ",e);
			//billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
			billerPayResponseVO.setErrorDesc(ExceptionMessages._149.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._149.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			payloadDTO.setResponseVO(billerPayResponseVO);
			payloadDTO.setRequestVO(billerPayRequestVO);
		}
		LOGGER.info("Inside ValidatePayeeProcessor processCS method-End "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		return payloadDTO;
	}

	/**
	 * @param payloadDTO
	 * @param billerPayResponseVO
	 * @param billerPayRequestVO
	 * @return
	 */
	private PayloadDTO sendFailureResponse(PayloadDTO payloadDTO, BillerPayResponseVO billerPayResponseVO, BillerPayRequestVO billerPayRequestVO) {
		billerPayResponseVO.setErrorDesc(ExceptionMessages._160.getMessage());
		billerPayResponseVO.setErrorCD(ExceptionMessages._160.getCode());
		billerPayResponseVO.setStatus(Messages._1.getCode());
		billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		payloadDTO.setResponseVO(billerPayResponseVO);
		payloadDTO.setRequestVO(billerPayRequestVO);
		return payloadDTO;
	}

	private boolean checkIsReponseFieldsMatchesWitExisingFields(String[] responseFields, BillerVO billerVO) {
		LOGGER.info("Inside ValidatePayeeProcessor checkIsReponseFieldsMatchesWitExisingFields method-Start "+billerVO.getBillerId());
		int fieldFlag=0;
		boolean isFiedExists=false;
		for(String resFieldName:responseFields){
			isFiedExists=false;
			fieldFlag=1;
			if(fieldFlag%2!=0){
			for(BillerField field:billerVO.getBillerFields()){
				if(resFieldName.equalsIgnoreCase(field.getFieldLabelName()) && field.getFieldType().equalsIgnoreCase(CommonConstants.R)){
				isFiedExists=true;
				 break;	
				}
			 }
			 if(isFiedExists){
				 return false;
			 }
			}
		}
		LOGGER.info("Inside ValidatePayeeProcessor checkIsReponseFieldsMatchesWitExisingFields method-End "+billerVO.getBillerId());
		return true;
	}
	//Added for Orange Money
	public PayloadDTO processCSWallet(PayloadDTO payloadDTO) {
		LOGGER.info("Inside ValidatePayeeProcessor - processCSWallet - method-Start "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		BillerPayDetailsVO billerPayDetailsVO=billerPayRequestVO.getBillerPayDetailsVO();
		try{
		BillerVO billerVO=payeeService.getWalletUniqueBillerId(payloadDTO);
		billerPayDetailsVO.setBillerCd(billerVO.getBillerId());
		LOGGER.info("Inside ValidatePayeeProcessor processCSWallet got biller data from DB :::"+payloadDTO.getRequestVO().getMessageVO().getReqID());
		//This block will only execute when validation is required --Start

		String strCurrencyCode="";
		String strTranType="";
		String RegRequiredParams =  null;
		String strErrorCode = "";
		String strAlias = "";
		
		List<ISOCODESVO> isocodesvos = referenceService.getCurrency(payloadDTO.getRequestVO().getClientVO().getCountry());
		if(isocodesvos != null && isocodesvos.size()>0){
			for(ISOCODESVO isocodesvo : isocodesvos){
				strCurrencyCode = isocodesvo.getCurrencycode_char();
				LOGGER.info("Inside ValidatePayeeProcessor - processCSWallet - currencyCheck isocodesvos:::"+strCurrencyCode);
			}
		}
	
		for(BillerField billerField: billerPayDetailsVO.getBillerFields()){
			if(billerField.getCaption().equalsIgnoreCase(CommonConstants.TRANSFER_TYPE_TEXT)){				
				strTranType = CommonConstants.hmWalletTransferType.get(billerField.getFieldValue());	
				LOGGER.info("Inside ValidatePayeeProcessor - processCSWallet - strTranType :::"+strTranType);
			}
		}
		
		if(StringUtils.isEmpty(strTranType) || (strTranType == null)){
			strTranType = "3";
		}
		
		if(strTranType != null) {
			
		//Added newly -start
		String strDBSeq = payeeService.getCommonSequenceNumberGenerator();
		LOGGER.info("Inside ValidatePayeeProcessor processCSWallet strDBSeq is ::: " + strDBSeq);
		//Added newly - end
		
		//DB Entry required
		String strBIC = dataBean.getMap().get(payloadDTO.getRequestVO().getClientVO().getCountry() + CommonConstants.BANK_IDENTIFICATION_CODE)+ReferenceNumberGenerator.generateReferenceNumber()+strDBSeq+strTranType;  //SCHBBWGX - (HEAD OFFICE)
		LOGGER.info("Inside ValidatePayeeProcessor processCSWallet before edmi call --- BIC Identification number is ::: " + strBIC);
		//DB entry required
		RegRequiredParams = dataBean.getMap().get(payloadDTO.getRequestVO().getClientVO().getCountry() + billerVO.getBillerId()+ CommonConstants.UNDERSCORE+CommonConstants.REG);    
		
		if(RegRequiredParams == null) {
			RegRequiredParams = dataBean.getMap().get(billerVO.getBillerId()+ CommonConstants.UNDERSCORE+CommonConstants.REG); 
		}
		LOGGER.info("Inside ValidatePayeeProcessor processCSWallet before edmi call --- RegRequiredParams -- Mapping Parameters are ::: " + RegRequiredParams);
		
		billerPayDetailsVO.setTxnCurrency(strCurrencyCode);
		billerPayDetailsVO.setTxnActivity(strBIC);
		billerPayDetailsVO.setPayMthd(strTranType);
		
		//ACCOUNTID:{billerPayDetailsVO.txnActivity}:INFOFIELD1:{billerPayDetailsVO.billerNickName}:INFOFIELD2:{billerPayDetailsVO.txnCurrency}:INFOFIELD3:{billerPayDetailsVO.payMthd}:INFOFIELD4:{clientVO.date(Calendar,ddMMYYYY)}
		String fieldsDelimitedStr = NarrationHelper.replceText(RegRequiredParams, billerPayRequestVO, true);
			
		if(Integer.parseInt(billerVO.getBillPresentmentType())>CommonConstants.ZERO_INT){
			LOGGER.info("Inside ValidatePayeeProcessor processCSWallet before edmi call "+payloadDTO.getRequestVO().getMessageVO().getReqID());
  			BillerPayResponseVO aggregaorRes = paymentDetailsService.getpaymentWalletDetails(billerPayRequestVO,fieldsDelimitedStr);
			
		//	BillerPayResponseVO aggregaorRes = new BillerPayResponseVO();
			//	aggregaorRes.setStatus(CommonConstants.SUCCESS);
				//aggregaorRes.setStatus(CommonConstants.FAILURE);
			
			billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());
			if(aggregaorRes!=null && aggregaorRes.getStatus()!=null && !aggregaorRes.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)){
				return sendFailureCsResponse(payloadDTO, aggregaorRes, billerPayRequestVO); 
				//return sendFailureCsResponse(payloadDTO, aggregaorRes, billerPayRequestVO); //Mocked for Failure response
				}else{
				//String validatePayeeResponse="AccountID|0010904-03|Name| KANTARIA INVESTMENTS |Amount Due|2317.82";
					//AccountID|11111|Name|WANJIRU MUTHONI|Balance|800.12|DueDate|2016-11-30
				//String aggregatorResposneFileds= "Alias|"+strBIC+"|Return Code|200"; 
				String aggregatorResposneFileds= aggregaorRes.getBillerPayDetailsVO().getPaymentDetailsVO().getPaymentDescription();
				//Process response fields received from Aggregator in case of success --Start
				//String [] responseFields=aggregatorResposneFileds.split(CommonConstants.RESPONSE_FIELDS_DELIMITER);
				String [] responseFields=aggregatorResposneFileds.split("\\|");
				//String validatePayeeResponse="AccountID|11111|Name|WANJIRU MUTHONI|Balance|800.12|DueDate|2016-11-30";
				//String [] responseFields=validatePayeeResponse.split("\\|");
				/*if(!checkIsReponseFieldsMatchesWitExisingFields(responseFields,billerVO)){
					return sendFailureResponse(payloadDTO, billerPayResponseVO, billerPayRequestVO);	
				}*/
				
				//Added newly - start
				List<String> list = Arrays.asList(responseFields);

			    Map<String, String> map = new HashMap<>();
			    for (int i = 0; i < list.size() - 1; i += 2) {
			        map.put(list.get(i), list.get(i + 1));
			    }
			    strAlias = map.get(CommonConstants.ALIAS);
			    billerPayRequestVO.getUser().setLoginId(strAlias);
			    
			    strErrorCode = map.get("Return Code");
			    
			    //LOGGER.info("Inside ValidatePayeeProcessor :: response fields "+responseFields+" response BIC number After CS call ::: "+ strAlias);
			    //LOGGER.info("Inside ValidatePayeeProcessor :: response fields "+responseFields+" response BIC number After CS call ::: "+ strErrorCode);
				//Added newly - end
				LOGGER.info("Inside ValidatePayeeProcessor :: response fields {} :: req id {} :: strAlias {} :: strErrorCode {}", new Object[]{responseFields,payloadDTO.getRequestVO().getMessageVO().getReqID(),strAlias,strErrorCode});
			}
		}
		    if(StringUtils.isNotEmpty(strAlias)){
				billerPayResponseVO.setErrorDesc(Messages._351.getMessage());
				billerPayResponseVO.setErrorCD(Messages._351.getCode());
				billerPayResponseVO.setStatus(Messages._0.getCode());
				billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
		    }else{
			    billerPayResponseVO.setErrorDesc(ExceptionMessages._160.getMessage());
				billerPayResponseVO.setErrorCD(ExceptionMessages._160.getCode());
				billerPayResponseVO.setStatus(Messages._1.getCode());
				billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
		    }
		     		    
		}
		
//		else {
//			billerPayResponseVO.setErrorDesc(ExceptionMessages._243.getMessage());
//			billerPayResponseVO.setErrorCD(ExceptionMessages._243.getCode());
//			billerPayResponseVO.setStatus(Messages._1.getCode());
//			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());	
//		}
		
		billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());
		billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		payloadDTO.setResponseVO(billerPayResponseVO);
		payloadDTO.setRequestVO(billerPayRequestVO);
		
		}catch(Exception e){
			//e.printStackTrace();
		//	LOGGER.info("Inside ValidatePayeeProcessor - processCSWallet - Exception "+payloadDTO.getRequestVO().getMessageVO().getReqID());
			LOGGER.error("Inside ValidatePayeeProcessor Error ",e);
			billerPayResponseVO.setErrorDesc(ExceptionMessages._149.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._149.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			payloadDTO.setResponseVO(billerPayResponseVO);
			payloadDTO.setRequestVO(billerPayRequestVO);
		}
		LOGGER.info("Inside ValidatePayeeProcessor processCSWallet method-End "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		return payloadDTO;
	}
	//Added for Delete Wallet CS call
	
	public PayloadDTO processWalletDeleteCS(PayloadDTO payloadDTO) {
		LOGGER.info("Inside ValidatePayeeProcessor processWalletDeleteCS method-Start "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		BillerPayResponseVO billerPayResponseVO = new BillerPayResponseVO();
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO) payloadDTO.getRequestVO();
		BillerPayDetailsVO billerPayDetailsVO=billerPayRequestVO.getBillerPayDetailsVO();
		List<PayeeDetailVO> payeeDetailVODB=new ArrayList<PayeeDetailVO>();
		try{
	//	BillerVO billerVO=payeeService.getUniqueBillerId(payloadDTO);
		//billerPayDetailsVO.setBillerCd(billerVO.getBillerId());
		LOGGER.info("Inside ValidatePayeeProcessor: processWalletDeleteCS: got biller data from DB "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		//This block will only execute when validation is required --Start

		//Added for fetch the wallet BIC number from DB start
		
		Long strPayeeId = billerPayDetailsVO.getId();
		String strBIC = null;
		String strNickName = null;
		BillerVO billerVO = null;
		
		String strAlias = "";
		//DB entry required
	    String RegRequiredParams =  null;
		if(strPayeeId != null){
			 
			try {
				LOGGER.info("Inside ValidatePayeeProcessor before fetching the Wallet information based on PayeeId ");
				payeeDetailVODB = payeeService.getWalletPayee(billerPayRequestVO);
				
				if(payeeDetailVODB !=null && payeeDetailVODB.size() > 0){
					LOGGER.info("Inside ValidatePayeeProcessor after fetching the Wallet information based on PayeeId :: payeeDetailVODB is not null ");
					PayeeDetailVO payeeDetailVO = payeeDetailVODB.get(0);
					strBIC = payeeDetailVO.getConsumerDetail();
					strNickName = payeeDetailVO.getPayeeShortName();
					billerVO = payeeDetailVO.getBillerVO();
					
					RegRequiredParams = dataBean.getMap().get(payloadDTO.getRequestVO().getClientVO().getCountry() + billerVO.getBillerId()+ CommonConstants.UNDERSCORE+CommonConstants.DEREG);    
					
					if(RegRequiredParams == null) {
						RegRequiredParams = dataBean.getMap().get(billerVO.getBillerId()+ CommonConstants.UNDERSCORE+CommonConstants.DEREG); 
					}
					LOGGER.info("Inside ValidatePayeeProcessor processWalletDeleteCS before edmi call --- str BIC number is " + strBIC);
					
					//Added for fetch the wallet BIC number from DB end
					
					billerPayDetailsVO.setTxnActivity(strBIC);
					billerPayDetailsVO.setBillerNickName(strNickName);
					
					//ACCOUNTID:{billerPayDetailsVO.txnActivity}:INFOFIELD1:{billerPayDetailsVO.billerNickName}:INFOFIELD2:{clientVO.date(Calendar,ddMMYYYY)}
					String fieldsDelimitedStr = NarrationHelper.replceText(RegRequiredParams, billerPayRequestVO, true);
					
					billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());
						
					if(Integer.parseInt(billerVO.getBillPresentmentType())>CommonConstants.ZERO_INT){
						LOGGER.info("Inside ValidatePayeeProcessor processWalletDeleteCS before edmi call "+payloadDTO.getRequestVO().getMessageVO().getReqID());
			  			BillerPayResponseVO aggregaorRes = paymentDetailsService.getpaymentWalletDetails(billerPayRequestVO,fieldsDelimitedStr);
						
						//below two lines are for mocking the CS validate wallet call 
						/*BillerPayResponseVO aggregaorRes = new BillerPayResponseVO();
						aggregaorRes.setStatus(CommonConstants.SUCCESS);*/
						
						//now  billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());;
						if(aggregaorRes!=null && aggregaorRes.getStatus()!=null && !aggregaorRes.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)){
							return sendFailureCsResponse(payloadDTO, aggregaorRes, billerPayRequestVO);
							}else{
							//String validatePayeeResponse="AccountID|0010904-03|Name| KANTARIA INVESTMENTS |Amount Due|2317.82";
								//AccountID|11111|Name|WANJIRU MUTHONI|Balance|800.12|DueDate|2016-11-30
							//String aggregatorResposneFileds= "Alias|42342344|Return Code|200"; 
								String aggregatorResposneFileds=aggregaorRes.getBillerPayDetailsVO().getPaymentDetailsVO().getPaymentDescription();
							//Process response fields received from Aggregator in case of success --Start
							//String [] responseFields=aggregatorResposneFileds.split(CommonConstants.RESPONSE_FIELDS_DELIMITER);
							String [] responseFields=aggregatorResposneFileds.split("\\|");
							//String validatePayeeResponse="AccountID|11111|Name|WANJIRU MUTHONI|Balance|800.12|DueDate|2016-11-30";
							//String [] responseFields=validatePayeeResponse.split("\\|");
							/*if(!checkIsReponseFieldsMatchesWitExisingFields(responseFields,billerVO)){
								return sendFailureResponse(payloadDTO, billerPayResponseVO, billerPayRequestVO);	
							}*/
							
							//Added newly - start
							
							List<String> list = Arrays.asList(responseFields);
							//System.out.println(list);

						    Map<String, String> map = new HashMap<>();
						    for (int i = 0; i < list.size() - 1; i += 2) {
						        map.put(list.get(i), list.get(i + 1));
						    }
						    strAlias = map.get(CommonConstants.ALIAS);
						    billerPayRequestVO.getUser().setLoginId(strAlias);
						    
						    //LOGGER.info("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: response fields: "+responseFields+" :response BIC number is ::: "+ strAlias);
							//Added newly - end
							LOGGER.info("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: response fields: {}:: strAlias: {} :: req id:{}", new Object[]{responseFields,strAlias,payloadDTO.getRequestVO().getMessageVO().getReqID()});
						}
					}
					
					if(StringUtils.isNotEmpty(strAlias)){
						billerPayResponseVO.setErrorDesc(Messages._351.getMessage());
						billerPayResponseVO.setErrorCD(Messages._351.getCode());
						billerPayResponseVO.setStatus(Messages._0.getCode());
						billerPayResponseVO.setStatusDesc(Messages._0.getMessage());
					}
					else{
						billerPayResponseVO.setErrorDesc(ExceptionMessages._160.getMessage());
						billerPayResponseVO.setErrorCD(ExceptionMessages._160.getCode());
						billerPayResponseVO.setStatus(Messages._1.getCode());
						billerPayResponseVO.setStatusDesc(Messages._1.getMessage());	
					}
				 		
					billerPayDetailsVO.setBillerCd(billerVO.getBillerUniqueId());;
					billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
					billerPayResponseVO.setUser(billerPayRequestVO.getUser());
					billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
					billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
					billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
					payloadDTO.setResponseVO(billerPayResponseVO);
					payloadDTO.setRequestVO(billerPayRequestVO);
				}
				
				else{
					billerPayResponseVO.setErrorDesc(ExceptionMessages._244.getMessage());
					billerPayResponseVO.setErrorCD(ExceptionMessages._244.getCode());
					billerPayResponseVO.setStatus(Messages._1.getCode());
					billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
					billerPayResponseVO.setUser(billerPayRequestVO.getUser());
					billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
					billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
					billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
					payloadDTO.setResponseVO(billerPayResponseVO);
					payloadDTO.setRequestVO(billerPayRequestVO);
				}
				
			  }
			 catch (Exception exception) {
		        //exception.printStackTrace();
				//LOGGER.error("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: Exception" + exception.getMessage());
				LOGGER.error("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: Exception" ,exception);
			 }
		}
		//Added for calling Delete Wallets from BO - start
		else if(strPayeeId == null && CommonConstants.DELETE_WALLET_PAYEE.equalsIgnoreCase(billerPayRequestVO.getServiceVO().getServiceName())) {
			LOGGER.info("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: Calling from BO :: PayeeId null and Service is WALLET");
			try {
				LOGGER.info("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: Before calling the delete Wallet Payee BO");
	            billerPayResponseVO = payeeService.deleteWalletPayeeBO(billerPayRequestVO);
	            LOGGER.info("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: After calling the delete Wallet Payee BO");
				billerPayResponseVO.setErrorDesc(Messages._351.getMessage());
				billerPayResponseVO.setErrorCD(Messages._351.getCode());
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				payloadDTO.setResponseVO(billerPayResponseVO);
				payloadDTO.setRequestVO(billerPayRequestVO);
				}
			 catch (Exception exception) {
		        //exception.printStackTrace();
				//LOGGER.info("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: Exception" + exception.getMessage());
				LOGGER.error("Inside ValidatePayeeProcessor :: processWalletDeleteCS :: Exception" ,exception);
			}
		}//Added for calling Delete Wallets from BO - end
		}catch(Exception e){
			//e.printStackTrace();
		//	LOGGER.info("Inside ValidatePayeeProcessor processWalletDeleteCS Exception "+payloadDTO.getRequestVO().getMessageVO().getReqID());
			LOGGER.error("Inside ValidatePayeeProcessor processWalletDeleteCS Error ",e);
			//billerPayResponseVO.setBillerPayDetailsVO(billerPayDetailsVO);
			billerPayResponseVO.setErrorDesc(ExceptionMessages._149.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._149.getCode());
			billerPayResponseVO.setStatus(Messages._1.getCode());
			billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			payloadDTO.setResponseVO(billerPayResponseVO);
			payloadDTO.setRequestVO(billerPayRequestVO);
		}
		LOGGER.info("Inside ValidatePayeeProcessor processWalletDeleteCS method-End "+payloadDTO.getRequestVO().getMessageVO().getReqID());
		return payloadDTO;
	}
	
	private PayloadDTO sendFailureCsResponse(PayloadDTO payloadDTO, BillerPayResponseVO billerPayResponseVO, BillerPayRequestVO billerPayRequestVO) {
			LOGGER.info("ValidatePayeeProcessor: sendFailureCsResponse : starts");
			//String aggregatorResposneFileds= "Alias|42342344|Return Code|603"; 
			String aggregatorResposneFileds= billerPayResponseVO.getBillerPayDetailsVO().getPaymentDetailsVO().getPaymentDescription();
			//Process response fields received from Aggregator in case of success --Start
			//String [] responseFields=aggregatorResposneFileds.split(CommonConstants.RESPONSE_FIELDS_DELIMITER);
			String [] responseFields=aggregatorResposneFileds.split("\\|");
			
			List<String> list = Arrays.asList(responseFields);

		    Map<String, String> map = new HashMap<>();
		    for (int i = 0; i < list.size() - 1; i += 2) {
		        map.put(list.get(i), list.get(i + 1));
		    }
		   /* String strAlias = map.get(CommonConstants.ALIAS);
		    billerPayRequestVO.getUser().setLoginId(strAlias);*/
		    
		    String strErrorCode = map.get("Return Code");
		    
		    if(StringUtils.isNotEmpty(strErrorCode)){
		         billerPayResponseVO.setErrorDesc(ExceptionMessages._160.getMessage());
		         billerPayResponseVO.setErrorCD(strErrorCode);
		    }else{
		    	 billerPayResponseVO.setErrorDesc(ExceptionMessages._160.getMessage());
		    	 billerPayResponseVO.setErrorCD(ExceptionMessages._160.getCode());	
		    }
				
		/*billerPayResponseVO.setErrorDesc(ExceptionMessages._160.getMessage());
		billerPayResponseVO.setErrorCD(strErrorCode);*/
		billerPayResponseVO.setStatus(Messages._1.getCode());
		billerPayResponseVO.setStatusDesc(Messages._1.getMessage());
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		payloadDTO.setResponseVO(billerPayResponseVO);
		payloadDTO.setRequestVO(billerPayRequestVO);
		LOGGER.info("ValidatePayeeProcessor: sendFailureCsResponse : ends");
		return payloadDTO;
	}
}