package com.scb.channels.payments.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import com.ctc.wstx.cfg.ErrorConsts;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerFieldItemVO;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.common.Biller;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.dao.BillerManagementDAO;
import com.scb.channels.payments.service.BillerManagementService;
import com.scb.channels.payments.service.CacheManagementService;


public class BillerManagementServiceImpl implements BillerManagementService {
	
	private BillerManagementDAO billerManageDAO;

 
	
	private CacheManagementService   cacheService;
	


	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerManagementServiceImpl.class);
	 
	public BillerManagementDAO getBillerManageDAO() {
		return billerManageDAO;
	}


	public void setBillerManageDAO(BillerManagementDAO billerManageDAO) {
		this.billerManageDAO = billerManageDAO;
	}
	
	public CacheManagementService getCacheService() {
		return cacheService;
	}


	public void setCacheService(CacheManagementService cacheService) {
		this.cacheService = cacheService;
	}

	@Override
	public BillerPayResponseVO getBillerCategories(
			BillerPayRequestVO billerPayRequestVO) {
		
		String Country=billerPayRequestVO.getClientVO().getCountry();
		
		BillerPayResponseVO response= new BillerPayResponseVO();
		
		
		List<BillerCategoryVO>  categoryList=null;
		
		
		
		try{
				
			categoryList=cacheService.getBillers(Country);
			
		
		if(categoryList!=null &&categoryList.size()>0 ){
			BillerPayDetailsVO billers = new BillerPayDetailsVO();
			billers.setBillerCategoryVO(categoryList);
			response.setBillerPayDetailsVO(billers);
			response.setStatus(Messages._0.getCode());
			response.setStatusDesc(Messages._0.getMessage());
		}else{
			
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setErrorCD(ExceptionMessages._127.getCode() );
			response.setErrorDesc(ExceptionMessages._127.getMessage());
		}
		
		
		}catch(Exception exception){
			LOGGER.debug("Exception at run time"+exception.getMessage()+"--------" +exception);
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setErrorCD(ExceptionMessages._127.getCode() );
			response.setErrorDesc(exception.getMessage());
		}
		
 		return response;
	}

	
	
	public BillerPayResponseVO getBillerNames(BillerPayRequestVO billerPayRequestVO){
		LOGGER.info("Inside BillerManagementServiceImpl getBillerNames method-Start"+billerPayRequestVO.getMessageVO().getReqID());
		String Country=billerPayRequestVO.getClientVO().getCountry();
		BillerPayDetailsVO billerrequest= billerPayRequestVO.getBillerPayDetailsVO();
		
		BillerPayResponseVO  response=new BillerPayResponseVO();
		String categoryId=billerrequest.getBillerCategoryCd();
		
		List<BillerVO> billers=null;
		List<BillerCategoryVO>  categoryList=null;
		
		int CategoryIdValue=Integer.valueOf(categoryId);
		
		 
		
		try{
			if(StringUtils.isNotBlank(categoryId)&& StringUtils.isNotBlank(Country)){
			
				billers=getBillersFromCache(Country,CategoryIdValue);
				/*	categoryList=cacheService.getBillers(Country);
					
					for(BillerCategoryVO category:categoryList){
						
						if(CategoryIdValue == category.getId()){
							
							if( category.getBillers().size()>0){
								LOGGER.debug("Actvie Biller Available for catgeory {}--{}", categoryId , Country);
								billers= new ArrayList<BillerVO>(0);
								for(BillerVO biller:category.getBillers()){
									if(biller.getStatusCode().equalsIgnoreCase(CommonConstants.ACTIVE)){
										billers.add(biller);
									}
								}

								billers.addAll(category.getBillers());
							}else{
								LOGGER.debug("No Actvie Biller Available for catgeory {}--{}", categoryId , Country);
							}
						}
						
					}*/
				
				/** 
				 * if not billers found for the billerCategory
				 */
				if(billers!=null & billers.size()>0){
					LOGGER.debug("Biller list size of  for category  {}--{}--{}",new Object[]{Country, categoryId  ,billers.size()});
					BillerPayDetailsVO billersPayVO =new BillerPayDetailsVO();
					BillerCategoryVO billertype= new BillerCategoryVO();
					billertype.getBillers().addAll(billers);
					billersPayVO.getBillerCategoryVO().add(billertype);
					response.setBillerPayDetailsVO(billersPayVO);
					response.setStatus(Messages._0.getCode());
					response.setStatusDesc(Messages._0.getMessage());
				}else{
					LOGGER.debug("Biller available Not for "+Country+"---"+ categoryId +"");
					response.setStatus(Messages._1.getCode());
					response.setStatusDesc(Messages._1.getMessage());
					response.setErrorCD(ExceptionMessages._127.getCode() );
					response.setErrorDesc(ExceptionMessages._127.getMessage());
				}
				
			
			
		}else{
			LOGGER.debug("Required Fields are empty for ");

			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setErrorCD(ExceptionMessages._127.getCode() );
			response.setErrorDesc(ExceptionMessages._127.getCode());
		}
		
		}catch(Exception exception){
			
			LOGGER.debug("Exception while Biller Retrieve"+exception.getMessage());
			exception.printStackTrace();
			response.setStatus(Messages._1.getCode());
			response.setStatusDesc(Messages._1.getMessage());
			response.setErrorCD(ExceptionMessages._127.getCode() );
			response.setErrorDesc(exception.getMessage());
		}
		
		return response;
	}
	
	public List<BillerVO> getBillerList(BillerPayRequestVO billerPayRequestVO){
		String Country=billerPayRequestVO.getClientVO().getCountry();
		BillerPayDetailsVO billerrequest= billerPayRequestVO.getBillerPayDetailsVO();
		String categoryId=billerrequest.getBillerCategoryCd();
		BillerPayResponseVO response=	getBillerNames(billerPayRequestVO);
		Set<BillerVO> billers =response.getBillerPayDetailsVO().getBillerCategoryVO().get(0).getBillers();
		List<BillerVO> list =null;
				if(billers!=null){
					list =new ArrayList<BillerVO>(0);
					list.addAll(billers);
				}
		//
		//List<BillerVO> list=(List<BillerVO>)cacheManager.getCache(CommonConstants.BILLER_CACHE).get(Country+CommonConstants.BILLER_LIST+CommonConstants.HYPHEN +categoryId).getValue();
		return list;
	}
	

	public List<BillerVO> getBillersFromCache(String Country, int CatgeoryId){
		
		List<BillerVO> billers=null;
		List<BillerCategoryVO>  categoryList=null;
		
		categoryList=cacheService.getBillers(Country);
		
		Set<BillerField> setBillerField=null;
		
		Set<BillerFieldItemVO> setItems=null;
		int presentment=0;
		for(BillerCategoryVO category:categoryList){
			
			if(CatgeoryId == category.getId()){
				
				if( category.getBillers().size()>0){
					LOGGER.debug("Actvie Biller Available for catgeory {}--{}", CatgeoryId , Country);
					billers= new ArrayList<BillerVO>(0);
					for(BillerVO biller:category.getBillers()){
						if(biller.getStatusCode().equalsIgnoreCase(CommonConstants.ACTIVE)){
							switch(biller.getCountryCode()){
							case CommonConstants.NG :
									billers.add(biller);
									break;
							default :
								if(biller.getIsOnline()!=null && biller.getIsOnline().equalsIgnoreCase(CommonConstants.YES_Y)){
									setBillerField=new HashSet<BillerField>();
									for(BillerField field:biller.getBillerFields()){
										if(field.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
											if(field.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
												setItems=new HashSet<BillerFieldItemVO>();
												for(BillerFieldItemVO item:field.getBillerFieldItems()){
													if(item.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
														setItems.add(item);
													}
												}
												field.setBillerFieldItems(setItems);
											}
											presentment=Integer.parseInt(biller.getBillPresentmentType());
											if(!field.getFieldLabelName().equalsIgnoreCase(CommonConstants.AMOUNT_FIELD))
											setBillerField.add(field);
										}
									}
									biller.setBillerFields(setBillerField);
									billers.add(biller);
								}
							}
							
						}
					}
				}else{
					LOGGER.debug("No Actvie Biller Available for catgeory {}--{}", CatgeoryId , Country);
				}
			}
			
		}
		
		
		return billers;
		
	}


	// Added for Orange Money - start
	
		@Override
	    public BillerPayResponseVO getWalletBillerNames(BillerPayRequestVO billerPayRequestVO) {
	           
	           LOGGER.info("Inside BillerManagementServiceImpl getWalletBillerNames method-Start: "+billerPayRequestVO.getMessageVO().getReqID());
	           String Country=billerPayRequestVO.getClientVO().getCountry();
	           BillerPayDetailsVO billerrequest= billerPayRequestVO.getBillerPayDetailsVO();
	           BillerPayResponseVO  response=new BillerPayResponseVO();
	           String categoryId=billerrequest.getBillerCategoryCd();
	           List<BillerVO> billers=null;
	           billers = getBillersFromCacheForWallet(Country, categoryId);
	                  
	           /** 
	            * if not billers found for the billerCategory
	           */
	           if(billers!=null & billers.size()>0){
	                  LOGGER.debug("Biller list size of  for category  {}--{}--{}",new Object[]{Country, categoryId  ,billers.size()});
	                  BillerPayDetailsVO billersPayVO =new BillerPayDetailsVO();
	                  BillerCategoryVO billertype= new BillerCategoryVO();
	                  billertype.getBillers().addAll(billers);
	                  billersPayVO.getBillerCategoryVO().add(billertype);
	                  response.setBillerPayDetailsVO(billersPayVO);
	                  response.setStatus(Messages._0.getCode());
	                  response.setStatusDesc(Messages._0.getMessage());
	           }else{
	                  LOGGER.debug("Biller available Not for "+Country+"---"+ categoryId +"");
	                  response.setStatus(Messages._1.getCode());
	                  response.setStatusDesc(Messages._1.getMessage());
	                  response.setErrorCD(ExceptionMessages._127.getCode() );
	                  response.setErrorDesc(ExceptionMessages._127.getMessage());                
	           }
	           LOGGER.info("Inside BillerManagementServiceImpl getWalletBillerNames method-End: "+billerPayRequestVO.getMessageVO().getReqID());
	           return response;
	    }

	 
		
		public List<BillerVO> getBillersFromCacheForWallet(String Country, String CatgeoryId){
	        
	        List<BillerVO> billers=null;
	        List<BillerCategoryVO>  categoryList=null;
	        
	        categoryList=cacheService.getWalletBillers(Country, CatgeoryId);
	        
	        Set<BillerField> setBillerField=null;
	        
	        Set<BillerFieldItemVO> setItems=null;
	        int presentment=0;
	        for(BillerCategoryVO category:categoryList){
	               
	               if(CatgeoryId.equals(category.getCategoryId())){
	                     
	                     if( category.getBillers().size()>0){
	                            LOGGER.debug("Actvie Biller Available for catgeory {}--{}", CatgeoryId , Country);
	                            billers= new ArrayList<BillerVO>(0);
	                            for(BillerVO biller:category.getBillers()){
//	                                   if(biller.getStatusCode().equalsIgnoreCase(CommonConstants.ACTIVE)){ // Biller Download disabling the status code of biller status from Active to deactive
	                            	if(biller.getStatusCode().equalsIgnoreCase(CommonConstants.D)){
	                                                 if(biller.getIsOnline()!=null && biller.getIsOnline().equalsIgnoreCase(CommonConstants.YES_Y)){
	                                                        setBillerField=new HashSet<BillerField>();
	                                                        for(BillerField field:biller.getBillerFields()){
	                                                               if(field.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
	                                                                      if(field.getFieldDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
	                                                                            setItems=new HashSet<BillerFieldItemVO>();
	                                                                            for(BillerFieldItemVO item:field.getBillerFieldItems()){
	                                                                                   if(item.getStatus().equalsIgnoreCase(CommonConstants.ACTIVE)){
	                                                                                          setItems.add(item);
	                                                                                   }
	                                                                            }
	                                                                            field.setBillerFieldItems(setItems);
	                                                                     }
	                                                                      presentment=Integer.parseInt(biller.getBillPresentmentType());
	                                                                      if(!field.getFieldLabelName().equalsIgnoreCase(CommonConstants.AMOUNT_FIELD))
	                                                                            setBillerField.add(field);
	                                                               }
	                                                        }
	                                                        biller.setBillerFields(setBillerField);
	                                                        billers.add(biller);
	                                                 }                                               
	                                   }
	                            }
	                     }else{
	                            LOGGER.debug("No Actvie Biller Available for catgeory {}--{}", CatgeoryId , Country);
	                     }
	               }                    
	        }             
	        return billers;            
	 }


 
	
	
	

}
