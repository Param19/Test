package com.scb.channels.payments.service;

import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;

public interface ArchivalService {
	
	public BillerDownloadResponseVO archive(BillerDownloadRequest billerDownloadRequest);
	
}
