package com.scb.channels.qrpayments.processor;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.QRPaymentVisaCardAcceptor;
import com.scb.channels.base.vo.QRPaymentVisaCardAcceptorAddress;
import com.scb.channels.base.vo.QRPaymentVisaPurchaseIdentifier;
import com.scb.channels.base.vo.QRPaymentVisaRequest;
import com.scb.channels.base.vo.QRPaymentVisaResponse;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;

public class QRVisaPaymentProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRVisaPaymentProcessor.class);
	
	private DataBean dataBean;
	
	private ReferenceService referenceService;
	
	public String buildRequest(PayloadDTO payload)throws Exception {
		String json = null;
		ISOCODESVO isoCodes = null;
		try{
		QRPaymentVisaRequest qrPaymentVisaRequest = new QRPaymentVisaRequest();
		QRPaymentVisaCardAcceptor qrPaymentVisaCardAcceptor = new QRPaymentVisaCardAcceptor();
		QRPaymentVisaCardAcceptorAddress qrPaymentVisaCardAcceptorAddress = new QRPaymentVisaCardAcceptorAddress();
		QRPaymentVisaPurchaseIdentifier qrPaymentVisaPurchaseIdentifier = new QRPaymentVisaPurchaseIdentifier();
		QRPaymentRequestVO qrPaymentRequestVO= (QRPaymentRequestVO)payload.getRequestVO();
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequestVO.getQrPaymentDetailVO();
		LOGGER.info("Inside QR VISA Payment Processor buildVISARequest :::: "+qrPaymentDetailVO.getClient_reference()+" RRN :: "+qrPaymentDetailVO.getHost_reference());
		List<ISOCODESVO> isocodesvos = referenceService.getCurrency(qrPaymentDetailVO.getCountryCode());
		if(isocodesvos != null && isocodesvos.size()>0){
			for(ISOCODESVO isocodesvo : isocodesvos){
				if(isocodesvo.getCountrycode().equalsIgnoreCase(qrPaymentDetailVO.getCountryCode())){
					isoCodes = isocodesvo;
					break;
				}
			}
		} 
		qrPaymentDetailVO.setHost_system(CommonConstants.VISA+" - "+"MerchantPayment");
		qrPaymentVisaCardAcceptorAddress.setCountry(qrPaymentDetailVO.getCountryCode());
		qrPaymentVisaCardAcceptorAddress.setCity(CommonConstants.VISA_CARD_ACCEPTOR_CITY);
		qrPaymentVisaCardAcceptor.setIdCode(qrPaymentDetailVO.getHost_reference());
		qrPaymentVisaCardAcceptor.setName(CommonConstants.VISA_CARD_ACCEPTOR_NAME);
		qrPaymentVisaCardAcceptor.setTerminalId(qrPaymentDetailVO.getTerminalId());
		qrPaymentVisaCardAcceptor.setAddress(qrPaymentVisaCardAcceptorAddress);
		qrPaymentVisaRequest.setSystemsTraceAuditNumber(qrPaymentDetailVO.getStan());
		qrPaymentVisaRequest.setRetrievalReferenceNumber(qrPaymentDetailVO.getHost_reference());
		qrPaymentVisaRequest.setRecipientPrimaryAccountNumber(qrPaymentDetailVO.getMerchantPan());
		qrPaymentVisaRequest.setMerchantCategoryCode(CommonConstants.VISA_MCC);
		qrPaymentVisaRequest.setAmount(qrPaymentDetailVO.getTotalPaymentAmt());
		SimpleDateFormat paymentDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
		qrPaymentVisaRequest.setLocalTransactionDateTime(paymentDateFormat.format(qrPaymentDetailVO.getPaymentDate()));
		//qrPaymentVisaRequest.setLocalTransactionDateTime("2017-04-04");
		String acquiringBin = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type()+qrPaymentDetailVO.getSourceOfFund();
		qrPaymentVisaRequest.setAcquiringBin(dataBean.map.get(acquiringBin+"_BIN"));
		qrPaymentVisaRequest.setAcquirerCountryCode(String.valueOf(isoCodes.getCountrycode_numeric()));
		qrPaymentVisaRequest.setTransactionCurrencyCode(qrPaymentDetailVO.getTxnCurrencyCode());
		qrPaymentVisaRequest.setBusinessApplicationId(CommonConstants.VISA_BUSINESS_APPLICATION_ID);
		qrPaymentVisaRequest.setSenderAccountNumber(qrPaymentDetailVO.getCardNumber());
		String customerName = (qrPaymentDetailVO.getCustomer_full_name() != null && qrPaymentDetailVO.getCustomer_full_name().length() >30 ) ? 
				qrPaymentDetailVO.getCustomer_full_name().substring(0,30) : qrPaymentDetailVO.getCustomer_full_name();
		qrPaymentVisaRequest.setSenderName(customerName);
		if(qrPaymentDetailVO.getPurchaseIdentfier() != null){
			qrPaymentVisaPurchaseIdentifier.setType("0");
			qrPaymentVisaPurchaseIdentifier.setReferenceNumber(qrPaymentDetailVO.getPurchaseIdentfier());
			qrPaymentVisaRequest.setPurchaseIdentifier(qrPaymentVisaPurchaseIdentifier);
		}
		qrPaymentVisaRequest.setSecondaryId(qrPaymentDetailVO.getSecondaryId());
		qrPaymentVisaRequest.setCardAcceptor(qrPaymentVisaCardAcceptor);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		json = objectMapper.writeValueAsString(qrPaymentVisaRequest);
		LOGGER.info("Inside QR VISA Request JSON ::::"+qrPaymentDetailVO.getClient_reference()+"::"+json.toString());
		}catch(JsonGenerationException jsonException){
			LOGGER.error("Error While Converting VISA Payment object to json ::::",jsonException);
			LOGGER.info("Error While Converting VISA Payment object to json ::::");
		}catch (IOException ioException) {
			LOGGER.error("Error While Converting VISA Payment object to json ioException::::",ioException);
			LOGGER.info("Error While Converting VISA Payment object to json ioException::::");
		}catch(Exception e){
			LOGGER.error("Error While Converting VISA Payment object to General Exception::::",e);
			LOGGER.info("Error While Converting VISA Payment object to General Exception::::");
		}
		return json;
	}
	
	public QRPaymentVisaResponse convertJsontoObject(Exchange exchange) throws JsonParseException, JsonMappingException, IOException{

		LOGGER.info("Inside QR VISA Payment Processor convertJsontoObject Start :::: ");
		String responseJson = exchange.getIn().getBody(String.class);
		Map<String, Object> headers = (Map<String, Object>) exchange.getIn().getHeaders();
		int httpStatusCode =  (int) headers.get("CamelHttpResponseCode");
		String httpStatus = String.valueOf(httpStatusCode);
		LOGGER.info("VISA RETURN HTTP STAUS :::: "+httpStatusCode+" :::ResponseJSON ::::"+responseJson);
		QRPaymentVisaResponse qrPaymentVISAResponse = null;
		if((CommonConstants.ACQUIRER_TIMEOUT_CODE).equalsIgnoreCase(httpStatus) || (CommonConstants.ACQUIRER_DUPLICATE_TXN).equalsIgnoreCase(httpStatus)){
			qrPaymentVISAResponse = new QRPaymentVisaResponse();
			qrPaymentVISAResponse.setStatusIdentifier(responseJson.toString());
			qrPaymentVISAResponse.setActionCode(httpStatus);
			LOGGER.info("QR VISA Payment Processor convertJsontoObject 202 || 303 TimeOut ::::"+qrPaymentVISAResponse.getStatusIdentifier());
		}
		if(CommonConstants.HTTP_SUCCESS_STATUS.equalsIgnoreCase(httpStatus)){
			ObjectMapper mapper = new ObjectMapper(); 
			qrPaymentVISAResponse = mapper.readValue(responseJson.getBytes(), QRPaymentVisaResponse.class);
			LOGGER.info("Got Success Transaction from VISA ::: ");
		}
		LOGGER.info("Inside QR VISA Payment Processor convertJsontoObject End ::::");
		return qrPaymentVISAResponse;
	}

	public PayloadDTO setVisaResponseToPayload(QRPaymentVisaResponse qrPaymentVISAResponse,PayloadDTO payload) throws Exception{
		
		QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
		QRPaymentResponseVO qrPaymentResponseVO = (QRPaymentResponseVO)payload.getResponseVO();
		LOGGER.info("Inside QR VISA Payment Processor setVISAResponseToPayload Start ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
		if(qrPaymentVISAResponse != null && ("00".equalsIgnoreCase(qrPaymentVISAResponse.getActionCode()) || "85".equalsIgnoreCase(qrPaymentVISAResponse.getActionCode()))){
			LOGGER.info("Got Success Status from VISA ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
			qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_SUCCESS);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(qrPaymentVISAResponse.getActionCode());
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostReasonCode(qrPaymentVISAResponse.getResponseCode());
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(CommonConstants.SUCCESS);
			qrPaymentRequestVO.getQrPaymentDetailVO().setMerchantCategoryCode(qrPaymentVISAResponse.getMerchantCategoryCode());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTransactionIdentifier(qrPaymentVISAResponse.getTransactionIdentifier());
			
			if(qrPaymentResponseVO != null){
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostName(qrPaymentRequestVO.getQrPaymentDetailVO().getHost_system());	
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
					LOGGER.info("QR VISA Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
				}	
			}
		}else if((CommonConstants.ACQUIRER_TIMEOUT_CODE).equalsIgnoreCase(qrPaymentVISAResponse.getActionCode()) ||(CommonConstants.ACQUIRER_DUPLICATE_TXN).equalsIgnoreCase(qrPaymentVISAResponse.getActionCode())){
			LOGGER.info("Got Timeout in VISA 202 ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference());
			qrPaymentRequestVO.getQrPaymentDetailVO().setStatus_identifier(qrPaymentVISAResponse.getStatusIdentifier());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.ACQUIRER_TIMEOUT);
			qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.ACQUIRER_TIMEOUT);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(qrPaymentVISAResponse.getActionCode());
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(CommonConstants.ACQUIRER_TIMEOUT);
			if(qrPaymentResponseVO != null){
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}else{
					LOGGER.info("QRPaymentResponseVO is Null For 202 Exception");
					qrPaymentResponseVO = new QRPaymentResponseVO();
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
					qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
					qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
					qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
					qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
				}
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(CommonConstants.ACQUIRER_TIMEOUT_CODE);
					hostResponse.setDesc(CommonConstants.ACQUIRER_TIMEOUT);
					hostResponse.setHostName(qrPaymentRequestVO.getQrPaymentDetailVO().getHost_system());	
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
					LOGGER.info("QR VISA Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
				}	
			}
		}else{
			LOGGER.info("Inside Condition Either 200/202/303 ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			qrPaymentRequestVO.getQrPaymentDetailVO().setPayment_status(CommonConstants.AGGREGATOR_PAY_FAILURE);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(qrPaymentVISAResponse.getActionCode());
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostReasonCode(qrPaymentVISAResponse.getResponseCode());
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(CommonConstants.FAIL);
			
			if(qrPaymentResponseVO != null){
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentRequestVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostName(qrPaymentRequestVO.getQrPaymentDetailVO().getHost_system());	
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
					LOGGER.info("QR VISA Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
				}	
			}
		}
		payload.setResponseVO(qrPaymentResponseVO);
		LOGGER.info("QR VISA  TXTStatus  ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("Sending Response Back :::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
		return payload;
	}
	/*public String buildAuthorizationHeader(){
		LOGGER.info("Inside QR Payment Processor buildAuthorizationHeader ::::");
		String userId = "ET5IB76N9UB5CDOI1IFV21ZvxmEBz-1E-r2yIi6USfKqDAHK4";
		String password = "L5123JO9hf8021OrFNC7WA";
		 return "Basic " + base64Encode(userId + ":" + password);
		
	}
	
	private static String base64Encode(String token) {
        byte[] encodedBytes = Base64.encodeBase64(token.getBytes());
        return new String(encodedBytes, Charset.forName("UTF-8"));
    }
	
	public PayloadDTO sample(PayloadDTO payload){
		LOGGER.info("Inside QR Payment Processor sample Start ::::");
		QRPaymentRequestVO qrPaymentRequestVO = (QRPaymentRequestVO)payload.getRequestVO();
		LOGGER.info("Inside QR Payment Processor sample Start ::::"+qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
		return payload;
	}*/

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	
	
	
}
