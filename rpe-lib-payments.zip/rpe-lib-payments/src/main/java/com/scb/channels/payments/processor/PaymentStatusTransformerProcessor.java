package com.scb.channels.payments.processor;

import java.util.HashSet;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.ws.provider.invoice.PostPaymentRes;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.StatusType;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.paymentservice.PaymentResponse;

public class PaymentStatusTransformerProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(PaymentStatusTransformerProcessor.class);
	
	/**
	 * Transform.
	 * 
	 * @param paymentStatusXML
	 *            the payment status xml from the edmi
	 * @return the payment response object
	 * @throws TransformerException
	 *             the transformer exception
	 */
	public PostPaymentRes getPostPaymentResponse(String paymentStatusXML) {
		LOGGER.info("Transforming payment final response "
				+ "xml string to object message :::: " + paymentStatusXML);
		System.out.println("Transforming payment final response "
				+ "xml string to object message :::: " + paymentStatusXML);
		
		PostPaymentRes paymentStatus = null;
		
		try {
			paymentStatus = (PostPaymentRes)CommonHelper.unMarshall(
					paymentStatusXML, PostPaymentRes.class);
			
			if (paymentStatus != null && paymentStatus.getHeader() != null
					&& paymentStatus.getHeader().getOriginationDetails() != null){
				LOGGER.info("Obtained the final status :::: " + 
						paymentStatus.getHeader().getOriginationDetails().getTrackingId());
				System.out.println("Obtained the final status :::: " + 
						paymentStatus.getHeader().getOriginationDetails().getTrackingId());
				
			} else {
				LOGGER.info("Payment final status has problem :::: " + paymentStatusXML);
				System.out.println("Payment final status has problem :::: " + paymentStatusXML);
			}
			
		} catch (TransformerException e) {
			LOGGER.error(e.getMessage());
			LOGGER.error("TransformerException occurred while getting final response object" + e);
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
			LOGGER.info("Exception occurred while getting final response object" + e);
		}
		return paymentStatus;
	}
	
	public PaymentResponse getPaymentFinalStatus(PayloadDTO payload) {
		LOGGER.info("PaymentStatusTransformerProcessor --- sendPaymentFinalStatus --- Start");
		
		PaymentResponse response = new PaymentResponse();
		HostResponseType hostResponse = new HostResponseType();
		StatusType status = new StatusType();
		Set<HostResponseVO> hostResponseList = new HashSet<HostResponseVO>();
		try {
			if (payload != null && payload.getResponseVO() != null
					&& payload.getResponseVO() instanceof BillerPayResponseVO) {

				BillerPayResponseVO responseVo = (BillerPayResponseVO)payload.getResponseVO();
				response = BillpaymentMappingHelper.getPaymentResponseVOMapping(responseVo);
				hostResponseList = responseVo.getHostResponseVO();
				
				if (responseVo.getBillerPayDetailsVO().getTxnActStatus() != null && 
						responseVo.getBillerPayDetailsVO().getCountryCode() != null &&
						responseVo.getBillerPayDetailsVO().getPayRef() != null &&
						responseVo.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
					
					hostResponse.setCode(responseVo.
							getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
					hostResponse.setDesc(responseVo.
							getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
					hostResponse.setHostReference(responseVo.getBillerPayDetailsVO()
							.getTransactionInfoVO().getHostTxnRefNo());
					
					if(responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS)) {
						
						LOGGER.info("AGGREGATOR_PAY_SUCCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("AGGREGATOR_PAY_SUCCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						LOGGER.info("TOKEN VALUE ::: " + 
								responseVo.getBillerPayDetailsVO()
								.getTransactionInfoVO().getOtpRefNo());
						System.out.println("TOKEN VALUE ::: " + 
								responseVo.getBillerPayDetailsVO()
								.getTransactionInfoVO().getOtpRefNo());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.SUCCESS);
						response.setToken(responseVo.getBillerPayDetailsVO()
								.getTransactionInfoVO().getOtpRefNo());
						
						hostResponse.setHostName(
							responseVo.getBillerPayDetailsVO().getHostName());
						
					} else if(responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.INPROCESS_STATUS)) {
						
						LOGGER.info("AGGREGATOR_PAY_IMPROCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("AGGREGATOR_PAY_INPROCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.INPROCESS_STATUS);
						
						hostResponse.setDesc(CommonConstants.INPROCESS_STATUS);
						hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.MANUAL_PROCESS_STATUS)) {
						
						LOGGER.info("AGGREGATOR_MANNUAL_PROCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("AGGREGATOR_MANNUAL_PROCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.MANUAL_PROCESS_STATUS);
						
						hostResponse.setDesc(CommonConstants.MANUAL_PROCESS_STATUS);
						hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.TIMEOUT)) {
						
						LOGGER.info("TIMEOUT STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("TIMEOUT STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.TIMEOUT);
						
						hostResponse.setDesc(CommonConstants.TIMEOUT);
						hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
						
					} else{
						LOGGER.info("FAILURE STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("FAILURE STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						hostResponse.setHostName(
							responseVo.getBillerPayDetailsVO().getHostName());
					}
					
					LOGGER.info("Incoming response has details");
					System.out.println("Incoming response has details");
					
					status.setRefrenceNumber(responseVo.getBillerPayDetailsVO().getPayRef());
					
					
				} else {
					LOGGER.info("The response object is not complete");
					System.out.println("The response object is not complete");
					status.setStatusCode(CommonConstants.TIMEOUT_CODE);
					status.setStatusDesc(CommonConstants.FAILURE);
					
					hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				}
				LOGGER.info("Payment response generated for :::::: " + 
						response.getMessageContext().getReqID());
				System.out.println("Payment response generated for :::::: " + 
						response.getMessageContext().getReqID());
			} else {
				LOGGER.info("The response object is not complete");
				System.out.println("The response object is not complete");
				status.setStatusCode(CommonConstants.TIMEOUT_CODE);
				status.setStatusDesc(CommonConstants.FAILURE);
				
				hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
				hostResponse.setDesc(CommonConstants.FAILURE);
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			}

			if(status.getStatusDesc() != null && 
				!(status.getStatusDesc().equalsIgnoreCase(CommonConstants.INPROCESS_STATUS) ||
				status.getStatusDesc().equalsIgnoreCase(CommonConstants.MANUAL_PROCESS_STATUS) ||
				status.getStatusDesc().equalsIgnoreCase(CommonConstants.TIMEOUT))) {
				
				if(hostResponseList != null && !hostResponseList.isEmpty()) {
					LOGGER.info("Setting the previous host response ::: ");
					System.out.println("Setting the previous host response ::: ");
					
					for(HostResponseVO previousHostResponse : hostResponseList){
						HostResponseType hostResponseType = new HostResponseType();
						
						hostResponseType.setCode(previousHostResponse.getCode());
						hostResponseType.setDesc(previousHostResponse.getDesc());
						hostResponseType.setHostName(previousHostResponse.getHostName());
						
						status.getHostResponse().add(hostResponseType);
					}
				}
			}
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);
			
			LOGGER.info("PaymentResponseImpl --- response.getToken() --- End ---- " + response.getToken());
			System.out.println("PaymentResponseImpl --- response.getToken() --- End --- " + response.getToken());
		} catch(Exception e) {
			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
			hostResponse.setDesc(CommonConstants.FAILURE);
			hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);

			LOGGER.error("Exception for Payment final response :::: " 
					+ response.getMessageContext() != null ? response.getMessageContext().getReqID() : "PaymentStatusTransformerProcessor: getPaymentFinalStatus Ends");
			
		}
		return response;
	}
	
	public String getFinalStatusXml(PaymentResponse paymentResponse) {
		String responseXml = null;
		LOGGER.info("Transforming payment response object to xml string");
		System.out.println("Transforming payment response object to xml string");
		try {
			responseXml = CommonHelper.getXML(paymentResponse, 
					PaymentResponse.class, PaymentResponse.class.getSimpleName());
			
			if(responseXml != null) {
				LOGGER.info("Transforming payment response xml successful --- > ::: " + responseXml);
				System.out.println("Transforming payment response xml successful --- > ::: " + responseXml);
			} else {
				LOGGER.info("Transforming payment response xml is NOT successful --- > ::: " + responseXml);
				System.out.println("Transforming payment response xml is NOT successful --- > ::: " + responseXml);
			}
			
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT FINAL RESPONSE XML :::::: " 
					+ e.getMessage());
			System.out.println("EXCEPTION OCCURRED WHILE GENERATING PAYMENT FINAL RESPONSE XML :::::: " 
					+ e.getMessage());
			LOGGER.error(e.getMessage());
			System.err.println(e.getMessage() + e);
		}
		return responseXml;
	}
	

	public PaymentResponse respondPaybillSubmitted(PayloadDTO dto) {
		LOGGER.info("PaymentResponseImpl --- respondPaybillSubmitted --0000- Start");
		System.out.println("PaymentResponseImpl --- respondPaybillSubmitted --- Start");

		HostResponseType hostResponse = new HostResponseType();
		PaymentResponse response = new PaymentResponse();
		StatusType status = new StatusType();
		try {
			if (dto != null && dto.getResponseVO() != null
					&& dto.getResponseVO() instanceof BillerPayResponseVO) {

				BillerPayResponseVO responseVo = (BillerPayResponseVO) dto.getResponseVO();
				response = BillpaymentMappingHelper.getPaymentResponseVOMapping(responseVo);

				status.setRefrenceNumber(responseVo.getBillerPayDetailsVO().getHostReference());

				if (responseVo.getUser() != null
						&& responseVo.getServiceVO() != null
						&& responseVo.getClientVO() != null
						&& responseVo.getMessageVO() != null
						&& responseVo.getBillerPayDetailsVO().getTxnActStatus() != null
						&& responseVo.getBillerPayDetailsVO().getTxnActStatus().
						equalsIgnoreCase(CommonConstants.SAVE_SUCCESS)) {
					LOGGER.info("Incoming request has details");
					System.out.println("Incoming request has details");

					hostResponse.setCode(CommonConstants.ZERO);
					hostResponse.setDesc(CommonConstants.SUBMITTED);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);

					status.getHostResponse().add(hostResponse);
					status.setStatusCode(CommonConstants.ZERO);
					status.setStatusDesc(CommonConstants.SUCCESS);

				} else {
					LOGGER.info("Incoming request is not complete");
					System.out.println("Incoming request is not complete");

					hostResponse.setCode(CommonConstants.NEGATIVE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);

					status.getHostResponse().add(hostResponse);
					status.setStatusCode(CommonConstants.NEGATIVE);
					status.setStatusDesc(CommonConstants.FAILURE);
				}

			} else {
				LOGGER.info("Incoming request is not complete");
				System.out.println("Incoming request is not complete");

				hostResponse.setCode(CommonConstants.NEGATIVE);
				hostResponse.setDesc(CommonConstants.FAILURE);
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);

				status.getHostResponse().add(hostResponse);
				status.setStatusCode(CommonConstants.NEGATIVE);
				status.setStatusDesc("The Request is not complete. Missing context details.");
			}

			response.setStatus(status);

			LOGGER.info("Payment response generated for :::::: "
					+ response.getMessageContext().getReqID());
			System.out.println("Payment response generated for :::::: "
					+ response.getMessageContext().getReqID());

			LOGGER.info("PaymentResponseImpl --- respondPaybillSubmitted --- End");
			System.out.println("PaymentResponseImpl --- respondPaybillSubmitted --- End");
			
		} catch (Exception e) {
			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			LOGGER.error("Exception for Payment :::: "
					+ response.getMessageContext().getReqID());
			System.out.println("Exception for Payment :::: " 
					+ response.getMessageContext().getReqID());
			
			LOGGER.error("Exception occurred while submitting Payment :::: " 
						+ e.getMessage());
			System.out.println("Exception occurred while submitting Payment :::: " 
						+ e.getMessage());
			
			System.err.println(e);
		}
		return response;
	}
}
