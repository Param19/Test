package com.scb.channels.qrpayments.service.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.qrpayments.service.QRPaymentCommonService;

public class QRPaymentCommonServiceImpl implements QRPaymentCommonService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentCommonServiceImpl.class);

	@Override
	public String buildCardAcceptorName(QRPaymentDetailVO qrPaymentDetailVO) {

		String merchantName = null;
		String merchantCity = null;
		if(qrPaymentDetailVO.getMerchantName() != null &&  qrPaymentDetailVO.getMerchantName().length() >= 23){
			merchantName = qrPaymentDetailVO.getMerchantName().substring(0, 23);
		}else if(qrPaymentDetailVO.getMerchantName() != null && qrPaymentDetailVO.getMerchantName().length() < 23){
			merchantName = StringUtils.rightPad(qrPaymentDetailVO.getMerchantName(), 23," ");
		}else 
			merchantName = CommonConstants.QR_MERCHANT_DUMMY_NAME;

		
		if(qrPaymentDetailVO.getMerchantCity() != null && qrPaymentDetailVO.getMerchantCity().length()>= 13){
			merchantCity = qrPaymentDetailVO.getMerchantCity().substring(0, 13);
		}else if(qrPaymentDetailVO.getMerchantCity() != null && qrPaymentDetailVO.getMerchantCity().length()< 13){
			merchantCity = StringUtils.rightPad(qrPaymentDetailVO.getMerchantCity(), 13," ");
		}else 
			merchantCity = CommonConstants.QR_MERCHANT_DUMMY_CITY;
		
		
		String merchantState = CommonConstants.DOUBLE_SPACE;
		String merchantCountry = (qrPaymentDetailVO.getCountryCode().equalsIgnoreCase(CommonConstants.IN)) ? qrPaymentDetailVO.getCountryCode() : qrPaymentDetailVO.getAcquireCountryCode();
		String cardAccString = new StringBuilder().append(merchantName).append(merchantCity).append(merchantState).append(merchantCountry).toString();
		LOGGER.info("Debit Card Service Card Acceptor Name :::: "+cardAccString);
		return cardAccString;
	}

}
