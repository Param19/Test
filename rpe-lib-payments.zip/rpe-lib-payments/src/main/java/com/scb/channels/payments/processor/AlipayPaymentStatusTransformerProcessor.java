package com.scb.channels.payments.processor;

import java.util.HashSet;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.ws.provider.invoice.PostPaymentRes;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.HostResponseType;
import com.scb.channels.common.StatusType;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.paymentservice.PaymentResponse;

public class AlipayPaymentStatusTransformerProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AlipayPaymentStatusTransformerProcessor.class);
	
	/**
	 * Transform.
	 * 
	 * @param paymentStatusXML
	 *            the payment status xml from the edmi
	 * @return the payment response object
	 * @throws TransformerException
	 *             the transformer exception
	 */
	public PostPaymentRes getPostPaymentResponse(String paymentStatusXML) {
		LOGGER.info("Transforming alipay payment final response "
				+ "xml string to object message :::: " + paymentStatusXML);
		System.out.println("Transforming alipay payment final response "
				+ "xml string to object message :::: " + paymentStatusXML);
		
		PostPaymentRes paymentStatus = null;
		
		try {
			paymentStatus = (PostPaymentRes)CommonHelper.unMarshall(
					paymentStatusXML, PostPaymentRes.class);
			
			if (paymentStatus != null && paymentStatus.getHeader() != null
					&& paymentStatus.getHeader().getOriginationDetails() != null){
				LOGGER.info("Obtained the final alipay status :::: " + 
						paymentStatus.getHeader().getOriginationDetails().getTrackingId());
				System.out.println("Obtained the final alipay status :::: " + 
						paymentStatus.getHeader().getOriginationDetails().getTrackingId());
				
			} else {
				LOGGER.info("Payment final alipay status has problem :::: " + paymentStatusXML);
				System.out.println("Payment final alipay status has problem :::: " + paymentStatusXML);
			}
			
		} catch (TransformerException e) {
			LOGGER.error(e.getMessage());
			//System.out.println("TransformerException occurred while getting alipay final response object" + e);
			LOGGER.info("TransformerException occurred while getting alipay final response object", e);
		} catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
			//System.out.println("Exception occurred while getting alipay final response object" + e);
			LOGGER.info("Exception occurred while getting final alipay response object", e);
		}
		return paymentStatus;
	}
	
	
	public PaymentResponse getPaymentFinalStatus(PayloadDTO payload) {
		LOGGER.info("AlipayPaymentStatusTransformerProcessor --- sendPaymentFinalStatus --- Start");
		System.out.println("AlipayPaymentStatusTransformerProcessor --- sendPaymentFinalStatus --- Start");
		
		PaymentResponse response = new PaymentResponse();
		HostResponseType hostResponse = new HostResponseType();
		StatusType status = new StatusType();
		Set<HostResponseVO> hostResponseList = new HashSet<HostResponseVO>();
		BillerPayResponseVO responseVo = new BillerPayResponseVO();
		try {
			if (payload != null && payload.getResponseVO() != null
					&& payload.getResponseVO() instanceof BillerPayResponseVO) {

				responseVo = (BillerPayResponseVO)payload.getResponseVO();
				response = BillpaymentMappingHelper.getPaymentResponseVOMapping(responseVo);
				hostResponseList = responseVo.getHostResponseVO();
				
				if (responseVo.getBillerPayDetailsVO().getTxnActStatus() != null && 
						responseVo.getBillerPayDetailsVO().getCountryCode() != null &&
						responseVo.getBillerPayDetailsVO().getPayRef() != null &&
						responseVo.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
					
					hostResponse.setCode(responseVo.
							getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
					hostResponse.setDesc(responseVo.
							getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
					/*hostResponse.setHostReference(responseVo.getBillerPayDetailsVO()
							.getTransactionInfoVO().getHostTxnRefNo());*/
					
					if(responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_SUCCESS)) {
						
						LOGGER.info("ALIPAY AGGREGATOR_PAY_SUCCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("ALIPAY AGGREGATOR_PAY_SUCCESS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.SUCCESS);
						
						hostResponse.setHostName(
							responseVo.getBillerPayDetailsVO().getHostName());
						hostResponse.setHostReference(responseVo.getBillerPayDetailsVO()
								.getTransactionInfoVO().getHostTxnRefNo());
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.AGGREGATOR_PAY_NOT_SUCCESS)) {
						
						LOGGER.info("ALIPAY AGGREGATOR_PAY_NOT_SUCCESS STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("ALIPAY AGGREGATOR_PAY_NOT_SUCCESS STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.TIMEOUT);
						
						hostResponse.setHostName(CommonConstants.ALIPAY_AGGREGATOR);
						hostResponse.setHostReference(responseVo.getBillerPayDetailsVO()
								.getTransactionInfoVO().getHostTxnRefNo());
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.TIMEOUT)) {
						
						LOGGER.info("ALIPAY TIMEOUT STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("ALIPAY TIMEOUT STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.TIMEOUT);
						
						hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
						hostResponse.setDesc(CommonConstants.TIMEOUT);
						hostResponse.setHostName(CommonConstants.ALIPAY_AGGREGATOR);
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.INPROCESS_STATUS)) {
						
						LOGGER.info("ALIPAY INPROCESS STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("ALIPAY INPROCESS STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.ZERO);
						status.setStatusDesc(CommonConstants.TIMEOUT);
						
						hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
						hostResponse.setDesc(CommonConstants.TIMEOUT);
						hostResponse.setHostName(CommonConstants.ALIPAY_AGGREGATOR);
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.COREBANK_PAY_FAILURE)) {
						// Condition added for Hogan getTransactionStatus inquiry - to set hostname before sending PaymentResponse to ibank
						LOGGER.info("ALIPAY CBPAYFAIL STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						hostResponse.setCode(CommonConstants.TIMEOUT_CODE);//status.hostResponse.code
						hostResponse.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.POST_TRANSACTION);
						
					} else if (responseVo.getBillerPayDetailsVO().getTxnActStatus()
							.equalsIgnoreCase(CommonConstants.CARD_AUTH_FAILURE)) {
						// Condition added for Hogan getTransactionStatus inquiry - to set hostname before sending PaymentResponse to ibank
						LOGGER.info("ALIPAY CCAUTFAIL STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						hostResponse.setCode(CommonConstants.TIMEOUT_CODE);//status.hostResponse.code
						hostResponse.setHostName(CommonConstants.HOGAN + " - " + CommonConstants.CARD_AUTHORIZE);
						
					} else{
						LOGGER.info("ALIPAY FAILURE STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						System.out.println("ALIPAY FAILURE STATUS ::: " + 
								responseVo.getBillerPayDetailsVO().getPayRef());
						
						status.setStatusCode(CommonConstants.TIMEOUT_CODE);
						status.setStatusDesc(CommonConstants.FAILURE);
						hostResponse.setHostName(
							responseVo.getBillerPayDetailsVO().getHostName());
					}
					
					LOGGER.info("Incoming alipay response has details");
					System.out.println("Incoming alipay response has details");
					
					//status.setRefrenceNumber(responseVo.getBillerPayDetailsVO().getPayRef());
					status.setRefrenceNumber(responseVo.getBillerPayDetailsVO().getHostReference()); // Sending RPE Reference Number in final response as well  

					
				} else {
					LOGGER.info("The alipay response object is not complete");
					System.out.println("The alipay response object is not complete");
					status.setStatusCode(CommonConstants.TIMEOUT_CODE);
					status.setStatusDesc(CommonConstants.FAILURE);
					
					hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				}
				LOGGER.info("Payment alipay response generated for :::::: " + 
						response.getMessageContext().getReqID());
				System.out.println("Payment alipay response generated for :::::: " + 
						response.getMessageContext().getReqID());
			} else {
				LOGGER.info("The alipay response object is not complete");
				System.out.println("The alipay response object is not complete");
				status.setStatusCode(CommonConstants.TIMEOUT_CODE);
				status.setStatusDesc(CommonConstants.FAILURE);
				
				hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
				hostResponse.setDesc(CommonConstants.FAILURE);
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			}
			
			String hostName = hostResponse.getHostName() != null && 
				hostResponse.getHostName().contains(CommonConstants.ALIPAY_AGGREGATOR) ? 
						CommonConstants.ALIPAY_AGGREGATOR : hostResponse.getHostName();
			if(hostName != null && !hostName.isEmpty()) {
				hostResponse.setHostName(hostName);
			}
			
			if(hostResponseList != null && !hostResponseList.isEmpty()) {
				LOGGER.info("Setting the previous alipay host response ::: ");
				System.out.println("Setting the previous alipay host response ::: ");
				
				for(HostResponseVO previousHostResponse : hostResponseList){
					if(!hostResponse.getHostName().equalsIgnoreCase(previousHostResponse.getHostName())) {
						HostResponseType hostResponseType = new HostResponseType();
						
						hostResponseType.setCode(previousHostResponse.getCode());
						hostResponseType.setDesc(previousHostResponse.getDesc());
						//hostResponseType.setHostName(previousHostResponse.getHostName());
						
						hostName = previousHostResponse.getHostName() != null && 
								previousHostResponse.getHostName().contains(CommonConstants.ALIPAY_AGGREGATOR) ? 
										CommonConstants.ALIPAY_AGGREGATOR : previousHostResponse.getHostName();
							if(hostName != null && !hostName.isEmpty()) {
								hostResponseType.setHostName(hostName);
							}
						
						if(previousHostResponse.getHostName().
								equalsIgnoreCase(CommonConstants.ALIPAY_AGGREGATOR)) {
							hostResponseType.setHostReference(
								responseVo.getBillerPayDetailsVO().
									getTransactionInfoVO().getHostTxnRefNo());
						}
						
						status.getHostResponse().add(hostResponseType);
					}
				}
			}
			
			LOGGER.info("hostRespCd: "+hostResponse.getCode()
					+" hostRespDesc: "+hostResponse.getDesc()
					+" hostName: "+hostResponse.getHostName());
			
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);

			LOGGER.info("AlipayPaymentStatusTransformerProcessor --- response.getToken() --- End ---- " + response.getToken());
			System.out.println("AlipayPaymentStatusTransformerProcessor --- response.getToken() --- End --- " + response.getToken());
		} catch(Exception e) {
			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			hostResponse.setCode(CommonConstants.TIMEOUT_CODE);
			hostResponse.setDesc(CommonConstants.FAILURE);
			hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
			
			status.getHostResponse().add(hostResponse);
			response.setStatus(status);

			LOGGER.error("Exception for alipay Payment final response :::: " 
					+ response.getMessageContext().getReqID());
			System.out.println("Exception for alipay Payment final response :::: " 
					+ response.getMessageContext().getReqID());
			LOGGER.error("Exception occurred while alipay Payment final response :::: ", e);
			System.out.println("Exception occurred while alipay Payment final response :::: " + e);
			System.err.println(e);
		}
		return response;
	}
	
	public String getFinalStatusXml(PaymentResponse paymentResponse) {
		String responseXml = null;
		LOGGER.info("Transforming alipay payment response object to xml string");
		System.out.println("Transforming alipay payment response object to xml string");
		try {
			responseXml = CommonHelper.getXML(paymentResponse, 
					PaymentResponse.class, PaymentResponse.class.getSimpleName());
			
			if(responseXml != null) {
				LOGGER.info("Transforming alipay payment response xml successful --- > ::: " + responseXml);
				System.out.println("Transforming alipay payment response xml successful --- > ::: " + responseXml);
			} else {
				LOGGER.info("Transforming alipay payment response xml is NOT successful --- > ::: " + responseXml);
				System.out.println("Transforming alipay payment response xml is NOT successful --- > ::: " + responseXml);
			}
			
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING ALIPAY PAYMENT FINAL RESPONSE XML :::::: " 
					+ e.getMessage());
			System.out.println("EXCEPTION OCCURRED WHILE GENERATING ALIPAY PAYMENT FINAL RESPONSE XML :::::: " + e);
			LOGGER.error("Exception :::", e);
			System.err.println(e.getMessage() + e);
		}
		return responseXml;
	}
	

	public PaymentResponse respondPaybillSubmitted(PayloadDTO dto) {
		LOGGER.info("AlipayPaymentStatusTransformerProcessor --- respondPaybillSubmitted --0000- Start");
		System.out.println("AlipayPaymentStatusTransformerProcessor --- respondPaybillSubmitted --- Start");

		HostResponseType hostResponse = new HostResponseType();
		PaymentResponse response = new PaymentResponse();
		StatusType status = new StatusType();
		try {
			if (dto != null && dto.getResponseVO() != null
					&& dto.getResponseVO() instanceof BillerPayResponseVO) {

				BillerPayResponseVO responseVo = (BillerPayResponseVO) dto.getResponseVO();
				response = BillpaymentMappingHelper.getPaymentResponseVOMapping(responseVo);

				status.setRefrenceNumber(responseVo.getBillerPayDetailsVO().getHostReference());

				if (responseVo.getUser() != null
						&& responseVo.getServiceVO() != null
						&& responseVo.getClientVO() != null
						&& responseVo.getMessageVO() != null
						&& responseVo.getBillerPayDetailsVO().getTxnActStatus() != null
						&& responseVo.getBillerPayDetailsVO().getTxnActStatus().
						equalsIgnoreCase(CommonConstants.SAVE_SUCCESS)) {
					LOGGER.info("Incoming alipay request has details");
					System.out.println("Incoming alipay request has details");

					hostResponse.setCode(CommonConstants.ZERO);
					hostResponse.setDesc(CommonConstants.SUBMITTED);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);

					status.getHostResponse().add(hostResponse);
					status.setStatusCode(CommonConstants.ZERO);
					status.setStatusDesc(CommonConstants.SUCCESS);

				} else {
					LOGGER.info("Incoming alipay request is not complete");
					System.out.println("Incoming alipay request is not complete");

					hostResponse.setCode(CommonConstants.NEGATIVE);
					hostResponse.setDesc(CommonConstants.FAILURE);
					hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);

					status.getHostResponse().add(hostResponse);
					status.setStatusCode(CommonConstants.NEGATIVE);
					status.setStatusDesc(CommonConstants.FAILURE);
				}

			} else {
				LOGGER.info("Incoming alipay request is not complete");
				System.out.println("Incoming alipay request is not complete");

				hostResponse.setCode(CommonConstants.NEGATIVE);
				hostResponse.setDesc(CommonConstants.FAILURE);
				hostResponse.setHostName(CommonConstants.SRM_SOURCE_SYSTEM_NAME);

				status.getHostResponse().add(hostResponse);
				status.setStatusCode(CommonConstants.NEGATIVE);
				status.setStatusDesc("The alipay Request is not complete. Missing context details.");
			}

			response.setStatus(status);

			LOGGER.info("Alipay Payment response generated for :::::: "
					+ response.getMessageContext().getReqID());
			System.out.println("Alipay Payment response generated for :::::: "
					+ response.getMessageContext().getReqID());

			LOGGER.info("AlipayPaymentStatusTransformerProcessor --- respondPaybillSubmitted --- End");
			System.out.println("AlipayPaymentStatusTransformerProcessor --- respondPaybillSubmitted --- End");
			
		} catch (Exception e) {
			status.setStatusCode("-1");
			status.setStatusDesc(e.getMessage());
			
			LOGGER.error("Exception for alipay Payment :::: "
					+ response.getMessageContext().getReqID());
			System.out.println("Exception for alipay Payment :::: " 
					+ response.getMessageContext().getReqID());
			
			LOGGER.error("Exception occurred while submitting alipay Payment :::: ", e);
			System.out.println("Exception occurred while submitting alipay Payment :::: "+ e);
			System.err.println(e);
		}
		return response;
	}
}
