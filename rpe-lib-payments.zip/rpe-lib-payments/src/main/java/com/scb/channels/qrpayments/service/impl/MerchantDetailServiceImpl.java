package com.scb.channels.qrpayments.service.impl;

import com.scb.channels.base.vo.QRMerchantVO;
import com.scb.channels.qrpayments.dao.MerchantDAO;
import com.scb.channels.qrpayments.service.MerchantDetailService;

public class MerchantDetailServiceImpl implements MerchantDetailService{
	
	private MerchantDAO merchantDAO;

	public MerchantDAO getMerchantDAO() {
		return merchantDAO;
	}

	public void setMerchantDAO(MerchantDAO merchantDAO) {
		this.merchantDAO = merchantDAO;
	}

	@Override
	public void saveMerchant(QRMerchantVO merchantVO) {
		// TODO Auto-generated method stub
		merchantDAO.savePayment(merchantVO);
		
	}

}
