package com.scb.channels.payments.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.ws.WebServiceException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.cash.payment.mobile.v2.invoice.Biller;
import com.sc.cash.payment.mobile.v2.invoice.BillerCategory;
import com.sc.cash.payment.mobile.v2.invoice.FieldDetails;
import com.sc.cash.payment.mobile.v2.invoice.Invoice;
import com.sc.cash.payment.mobile.v2.invoice.ListDetails;
import com.sc.cash.payment.mobile.v2.invoice.ProductList;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillerCategoriesReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillerCategoriesRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersProductsReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersProductsRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersReq;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.GetBillersRes;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.InvoicePortType;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerDownloadHistory;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.TempBillerCategoryVO;
import com.scb.channels.base.vo.TempBillerField;
import com.scb.channels.base.vo.TempBillerFieldItemVO;
import com.scb.channels.base.vo.TempBillerVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.BillerDownloadProcessService;


public class BillerDownloadProcessServiceImpl implements BillerDownloadProcessService {

	private InvoicePortType invoice;
	 
	private BillerDownloadDAO    billerDAO;

	
	private DataBean dataBean;

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadProcessServiceImpl.class);

	@Override
	public PayloadDTO getDataFromAggregator(PayloadDTO dto) {
		List<TempBillerCategoryVO> tempCategoryList = null;
		BillerDownloadRequest request = (BillerDownloadRequest) dto.getRequestVO();
		BillerDownloadResponse response = (BillerDownloadResponse) dto.getResponseVO();
		LOGGER.error("Proceeding for the Biller Products ");
		try {
			if (CommonConstants.DYNAMIC.equalsIgnoreCase(request.getBillerDownloadCategoryType())) {
				getBillerfromAggregator(dto);
				response = (BillerDownloadResponse) dto.getResponseVO();
				tempCategoryList = response.getTempBillerCategory();
				if (dto.getRequestVO().getStatus().equals(CommonConstants.SUCC) && (tempCategoryList != null && tempCategoryList.size() > 0)) {
					getBillerProduts(dto, tempCategoryList);
					LOGGER.error("successfully saved aggregator data");
				} else {
					LOGGER.error("No Billers Avaialable from the Aggregator ");
					LOGGER.info("BILLER DOWNLOAD FAILED " + request.getUser().getCountry());
					throw new BusinessException("No Billers  Categories Avaialable from the Aggregator/exception thrown at while retrieving aggregator categories ");
				}
			}
			if (CommonConstants.STATIC.equalsIgnoreCase(request.getBillerDownloadCategoryType())) {
				response = new BillerDownloadResponse();
				dto.setResponseVO(response);
				getBillerCategoriesfromAggregator(dto);
				response = (BillerDownloadResponse) dto.getResponseVO();
				getBillersfromStaticCategories(dto);
				LOGGER.info("completed static categories Biller Download");
			}

			InvoiceAggregatorhelper.encrichWithCountryDetails(dto);
			tempCategoryList = response.getTempBillerCategory();
			billerDAO.deleteTemporayTableData(request.getUser().getCountry());
			billerDAO.saveAggregatorData(tempCategoryList);
		} catch (Exception exc) {
			LOGGER.error("exception Occured During the Dwonload Biller  " + exc);
			LOGGER.error("exception Occured During the Dwonload Biller  " , exc);
			request.setStatus(CommonConstants.FAIL);
			request.setStatusDesc(CommonConstants.FAIL);
			request.setErrorDesc(exc.getMessage());
			LOGGER.info("BILLER DOWNLOAD FAILED " + request.getUser().getCountry());
		}

		return dto;
	}
	
	
	public void getBillersfromStaticCategories(PayloadDTO payload) throws BusinessException{
		//int cnt=0;
		List<String> listAggFailed=new ArrayList<String>();
		GetBillersRes aggregatorBillerResponse=null;
		TempBillerField field= null;
		
		TempBillerFieldItemVO tempBillerFieldItemVO= null;
		List<TempBillerCategoryVO>  actvieTempCategoryList= new ArrayList<TempBillerCategoryVO>(0);
		//GetBillersRes billerResponse=null;
		BillerDownloadRequest request=(BillerDownloadRequest)payload.getRequestVO();
		BillerDownloadResponse  response=(BillerDownloadResponse)payload.getResponseVO();
		List<BillerDownloadHistory> history=response.getBillerDownloadHistory();
		List<TempBillerCategoryVO>  tempCategoryList=response.getTempBillerCategory();
		String Country=request.getUser().getCountry();
		request.setSubTypeName(CommonConstants.EDMI_GETBILLERS_NAME);
		request.setEventType(CommonConstants.GET);
		BillerCategory category=new BillerCategory();
		for(TempBillerCategoryVO   tempCategory:tempCategoryList){
			//request.setBillerCatgoryId(tempCategory.getCategoryId());
			request.setInternalRequestId(InvoiceAggregatorhelper.getFrequentGenerateUniqueId());
			GetBillersReq productrequest=InvoiceAggregatorhelper.getAggregatorAllBillersRequest(request);
			tempCategory.setCategoryId(tempCategory.getCategoryName());
			category.setCategoryType(tempCategory.getCategoryId());
			productrequest.getGetBillersReqPayload().getGetBillersReq().getInvoiceInfo().getBillerCategory().add(category);
			LOGGER.info("Download started for the category :: "+tempCategory.getCategoryId() +":: country billers :: "+tempCategory.getCountryCode());
			try{
				aggregatorBillerResponse= invoice.getBillers(productrequest);
				LOGGER.info("response retrieved for billerrequest category id"+tempCategory.getCategoryId() +"Country code"+tempCategory.getCountryCode() );
				if(aggregatorBillerResponse!=null &&aggregatorBillerResponse.getHeader().getExceptions()==null){
					
					if(aggregatorBillerResponse.getGetBillersResPayload()!=null && aggregatorBillerResponse.getGetBillersResPayload().getGetBillersRes()!=null){
						
						for(BillerCategory aggregatorBillerCatgry : aggregatorBillerResponse.getGetBillersResPayload().getGetBillersRes().getInvoiceInfo().getBillerCategory()){
							
								
							for(Biller aggregatorBillers: aggregatorBillerCatgry.getBiller()){
								
								 TempBillerVO biller=new TempBillerVO();
								 biller.setBillerDesc(aggregatorBillers.getBillerName());
								 biller.setBillerUniqueId(aggregatorBillers.getBillerID());
								 biller.setBillerId(aggregatorBillers.getBillerID());
								 biller.setBillerShortName(aggregatorBillers.getBillerName());
								 if(aggregatorBillers.getIsOnline() !=null){
								 biller.setIsOnline(aggregatorBillers.getIsOnline());
								 }else{
									 biller.setIsOnline("YES"); 
								 }
								 try{
								 if(aggregatorBillers.getBillerName() !=null && aggregatorBillers.getBillerName().contains(dataBean.getMap().get(CommonConstants.DEL_SQUARE_OPN))){ 
									 double defaultAmt=0.0;
								     defaultAmt=Double.parseDouble(aggregatorBillers.getBillerName().substring(
											 aggregatorBillers.getBillerName().indexOf(dataBean.getMap().get(CommonConstants.DEL_SQUARE_OPN))+1,
											 aggregatorBillers.getBillerName().indexOf(dataBean.getMap().get(CommonConstants.DEL_SQUARE_CLOSE)))); 
								     biller.setDefaultAmount(defaultAmt);
																	 }
								 }catch(Exception e){
									 biller.setDefaultAmount(null);
									 LOGGER.error("Exception occurred ::: ",e);
								 }

								// biller.setAggregatePaymentCode(aggregatorBillers.getBillerID());
								 if(StringUtils.isNotBlank(aggregatorBillers.getAccountQueryFlag())&& aggregatorBillers.getAccountQueryFlag().equalsIgnoreCase(CommonConstants.YES_Y)){
									 biller.setBillPresentmentType(CommonConstants.ONE);
								 }else{
									 biller.setBillPresentmentType(CommonConstants.ZERO);
								 }
								/* TempBillerField field= new TempBillerField();
								 field.setFieldLabelName(request.getDefaultBillerField());
								 field.setBillerId(biller);
								 biller.getBillerFields().add(field);
								 biller.setCategorytype(tempCategory);
								 biller.setVersion(CommonConstants.ONE_INT);
								 tempCategory.getBillers().add(biller);*/
								 
								for ( FieldDetails fieldDetails : aggregatorBillers.getFieldDetails()){
									 field= new TempBillerField();
									// field.setFieldDataType("List1");
									 if(fieldDetails.getDataType()!=null && fieldDetails.getDataType().equalsIgnoreCase(CommonConstants.FIELD_DATETYPE_LIST)){
										 for(ListDetails listDetails:fieldDetails.getListDetails()){
										 tempBillerFieldItemVO=new TempBillerFieldItemVO();
										 tempBillerFieldItemVO.setId(listDetails.getIdentifier());
										 tempBillerFieldItemVO.setDescription(listDetails.getDescription());
										 tempBillerFieldItemVO.setStatus(CommonConstants.ACTIVE);
										 tempBillerFieldItemVO.setRemarks(CommonConstants.FIELD_DATETYPE_LIST);
										 tempBillerFieldItemVO.setBillerField(field);
										 field.getBillerFieldItems().add(tempBillerFieldItemVO);
										 }
									 }
									 field.setFieldLabelName(fieldDetails.getFieldName());
									 if(fieldDetails.getDataType() !=null){
									 field.setFieldDataType(fieldDetails.getDataType());
									 }else{
										 //field.setFieldDataType("Text"); 
									 }
									 field.setFieldMaxLength(fieldDetails.getMaximumLength());
									 field.setFieldMinLength(fieldDetails.getMinimumLength());
									 if(fieldDetails.getBlockType()!=null){
										 
										 if(fieldDetails.getBlockType().equalsIgnoreCase("payBill")){
											 field.setFieldType("P");	 
										 }else if(fieldDetails.getBlockType().equalsIgnoreCase("getNameResponse")){
											 field.setFieldType("R");
										 }else if(fieldDetails.getBlockType().equalsIgnoreCase("getName")){
											 field.setFieldType("N");
										 }
										 
									 }
									 //field.setFieldType(fieldDetails.getBlockType());
									 if(fieldDetails.getReqForPaymentFlag()==null){
									 field.setIsfieldRequired(CommonConstants.YES);
									 }else
									 {
										 if(fieldDetails.getReqForPaymentFlag().equalsIgnoreCase(CommonConstants.NO)){
										 field.setIsfieldRequired(CommonConstants.N); 
										 }
										 else{
											 field.setIsfieldRequired(CommonConstants.YES); 
										 }
									 }
									 field.setStatus(CommonConstants.ACTIVE);
									 try{
									 field.setOrderSequence(Integer.parseInt(fieldDetails.getSequence()));
									 }catch(Exception e){
										 field.setOrderSequence(null); 
									 }
									 field.setCaption(fieldDetails.getLabel());
									 field.setBillerId(biller);
									 biller.getBillerFields().add(field);
								}
								 
								// biller.getBillerFields().add(field);
								 biller.setCategorytype(tempCategory);
								 biller.setVersion(CommonConstants.ONE_INT);
								 tempCategory.getBillers().add(biller);
							}
							if(aggregatorBillerCatgry.getBiller().size()>0){
							 actvieTempCategoryList.add(tempCategory);
							}else{
								InvoiceAggregatorhelper.downloadHistorycategoryforNewTempcategory(tempCategory,null,CommonConstants.AGG_BILLER_RESPONSE_NULL,history);
							}
						}
					}else{
						LOGGER.info("Null Response from Aggregator" + tempCategory.getCategoryId() + "---" + tempCategory.getCategoryName());
						listAggFailed.add(tempCategory.getCategoryId());
					}
					
				}else{
					listAggFailed.add(tempCategory.getCategoryId());
					LOGGER.info("error present in the Biller repsonse for category"+tempCategory.getCategoryId()+ "---"+tempCategory.getCategoryName());
					InvoiceAggregatorhelper.downloadHistorycategoryforNewTempcategory(tempCategory,null,CommonConstants.AGG_BILLER_FETCH_EXCEPTION,history);
					for( ExceptionType exceptionMessage:aggregatorBillerResponse.getHeader().getExceptions().getException()){
						LOGGER.info("exceptions are  {}-{}",new Object[]{exceptionMessage.getCode(),exceptionMessage.getDescription()});	
					}
				}
				
				
			}catch(Exception error){
				LOGGER.error("exception  occuerd in getting info",error);
				listAggFailed.add(tempCategory.getCategoryId());
				LOGGER.debug("exception for getting billers for static Biller catgeory {categoryid}",new Object[]{tempCategory.getCategoryId(),tempCategory.getCategoryName()});
				LOGGER.debug("exception  occuerd",new Object[]{tempCategory.getCategoryId(),error.getMessage()});
				
			}
			
			LOGGER.info("Download done for the category :: "+tempCategory.getCategoryId() +":: country billers:: "+tempCategory.getCountryCode());
			//break;
		}
		
		if(actvieTempCategoryList.size()>0){
			
			LOGGER.debug("Actvie Biller  static catgeories List ---->"+actvieTempCategoryList.size()) ;
			response.setTempBillerCategory(actvieTempCategoryList);
			if(listAggFailed.size()>0){
				String[] strAggFailed = new String[listAggFailed.size()];
				strAggFailed = listAggFailed.toArray(strAggFailed); 
				response.setAggFetchFailedCategories(strAggFailed);
				}
		}else{
			LOGGER.info("BILLER DOWNLOAD FAILED "+request.getUser().getCountry());
			throw new BusinessException("No active biller  present in the fro static categories");
			
		}
		
	 	request.setStatus(CommonConstants.SUCC);
		request.setStatusDesc(Messages._180.getMessage());
	 
	}
	
	public PayloadDTO getBillerCategoriesfromAggregator(PayloadDTO payload){
		GetBillerCategoriesRes aggregatorResponse=null;
		BillerDownloadRequest request=(BillerDownloadRequest)payload.getRequestVO();
		try{
		GetBillerCategoriesReq  aggregatorRequest=InvoiceAggregatorhelper.getAggregatorBillerCatgeoryRequest(request);
		  aggregatorResponse=invoice.getBillerCategories(aggregatorRequest);
		} catch (Exception exception) {
		LOGGER.error("Exception occurred during getBiller Categories. from the EDMI" + exception.getMessage());
		LOGGER.error("Exception occurred during getBiller Categories. from the EDMI" ,exception);
		request.setStatus(Messages._190.getCode());
		request.setStatusDesc(Messages._190.getMessage());
		request.setErrorCD(ExceptionMessages._181.getCode());
		request.setErrorDesc(ExceptionMessages._181.getMessage());
		payload.setRequestVO(request);
		return payload;
		
		}
		  
				  
		 if(aggregatorResponse.getHeader()!=null && aggregatorResponse.getHeader().getExceptions()!=null && aggregatorResponse.getHeader().getExceptions().getException()!=null){
			StringBuffer exceptionMessage = new StringBuffer(CommonConstants.EMPTY);
			List<ExceptionType> invoicexception =aggregatorResponse.getHeader().getExceptions().getException();
			LOGGER.info("exception while getting aggregator Biller Categories");
			for(ExceptionType error:invoicexception){
				exceptionMessage.append(error.getDescription()+"   " + error.getCode());
			}
			
			request.setStatus(Messages._190.getCode());
			request.setStatusDesc(Messages._190.getMessage());
			request.setErrorCD(ExceptionMessages._181.getCode());
			request.setErrorDesc(exceptionMessage.toString());
			LOGGER.info("exceptio messages from EDMI for Billercateories  ---> "+exceptionMessage);
		}else if(aggregatorResponse !=null  && aggregatorResponse.getGetBillerCategoriesResPayload()!=null && aggregatorResponse.getGetBillerCategoriesResPayload().getGetBillerCategoriesRes()!=null){
			Invoice invoice =aggregatorResponse.getGetBillerCategoriesResPayload().getGetBillerCategoriesRes();
			payload = InvoiceAggregatorhelper.aggregatorBillerCategorymapping(invoice, payload);
			LOGGER.info("Successfully retrieved the aggragator Biller categeries  ");
			request.setStatus(Messages._180.getCode());
			request.setStatusDesc(Messages._180.getMessage());
		}
		 LOGGER.info("Aggregator Billercategories Response"+aggregatorResponse);
	
	return payload;
	
	}
	
	public PayloadDTO getBillerProduts(PayloadDTO payload,List<TempBillerCategoryVO> tempCategoryList) throws Exception{
		GetBillersProductsRes aggregatorProductResponse=null;
		BillerDownloadRequest request=(BillerDownloadRequest)payload.getRequestVO();
		BillerDownloadResponse response=(BillerDownloadResponse)payload.getResponseVO();
		List<BillerDownloadHistory> history=response.getBillerDownloadHistory();
		request.setSubTypeName(CommonConstants.EDMI_GETBILLER_PRODUCTS_NAME);
		request.setEventType(CommonConstants.GET);
		Set<String> aggFetchFailedBillers=new HashSet<String>();
		try{
			List<TempBillerCategoryVO> tempIntermiCategoryList= new ArrayList<TempBillerCategoryVO>(0);
			for(TempBillerCategoryVO  tempCategory:tempCategoryList){
				
				TempBillerCategoryVO tempCategoryVO=tempCategory;
				TempBillerCategoryVO  tempIntermiCategoryVO=(TempBillerCategoryVO)tempCategoryVO.clone();
				Set<TempBillerVO>  setTempBiller= tempCategoryVO.getBillers();
				 
				Set<TempBillerVO> intermediateBillers= new HashSet<TempBillerVO>(0);
				
				for(TempBillerVO tempBiller:setTempBiller){
					
						try{
					request.setBillerCatgoryId(tempCategory.getCategoryId());
					request.setBillerId(tempBiller.getBillerId());
					
					Set<TempBillerVO> intermediateBillersperID=getBillerProdutsfromAggregator(request,tempBiller,tempCategory,history);
					if(intermediateBillersperID!=null && intermediateBillersperID.size()>0){
						intermediateBillers.addAll(intermediateBillersperID);
						LOGGER.info("retrieve products for the Billers {}{}-{}{} " ,new Object[]{tempCategoryVO.getCategoryId(),tempCategoryVO.getCategoryName(),tempBiller.getBillerId(),tempBiller.getBillerDesc()});
						LOGGER.info("product count is ---  "+ intermediateBillersperID.size()); 
							
						}else{
							
							LOGGER.info("Unable to retrieve the Billers {}{}-{}{} " ,new Object[]{tempCategoryVO.getCategoryId(),tempCategoryVO.getCategoryName(),tempBiller.getBillerId(),tempBiller.getBillerDesc()});
							//setTempBiller.remove(tempBiller);
						}
					
					tempIntermiCategoryVO.setBillers(intermediateBillers);
					
					}catch(Exception e){
					tempBiller.getAggFetchFailedBillers().add(tempBiller.getBillerId());
					InvoiceAggregatorhelper.downloadHistorycategoryforNewTempBillers(tempBiller,tempCategory,null,CommonConstants.AGG_BILLER_FETCH_FAIL,history);
						e.printStackTrace();
						LOGGER.info("Error Occured During that Biller while retir" ,new Object[]{tempCategoryVO.getCategoryId(),tempCategoryVO.getCategoryName(),tempBiller.getBillerId(),tempBiller.getBillerDesc()});
					}
						aggFetchFailedBillers.addAll(tempBiller.getAggFetchFailedBillers());	
				}
				
				tempIntermiCategoryList.add(tempIntermiCategoryVO);
			}
			if(aggFetchFailedBillers.size()>0){
				String[] strAggFailed = new String[aggFetchFailedBillers.size()];
				strAggFailed = aggFetchFailedBillers.toArray(strAggFailed); 
				response.setAggFetchFailedBillers(strAggFailed);
				}
			 		
			response.setTempBillerCategory(tempIntermiCategoryList);
			 			
			} catch (Exception exception) {
				LOGGER.error("Exception occurred during getBiller Categories. from the EDMI",exception);
			LOGGER.info("Exception occurred during getBiller Categories. from the EDMI" + exception.getMessage());
			exception.printStackTrace();
			LOGGER.info("BILLER DOWNLOAD FAILED "+request.getUser().getCountry());
			throw  new Exception(); 
			}
		return payload;
	}
	
	
	
	public  Set<TempBillerVO>  getBillerProdutsfromAggregator(BillerDownloadRequest request,TempBillerVO tempSingleBiller,TempBillerCategoryVO tempcategory,List<BillerDownloadHistory> history) throws Exception{
		Set<TempBillerVO> intermediateBillers=null;
		
		int productCount=0;
		GetBillersProductsRes aggregatorProductResponse=null;
		request.setSubTypeName(CommonConstants.EDMI_GETBILLER_PRODUCTS_NAME);
		request.setEventType(CommonConstants.GET);
		request.setInternalRequestId(InvoiceAggregatorhelper.getFrequentGenerateUniqueId());
		GetBillersProductsReq productrequest=InvoiceAggregatorhelper.getAggregatorBillerProductRequest(request);
		LOGGER.info("retreiving the  Product details for {}-{}-{}",new Object[]{request.getBillerCatgoryId(),request.getBillerId()});
		try{
			
			aggregatorProductResponse=invoice.getBillersProducts(productrequest);
		if(aggregatorProductResponse.getHeader()!=null&&aggregatorProductResponse.getHeader().getExceptions()==null){
				
			if(aggregatorProductResponse!=null && aggregatorProductResponse.getGetBillersProductsResPayload()!=null && aggregatorProductResponse.getGetBillersProductsResPayload().getGetBillerProductsRes()!=null &&aggregatorProductResponse.getGetBillersProductsResPayload().getGetBillerProductsRes().getInvoiceInfo()!=null &&  aggregatorProductResponse.getGetBillersProductsResPayload().getGetBillerProductsRes()!=null &&aggregatorProductResponse.getGetBillersProductsResPayload().getGetBillerProductsRes().getInvoiceInfo().getProductList()!=null){
				 List<ProductList> productList=aggregatorProductResponse.getGetBillersProductsResPayload().getGetBillerProductsRes().getInvoiceInfo().getProductList();
				 TempBillerVO tempBiller=tempSingleBiller;
				 Set<TempBillerField> tempFieldsclone=tempSingleBiller.getBillerFields();
				 for(TempBillerField TempBillerField:tempFieldsclone){
					 TempBillerField.setFieldType("P"); 
				 }
				 	if(productList.size() >0){
				 		
				 		intermediateBillers=new HashSet<TempBillerVO>(0);
				 		
				 		for(ProductList product:productList){
					 		if(productCount==0){
					 			productCount++;
					 		}else{
					 			tempBiller =(TempBillerVO)tempSingleBiller.clone();
					 			tempFieldsclone=new HashSet<TempBillerField>();
					 			for(TempBillerField intermediateField:(tempSingleBiller.getBillerFields())){
					 				tempFieldsclone.add((TempBillerField)intermediateField.clone());
					 			}
					 		}
					 		tempBiller.setAggregatePaymentCode(product.getPaymentCode());
				 			tempBiller.setBillerUniqueId(product.getPaymentCode());
				 			//tempBiller.setMaximumAmount(InvoiceAggregatorhelper.getDefualtAmountDouble(product.getMaximumAmountAllowed()));
				 			//tempBiller.setMinimumAmount(InvoiceAggregatorhelper.getDefualtAmountDouble(product.getMinimumAmountAllowed()));
				 			tempBiller.setDefaultAmount(InvoiceAggregatorhelper.getDefualtAmountDouble(product.getMinimumAmountAllowed()));
				 			tempBiller.setBillerDesc(tempSingleBiller.getBillerDesc());
				 			tempBiller.setBillerProductName(product.getProdcutName());
				 			tempBiller.setBillPresentmentType(InvoiceAggregatorhelper.getPresentmentType(product.getPartialPaymentAllowed(), product.getMinimumAmountAllowed(), product.getMaximumAmountAllowed()));
				 			tempBiller.setBillerFields(tempFieldsclone);
				 			intermediateBillers.add(tempBiller);
				 		}
				 		return intermediateBillers; 
						
					}  else{
						LOGGER.info("No products for this billers",new Object[]{request.getBillerCatgoryId(),request.getBillerId()});
						InvoiceAggregatorhelper.downloadHistorycategoryforNewTempBillers(tempSingleBiller,tempcategory,null,CommonConstants.AGG_BILLER_RESPONSE_NULL,history);
					}
		}else{
			tempSingleBiller.getAggFetchFailedBillers().add(tempSingleBiller.getBillerId());
			LOGGER.info("BILLER DOWNLOAD FAILED " + request.getUser().getCountry() + "Category : " + request.getBillerCatgoryId() + "Biller : " + request.getBillerId());
			LOGGER.info("Product Resposne not recevied for BIller  --  {}",new Object[]{request.getBillerCatgoryId(),request.getBillerId()});
			InvoiceAggregatorhelper.downloadHistorycategoryforNewTempBillers(tempSingleBiller,tempcategory,null,CommonConstants.AGG_BILLER_RESPONSE_NULL,history);
			
		}
			 
		 
		}else{
			tempSingleBiller.getAggFetchFailedBillers().add(tempSingleBiller.getBillerId());
			LOGGER.info("BILLER DOWNLOAD FAILED " + request.getUser().getCountry() + "Category : " + request.getBillerCatgoryId() + "Biller : " + request.getBillerId());
			InvoiceAggregatorhelper.downloadHistorycategoryforNewTempBillers(tempSingleBiller,tempcategory,null,CommonConstants.AGG_BILLER_FETCH_EXCEPTION,history);
			LOGGER.info("Edmi Error Error Resposne is there for  {}{}{}",new Object[]{request.getBillerCatgoryId(),request.getBillerId()});
			
			ExceptionListType exceptions=	aggregatorProductResponse.getHeader().getExceptions();
			for(ExceptionType exception:exceptions.getException()){
				
				LOGGER.info("Error for the biller {}-{}--------{}--{}",new Object[]{request.getBillerCatgoryId(),request.getBillerId(),exception.getCode(),exception.getDescription()});
			}
			LOGGER.debug("Edmi Error Error Resposne is there  {}{}{}",new Object[]{request.getBillerCatgoryId(),request.getBillerId()});
		}
		
		}catch(Exception e){
			LOGGER.error("Exception  ",e);
			tempSingleBiller.getAggFetchFailedBillers().add(tempSingleBiller.getBillerId());
			LOGGER.error("Exception while Getting the product for {}{}{}",new Object[]{request.getBillerCatgoryId(),request.getBillerId()});
			InvoiceAggregatorhelper.downloadHistorycategoryforNewTempBillers(tempSingleBiller,tempcategory,null,CommonConstants.AGG_BILLER_FETCH_FAIL,history);
			LOGGER.info("BILLER DOWNLOAD FAILED "+request.getUser().getCountry());
			throw new BusinessException("No product Details for Billers");
			
		}
		
		return intermediateBillers;
	}
	
	public PayloadDTO getBillerfromAggregator(PayloadDTO payload){
		GetBillersRes aggregatorBillersResponse=null;
		GetBillersRes billerResponse=null;
		BillerDownloadRequest request=(BillerDownloadRequest)payload.getRequestVO();
		LOGGER.info("Hitting the All GetBillers from Aggregator");
		request.setSubTypeName(CommonConstants.EDMI_GETBILLERS_NAME);
		request.setEventType(CommonConstants.GET);
		request.setInternalRequestId(InvoiceAggregatorhelper.getFrequentGenerateUniqueId());
		
		
		try{
			GetBillersReq productrequest=InvoiceAggregatorhelper.getAggregatorAllBillersRequest(request);
			  billerResponse= invoice.getBillers(productrequest);
			  LOGGER.info("Retrevied AggregatorBillers Successfully,but  check if not null or not");
			  
			 if(billerResponse!=null && billerResponse.getGetBillersResPayload()!=null && billerResponse.getGetBillersResPayload().getGetBillersRes().getInvoiceInfo()!=null){
				 LOGGER.error("GetBiller response is not null");
				 if(billerResponse.getGetBillersResPayload().getGetBillersRes().getInvoiceInfo().getBillerCategory()!=null&&billerResponse.getGetBillersResPayload().getGetBillersRes().getInvoiceInfo().getBillerCategory().size()>0){
					 
					 List<BillerCategory> billersCategoryList=billerResponse.getGetBillersResPayload().getGetBillersRes().getInvoiceInfo().getBillerCategory();
					 LOGGER.info("GetBiller List data  is avaialble");
					 InvoiceAggregatorhelper.mappingBillercategorieswithBillerList(payload, billersCategoryList);
			      LOGGER.info("GetBiller List data  is avaialble");
			      
			      	request.setStatus(CommonConstants.SUCC);
					request.setStatusDesc(Messages._180.getMessage());
				 
					 
			 }
					
				 else{
					 LOGGER.error("GetBiller list  is   null");
					 	request.setStatus(CommonConstants.FAIL);
						request.setStatusDesc(Messages._190.getMessage());
						request.setErrorCD(ExceptionMessages._182.getCode());
						request.setErrorDesc(ExceptionMessages._182.getMessage());
						LOGGER.info("BILLER DOWNLOAD FAILED "+request.getUser().getCountry());
						return payload;
				 }
				  
			  }else{
				  LOGGER.error("GetBiller response is   null");
				  request.setStatus(CommonConstants.FAIL);
					request.setStatusDesc(Messages._190.getMessage());
					request.setErrorCD(ExceptionMessages._182.getCode());
					request.setErrorDesc(ExceptionMessages._182.getMessage());
					LOGGER.info("BILLER DOWNLOAD FAILED "+request.getUser().getCountry());
					return payload;
				  
			  }
			  
		}catch (Exception exception) {
					if(exception instanceof WebServiceException){
						LOGGER.error("WebserviceException or timeout occurred during call with getBiller Categories  from the Aggregator" + exception.getMessage());
						exception.printStackTrace();
					}else{
						LOGGER.error("general Exception occurred during call with  getBiller Categories  from the Aggregator -" + exception.getMessage());
					}
			
			exception.printStackTrace();
			LOGGER.error("general Exception occurred during call with  getBiller Categories  from the Aggregator -",exception);
			request.setStatus(CommonConstants.FAIL);
			request.setStatusDesc(Messages._190.getMessage());
			request.setErrorCD(ExceptionMessages._182.getCode());
			request.setErrorDesc(ExceptionMessages._182.getMessage());
			LOGGER.info("BILLER DOWNLOAD FAILED "+request.getUser().getCountry());
			return payload;
			}
		//System.out.println(aggregatorBillersResponse);
		//return payload;
		return payload;
	}
		

	public BillerDownloadDAO getBillerDAO() {
		return billerDAO;
	}

	public void setBillerDAO(BillerDownloadDAO billerDAO) {
		this.billerDAO = billerDAO;
	}
	
	public InvoicePortType getInvoice() {
		return invoice;
	}

	public void setInvoice(InvoicePortType invoice) {
		this.invoice = invoice;
	}

	@Override
	public void getBillerfromStaticCategoery(PayloadDTO dto) {
		// TODO Auto-generated method stub
		
	}
	

}
