package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerField;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.PaymentTransactionService;

public class PaymentValidationProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentValidationProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;
	
	/**
	 * @param bean
	 * @return
	 */
	public PayloadDTO process(PayloadDTO bean) {
		LOGGER.info("Task of validating payment request ::: Start");
		
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		BillerPayDetailsVO billerDetails = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
			LOGGER.info("Validating payment request for ::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			if(billerPayRequestVO.getBillerPayDetailsVO().getPayMthd()!=null && !billerPayRequestVO.getUser().getCountry().equalsIgnoreCase(CommonConstants.HK_COUNTRY_CODE))
			if(billerPayRequestVO.getBillerPayDetailsVO().getPayMthd().equalsIgnoreCase(CommonConstants.ONE_TIME_PAYMENT)){
				LOGGER.info("Onetime Payment ::" + billerPayRequestVO.getUser().getCountry() +"::"+billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				paymentTransactionService.saveOneTimePayee(billerPayRequestVO);
			}
			
			
			if(billerPayRequestVO.getBillerPayDetailsVO().getPayeeId() != null 
					/*&& billerPayRequestVO.getBillerPayDetailsVO().getPayMthd() != null
					&& billerPayRequestVO.getBillerPayDetailsVO()
						.getPayMthd().equalsIgnoreCase("R")*/){
				
				billerDetails = paymentTransactionService.populateDetailsForPayee(
						billerPayRequestVO.getBillerPayDetailsVO());
				
				if(billerDetails == null){
					billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.FAIL);
					billerPayRequestVO.getBillerPayDetailsVO()
						.getTransactionInfoVO().setHostRespCd(ExceptionMessages._164.getCode());
					billerPayRequestVO.getBillerPayDetailsVO()
						.getTransactionInfoVO().setHostRespDesc(ExceptionMessages._164.getMessage());
				}
			}
			
		}catch (Exception e) {
			LOGGER.error("Exception while validating payment request ::: " , e);
			
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO()
				.getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO()
				.getTransactionInfoVO().setHostRespDesc(e.getMessage());
		} finally {
			
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			LOGGER.info("Setting header objects in response vo in payee validation" 
					+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
				
			bean.setResponseVO(billerPayResponseVO);
		}
		
		bean.setRequestVO(billerPayRequestVO);
		LOGGER.info("Task of validating payment request ::: End");
		return bean;
	}
	
	/**
	 * @param bean
	 * @return
	 */
	public PayloadDTO processCS(PayloadDTO bean) {
		LOGGER.info("Task of validating payment request processCS ::: Start");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		BillerPayDetailsVO billerDetails = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
			LOGGER.info("Validating payment request for processCS ::: " +billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			if(billerPayRequestVO.getBillerPayDetailsVO().getPayMthd()!=null)
			if(billerPayRequestVO.getBillerPayDetailsVO().getPayMthd().equalsIgnoreCase(CommonConstants.ONE_TIME_PAYMENT)){
				paymentTransactionService.saveOneTimePayee(billerPayRequestVO);
			}
			if(billerPayRequestVO.getBillerPayDetailsVO().getPayeeId() != null){
				billerDetails = paymentTransactionService.populateDetailsForPayeeCS(billerPayRequestVO.getBillerPayDetailsVO());
				if(billerDetails == null){
					billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.FAIL);
					billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(ExceptionMessages._164.getCode());
					billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(ExceptionMessages._164.getMessage());
				}
			}
		}catch (Exception e) {
			LOGGER.error("Exception while validating payment request processCS ::: " , e);
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
		} finally {
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			LOGGER.info("Setting header objects in response vo in payee validation processCS" + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
			bean.setResponseVO(billerPayResponseVO);
		}
		bean.setRequestVO(billerPayRequestVO);
		LOGGER.info("Task of validating payment request processCS ::: End");
		return bean;
	}


	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
}
