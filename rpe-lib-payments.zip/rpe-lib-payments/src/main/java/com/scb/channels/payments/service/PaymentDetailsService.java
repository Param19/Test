package com.scb.channels.payments.service;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;

/**
 * The Interface PaymentTransactionService.
 */
public interface PaymentDetailsService{
	
	BillerPayResponseVO getpaymentDetails(BillerPayRequestVO billerPayRequestVO);
	
	BillerPayResponseVO validateWallet(BillerPayRequestVO billerPayRequestVO);
	
	//Added for Orange Money
	BillerPayResponseVO getpaymentWalletDetails(BillerPayRequestVO billerPayRequestVO,String fieldsDelimitedStr);
}