package com.scb.channels.payments.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.qrpayments.service.QRPaymentTransactionService;

public class QRPaymentRetryListProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentRetryListProcessor.class);
	
	private QRPaymentTransactionService qrPaymentTransactionService;
	
	private DataBean dataBean; 
	
	public List<QRPaymentDetailVO> process() {
		QRPaymentRequestVO qrPaymentRequestVO = null;
		List<QRPaymentDetailVO> tempList = null;
		List<QRPaymentDetailVO> list = new ArrayList<QRPaymentDetailVO>();
		try {
			LOGGER.info(":::: Getting retry payments for qr payment ::::");
			
			String countryList = dataBean.getMap().get(CommonConstants.QR_COUNTRIES);
			List<String> qrCountries = countryList != null ? Arrays.asList(countryList.toString().split(CommonConstants.COMMA)) : CommonConstants.QR_COUNTRY_LIST;
	        for (String country : qrCountries){
	        	
	        	LOGGER.info(":::: Inside  QRPaymentRetryListProcessor Process Country ::::"+country);
	        	String paymentTypeList = dataBean.getMap().get(country+CommonConstants.QR_PAYMENTTYPE);
	        	List<String> sourceOfFundList = paymentTypeList != null ? Arrays.asList(paymentTypeList.toString().split(CommonConstants.COMMA)) : CommonConstants.QR_FUND_LIST;
	        	for(String paymentType : sourceOfFundList){
	        		
	        		LOGGER.info(":::: Inside  QRPaymentRetryListProcessor Process PaymentType ::::"+paymentType);
	        		tempList = new ArrayList<QRPaymentDetailVO>();
					qrPaymentRequestVO = new QRPaymentRequestVO();
					QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
					qrPaymentDetailVO.setCountryCode(country);
					qrPaymentDetailVO.setSourceOfFund(paymentType);
					qrPaymentRequestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
					tempList = qrPaymentTransactionService.getQRPaymentRetryTransactionList(qrPaymentRequestVO);
					for(QRPaymentDetailVO qrPaymentDetailVo : tempList){
						list.add(qrPaymentDetailVo);
					}
	        	}
	        }
			LOGGER.info("Inside PaymentRetryListProcessor After Fetching retry list from DB -- "+list);
		}catch (Exception e) {
			LOGGER.error(e.getMessage());
			LOGGER.error("Exception ::: ", e);
		} 
		return list;
	}
	public PayloadDTO populatePayload(QRPaymentDetailVO qrPaymentDetailVO) {
		PayloadDTO payloadDTO = null;
		LOGGER.info("Inside populate Payload  at QRPaymentRetryListProcessor");
		QRPaymentRequestVO qrPaymentRequestVO = null;
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();
		
		try {
			qrPaymentRequestVO = new QRPaymentRequestVO();
			if(qrPaymentDetailVO!=null) {
				LOGGER.info("Populate qr payload for retry :::: "+ qrPaymentDetailVO.getClient_reference());
				
				user.setCustomerId(qrPaymentDetailVO.getCustomerId() != null ?	qrPaymentDetailVO.getCustomerId() : CommonConstants.EMPTY);
				user.setCountry(qrPaymentDetailVO.getCountryCode());
				user.setChannelId(qrPaymentDetailVO.getChannel() != null ?	qrPaymentDetailVO.getChannel() : CommonConstants.EMPTY);
				
				service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
				service.setServiceName(CommonConstants.QR_PAYMENT);
				
				message.setReqID(qrPaymentDetailVO.getClient_reference());
				
				client.setChannel(qrPaymentDetailVO.getChannel() != null ?	qrPaymentDetailVO.getChannel() : CommonConstants.EMPTY);
				client.setCountry(qrPaymentDetailVO.getCountryCode());
				
				//qrPaymentDetailVO.setTxnActStatus(qrPaymentDetailVO.getPayment_status());
				qrPaymentRequestVO.setQrPaymentDetailVO(qrPaymentDetailVO);
				qrPaymentRequestVO.setUser(user);
				qrPaymentRequestVO.setClientVO(client);
				qrPaymentRequestVO.setMessageVO(message);
				qrPaymentRequestVO.setServiceVO(service);
				
				payloadDTO = new PayloadDTO();
				payloadDTO.setRequestVO(qrPaymentRequestVO);
				LOGGER.info("qr payload for retry populated successfully :::: "+qrPaymentDetailVO.getClient_reference());
			}
		} catch (Exception e) {
			payloadDTO = null;
			LOGGER.error("Exception occurred during retry for one of the qr payments", e);
			LOGGER.error(e.getMessage());
		} 
		return payloadDTO;
	}
	
	
	public QRPaymentTransactionService getQrPaymentTransactionService() {
		return qrPaymentTransactionService;
	}

	public void setQrPaymentTransactionService(QRPaymentTransactionService qrPaymentTransactionService) {
		this.qrPaymentTransactionService = qrPaymentTransactionService;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	
}
