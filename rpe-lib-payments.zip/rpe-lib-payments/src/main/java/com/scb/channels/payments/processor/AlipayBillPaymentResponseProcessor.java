package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.actors.threadpool.Arrays;

import com.sc.cash.payment.mobile.v2.invoice.PaymentDetails;
import com.sc.cash.payment.mobile.v2.invoice.TransactionStatus2;
import com.sc.cash.payment.mobile.v2.ws.provider.invoice.PostPaymentRes;
import com.sc.scbml_1.ExceptionType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.MessageVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.TransactionInfoVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.service.PaymentTransactionService;

public class AlipayBillPaymentResponseProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AlipayBillPaymentResponseProcessor.class);
	
	PaymentTransactionService paymentTransactionService;
	
	private DataBean dataBean;
	
	public PayloadDTO process(PostPaymentRes paymentResponse){
		PayloadDTO payload = new PayloadDTO();
		BillerPayResponseVO response = new BillerPayResponseVO();
		BillerPayRequestVO request = new BillerPayRequestVO();
		BillerPayDetailsVO billerDetails = new BillerPayDetailsVO();
		TransactionInfoVO transaction = new TransactionInfoVO();
		
		MessageVO message = new MessageVO();
		ClientVO client = new ClientVO();
		ServiceVO service = new ServiceVO();
		UserVO user = new UserVO();
		
		if(paymentResponse != null && paymentResponse.getHeader() != null &&
				paymentResponse.getHeader().getOriginationDetails() != null &&
				paymentResponse.getHeader().getOriginationDetails().getTrackingId() != null) {
			
			String trackingId = paymentResponse.getHeader().getOriginationDetails().getTrackingId();
			
			
			LOGGER.info("Fetch the alipay payment details from the DB :::: " + 
					paymentResponse.getHeader().getOriginationDetails().getTrackingId());
			System.out.println("Fetch the alipay payment details from the DB :::: " + 
					paymentResponse.getHeader().getOriginationDetails().getTrackingId());
			
			PaymentDetailVO paymentDetails = paymentTransactionService.getPaymentDetails(trackingId);
			String partnerName = (paymentDetails != null && paymentDetails.getPayee() != null && 
					paymentDetails.getPayee().getBillerVO() != null && 
					paymentDetails.getPayee().getBillerVO().getBillerId() != null) ? 
					paymentDetails.getPayee().getBillerVO().getBillerId() : "ALIPAY";
					
			String partnerType = (paymentDetails != null && paymentDetails.getPayee() != null && 
					paymentDetails.getPayee().getBillerVO() != null && 
					paymentDetails.getPayee().getBillerVO().getBillerDesc() != null) ? 
					paymentDetails.getPayee().getBillerVO().getBillerDesc() : "ALIPAY WALLET";
			
			
			if(paymentDetails != null){
				billerDetails = BillpaymentMappingHelper.
						getBillPayRequestFromPaymentDetails(paymentDetails);
				
				transaction = billerDetails.getTransactionInfoVO();
				
				LOGGER.info("Alipay Payment details object available :::: " + 
						paymentResponse.getHeader().getOriginationDetails().getTrackingId());
				System.out.println("Alipay Payment details object available :::: " + 
						paymentResponse.getHeader().getOriginationDetails().getTrackingId());
			
				
				billerDetails.setHostName(CommonConstants.ALIPAY_AGGREGATOR);
				/*billerDetails.setPayRef(
						paymentResponse.getHeader().getOriginationDetails().getTrackingId());
				billerDetails.setCountryCode(
						paymentResponse.getHeader().getOriginationDetails().
						getMessageSender().getCountryCode());*/
				
				if(paymentResponse.getHeader().getExceptions() != null && 
						paymentResponse.getHeader().getExceptions().getException() != null) {
					
					ExceptionType exception = paymentResponse.getHeader().getExceptions().getException().get(0);
					
					LOGGER.info("Alipay Payment failed for transaction :: " + trackingId);
					LOGGER.info("error code ::: alipay " + exception.getCode().getValue());
					LOGGER.info("error desc ::: alipay " + exception.getDescription());
					
					transaction.setHostRespCd(exception.getCode().getValue());
					transaction.setHostRespDesc(exception.getDescription());
					
					billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
					billerDetails.setTransactionInfoVO(transaction);
					
				} else {
					if(paymentResponse.getPostPaymentResPayload() != null && 
							paymentResponse.getPostPaymentResPayload().
							getPostPaymentRes().getInvoiceInfo() != null &&
									paymentResponse.getPostPaymentResPayload().
							getPostPaymentRes().getInvoiceInfo().
							getPaymentDetails() != null) {
						
						PaymentDetails invoicePaymentDetails = 
								paymentResponse.getPostPaymentResPayload().getPostPaymentRes().
								getInvoiceInfo().getPaymentDetails().get(0);
						
						if(invoicePaymentDetails != null && invoicePaymentDetails.getTransactionStatus() != null) {
							LOGGER.info("Alipay Payment TransactionStatus object identified :::: " + 
									paymentResponse.getHeader().getOriginationDetails().getTrackingId());
							System.out.println("Alipay Payment TransactionStatus object identified :::: " + 
									paymentResponse.getHeader().getOriginationDetails().getTrackingId());
							
							//if(paymentDetails.getTotalAmount().equals(invoicePaymentDetails.getTransactionAmount())) {

								LOGGER.info("Alipay ::: Setting failure ::: transaction amount & response amount are same, Req Amount :" 
										+paymentDetails.getTotalAmount() +", Response Amount :" + invoicePaymentDetails.getTransactionAmount());
								
								TransactionStatus2 transactionStatus = invoicePaymentDetails.getTransactionStatus();
								transaction.setHostRespCd(transactionStatus.getStatusCodeID());
								transaction.setHostRespDesc(transactionStatus.getStatusDescription());
								
								LOGGER.info("Alipay ::: transactionStatus details : for {}, getStatusCodeID {},  getStatusDescription {},  getStatus {}, getStatusCode {}",
										new Object[] { paymentResponse.getHeader().getOriginationDetails().getTrackingId(),	transactionStatus.getStatusCodeID(),
										transactionStatus.getStatusDescription(), transactionStatus.getStatus(), transactionStatus.getStatusCode()});
								
								if(invoicePaymentDetails.getAggregatorTransactionID() != null){
									transaction.setHostTxnRefNo(invoicePaymentDetails.getAggregatorTransactionID());
								}
											
								if(transaction.getHostRespCd() != null && 
										Arrays.asList(dataBean.getMap().
												get(billerDetails.getCountryCode() + CommonConstants.AGGREGATOR_SUCCESS_STATUS).
												split(CommonConstants.COMMA)).
												contains(transaction.getHostRespCd())) {
									
									LOGGER.info("Alipay :: Setting success ::: " + transaction.getHostRespCd());
									billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_SUCCESS);
									
								} else if(transaction.getHostRespCd() != null && 
										Arrays.asList(dataBean.getMap().
												get(billerDetails.getCountryCode() + CommonConstants.AGGREGATOR_INPROCESS_STATUS).
												split(CommonConstants.COMMA)).
												contains(transaction.getHostRespCd())) {
									LOGGER.info("Alipay :: Setting UNknown Status to INprocess ::: " + transaction.getHostRespCd());
									billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_INPROCESS);								
								}else if(transaction.getHostRespCd() != null && 
										Arrays.asList(dataBean.getMap().
												get(billerDetails.getCountryCode() + CommonConstants.AGGREGATOR_NOT_SUCCESS).
												split(CommonConstants.COMMA)).
												contains(transaction.getHostRespCd())) {
									LOGGER.info("Alipay :: Setting UNknown Status to INprocess ::: " + transaction.getHostRespCd());
									billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_NOT_SUCCESS);								
								}
								
								else {
									LOGGER.info("Alipay :: Setting failure ::: " + transaction.getHostRespCd());
									billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
								}
								
							/*} else { //Suggest to check if payAmount in the response match that in the request. If mismatch,
										//client shall handle it as exception and report fatal error.:: from Alipay API Doc
								LOGGER.info("Setting failure ::: transaction amount & response amount are not same, Req Amount :" 
										+paymentDetails.getTotalAmount() +", Response Amount :" + invoicePaymentDetails.getTransactionAmount());
								billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
							}*/
														
							LOGGER.info("Alipay :: Collected all required details :::: " + 
									billerDetails.getPayRef() + " :::: " +
									billerDetails.getCountryCode() + " :::: " + 
									billerDetails.getTransactionInfoVO().getHostRespCd() + " :::: " +
									billerDetails.getTransactionInfoVO().getHostRespDesc() + " :::: ");
							
							user.setCustomerId(billerDetails.getCustomerId() != null ?
									billerDetails.getCustomerId() : CommonConstants.EMPTY);
							user.setCountry(billerDetails.getCountryCode());
							user.setChannelId(billerDetails.getChannel() != null ?
									billerDetails.getChannel() : CommonConstants.EMPTY);
							
							service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
							service.setServiceName(CommonConstants.WALLET_PAYMENT);
							service.setServiceTxnType(CommonConstants.INSERT);
							
							message.setReqID(billerDetails.getPayRef());
							message.setRequestCode(billerDetails.getPayRef());
							message.setCorrelationId(billerDetails.getPayRef());
							
							client.setChannel(billerDetails.getChannel() != null ?
									billerDetails.getChannel() : CommonConstants.EMPTY);
							client.setCountry(billerDetails.getCountryCode());
							client.setPartnerName(partnerName);
							client.setPartnerType(partnerType);
							LOGGER.info("Alipay :: Header objects has been set for payload ::: " 
									+ billerDetails.getPayRef());
							
						} else {
							transaction.setHostRespCd(CommonConstants.NEGATIVE);
							transaction.setHostRespDesc("Missing Invoice details in payment response");
							billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
	
							LOGGER.info("Alipay :: Missing Payment TransactionStatus object details for payment status");
						}
					} else {
						transaction.setHostRespCd(CommonConstants.NEGATIVE);
						transaction.setHostRespDesc("Missing payload details in payment response");
						billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_TIMEOUT);
						
						LOGGER.info("Alipay :: Missing payload details for payment status");
					}
				}
				response.setStatus(CommonConstants.SUCC);
				LOGGER.info("Alipay payload for ::: " + billerDetails.getPayRef());
			}
		} else {
			transaction.setHostRespCd(CommonConstants.NEGATIVE);
			transaction.setHostRespDesc("Missing tracking id in payment response");
			billerDetails.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			
			LOGGER.info("Alipay Payment Status Object is NULL");
			System.out.println("Alipay Payment Status Object is NULL");
			response.setStatus(CommonConstants.FAIL);
		}
		
		billerDetails.setHostName(CommonConstants.ALIPAY_AGGREGATOR);
		billerDetails.setTransactionInfoVO(transaction);
		response.setBillerPayDetailsVO(billerDetails);
		request.setBillerPayDetailsVO(billerDetails);
		
		if(response.getBillerPayDetailsVO() != null && 
				response.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
			LOGGER.info("Alipay :: Setting the aggregator response status details to host response list in alipay reversal" + 
					response.getBillerPayDetailsVO().getPayRef() +
				response.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
				response.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			
			HostResponseVO hostResponse = new HostResponseVO();
			hostResponse.setCode(response.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
			hostResponse.setDesc(response.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
			hostResponse.setHostName(response.getBillerPayDetailsVO().getHostName());
			
			//response.getHostResponseVO().add(hostResponse);
			request.getHostResponseVO().add(hostResponse);
		}
		
		request.setMessageVO(message);
		request.setServiceVO(service);
		request.setUser(user);
		request.setClientVO(client);
		
		response.setMessageVO(message);
		response.setServiceVO(service);
		response.setUser(user);
		response.setClientVO(client);
		
		payload.setRequestVO(request);
		payload.setResponseVO(response);
		
		LOGGER.info("Alipay :: return payload for ::: " + billerDetails.getPayRef());
		return payload;
	}

	/**
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}

	/**
	 * @param dataBean the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
}
