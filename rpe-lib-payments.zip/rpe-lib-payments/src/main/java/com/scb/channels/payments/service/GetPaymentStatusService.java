package com.scb.channels.payments.service;

import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;

/**
 * @author 1521723
 * 
 */
public interface GetPaymentStatusService {

	/**
	 * @param billerPayRequestVO
	 * @return
	 */
	public BillerPayResponseVO getPaymentStatus(BillerPayRequestVO billerPayRequestVO) throws Exception ;
	
}