package com.scb.channels.qrpayments.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.base.vo.QRPaymentViewVO;
import com.scb.channels.qrpayments.dao.QRPaymentDAO;
import com.scb.channels.qrpayments.service.QRPaymentService;

// TODO: Auto-generated Javadoc
/**
 * The Class QRPayServiceImpl.
 */
public class QRPayServiceImpl implements QRPaymentService{

	/** The Constant LOGGER. */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(QRPayServiceImpl.class);
	
	/** The qr payment dao. */
	private QRPaymentDAO qrPaymentDAO;
	
	/* (non-Javadoc)
	 * @see com.scb.channels.qrpayments.service.QRPaymentService#getQRPaymentHistoryById(com.scb.channels.base.vo.QRPaymentHistoryRequestVO)
	 */
	//@Override
	//public List<QRPaymentVO> getQRPaymentHistoryById(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO) {
	@Override
		public List<QRPaymentVO> getQRPaymentHistoryViewById(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO) {
		List<QRPaymentVO> qrPaymentResObj = null;
		
		try {

			LOGGER.info("getQRPaymentHistoryByCustId into DB {}}",new Object[] { qrPaymentHistoryRequestVO.getUser().getCustomerId() });

			//qrPaymentResObj = qrPaymentDAO.getPaymentHistoryByCustId(qrPaymentHistoryRequestVO);
			qrPaymentResObj = qrPaymentDAO.getPaymentHistoryViewByCustId(qrPaymentHistoryRequestVO);

			LOGGER.info("At service class after DB Fetch getQRPaymentHistoryByCustId {}}",new Object[] {qrPaymentResObj});

			return qrPaymentResObj;
			
		} catch (Exception e) {

			LOGGER.info("getPaymentHistoryByCustId Error" + e.getMessage());

			throw e;

		}

	}

	/**
	 * Gets the qr payment dao.
	 *
	 * @return the qr payment dao
	 */
	public QRPaymentDAO getQrPaymentDAO() {
		return qrPaymentDAO;
	}

	/**
	 * Sets the qr payment dao.
	 *
	 * @param qrPaymentDAO the new qr payment dao
	 */
	public void setQrPaymentDAO(QRPaymentDAO qrPaymentDAO) {
		this.qrPaymentDAO = qrPaymentDAO;
	}
	
	

}
