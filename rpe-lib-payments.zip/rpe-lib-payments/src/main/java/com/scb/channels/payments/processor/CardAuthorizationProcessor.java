package com.scb.channels.payments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.CreditCardService;
import com.scb.channels.payments.service.impl.CreditCardServiceImpl;

public class CardAuthorizationProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditCardServiceImpl.class);
	
	/**
	 * CreditCardService bean
	 */
	private CreditCardService creditCardService;
	
	public PayloadDTO processAuthorization(PayloadDTO bean) throws BusinessException {


		LOGGER.info("Task in Card Authorization Processor :::: Start");
		
		BillerPayRequestVO billerPayRequestVO = null;
 		BillerPayResponseVO billerPayResponseVO = null;
		try {
			if(bean != null && bean.getRequestVO() != null){
				billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
				LOGGER.info("Posting request to credit card system ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				billerPayResponseVO = creditCardService.authorizeCreditCard(billerPayRequestVO);
				
				LOGGER.info("Received response response from credit card system ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			}
		}catch (Exception e) {
			LOGGER.info("Exception Occurred while Card authorization from credit card system :::" +
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			LOGGER.info("Exception :::: ", e);
			LOGGER.error("Exception :::: ", e);
			
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			
			LOGGER.info("Setting Fail status for the card authorization due to Exception ::: " 
					+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
			billerPayResponseVO.setStatusDesc(e.getMessage());
			billerPayResponseVO.setErrorDesc(e.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
			
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for card auth ::: " + billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				LOGGER.error(e.getCause().toString());
				billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			}
			
		} finally{
			
			if (billerPayResponseVO != null) {
				LOGGER.info("Setting header objects in response value object" 
						+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				if(billerPayResponseVO.getBillerPayDetailsVO() == null) {
					billerPayResponseVO.setBillerPayDetailsVO(
							billerPayRequestVO.getBillerPayDetailsVO());
				}
				
				if(billerPayResponseVO.getBillerPayDetailsVO() != null && 
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
					LOGGER.info("Setting the aggregator response status details to host response list  in card auth posting" + 
							billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
					
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
					hostResponse.setDesc(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
					hostResponse.setHostName(billerPayResponseVO.getBillerPayDetailsVO().getHostName());
					
					billerPayRequestVO.getHostResponseVO().add(hostResponse);
				}
				
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			}
			bean.setResponseVO(billerPayResponseVO);
		}
		LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() ::::: " 
				+ billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus());
		
		LOGGER.info("Task in Post Transaction Processor :::: End");
		return bean;
	
	
	}
	
	public PayloadDTO processAuthorizationReversal(PayloadDTO bean) throws BusinessException {

		LOGGER.info("Task in process Authorization Reversal :::: Start");
		
		BillerPayRequestVO billerPayRequestVO = null;
 		BillerPayResponseVO billerPayResponseVO = null;
		try {
			if(bean != null && bean.getRequestVO() != null){
				billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
				LOGGER.info("Posting request to credit card system for auth reversal ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				billerPayResponseVO = creditCardService.reverseCardAuthorization(billerPayRequestVO);
				
				LOGGER.info("Received response response from credit card system fore reversal ::: " +
						billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			}
		}catch (Exception e) {
			LOGGER.info("Exception Occurred while Card authorization from credit card system :::" +
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			LOGGER.info("Exception while auth reversal :::: ", e);
			LOGGER.error("Exception during auth reversal :::: ", e);
			
			if (billerPayResponseVO == null) {
				billerPayResponseVO = new BillerPayResponseVO();
			}
			
			LOGGER.info("Setting Fail status for the card authorization due to Exception ::: " 
					+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			billerPayResponseVO.setStatus(ExceptionMessages._105.getCode());
			billerPayResponseVO.setStatusDesc(e.getMessage());
			billerPayResponseVO.setErrorDesc(e.getMessage());
			billerPayResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnStatusCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
			
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for card auth reversal ::: " 
						+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				LOGGER.error(e.getCause().toString());
				billerPayResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				billerPayResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespCd(CommonConstants.NEGATIVE);
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setHostRespDesc(e.getMessage());
			}
			
		} finally{
			
			if (billerPayResponseVO != null) {
				LOGGER.info("Setting header objects in response value object during card auth ::: " 
						+ billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
				
				if(billerPayResponseVO.getHostResponseVO() != null) {
					for(HostResponseVO hostRes : billerPayRequestVO.getHostResponseVO()) {
						billerPayResponseVO.getHostResponseVO().add(hostRes);
					}
				}
				
				if(billerPayResponseVO.getBillerPayDetailsVO() == null) {
					billerPayResponseVO.setBillerPayDetailsVO(
							billerPayRequestVO.getBillerPayDetailsVO());
				}
				
				if(billerPayResponseVO.getBillerPayDetailsVO() != null && 
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO() != null) {
					LOGGER.info("Setting the aggregator response status details to host response list in card auth reversal" + 
							billerPayRequestVO.getBillerPayDetailsVO().getPayRef() +
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd() +
						billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
					
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespCd());
					hostResponse.setDesc(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getHostRespDesc());
					hostResponse.setHostName(billerPayResponseVO.getBillerPayDetailsVO().getHostName());
					
					billerPayRequestVO.getHostResponseVO().add(hostResponse);
				}
				
				billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO()); 
				billerPayResponseVO.setUser(billerPayRequestVO.getUser());
				billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
				billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
				
				bean.getRequestVO().getHostResponseVO().addAll(billerPayResponseVO.getHostResponseVO());
			}
			bean.setResponseVO(billerPayResponseVO);
		}
		LOGGER.info("billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus() ::::: " 
				+ billerPayRequestVO.getBillerPayDetailsVO().getTxnActStatus());
		
		LOGGER.info("Task in process Authorization Reversal :::: End");
		return bean;
	
	
	}

	public void setCreditCardService(CreditCardService creditCardService) {
		this.creditCardService = creditCardService;
	}
	
}
