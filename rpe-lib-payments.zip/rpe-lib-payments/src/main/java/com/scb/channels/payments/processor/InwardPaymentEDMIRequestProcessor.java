package com.scb.channels.payments.processor;

import java.math.BigDecimal;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.v5.customer.ContactDetails2;
import com.sc.corebanking.v5.customer.Customer;
import com.sc.corebanking.v5.customer.CustomerInfo;
import com.sc.corebanking.v5.customer.GetCustomerContactDetails;
import com.sc.corebanking.v5.customer.GetCustomerContactDetailsReqPayload;
import com.sc.corebanking.v5.customer.GetCustomerContactDetailsResPayload;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerContactDetailsReq;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerContactDetailsRes;
import com.sc.scbml_1.DomainName;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.MessageSender;
import com.sc.scbml_1.MessageSenderType;
import com.sc.scbml_1.MessageType;
import com.sc.scbml_1.OriginationDetailsType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.ProcessType;
import com.sc.scbml_1.SCBMLHeaderType;
import com.sc.scbml_1.SenderDomainType;
import com.sc.scbml_1.SubDomainName;
import com.sc.scbml_1.SubType;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;

public class InwardPaymentEDMIRequestProcessor {

	private static final Logger logger = LoggerFactory.getLogger(InwardPaymentEDMIRequestProcessor.class);
	
	public static GetCustomerContactDetailsReq process(InwardPaymentRequestVO inwardPaymentRequestVO) throws DatatypeConfigurationException{
		
		GetCustomerContactDetailsReq contactDetailsReq = new GetCustomerContactDetailsReq();
		SCBMLHeaderType headerType = new SCBMLHeaderType();
		headerType.setCaptureSystem("eBBS");
		MessageDetailsType messageDetailsType = new MessageDetailsType();
		messageDetailsType.setMessageVersion(new BigDecimal("4.0"));
		MessageType messageType = new MessageType();
		SubType subType = new SubType();
		subType.setSubTypeName("getCustomerContactDetails");
		messageType.setSubType(subType);
		messageType.setTypeName("CoreBanking:Customer");
		messageDetailsType.setMessageType(messageType);
		OriginationDetailsType originationDetailsType = new OriginationDetailsType();
		originationDetailsType.setPossibleDuplicate(true);
		originationDetailsType.setTrackingId("Track10002");
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(DateUtils.getCurrentDate());
		XMLGregorianCalendar date = null;
		try {
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			logger.info("Calender::: "+date);
			originationDetailsType.setInitiatedTimestamp(date);
			originationDetailsType.setMessageTimestamp(date);
		} catch (DatatypeConfigurationException e) {
		}
		MessageSender messageSender = new MessageSender();
		messageSender.setValue("IBNK");
		MessageSenderType messageSenderType = new MessageSenderType();
		messageSenderType.setCountryCode("SG");
		SenderDomainType senderDomainType = new SenderDomainType();
		DomainName domainName = new DomainName();
		domainName.setValue("CoreBanking");
		senderDomainType.setDomainName(domainName);
		SubDomainName subDomainName = new SubDomainName();
		subDomainName.setSubDomainType("IBNK");
		senderDomainType.setSubDomainName(subDomainName);
		
		messageSenderType.setMessageSender(messageSender);
		messageSenderType.setSenderDomain(senderDomainType);
		
		originationDetailsType.setMessageSender(messageSenderType);
		headerType.setOriginationDetails(originationDetailsType);
		headerType.setMessageDetails(messageDetailsType);
		
		ProcessType processType = new ProcessType();
		processType.setEventType("Enquiry");
		processType.setProcessName("CustomerContactEnquiry");
		headerType.setProcess(processType);
		
		contactDetailsReq.setHeader(headerType);
		GetCustomerContactDetailsReqPayload customerContactDetailsReqPayload = new GetCustomerContactDetailsReqPayload();
		GetCustomerContactDetails customerContactDetails = new GetCustomerContactDetails();
		logger.info("InwardPaymentEDMIRequestProcessor relID"+inwardPaymentRequestVO.getRelId());
		customerContactDetails.setCustomerIdentificationNumber(inwardPaymentRequestVO.getRelId());
		customerContactDetailsReqPayload.setGetCustomerContactDetailsReq(customerContactDetails);
		customerContactDetailsReqPayload.setPayloadFormat(PayloadFormatEnum.CSV);
		contactDetailsReq.setGetCustomerContactDetailsReqPayload(customerContactDetailsReqPayload);
		
		return contactDetailsReq;
	}
	
	public InwardPaymentResponseVO process1(Object obj){
		logger.info("InwardPaymentEDMIRequestProcessor :::::"+obj);
		InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
		
		if(obj instanceof GetCustomerContactDetailsRes){
			logger.info("InwardPaymentEDMIRequestProcessor if condition:::");
			GetCustomerContactDetailsRes contactDetailsRes = (GetCustomerContactDetailsRes)obj;
			GetCustomerContactDetailsResPayload contactDetailsResPayload =  contactDetailsRes.getGetCustomerContactDetailsResPayload();
			if(contactDetailsResPayload != null){
				logger.info("InwardPaymentEDMIRequestProcessor contactDetailsResPayload:::"+contactDetailsResPayload.getGetCustomerContactDetailsRes());
				Customer customer =   contactDetailsResPayload.getGetCustomerContactDetailsRes();
				logger.info("InwardPaymentEDMIRequestProcessor customer:::"+customer);
				if(customer != null){
					CustomerInfo customerInfo = customer.getCustomerInfo();
					List<ContactDetails2> contactDetails = customerInfo.getContactDetails();
					
					for(ContactDetails2 contactDetails2: contactDetails){
						logger.info("InwardPaymentEDMIRequestProcessor if contactDetails2:::");
						if(contactDetails2.getContactTypeClassification().equals("M")){
							logger.info("InwardPaymentEDMIRequestProcessor getContactTypeClassification:::");
							logger.info("My Telephone number::: "+contactDetails2.getContactTelephoneNumber().getValue());
							inwardPaymentResponseVO.setReferenceNumber(contactDetails2.getContactTelephoneNumber().getValue());
						}
						
					}
					
				} else {
					logger.info("InwardPaymentEDMIRequestProcessor else condition:::");
					if(contactDetailsRes.getHeader().getExceptions()!=null){
						List<ExceptionType> exceptionTypes = contactDetailsRes.getHeader().getExceptions().getException();
						for(ExceptionType exceptionType : exceptionTypes){
							logger.info("Exception Code:::: "+exceptionType.getCode());
							logger.info("Exception Description:::: "+exceptionType.getDescription());
						}
					}
				}

			} 
		}
		
		inwardPaymentResponseVO.setStatus("S123");
		inwardPaymentResponseVO.setStatusDesc("Sucess");
		
		return inwardPaymentResponseVO;
	}
}
