/**
 * 
 */
package com.scb.channels.payments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PayeeManagementService;

/**
 * The Class BillerPayProcessor.
 *
 * @author 1460693
 */
public class AddBillerProcessor extends AbstractProcessor {
	
	public static final String BILLER_ADDED = "Biller Added";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AddBillerProcessor.class);
	
	private PayeeManagementService payeeService;
	
	
	
	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/** The payment transaction service. */
		/* (non-Javadoc)
	 * @see com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang.Object)
	 */
 
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {

		BillerPayRequestVO billerPayRequestVO = null;
 		BillerPayResponseVO billerPayResponseVO = null;
		try {
			
			billerPayRequestVO=(BillerPayRequestVO) bean.getRequestVO();
			//billerPayResponseVO = payeeService.addBiller(billerPayRequestVO);
			
			if(billerPayResponseVO==null){
				
				billerPayResponseVO=  new BillerPayResponseVO();
				
				billerPayResponseVO.setErrorDesc(billerPayResponseVO.getStatusDesc());
				billerPayResponseVO.setErrorCD(ExceptionMessages._144.getCode());
			}else{
				billerPayResponseVO.setStatus(Messages._304.getCode());
				billerPayResponseVO.setStatusDesc(Messages._304.getMessage());
			}
			billerPayResponseVO.setUser(billerPayRequestVO.getUser());
			billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
			billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
			billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
			
			bean.setResponseVO(billerPayResponseVO);
		}catch (Exception e) { 
			
			
		} finally{ 
			
			
			
		}
		return bean;
	
	}

	 

}
