package com.scb.channels.qrpayments.service.impl;

import iso.std.iso._20022.tech.xsd.cain_001_001.Acquirer6;
import iso.std.iso._20022.tech.xsd.cain_001_001.AcquirerAuthorisationInitiation1;
import iso.std.iso._20022.tech.xsd.cain_001_001.Algorithm13Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.Algorithm15Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.Algorithm7Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.AlgorithmIdentification11;
import iso.std.iso._20022.tech.xsd.cain_001_001.AlgorithmIdentification13;
import iso.std.iso._20022.tech.xsd.cain_001_001.AlgorithmIdentification14;
import iso.std.iso._20022.tech.xsd.cain_001_001.AttributeType1Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.AuthenticationMethod5Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionAmount1;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionDetail1;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardTransactionEnvironment1;
import iso.std.iso._20022.tech.xsd.cain_001_001.Cardholder9;
import iso.std.iso._20022.tech.xsd.cain_001_001.CardholderAuthentication7;
import iso.std.iso._20022.tech.xsd.cain_001_001.CertificateIssuer1;
import iso.std.iso._20022.tech.xsd.cain_001_001.ContentInformationType10;
import iso.std.iso._20022.tech.xsd.cain_001_001.ContentType2Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.CurrencyAndAmount;
import iso.std.iso._20022.tech.xsd.cain_001_001.DetailedAmount10;
import iso.std.iso._20022.tech.xsd.cain_001_001.DetailedAmount8;
import iso.std.iso._20022.tech.xsd.cain_001_001.EncryptedContent3;
import iso.std.iso._20022.tech.xsd.cain_001_001.EnvelopedData4;
import iso.std.iso._20022.tech.xsd.cain_001_001.GenericIdentification32;
import iso.std.iso._20022.tech.xsd.cain_001_001.IssuerAndSerialNumber1;
import iso.std.iso._20022.tech.xsd.cain_001_001.KEK4;
import iso.std.iso._20022.tech.xsd.cain_001_001.KEKIdentifier2;
import iso.std.iso._20022.tech.xsd.cain_001_001.KeyTransport4;
import iso.std.iso._20022.tech.xsd.cain_001_001.OnLinePIN4;
import iso.std.iso._20022.tech.xsd.cain_001_001.Organisation18;
import iso.std.iso._20022.tech.xsd.cain_001_001.PINFormat3Code;
import iso.std.iso._20022.tech.xsd.cain_001_001.PaymentCard12;
import iso.std.iso._20022.tech.xsd.cain_001_001.PlainCardData10;
import iso.std.iso._20022.tech.xsd.cain_001_001.Recipient4Choice;
import iso.std.iso._20022.tech.xsd.cain_001_001.Recipient5Choice;
import iso.std.iso._20022.tech.xsd.cain_001_001.RelativeDistinguishedName1;
import iso.std.iso._20022.tech.xsd.cain_001_001.TrackData1;
import iso.std.iso._20022.tech.xsd.cain_005_001.CardTransaction7;
import iso.std.iso._20022.tech.xsd.cain_005_001.CardTransactionAmount5;
import iso.std.iso._20022.tech.xsd.cain_005_001.CardTransactionDetail5;
import iso.std.iso._20022.tech.xsd.cain_005_001.CardTransactionEnvironment3;
import iso.std.iso._20022.tech.xsd.cain_005_001.MessageReason1Code;
import iso.std.iso._20022.tech.xsd.cain_005_001.Organisation19;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import card.std.xsd.v2.supp.SupplementaryType;

import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.CreditCardAuthorizationPortType;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq;
import com.sc.corebanking.cards.v1.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.MessageDetailsType;
import com.sc.scbml_1.PayloadFormatEnum;
import com.sc.scbml_1.SubDomainName;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.QRCardAuthConstant;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.AlipayMappingHelper;
import com.scb.channels.mapper.helper.CreditCardMappingHelper;
import com.scb.channels.qrpayments.service.QRCreditCardService;
import com.scb.channels.qrpayments.service.QRPaymentCommonService;

public class QRCreditCardServiceImpl implements QRCreditCardService{

	private static final Logger LOGGER = LoggerFactory.getLogger(QRCreditCardServiceImpl.class);

	private CreditCardAuthorizationPortType qrCreditCardServiceClient;
	private com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.CreditCardAuthorizationPortType qrCreditCardServiceV2Client;

	private DataBean dataBean;
	private ReferenceService referenceService;
	private QRPaymentCommonService qrPaymentCommonService;
	
	@Override
	public QRPaymentResponseVO authorizeCreditCard(QRPaymentRequestVO qrPaymentRequest) {

		QRPaymentResponseVO qrPaymentResponseVO = null;
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequest.getQrPaymentDetailVO();
		try{
			LOGGER.info("Card Authorization request : from {} for {} in {} as {}",
					new Object[] { qrPaymentRequest.getUser().getCountry(),
					qrPaymentRequest.getUser().getCustomerId(),
					qrPaymentRequest.getUser().getChannelId(),
					qrPaymentRequest.getMessageVO().getRequestCode() });

			//qrPaymentDetailVO.setChannel("IBK");
			LOGGER.info("Card Authorization request for :::: "+qrPaymentDetailVO.getClient_reference());
			AuthorizeCardPurchaseTransactionReq authorizeCardRequest = CreditCardMappingHelper.getQRCardAuthorizationRequest(qrPaymentDetailVO);
			if(authorizeCardRequest != null) {
				authorizeCardRequest.setHeader(AlipayMappingHelper.populateHeader(
						qrPaymentRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						qrPaymentDetailVO.getClient_reference(), 
						CommonConstants.CCMS, CommonConstants.CARD_AUTHORIZATION_TRANSACTION,
						CommonConstants.POST_SINGLE_LEG,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
			}

			qrPaymentDetailVO.setHost_system(CommonConstants.CCMS + " - " + CommonConstants.CARD_AUTHORIZE);				
			AcquirerAuthorisationInitiation1 authstnInitn = authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn();
			CardTransactionEnvironment1 envt = authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt();
			Organisation18 accptr = envt.getAccptr();
			GenericIdentification32 id = new GenericIdentification32();
			ContentInformationType10 prtctdCardData = new ContentInformationType10();
			PaymentCard12 card = authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getEnvt().getCard();
			EnvelopedData4 envlpdData =  new EnvelopedData4();
			List<Recipient4Choice> rcpt = new ArrayList<Recipient4Choice>();
			List<CardholderAuthentication7> authntcn = new ArrayList<CardholderAuthentication7>();
			Recipient4Choice recipient4Choice = new Recipient4Choice();
			KeyTransport4 keyTrnsprt = new KeyTransport4();
			Recipient5Choice rcptId =  new Recipient5Choice();
			KEKIdentifier2 keyIdr = new KEKIdentifier2();
			AlgorithmIdentification11 keyNcrptnAlgo = new AlgorithmIdentification11();
			KEK4 kek = new KEK4();
			EncryptedContent3 ncrptdCntt =  new EncryptedContent3();
			AlgorithmIdentification13 keyNcrptnAlgo13 = new AlgorithmIdentification13();
			AlgorithmIdentification14 cnttNcrptnAlgo = new AlgorithmIdentification14();	
			Cardholder9 crdhldr = new Cardholder9();
			CardholderAuthentication7 cardholderAuthentication7 = new CardholderAuthentication7();
			OnLinePIN4 crdhldrOnLinePIN = new OnLinePIN4();

			keyIdr.setKeyId(QRCardAuthConstant.Default);
			keyIdr.setKeyVrsn(QRCardAuthConstant.Default);
			rcptId.setKeyIdr(keyIdr);
			kek.setKEKId(keyIdr);

			keyTrnsprt.setRcptId(rcptId);

			recipient4Choice.setKEK(kek);
			recipient4Choice.setKeyTrnsprt(keyTrnsprt);
			rcpt.add(recipient4Choice);
			envlpdData.getRcpt().addAll(0, rcpt);

			keyNcrptnAlgo13.setAlgo(Algorithm13Code.EA_2_C);
			kek.setKeyNcrptnAlgo(keyNcrptnAlgo13);
			keyNcrptnAlgo.setAlgo(Algorithm7Code.ERSA);
			keyTrnsprt.setKeyNcrptnAlgo(keyNcrptnAlgo);

			cnttNcrptnAlgo.setAlgo(Algorithm15Code.EA_2_C);
			ncrptdCntt.setCnttTp(ContentType2Code.AUTH);
			ncrptdCntt.setCnttNcrptnAlgo(cnttNcrptnAlgo);
			envlpdData.setNcrptdCntt(ncrptdCntt);

			prtctdCardData.setEnvlpdData(envlpdData);
			card.setPrtctdCardData(prtctdCardData);

			crdhldrOnLinePIN.setPINFrmt(PINFormat3Code.ISO_0);
			cardholderAuthentication7.setAuthntcnMtd(AuthenticationMethod5Code.TOKP);
			cardholderAuthentication7.setCrdhldrOnLinePIN(crdhldrOnLinePIN);
			authntcn.add(cardholderAuthentication7);
			crdhldr.getAuthntcn().addAll(0, authntcn);

			envt.setCard(card);
			envt.setCrdhldr(crdhldr);

			String merchantId = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type();

			id.setId(dataBean.map.get(merchantId+"_MERCHID"));
			LOGGER.info("QR Merchant Id for CCMS ::::: "+id);
			if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
				accptr.setSchmeData("V");
			}else{
				accptr.setSchmeData("M");
			}

			accptr.setId(id);
			envt.setAccptr(accptr);
			authstnInitn.setEnvt(envt);

			authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionInfo().getCain00100101().getDocument().getAcqrrAuthstnInitn().setAuthstnInitn(authstnInitn);

			AuthorizeCardPurchaseTransactionRes authorizeCardResponse = qrCreditCardServiceClient.authorizeCardPurchaseTransaction(authorizeCardRequest);
			if (authorizeCardResponse.getHeader().getExceptions() != null) {
				qrPaymentResponseVO = new QRPaymentResponseVO();

				// Check if there is any exception from CCMS response
				for (ExceptionType exceptionType : authorizeCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in credit card authorize response ::: "+qrPaymentDetailVO.getClient_reference());
					LOGGER.info("Exceptions code in credit card authorize ::: ",exceptionType.getCode().getValue());
					LOGGER.info("Exceptions description in card authorize ::: ",exceptionType.getDescription());
					qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
					qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);

					qrPaymentResponseVO.setStatusDesc(exceptionType.getDescription());
					qrPaymentResponseVO.setStatus(exceptionType.getCode().getValue());

					qrPaymentDetailVO.setHostResponseCode(exceptionType.getCode().getValue());
					qrPaymentDetailVO.setHostResponseDesc(exceptionType.getDescription());

					break;
				} 
				//MOCK
				/*qrPaymentDetailVO.setHostResponseCode("00000");
				qrPaymentDetailVO.setHostResponseDesc("SUCCESS");
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);*/
			} else {
				qrPaymentResponseVO = CreditCardMappingHelper.getQRCardAuthorizationResponse(authorizeCardResponse);
				LOGGER.info("Got  Credit CardAuth response ::: "+qrPaymentDetailVO.getClient_reference());
				String status = null;
				String description = null;
				if(qrPaymentResponseVO != null && (qrPaymentResponseVO.getStatus() != null || qrPaymentResponseVO.getStatusDesc() != null)) {

					status = qrPaymentResponseVO.getStatus();
					description = qrPaymentResponseVO.getStatusDesc();

					if(status != null && status.equals("00000")) {
						LOGGER.info("QR Credit card authentication success ::: ");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);
						description = CommonConstants.SUCCESS;
						qrPaymentDetailVO.setAuth_code(qrPaymentResponseVO.getQrPaymentDetailVO().getAuth_code());
					} else {
						LOGGER.info("QR Credit card authentication failure ::: ");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
						status = CommonConstants.FAILURE;
					}
					qrPaymentDetailVO.setHostResponseCode(status);
					qrPaymentDetailVO.setHostResponseDesc(description);
				}

				LOGGER.info("QR Card Authorization Response for request id:{}, :: {} :: {}", 
						new Object[] {qrPaymentRequest.getMessageVO().getRequestCode(), 
						qrPaymentDetailVO.getHostResponseCode(),
						qrPaymentDetailVO.getHostResponseDesc()});
			}
		}catch(Exception e){
			LOGGER.error("Error Inside QRCreditCardServiceImpl authorizeCreditCard :::",e);
			LOGGER.info("Inside Exception Block QRCreditCardServiceImpl  :::",e+" ::"+qrPaymentDetailVO.getClient_reference());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);

			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.NEGATIVE);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());

			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO();
				/**Added this from finally loop*/
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			}

		}finally {
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		}
		LOGGER.info("CreditCardServiceImpl ::: authorizeCreditCard ::: Status ::"+qrPaymentRequest.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("QRCreditCardServiceImpl authorizeCreditCard End::: "+qrPaymentDetailVO.getClient_reference());
		return qrPaymentResponseVO;
	}

	@Override
	public QRPaymentResponseVO reverseCardAuthorization(QRPaymentRequestVO qrPaymentRequest) {

		LOGGER.info("QRCreditCardServiceImpl ::: reverseCardAuthorization ::: start");
		QRPaymentResponseVO qrPaymentResponseVO = new QRPaymentResponseVO();;
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequest.getQrPaymentDetailVO();

		try {
			LOGGER.info("QR Card Authorization reversal request : from {} for {} in {} as {}",
					new Object[] { qrPaymentRequest.getUser().getCountry(),
					qrPaymentRequest.getUser().getCustomerId(),
					qrPaymentRequest.getUser().getChannelId(),
					qrPaymentRequest.getMessageVO().getRequestCode() });

			ReverseCardPurchaseTransactionReq reverseAuthorizeCardRequest = CreditCardMappingHelper.getQRReverseCardAuthorizationRequest(qrPaymentDetailVO);
			LOGGER.info("QRCreditCardServiceImpl ::: reverseCardAuthorization ::: start ::"+qrPaymentDetailVO.getClient_reference());

			if(reverseAuthorizeCardRequest != null) {
				reverseAuthorizeCardRequest.setHeader(AlipayMappingHelper.populateHeader(
						qrPaymentRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						qrPaymentRequest.getQrPaymentDetailVO().getClient_reference(), 
						CommonConstants.CCMS, CommonConstants.CARD_AUTHORIZATION_REVERSAL_TRANSACTION,
						CommonConstants.CARD_AUTH_REVERSE_EVENT_TYPE,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
			}
			CardTransactionEnvironment3 envt = reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionInfo().getCain00500101().getDocument().getAcqrrRvslInitn().getRvslInitn().getEnvt();
			Organisation19 accptr = new Organisation19();
			iso.std.iso._20022.tech.xsd.cain_005_001.GenericIdentification32 id = new iso.std.iso._20022.tech.xsd.cain_005_001.GenericIdentification32();

			String merchantId = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type();
			id.setId(dataBean.map.get(merchantId+"_MERCHID"));
			accptr.setId(id);
			envt.setAccptr(accptr);
			qrPaymentDetailVO.setHost_system(CommonConstants.CCMS + " - " + CommonConstants.CARD_AUTHORIZE_REVERSE);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().setPayloadFormat(PayloadFormatEnum.XML);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().setPayloadVersion(CommonConstants.ALIPAY_PAYLOAD_VERSION);

			ReverseCardPurchaseTransactionRes reverseAuthorizeCardResponse = qrCreditCardServiceClient.	reverseCardPurchaseTransaction(reverseAuthorizeCardRequest);

			if (reverseAuthorizeCardResponse.getHeader().getExceptions() != null) {

				// Check if there is any exception from Hogan response
				for (ExceptionType exceptionType : reverseAuthorizeCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in qr card authorize reversal response ::: " 
							+	qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
					LOGGER.info("Exceptions code in qr card authorize reversal ::: " 
							+ exceptionType.getCode().getValue() 
							+ " ::: " +	qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
					LOGGER.info("Exceptions description in qr card authorize reversal ::: " 
							+	exceptionType.getDescription()
							+ " ::: " +	qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());

					qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
					qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);

					qrPaymentResponseVO.setStatusDesc(exceptionType.getDescription());
					qrPaymentResponseVO.setStatus(exceptionType.getCode().getValue());

					qrPaymentDetailVO.setHostResponseCode(exceptionType.getCode().getValue());
					qrPaymentDetailVO.setHostResponseDesc(exceptionType.getDescription());

					break;
				} 
				//MOCK
				/*qrPaymentDetailVO.setHostResponseCode("00000");
				qrPaymentDetailVO.setHostResponseDesc("SUCCESS");
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);*/
			} else {
				qrPaymentResponseVO = CreditCardMappingHelper.getQRReverseCardAuthorizationResponse(reverseAuthorizeCardResponse);
				LOGGER.info("Got response from Credit Card reversal response ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());

				String status = null;
				String description = null;
				if(qrPaymentResponseVO != null && (qrPaymentResponseVO.getStatus() != null || qrPaymentResponseVO.getStatusDesc() != null)) {

					status = qrPaymentResponseVO.getStatus();
					description = qrPaymentResponseVO.getStatusDesc();

					if(status != null && status.equals("00000")) {
						LOGGER.info("Credit card reverse authentication success ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);
						//qrPaymentDetailVO.setPayment_status(CommonConstants.CARD_AUTH_REV_SUCCESS);
						description = CommonConstants.SUCCESS;
					} else {
						LOGGER.info("Credit card reverse authentication failure ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
						//qrPaymentDetailVO.setPayment_status(CommonConstants.CARD_AUTH_REV_FAILURE);
						status = CommonConstants.FAILURE;
					}
					qrPaymentDetailVO.setHostResponseCode(status);
					qrPaymentDetailVO.setHostResponseDesc(description);
				}
			}				
		} catch (Exception e) {
			LOGGER.error("Error Inside QRCreditCardServiceImpl reverseCardAuthorization :::",e);
			LOGGER.info("Inside Exception Block QRCreditCardServiceImpl reverseCardAuthorization :::",e+" ::"+qrPaymentDetailVO.getClient_reference());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);

			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.NEGATIVE);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());

			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO();
				/**Added this from finally loop*/
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			}

		} finally {
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		}
		LOGGER.info("CreditCardServiceImpl ::: reverseAuthorizeCreditCard ::: Status ::"+qrPaymentRequest.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("CreditCardServiceImpl ::: reverseAuthorizeCreditCard ::: End ::"+qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
		return qrPaymentResponseVO;

	}

	public CreditCardAuthorizationPortType getQrCreditCardServiceClient() {
		return qrCreditCardServiceClient;
	}

	public void setQrCreditCardServiceClient(
			CreditCardAuthorizationPortType qrCreditCardServiceClient) {
		this.qrCreditCardServiceClient = qrCreditCardServiceClient;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	@Override
	public QRPaymentResponseVO authorizeCreditCardV2(QRPaymentRequestVO qrPaymentRequest) {

		QRPaymentResponseVO qrPaymentResponseVO = null;
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequest.getQrPaymentDetailVO();
		List<ISOCODESVO> isocodesvos=null;
		ISOCODESVO isoCodes = null;
		int precisionAmt=1;
		try{
			LOGGER.info("Card Authorization V2 request : from {} for {} in {} as {}",
					new Object[] { qrPaymentRequest.getUser().getCountry(),
					qrPaymentRequest.getUser().getCustomerId(),
					qrPaymentRequest.getUser().getChannelId(),
					qrPaymentRequest.getMessageVO().getRequestCode() });

			//qrPaymentDetailVO.setChannel("IBK");
			LOGGER.info("Card Authorization V2 request for :::: "+qrPaymentDetailVO.getClient_reference());
			com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq authorizeCardRequest = CreditCardMappingHelper.getQRCardAuthorizationV2Request(qrPaymentDetailVO);
			if(authorizeCardRequest != null) {
				authorizeCardRequest.setHeader(AlipayMappingHelper.populateHeader(
						qrPaymentRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						qrPaymentDetailVO.getClient_reference(), 
						CommonConstants.C400, CommonConstants.CARD_AUTHORIZATION_TRANSACTION,
						CommonConstants.CARD_AUTHORIZATION_TRANSACTION,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
				//Message Version 2.0
				MessageDetailsType messageDetails = authorizeCardRequest.getHeader().getMessageDetails();
				messageDetails.setMessageVersion(new BigDecimal(CommonConstants.TWO_DECIMAL));
				// override sub-domain type value
				SubDomainName subDomainName = authorizeCardRequest.getHeader().getOriginationDetails().getMessageSender().getSenderDomain().getSubDomainName();
				subDomainName.setSubDomainType(CommonConstants.CREDIT_CARD);
			}

			qrPaymentDetailVO.setHost_system(CommonConstants.C400 + " - " + CommonConstants.CARD_AUTHORIZE);				
			AcquirerAuthorisationInitiation1 authstnInitn = authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn();
			CardTransactionEnvironment1 envt = authstnInitn.getEnvt();
			Organisation18 accptr = envt.getAccptr();
			GenericIdentification32 id = new GenericIdentification32();
			PlainCardData10 plainCardData = envt.getCard().getPlainCardData();

			TrackData1 td1=new TrackData1();
			td1.setTrckNb(QRCardAuthConstant.TWO);
			td1.setTrckVal(QRCardAuthConstant.Default);			

			plainCardData.getTrckData().add(td1);
			envt.getCard().setPlainCardData(plainCardData);

			Cardholder9 crdhldr = new Cardholder9();
			List<CardholderAuthentication7> authntcn = new ArrayList<CardholderAuthentication7>();				
			CardholderAuthentication7 cardholderAuthentication7 = new CardholderAuthentication7();
			OnLinePIN4 crdhldrOnLinePIN = new OnLinePIN4();		
			ContentInformationType10 prtctdCardData = new ContentInformationType10();
			EnvelopedData4 envlpdData =  new EnvelopedData4();
			EncryptedContent3 ncrptdCntt =  new EncryptedContent3();
			AlgorithmIdentification14 cnttNcrptnAlgo = new AlgorithmIdentification14();	
			Recipient4Choice rcpt =  new Recipient4Choice();
			KEKIdentifier2 keyIdr = new KEKIdentifier2();
			KeyTransport4 keyTrnsprt=new KeyTransport4();
			Recipient5Choice rcptId =  new Recipient5Choice();
			IssuerAndSerialNumber1 issrAndSrlNb=new IssuerAndSerialNumber1();
			CertificateIssuer1 issr=new CertificateIssuer1();
			RelativeDistinguishedName1 rltvDstngshdNm=new RelativeDistinguishedName1();
			AlgorithmIdentification11 keyNcrptnAlgo=new AlgorithmIdentification11();
			KEK4 kek=new KEK4();
			AlgorithmIdentification13 keyNcrptnAlgoKek=new AlgorithmIdentification13();

			cnttNcrptnAlgo.setAlgo(Algorithm15Code.EA_2_C);
			ncrptdCntt.setCnttNcrptnAlgo(cnttNcrptnAlgo);
			ncrptdCntt.setCnttTp(ContentType2Code.AUTH);
			ncrptdCntt.setNcrptdData(QRCardAuthConstant.ZERO_BYTE);							
			envlpdData.setNcrptdCntt(ncrptdCntt);

			keyIdr.setKeyId(QRCardAuthConstant.Default);
			keyIdr.setKeyVrsn(QRCardAuthConstant.Default);
			rcpt.setKeyIdr(keyIdr);

			rltvDstngshdNm.setAttrTp(AttributeType1Code.CNAT);
			rltvDstngshdNm.setAttrVal(QRCardAuthConstant.Default);
			issr.getRltvDstngshdNm().add(rltvDstngshdNm);
			issrAndSrlNb.setIssr(issr);
			issrAndSrlNb.setSrlNb(QRCardAuthConstant.ZERO_BYTE);

			rcptId.setIssrAndSrlNb(issrAndSrlNb);
			rcptId.setKeyIdr(keyIdr);
			keyTrnsprt.setRcptId(rcptId);

			keyNcrptnAlgo.setAlgo(Algorithm7Code.ERSA);
			keyTrnsprt.setKeyNcrptnAlgo(keyNcrptnAlgo);
			keyTrnsprt.setNcrptdKey(QRCardAuthConstant.ZERO_BYTE);			
			rcpt.setKeyTrnsprt(keyTrnsprt);			

			kek.setKEKId(keyIdr);			
			keyNcrptnAlgoKek.setAlgo(Algorithm13Code.EA_2_C);
			kek.setKeyNcrptnAlgo(keyNcrptnAlgoKek);			
			kek.setNcrptdKey(QRCardAuthConstant.ZERO_BYTE);			
			rcpt.setKEK(kek);

			envlpdData.getRcpt().add(rcpt);

			prtctdCardData.setCnttTp(ContentType2Code.AUTH);
			prtctdCardData.setEnvlpdData(envlpdData);			

			crdhldrOnLinePIN.setPINFrmt(PINFormat3Code.ISO_0);
			crdhldrOnLinePIN.setNcrptdPINBlck(prtctdCardData);	

			cardholderAuthentication7.setAuthntcnMtd(AuthenticationMethod5Code.TOKP);
			cardholderAuthentication7.setCrdhldrOnLinePIN(crdhldrOnLinePIN);
			authntcn.add(cardholderAuthentication7);
			crdhldr.getAuthntcn().addAll(0, authntcn);
			envt.setCrdhldr(crdhldr);			

			String merchantId = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type();

			id.setId(dataBean.map.get(merchantId+CommonConstants.UNDERSCORE+CommonConstants.MERCHID));
			LOGGER.info("QR Merchant Id for C400 ::::: "+id);
			if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
				accptr.setSchmeData(CommonConstants.VISA_INDR);
			}else{
				accptr.setSchmeData(CommonConstants.MASTER_INDR);
			}

			accptr.setId(id);
			accptr.setCmonNm(qrPaymentCommonService.buildCardAcceptorName(qrPaymentDetailVO));
			
			envt.setAccptr(accptr);			

			Acquirer6 acquirer6=envt.getAcqrr();
			acquirer6.setId(CommonConstants.ELEVEN_ZEROES);
			envt.setAcqrr(acquirer6);

			authstnInitn.setEnvt(envt);

			authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().setAuthstnInitn(authstnInitn);

			CardTransactionDetail1 txDtls = authstnInitn.getTx().getTxDtls();

			CardTransactionAmount1 txAmts = new CardTransactionAmount1();
			CurrencyAndAmount ttlAmt=new CurrencyAndAmount();
			if(qrPaymentDetailVO.getTransactionCurrency()!=null){
				ttlAmt.setCcy(qrPaymentDetailVO.getTransactionCurrency());
				BigDecimal totalPaymentAmt = qrPaymentDetailVO.getTotalPaymentAmt();
				isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getTransactionCurrency());
				if(isocodesvos != null && isocodesvos.size()>0){
					isoCodes=isocodesvos.get(0);
					if(isoCodes!=null && totalPaymentAmt!=null){
						precisionAmt=isoCodes.getCurrency_precision();
						totalPaymentAmt=totalPaymentAmt.multiply(new BigDecimal(precisionAmt));
						ttlAmt.setValue(totalPaymentAmt.setScale(0,BigDecimal.ROUND_UP));
					}				
				}
				txAmts.setTtlAmt(ttlAmt);
			}			

			if(qrPaymentDetailVO.isCrossCurrency()){

				DetailedAmount8 crdhldrBllgTxAmt = new DetailedAmount8();
				if(qrPaymentDetailVO.getDebitAccCurrency()!=null){
					BigDecimal debitAmt = qrPaymentDetailVO.getDebitAmount();
					isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getDebitAccCurrency());
					if(isocodesvos != null && isocodesvos.size()>0){
						isoCodes=isocodesvos.get(0);
						if(isoCodes!=null && debitAmt!=null){
							precisionAmt=isoCodes.getCurrency_precision();
							debitAmt=debitAmt.multiply(new BigDecimal(precisionAmt));
							crdhldrBllgTxAmt.setAmt(debitAmt.setScale(0,BigDecimal.ROUND_UP));
							
							BigDecimal dbtFXRateAmt=qrPaymentDetailVO.getDebitAmtFxRate();
							if(dbtFXRateAmt!=null){
								String fxAmtStr = dbtFXRateAmt.toString();
								if(fxAmtStr!=CommonConstants.EMPTY && fxAmtStr!=null && fxAmtStr.length()>8){
									fxAmtStr=fxAmtStr.substring(0, 8);
									dbtFXRateAmt=new BigDecimal(fxAmtStr);
								}
							}
							//crdhldrBllgTxAmt.setXchgRate(dbtFXRateAmt);
						}				
					}
					txAmts.setCrdhldrBllgTxAmt(crdhldrBllgTxAmt);
				}

				DetailedAmount10 da10 = new DetailedAmount10();
				CurrencyAndAmount amt = new CurrencyAndAmount();			
				if(qrPaymentDetailVO.getSettlementCurrency()!=null){
					amt.setCcy(qrPaymentDetailVO.getSettlementCurrency());			
					BigDecimal setleAmount = qrPaymentDetailVO.getSettlementAmount();
					isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getSettlementCurrency());
					if(isocodesvos != null && isocodesvos.size()>0){
						isoCodes=isocodesvos.get(0);
						if(isoCodes!=null && setleAmount!=null){
							precisionAmt=isoCodes.getCurrency_precision();
							setleAmount=setleAmount.multiply(new BigDecimal(precisionAmt));
							amt.setValue(setleAmount.setScale(0,BigDecimal.ROUND_UP));
						}				
					}
					da10.setAmt(amt);
					da10.setAddtlTp(QRCardAuthConstant.SETTLEMENT_AMOUNT);
				}	
				txDtls.getAddtlAmts().add(da10);
			}
			txDtls.setTxAmts(txAmts);	

			authorizeCardRequest.getAuthorizeCardPurchaseTransactionReqPayload().getAuthorizeCardPurchaseTransactionReq().getDocument().getAcqrrAuthstnInitn().getAuthstnInitn().getTx().setTxDtls(txDtls);
/*
			String requestXML = CommonHelper.getXML(authorizeCardRequest, com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq.class, 
					com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionReq.class.getSimpleName());
			LOGGER.info(":::EDMI::Auth:::requestXML::::::"+requestXML);
*/
			com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes authorizeCardResponse = qrCreditCardServiceV2Client.authorizeCardPurchaseTransaction(authorizeCardRequest);

/*			String responseXML = CommonHelper.getXML(authorizeCardResponse, com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes.class, 
					com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.AuthorizeCardPurchaseTransactionRes.class.getSimpleName());
			LOGGER.info(":::EDMI::Auth:::responseXML::::::"+responseXML);*/

			if (authorizeCardResponse.getHeader().getExceptions() != null) {
				qrPaymentResponseVO = new QRPaymentResponseVO();

				// Check if there is any exception from CCMS response
				for (ExceptionType exceptionType : authorizeCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in credit card authorize response ::: "+qrPaymentDetailVO.getClient_reference());
					LOGGER.info("Exceptions code in credit card authorize ::: ",exceptionType.getCode().getValue());
					LOGGER.info("Exceptions description in card authorize ::: ",exceptionType.getDescription());
					qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
					qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);

					qrPaymentResponseVO.setStatusDesc(exceptionType.getDescription());
					qrPaymentResponseVO.setStatus(exceptionType.getCode().getValue());

					qrPaymentDetailVO.setHostResponseCode(exceptionType.getCode().getValue());
					qrPaymentDetailVO.setHostResponseDesc(exceptionType.getDescription());

					break;
				} 
				//MOCK
				/*qrPaymentDetailVO.setHostResponseCode("00000");
				qrPaymentDetailVO.setHostResponseDesc("SUCCESS");
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);*/
			} else {
				qrPaymentResponseVO = CreditCardMappingHelper.getQRCardAuthorizationV2Response(authorizeCardResponse);
				LOGGER.info("Got  Credit CardAuth response ::: "+qrPaymentDetailVO.getClient_reference());
				String status = null;
				String description = null;
				if(qrPaymentResponseVO != null && (qrPaymentResponseVO.getStatus() != null || qrPaymentResponseVO.getStatusDesc() != null)) {

					status = qrPaymentResponseVO.getStatus();
					description = qrPaymentResponseVO.getStatusDesc();

					if(status != null && status.equals(CommonConstants.FIVE_ZEROES)) {
						LOGGER.info("QR Credit card authentication success ::: ");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_SUCCESS);
						description = CommonConstants.SUCCESS;
						qrPaymentDetailVO.setAuth_code(qrPaymentResponseVO.getQrPaymentDetailVO().getAuth_code());
					} else {
						LOGGER.info("QR Credit card authentication failure ::: ");
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
						status = CommonConstants.FAILURE;
					}
					qrPaymentDetailVO.setHostResponseCode(status);
					qrPaymentDetailVO.setHostResponseDesc(description);
				}

				LOGGER.info("QR Card Authorization Response for request id:{}, :: {} :: {}", 
						new Object[] {qrPaymentRequest.getMessageVO().getRequestCode(), 
						qrPaymentDetailVO.getHostResponseCode(),
						qrPaymentDetailVO.getHostResponseDesc()});
			}
		}catch(Exception e){
			LOGGER.error("Error Inside QRCreditCardServiceImpl authorizeCreditCard :::",e);
			LOGGER.info("Inside Exception Block QRCreditCardServiceImpl  :::",e+" ::"+qrPaymentDetailVO.getClient_reference());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);

			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_TIMEOUT);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.NEGATIVE);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());

			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO();
				/**Added this from finally loop*/
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			}

		}finally {
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		}
		LOGGER.info("CreditCardServiceImpl ::: authorizeCreditCard ::: Status ::"+qrPaymentRequest.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("QRCreditCardServiceImpl authorizeCreditCard End::: "+qrPaymentDetailVO.getClient_reference());
		return qrPaymentResponseVO;
	}

	/* (non-Javadoc)
	 * @see com.scb.channels.qrpayments.service.QRCreditCardService#reverseCardAuthorizationV2(com.scb.channels.base.vo.QRPaymentRequestVO)
	 * 
	 */
	@Override
	public QRPaymentResponseVO reverseCardAuthorizationV2(
			QRPaymentRequestVO qrPaymentRequest) {

		LOGGER.info("QRCreditCardServiceImpl ::: reverseCardAuthorization V2 ::: start");
		QRPaymentResponseVO qrPaymentResponseVO = new QRPaymentResponseVO();;
		QRPaymentDetailVO qrPaymentDetailVO = qrPaymentRequest.getQrPaymentDetailVO();
		List<ISOCODESVO> isocodesvos=null;
		ISOCODESVO isoCodes = null;
		int precisionAmt=1;
		try {
			LOGGER.info("QR Card Authorization reversal V2 request : from {} for {} in {} as {}",
					new Object[] { qrPaymentRequest.getUser().getCountry(),
					qrPaymentRequest.getUser().getCustomerId(),
					qrPaymentRequest.getUser().getChannelId(),
					qrPaymentRequest.getMessageVO().getRequestCode() });

			com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq reverseAuthorizeCardRequest = CreditCardMappingHelper.getQRReverseCardAuthorizationV2Request(qrPaymentDetailVO);
			LOGGER.info("QRCreditCardServiceImpl ::: reverseCardAuthorization V2 ::: start ::"+qrPaymentDetailVO.getClient_reference());

			if(reverseAuthorizeCardRequest != null) {
				reverseAuthorizeCardRequest.setHeader(AlipayMappingHelper.populateHeader(
						qrPaymentRequest.getUser().getCountry(), 
						CommonConstants.I_BANKING, AlipayMappingHelper.getGregorianCalendar(),
						qrPaymentRequest.getQrPaymentDetailVO().getClient_reference(), 
						CommonConstants.C400, CommonConstants.CARD_AUTHORIZATION_REVERSAL_TRANSACTION,
						CommonConstants.CARD_AUTH_REVERSE_EVENT_TYPE,CommonConstants.CARD_AUTHENTICATION_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));
				MessageDetailsType messageDetails = reverseAuthorizeCardRequest.getHeader().getMessageDetails();
				messageDetails.setMessageVersion(new BigDecimal(CommonConstants.TWO_DECIMAL));
				// override sub-domain type value
				SubDomainName subDomainName = reverseAuthorizeCardRequest.getHeader().getOriginationDetails().getMessageSender().getSenderDomain().getSubDomainName();
				subDomainName.setSubDomainType(CommonConstants.CREDIT_CARD);
			}

			CardTransactionEnvironment3 envt = reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getEnvt();
			Organisation19 accptr = envt.getAccptr();
			if(accptr==null){
				accptr=new Organisation19();
			}
			iso.std.iso._20022.tech.xsd.cain_005_001.GenericIdentification32 id = new iso.std.iso._20022.tech.xsd.cain_005_001.GenericIdentification32();

			String merchantId = qrPaymentDetailVO.getCountryCode()+qrPaymentDetailVO.getCard_type();

			id.setId(dataBean.map.get(merchantId+CommonConstants.UNDERSCORE+CommonConstants.MERCHID));
			LOGGER.info("QR Merchant Id for C400 ::::: "+id);
			if(qrPaymentDetailVO.getCard_type().equalsIgnoreCase(CommonConstants.VISA)){
				accptr.setSchmeData(CommonConstants.VISA_INDR);
			}else{
				accptr.setSchmeData(CommonConstants.MASTER_INDR);
			}

			accptr.setId(id);
			envt.setAccptr(accptr);	
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().setEnvt(envt);

			CardTransaction7 tx = reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().getTx();
			CardTransactionDetail5 txDtls = new CardTransactionDetail5();
			CardTransactionAmount5 txAmts = new CardTransactionAmount5();
			iso.std.iso._20022.tech.xsd.cain_005_001.CurrencyAndAmount ttlAmt = new iso.std.iso._20022.tech.xsd.cain_005_001.CurrencyAndAmount();
			if(qrPaymentDetailVO.getTransactionCurrency()!=null){
				ttlAmt.setCcy(qrPaymentDetailVO.getTransactionCurrency());
				BigDecimal totalPaymentAmt = qrPaymentDetailVO.getTotalPaymentAmt();
				isocodesvos = referenceService.getPrecisionCurrency(qrPaymentDetailVO.getTransactionCurrency());
				if(isocodesvos != null && isocodesvos.size()>0){
					isoCodes=isocodesvos.get(0);
					if(isoCodes!=null && totalPaymentAmt!=null){
						precisionAmt=isoCodes.getCurrency_precision();
						totalPaymentAmt=totalPaymentAmt.multiply(new BigDecimal(precisionAmt));
						ttlAmt.setValue(totalPaymentAmt.setScale(0,BigDecimal.ROUND_UP));
					}				
				}
				txAmts.setTtlAmt(ttlAmt);
				txDtls.setTxAmts(txAmts);				
			}
			txDtls.getMsgRsn().add(MessageReason1Code.COFF);
			tx.setTxDtls(txDtls);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getDocument().getAcqrrRvslInitn().getRvslInitn().setTx(tx);

			SupplementaryType supplementaryData=reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getAuthorizationSupplementary().getSupplementaryData();
			supplementaryData.setOriginalMessageType(getOriginalMessageType(CommonConstants.QR_MTI_0100,qrPaymentDetailVO.getStan(),qrPaymentDetailVO.getPaymentDate(),QRCardAuthConstant.FIIdentificationCode,QRCardAuthConstant.FIIdentificationCode));
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().getReverseCardPurchaseTransactionReq().getAuthorizationSupplementary().setSupplementaryData(supplementaryData);

			qrPaymentDetailVO.setHost_system(CommonConstants.C400 + " - " + CommonConstants.CARD_AUTHORIZE_REVERSE);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().setPayloadFormat(PayloadFormatEnum.XML);
			reverseAuthorizeCardRequest.getReverseCardPurchaseTransactionReqPayload().setPayloadVersion(QRCardAuthConstant.PayloadVersion_V2);

		/*	String requestXML = CommonHelper.getXML(reverseAuthorizeCardRequest, com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq.class, 
					com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionReq.class.getSimpleName());
			LOGGER.info(":::EDMI::reverse:::requestXML::::::"+requestXML);
*/
			com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes reverseAuthorizeCardResponse = qrCreditCardServiceV2Client.reverseCardPurchaseTransaction(reverseAuthorizeCardRequest);

/*			String responseXML = CommonHelper.getXML(reverseAuthorizeCardResponse, com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes.class, 
					com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.ReverseCardPurchaseTransactionRes.class.getSimpleName());
			LOGGER.info(":::EDMI::reverse:::responseXML::::::"+responseXML);*/

			if (reverseAuthorizeCardResponse.getHeader().getExceptions() != null) {

				// Check if there is any exception from Hogan response
				for (ExceptionType exceptionType : reverseAuthorizeCardResponse.getHeader()
						.getExceptions().getException()) {
					LOGGER.info("Exceptions present in qr card authorize reversal response ::: " 
							+	qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
					LOGGER.info("Exceptions code in qr card authorize reversal ::: " 
							+ exceptionType.getCode().getValue() 
							+ " ::: " +	qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
					LOGGER.info("Exceptions description in qr card authorize reversal ::: " 
							+	exceptionType.getDescription()
							+ " ::: " +	qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());

					qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
					qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);

					qrPaymentResponseVO.setStatusDesc(exceptionType.getDescription());
					qrPaymentResponseVO.setStatus(exceptionType.getCode().getValue());

					qrPaymentDetailVO.setHostResponseCode(exceptionType.getCode().getValue());
					qrPaymentDetailVO.setHostResponseDesc(exceptionType.getDescription());

					break;
				} 
				//MOCK
				/*qrPaymentDetailVO.setHostResponseCode("00000");
				qrPaymentDetailVO.setHostResponseDesc("SUCCESS");
				qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);*/
			} else {
				qrPaymentResponseVO = CreditCardMappingHelper.getQRReverseCardAuthorizationV2Response(reverseAuthorizeCardResponse);
				LOGGER.info("Got response from Credit Card reversal response ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());

				String status = null;
				String description = null;
				if(qrPaymentResponseVO != null && (qrPaymentResponseVO.getStatus() != null || qrPaymentResponseVO.getStatusDesc() != null)) {

					status = qrPaymentResponseVO.getStatus();
					description = qrPaymentResponseVO.getStatusDesc();

					if(status != null && status.equals(CommonConstants.FIVE_ZEROES)) {
						LOGGER.info("Credit card reverse authentication success ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_SUCCESS);
						//qrPaymentDetailVO.setPayment_status(CommonConstants.CARD_AUTH_REV_SUCCESS);
						description = CommonConstants.SUCCESS;
					} else {
						LOGGER.info("Credit card reverse authentication failure ::: " + qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
						qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_FAILURE);
						//qrPaymentDetailVO.setPayment_status(CommonConstants.CARD_AUTH_REV_FAILURE);
						status = CommonConstants.FAILURE;
					}
					qrPaymentDetailVO.setHostResponseCode(status);
					qrPaymentDetailVO.setHostResponseDesc(description);
				}
			}				
		} catch (Exception e) {
			LOGGER.error("Error Inside QRCreditCardServiceImpl reverseCardAuthorization :::",e);
			LOGGER.info("Inside Exception Block QRCreditCardServiceImpl reverseCardAuthorization :::",e+" ::"+qrPaymentDetailVO.getClient_reference());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequest.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequest.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);

			qrPaymentDetailVO.setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentDetailVO.setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
			qrPaymentDetailVO.setHostResponseCode(CommonConstants.NEGATIVE);
			qrPaymentDetailVO.setHostResponseDesc(e.getMessage());

			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO();
				/**Added this from finally loop*/
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			}

		} finally {
			qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
		}
		LOGGER.info("CreditCardServiceImpl ::: reverseAuthorizeCreditCard ::: Status ::"+qrPaymentRequest.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("CreditCardServiceImpl ::: reverseAuthorizeCreditCard ::: End ::"+qrPaymentRequest.getQrPaymentDetailVO().getClient_reference());
		return qrPaymentResponseVO;		
	}

	public com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.CreditCardAuthorizationPortType getQrCreditCardServiceV2Client() {
		return qrCreditCardServiceV2Client;
	}

	public void setQrCreditCardServiceV2Client(
			com.sc.corebanking.creditcard.v2.ws.provider.creditcardauthorization.CreditCardAuthorizationPortType qrCreditCardServiceV2Client) {
		this.qrCreditCardServiceV2Client = qrCreditCardServiceV2Client;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}
	
	public QRPaymentCommonService getQrPaymentCommonService() {
		return qrPaymentCommonService;
	}

	public void setQrPaymentCommonService(
			QRPaymentCommonService qrPaymentCommonService) {
		this.qrPaymentCommonService = qrPaymentCommonService;
	}
	
	/**
     * Method to populate original data elements in a single field for C400 reversal
     * @param orgMsgTypId - lookup value of the Message Type Id - 4 chars
     * @param orgSTAN  - STAN sent during the authorization - 6 chars
     * @param OrgTranxDtTime - datetime sent during authorize txn - 11 chars
     * @param orgAcquiringInst - original acquiring institution - 11 chars
     * @param orgForwardingInst - original forwarding institution - 11 chars
     * @return originalMessageType of total 42 chars
     */
     public static String getOriginalMessageType(String orgMsgTypId, String orgSTAN, Timestamp paymentDate, String orgAcquiringInst, String orgForwardingInst){
       SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
       String originalMessageType=CommonConstants.EMPTY;
       try{
           String paymentDateStr = simpleDateFormat.format(paymentDate);
           originalMessageType = orgMsgTypId + orgSTAN + paymentDateStr + orgAcquiringInst + orgForwardingInst;
       }catch(Exception ex){
              LOGGER.info(":::::: error in getOriginalMessageType::::::"+ex.getMessage());
       }
       return originalMessageType;
     }

}
