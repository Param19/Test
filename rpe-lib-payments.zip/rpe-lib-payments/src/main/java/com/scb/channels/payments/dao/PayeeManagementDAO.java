package com.scb.channels.payments.dao;

import java.util.Date;
import java.util.List;

import com.scb.channels.base.vo.BillerVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayeeFieldDetailsView;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeVO;

/**
 * @author 1521723 The Interface Payee managementDAO.
 * 
 */
public interface PayeeManagementDAO {

	/***
	 * add payee.
	 * 
	 * @param billerPayDetailsVO
	 *            the biller pay details vo
	 */

	public void savePayee(PayeeDetailVO PayeeDetailsVO);

	/**
	 * @param PayeeDetailsVO
	 */
	boolean deletePayee(PayeeDetailVO PayeeDetailsVO);


	/**
	 * @param payee
	 */
	public List<PayeeDetailVO> checkIsPayeeExists(PayeeDetailVO payee);
	
	
	/**
	 * @param billerUniqueId
	 * @return
	 */
	public BillerVO getUniqueBillerId(String billerUniqueId,String cntry) ;

	/**
	 * @param userVO
	 * @return
	 */
	List<ViewPayeeVO> viewPayeeListFromView(UserVO userVO);

	/**
	 * Gets the payee.
	 *
	 * @param payeeId the payee id
	 * @return the payee
	 */
	public PayeeDetailVO getPayee(Integer payeeId);
	
	/**
	 * @param userVO
	 * @return
	 */
	List<ViewPayeeVO> viewPayeeListFromViewHK(ViewPayeeRequestVO viewPayeeReq);
	
	/**
	 * @param billerUniqueId
	 * @param countryCode
	 * @return
	 */
	public BillerVO getUniqueBillerIdHK(String billerUniqueId,String countryCode);
	

	/**
	 * @param PayeeDetailsVO
	 * @return
	 */
	public List<ViewPayeeVO> getPayeeList(PayeeDetailVO PayeeDetailsVO);

	/**
	 * @param PayeeDetailsVO
	 * @return
	 */
	boolean savePayeeHK(PayeeDetailVO PayeeDetailsVO);

	/**
	 * @param PayeeDetailsVO
	 * @return
	 */
	String updatePayeeIfExists(PayeeDetailVO PayeeDetailsVO);

	/**
	 * @param PayeeDetailsVO
	 * @return
	 */
	boolean updatePayeeStatus(PayeeDetailVO PayeeDetailsVO);
	
	/**
	 * @param countryCode
	 * @param timeIntervel
	 * @return
	 */
	boolean saveTerminateInactivePayee(String countryCode);
	
	/**
	 * @param payeeDetails
	 */
	void updatePayee(PayeeDetailVO payeeDetails);
	
	/**
	 * @param userVO
	 * @return
	 */
	List<ViewPayeeVO> getPayeeListCS(UserVO userVO,Integer payeeId);
	
	/**
	 * @param PayeeDetailsVO
	 */
	public void savePayeeCS(PayeeDetailVO PayeeDetailsVO);
	
	
	/**
	 * @param billerUniqueId
	 * @return
	 */
	public PayeeDetailVO getOneTimePayee(PayeeDetailVO payeeDetailVO) ;

	/**
	 * @param payeeDetailVO
	 * @return
	 */
	List<PayeeFieldDetailsView> getPayeeFieldsCS(PayeeDetailVO payeeDetailVO);
	
	/**
	 * @param payeeId
	 * @return
	 */
	public PayeeDetailVO getPayeeToValidatePayment(Integer payeeId);
	
	
	public BillerVO getFieldInfo(String billerUniqueId,String countryCode) ;
	
	public boolean checkIfAnyInprocessPayments(Date fromDate,Date toDate,Integer payeeId,String countryCode,List<String> statusList) ;
	
	
	////Added for Orange Money
	List<ViewPayeeVO> viewWalletPayeeList(UserVO userVO);
	
	List<PayeeDetailVO> getPayeeListCS(UserVO userVO, Integer payeeId, String WalletType, String Country, String AccountNumber);
	
	List<ViewPayeeVO> getWalletPayeeList(UserVO userVO,Integer payeeId);
	
	boolean deletePayeeBO(PayeeDetailVO PayeeDetailsVO);
	
	boolean addPayeeBO(PayeeDetailVO PayeeDetailsVO);
	
	public String getCommonSequenceNumberGenerator(String strNameQueryName);

	public String getCurrentDayPayment(String strCountry, String AccountNumber);

	List<ViewPayeeVO> getPayeeListByWallet(UserVO userVO, Integer payeeId,
			String walletNumber);
	
	public BillerVO getWalletFieldInfo(String billerUniqueId,String countryCode) ;
	
	public BillerVO getWalletUniqueBillerId(String billerUniqueId,String cntry) ;
}