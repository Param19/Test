package com.scb.channels.payments.service;

public interface BillerDownloadCountriesService {
	
	public String getBillerDownloadCountries();
	

}
