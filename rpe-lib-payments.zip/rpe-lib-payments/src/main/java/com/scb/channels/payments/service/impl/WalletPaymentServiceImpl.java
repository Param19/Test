package com.scb.channels.payments.service.impl;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.ws.WebServiceException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sc.corebanking.v6.transaction.ContraAccountNarration;
import com.sc.corebanking.v6.transaction.CreditNarration;
import com.sc.corebanking.v6.transaction.DebitNarration;
import com.sc.corebanking.v6.transaction.PostTransactionReq;
import com.sc.corebanking.v6.transaction.PostTransactionReqPayload;
import com.sc.corebanking.v6.transaction.TransactionInfo;
import com.sc.corebanking.v6.transaction.TransactionReference;
import com.sc.corebanking.v6.transaction.TransactionsPosting;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransaction;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.TransactionPortType;
import com.sc.scbml_1.ExceptionType;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.HostResponseTypeVO;
import com.scb.channels.base.vo.InwardPaymentDetailVO;
import com.scb.channels.base.vo.InwardPaymentRequestVO;
import com.scb.channels.base.vo.InwardPaymentResponseVO;
import com.scb.channels.base.vo.NarrationVO;
import com.scb.channels.base.vo.PayeeDetailVO;
import com.scb.channels.base.vo.PayeeFieldDetailsView;
import com.scb.channels.base.vo.StatusTypeVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.mapper.helper.BillpaymentMappingHelper;
import com.scb.channels.payments.dao.InwardTransactionDAO;
import com.scb.channels.payments.dao.PayeeManagementDAO;
import com.scb.channels.payments.service.PaymentCommonService;
import com.scb.channels.payments.service.WalletTransactionService;

public class WalletPaymentServiceImpl implements WalletTransactionService {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(WalletPaymentServiceImpl.class);

	/** The common service. */
	private PaymentCommonService paymentCommonService;

	/** The PayeeManagement Dao. */
	private PayeeManagementDAO payeeManagementDAO;

	/** The InwardTransaction Dao. */
	private InwardTransactionDAO inwardTransactionDao;

	public InwardTransactionDAO getInwardTransactionDao() {
		return inwardTransactionDao;
	}

	public void setInwardTransactionDao(InwardTransactionDAO inwardTransactionDao) {
		this.inwardTransactionDao = inwardTransactionDao;
	}

	/** The transaction port type. */
	private TransactionPortType transactionPortType;

	public PaymentCommonService getPaymentCommonService() {
		return paymentCommonService;
	}

	public void setPaymentCommonService(PaymentCommonService paymentCommonService) {
		this.paymentCommonService = paymentCommonService;
	}

	public TransactionPortType getTransactionPortType() {
		return transactionPortType;
	}

	public void setTransactionPortType(TransactionPortType transactionPortType) {
		this.transactionPortType = transactionPortType;
	}

	public PayeeManagementDAO getPayeeManagementDAO() {
		return payeeManagementDAO;
	}

	public void setPayeeManagementDAO(PayeeManagementDAO payeeManagementDAO) {
		this.payeeManagementDAO = payeeManagementDAO;
	}

	public DataBean getDataBean() {
		return dataBean;
	}

	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}

	/** The data bean. */
	private DataBean dataBean;

	@Override
	public InwardPaymentResponseVO validateWalletRequest(InwardPaymentRequestVO inwardPaymentRequestVO) {

		LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateWalletRequest start::::::::" +inwardPaymentRequestVO.getReferenceNumber());
		InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
		ExceptionMessages exceptionMessages = null;
		try {
			LOGGER.info(": Before checkEmptyFields() : "+inwardPaymentRequestVO.getReferenceNumber());
			exceptionMessages = checkEmptyFields(inwardPaymentRequestVO, inwardPaymentResponseVO);
			LOGGER.info(": After checkEmptyFields() : exceptionMessages : "+exceptionMessages +": referenceNo: " +inwardPaymentRequestVO.getReferenceNumber());
			boolean decimalFlag = false;
			boolean dailyLimitCheckFlag = false;
			double walletDailyLimitAmount = 0.0;
			String dailyLimit = "";
			String accountNumber = inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber();
			String country = inwardPaymentRequestVO.getClientInfoVO().getCountry();
			String strAmt = inwardPaymentRequestVO.getInwardTransactionInfoVO().getAmount();
			double amount = StringUtils.isNotEmpty(strAmt)?Double.parseDouble(strAmt):0;
			String walletLimitCheckCountries = dataBean.getMap().get(CommonConstants.WALLET_LIMITCHECK_COUNTRIES);
			
			//Validation with values
			if (exceptionMessages == null){
				LOGGER.info("WalletPaymentServiceImpl:validateWalletRequest: No empty fields: "+inwardPaymentRequestVO.getReferenceNumber());
				dailyLimit = dataBean.getMap().get(country + CommonConstants.WALLET_DAILY_LIMIT);
				walletDailyLimitAmount = StringUtils.isNotEmpty(dailyLimit)?Double.parseDouble(dailyLimit):0;
				LOGGER.info("validateWalletRequest: Before validateFieldValues() : "+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMessages = validateFieldValues(country, accountNumber, amount, decimalFlag, exceptionMessages,inwardPaymentResponseVO);
				LOGGER.info("validateWalletRequest: After validateFieldValues() : exceptionMessages : "+exceptionMessages + ": referenceNo: "+inwardPaymentRequestVO.getReferenceNumber());
			}
			
			StatusTypeVO statusTypeVO = new StatusTypeVO();
			statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
		
			if(CommonConstants.VALIDSUCC.equals(inwardPaymentResponseVO.getStatus())){
				List<PayeeDetailVO> listPayee = payeeManagementDAO.getPayeeListCS(null, null, CommonConstants.WALLET_PAYEE,
						inwardPaymentRequestVO.getClientInfoVO().getCountry(), inwardPaymentRequestVO
								.getInwardTransactionInfoVO().getAccountNumber());
				// payee = listPayee.get(0);
				if (listPayee == null || (listPayee != null && listPayee.size() == 0)) {
					exceptionMessages = ExceptionMessages._244; // Wallet Payee not available
				} else {
					//if (listPayee != null) {
					PayeeDetailVO payeeDetailVO = listPayee.get(0);
					if (payeeDetailVO.getConsumerDetail() != null
							&& payeeDetailVO.getConsumerDetail().equalsIgnoreCase(
									inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber())) {
						if(amount > 0.0 && inwardPaymentRequestVO.getInwardTransactionInfoVO().getReserve2().equalsIgnoreCase(CommonConstants.DISCHARGE)) {
							double debitAmountPerDay = inwardTransactionDao.getTotalDebitWalletPayment(payeeDetailVO.getCustomerId(),country,inwardPaymentRequestVO.getClientInfoVO().getDate());
							LOGGER.info(":::::::: WalletPaymentServiceImpl Total Debit Amount per day :: Account to Wallet ::: " + debitAmountPerDay +  " current debit amount ::: " + amount +"referenceNo: "+inwardPaymentRequestVO.getReferenceNumber());
							dailyLimitCheckFlag = paymentCommonService.dailyLimitCheckValidation(walletLimitCheckCountries, country, amount, debitAmountPerDay, walletDailyLimitAmount);
							LOGGER.info(":::::::: WalletPaymentServiceImpl Total Debit Amount with current debit amount :: dailyLimitCheckFlag ::: " + dailyLimitCheckFlag +": referenceNo: "+inwardPaymentRequestVO.getReferenceNumber());
							if (!dailyLimitCheckFlag) {
								exceptionMessages = ExceptionMessages._250;
								LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - daily limit check exceeded ::::::::");
							}
						}
	
						if (exceptionMessages == null) {
							String strReserveFlag = inwardPaymentRequestVO.getInwardTransactionInfoVO().getReserve2();
							String strTransferType = payeeDetailVO.getConsumerDetail().substring(
								payeeDetailVO.getConsumerDetail().length() - 1);
							inwardPaymentRequestVO.setPayeeId(payeeDetailVO.getPayeeId().longValue());
							inwardPaymentRequestVO.setRelId(payeeDetailVO.getCustomerId());
							boolean TransferFlag = false;
						
						if ((strTransferType.equals(CommonConstants.ONE) || strTransferType.equals(CommonConstants.THREE_STR))
								&& strReserveFlag.equalsIgnoreCase(CommonConstants.DISCHARGE)) {
							LOGGER.info("WalletPaymentServiceImpl TransferTYpe Request DEBIT match :::::::: strTransferType :: " + strTransferType + " strReserveFlag :: "
								 + strReserveFlag + " TransferFlag " + TransferFlag + " referenceNo: "+inwardPaymentRequestVO.getReferenceNumber());
							TransferFlag = true;
						} else if ((strTransferType.equals(CommonConstants.TWO) || strTransferType.equals(CommonConstants.THREE_STR))
								&& strReserveFlag.equalsIgnoreCase(CommonConstants.CHARGE)) {
							LOGGER.info("WalletPaymentServiceImpl TransferTYpe Request CREDIT match :::::::: strTransferType :: " + strTransferType + " strReserveFlag :: "
									 + strReserveFlag + " TransferFlag " + TransferFlag +" referenceNo: "+inwardPaymentRequestVO.getReferenceNumber());
							TransferFlag = true;
						}
	
						if (!TransferFlag) {
							LOGGER.error("WalletPaymentServiceImpl TransferType Request mismatch::::::::"+inwardPaymentRequestVO.getReferenceNumber());
							statusTypeVO.setStatusCode(ExceptionMessages._243.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._243.getMessage());
							inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
							inwardPaymentResponseVO.setStatus(ExceptionMessages._243.getCode());
						}
	
						List<PayeeFieldDetailsView> payeeFieldDetailsView = payeeManagementDAO.getPayeeFieldsCS(payeeDetailVO);
	
						for (PayeeFieldDetailsView payeeFieldDetails : payeeFieldDetailsView) {
							if (payeeFieldDetails.getFieldLabelName() != null
									&& payeeFieldDetails.getFieldLabelName().equalsIgnoreCase(CommonConstants.ACCOUNT)) {
								inwardPaymentRequestVO.getInwardTransactionInfoVO().setAccountNumber(
										payeeFieldDetails.getFieldValue());
							}
						}
					} 
				}else {
						LOGGER.error("WalletPaymentServiceImpl ValidateWalet Request mismatch::::::::"+inwardPaymentRequestVO.getReferenceNumber());
						statusTypeVO.setStatusCode(ExceptionMessages._242.getCode());
						statusTypeVO.setStatusDesc(ExceptionMessages._242.getMessage());
						inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						inwardPaymentResponseVO.setStatus(ExceptionMessages._242.getCode());
					}

			}
		}
		if (exceptionMessages != null) {
			statusTypeVO.setStatusCode(exceptionMessages.getCode());
			statusTypeVO.setStatusDesc(exceptionMessages.getMessage());
			inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
			inwardPaymentResponseVO.setStatus(exceptionMessages.getCode());
		}

		} catch (Exception e) {
			LOGGER.info("Exception occured while ValidateWalet : "+inwardPaymentRequestVO.getReferenceNumber());
			LOGGER.error("WalletPaymentServiceImpl ValidateWalet exception::::::::", e);
			StatusTypeVO statusTypeVO = new StatusTypeVO();
			statusTypeVO.setStatusCode(ExceptionMessages._400.getCode());
			statusTypeVO.setStatusDesc(ExceptionMessages._400.getMessage());
			inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
			inwardPaymentResponseVO.setStatus(ExceptionMessages._400.getCode());
		}
		return inwardPaymentResponseVO;
	}

	private ExceptionMessages validateFieldValues(String country, String accountNumber, double amount, boolean decimalFlag, ExceptionMessages exceptionMessages, InwardPaymentResponseVO inwardPaymentResponseVO) {
		
		String decimalNotAllowCountries = dataBean.getMap().get(CommonConstants.INWARD_DECIMAL_NOT_ALLOW_COUNTRIES);
		String bankIdentificationCode = dataBean.getMap().get(country + CommonConstants.BANK_IDENTIFICATION_CODE); // SCHBBWGX -(HEAD OFFICE)
		String strCustomerId = payeeManagementDAO.getCurrentDayPayment(country,accountNumber);
		LOGGER.info(":::::::: WalletPaymentServiceImpl Customer ID is ::: " + strCustomerId);
		
		if (amount > 0.0) {
			decimalFlag = paymentCommonService.decimalAmountValidation(decimalNotAllowCountries, country, amount);
		}
		
		if (!decimalFlag) {
			exceptionMessages = ExceptionMessages._453;
			LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - Invalid Amount Format ::::::::");
		}  else if (!accountNumber.startsWith(bankIdentificationCode)) { // CS - BIC validation - Comment this for local env
			LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - Customer BIC number not started with Country Specific BIC ::::::::");
			exceptionMessages = ExceptionMessages._400;
		}  else {
			// Set status to SUCCESS if validation is completed
			LOGGER.info("Validation successful. Setting status to VALIDSUCC");
			inwardPaymentResponseVO.setStatus(CommonConstants.VALIDSUCC);
		}
		return exceptionMessages;
	}

	/**
	 * Return Exception Message in case any of the field is empty/null. Otherwise set response status as Success.
	 * @param inwardPaymentRequestVO
	 * @param inwardPaymentResponseVo
	 * @return exceptionMsg
	 */
	private ExceptionMessages checkEmptyFields(InwardPaymentRequestVO inwardPaymentRequestVO, InwardPaymentResponseVO inwardPaymentResponseVo) {
		String currencyFlag = "";
		String cntry = inwardPaymentRequestVO.getClientInfoVO().getCountry();
		LOGGER.info("WalletPaymentServiceImpl : Checking empty fields : country: "+cntry +": referenceNo: "+inwardPaymentRequestVO.getReferenceNumber());
		String referenceNumber = inwardPaymentRequestVO.getReferenceNumber();
		String accountNumber = inwardPaymentRequestVO.getInwardTransactionInfoVO().getAccountNumber();
		String mobileNumber = inwardPaymentRequestVO.getSenderInfoVO().getMobileNumber();
		String currency = inwardPaymentRequestVO.getInwardTransactionInfoVO().getCurrency();
		 // Currency and Country validation
		 if (!currency.isEmpty()) {
			 currencyFlag = paymentCommonService.currencyValidation(inwardPaymentRequestVO);
		 }
		 //Amount
		 String strAmount = inwardPaymentRequestVO.getInwardTransactionInfoVO().getAmount();
		 ExceptionMessages exceptionMsg = null;
		 if (StringUtils.isEmpty(mobileNumber)) {
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - mobile number is empty ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMsg = ExceptionMessages._251;
		  }else if (StringUtils.isEmpty(currency)){
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - currency is empty ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMsg = ExceptionMessages._252;
		  }else if (StringUtils.isEmpty(strAmount)){
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - Amount is empty ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMsg = ExceptionMessages._253;
		  }else if (StringUtils.isEmpty(accountNumber)){
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - AccountNumber is empty ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMsg = ExceptionMessages._254;
		  }else if (StringUtils.isEmpty(cntry)){
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - Country is empty ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMsg = ExceptionMessages._255;
		  }else if (StringUtils.isEmpty(referenceNumber)){
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - referenceNumber is empty ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
				exceptionMsg = ExceptionMessages._256;
		  }else if (currencyFlag.equalsIgnoreCase(ExceptionMessages._454.getErrorCode())) {
				exceptionMsg = ExceptionMessages._454;
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - Invalid Currency ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
		  } else if (currencyFlag.equalsIgnoreCase(ExceptionMessages._456.getErrorCode())) {
				exceptionMsg = ExceptionMessages._456;
				LOGGER.info(":::::::: WalletPaymentServiceImpl ValidateData failed - Invalid Country ::::::::"+inwardPaymentRequestVO.getReferenceNumber());
		  }
		 return exceptionMsg;
	}


	// CR1477, Orange Money changes Starts, 03Feb18, Vijayan A
	// Method added to do Wallet to Bank & Bank to Wallet
	public InwardPaymentResponseVO postSingleLegTransaction(InwardPaymentRequestVO inwardPaymentRequestVO) {

		try {
			LOGGER.info("WalletPaymentServiceImpl ::: postSingleLegTransaction ::: start"+inwardPaymentRequestVO.getReferenceNumber());
			inwardPaymentRequestVO.setServiceName(CommonConstants.POST_TRANSACTION);
			PostTransactionResponse postResponse = null;
			InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
			String sTransferType = null;
			
			// Checking Credit or Debit Flag 1:B2W, 2:W2B
			if (inwardPaymentRequestVO.getInwardTransactionInfoVO().getReserve2() != null
					&& inwardPaymentRequestVO.getInwardTransactionInfoVO().getReserve2().equalsIgnoreCase(CommonConstants.DISCHARGE)) {
				sTransferType = CommonConstants.DISCHARGE;
			} else {
				sTransferType = CommonConstants.CHARGE;
			}
			
			//trantype will be fetched based On service provide & credit/debit flag
			BillerCatgegoryReference billerCatgegoryReference = paymentCommonService.getBillerCategoryReference(
					inwardPaymentRequestVO.getClientInfoVO().getServiceProvider() + CommonConstants.UNDERSCORE + sTransferType, null, inwardPaymentRequestVO
							.getClientInfoVO().getCountry());

			LOGGER.info("postTransactionSingleLeg::: TransactionServiceImpl ::: billerCatgegoryReference:: "
					+ billerCatgegoryReference);

			if (billerCatgegoryReference != null && billerCatgegoryReference.getFetchType() != null
					&& billerCatgegoryReference.getFetchType().equalsIgnoreCase(CommonConstants.INWARD_FETCH_TYPE)) {

				PostTransaction postTransaction = new PostTransaction();
				PostTransactionReq postTransactionReq = new PostTransactionReq();
				PostTransactionReqPayload postTransactionReqPayload = new PostTransactionReqPayload();

				BillpaymentMappingHelper.populateTransactionInfo(postTransactionReqPayload);
				// Transaction transaction = new Transaction();

				LOGGER.info("postTransactionSingleLeg::: TransactionServiceImpl ::: referenceNumber:: "
						+ inwardPaymentRequestVO.getReferenceNumber());
				TransactionInfo transactionInfo = postTransactionReqPayload.getPostTransactionReq()
						.getTransactionInfo();
				transactionInfo.setUniqueReferenceIdentifier(inwardPaymentRequestVO.getHostReferenceNumber());

				transactionInfo.setTransactionType(billerCatgegoryReference.getPaymentTransactionType());
				transactionInfo.setTransactionCurrencyCode(inwardPaymentRequestVO.getInwardTransactionInfoVO()
						.getCurrency());
				List<TransactionsPosting> transactionsPostings = transactionInfo.getTransactionsPosting();
				List<ContraAccountNarration> debitNarrations = transactionInfo.getContraAccountNarration();
				List<CreditNarration> creditNarrations = transactionInfo.getCreditNarration();
				List<DebitNarration> debitTxnNarrations = transactionInfo.getDebitNarration();
				
				inwardPaymentRequestVO = paymentCommonService.populateNarration(inwardPaymentRequestVO,
						CommonConstants.WALLET_SERVICE, inwardPaymentRequestVO.getClientInfoVO()
								.getServiceProvider(), sTransferType);
				List<NarrationVO> narrationVOs = inwardPaymentRequestVO.getDebitNarrationVOs();
				List<NarrationVO> cnarrationVOs = inwardPaymentRequestVO.getCreditNarrationVOs();

				LOGGER.info("postTransactionSingleLeg::: TransactionServiceImpl inwardPaymentRequestVO:::"
						+ inwardPaymentRequestVO.getReferenceNumber());
				if(sTransferType.equalsIgnoreCase(CommonConstants.CHARGE)){ // for Credit Transaction Narration population
				if (narrationVOs != null) {
					for (NarrationVO narrationVO : narrationVOs) {
						ContraAccountNarration debitNarration = new ContraAccountNarration();
						debitNarration.setNarration(narrationVO.getNarration());
						debitNarrations.add(debitNarration);
					}
				}

				//LOGGER.info("postTransactionSingleLeg::: TransactionServiceImpl ::: cnarrationVOs " + cnarrationVOs);
				if (cnarrationVOs != null) {
					for (NarrationVO narrationVO : cnarrationVOs) {
						CreditNarration creditNarration = new CreditNarration();
						creditNarration.setCreditNarration(narrationVO.getNarration());
						creditNarrations.add(creditNarration);
					 }
				   }
				 } 
				else // for Debit Transaction Narration population
					{
					if (narrationVOs != null) {
						for (NarrationVO narrationVO : narrationVOs) {
							DebitNarration debitNarration = new DebitNarration();
							debitNarration.setDebitNarration(narrationVO.getNarration());
							debitTxnNarrations.add(debitNarration);
						}
					}
					
					//LOGGER.info("postTransactionSingleLeg::: TransactionServiceImpl ::: cnarrationVOs " + cnarrationVOs);
					if (cnarrationVOs != null) {
						for (NarrationVO narrationVO : cnarrationVOs) {
							ContraAccountNarration creditNarration = new ContraAccountNarration();
							creditNarration.setNarration(narrationVO.getNarration());
							debitNarrations.add(creditNarration);
						}
					}
				}

				LOGGER.info("postTransactionSingleLeg::: TransactionServiceImpl :::"
						+ inwardPaymentRequestVO.getReferenceNumber());
				
				TransactionsPosting transactionsPosting = new TransactionsPosting();
				
				transactionsPosting.setAccountNumber(inwardPaymentRequestVO.getInwardTransactionInfoVO()
						.getAccountNumber());
				// transactionsPosting.setAccountNumber(AccountNumber);
				transactionsPosting.setAccountCurrencyCode(inwardPaymentRequestVO.getInwardTransactionInfoVO()
						.getCurrency());
				transactionsPosting.setTransactionAmount(inwardPaymentRequestVO.getInwardTransactionInfoVO()
						.getAmount());

				transactionsPosting.setCreditDebitIndicator(sTransferType == CommonConstants.DISCHARGE ? CommonConstants.DEBIT_WALLET : CommonConstants.CREDIT_WALLET);

				TransactionReference transactionReference = new TransactionReference();
				transactionsPostings.add(transactionsPosting);
				// 1508384 Commented for OM 
				//transactionReference.setReferenceNumber(inwardPaymentRequestVO.getHostReferenceNumber());
				transactionsPosting.setTransactionReference(transactionReference);
				postTransactionReq.setPostTransactionReqPayload(postTransactionReqPayload);

				postTransactionReq.setHeader(BillpaymentMappingHelper.populateInwardHeader(inwardPaymentRequestVO
						.getClientInfoVO().getCountry(), CommonConstants.I_BANKING, BillpaymentMappingHelper
						.getGregorianCalendar(), inwardPaymentRequestVO.getReferenceNumber(),
						CommonConstants.CAPTURING_SYSTEM, CommonConstants.POST_SINGLE_LEG_TRANSACTION,
						CommonConstants.POST_SINGLE_LEG, CommonConstants.INWARD_TRANSACTION_STATUS_MESSAGE_TYPE_NAME,
						CommonConstants.DOMAIN_NAME));

				postTransaction.setPostTransactionRequest(postTransactionReq);

				String str = CommonHelper.getXML(postTransaction, PostTransaction.class, "postTransaction");
				//System.out.println(str);

				postResponse = transactionPortType.postTransaction(postTransaction);

				if (postResponse != null && postResponse.getPostTransactionResponse() != null
						&& postResponse.getPostTransactionResponse().getHeader() != null
						&& postResponse.getPostTransactionResponse().getHeader().getExceptions() != null) {

					for (ExceptionType exceptionType : postResponse.getPostTransactionResponse().getHeader()
							.getExceptions().getException()) {

						LOGGER.info("Exceptions present in the :performInwardBillPayment response ::: "
								+ inwardPaymentRequestVO.getReferenceNumber() + " Exceptions code "
								+ exceptionType.getCode().getValue() + "  Description ::: "
								+ exceptionType.getDescription());

						StatusTypeVO statusTypeVO = new StatusTypeVO();
						HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
						String exceptionCode = exceptionType.getCode().getValue().trim();

						if (exceptionCode.equalsIgnoreCase(CommonConstants.TIMEOUT_CODE)) {

							statusTypeVO.setStatusCode(ExceptionMessages._202.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._202.getMessage());
							hostResponseTypeVO.setCode(exceptionType.getCode().getValue());
							hostResponseTypeVO.setDesc(exceptionType.getDescription());
							hostResponseTypeVO.setHostName(CommonConstants.EBBS);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
							inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._202.getMessage());
							inwardPaymentRequestVO.setHostStatusCode(exceptionCode);
							inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());

						} else {

							statusTypeVO.setStatusCode(ExceptionMessages._458.getCode());
							statusTypeVO.setStatusDesc(ExceptionMessages._458.getMessage());
							hostResponseTypeVO.setCode(exceptionType.getCode().getValue());
							hostResponseTypeVO.setDesc(exceptionType.getDescription());
							hostResponseTypeVO.setHostName(CommonConstants.EBBS);
							inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_FAILURE);
							inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._201.getMessage());
							inwardPaymentRequestVO.setHostStatusCode(exceptionType.getCode().getValue());
							inwardPaymentRequestVO.setHostStatusDescription(exceptionType.getDescription());
						}

						statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
						inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
						inwardPaymentResponseVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());

					}

				} else if (postResponse != null
						&& postResponse.getPostTransactionResponse() != null
						&& postResponse.getPostTransactionResponse().getPostTransactionResPayload() != null
						&& postResponse.getPostTransactionResponse().getPostTransactionResPayload()
								.getPostTransactionRes() != null
						&& postResponse.getPostTransactionResponse().getPostTransactionResPayload()
								.getPostTransactionRes().getTransactionInfo() != null) {

					LOGGER.info("Response payload from host ::: " + inwardPaymentRequestVO.getReferenceNumber());
					TransactionInfo transactionInfo2 = postResponse.getPostTransactionResponse()
							.getPostTransactionResPayload().getPostTransactionRes().getTransactionInfo();
					inwardPaymentResponseVO.setReferenceNumber(transactionInfo2.getTransactionReferenceNumber());
					HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
					hostResponseTypeVO.setHostName(CommonConstants.EBBS);
					hostResponseTypeVO.setCode(transactionInfo2.getTransactionResponse().getCode());
					hostResponseTypeVO.setDesc(transactionInfo2.getTransactionResponse().getDescription());
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(ExceptionMessages._000.getCode());
					statusTypeVO.setStatusDesc(ExceptionMessages._000.getMessage());
					statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
					statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
					inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
					inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_SUCCESS);
					inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._000.getMessage());
					inwardPaymentRequestVO.setHostStatusCode(transactionInfo2.getTransactionResponse().getCode());
					inwardPaymentRequestVO.setHostStatusDescription(transactionInfo2.getTransactionResponse()
							.getDescription());

				} else {

					LOGGER.info("No response payload from host ::: " + inwardPaymentRequestVO.getReferenceNumber());
					HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
					hostResponseTypeVO.setCode(ExceptionMessages._503.getCode());
					hostResponseTypeVO.setDesc("No response payload from host");
					StatusTypeVO statusTypeVO = new StatusTypeVO();
					statusTypeVO.setStatusCode(ExceptionMessages._457.getCode());
					statusTypeVO.setStatusDesc(ExceptionMessages._457.getMessage());
					statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
					statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
					inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);
					inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
					inwardPaymentRequestVO.setPaymentDescription(CommonConstants.TIMEOUT);
					inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._503.getCode());
					inwardPaymentRequestVO.setHostStatusDescription("No response payload from host");

				}
				LOGGER.info("performBillPayment ::: performInwardBillPayment TransactionServiceImpl ::: End"
						+ inwardPaymentRequestVO.getReferenceNumber());

			} else {

				LOGGER.info("Service Provider Problem ::: " + inwardPaymentRequestVO.getReferenceNumber());
				StatusTypeVO statusTypeVO = new StatusTypeVO();
				HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
				hostResponseTypeVO.setCode(ExceptionMessages._455.getCode());
				hostResponseTypeVO.setDesc(ExceptionMessages._455.getMessage());
				statusTypeVO.setStatusCode(ExceptionMessages._455.getCode());
				statusTypeVO.setStatusDesc(ExceptionMessages._455.getMessage());
				statusTypeVO.setReferenceNumber(inwardPaymentRequestVO.getReferenceNumber());
				statusTypeVO.setHostResponseTypeVO(hostResponseTypeVO);
				inwardPaymentRequestVO.setPaymentStatus(CommonConstants.VALIDFAIL);
				inwardPaymentRequestVO.setPaymentDescription("Invalid Service Provider");
				inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._455.getCode());
				inwardPaymentRequestVO.setHostStatusDescription(ExceptionMessages._455.getMessage());
				inwardPaymentResponseVO.setStatusTypeVO(statusTypeVO);

			}

			return inwardPaymentResponseVO;

		} catch (WebServiceException ex) {
			InwardPaymentResponseVO inwardPaymentResponseVO = new InwardPaymentResponseVO();
			LOGGER.error("performInwardBillPayment TransactionServiceImpl SocketTimeoutException WebServiceException:::::", ex);
			//ex.printStackTrace();
			StatusTypeVO statusType = new StatusTypeVO();
			statusType.setStatusCode(ExceptionMessages._202.getCode());
			statusType.setStatusDesc(ExceptionMessages._202.getMessage());
			HostResponseTypeVO hostResponseTypeVO = new HostResponseTypeVO();
			hostResponseTypeVO.setHostName(CommonConstants.EBBS);
			hostResponseTypeVO.setCode(ExceptionMessages._202.getCode());
			hostResponseTypeVO.setDesc(CommonConstants.HOST_TIMEOUT_MESSAGE);
			statusType.setHostResponseTypeVO(hostResponseTypeVO);
			inwardPaymentResponseVO.setStatusTypeVO(statusType);
			inwardPaymentRequestVO.setPaymentStatus(CommonConstants.COREBANK_PAY_TIMEOUT);
			inwardPaymentRequestVO.setPaymentDescription(ExceptionMessages._202.getMessage());
			inwardPaymentRequestVO.setHostStatusCode(ExceptionMessages._503.getCode());
			inwardPaymentRequestVO.setHostStatusDescription(CommonConstants.HOST_TIMEOUT_MESSAGE);
			return inwardPaymentResponseVO;
		}
	}

	@Override
	public List<InwardPaymentDetailVO> getWalletPaymentRetryTransactionList(InwardPaymentDetailVO inwardPaymentDetailsVO) {

		String country = (inwardPaymentDetailsVO != null && inwardPaymentDetailsVO.getCountryCode() != null ? inwardPaymentDetailsVO
				.getCountryCode() : null);
		country = country != null && !country.isEmpty() ? country.toString() : CommonConstants.EMPTY;

		LOGGER.info("Inside method  getWalletPaymentRetryTransactionList :: country>>>>>>> " + country);
		// BillerPayDetailsVO billerPayDetailsVO = new BillerPayDetailsVO();
		// List<BillerPayDetailsVO> billerPayListFromDB = new
		// ArrayList<BillerPayDetailsVO>();
		// billerPayRequestVO.setBillerPayDetailsVO(billerPayDetailsVO);
		Calendar calendar = DateUtils.getCountryCalendar();
		calendar.add(Calendar.HOUR, -12);
		Date fromDate = calendar.getTime();

		String postBuffer = dataBean.getMap().get(country + CommonConstants.PAYMENT_TIMER_BUFFER);
		int retryBuffer = postBuffer != null && !postBuffer.isEmpty() ? Integer.parseInt(postBuffer) : 0;

		Calendar cal = DateUtils.getCountryCalendar();
		cal.add(Calendar.HOUR, retryBuffer);
		Date toDate = cal.getTime();

		String interval = dataBean.getMap().get(country + CommonConstants.WALLET_PAYMENT_RETRY_TIMER);
		int retryInterval = interval != null && !interval.isEmpty() ? Integer.parseInt(interval) : 15;

		String retryValue = dataBean.getMap().get(country + CommonConstants.WALLET_PAYMENT_TIMEOUT_RETRY_COUNT);
		int retryCount = retryValue != null && !retryValue.isEmpty() ? Integer.parseInt(retryValue)
				: CommonConstants.THREE;

		Object retryStatusObject = dataBean.getMap().get(country + CommonConstants.WALLET_PAYMENT_TIMEOUT_RETRY_STATUS);
		List<String> retryStatus = retryStatusObject != null ? Arrays.asList(retryStatusObject.toString().split(
				CommonConstants.COMMA)) : Arrays.asList(CommonConstants.COREBANK_PAY_TIMEOUT);

		Object retryCountriesObject = dataBean.getMap().get(country + CommonConstants.WALLET_PAYMENT_TIMEOUT_RETRY_COUNTRY);
		List<String> retryCountries = retryCountriesObject != null ? Arrays.asList(retryCountriesObject.toString()
				.split(CommonConstants.COMMA)) : CommonConstants.WALLET_PAYMENT_AFRICAN_COUNTRIES;

		LOGGER.info("getWalletPaymentRetryTransactionList: retry details -- retryInterval {} -- retryCount {} -- retryStatus {} -- retryCountries {}",
				new Object[] { retryInterval, retryCount, retryStatus, retryCountries });

		Calendar updatedTimeCalendar = Calendar.getInstance();
		// updatedTimeCalendar.setTime(new Date());
		updatedTimeCalendar.add(Calendar.MINUTE, -(retryInterval));
		Timestamp updatedTimeStamp = new Timestamp(updatedTimeCalendar.getTime().getTime());

		LOGGER.info("getWalletPaymentRetryTransactionList: At getPayment retry TransactionList for countries {} and status {} --- "
				+ "From Date {} and To Date {} and update date {} ", new Object[] { retryCountries, retryStatus,
				fromDate, toDate, updatedTimeStamp });
		List<InwardPaymentDetailVO> retryList = inwardTransactionDao.geWallettPaymentRetryList(fromDate, toDate,
				updatedTimeStamp, retryCount, retryStatus, retryCountries);
		if (retryList == null) {
			LOGGER.info("RECORDS PICKED WALLET PAYMENT RETRY NULL");
		} else {
			for (InwardPaymentDetailVO paymentDetailVO : retryList) {
				LOGGER.info("RECORDS PICKED PAYMENT RETRY" + paymentDetailVO.getReferenceNumber() + "  "
						+ paymentDetailVO.getHostReferenceNumber());
			}
		}

		LOGGER.info("At getPaymentRetryTransactionList End>>>.> ");
		return retryList;
	}

	// CR1477, Orange Money changes Ends, 03Feb18, Vijayan A

}