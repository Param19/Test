/**
 * 
 */
package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.helper.Messages;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.ViewPayeeRequestVO;
import com.scb.channels.base.vo.ViewPayeeResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.PayeeManagementService;

/**
 * The Class ViewPayeeListProcessor.
 * 
 * @author 1521723
 */
public class ViewPayeeListProcessor  {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ViewPayeeListProcessor.class);

	private PayeeManagementService payeeService;

	public void setPayeeService(PayeeManagementService payeeService) {
		this.payeeService = payeeService;
	}

	/** ViewPayeeListProcessor doTasks */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.channels.common.processor.AbstractProcessor#doTasks(java.lang
	 * .Object)
	 */

	public PayloadDTO process(PayloadDTO bean) throws BusinessException {
		LOGGER.info("ViewPayeeListProcessor :: process :: START ");
		ViewPayeeRequestVO viewPayeeRequestVO = null;
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeRequestVO = (ViewPayeeRequestVO) bean.getRequestVO();
			viewPayeeResponseVO = payeeService.viewPayeeList(viewPayeeRequestVO);
			if (viewPayeeResponseVO == null) {
				viewPayeeResponseVO = new ViewPayeeResponseVO();
				viewPayeeResponseVO.setStatus(Messages._1.getCode());
				viewPayeeResponseVO.setStatusDesc(Messages._1.getMessage());
				viewPayeeResponseVO.setErrorDesc(ExceptionMessages._151.getMessage());
				viewPayeeResponseVO.setErrorCD(ExceptionMessages._151.getCode());
			} else {
				if (!viewPayeeResponseVO.getListViewPayeeVO(). isEmpty()) {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
				} else {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
					viewPayeeResponseVO.setErrorCD(Messages._307.getCode());
					viewPayeeResponseVO.setErrorDesc(Messages._307.getMessage());
				}
			}
			bean.setResponseVO(viewPayeeResponseVO);
		} catch (Exception e) {
			LOGGER.info("ViewPayeeListProcessor :: process ::" + e.getMessage());
			LOGGER.error("ViewPayeeListProcessor :: process ::",e);
		}
		LOGGER.info("ViewPayeeListProcessor :: process :: END ");
		return bean;
	}
	
	public PayloadDTO processAlipay(PayloadDTO bean) throws BusinessException {
		LOGGER.info("ViewPayeeListProcessor :: processAlipay :: START ");
		ViewPayeeRequestVO viewPayeeRequestVO = null;
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeRequestVO = (ViewPayeeRequestVO) bean.getRequestVO();
			//viewPayeeRequestVO.setAuditIdentifier(CommonConstants.PAYEE_AUDIT_REQUEST);
			if(viewPayeeRequestVO.getUser().getCustomerId() != null && viewPayeeRequestVO.getUser().getCustomerType() !=null){
				viewPayeeRequestVO.getUser().setCustomerId(viewPayeeRequestVO.getUser().getCustomerType()+viewPayeeRequestVO.getUser().getCustomerId());
			}
			viewPayeeResponseVO = payeeService.viewPayeeListHK(viewPayeeRequestVO);
			if (viewPayeeResponseVO == null) {
				viewPayeeResponseVO = new ViewPayeeResponseVO();
				viewPayeeResponseVO.setStatus(Messages._1.getCode());
				viewPayeeResponseVO.setStatusDesc(Messages._1.getMessage());
				viewPayeeResponseVO.setErrorDesc(ExceptionMessages._151.getMessage());
				viewPayeeResponseVO.setErrorCD(ExceptionMessages._151.getCode());
			} else {
				if (!viewPayeeResponseVO.getListViewPayeeVO(). isEmpty()) {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
				} else {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
					viewPayeeResponseVO.setErrorCD(Messages._307.getCode());
					viewPayeeResponseVO.setErrorDesc(Messages._307.getMessage());
				}
			}
			bean.setResponseVO(viewPayeeResponseVO);
		} catch (Exception e) {
			LOGGER.info("ViewPayeeListProcessor :: processAlipay ::" + e.getMessage());
			LOGGER.info("ViewPayeeListProcessor :: processAlipay ::" , e);
		}
		LOGGER.info("ViewPayeeListProcessor :: processAlipay :: END ");
		return bean;
	}
	
	
	public PayloadDTO processCS(PayloadDTO bean) throws BusinessException {
		LOGGER.info("ViewPayeeListProcessor :: processCS :: START "+bean.getRequestVO().getMessageVO().getReqID());
		ViewPayeeRequestVO viewPayeeRequestVO = null;
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeRequestVO = (ViewPayeeRequestVO) bean.getRequestVO();
			viewPayeeResponseVO = payeeService.viewPayeeListCS(viewPayeeRequestVO);
			if (viewPayeeResponseVO == null) {
				viewPayeeResponseVO = new ViewPayeeResponseVO();
				viewPayeeResponseVO.setStatus(Messages._1.getCode());
				viewPayeeResponseVO.setStatusDesc(Messages._1.getMessage());
				viewPayeeResponseVO.setErrorDesc(ExceptionMessages._151.getMessage());
				viewPayeeResponseVO.setErrorCD(ExceptionMessages._151.getCode());
			} else {
				if (!viewPayeeResponseVO.getListViewPayeeVO(). isEmpty()) {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
				} else {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
					viewPayeeResponseVO.setErrorCD(Messages._307.getCode());
					viewPayeeResponseVO.setErrorDesc(Messages._307.getMessage());
				}
			}
			bean.setResponseVO(viewPayeeResponseVO);
		} catch (Exception e) {
			LOGGER.info("ViewPayeeListProcessor :: processCS :: Exception" +bean.getRequestVO().getMessageVO().getReqID()+"  "+ e.getMessage());
			LOGGER.error("ViewPayeeListProcessor :: processCS :: Exception" ,e);
		}
		LOGGER.info("ViewPayeeListProcessor :: processCS :: END "+bean.getRequestVO().getMessageVO().getReqID());
		return bean;
	}
	//Added for Orange Money - start
	
	public PayloadDTO processWallet(PayloadDTO bean) throws BusinessException {
		LOGGER.info("ViewPayeeListProcessor :: processWallet :: START ");
		ViewPayeeRequestVO viewPayeeRequestVO = null;
		ViewPayeeResponseVO viewPayeeResponseVO = null;
		try {
			viewPayeeRequestVO = (ViewPayeeRequestVO) bean.getRequestVO();
			viewPayeeResponseVO = payeeService.viewWalletPayeeList(viewPayeeRequestVO);
			if (viewPayeeResponseVO == null) {
				viewPayeeResponseVO = new ViewPayeeResponseVO();
				viewPayeeResponseVO.setStatus(Messages._1.getCode());
				viewPayeeResponseVO.setStatusDesc(Messages._1.getMessage());
				viewPayeeResponseVO.setErrorDesc(ExceptionMessages._247.getMessage());
				viewPayeeResponseVO.setErrorCD(ExceptionMessages._247.getCode());
			} else {
				if (!viewPayeeResponseVO.getListViewPayeeVO(). isEmpty()) {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
				} else {
					viewPayeeResponseVO.setStatus(Messages._0.getCode());
					viewPayeeResponseVO.setStatusDesc(Messages._0.getMessage());
					viewPayeeResponseVO.setErrorCD(Messages._356.getCode());
					viewPayeeResponseVO.setErrorDesc(Messages._356.getMessage());
				}
			}
			bean.setResponseVO(viewPayeeResponseVO);
		} catch (Exception e) {
			//LOGGER.info("ViewPayeeListProcessor :: processWallet ::" + e.getMessage());
			LOGGER.error("Exception during ViewPayeeListProcessor :: processWallet:",e);
		}
		LOGGER.info("ViewPayeeListProcessor :: processWallet :: END ");
		return bean;
	}
	//Added for Orange Money - end
}
