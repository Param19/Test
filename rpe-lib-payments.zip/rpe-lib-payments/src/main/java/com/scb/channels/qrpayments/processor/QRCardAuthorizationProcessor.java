package com.scb.channels.qrpayments.processor;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.qrpayments.service.QRCreditCardService;

public class QRCardAuthorizationProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QRCardAuthorizationProcessor.class);
	
	private QRCreditCardService qrCreditCardService;
	
	public PayloadDTO processAuthorization(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in QR Card Authorization Processor :::: Start");
		
		QRPaymentRequestVO  qrPaymentRequestVO  = null;
		QRPaymentResponseVO qrPaymentResponseVO = null;
		try{
			if(bean != null && bean.getRequestVO() != null){
				qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
				LOGGER.info("Posting request to CCMS ::: ");
				if(qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode()!=null 
						&& qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode()!=""
						&& qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode().equals(CommonConstants.IN)){
					qrPaymentResponseVO = qrCreditCardService.authorizeCreditCard(qrPaymentRequestVO);
				}else{
					qrPaymentResponseVO = qrCreditCardService.authorizeCreditCardV2(qrPaymentRequestVO);
				}
				
			}
		}catch(Exception e){
			LOGGER.info("Error while posting the request to CCMS :::: ",e);
			LOGGER.error("Error inside QRCardAuthorizationProcessor processAuthorization :::  ",e);
			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO(); 
			}
			LOGGER.info("Setting Fail status for the card authorization due to Exception ::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			qrPaymentResponseVO.setStatus(ExceptionMessages._105.getCode());
			qrPaymentResponseVO.setStatusDesc(e.getMessage());
			qrPaymentResponseVO.setErrorDesc(e.getMessage());
			qrPaymentResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for card auth due to web service exception::: " + qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
				LOGGER.error("Setting timeout for card auth :::",e.getCause().toString());
				qrPaymentResponseVO.setStatusDesc(CommonConstants.FAILURE);
				qrPaymentResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.CARD_AUTH_TIMEOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.NEGATIVE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			}
		}finally{		
			if (qrPaymentResponseVO != null) {
						
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostName(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_system());	
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
					LOGGER.info("QRCard Auth Processor Size:::: "+qrPaymentRequestVO.getHostResponseVO().size());
				}				
				qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
				qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
				qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
				qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
			}		
			bean.setResponseVO(qrPaymentResponseVO);		
		}
		LOGGER.info("QR Card Auth TXTStatus :::: "+qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("Task in QRCard processAuthorization Processor End ::"+ qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference());
		return bean;
	}
	
	public PayloadDTO processAuthorizationReversal(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Task in QR Card Authorization Reversal Processor :::: Start");
		
		QRPaymentRequestVO  qrPaymentRequestVO  = null;
		QRPaymentResponseVO qrPaymentResponseVO = null;
		try{
			if(bean != null && bean.getRequestVO() != null){
				qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
				LOGGER.info("Posting Reversal request to CCMS ::: "+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
				if(qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode()!=null 
						&& qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode()!=""
						&& qrPaymentRequestVO.getQrPaymentDetailVO().getCountryCode().equals(CommonConstants.IN)){
					qrPaymentResponseVO = qrCreditCardService.reverseCardAuthorization(qrPaymentRequestVO);
				}else{				
					qrPaymentResponseVO = qrCreditCardService.reverseCardAuthorizationV2(qrPaymentRequestVO);
				}
			}
		}catch(Exception e){
			LOGGER.info("Error while posting the request to CCMS :::: ",e);
			LOGGER.error("Error inside QRCardAuthorizationProcessor processAuthorizationReversal :::  ",e);
			if(qrPaymentResponseVO == null){
				qrPaymentResponseVO = new QRPaymentResponseVO(); 
			}
			LOGGER.info("Setting Fail status for the card authorization reversal due to Exception ::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			qrPaymentResponseVO.setStatus(ExceptionMessages._105.getCode());
			qrPaymentResponseVO.setStatusDesc(e.getMessage());
			qrPaymentResponseVO.setErrorDesc(e.getMessage());
			qrPaymentResponseVO.setErrorCD(ExceptionMessages._105.getCode());
			
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnStatusCd(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.FAIL);
			qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_FAILURE);
			if(e instanceof WebServiceException){
				LOGGER.info("Setting timeout for card auth reversal due to webservice exception ::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
				LOGGER.error("Setting timeout for card auth :::",e.getCause().toString());
				qrPaymentResponseVO.setStatusDesc(CommonConstants.TIMEOUT_MSG);
				qrPaymentResponseVO.setStatus(CommonConstants.NEGATIVE);
				
				qrPaymentRequestVO.getQrPaymentDetailVO().setTxnActStatus(CommonConstants.CARD_AUTH_REV_TIMEOUT);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseCode(CommonConstants.NEGATIVE);
				qrPaymentRequestVO.getQrPaymentDetailVO().setHostResponseDesc(e.getMessage());
			}
		}finally{		
			if (qrPaymentResponseVO != null) {
				if(qrPaymentResponseVO.getQrPaymentDetailVO() == null) {
					qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentRequestVO.getQrPaymentDetailVO());
				}				
				if(qrPaymentResponseVO.getQrPaymentDetailVO() != null ) {
					LOGGER.info("Setting the aggregator response status details to host response list in card auth reversal" + 
						qrPaymentRequestVO.getQrPaymentDetailVO().getHost_reference() +
						qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode() +
						qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference()+
						qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					
					HostResponseVO hostResponse = new HostResponseVO();
					hostResponse.setCode(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseCode());
					hostResponse.setDesc(qrPaymentResponseVO.getQrPaymentDetailVO().getHostResponseDesc());
					hostResponse.setHostName(qrPaymentResponseVO.getQrPaymentDetailVO().getHost_system());		
					qrPaymentRequestVO.getHostResponseVO().add(hostResponse);
				}				
				qrPaymentResponseVO.setMessageVO(qrPaymentRequestVO.getMessageVO()); 
				qrPaymentResponseVO.setUser(qrPaymentRequestVO.getUser());
				qrPaymentResponseVO.setServiceVO(qrPaymentRequestVO.getServiceVO());
				qrPaymentResponseVO.setClientVO(qrPaymentRequestVO.getClientVO());
			}
			bean.setResponseVO(qrPaymentResponseVO);		
		}
		LOGGER.info("QR Card Auth Reversal TXTStatus ::::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getTxnActStatus());
		LOGGER.info("Task in Card Auth Reversal Post Transaction Processor End ::"+qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
		return bean;
	}

	public QRCreditCardService getQrCreditCardService() {
		return qrCreditCardService;
	}

	public void setQrCreditCardService(QRCreditCardService qrCreditCardService) {
		this.qrCreditCardService = qrCreditCardService;
	}
	

}
