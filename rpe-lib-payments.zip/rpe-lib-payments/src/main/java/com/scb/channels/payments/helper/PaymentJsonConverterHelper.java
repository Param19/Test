package com.scb.channels.payments.helper;

import org.bouncycastle.crypto.engines.DESedeEngine;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.PaymentTransactionService;

public class PaymentJsonConverterHelper {
	
	
	/** The Constant KEY. */
	public static final String KEY = "000027798405508980992826";
	
	/** The gson */
	private Gson gson;
	
	/** The key. */
	private String key = KEY;
	
	/** The encrypt cipher. */
	private static PaddedBufferedBlockCipher encryptCipher;
	
	/** The decrypt cipher. */
	private static PaddedBufferedBlockCipher decryptCipher;		
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentJsonConverterHelper.class);
	
	/** The paymentTransactionService. */
	private PaymentTransactionService paymentTransactionService;
	
	
	public PayloadDTO objectToJsonConverter(PayloadDTO bean){
		
		LOGGER.info("Inside PaymentJsonConverterHelper - objectToJsonConverter");
		BillerPayRequestVO  billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
		String requestVOString = gson.toJson(billerPayRequestVO);
		
		LOGGER.info("After Converting payload to jSon string RequestVO Object {}",new Object[]{requestVOString});
		PaymentJsonConverterHelper.InitCiphers(key.getBytes());
		String encryptedString = PaymentJsonConverterHelper.encrypt(requestVOString);
		LOGGER.info("After Encrypting the payload string");
		billerPayRequestVO.getBillerPayDetailsVO().setPayRef(encryptedString);
		
		LOGGER.info(" Before updateRequestVOString  - objectToJsonConverter encryptedString{}",new Object[]{encryptedString});
		paymentTransactionService.updateRequestVOString(billerPayRequestVO.getBillerPayDetailsVO());
		LOGGER.info("After updateRequestVOString   - objectToJsonConverter");
		
		LOGGER.info("Completed PaymentJsonConverterHelper - objectToJsonConverter");
		return bean;
		
	}
	
	
	public PayloadDTO jsonToObjectConverter(BillerPayDetailsVO billerPayDetailsVO){
		
		LOGGER.info("Inside PaymentJsonConverterHelper - jsonToObjectConverter");
		String billerPayRequestString = null;
		String decryptedString = null;
		int version=0;
		int processingMode = 0;
		PayloadDTO payloadDTO = new PayloadDTO();
		if(billerPayDetailsVO!=null){
			billerPayRequestString = billerPayDetailsVO.getPayRef();
			PaymentJsonConverterHelper.InitCiphers(key.getBytes());
			
			LOGGER.info("Before Convert the jSon to gSon decryptedString - jsonToObjectConverter");
			decryptedString = PaymentJsonConverterHelper.decrypt(billerPayRequestString);
			BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)gson.fromJson(decryptedString, BillerPayRequestVO.class);
			LOGGER.info("After Convert the jSon to gSon decryptedString  decryptedString - jsonToObjectConverter");
			
			version = billerPayDetailsVO.getTransactionInfoVO().getVersion();
			processingMode = billerPayDetailsVO.getTransactionInfoVO().getProcessingMode();
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setVersion(version);
			billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setProcessingMode(processingMode);
			payloadDTO.setRequestVO(billerPayRequestVO);
			
		}
		LOGGER.info("Completed PaymentJsonConverterHelper - jsonToObjectConverter");
		return payloadDTO;
		
	}
	
	
	public PayloadDTO updateRetryCount(PayloadDTO bean){
		LOGGER.info("Inside updateRetryCount");
		// for aggregator posting retry count
		int version = 0; 
		
		// for Connection timeout retry count
		int processingMode = 0;
		
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
		BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO)bean.getResponseVO();
		
		version = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getVersion();
		processingMode = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getProcessingMode();
		
		if(billerPayResponseVO != null){
			LOGGER.info("billerPayResponseVO not null ");
			if(billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnStatusCd().equals(CommonConstants.WACK)){
				LOGGER.info("Inside WACK ");
				processingMode = processingMode + 1;
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setProcessingMode(processingMode);
			}else if( !billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().getTxnStatusCd().equals(CommonConstants.PACK)){
				LOGGER.info("Inside NOT PACK But FAIL ");
				version = version + 1;
				billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setVersion(version);
			}
			LOGGER.info("Before updatePmtVersion ");
			LOGGER.info("Txn ID {}",new Object[]{billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getMessageVO().getRequestCode()});
			paymentTransactionService.updatePmtVersion(billerPayRequestVO.getBillerPayDetailsVO());
			LOGGER.info("After updatePmtVersion ");
		}
		
		LOGGER.info("Completed updateRetryCount ");
		return bean;
	}
	
	
	public PayloadDTO updatePaymentSchedulerStatusFiller(PayloadDTO bean){
		BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO)bean.getResponseVO();
		// To update the table to set the client ref no as SCHEDULER (It is to identify whether this transaction is  done by scheduler or not)
		if(billerPayResponseVO!=null && billerPayResponseVO.getBillerPayDetailsVO()!=null){
			billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().setClientRefNo("");
		}
		bean.setResponseVO(billerPayResponseVO);
		
		return bean;
		
	}
	
	
	public PayloadDTO updatePaymentRevfVersionCount(PayloadDTO bean){
		LOGGER.info("Inside updateRevfVersionCount ");
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
		
		// for Reversal retry count(max 3)
		int version = 0; 
		
		int processingMode = 0;
		//processingMode = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getProcessingMode();
		version = billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().getVersion();
		version = version + 1;
		billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setVersion(version);
		//billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setProcessingMode(processingMode);
		LOGGER.info("Version {} ",new Object[]{version});
		LOGGER.info("Before updatePmtVersion ");
		paymentTransactionService.updatePmtVersion(billerPayRequestVO.getBillerPayDetailsVO());
		LOGGER.info("After updatePmtVersion ");
		return bean;
	}
	/**
	 * Inits the ciphers.
	 */
	public synchronized static void InitCiphers(byte[] key) {
		if (encryptCipher == null || decryptCipher== null) {
	        encryptCipher = new PaddedBufferedBlockCipher( new DESedeEngine());
	        encryptCipher.init(true, new KeyParameter(key));       
	        decryptCipher = new PaddedBufferedBlockCipher( new DESedeEngine());
	        decryptCipher.init(false, new KeyParameter(key));
		}
    }
	
	 /**
     * Decrypt.
     *
     * @param encValue the enc value
     * @return the string
     */
    public static String decrypt(String encValue) {
        String decResult = "";
 
        try {
            byte[] encryptedContent = Hex.decode(encValue);
            byte[] dec = new byte[decryptCipher.getOutputSize(encryptedContent.length)];
            int size1 = decryptCipher.processBytes(encryptedContent, 0, encryptedContent.length, dec, 0);
            int size2 = decryptCipher.doFinal(dec, size1);
            byte[] decryptedContent = new byte[size1 + size2];
            System.arraycopy(dec, 0, decryptedContent, 0, decryptedContent.length);
            decResult = new String(decryptedContent);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
 
        return decResult;
    }
	
    
    /**
     * Encrypt.
     *
     * @param value the value
     * @return the string
     */
    public static String encrypt(String value) {
        String encResult = "";
        try {
            byte[] enc = new byte[encryptCipher.getOutputSize(value.getBytes().length)];
            int size1 = encryptCipher.processBytes(value.getBytes(), 0, value.getBytes().length, enc, 0);
            int size2 = encryptCipher.doFinal(enc, size1);  
            byte[] encryptedContent = new byte[size1 + size2];
            System.arraycopy(enc, 0, encryptedContent, 0, encryptedContent.length);
 
            encResult = new String(Hex.encode(encryptedContent));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return encResult.toUpperCase();
    }
    
	public void setGson(Gson gson) {
		this.gson = gson;
	}


	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
	


}
