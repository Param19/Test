package com.scb.channels.payments.service.impl;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.ClientVO;
import com.scb.channels.base.vo.JobsVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.PaymentHistoryResponseVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.base.vo.ServiceVO;
import com.scb.channels.base.vo.UserVO;
import com.scb.channels.common.service.impl.DataBean;
import com.scb.channels.payments.dao.BillerDownloadDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.JobManagerService;

public class JobManagerServiceImpl implements JobManagerService {

	private BillerDownloadDAO billerDownloadDAO;
	
	private DataBean dataBean;
	
	/** LOGGER object * */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillerDownloadRequestCreateServiceImpl.class);
	
	@Override
	public boolean getjobStatus(String country, String Jobname) {

		String JobName=Jobname;
		String JvmName=InvoiceAggregatorhelper.getJVMName();
		boolean paymentRetryIntervalCheck = true;
	
		try{
		JobsVO job  =	billerDownloadDAO.getJobDetails(country, JobName);

		if(job==null){
			job=preareIntialStatus(country,Jobname);
			billerDownloadDAO.saveInitialJob(job);
			return true;
			
			}else{
				
				LOGGER.info("BillerDownloadJob status is "+job.getStatus());
				
				/*if(Jobname.equalsIgnoreCase(CommonConstants.PAYMENT_RETRY_JOB)){
					//Clusterd Env - Every 15 min only payment retry should execute
					long fromDB= Long.parseLong(dataBean.getMap().get(CommonConstants.PAYMENT_RETRY_TIMER));
					long addFifteenMinFrLasUpd  =  job.getJobLastUpdated().getTime()+ (fromDB * 1000);
					if(addFifteenMinFrLasUpd >  System.currentTimeMillis()){
						paymentRetryIntervalCheck = false;
					}
					}else if (Jobname.equalsIgnoreCase(CommonConstants.PAYMENT_INPROCESS_JOB)){
						long dbVal = Long.parseLong(dataBean.getMap().get(CommonConstants.PAYMENT_INPROCESS_TIMER));
						long addThirtyMinIn  =  job.getJobLastUpdated().getTime()+ (dbVal * 1000);
						if(addThirtyMinIn >  System.currentTimeMillis()){
							paymentRetryIntervalCheck = false;
					}
				}*/

			if(CommonConstants.COMPLETE.equalsIgnoreCase(job.getStatus())  && paymentRetryIntervalCheck){
				
				
					int updatedCount=billerDownloadDAO.updateJob(job,JvmName,CommonConstants.IN_PROGRESS);
					LOGGER.info("updatedCount"+updatedCount);

						if(updatedCount>0){
							LOGGER.info("Jobstatus is true");

							return true;
						}else{
							LOGGER.info("Jobstatus is flase");
							return false;
						}
					
					}else{
						
						return false;
					}
				 
				
			}
				
			 
			
		}catch(Exception error){
			error.printStackTrace();
			LOGGER.debug("Exception occured for job"+Jobname);
			LOGGER.debug("Error while getting job status "+error.getMessage());
			return false;
			
			
		}
		
	}
 
	
	
	public JobsVO preareIntialStatus(String Country, String JobName){
		JobsVO job= new JobsVO();
		String JvmName=InvoiceAggregatorhelper.getJVMName();
		LOGGER.info("jvm Name is  ----   "+JvmName);
		LOGGER.info("Intial Job name is "+JobName);
		job.setJobName(JobName);
		job.setCountryCode(Country);
		job.setJvmName(JvmName);
		job.setStatus(CommonConstants.IN_PROGRESS);
		job.setJobDescription(JobName);
		job.setJobLastUpdated(new Timestamp(System.currentTimeMillis()));
		
		return job;
	}
	
	
	public boolean finalJObupdateStaus(String country, String JobName){
		boolean jobStatus=false;
		
		try{
			String JvmName=InvoiceAggregatorhelper.getJVMName();
			JobsVO job =	billerDownloadDAO.getJobDetails(country, JobName);
			
			if(job!=null){
				int count=billerDownloadDAO.updateJob(job, JvmName,CommonConstants.COMPLETE);
					
				if(count>0){
					LOGGER.info(JobName+"Job is updated as Complete  successfully");
					return true;
				}else{
					
					LOGGER.info(JobName+"Job is updated as Complete  successfully");
				}
					
				}else{
					
					
					LOGGER.info("Job is not available for "+JobName);
					return false;
				}
		
		
		}catch(Exception error){
			error.printStackTrace();
			LOGGER.info("Job is not available for "+JobName);
			return false;
		}
		return false ;
		
	}
	
	
	public BillerDownloadDAO getBillerDownloadDAO() {
		return billerDownloadDAO;
	}


	public void setBillerDownloadDAO(BillerDownloadDAO billerDownloadDAO) {
		this.billerDownloadDAO = billerDownloadDAO;
	}



	public DataBean getDataBean() {
		return dataBean;
	}



	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}


	@Override
		public BillerDownloadResponseVO getBillerDownloadStatusCheck(
				BillerDownloadRequest billerDownloadRequest) {
			BillerDownloadResponseVO billerDownloadResponseVO = null;

			try {

				LOGGER.info("getBillerDownloadStatusCheck into DB {}}",
						new Object[] { billerDownloadRequest.getUser()
								.getCountry() });

				billerDownloadResponseVO = billerDownloadDAO.getBillerDownloadStatusCheck(billerDownloadRequest);

				LOGGER.info("At service class after DB Fetch getBillerDownloadStatusCheck {}}",new Object[] {billerDownloadResponseVO});

				return billerDownloadResponseVO;
				
			} catch (Exception e) {

				LOGGER.info("getBillerDownloadStatusCheck Error" + e.getMessage());

				throw e;

			}

		}
	
	@Override
	public boolean addJob(String country, String jobName) {
		
		JobsVO job= new JobsVO();
		String JvmName=InvoiceAggregatorhelper.getJVMName();
		LOGGER.info("jvm Name is  ----   "+JvmName);
		job.setJobName(jobName);
		job.setCountryCode(country);
		job.setJvmName(JvmName);
		job.setStatus(CommonConstants.IN_PROGRESS);
		job.setJobDescription(jobName);
		job.setJobLastUpdated(new Timestamp(System.currentTimeMillis()));
		
		Long returnValue = billerDownloadDAO.saveJob(job);
		
		boolean value = (returnValue != null && returnValue > 0L) ? true : false;
		
		return value;
	}
	
	@Override
	public void removeJob(String country, String jobName) {
		billerDownloadDAO.deleteJob(country, jobName);
	}
	
	@Override
	public PayloadDTO getJobPayloadForAudit(String jobName, String status) {
		
		PayloadDTO payload = new PayloadDTO();
		PaymentHistoryResponseVO response = new PaymentHistoryResponseVO();
		String environment = System.getProperty(CommonConstants.ENV);
		
		ServiceVO service = new ServiceVO();
		ClientVO client = new ClientVO();
		
		service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
		service.setServiceName(jobName);
		
		client.setEnvironment(environment);
		client.setClientIpAddress(InvoiceAggregatorhelper.getIpAddress());
		
		response.setServiceVO(service);
		response.setClientVO(client);
		response.setStatus(status);
		response.setCreatedBy(InvoiceAggregatorhelper.getJVMName());	payload.setResponseVO(response);
		
		return payload;
	}
	
	@Override
	public PayloadDTO getQRJobPayloadForAudit(String jobName, String status) {
		
		PayloadDTO payload = new PayloadDTO();
	
		QRPaymentResponseVO response = new QRPaymentResponseVO();
		String environment = System.getProperty(CommonConstants.ENV);
		
		ServiceVO service = new ServiceVO();
		ClientVO client = new ClientVO();
		
		service.setHostSystem(CommonConstants.SRM_SOURCE_SYSTEM_NAME);
		service.setServiceName(jobName);
		
		client.setEnvironment(environment);
		client.setClientIpAddress(InvoiceAggregatorhelper.getIpAddress());
		
		response.setServiceVO(service);
		response.setClientVO(client);
		response.setStatus(status);
		response.setCreatedBy(InvoiceAggregatorhelper.getJVMName());	
		payload.setResponseVO(response);
		
		return payload;
	}
}
