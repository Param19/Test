/**
 * 
 */
package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.service.ReferenceService;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;
import com.scb.channels.payments.service.PaymentTransactionFactory;
import com.scb.channels.payments.service.impl.PaymentTransactionServiceImpl;

/**
 * The Class BillerPayProcessor.
 *
 * @author 1464141
 */
public class AggregatorPostingProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AggregatorPostingProcessor.class);
	
	/** The payment transaction service. */
	private ReferenceService referenceService;
	private PaymentTransactionFactory paymentTransactionFactory;
	/**
	 * @param bean
	 * @return
	 */
	public PayloadDTO process(PayloadDTO bean) {
		LOGGER.info("Task of Posting payment to aggregator ::: Start");
		BillerPayRequestVO billerPayRequestVO = null;
		BillerPayResponseVO billerPayResponseVO = null;
		try {
			billerPayRequestVO = (BillerPayRequestVO)bean.getRequestVO();
			LOGGER.info("Send to service ::: " + 
					billerPayRequestVO.getBillerPayDetailsVO().getPayRef());
			
			//<!--  for Alipay wallet topup service -->
			/*ReferenceVO referenceVO = new ReferenceVO();			
			referenceVO.setCountryCode(billerPayRequestVO.getClientVO().getCountry());
			referenceVO.setChannelId(billerPayRequestVO.getClientVO().getChannel());
			referenceVO.setAggregator(billerPayRequestVO.getClientVO().getPartnerName());
			referenceVO.setType(billerPayRequestVO.getClientVO().getPartnerType());
			referenceVO.setApiVersion(CommonConstants.VERSION_2);
			
			String alipayWallet = referenceService.getReferenceMap(referenceVO).get(CommonConstants.SERVICE_NAME_KEY);
			*/
			/*String alipayWallet = referenceService.getReferenceMap(InvoiceAggregatorhelper.getReferenceVO(billerPayRequestVO)).get(CommonConstants.SERVICE_NAME_KEY);
			
			if(alipayWallet.equalsIgnoreCase(CommonConstants.AGGREGATOR_EVENT_TYPE)) { 
				alipayPaymentTransactionService.alipayAggregatorPayment(billerPayRequestVO);
			} else {
				paymentTransactionService.aggregatorPayment(billerPayRequestVO);
			}*/
			
			String className = referenceService.getReferenceMap(InvoiceAggregatorhelper.getReferenceVO(billerPayRequestVO)).get(CommonConstants.CLASS);
			
			if(className != null) {
				paymentTransactionFactory.getPaymentTransactionServiceImpl(className).aggregatorPayment(billerPayRequestVO);
			} 
			else if (CommonConstants.AFRICAN_COUNTRIES_IS.contains(billerPayRequestVO.getClientVO().getCountry())){
				className = PaymentTransactionServiceImpl.class.getSimpleName();
				paymentTransactionFactory.getPaymentTransactionServiceImpl(className).aggregatorPayment(billerPayRequestVO);
			} else if(CommonConstants.AFRICAN_COUNTRIES_CS.contains(billerPayRequestVO.getClientVO().getCountry())){
				className = PaymentTransactionServiceImpl.class.getSimpleName();
				paymentTransactionFactory.getPaymentTransactionServiceImpl(className).aggregatorPaymentCS(billerPayRequestVO);
			}
			else{
				billerPayRequestVO.getBillerPayDetailsVO()
					.setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
				billerPayRequestVO.getBillerPayDetailsVO()
					.getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
				billerPayRequestVO.getBillerPayDetailsVO()
					.getTransactionInfoVO().setHostRespDesc("Aggregator config not available");
				
				LOGGER.info("Implementation class Mapping not available in DB, so Cant proceed further");
				new Exception("Implementation class Mapping not available in DB, so Cant proceed further");
			}			
			
			LOGGER.info("aggregator Payment invoked using "+ className);
		}catch (Exception e) {
			//e.printStackTrace();
			LOGGER.error("Exception while posting payment to aggregator queue ::: " , e);
			
			billerPayRequestVO.getBillerPayDetailsVO().setTxnActStatus(CommonConstants.AGGREGATOR_PAY_FAILURE);
			billerPayRequestVO.getBillerPayDetailsVO()
				.getTransactionInfoVO().setHostRespCd(CommonConstants.FAIL);
			billerPayRequestVO.getBillerPayDetailsVO()
				.getTransactionInfoVO().setHostRespDesc(e.getMessage());
		}
		LOGGER.info("Task of Posting payment to aggregator ::: End");
		
		if(bean.getResponseVO() == null){
			billerPayResponseVO = new BillerPayResponseVO();
		} else {
			billerPayResponseVO = (BillerPayResponseVO) bean.getResponseVO();
		}
		
		billerPayResponseVO.setUser(billerPayRequestVO.getUser());
		billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
		billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
		billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
		billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
		bean.setResponseVO(billerPayResponseVO);
		
		return bean;
	}	

	public void setPaymentTransactionFactory(
			PaymentTransactionFactory paymentTransactionFactory) {
		this.paymentTransactionFactory = paymentTransactionFactory;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

}
