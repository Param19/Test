package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.ExceptionMessages;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponse;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.payments.service.ArchivalService;

public class ArchivalProcessor extends AbstractProcessor{
	
	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AddPayeeProcessor.class);
	
	private ArchivalService archivalService;

	public void setArchivalService(ArchivalService archivalService) {
		this.archivalService = archivalService;
	}

	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		
		LOGGER.info("Archival Processor inside doTasks method");
		BillerDownloadRequest billerDownloadRequest = null;
		BillerDownloadResponseVO billerDownloadResponse = null;
		
		try{
			billerDownloadRequest = (BillerDownloadRequest)bean.getRequestVO();
			billerDownloadResponse = archivalService.archive(billerDownloadRequest);
			LOGGER.info("Archival Processor after getting the response " + billerDownloadResponse);
			bean.setResponseVO(billerDownloadResponse);
			
		}catch(Exception ex){
			LOGGER.error("Exception block at DoTask --> Archival Processor "
					+ ex.getMessage());
			billerDownloadResponse.setErrorDesc(ExceptionMessages._161.getMessage());
			billerDownloadResponse.setErrorCD(ExceptionMessages._161.getCode());
			bean.setResponseVO(billerDownloadResponse);
		}
		
		return bean;
	}
	
}
