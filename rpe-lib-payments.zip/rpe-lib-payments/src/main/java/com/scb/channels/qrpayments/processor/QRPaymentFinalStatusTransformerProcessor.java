package com.scb.channels.qrpayments.processor;

import java.util.Date;

import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonHelper;
import com.scb.channels.qrpayments.QrPaymentRequestType;
import com.scb.channels.qrpayments.QrPaymentResponseType;

public class QRPaymentFinalStatusTransformerProcessor {
	
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(QRPaymentFinalStatusTransformerProcessor.class);

	public QrPaymentRequestType getObject(String qrPaymentRequestXML) {
		QrPaymentRequestType qrPaymentRequest = null;
		
		try {
			LOGGER.info("REQUEST IN TIME ::::::::::"+ new Date()+":::::Transforming qrpayment xml string to object message :::: " + qrPaymentRequestXML);
			qrPaymentRequest = (QrPaymentRequestType)CommonHelper.unMarshall(qrPaymentRequestXML, QrPaymentRequestType.class);
			
			if(qrPaymentRequest != null && qrPaymentRequest.getMessageContext() != null) {
				LOGGER.info("Transforming qrpayment request successful --- > "+ qrPaymentRequest.getMessageContext().getReqID());
			}
		
		} catch (TransformerException e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: "+ e.getMessage());
			LOGGER.error(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING PAYMENT REQUEST :::::: "+ e.getMessage());
			LOGGER.error(e.getMessage());
		}
		return qrPaymentRequest;
	}
	
	public String getResponseXml(QrPaymentResponseType qrPaymentResponse) {
		String responseXml = null;
		LOGGER.info("Transforming payment final status response object to xml string");
		try {
			responseXml = CommonHelper.getXML(qrPaymentResponse,
					QrPaymentResponseType.class, QrPaymentResponseType.class.getSimpleName());
			
			if(responseXml != null) {
				LOGGER.info("RESPONSE OUT TIME ::::::::::"+ new Date()+":::::Transforming qrpayment final status response xml successful --- > ::: " + responseXml);
			} else {
				LOGGER.info("RESPONSE OUT TIME ::::::::::"+ new Date()+":::::Transforming qrpayment final status response xml is NOT successful --- > ::: " + responseXml);
			}
			
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURRED WHILE GENERATING QRPAYMENT FINAL STATUS RESPONSE XML :::::: "+ e.getMessage());
			LOGGER.error(e.getMessage());
		}
		return responseXml;
	}
	
}
