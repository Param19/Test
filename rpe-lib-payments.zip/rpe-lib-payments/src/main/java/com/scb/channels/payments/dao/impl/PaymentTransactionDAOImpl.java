package com.scb.channels.payments.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.helper.HibernateHelper;
import com.scb.channels.base.vo.BillerPayDetailsVO;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.PaymentDetailVO;
import com.scb.channels.payments.dao.PaymentTransactionDAO;
import com.scb.channels.payments.helper.InvoiceAggregatorhelper;


/**
 * The Class PaymentTransactionDAOImpl.
 */
public class PaymentTransactionDAOImpl extends HibernateDaoSupport implements PaymentTransactionDAO {

	

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentTransactionDAOImpl.class);
	
	/**
	 * Update payment txn.
	 * 
	 * @param billerPayDetailsVO
	 *            the biller pay details vo
	 * @see com.scb.channels.transaction.billpayment.dao.PaymentTransactionDAO#updatePaymentTxn(com.scb.channels.common.vo.BillerPayDetailsVO)
	 */
	public void updatePaymentStatus(PaymentDetailVO payment) {
		LOGGER.info("updatePaymentStatus ::: transactionDaoImpl ::: Start");
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			LOGGER.info("Creating Session for update ::: " + payment.getReferenceNumber());
			session = getHibernateTemplate().getSessionFactory().openSession();
				
			LOGGER.info("Update the payment ::: " + payment.getReferenceNumber());
			transaction = session.beginTransaction();
			session.update(payment);
			
			transaction.commit();
			session.flush();
			LOGGER.info("Update complete ::: " + payment.getReferenceNumber());
			
		} catch (Exception exception) {
			 LOGGER.info("Exception for ::: " + payment.getReferenceNumber());
			 LOGGER.info("Exception occurred duirng update payment ::: " + exception);
			 LOGGER.error("",exception);
			 if (transaction != null) {
				LOGGER.info("Closing transaction in update payment");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in update payment");
				session.close();
			}
		}
		LOGGER.info("updatePaymentStatus ::: transactionDaoImpl ::: End");
	}
	
	public void updateRequestVOString(BillerPayDetailsVO billerPayDetailsVO) {
		Query query = getHibernateTemplate().getSessionFactory().openSession().createQuery(
		"Update BillerPayDetailsVO set payRef =:payRef, transactionInfoVO.dtUpd=:dtUpd, transactionInfoVO.updBy=:updBy where transactionInfoVO.messageVO.requestCode = :txnId");
		query.setParameter(HibernateHelper.PAY_REF, billerPayDetailsVO.getPayRef());
		query.setParameter(HibernateHelper.TXN_ID, billerPayDetailsVO.getTransactionInfoVO().getMessageVO().getRequestCode());
		query.setParameter(HibernateHelper.DATE_UPDATE, DateUtils.getCurrentDate());
		query.setParameter(HibernateHelper.UPDATE_BY, billerPayDetailsVO.getTransactionInfoVO().getUpdBy());
		query.executeUpdate();
	}


	public List<PaymentDetailVO> getReversalFailurePaymentTransactionList(
			BillerPayRequestVO billerPayRequestVO) {
		Criteria criteria = getHibernateTemplate().getSessionFactory().openSession().createCriteria(PaymentDetailVO.class); 
		criteria.add(Restrictions.eq("paymentStatus", CommonConstants.REVERSAL_PAY_TIMEOUT));
		criteria.add(Restrictions.lt("version", CommonConstants.THREE));
		List<PaymentDetailVO> list = criteria.list();
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list;
		}
	}

	/**
	 * updateBillPmtTxn ClientRefNum forAlertSuccess.
	 * 
	 * @param billerPayDetailsVO
	 *            the biller pay details vo
	 * @see com.scb.channels.transaction.billpayment.dao.PaymentTransactionDAO#updatePaymentTxn(com.scb.channels.common.vo.BillerPayDetailsVO)
	 */
	public void updatePmtVersion(BillerPayDetailsVO billerPayDetailsVO) {
		Query query = getHibernateTemplate().getSessionFactory().openSession().createQuery(
		"Update PaymentDetailVO set updatedTime=:dtUpd, version=:version where referenceNumber = :txnId");
		query.setParameter(HibernateHelper.TXN_ID, billerPayDetailsVO.getPayRef());
		query.setParameter("version", billerPayDetailsVO.getTransactionInfoVO().getVersion());
		query.setParameter(HibernateHelper.DATE_UPDATE, DateUtils.getCurrentDate());
		query.executeUpdate();
	}
	/**
	 * Save payment txn.
	 * 
	 * @param billerPayDetailsVO
	 *            the biller pay details vo
	 * @see com.scb.channels.transaction.billpayment.dao.PaymentTransactionDAO#savePaymentTxn(com.scb.channels.common.vo.BillerPayDetailsVO)
	 */
	public PaymentDetailVO savePayment(PaymentDetailVO payment) {
		LOGGER.info("savePayment ::: transactionDaoImpl ::: Start");
		Session session = null;
		Transaction transaction = null;
		 try{
			 LOGGER.info("create Session ::: " + payment.getReferenceNumber());
			 session = getHibernateTemplate().getSessionFactory().openSession();
			 
			 BigDecimal amount = payment.getPaymentAmount() != null ? 
					 payment.getPaymentAmount() : new BigDecimal(0);
			 
			 BigDecimal fees = payment.getFees() != null ? 
					 payment.getFees() : new BigDecimal(0);
					 
			 payment.setTotalAmount(amount.add(fees));
			 
			 transaction = session.beginTransaction();
			 LOGGER.info("saving payment ::: " + payment.getReferenceNumber());
			 payment.setCreatedBy(InvoiceAggregatorhelper.getJVMName());
			 payment.setUpdatedBy(InvoiceAggregatorhelper.getJVMName());
			 session.save(payment);
			 
			 transaction.commit();
			 session.flush();
			 LOGGER.info("Transaction committed ::: " + payment.getReferenceNumber());
		 } catch (Exception exception) {
			 exception.printStackTrace();
			 payment.setId(null);
			 LOGGER.info("Exception for ::: " + payment.getReferenceNumber());
			 LOGGER.info("Exception occurred duirng saving payment ::: ", exception);
			 LOGGER.error("",exception);
			 if(transaction != null) {
				 LOGGER.info("Closing transaction in save payment");
				 transaction.rollback();
			 }
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in save payment");
				 session.close();
			 }
		 }
		 
		 LOGGER.info("savePayment ::: transactionDaoImpl ::: End");
		 return payment;
	}



	@Override
	public PaymentDetailVO getPaymentDetails(String referenceNumber) {
		
		Session session = null;
		Criteria criteria = null;
		PaymentDetailVO dbPayment = null;
		try {
			 LOGGER.info("Creating Session for update ::: " + referenceNumber);
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria = session.createCriteria(PaymentDetailVO.class)
					.add(Restrictions.eq("referenceNumber", referenceNumber));
			
			Object object = criteria.uniqueResult();
			if(object != null) {
				dbPayment = (PaymentDetailVO) object;
				LOGGER.info("Obtained persistent object ::: " + referenceNumber);
			} else {
				LOGGER.info("No data in the DB for ::: " + referenceNumber);
			}
		} catch (Exception exception){
			 LOGGER.info("Exception for ::: " + referenceNumber);
			 LOGGER.info("Exception occurred duirng saving payment ::: " + exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in get payment details");
				 session.close();
			 }
		 }
		
		return dbPayment;
	}
	
	public List<PaymentDetailVO> getPaymentRetryList(BillerPayRequestVO billerPayRequestVO,
			Date fromDate,Date toDate, Timestamp updatedTimeStamp, int retryCount, 
			List<String> statusList, List<String> countries) {
		Session session = null;
		Criteria criteria = null;
		List<PaymentDetailVO> list = new ArrayList<PaymentDetailVO>();
		try{
			LOGGER.debug("Inside getPaymentRetryList befor  DB Fetch ");
		 session = getHibernateTemplate().getSessionFactory().openSession();
		 criteria =session.createCriteria(PaymentDetailVO.class); 
		criteria.add(Restrictions.in(HibernateHelper.COUNTRY_CODE, countries));
		criteria.add(Restrictions.between("paymentDate", fromDate, toDate));
		criteria.add(Restrictions.lt("updatedTime", updatedTimeStamp));
		criteria.add(Restrictions.in(HibernateHelper.PAYMENT_STATUS, statusList));
		criteria.add(Restrictions.le("version", retryCount));
		list = criteria.list();
		LOGGER.debug("Inside getPaymentRetryList After  DB Fetch List "+list);
		
		if (!list.isEmpty()) {
			//Deleting duplicate records 
			Set<PaymentDetailVO> setValueFrDB = new LinkedHashSet<PaymentDetailVO>(list);
			List<PaymentDetailVO> modifiedResponse  =new LinkedList<PaymentDetailVO>(setValueFrDB);
			list = modifiedResponse;
			logger.info("After DB Fetch at getPaymentRetryList Datalayer payment Retry size  "
					+ list.size());
		}
		} catch (Exception exception){
			 LOGGER.info("Exception occurred duirng saving payment ::: " + exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in getPaymentRetryList details");
				 session.close();
			 }
		 }
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list;
		}
		
	}

	public List<PaymentDetailVO> getInprocessPayments(Date fromDate,Date toDate,
			Timestamp updatedTimeStamp, int retryCount, List<String> countries) {
		Session session = null;
		Criteria criteria = null;
		List<PaymentDetailVO> list = new ArrayList<PaymentDetailVO>();
		try{
			LOGGER.debug("Inside getInprocessPayments before  DB Fetch ");
			session = getHibernateTemplate().getSessionFactory().openSession();
			criteria =session.createCriteria(PaymentDetailVO.class); 
			criteria.add(Restrictions.in(HibernateHelper.COUNTRY_CODE, countries));
			criteria.add(Restrictions.between("paymentDate", fromDate, toDate));
			criteria.add(Restrictions.lt("updatedTime", updatedTimeStamp));
			criteria.add(Restrictions.eq(HibernateHelper.PAYMENT_STATUS, CommonConstants.AGGREGATOR_INPROCESS));
			criteria.add(Restrictions.le("version", retryCount));
			list = criteria.list();
		LOGGER.debug("Inside getInprocessPayments After  DB Fetch List "+list);
		if (!list.isEmpty()) {
			//Deleting duplicate records 
			Set<PaymentDetailVO> setValueFrDB = new LinkedHashSet<PaymentDetailVO>(list);
			List<PaymentDetailVO> modifiedResponse  =new LinkedList<PaymentDetailVO>(setValueFrDB);
			list = modifiedResponse;
			logger.info("After DB Fetch at getInprocessPayments Datalayer payment InprocessPayments size  "
					+ list.size());
		}
		} catch (Exception exception){
			 LOGGER.info("Exception occurred while retriving in-process payments ::: ", exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in getInprocessPayments");
				 session.close();
			 }
		 }
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list;
		}
		
	}
	
	@Override
	public String getReferenceNumberSequence(
			BillerPayRequestVO billerPayRequestVO) {
LOGGER.info("Payment getReferenceNumberSequence method Start::");
		
		Session session = null;
		String key=null;
		try {
 			session = getHibernateTemplate().getSessionFactory().openSession();
			Query query = session.getNamedQuery("RefrenceNumberFun");
			key =query.uniqueResult().toString();
			LOGGER.info("Sequence Number is:: "+key);
		    return key;
	       }catch(Exception ex) {
		 ex.printStackTrace();
		   LOGGER.error("Exception occurred duirng Sequence Number ::: " + ex.getMessage());
		 
	} finally {
		if(session != null) {
			LOGGER.info("PaymentTransactionDAOImpl closing Session ");
			session.close();
		}

	}
		return key;


	}
	
		@Override
		public String getCCReferenceNumberSequence(BillerPayRequestVO billerPayRequestVO) {
			LOGGER.info("PaymentTransactionDAOImpl: getCCReferenceNumberSequence method Start::");
			
			Session session = null;
			String key=null;
			try {
	 			session = getHibernateTemplate().getSessionFactory().openSession();
				Query query = session.getNamedQuery("CCReferenceNumberFun");//CCReferenceNumberFun
				LOGGER.info("PaymentTransactionDAOImpl : Query: "+query);
				key =query.uniqueResult().toString();
				LOGGER.info("getCCReferenceNumberSequence: Sequence Number is:: "+key);
			    return key;
		       }catch(Exception ex) {
			 ex.printStackTrace();
			   LOGGER.error("Exception occurred duirng Sequence Number ::: " + ex.getMessage());
			 
		} finally {
			if(session != null) {
				LOGGER.info("PaymentTransactionDAOImpl : getCCReferenceNumberSequence : closing Session ");
				session.close();
			}
	
		}
			return key;
	
		}
}
