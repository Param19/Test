package com.scb.channels.payments.dao;

import java.util.List;

import com.scb.channels.base.vo.BackupMasterBillerCategoryVO;
import com.scb.channels.base.vo.BillerCategoryVO;
import com.scb.channels.base.vo.BillerCatgegoryReference;
import com.scb.channels.base.vo.BillerDownloadRequest;
import com.scb.channels.base.vo.BillerDownloadResponseVO;
import com.scb.channels.base.vo.JobsVO;
import com.scb.channels.base.vo.TempBillerCategoryVO;

public interface BillerDownloadDAO {

	/**
	 * @param Country
	 * @return Integer
	 */
	public Integer getCountBillerCategories(String Country);
	
	/**
	 * <p>used for the store  aggragator Data in DB intemp table
	 * @param aggregatorlist
	 */
	public void saveAggregatorData(List<TempBillerCategoryVO> aggregatorCategory);
	
	/**
	 * <p>used for the remove   aggragator Data in DB in temp  all  three tables
	 * @param aggregatorlist
	 */
	public void deleteTemporayTableData(String country);
	/**
	 * <p>save masterBillers
	 * @param masterCatgegories
	 */
	public void saveMasterBiller(List<BillerCategoryVO> masterCatgegories);
	
	/**
	 * <p> retrive Master Biller
	 * @param masterCatgegories
	 */
	public List<BillerCategoryVO> getAllMasterBillersforCountry(String Country,String[] categorys,String[] billers);
	
	/**
	 * @param country
	 * @return list<BillerCatgegoryReference>
	 * 
	 * <p> getactegories from ref table
	 */
	public List<BillerCatgegoryReference> getCategoriesFromRef(String country);
	
	/**
	 * @param category
	 * @param country
	 * @return
	 */
	public List<BillerCatgegoryReference> getCategoryReference(List<String> category, String country);
		
	
			/**
	 * @param Country
	 * @param MasterData
	 * 
	 * <p> taking back up information
	 */
	public void saveBackupDatafromMaster(String Country,List<BackupMasterBillerCategoryVO> MasterData);
	
	
	/**
	 * @param country
	 * @param jobName
	 * @return
	 */
	public JobsVO getJobDetails(String country,String jobName);
	
	
	/**
	 * @param job
	 */
	public void saveInitialJob(JobsVO job);
	
	
	 
	/**
	 * @param job
	 * @param jvmName
	 */
	public int updateBillerJobProgress(JobsVO job,String jvmName);
	
 
	/**
	 * @param country
	 * @return
	 */
	public int updatefinalJobStatus(String country);
	

	public int updateJob(JobsVO job,String JVMName,String  newStatus);
	
	public BillerDownloadResponseVO getBillerDownloadStatusCheck(
			BillerDownloadRequest billerDownloadRequest);
	
	public Long saveJob(JobsVO job);
	public void deleteJob(String country, String jobName);
	
	public BillerDownloadResponseVO saveUpdatePayeesOnceDownloadDone(String country);
	
	
		
 }
