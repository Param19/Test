package com.scb.channels.qrpayments.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.scb.channels.base.helper.DateUtils;
import com.scb.channels.base.vo.ISOCODESVO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentHistoryRequestVO;
import com.scb.channels.base.vo.QRPaymentVO;
import com.scb.channels.qrpayments.dao.QRPaymentDAO;

public class QRPaymentDAOImpl extends HibernateDaoSupport implements QRPaymentDAO{

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(QRPaymentDAOImpl.class);
	
	@Override
	public QRPaymentVO savePayment(QRPaymentVO qrpaymentvo) throws Exception {
		LOGGER.info("savePayment ::: QRPaymentDAOImpl ::: Start");
		Session session = null;
		Transaction transaction = null;
		try{
			 LOGGER.info("saving payment ::: " + qrpaymentvo.getClient_reference());
			session = getHibernateTemplate().getSessionFactory().openSession();	
			transaction = session.beginTransaction();
			qrpaymentvo.setCreated_by(qrpaymentvo.getJvmName());
			qrpaymentvo.setUpdated_by(qrpaymentvo.getJvmName());
			session.saveOrUpdate(qrpaymentvo);
			transaction.commit();
			LOGGER.info("Transaction commited  ::: " + qrpaymentvo.getClient_reference());
			session.flush();
			//session.close();
		}catch(Exception e){
			qrpaymentvo.setQrpayment_id(null);
			LOGGER.info("Exception occurred duirng saving payment ::: " + qrpaymentvo.getClient_reference());
			 LOGGER.error("Exception occurred duirng saving payment ::: ",e);
			if(transaction != null) {
				 LOGGER.info("Closing transaction in qr save payment");
				 transaction.rollback();
			 }
			throw new Exception(e);
		}finally {
			if( session != null){
			 LOGGER.info("Closing session in save payment");
			 session.close();
	   	     }
		}
		 LOGGER.info("savePayment ::: QRPaymentDAOImpl ::: End");
		return qrpaymentvo;
	}

	@Override
	public String getQRReferenceNumber(QRPaymentDetailVO qrPaymentDetailVO) {

		LOGGER.info("Payment getQRReferenceNumberSequence method Start::");
		
		Session session = null;
		String key=null;
		//String functionName = null;
		try {
 			session = getHibernateTemplate().getSessionFactory().openSession();
 			/*if(qrPaymentDetailVO.getCountryCode() != null && qrPaymentDetailVO.getCard_type() != null)
 				functionName = qrPaymentDetailVO.getCountryCode()+CommonConstants.UNDERSCORE+qrPaymentDetailVO.getSourceOfFund()+CommonConstants.UNDERSCORE+"QRRefrenceNumberFun";
 			else
 				functionName = "QRRefrenceNumberFun";*/
 			
			Query query = session.getNamedQuery("QRRefrenceNumberFun");
			key =query.uniqueResult().toString();
			LOGGER.info("QR Sequence Number is:: "+key);
		    return key;
	       }catch(Exception ex) {
	    	   ex.printStackTrace();
		   LOGGER.error("Exception occurred duirng Sequence Number ::: " + ex.getMessage());
		 
	} finally {
		if(session != null) {
			LOGGER.info("QRPaymentDAOImpl closing Session ");
			session.close();
		}

	}
		return key;

	}

	@Override
	public void updatePaymentStatus(QRPaymentVO qrPaymentVO) {
		LOGGER.info("updatePaymentStatus ::: transactionDaoImpl ::: Start");
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			LOGGER.info("Creating Session for update ::: " + qrPaymentVO.getClient_reference());
			session = getHibernateTemplate().getSessionFactory().openSession();
			//System.out.println(qrPaymentVO.toString());	
			transaction = session.beginTransaction();
			session.update(qrPaymentVO);
			
			transaction.commit();
			session.flush();
			LOGGER.info("Update complete ::: " + qrPaymentVO.getClient_reference());
			
		} catch (Exception exception) {
			 LOGGER.info("Exception for ::: " + qrPaymentVO.getClient_reference());
			 LOGGER.info("Exception occurred duirng update payment ::: " + exception);
			 LOGGER.error("",exception);
			 if (transaction != null) {
				LOGGER.info("Closing transaction in update payment");
				transaction.rollback();
			}
		} finally {
			if (session != null) {
				LOGGER.info("Closing session in update payment");
				session.close();
			}
		}
		LOGGER.info("updatePaymentStatus ::: transactionDaoImpl End :::"+qrPaymentVO.getClient_reference());
	}

	@Override
	public QRPaymentVO getQRPaymentDetails(String client_reference) {
		
		Session session = null;
		Criteria criteria = null;
		QRPaymentVO dbQRPayment = null;
		try {
			 LOGGER.info("Creating Session for select ::: " + client_reference);
			session = getHibernateTemplate().getSessionFactory().openSession();
			/*criteria = session.createCriteria(QRPaymentVO.class)
					.add(Restrictions.eq("host_reference", host_reference));*/
			/**Changing the input parameter to client reference*/
			criteria = session.createCriteria(QRPaymentVO.class)
					.add(Restrictions.eq("client_reference", client_reference));
			
			Object object = criteria.uniqueResult();
			if(object != null) {
				dbQRPayment = (QRPaymentVO) object;
				LOGGER.info("Obtained persistent object ::: " + client_reference);
				LOGGER.info("Obtained persistent object ::: " + dbQRPayment.toString());
			} else {
				LOGGER.info("No data in the DB for ::: " + client_reference);
			}
		} catch (Exception exception){
			 LOGGER.info("Exception for ::: " + client_reference);
			 LOGGER.info("Exception occurred duirng saving payment ::: " + exception);
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in get payment details");
				 session.close();
			 }
		 }		
		return dbQRPayment;
	}

	@Override
	public List<QRPaymentVO> getPaymentHistoryByCustId(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO) {

		List<QRPaymentVO> qrPaymentVOList = null;
		Session session = null;
		try{
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(QRPaymentVO.class);
			criteria.add(Restrictions.eq("customer_id", qrPaymentHistoryRequestVO.getUser().getCustomerId()));
	          if(qrPaymentHistoryRequestVO.getUser().getCountry()!= null){
	        	  criteria.add(Restrictions.eq("country_code", qrPaymentHistoryRequestVO.getUser().getCountry()));
	          }
	          if(qrPaymentHistoryRequestVO.getFromDate() != null){
	              LOGGER.info("At QR PaymentHistory Service getQRPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{qrPaymentHistoryRequestVO.getFromDate(), qrPaymentHistoryRequestVO.getToDate()});
	              Calendar cal = DateUtils.getCountryCalendar();
	              Date toDat = cal.getTime();
	              if(qrPaymentHistoryRequestVO.getToDate() !=  null){
	                 toDat = qrPaymentHistoryRequestVO.getToDate();
	              }
	              LOGGER.info("At QR PaymentHistory Service iff part getQRPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{qrPaymentHistoryRequestVO.getFromDate(), toDat});
	              criteria.add(Restrictions.between("payment_date", qrPaymentHistoryRequestVO.getFromDate(), toDat)); 
	          }else{

	              Calendar calendar = DateUtils.getCountryCalendar();
	              calendar.add(Calendar.DAY_OF_YEAR, -7);
	              Date fromDate = calendar.getTime();
	              Calendar cal = DateUtils.getCountryCalendar();
	              Date toDate = cal.getTime();
	              LOGGER.info("At QR PaymentHistory Service elseeeeee part getQRPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{fromDate, toDate});
	              criteria.add(Restrictions.between("payment_date", fromDate, toDate));
	          }
	          	criteria.addOrder(Order.desc("payment_date"));
	          	logger.info("beforre DB Fetch  ## at getQRCustomerPaymentHistory payment history");
	          	qrPaymentVOList = criteria.list();
	          	logger.info("After DB Fetch at getQRCustomerPaymentHistory payment history size  ");
	  			if (!qrPaymentVOList.isEmpty()) {
	  				//Deleting duplicate records 
	  				Set<QRPaymentVO> setValueFrDB = new LinkedHashSet<QRPaymentVO>(qrPaymentVOList);
	  				List<QRPaymentVO> modifiedResponse  =new LinkedList<QRPaymentVO>(setValueFrDB);
	  				qrPaymentVOList = modifiedResponse;
	  				logger.info("After DB Fetch at getQRCustomerPaymentHistory Datalayer payment history size  "+ qrPaymentVOList.size());
	  			}
	
		}catch(Exception e) {
			 LOGGER.info("Exception occurred duirng QRPaymentHistory::: ");
		} finally {
			if(session != null) {
				LOGGER.info("PaymentDAOImpl :PaymentHistory, closing Session ");
				session.close();
			}
		}
		return qrPaymentVOList;	
	}	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<QRPaymentVO> getPaymentHistoryViewByCustId(QRPaymentHistoryRequestVO qrPaymentHistoryRequestVO) {

		//List<QRPaymentViewVO> qrPaymentVOList = null;
		List<QRPaymentVO> qrPaymentVOList = null;
		Session session = null;
		boolean listFlag = false;
		try{
			session = getHibernateTemplate().getSessionFactory().openSession();
			//Criteria criteria = session.createCriteria(QRPaymentViewVO.class);
			Criteria criteria = session.createCriteria(QRPaymentVO.class);
			criteria.add(Restrictions.eq("customer_id", qrPaymentHistoryRequestVO.getUser().getCustomerId()));
	          if(qrPaymentHistoryRequestVO.getUser().getCountry()!= null){
	        	  criteria.add(Restrictions.eq("country_code", qrPaymentHistoryRequestVO.getUser().getCountry()));
	          }
	          if(qrPaymentHistoryRequestVO.getFromDate() != null){
	              LOGGER.info("At QR PaymentHistory Service getQRPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{qrPaymentHistoryRequestVO.getFromDate(), qrPaymentHistoryRequestVO.getToDate()});
	              Calendar cal = DateUtils.getCountryCalendar();
	              Date toDat = cal.getTime();
	              if(qrPaymentHistoryRequestVO.getToDate() !=  null){
	                 toDat = qrPaymentHistoryRequestVO.getToDate();
	              }
	              LOGGER.info("At QR PaymentHistory Service iff part getQRPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{qrPaymentHistoryRequestVO.getFromDate(), toDat});
	              criteria.add(Restrictions.between("payment_date", qrPaymentHistoryRequestVO.getFromDate(), toDat)); 
	          }else{

	              Calendar calendar = DateUtils.getCountryCalendar();
	              calendar.add(Calendar.DAY_OF_YEAR, -7);
	              Date fromDate = calendar.getTime();
	              Calendar cal = DateUtils.getCountryCalendar();
	              Date toDate = cal.getTime();
	              LOGGER.info("At QR PaymentHistory Service elseeeeee part getQRPaymentHistoryByCustId From Date {} and To Date {}",new Object[]{fromDate, toDate});
	              criteria.add(Restrictions.between("payment_date", fromDate, toDate));
	          }
	          	criteria.addOrder(Order.desc("payment_date"));
	          	LOGGER.info("beforre DB Fetch  ## at getQRCustomerPaymentHistory payment history");
	          	qrPaymentVOList = criteria.list();
	          	LOGGER.info("After DB Fetch at getQRCustomerPaymentHistory payment history size  ");
	  			if (!qrPaymentVOList.isEmpty()) {
	  				//Deleting duplicate records 
	  				/*Set<QRPaymentVO> setValueFrDB = new LinkedHashSet<QRPaymentVO>(qrPaymentVOList);
	  				List<QRPaymentVO> modifiedResponse  =new LinkedList<QRPaymentVO>(setValueFrDB);
	  				for(QRPaymentVO qRPaymentViewVOList : modifiedResponse)*/
	  				for(QRPaymentVO qRPaymentViewVOList : qrPaymentVOList)
	  				{
	  					listFlag=false;
	  					LOGGER.info("qRPaymentViewVOList.getPayment_status()::::"+qRPaymentViewVOList.getPayment_status());
	  					if(!(qRPaymentViewVOList.getPayment_status().equals("NEW") || 
	  							qRPaymentViewVOList.getPayment_status().equals("SAVESUCC")))
	  					{
	  						if(qRPaymentViewVOList.getPayment_status().equals("AGGPAYSUCC"))
	  						{
	  							listFlag=true;
	  							qRPaymentViewVOList.setPayment_status("SUCCESS");
	  						}else if(qRPaymentViewVOList.getPayment_status().equals("AGGTMOUT")||qRPaymentViewVOList.getPayment_status().equals("TIMEOUT")
	  								||qRPaymentViewVOList.getPayment_status().equals("ACQTMOUT"))
	  						{
	  							listFlag=true;
	  							qRPaymentViewVOList.setPayment_status("SUBMITTED");
	  						}
	  						
	  						if(!listFlag)
	  						{
	  							qRPaymentViewVOList.setPayment_status("FAILURE");
	  						}
	  						LOGGER.info("listFlag::::::"+listFlag);
	  						LOGGER.info("qRPaymentViewVOList.getPayment_status()::::"+qRPaymentViewVOList.getPayment_status());
	  					}
	  				}
	  				//qrPaymentVOList = modifiedResponse;
	  				LOGGER.info("After DB Fetch at getQRCustomerPaymentHistory Datalayer payment history size  "+ qrPaymentVOList.size());
	  			}
	
		}catch(Exception e) {
			 LOGGER.info("Exception occurred duirng QRPaymentHistory::: ");
		} finally {
			if(session != null) {
				LOGGER.info("PaymentDAOImpl :PaymentHistory, closing Session ");
				session.close();
			}
		}
		return qrPaymentVOList;	
	}
	
	public ISOCODESVO getIsoCodesVo(String countryCode)
	{
		ISOCODESVO dbIsoCodes = null;
		Session session = null;
		try{
			LOGGER.info("Fetching ISO Codes for following country::::"+countryCode);
			session = getHibernateTemplate().getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(ISOCODESVO.class);
			criteria.add(Restrictions.eq("countrycode", countryCode));
			Object object = criteria.uniqueResult();
			if(object != null) {
				dbIsoCodes = (ISOCODESVO) object;
				LOGGER.info("Obtained persistent object ::: " + countryCode);
			} else {
				LOGGER.info("No data in the DB for ::: " + countryCode);
			}
		}catch(Exception e)
		{
			 LOGGER.info("Exception occurred duirng fetching IsoCodes::: ");
			 e.printStackTrace();
		} finally {
			if(session != null) {
				LOGGER.info("QRPaymentDAOImpl :IsoCodes, closing Session ");
				session.close();
			}
		}
		return dbIsoCodes;
	}

	@Override
	public List<QRPaymentVO> getQRPaymentRetryList(Date fromDate, Date toDate,Timestamp updatedTimeStamp,int retryCount,List<String> statusList, String country,String sourceOfFund){
		
		Session session = null;
		Criteria criteria = null;
		List<QRPaymentVO> list = new ArrayList<QRPaymentVO>();
		try{
			LOGGER.debug("Inside getQRPaymentRetryList before  DB Fetch ");
		session = getHibernateTemplate().getSessionFactory().openSession();
		criteria =session.createCriteria(QRPaymentVO.class); 
		criteria.add(Restrictions.eq("country_code", country));
		criteria.add(Restrictions.eq("payment_type", sourceOfFund));
		criteria.add(Restrictions.between("payment_date", fromDate, toDate));
		criteria.add(Restrictions.lt("updated_timestamp", updatedTimeStamp));
		criteria.add(Restrictions.in("payment_status", statusList));
		criteria.add(Restrictions.le("version", retryCount));
		list = criteria.list();
		/*		
		if (!list.isEmpty()) {
			//Deleting duplicate records 
			Set<QRPaymentVO> setValueFrDB = new LinkedHashSet<QRPaymentVO>(list);
			List<QRPaymentVO> modifiedResponse  =new LinkedList<QRPaymentVO>(setValueFrDB);
			list = modifiedResponse;
			LOGGER.info("After DB Fetch at getQRPaymentRetryList Datalayer payment Retry size  "+ list.size());
		}*/
		if (!list.isEmpty()) {
			LOGGER.debug("Inside getQRPaymentRetryList After  DB Fetch List "+list.size());
		}
		} catch (Exception exception){
			 LOGGER.info("Exception occurred duirng getQRPaymentRetryList ::: " + exception);
			 exception.printStackTrace();
		 } finally {
			 if( session != null){
				 LOGGER.info("Closing session in getQRPaymentRetryList details");
				 session.close();
			 }
		 }
		if (CollectionUtils.isEmpty(list)) {
			return null;
		} else {
			return list;
		}
		
	}
	
}
