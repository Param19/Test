package com.scb.channels.payments.helper;

public class PaymentErrorConstant {
	
	 public static final String ERR_PYMT_GENERAL_FAILURE = "ERR_PYMT_GENERAL_FAILURE";
	 public static final String ERR_PYMT_EDMI_HOST_TIMEOUT ="ERR_PYMT_EDMI_HOST_TIMEOUT";
	 public static final String ERR_INVALID_ERROR_CODE ="ERR_INVALID_ERROR_CODE";
	 public static final String ERR_PAYEE_GENERAL_FAILURE = "ERR_PAYEE_GENERAL_FAILURE";
	 public static final String SOCKET_TIMEOUT = "SOCKET_TIMEOUT";
}
