package com.scb.channels.qrpayments.processor;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.vo.HostResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.base.vo.QRPaymentDetailVO;
import com.scb.channels.base.vo.QRPaymentRequestVO;
import com.scb.channels.base.vo.QRPaymentResponseVO;
import com.scb.channels.common.processor.AbstractProcessor;
import com.scb.channels.common.processor.BusinessException;
import com.scb.channels.qrpayments.service.QRPaymentTransactionService;

public class QRPaymentGetTxnStatusProcessor extends AbstractProcessor {

	private QRPaymentTransactionService qrPaymentTransactionService;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(QRPaymentUpdateTransactionProcessor.class);

	@Override
	protected PayloadDTO doTasks(PayloadDTO bean) throws BusinessException {
		LOGGER.info("Get Payment Status processor ::: Start");
		try {
			QRPaymentRequestVO qrPaymentRequestVO = null;
			QRPaymentResponseVO qrPaymentResponseVO = null;
			qrPaymentRequestVO = (QRPaymentRequestVO) bean.getRequestVO();
			//LOGGER.info("Getting the status for the Transaction Reference Number :::: "+ qrPaymentRequestVO.getQrPaymentDetailVO().getClient_reference());
			qrPaymentResponseVO = qrPaymentTransactionService.getQRPaymentTxnStatus(qrPaymentRequestVO);
			Set<HostResponseVO> hostResponseList = new HashSet<HostResponseVO>();
			qrPaymentRequestVO.setHostResponseVO(hostResponseList);
			if(qrPaymentResponseVO.getQrPaymentDetailVO() == null){
				QRPaymentDetailVO qrPaymentDetailVO = new QRPaymentDetailVO();
				qrPaymentResponseVO.setQrPaymentDetailVO(qrPaymentDetailVO);
			}
					
			LOGGER.info("Fetch status complete :::: "+ qrPaymentResponseVO.getQrPaymentDetailVO().getClient_reference());
			bean.setResponseVO(qrPaymentResponseVO);
			bean.setRequestVO(qrPaymentRequestVO);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			throw new BusinessException();
		}
		return bean;
	}

	public QRPaymentTransactionService getQrPaymentTransactionService() {
		return qrPaymentTransactionService;
	}

	public void setQrPaymentTransactionService(
			QRPaymentTransactionService qrPaymentTransactionService) {
		this.qrPaymentTransactionService = qrPaymentTransactionService;
	}

}
