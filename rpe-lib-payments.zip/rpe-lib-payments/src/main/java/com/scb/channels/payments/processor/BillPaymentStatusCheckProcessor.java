package com.scb.channels.payments.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.channels.base.helper.CommonConstants;
import com.scb.channels.base.vo.BillerPayRequestVO;
import com.scb.channels.base.vo.BillerPayResponseVO;
import com.scb.channels.base.vo.PayloadDTO;
import com.scb.channels.payments.service.PaymentTransactionService;

public class BillPaymentStatusCheckProcessor {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BillPaymentStatusCheckProcessor.class);
	
	/** The payment transaction service. */
	private PaymentTransactionService paymentTransactionService;

	public PayloadDTO process(PayloadDTO payloadDTO) {
		LOGGER.info("Inside BillPaymentStatusCheckProcessor");
		BillerPayRequestVO billerPayRequestVO = (BillerPayRequestVO)payloadDTO.getRequestVO();
		BillerPayResponseVO billerPayResponseVO = null;
		
		try {
			if(billerPayRequestVO != null){
				String requestCode = billerPayRequestVO.getBillerPayDetailsVO().getPayRef();
				
				LOGGER.info("Before updating intermediate status ::::::: " + requestCode);
				//Sending request to EDMI
				try{
					LOGGER.info("Before hitting edmi service");
					billerPayRequestVO.getBillerPayDetailsVO().getTransactionInfoVO().setTxnId(requestCode);
					billerPayResponseVO = new BillerPayResponseVO();
					billerPayResponseVO = paymentTransactionService.paymentStatusCheck(billerPayRequestVO);
					LOGGER.info("After getting response from edmi service");
					
				}catch (Exception e) {
					LOGGER.error("Exception occurred ::: ",e);
					billerPayResponseVO.setUser(billerPayRequestVO.getUser());
					billerPayResponseVO.setMessageVO(billerPayRequestVO.getMessageVO());
					billerPayResponseVO.setClientVO(billerPayRequestVO.getClientVO());
					billerPayResponseVO.setServiceVO(billerPayRequestVO.getServiceVO());
					billerPayResponseVO.setBillerPayDetailsVO(billerPayRequestVO.getBillerPayDetailsVO());
					
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 		setTxnStatusCd(CommonConstants.FAIL);
				
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 			setHostRespCd("-1");
					
					billerPayResponseVO.getBillerPayDetailsVO().getTransactionInfoVO().
			 			setHostRespDesc(e.getMessage());
				}

				payloadDTO.setResponseVO(billerPayResponseVO);
			}
		}catch (Exception e) {
			LOGGER.error("Exception occurred ::: ",e);
		}
		
		return payloadDTO;
	}

	/**
	 * Gets the payment transaction service.
	 *
	 * @return the paymentTransactionService
	 */
	public PaymentTransactionService getPaymentTransactionService() {
		return paymentTransactionService;
	}

	/**
	 * Sets the payment transaction service.
	 *
	 * @param paymentTransactionService the paymentTransactionService to set
	 */
	public void setPaymentTransactionService(
			PaymentTransactionService paymentTransactionService) {
		this.paymentTransactionService = paymentTransactionService;
	}
	
	
	
	/*public void updatePaymentStatus1(PayloadDTO payloadDTO){
		BillerPayResponseVO billerPayResponseVO = (BillerPayResponseVO) payloadDTO.getResponseVO();
		BillerPayDetailsVO billerPayDetailsVO = billerPayResponseVO.getBillerPayDetailsVO();
		paymentTransactionService.updatePaymentStatus(billerPayResponseVO.getBillerPayDetailsVO());
		
	}*/
}
